Available tested versions:

* Knative Serving: 1.11.0, Knative Operator: 1.11.7, Istio: 1.18.2, Certmanager: 1.13.3, tested on kubernetes: 1.28.0

* Knative Serving: 1.12.3, Knative Operator: 1.12.2, Istio: 1.19.6, Certmanager: 1.13.3, tested on kubernetes: 1.28.3

* Knative Serving: 1.13.1, Knative Operator: 1.13.1, Istio: 1.20.2, Certmanager: 1.13.3, tested on kubernetes: 1.29.0

* Knative Serving: 1.14.1, Knative Operator: 1.14.3, Istio: 1.21.1, Certmanager: 1.13.3, tested on kubernetes: 1.29.4

* Knative Serving: 1.14.1, Knative Operator: 1.14.5, Istio: 1.21.1, Certmanager: 1.13.3, tested on kubernetes: 1.30.2

* Knative Serving: 1.15.0, Knative Operator: 1.15.0, Istio: 1.22.2, Certmanager: 1.13.3, tested on kubernetes: 1.30.2

* Knative Serving: 1.15.1, Knative Operator: 1.15.1, Istio: 1.22.2, Certmanager: 1.13.3, tested on kubernetes: 1.30.3
* Knative Serving: 1.15.2, Knative Operator: 1.15.2, Istio: 1.22.2, Certmanager: 1.13.3, tested on kubernetes: 1.30.3

* Knative Serving: 1.15.2, Knative Operator: 1.15.4, Istio: 1.22.2, Certmanager: 1.13.3, tested on kubernetes: 1.30.4
