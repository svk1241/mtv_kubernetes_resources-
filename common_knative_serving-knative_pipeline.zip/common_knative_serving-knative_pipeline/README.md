## Common Knative Serving

### Summary

This repository contains automation of Knative Serving installation proccess using knative operator and istio helm charts. For now, current installation proccess is made compliant with MTV Knative Serving installation proccess (which can be found [here](https://luxproject.luxoft.com/stash/projects/DDMTV/repos/mtv_kubernetes_resources/browse/backend/kubernetes/deployment/common/knative/installator))


### Contents

* `installer` contains installation, deletion scripts and corresponding manifests and certificates that are used as a source for creating installer artifact (.tgz archive)
* `ci` contains jenkins pipelines, resources and scripts used to test and update knative installer

### Update process

The knative update process is defined via two jenkinsfiles:

1. `ci/jenkinsfiles/create-update-pr.jenkinsfile` (see [pipeline](https://luxproject.luxoft.com/jenkins/job/MPC/job/Knative/job/knative_create_update_pr)) is responsible for fetching new versions of components, pulling source of these componens and create Pull request with version updates
2. `ci/jenkinsfiles/test-update-pr.jenkinsfile` (see [pipeline](https://luxproject.luxoft.com/jenkins/job/MPC/job/Knative/job/test_and_deploy_knative_artifact/view/change-requests/)) is resposible for performing testing of new versions (in jenkins, it is configured to be a multibranch pipeline that discovers PRs created by pipeline #1 and also triggers on new updates in `develop` branch, from which repository is versioned and artifacts being created and deployed)

Flow diagram of update process can be found in docs directory: `docs/Knative_upgrade_pipeline_flow.png`

### Versioning

Automatic versioning is configured for this repository: see [pipeline](https://luxproject.luxoft.com/jenkins/job/MPC/job/Versioning/job/knative_versioning/)

When new changes in `develop` branch are detected by the pipeline, it runs and triggers [semver pipeline](https://luxproject.luxoft.com/jenkins/job/MPC/job/Versioning/job/semantic_versioning/)
to run. Currently, `develop` branch is only tagged with corresponding version tags (no changelog is kept)

### Usage

To install knative to the cluster:
* Make sure that your environment meets the requirements and have the following utilities installed:
    - bash >= v5.0.0
    - kubectl >= v1.28.4
    - yq v4.x (Required if you choose configuration via config files)
    - jq >= v1.6
    - envsubst >= v0.19.8.1
* Download artifact from [artifactory](https://luxproject.luxoft.com/artifactory/webapp/#/artifacts/browse/tree/General/MPC-generic/knative/serving/installers) and untar it
* Make sure nodes to deploy knative on have proper labels
* Replace certificate and key in `installer/cerfificates` folder with yours or create k8s tls secret under `istio-system` namespace, or use `-m` option in the following step to install certmanager for auto-issuing certificates
* Run `install-knative.sh` under `installer` folder with the following parameters:
    * `-d example.com` - desired domain suffix
    * `-v 1.11` - desired knative version
    * `-a 1.18.2` - desired istio version
    * `-k lxftlmshubacr.azurecr.io` - container registry for knative images (default `gcr.io`)
    * `-i lxftlmshubacr.azurecr.io` - container registry for istio images (default `docker.io`)
    * `-n a:b` - node selector, which affects on which nodes knative and istio will be deployed (default: `knode:kn-node`)
    * `-u <username>` - username for private container registry (if using such registry)
    * `-p <password>` - password for private container registry (if using such registry)
    * `-r` - use rendered helm charts instead of installing istio via helm
    * `-q` - make LoadBalancer public in cloud kubernetes cluster (it is internal by default, currently supporing internal on AKS, EKS, GKE)
    * `-t <k8s-tls-secret-name>` - provide existing tls-secret to use in custom gateway (if not provided, `cert.pem` and `key.pem` under `certificates` directory must 
    be present, containing your certificate and key)
    * `-c` - use config files for configuration (command line options take precedence over config files)
    * `-m` - install certmanager to the cluster for auto-issuing the certificates
* It is possible to configure knative and istio using configuration files (`basic-config.yaml` and `config-serving.yaml`, the former is used to configure basic knative and istio values which are avaliable for configuration from scripts' options (scripts' options take precedence over `basic-config.yaml`) and the latter is used for more precise configuration of Knative Serving, e.g. to use custom tracing endpoint)

#### Configuration files overview

There are two configuration files that can be used to configure knative and istio: `basic-config.yaml`

1. Configuration file `basic-config.yaml`.
This file is used to configure general properties of knative and istio
```yaml
common:
  dns: "example.com" # Specify hostname here
  nodeSelector: # Specify label on nodes on which knative and istio will be deployed
    key: a
    value: b
  certmanager: true # If not set, see options below:
  # tlsSecretName: my-tls-secret # this secret must be in istio-system namespace
  # In nothing is set regarding tls - assuming that we have two files in certificates folder with tls secret

knative:
  registry: gcr.io 
  version: "1.14.1"
istio:
  version: "1.21.1"
  registry: docker.io
  loadBalancerPublic: false # If set to false, load balancer will be annotated to be internal on cloud platforms
  istiod:
    replicas: 1 # This value will be added to Deployment istiod (spec.replicas)
    # minReplicas and maxReplicas will be added to HorisonalPodAutoscaler istiod
    minReplicas: 1
    maxReplicas: 5
  gateway:
    replicas: 1 # This value will be added to Deployment istio-ingressgateway (splec.replicas)
    # minReplicas and maxReplicas will be added to HorisontalPodAutoscaler istio-ingressgateway (spec.minReplicas and spec.maxReplicas)
    minReplicas: 1
    maxReplicas: 5
```
2. Configuration file `config-serving.yaml`.
This file is used for precise configuration of KnativeServing custom resource. 
Contents of this configuration file are `spec` key from KnativeServing CRD. 
Refer to knative-serving documentation to learn how to configure serving via KnativeServing CRD 
```yaml
spec:
  workloads:
  - name: webhook
    replicas: 1
  - name: activator
    replicas: 1
  - name: autoscaler
    replicas: 1
  - name: autoscaler-hpa
    replicas: 1
  - name: controller
    replicas: 1
  podDisruptionBudgets:
  - name: activator-pdb
    minAvailable: 50%
  - name: webhook-pdb
    minAvailable: 50%
  registry:
    imagePullSecrets:
    - name: knative-hub-secret
  config:
    autoscaler:
      minReplicas: "20"
    webhook:
      minReplicas: "20"
    observability:
      logging.enable-request-log: "true"
      logging.request-log-template: '{"TraceID":"{{index .Request.Header "X-B3-Traceid" 0 }}", "RequestId":"{{index .Request.Header "X-Mtv-Requestid" 0 }}"}'
      # used for monitoring solution. Need to parametrize accordingly
      metrics.backend-destination: opencensus
      metrics.opencensus-address: monitoring-opentelemetry-collector.monitoring:55678
      metrics.request-metrics-backend-destination: opencensus
    features:
      kubernetes.podspec-nodeselector: "enabled"
      kubernetes.podspec-tolerations: "enabled"
      kubernetes.podspec-securitycontext: "enabled"
    gc:
      min-non-active-revisions: "0"
      max-non-active-revisions: "0"
      retain-since-create-time: "disabled"
      retain-since-last-active-time: "disabled"
    tracing:
      backend: zipkin
      debug: "false"
      sample-rate: "0.1"
      zipkin-endpoint: http://monitoring-opentelemetry-collector.monitoring.svc.cluster.local:9411/api/v2/spans
```

#### Example:
* Using private registry:
```
./install-knative.sh -k lxftlmshubacr.azurecr.io -i lxftlmshubacr.azurecr.io -u username -p password
```
* Using default public registries of knative and istio:
```
./install-knative.sh
```

#### Deleting
To delete knative its recommended to use `delete-knative.sh` script, which may be found in installer folder

If you installed with `./install-knative.sh -m` (and installer certmanager to the cluster), and want to delete the certmanager, run `./delete-knative.sh -c`

Otherwise run `delete-knative.sh` without providing options




### Usage of custom istio gateway knative-main-gateway instead of configuring default knative-ingress-gateway

KnativeServing CR allows configuring default knative-ingress-gateway, but its CRD is different from istio's gateway CRD in the part that is responsible for configuring the gateway, which, in particular, does not allow configuring `tls` field of istio's gateway (and without this field operator will fail to reconcile knative-ingress-gateway due to istio validation fail). It is a conscious decision of Knative team, not to bring unnecessary dependencies from istio.

Instead, to allow https traffic and get all functionality that istio gateways provide, separate gateway `knative-main-gateway` is used, and configured in CR KnativeServing to be used instead of default `knative-ingress-gateway`

### Some explanation on how knative operator with Knative Serivng work and updated

#### About knative operator versioning and supported Knative Serving versions

Knative operator versions are not exactly the same as Knative Serving versions, they diverge on Patch versions

To use knative serving of version X.Y.0, the operator must be at least of version X.Y.0.

To use newer version of Knative Serving, operator must be of verstion that supports corresponding Knative Serving version.
E.g. in order to use Knative Serving v1.12.0 operator must be at least of version v1.12.0. If you use knative operator of older version, operator will report error (```Reconcile error: version X.Y.Z is not supported```).

Also, operator supports three previous versions of Knative Serving. It means that using the operator v1.11.0 you can change version of Knative Serving to 1.10, 1.9 and 1.8 (Any patch version may be specified). Important note: operator permits upgrades of downgrades by one minor release version at a time. So to upgrade from 1.8 to 1.10, you have to upgrade to 1.9 at first, and then to 1.10

#### Knative operator requirements regarding external internet access:

According to [documentation](https://knative.dev/docs/install/operator/knative-with-operators/#prerequisites:~:text=Your%20Kubernetes%20cluster%20must%20have%20access%20to%20the%20internet%2C%20because%20Kubernetes%20needs%20to%20be%20able%20to%20fetch%20images.%20To%20pull%20from%20a%20private%20registry%2C%20see%20Deploying%20images%20from%20a%20private%20container%20registry.)
the operator only needs to have access to the internet in order to be able to fetch images
from container registries. However, there is an [option to use private container registries](https://knative.dev/docs/serving/deploying-from-private-registry/).
So, the images may be stored in local container registry, and no additional external internet access will be needed.

#### How knative operator manages deployments of Knative Serving:
Knative operator continuously monitors status of deployments of Knative Serving.

Knative Serving deployments are created, when CR KnativeServing is applied, and last until the CR is deleted

Below there are some cases, that show which effect deletion of specific components takes:
1.  Deleting any of deployments of knative-serving (or all at once), including activator, autoscaler, autoscaler-hpa, controller, net-istio-controller, net-istio-webhook, webhook,
    leads to their immediate recreation. All knative serving services (ksvc) are available
2.  Deleting CR KnativeServing leads to deletion of all knative-serving deployments, knative services become unavailable, no recreation.
    Applying CR KnativeServing again (e.g. `kubectl apply -f <KnativeServing CR yaml file>`) leads to creation of all
    knative serving deployments, knative services become available as soon as KnativeServing CR READY status is True
3.  Operator deletion: after deleting knative operator
    ```
    kubectl delete deploy knative-operator
    kubectl delete deploy operator-webhook
    ```
    all knative serving deployments remain, knative services are available. Deployments are no longer monitored (because operator is deleted),
    hense if we delete any of knative-serving deployments it won't be recreated.

#### Upgrading Knative Serving with existing workload
Knative Serving can be upgraded with existing workload. To do so, it is sufficient to apply CR KnativeServing with new version in `spec.version` field.
First, knative-serving deployments are upgraded, then a new revision of each knative service is created, with newer queue proxy image

Upgrading edge case:

Consider a knative service, which is configured with the following annotations:

   ``` 
   autoscaling.knative.dev/initial-scale: "5"
   autoscaling.knative.dev/min-scale: "5"
   autoscaling.knative.dev/max-scale: "5"
   ```

which forces knative to keep exactly 5 replicas of service's pods. Moreover, the resources limits are set in such way, that there is no available cpu resource to deploy new pod of the Knative service.

*Knative Serving deployments will be updated, while knative services will remain not updated, with older queue proxy image, but available*

When we update Knative Serving, the existing replicas, with older queue image version, remain, while newer replicas, with newer queue image, appear in infinite `Pending` state (0/1 nodes are available: 1 Insufficient cpu. preemption: 0/1 nodes are available: 1 No preemption victims found for incoming pod)
- If we have two nodes, one with label `a=b`, other without such label, and the service we deploy has `nodeSelector` that prescribes the pods to be deployed only on the nodes with label a=b, then the same situation would occur (pods will not be deployed on node without the label)
- If we specify affinity using `requiredDuringSchedulingIgnoredDuringExecution`, this will lead to the same situation
- If we specify affinity using `preferredDuringSchedulingIgnoredDuringExecution`, new replicas will be created on different node (assuming that preferred node is out of resources), and after creation replicas won't be rescheduled


### Package delivery process

Package delivery is the last step of upgrade pipeline. After new version of Knative Serving is tested, a .tgz archive, containing this version only (including necessary installation scripts) is created and pushed to 
Artifactory.

For example, if new version of Knative Serving is 1.12.0, Istio - 1.19.3 and they were tested on kubernetes cluster with k8s v1.28.3 - name of the artifact would be `installer-vX.Y.Z-task-autopr-knative-v1-12-0-istio-v1-19-3-k8s-v1-28-3.1.tgz`

Version suffix (`v0.2.0-task-autopr-knative-v1-12-0-istio-v1-19-3-k8s-v1-28-3.1`) is inferred by semantic versioning pipeline

Artifacts are stored under `MPC-generic/knative/serving/installers` path in [artifactory](https://luxproject.luxoft.com/artifactory/MPC-generic/knative/serving/installers)