#! /bin/bash -e

OPERATOR_NAMESPACE='knative-operator'
CERTMANAGER_PATH='certmanager'

usage() {
  echo "USAGE: ${BASH_SOURCE[0]} -d <example.url> -v <knative-version> -a <istio-version> [-n <node-label>:<value>] -i <istio-registry> -k <knative-registry> -u <docker-username> -p <docker-password>"
  echo "PARAMETERS:"
  echo "    -d - (optional) specify DNS suffix for Knative services. Default value: example.com"
  echo "    -v - (optional) specify Knative version."
  echo "    -a - (optional) specify Istio version."
  echo "    -n - (optional) specify label of nodes to deploy Knative on. Default value: knode=kn-node. Format: <key>:<value> (e.g. 'a:b')"
  echo "    -i - (optional) specify Registry for Istio images. Default value: docker.io/isio"
  echo "    -k - (optional) specify Registry for Knative images. Default value: gcr.io"
  echo "    -u - (optional) docker username for specified registries"
  echo "    -p - (optional) docker password for specified registries"
  echo "    -q - (optional) if set, istio gateway will be public on cloud platforms (by default it is internal)"
  echo "                    currently supported cloud platforms: AKS, EKS"
  echo "                    default behaviour: gateway is internal"
  echo "    -r - (optional, flag) use rendered istio helm charts (plain yamls)"
  echo "    -m - (optional, flag) if set, certmanager is used to issue self-signed certificates to use in knative-main-gateway as tls secret"
  echo "    -t - (optional) name of tls secret to use (must be already present). If not provided, certificates from ./certificates folder will be used to create tls-sertificate"
  echo "    -c - (optional) if set, script will look at customizeable configuration files (basic-config.yaml and config-serving.yaml)"
  echo "    -h - Show this message"
  exit 0
}

get_operator_status() {
  kubectl logs deploy/knative-operator -n ${OPERATOR_NAMESPACE} | grep -E '^{' | jq -s add | jq -r 'try (.status.conditions[] | select(.type=="Ready") | .status) catch .'
}

wait_for_certmanager() {
  while ! echo '{"apiVersion": "cert-manager.io/v1", "kind": "ClusterIssuer", "metadata": {"name": "test-certmanager-resource"}, "spec": {"selfSigned": {}}}' | kubectl apply -f - 2>/dev/null; do
    echo "Waiting for certmanager to be ready"
    sleep 10
  done
  kubectl delete ClusterIssuer test-certmanager-resource
  echo "Certmanager installed"
}

substitute() {
  filename=$1

  dns="${dns}" \
  version="${version}" \
  istio_version="${istio_version}" \
  node_selector_key="${node_selector_key}" \
  node_selector_value="${node_selector_value}" \
  istio_registry="${istio_registry}" \
  knative_registry="${knative_registry}" \
  tls_secret_name="${tls_secret_name}" \
  istiod_autoscale_min="${istiod_autoscale_min}" \
  istiod_autoscale_max="${istiod_autoscale_max}" \
  istiod_replica_count="${istiod_replica_count}" \
  gateway_autoscale_min="${gateway_autoscale_min}" \
  gateway_autoscale_max="${gateway_autoscale_max}" \
  gateway_replica_count="${gateway_replica_count}" \
  envsubst '${dns} ${version} ${istio_version} ${node_selector_key} ${node_selector_value} ${istio_registry} ${knative_registry} ${tls_secret_name} ${istiod_autoscale_min} ${istiod_autoscale_max} ${istiod_replica_count} ${gateway_autoscale_min} ${gateway_autoscale_max} ${gateway_replica_count}' <"${filename}" >temp_buffer.yaml
  cat temp_buffer.yaml >"${filename}"
}

dns=''
version=''
istio_version=''
node=''
istio_registry=''
knative_registry=''
docker_username=''
docker_password=''
public_on_cloud=''
tls_secret_name=''
node_selector_key=''
node_selector_value=''
use_certmanager=''
use_config=false

# default values
istiod_autoscale_min='1'
istiod_autoscale_max='5'
istiod_replica_count='1'
gateway_autoscale_min='1'
gateway_autoscale_max='5'
gateway_replica_count='1'

# Read command line options
while getopts ":a:d:v:n:i:k:t:u:p:cqrmh" opt; do
  case "$opt" in
  c)
    use_config=true
    ;;
  m)
    use_certmanager=true
    ;;
  u)
    docker_username="${OPTARG}"
    ;;
  p)
    docker_password="${OPTARG}"
    ;;
  a)
    istio_version="${OPTARG}"
    ;;
  d)
    dns="${OPTARG}"
    ;;
  v)
    version="${OPTARG}"
    ;;
  n)
    node="${OPTARG}"
    ;;
  i)
    istio_registry="${OPTARG}"
    ;;
  k)
    knative_registry="${OPTARG}"
    ;;
  q)
    public_on_cloud=true
    ;;
  t)
    tls_secret_name="${OPTARG}"
    ;;
  h)
    usage
    ;;
  *)
    echo "Invalid option -${opt} !"
    echo "Use -h key to get usage information."
    exit 1
    ;;
  esac
done

# Read values from config file
if [[ ${use_config} = true ]] && [ -f "basic-config.yaml" ]; then
  dns=$([[ "${dns}" = '' ]] && yq '.common.dns // "example.com"' basic-config.yaml || echo "${dns}")
  version=$([[ "${version}" = '' ]] && yq '.knative.version // "1.12.0"' basic-config.yaml || echo "${version}")
  istio_version=$([[ "${istio_version}" = '' ]] && yq '.istio.version // "1.19.3"' basic-config.yaml || echo "${istio_version}")
  node_selector_key=$([[ ${node} = '' ]] && yq '.common.nodeSelector.key // "knode"' basic-config.yaml || echo "${node_selector_key}")
  node_selector_value=$([[ ${node} = '' ]] && yq '.common.nodeSelector.value // "kn-node"' basic-config.yaml || echo "${node_selector_value}")
  node=$([[ "${node}" = '' ]] && echo "${node_selector_key}:${node_selector_value}" || echo "${node}")
  istio_registry=$([[ ${istio_registry} = '' ]] && yq '.istio.registry // "docker.io"' basic-config.yaml || echo "${istio_registry}")
  knative_registry=$([[ ${knative_registry} = '' ]] && yq '.knative.registry // "gcr.io"' basic-config.yaml || echo "${knative_registry}")
  public_on_cloud=$([[ ${public_on_cloud} = '' ]] && yq '.istio.loadBalancerPublic // "false"' basic-config.yaml || echo "${public_on_cloud}")
  tls_secret_name=$([[ ${tls_secret_name} = '' ]] && yq '.common.tlsSecretName // "istio-custom-tls-secret"' basic-config.yaml || echo "${tls_secret_name}")
  use_certmanager=$([[ ${use_certmanager} = '' ]] && yq '.common.certmanager // "false"' basic-config.yaml || echo "${use_certmanager}")
  istiod_autoscale_min=$(yq '.istio.istiod.minReplicas // 1' basic-config.yaml)
  istiod_autoscale_max=$(yq '.istio.istiod.maxReplicas // 5' basic-config.yaml)
  istiod_replica_count=$(yq '.istio.istiod.replicas // 1' basic-config.yaml)
  gateway_autoscale_min=$(yq '.istio.gateway.minReplicas // 1' basic-config.yaml)
  gateway_autoscale_max=$(yq '.istio.gateway.maxReplicas // 5' basic-config.yaml)
  gateway_replica_count=$(yq '.istio.gateway.replicas // 1' basic-config.yaml)
fi

echo "DNS suffix for Knative services: ${dns}"
echo "Knative version to install: ${version}"
echo "Istio version: ${istio_version}"
echo "Node pool to deploy Knative: ${node}"
echo "Registry for Istio images: ${istio_registry}"
echo "Registry for Knative images: ${knative_registry}"

IFS=':' read -a nodearg <<<"${node}"
node_selector_key="${nodearg[0]}"
node_selector_value="${nodearg[1]}"

echo "[1/4]: Installing operator"

kubectl create namespace ${OPERATOR_NAMESPACE} --dry-run=client -o yaml | kubectl apply -f -

if [[ "${knative_registry}" != "" && "${docker_username}" != "" && "${docker_password}" != "" ]]; then
  kubectl create secret docker-registry knative-hub-secret --docker-server=https://${knative_registry} --docker-username=${docker_username} --docker-password=${docker_password} -n ${OPERATOR_NAMESPACE} --dry-run=client -o yaml | kubectl apply -f -
fi

cp ./operator/operator_tmpl.yaml ./operator.yaml
substitute './operator.yaml'

kubectl apply -f ./operator.yaml
sleep 20

echo "[2/4]: Installing Knative Serving"
cp ./operator/config-serving.yaml ./templ.yaml
substitute './templ.yaml'
if [[ "${use_config}" = true ]]; then
  yq -i '. *d (load("config-serving.yaml"))' templ.yaml
fi
kubectl create ns knative-serving --dry-run=client -o yaml | kubectl apply -f -

cat templ.yaml

if [[ "${knative_registry}" != "" && "${docker_username}" != "" && "${docker_password}" != "" ]]; then
  kubectl create secret docker-registry knative-hub-secret --docker-server=https://${knative_registry} --docker-username=${docker_username} --docker-password=${docker_password} -n knative-serving --dry-run=client -o yaml | kubectl apply -f -
fi

kubectl apply -f templ.yaml
sleep 20

echo "[3/4]: Installing Istio"
mkdir -p tmp/istio
cp ./istio/base-all.yaml tmp/istio/base-all.yaml
cp ./istio/istiod-all.yaml tmp/istio/istiod-all.yaml
cp ./istio/gateway-all.yaml tmp/istio/gateway-all.yaml
cp -r ./istio/patches tmp/istio

substitute ./tmp/istio/base-all.yaml
substitute ./tmp/istio/istiod-all.yaml
substitute ./tmp/istio/gateway-all.yaml
substitute ./tmp/istio/patches/patch-gateway-autoscaling-replicas.yaml
substitute ./tmp/istio/patches/patch-gateway-replica-count.yaml

kubectl create ns istio-system --dry-run=client -o yaml | kubectl apply -f -
kubectl apply -f ./tmp/istio/base-all.yaml
kubectl apply -f ./tmp/istio/istiod-all.yaml
sleep 60

# Apply annotations to LoadBalancer
if [[ "${public_on_cloud}" = "true" ]]; then
  patch_path="./patches/patch-lb-public.yaml" envsubst <"./istio/kustomization.yaml" >"./tmp/istio/kustomization.yaml"
else
  patch_path="./patches/patch-lb-internal.yaml" envsubst <"./istio/kustomization.yaml" >"./tmp/istio/kustomization.yaml"
fi
kubectl apply -k ./tmp/istio/

if [[ "${istio_registry}" != "" && "${docker_username}" != "" && "${docker_password}" != "" ]]; then
  kubectl create secret docker-registry istio-hub-secret --docker-server=https://${istio_registry} --docker-username=${docker_username} --docker-password=${docker_password} -n istio-system --dry-run=client -o yaml | kubectl apply -f -
fi

if [[ ${use_certmanager} = "true" ]]; then
  echo "Installing cert-manager"
  kubectl apply -f ${CERTMANAGER_PATH}/certmanager.yaml
  wait_for_certmanager
  cp ${CERTMANAGER_PATH}/selfsigned-certificates.yaml selfsigned-certificates.yaml
  tls_secret_name="selfsigned-tls-secret"
  substitute selfsigned-certificates.yaml
  kubectl apply -f selfsigned-certificates.yaml
elif [[ "${tls_secret_name}" = '' ]]; then
  tls_secret_name="tls-secret"
  kubectl create -n istio-system secret tls ${tls_secret_name} --key=certificates/key.pem --cert=certificates/cert.pem --dry-run=client -o yaml |
    kubectl apply -f -
fi

cp ./istio/istio-gateway.yaml istio-gateway.yaml
substitute "istio-gateway.yaml"
kubectl apply -f istio-gateway.yaml
sleep 30

echo "[4/4]: Waiting for installation to complete..."
ok=$(get_operator_status)
retries=30
while [[ "${ok}" != "True" ]]; do
  sleep 10
  if [[ $(expr ${retries} % 5) -eq 0 ]]; then
    kubectl get deploy -n ${OPERATOR_NAMESPACE}
    kubectl get deploy -n knative-serving
    kubectl get deploy -n istio-system
  fi
  ok=$(get_operator_status)
  echo "Still waiting..."
  retries=$((retries - 1))
  if [[ "${retries}" -lt "0" ]]; then
    echo "Installation failed"
    exit 1
  fi
done

echo "Installation finished successfully"
lb_external_ip=$(kubectl get svc -n istio-system istio-ingressgateway -o=jsonpath="{.status.loadBalancer.ingress[0].ip}")
echo "External LoadBalancer ip: ${lb_external_ip}"
