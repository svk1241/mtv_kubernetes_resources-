#!/bin/bash -e

CERTMANAGER_PATH='certmanager'

help() {
  echo "USAGE: ${BASH_SOURCE[0]}"
  echo "PARAMETERS:"
  echo "  -c - if set, delete certmanager too"
}

keep_certmanager=true

while getopts ':c' o; do
  case "${o}" in
    c)
      keep_certmanager=false
      ;;
    h)
      help
      exit 0
      ;;
    *)
      echo "Unknown option ${o}"
      help
      exit 1
      ;;
  esac
done


# Deleting certmanager
if [[ $(kubectl get ns cert-manager --ignore-not-found=true) != "" ]] && [[ ${keep_certmanager} = false ]]; then
  kubectl delete -f selfsigned-certificates.yaml
  kubectl delete --ignore-not-found=true -f ${CERTMANAGER_PATH}/certmanager.yaml
fi

# Delete knative services, if needed
echo "Deleting existing knative workloads (knative services)..."
kubectl get ksvc --all-namespaces --ignore-not-found=true | tail -n +2 | awk '{print "-n " $1 " " $2}' | xargs -r kubectl delete ksvc

# Delete serving's crds
kubectl get crd | awk '{print $1}' | grep serving.knative | xargs -r kubectl delete crd
kubectl get crd | awk '{print $1}' | grep internal.knative | xargs -r kubectl delete crd

# Delete KnativeServing CR
echo "Deleting KnativeServing CR..."
kubectl delete KnativeServing knative-serving -n knative-serving --ignore-not-found=true

# Wait until KnativeServing CR is deleted
while [[ ! $(kubectl get KnativeServing knative-serving -n knative-serving --ignore-not-found=true | wc -l) = 0 ]]; do
  sleep 10
  echo "Still deleting..."
done
echo "Done"

# Delete istio
echo "Deleting istio"
kubectl delete -f tmp/istio/gateway-all.yaml
kubectl delete -f tmp/istio/istiod-all.yaml
kubectl delete -f tmp/istio/base-all.yaml
rm -rf tmp
kubectl delete ns istio-system
echo "Done"
# Delete operator
echo "Deleting operator..."
kubectl delete -f operator.yaml
echo "Done"

echo "Deleting namespaces..."
kubectl delete namespace --ignore-not-found=true knative-serving knative-operator
echo "Done"

echo "Deleted successfully"
