# Knative and istio helm charts
This doc describes structure of knative and istio component and installation options

## Structure

This directory contains neccessary components of knative and istio deliverable solution

These components are:
1. `istio-base` - istio/base chart
2. `istio-gateway` - istio/gateway chart
3. `istiod` - istio/istiod chart
2. `knative-operator` - chart that provides knative operator.
3. `knative-serving` - chart that provides customizable KnativeServing custom resource manifest along with custom istio's `Gateway` resource named `knative-main-gateway` to allow HTTPS ingress traffic.

Depending on installation way you choose (see further sections), those charts can be configured
1. With `helmfile-values.yaml` file in `values` directory (see Installation with helmfile)
2. With individual values file for each chart in `values` directory (e.g. `istio-base-values.yaml` etc.)

File `release-values.gotmpl` is helper file, do not remove or edit it.

## Usage

This section describes supported means for installing knative and istio component into a kubernetes cluster.

As common prerequisite for each installation option you must create corresponding namespaces for each chart with 
1. kubernetes docker secret, containing credentials for accessing private registry (if you use private registry to store knative and istio images) and/or
2. kubernetes secret with SSL certificates (if you decide to enable HTTPS).

### Installation with helm
<!-- TODO: Provide better overview of configuring for this install option -->
Prerequisites:
1. `helm` of version >= 3.15 

Installation with helm is straight forward, you need:
1. Edit per-chart values files under `values` directory (these are `istiod-values.yaml`, `gateway-values.yaml`, `istio-base-values.yaml`, `knative-operator-values.yaml` and `knative-serving-values.yaml`). Make sure to replace all placeholders (e.g. `<secret-name>` with your values)
2. Then perform 5 subsequent `helm install` (supposing that these commands are performed under directory `charts/knative-istio`):
  * `helm install --wait --namespace istio-system istio-base ./istio-base --values values/istio-base-values.yaml`
  * `helm install --wait --namespace istio-system istiod ./istiod --values values/istiod-values.yaml`
  * `helm install --wait --namespace istio-system istio-ingressgateway ./istio-gateway --values values/gateway-values.yaml`
  * `helm install --wait --namespace knative-operator knative-operator ./knative-operator --values values/knative-operator-values.yaml`
  * `helm install --wait --namespace knative-serving knative-serving ./knative-serving --values values/knative-serving-values.yaml`

### Installation with helmfile

To install chart with helmfile, some prerequisites must be met
1. `helmfile` of version >= 0.168.0 must be installed (see https://github.com/helmfile/helmfile?tab=readme-ov-file#installation)
2. `helm` of version >= v3.15.3
3. `diff` plugin for helm of version >= 3.9.10



By default, istio is installed in `istio-system` namespace, knative operator is installed in `knative-operator` namespace, and knative-serving is installed in `knative-serving` namespace.

When installing with helmfile, you need to manualy edit `values/helmfile-values.yaml` with configuration you need. Make sure to at least replace placeholders with values you need

Below is the structure of mentioned `values.yaml`:
```yaml
istiod:
  global:
    configValidation: true
    istioNamespace: istio-system
    imagePullSecrets:
      - <secret-name>
    proxy_init:
      image: <istio-registry>/istio/proxyv2:<istio-version>
    proxy:
      image: <istio-registry>/istio/proxyv2:<istio-version>
  pilot:
    image: <istio-registry>/istio/pilot:<istio-version>
    nodeSelector:
      <key>: <value>

istio-base:
  global:
    istioNamespace: istio-system

gateway:
  name: istio-ingressgateway
  nodeSelector:
    <key>: <value>
  autoscaling:
    minReplicas: 2
  service:
    annotations:
      service.beta.kubernetes.io/azure-load-balancer-internal: "true" # azure


knative-operator:
  nodeSelector:
    <key>: <value>
  dockerRegistrySecret: acrsecret
  knativeOperator:
    image: <knative-registry>/knative-releases/knative.dev/operator/cmd/operator
    tag: <operator-version>
  operatorWebhook:
    image: <knative-registry>/knative-releases/knative.dev/operator/cmd/webhook
    tag: <operator-version>

knative-serving:
  spec:
    version: "1.14.0"
    registry:
      override:
        activator: <knative-registry>/knative-releases/knative.dev/serving/cmd/activator:<knative-version>
        autoscaler: <knative-registry>/knative-releases/knative.dev/serving/cmd/autoscaler:<knative-version>
        controller: <knative-registry>/knative-releases/knative.dev/serving/cmd/controller:1<knative-version>
        net-istio-controller/controller: <knative-registry>/knative-releases/knative.dev/net-istio/cmd/controller:<knative-version>
        net-istio-webhook/webhook: <knative-registry>/knative-releases/knative.dev/net-istio/cmd/webhook:<knative-version>
        webhook: <knative-registry>/knative-releases/knative.dev/serving/cmd/webhook:<knative-version>
        queue-proxy: <knative-registry>/knative-releases/knative.dev/serving/cmd/queue:<knative-version>
      imagePullSecrets:
      - name: <secret-name>
    ingress:
      istio:
        enabled: true
        knative-ingress-gateway:
          selector:
            istio: ingressgateway
          servers:
          - port:
              number: 80
              name: http
              protocol: HTTP
            hosts:
            - '*'
          - port:
              number: 443
              name: https
              protocol: HTTPS
            hosts:
            - '*'
            tls:
              mode: SIMPLE
              credentialName: <tls-secret-name>
    podDisruptionBudgets:
    - name: activator-pdb
      minAvailable: 50%
    - name: webhook-pdb
      minAvailable: 50%
    workloads:
    - name: webhook
      nodeSelector:
        <key>: <value>
      replicas: <replicas>
    - name: activator
      nodeSelector:
        <key>: <value>
      replicas: <replicas>
    - name: autoscaler
      nodeSelector:
        <key>: <value>
      replicas: <replicas>
    - name: controller
      nodeSelector:
        <key>: <value>
      replicas: <replicas>
    - name: autoscaler-hpa
      replicas: 0
    config:
      features: 
        kubernetes.podspec-nodeselector: "enabled"
        kubernetes.podspec-tolerations: "enabled"
        kubernetes.podspec-securitycontext: "enabled"
        kubernetes.podspec-persistent-volume-claim: "enabled"
        kubernetes.podspec-persistent-volume-write: "enabled"
      gc:
        min-non-active-revisions: "0"
        max-non-active-revisions: "0"
        retain-since-create-time: "disabled"
        retain-since-last-active-time: "disabled"
      domain: 
        <domain>: ""
```

Helmfile configuration is defined in `helmfile.yaml` file. You do not need to edit it, except for case when you want to change namespaces in which charts are installed. To alter namespaces, you will need to change `releases.[i].namespace` key in `helmfile.yaml` (see example below):
```yaml
---
releases:
  - name: istio-umbrella # This is the name of release you want to change namespace for
    chart: ./istio-umbrella
    values: 
    - &all-values release-values.gotmpl
    createNamespace: true
    namespace: istio-system # <-- change this
    wait: true
    cleanupOnFail: true
    waitForJobs: true

```

Altering namespaces requires some additional changes to `values.yaml`:
1. If you change `istio-umbrella`'s namespace - you will need to change:
    1. `istio-umbrella.istiod.global.istioNamespace` to new namespace
    2. `istio-umbrella.istio-base.global.istioNamespace` to new namespace
    3. Change service reference for knative serving: 
  
  change 
  ```yaml
    gateway.knative-serving.knative-main-gateway: "istio-ingressgateway.istio-system.svc.cluster.local"
  ``` 
  to 
  ```yaml
    gateway.knative-serving.knative-main-gateway: "istio-ingressgateway.<new-istio-namespace>.svc.cluster.local"
  ```
  and 
  ```yaml
  local-gateway.knative-serving.knative-local-gateway: "knative-local-gateway.istio-system.svc.cluster.local"
  ```
  to 
  ```yaml
  local-gateway.knative-serving.knative-local-gateway: "knative-local-gateway.<new-istio-namespace>.svc.cluster.local"
  ```
2. If you change namespace of `knative-serving`, you need to change:
  ```yaml
  gateway.knative-serving.knative-main-gateway: "istio-ingressgateway.istio-system.svc.cluster.local"
  ``` 
  to 
  ```yaml
  gateway.<new-knative-namespace>.knative-main-gateway: "istio-ingressgateway.istio-system.svc.cluster.local"
  ```
  and change 
  ```yaml
  gateway.knative-serving.knative-local-gateway: "istio-ingressgateway.istio-system.svc.cluster.local"
  ```
  to
  ```yaml
  gateway.<new-knative-namespace>.knative-local-gateway: "istio-ingressgateway.istio-system.svc.cluster.local"
  ```
