#!/bin/bash -e

STEPS_COUNT=3

HELMFILE=false

help() {
    echo "USAGE: ${BASH_SOURCE[0]} [--helmfile] [-h]"
    echo "OPTIONS:"
    echo "  1. --helmfile (optional) - flag, if set - helmfile is used to uninstall knative. Use if you installed with helmfile (Default: false)"
    echo "  2. -h (optional) - flag, if set - print this message and exit"
}

uninstall_with_helmfile() {
    # First, delete KnativeServing resource to avoid issue with simultaneous deletion of CR and operator
    kubectl delete KnativeServing -n knative-serving knative-serving
    # Then delete via helmfile
    helmfile destroy --args=--wait
}

uninstall_with_helm() {
    # Uninstall each chart
    helm uninstall --wait --namespace knative-serving knative-serving
    helm uninstall --wait --namespace knative-operator knative-operator
    helm uninstall --wait --namespace istio-system istio-ingressgateway
    helm uninstall --wait --namespace istio-system istiod
    helm uninstall --wait --namespace istio-system istio-base
}

while [[ "$#" -gt 0 ]]; do
    case $1 in
        --helmfile) HELMFILE=true ;;
        -h) help; exit 0; shift ;; # Not required
        *) echo "Unknown parameter: $1"; help; exit 1 ;;
    esac
    shift
done

echo 'Beginning uninstallation of Knative'
echo "[1/${STEPS_COUNT}] Uninstall all knative services"

kubectl get ksvc --all-namespaces --no-headers | while read -r svc; do
    ns=$(echo $svc | awk '{print $1}')
    svc_name=$(echo $svc | awk '{print $2}')
    delete_svc="kubectl delete --wait ksvc $svc_name -n $ns"
    eval $delete_svc
done

sleep 10

kubectl get vs --all-namespaces --no-headers | while read -r vs; do
    vs_ns=$(echo $vs | awk '{print $1}')
    vs_name=$(echo $vs | awk '{print $2}')
    delete_vs="kubectl delete vs $vs_name -n $vs_ns"
    eval eval "${delete_vs}"
done

while [ "$(kubectl get ksvc --all-namespaces | wc -l)" != 0 ]; do
    echo "Waiting for ksvc resources removal"
    sleep 5
done

while [ "$(kubectl get vs --all-namespaces | wc -l)" != 0 ]; do
    echo "Waiting for vs resources removal"
    sleep 5
done

while [ "$(kubectl get kingress --all-namespaces | wc -l)" != 0 ]; do
    echo "Waiting for kingress resources removal"
    sleep 5
done

while [ "$(kubectl get rt --all-namespaces | wc -l)" != 0 ]; do
    echo "Waiting for rt resources removal"
    sleep 5
done

echo 'All knative services were deleted'

if [[ "${HELMFILE}" == "true" ]]; then
    echo "[2/${STEPS_COUNT}] Uninstall with helmfile"
    uninstall_with_helmfile
else
    echo "[2/${STEPS_COUNT}] Uninstall with helm"
    uninstall_with_helm
fi

echo 'Uninstalled all except CRDs'

echo "[3/${STEPS_COUNT}] Delete CRDs"

kubectl get crd --no-headers | grep -E '(istio\.io|knative\.dev)'| while read -r crd; do 
    crd_name=$(echo "${crd}" | awk '{ print $1 }')
    delete_cmd="kubectl delete crd ${crd_name}"
    eval "${delete_cmd}"
done

echo 'All knative and istio CRDs deleted'
echo 'Successfully deleted Knative Serving and Istio'
