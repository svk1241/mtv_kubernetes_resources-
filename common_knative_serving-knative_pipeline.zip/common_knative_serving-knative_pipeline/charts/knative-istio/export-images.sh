#!/bin/bash

usage () {
    echo "USAGE: ${BASH_SOURCE[0]} -r <registry name> -u <username> -p <password> -k <knative version> -i <istio version> -f"
    echo
    echo "    -r - (required) name of destination ACR. Example: ddcregistry."
    echo "    -u - (optional) username to provide for images export. The username for DXC Luxoft public ACR is expected."
    echo "    -p - (optional) password to provide for images export. The password for DXC Luxoft public ACR is expected."
    echo "    -k - (optional) knative serving version to pull. Default: 1.14.0."
    echo "    -o - (optional) knative operator version to pull. Default: 1.15.2."
    echo "    -i - (optional) istio version to pull. Default: 1.21.1."
    echo "    -f - (optional) force import (overwriting the image if exits)."
    exit 0
}

SOURCE_ACR="acreastuspublic001.azurecr.io"
KNATIVE_VERSION="1.14.0"
ISTIO_VERSION="1.21.1"
KNATIVE_OPERATOR_VERSION="1.15.2"

while getopts ":r:u:p:o:k:i:fh" opt; do
  case $opt in
    r) DESTINATION_ACR="$OPTARG"
    ;;
    u) USERNAME="--username $OPTARG"
    ;;
    p) PASSWORD="--password $OPTARG"
    ;;
    k) KNATIVE_VERSION="$OPTARG"
    ;;
    i) ISTIO_VERSION="$OPTARG"
    ;;
    o) KNATIVE_OPERATOR_VERSION="$OPTARG"
    ;;
    f) FORCE="--force"
       echo "[INFO] Force mode is used."
    ;;
    h) usage
    ;;    
    *) echo "Invalid option -$OPTARG !"
       echo "Use -h key to get usage information."
       exit 1
    ;;
  esac
done

AUTH_OPTS="${USERNAME} ${PASSWORD}"


# Import Istio images
echo "[1/3] Importing Istio images . . ."
az acr import --name ${DESTINATION_ACR} --source ${SOURCE_ACR}/istio/pilot:${ISTIO_VERSION} --image istio/pilot:${ISTIO_VERSION} ${AUTH_OPTS} ${FORCE}
az acr import --name ${DESTINATION_ACR} --source ${SOURCE_ACR}/istio/proxyv2:${ISTIO_VERSION} --image istio/proxyv2:${ISTIO_VERSION} ${AUTH_OPTS} ${FORCE}
echo "Successful!"

# Import Knative images
echo "[2/3] Importing Knative images . . ."
az acr import --name ${DESTINATION_ACR} --source ${SOURCE_ACR}/knative-releases/knative.dev/serving/cmd/activator:${KNATIVE_VERSION} --image knative-releases/knative.dev/serving/cmd/activator:${KNATIVE_VERSION} ${AUTH_OPTS} ${FORCE}
az acr import --name ${DESTINATION_ACR} --source ${SOURCE_ACR}/knative-releases/knative.dev/serving/cmd/autoscaler:${KNATIVE_VERSION} --image knative-releases/knative.dev/serving/cmd/autoscaler:${KNATIVE_VERSION} ${AUTH_OPTS} ${FORCE}
az acr import --name ${DESTINATION_ACR} --source ${SOURCE_ACR}/knative-releases/knative.dev/serving/cmd/controller:${KNATIVE_VERSION} --image knative-releases/knative.dev/serving/cmd/controller:${KNATIVE_VERSION} ${AUTH_OPTS} ${FORCE}
az acr import --name ${DESTINATION_ACR} --source ${SOURCE_ACR}/knative-releases/knative.dev/serving/cmd/webhook:${KNATIVE_VERSION} --image knative-releases/knative.dev/serving/cmd/webhook:${KNATIVE_VERSION} ${AUTH_OPTS} ${FORCE}
az acr import --name ${DESTINATION_ACR} --source ${SOURCE_ACR}/knative-releases/knative.dev/serving/cmd/queue:${KNATIVE_VERSION} --image knative-releases/knative.dev/serving/cmd/queue:${KNATIVE_VERSION} ${AUTH_OPTS} ${FORCE}
az acr import --name ${DESTINATION_ACR} --source ${SOURCE_ACR}/knative-releases/knative.dev/operator/cmd/operator:${KNATIVE_OPERATOR_VERSION} --image knative-releases/knative.dev/operator/cmd/operator:${KNATIVE_OPERATOR_VERSION} ${AUTH_OPTS} ${FORCE}
az acr import --name ${DESTINATION_ACR} --source ${SOURCE_ACR}/knative-releases/knative.dev/operator/cmd/webhook:${KNATIVE_OPERATOR_VERSION} --image knative-releases/knative.dev/operator/cmd/webhook:${KNATIVE_OPERATOR_VERSION} ${AUTH_OPTS} ${FORCE}
echo "Successful!"

# Import net-istio images
echo "[3/3] Importing Net-istio images . . ."
az acr import --name ${DESTINATION_ACR} --source ${SOURCE_ACR}/knative-releases/knative.dev/net-istio/cmd/controller:${KNATIVE_VERSION} --image knative-releases/knative.dev/net-istio/cmd/controller:${KNATIVE_VERSION} ${AUTH_OPTS} ${FORCE}
az acr import --name ${DESTINATION_ACR} --source ${SOURCE_ACR}/knative-releases/knative.dev/net-istio/cmd/webhook:${KNATIVE_VERSION} --image knative-releases/knative.dev/net-istio/cmd/webhook:${KNATIVE_VERSION} ${AUTH_OPTS} ${FORCE}
echo "Successful!"

echo "Images importing finished"