## Knative Serving installation package 

### Version info:
* Knative Serving: 1.11.0
* Istio: 1.18.2

### Summary

This package contains installation scripts and necessary files for installing Knative Serving and Istio on a kubernetes cluster

### Requirements

Installation and deletion scripts depend on some utilities, which are required to execure the scripts:
- bash >= v5.0.0
- kubectl >= v1.28.4
- yq v4.x (Required if you choose configuration via config files)
- jq >= v1.6
- envsubst >= v0.19.8.1

### Usage:
1. Install Knative:

    Use `./install-knative.sh` to install knative to the cluster

    To apply configuration declared in config files `basic-config.yaml` and `config-serving.yaml` use `./install-knative.sh -c`.
    See configuration files structures overview in section **Configuration files**
    
    Before installing, make sure that all nodes, on which you want to deploy Knative Serving have common label (of your choice)

    You have three options to provide tls-secrets: 
        * Add your key.pem and cert.pem files under `certificates` directory - this will lead to creation of secret `tls-secret` during installation
        * Create k8s tls secret under `istio-system` namespace in advance (you would likely need to create the namespace first)
        * Install certmanager to the cluster (use `-m` option)

    Example:

   ```
   ./install-knative.sh -n a:b
   ```
   This command will install knative on the cluster, Knative Serving deployments will schedule pods on nodes with label `a:b`
   Default value of `-n` parameter is `knode:kn-node`
   Use `./install-knative.sh -h` to see reference on available parameters

   ```
   ./install-knative.sh -m
   ```
   This command will install certmanager and create selfsigned auto-updating tls credentials in `istio-system` namespace
2. Delete Knative:

    Use `./delete-knative.sh` to delete knative installation

    If you also want to delete cert-manager that you installed with `./install-knative.sh -m` - use `./delete-knative.sh -c`

### Configuration files

There are two configuration files that can be used to configure knative and istio: `basic-config.yaml`

1. Configuration file `basic-config.yaml`.
This file is used to configure general properties of knative and istio
```yaml
common:
  dns: "example.com" # Specify hostname here
  nodeSelector: # Specify label on nodes on which knative and istio will be deployed
    key: a
    value: b
  certmanager: true # If not set, see options below:
  # tlsSecretName: my-tls-secret # this secret must be in istio-system namespace
  # In nothing is set regarding tls - assuming that we have two files in certificates folder with tls secret

knative:
  registry: gcr.io 
  version: "1.14.1"
istio:
  version: "1.21.1"
  registry: docker.io
  loadBalancerPublic: false # If set to false, load balancer will be annotated to be internal on cloud platforms
  istiod:
    replicas: 1 # This value will be added to Deployment istiod (spec.replicas)
    # minReplicas and maxReplicas will be added to HorisonalPodAutoscaler istiod
    minReplicas: 1
    maxReplicas: 5
  gateway:
    replicas: 1 # This value will be added to Deployment istio-ingressgateway (splec.replicas)
    # minReplicas and maxReplicas will be added to HorisontalPodAutoscaler istio-ingressgateway (spec.minReplicas and spec.maxReplicas)
    minReplicas: 1
    maxReplicas: 5
```
2. Configuration file `config-serving.yaml`.
This file is used for precise configuration of KnativeServing custom resource. 
Contents of this configuration file are `spec` key from KnativeServing CRD. 
Refer to knative-serving documentation to learn how to configure serving via KnativeServing CRD 
```yaml
spec:
  workloads:
  - name: webhook
    replicas: 1
  - name: activator
    replicas: 1
  - name: autoscaler
    replicas: 1
  - name: autoscaler-hpa
    replicas: 1
  - name: controller
    replicas: 1
  podDisruptionBudgets:
  - name: activator-pdb
    minAvailable: 50%
  - name: webhook-pdb
    minAvailable: 50%
  registry:
    imagePullSecrets:
    - name: knative-hub-secret
  config:
    autoscaler:
      minReplicas: "20"
    webhook:
      minReplicas: "20"
    observability:
      logging.enable-request-log: "true"
      logging.request-log-template: '{"TraceID":"{{index .Request.Header "X-B3-Traceid" 0 }}", "RequestId":"{{index .Request.Header "X-Mtv-Requestid" 0 }}"}'
      # used for monitoring solution. Need to parametrize accordingly
      metrics.backend-destination: opencensus
      metrics.opencensus-address: monitoring-opentelemetry-collector.monitoring:55678
      metrics.request-metrics-backend-destination: opencensus
    features:
      kubernetes.podspec-nodeselector: "enabled"
      kubernetes.podspec-tolerations: "enabled"
      kubernetes.podspec-securitycontext: "enabled"
    gc:
      min-non-active-revisions: "0"
      max-non-active-revisions: "0"
      retain-since-create-time: "disabled"
      retain-since-last-active-time: "disabled"
    tracing:
      backend: zipkin
      debug: "false"
      sample-rate: "0.1"
      zipkin-endpoint: http://monitoring-opentelemetry-collector.monitoring.svc.cluster.local:9411/api/v2/spans
```