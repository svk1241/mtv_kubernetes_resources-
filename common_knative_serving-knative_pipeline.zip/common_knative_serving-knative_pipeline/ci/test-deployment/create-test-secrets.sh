#!/bin/bash -e

# This script is used in ci proccess to create neccessary secrets for test workload

namespaces=("knative-operator" "knative-serving" "istio-system" "test")

for namespace in "${namespaces[@]}"; do
    kubectl create ns ${namespace} --dry-run=client -o yaml | kubectl apply -f -
    kubectl create secret docker-registry acrsecret \
    --docker-server=https://lxftlmshubacr.azurecr.io \
    --docker-username=${ARM_CLIENT_ID} \
    --docker-password=${ARM_CLIENT_SECRET} \
    -n ${namespace} --dry-run=client -o yaml | kubectl apply -f -
done

