resource "azurerm_kubernetes_cluster" "aks" {
  name                = "testing-aks"
  location            = azurerm_resource_group.rg.location
  resource_group_name = azurerm_resource_group.rg.name
  dns_prefix          = "knative-testing"
  sku_tier            = "Free"
  kubernetes_version  = var.kube_version

  default_node_pool {
    name       = "default"
    node_count = 1
    vm_size    = "Standard_A4_v2"
    max_pods   = 50
    orchestrator_version = var.kube_version
    os_sku     = "Ubuntu"
  }

  identity {
    type = "SystemAssigned"
  }
}

output "client_certificate" {
  value     = azurerm_kubernetes_cluster.aks.kube_config.0.client_certificate
  sensitive = true
}

output "kube_config" {
  value     = azurerm_kubernetes_cluster.aks.kube_config_raw
  sensitive = true
}

variable "kube_version" {
  type        = string
  default     = "1.27"
  description = "Kubernetes version for aks"
}

