resource "azurerm_resource_group" "rg" {
  name     = "rg-knative-upgrade"
  location = "eastus"
}
