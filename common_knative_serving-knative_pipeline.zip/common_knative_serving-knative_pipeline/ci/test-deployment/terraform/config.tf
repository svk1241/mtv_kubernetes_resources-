terraform {
  required_version = ">= 1.4.0"

  backend "azurerm" {
    resource_group_name  = "rg-hub-service"
    storage_account_name = "modpresalecommon"
    container_name       = "tfstate"
    key                  = "terraform-knative-upgrade.tfstate"
  }

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.90.0"
    }
  }
}

provider "azurerm" {
  subscription_id = "8e34da7d-09ba-4ef4-bd3c-8ca2d7b7b0f9"
  features {}
}
