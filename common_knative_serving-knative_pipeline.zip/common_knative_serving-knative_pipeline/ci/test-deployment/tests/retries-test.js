import http from 'k6/http';
import { check, sleep } from 'k6';
import { textSummary } from 'https://jslib.k6.io/k6-summary/0.0.2/index.js';
import { jUnit, jMeter } from './xml.js'

export const options = {
    stages: [
        { duration: '30s', target: 10 },
    ],
    thresholds: {
        http_req_failed: ['rate==0'],
        http_req_duration: ['avg<300']
    }
};

export default function () {
    const params = {
        headers: {
            'Host': 'example.com'
        }
    };

    const res = http.get(`http://${__ENV.ADDRESS}/health-risk`, params);
    check(res, {
        'All responses are status 200': (r) => r.status === 200,
    });

    sleep(1);
}

export function handleSummary(data) {
    return {
        'stdout': textSummary(data, {indent: '    ', enableColors: true}),
        'retries_summary_colored.out': textSummary(data, {indent: '    ', enableColors: true}),
        'retries_summary.out': textSummary(data, {indent: '    ', enableColors: false}),
        'retries_junit.xml': jUnit(data),
        'retries_out.jtl': jMeter(data),
        'retries_summary.json': JSON.stringify(data)
    }
}