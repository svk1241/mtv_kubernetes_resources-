import http from 'k6/http';
import { check, sleep } from 'k6';
import { Trend } from 'k6/metrics';
import { textSummary } from 'https://jslib.k6.io/k6-summary/0.0.2/index.js';
import { jUnit, jMeter } from './xml.js';

export const options = {
    stages: [
        {duration: '2s', target: 2},
//        {duration: '10s', target: 100},
    ],
    thresholds: {
        http_req_failed: ['rate==0'],
        http_req_duration: ['p(95)<400'],
        http_req_waiting: ['avg<200']
    }
};

export default function() {
    const responses = http.batch([
        ['GET', 'https://test.k6.io']
    ]);
    check(responses[0], { 'status was 200': (r) => r.status == 200 });
    sleep(1);
}

export function handleSummary(data) {
    return {
        'junit.xml': jUnit(data),
        'stdout': textSummary(data, { indent: '', enableColors: false }),
        'out.jtl': jMeter(data),
    }
}