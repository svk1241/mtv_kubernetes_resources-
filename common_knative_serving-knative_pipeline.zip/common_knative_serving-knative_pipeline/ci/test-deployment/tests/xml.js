var forEach = function (obj, callback) {
    for (var key in obj) {
        if (obj.hasOwnProperty(key)) {
            if (callback(key, obj[key])) {
                break
            }
        }
    }
}

var testSuitePrefix = __ENV.TEST_CASE_PREFIX ? __ENV.TEST_CASE_PREFIX : 'Testsuite'

var replacements = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    "'": '&#39;',
    '"': '&quot;',
}

function escapeHTML(str) {
    // TODO: something more robust?
    return str.replace(/[&<>'"]/g, function (char) {
        return replacements[char]
    })
}

function expandParametes(parameters) {
    if (!parameters) return ""
    let res = ""
    Object.keys(parameters).forEach(key => {
        res += `${key}="${parameters[key]}" `
    })
    return res
}

function xmlElement(name, parameters, content) {
    if (!content) {
        return `<${name} ${expandParametes(parameters)}/>`
    } else {
        return `<${name} ${expandParametes(parameters)}> ${content} </${name}>`
    }
}

function generateProperties(properties) {
    return properties.map(x => xmlElement("property", {name: x.name}, x.value)).join("")
}

function generateChecksReport(checks) {
    return testsuite(
        { name: 'checks' },
        multiple(checks.map(
            x => x.fails === 0 ? testcase({ name: testSuitePrefix + ': ' + x.name }, `passes: ${x.passes}\nfails:${x.fails}`) :
                testcase({ name: testSuitePrefix + ': ' + x.name }, failure({ message: 'check failed' }, `passes: ${x.passes}\nfails: ${x.fails}`))
        ))
    )
}

function generateJUnitXML(data, options) {
    var failures = 0
    var thresholdCases = []

    const checksReport = generateChecksReport(data.root_group.checks)
    forEach(data.metrics, function (metricName, metric) {
        if (!metric.thresholds) {
            return
        }
        forEach(metric.thresholds, function (thresholdName, threshold) {
            let values = Object.keys(metric.values).map((x) => ({ name: x, value: metric.values[x] }))

            if (threshold.ok) {
                thresholdCases.push(
                    xmlElement('testcase',
                        { name: testSuitePrefix + ': ' + escapeHTML(metricName) + ' - ' + escapeHTML(thresholdName) },
                        xmlElement("properties", null,
                            generateProperties(values)
                        ))
                )
            } else {
                failures++
                thresholdCases.push(
                    xmlElement('testcase', { name: testSuitePrefix + ': ' + escapeHTML(metricName) + ' - ' + escapeHTML(thresholdName) }, xmlElement(
                        'failure',
                        { message: `Threshold on ${escapeHTML(metricName)} (${escapeHTML(thresholdName)}) was crossed` },
                        generateProperties(values)
                    ))
                )
            }
        })
    })

    var name = options && options.name ? escapeHTML(options.name) : 'k6 thresholds'

    return xml(
        testsuites(
            { tests: thresholdCases.length + data.root_group.checks.length, failures: failures },
            multiple([
                testsuite({ name: 'thresholds', tests: thresholdCases.length, failures: failures }, multiple(thresholdCases)),
                checksReport,
            ])
        )
    )
}

function generateJMeterXML(data) {
    const thresholds = Object.entries(data.metrics).filter(x => x[1].thresholds && Object.values(x[1].thresholds).length > 0 && x[1].values.avg).map(
        x => multiple(Object.entries(x[1].thresholds).map(
            y => xmlElement('httpSample', { t: parseInt(x[1].values.avg, 10), lb: escapeHTML(y[0]), ts: 0, lt: 0, s: y[1].ok })
        ))
    )
    let avgTimeInMs = parseInt(data.metrics.http_req_duration.values.avg, 10)
    let medTimeInMs = parseInt(data.metrics.http_req_duration.values.med, 10)
    return xml(
        xmlElement('testResults', { version: "1.2" },
            multiple([
                thresholds
            ]).replace(",", "")
        )
    )

}

function xml(body) {
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + body
}

function testsuites(params, body) {
    return xmlElement('testsuites', params, body)
}

function testsuite(params, body) {
    return xmlElement('testsuite', params, body)
}

function testcase(params, body) {
    return xmlElement('testcase', params, body)
}

function failure(params, body) {
    return xmlElement('failure', params, body)
}

function multiple(elements) {
    return elements.join("\n")
}

function requestRecorder() {
    function record(requests, request) {
        requests.push(request)
        console.log(requests.length)
    }
    function toXml(requests) {
        return xml(
            xmlElement('report', null, multiple(requests.map(
                x => xmlElement('httpSample', {
                    t: parseInt(x.timings.duration, 10),
                    lt: parseInt(x.timings.connecting, 10),
                    ts: x.headers.date,
                    s: x.error_code === 0 ? "true" : "false",
                    lb: x.url,
                    rc: x.status,
                    rm: x.status_text
                }, null)
            )))
        )
    }
    return [record, toXml]
}

export const jUnit = generateJUnitXML
export const jMeter = generateJMeterXML
export const jMeterRecorder = requestRecorder