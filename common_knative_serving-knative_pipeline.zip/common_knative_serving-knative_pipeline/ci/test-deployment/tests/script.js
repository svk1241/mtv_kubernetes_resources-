import http from 'k6/http';
import { check, sleep } from 'k6';
import { Trend } from 'k6/metrics';
import { textSummary } from 'https://jslib.k6.io/k6-summary/0.0.2/index.js';
import { jUnit, jMeter } from './xml.js';

export const options = {
    stages: [
        { duration: '5s', target: 10 },
        { duration: '10s', target: 100 },
        { duration: '20s', target: 10 },
    ],
    thresholds: {
        http_req_failed: ['rate==0'],
        http_req_duration: ['avg<300'],
    },
};


export default function () {
    const params = {
        headers: {
            'Host': 'example.com'
        }
    };

    const responses = http.batch([
        ['GET', `${__ENV.PROTOCOL}://${__ENV.ADDRESS}/health-a`, null, params],
        ['GET', `${__ENV.PROTOCOL}://${__ENV.ADDRESS}/health-b`, null, params],
    ]);

    check(responses[0], {
        'All responses are status 200': (r) => r.status === 200,
        '/health-a is redirected to nginx-a service as /health': (r) => r.body.includes('A OK')
    });
    check(responses[1], {
        'All responses are status 200': (r) => r.status === 200,
        '/health-b is redirected to nginx-b service as /health': (r) => r.body.includes('B OK')
    });
    sleep(1);
}

export function handleSummary(data) {
    return {
        'routing_summary.json': JSON.stringify(data),
        'stdout': textSummary(data, { indent: '    ', enableColors: true }),
        'routing_summary.out': textSummary(data, { indent: '    ', enableColors: false }),
        'routing_summary_colored.out': textSummary(data, { indent: '    ', enableColors: true }),
        'routing_junit.xml': jUnit(data),
        'routing_out.jtl': jMeter(data),
    };
}

