#!/usr/bin/env bash

# TODO: ADD HELP MESSAGE

# Copyright 2023 The Knative Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# As per p. 4.b of Apache licence requirement mentioned above there is a notice of modification:
# Modified with adjustments by DXC Luxoft 2024

set -o errexit
set -o nounset
set -o pipefail

# Paths
CI_ROOT='ci/charts'

# Set the version and tag in Chart.yaml and values.yaml
VERSION=''
CHARTS_DIR=''
NAME=''
KNATIVE_OPERATOR_REPO_PATH=''

function check_required_parameters() {
    if [[ -z "${VERSION}" ]]; then
        echo 'ERROR: --version is mandatory'
        exit 1
    fi
    if [[ -z "${CHARTS_DIR}" ]]; then
        echo 'ERROR: --charts-dir is mandatory'
        exit 1
    fi
    if [[ -z "${NAME}" ]]; then
        echo 'ERROR: --name is mandatory'
        exit 1
    fi
    if [[ -z "${KNATIVE_OPERATOR_REPO_PATH}" ]]; then
        echo 'ERROR: --knative-operator-repo-path is mandatory'
        exit 1
    fi
}

function help() {
    echo "USAGE: ${BASH_SOURCE[0]} --version VERSION --charts-dir CHARTS_DIR --name NAME --knative-operator-repo-path KNATIVE_OPERATOR_REPO_PATH"
    echo ""
}

while [[ "$#" -gt 0 ]]; do
    case $1 in
        --version) VERSION="$2"; shift ;;
        --charts-dir) CHARTS_DIR="$2"; shift ;;
        --name) NAME="$2"; shift ;;
        --knative-operator-repo-path) KNATIVE_OPERATOR_REPO_PATH="$2"; shift ;;
        -h|--help) help; exit 0;;
        *) echo "Unknown parameter: $1"; help; exit 1 ;;
    esac
    shift
done

check_required_parameters

TARGET_DIR="${CHARTS_DIR}/${NAME}"
rm -rf "${TARGET_DIR}"
# Copy the base file and directories into the directory chart
cp -R "${KNATIVE_OPERATOR_REPO_PATH}/config/charts/." "${CHARTS_DIR}/"

mkdir -p ${TARGET_DIR}/templates
mkdir -p ${TARGET_DIR}/crds

# Generate the template based on the yaml files under config
echo "" > ${TARGET_DIR}/templates/operator.yaml
echo "" > ${TARGET_DIR}/crds/crds-all.yaml

for filename in ${KNATIVE_OPERATOR_REPO_PATH}/config/*.yaml; do
  if [[ $filename == *namespace.yaml ]]; then
      continue
  fi
  # Put CRD in crds/ directory
  if [[ $filename == *serving.yaml || $filename == *eventing.yaml ]]; then
    cat $filename >> ${TARGET_DIR}/crds/crds-all.yaml
    echo -e "\n---" >> ${TARGET_DIR}/crds/crds-all.yaml
    continue
  fi
  cat $filename >> ${TARGET_DIR}/templates/operator.yaml
  echo -e "\n---" >> ${TARGET_DIR}/templates/operator.yaml
done

# Replace the namespace and images with the helm parameters
sed -i.bak 's/namespace: knative-operator/namespace: "{{ .Release.Namespace | default .Values.namespace }}"/g' ${TARGET_DIR}/templates/operator.yaml
sed -i.bak 's/image: ko:\/\/knative.dev\/operator\/cmd\/operator/image: "{{ .Values.knativeOperator.image }}:{{ .Values.knativeOperator.tag }}"/g' ${TARGET_DIR}/templates/operator.yaml
sed -i.bak 's/image: ko:\/\/knative.dev\/operator\/cmd\/webhook/image: "{{ .Values.operatorWebhook.image }}:{{ .Values.operatorWebhook.tag }}"/g' ${TARGET_DIR}/templates/operator.yaml
sed -i.bak 's/operator.knative.dev\/release: devel/operator.knative.dev\/release: "v{{ .Chart.Version }}"/g' ${TARGET_DIR}/templates/operator.yaml
sed -i.bak 's/app.kubernetes.io\/version: devel/app.kubernetes.io\/version: "{{ .Chart.Version }}"/g' ${TARGET_DIR}/templates/operator.yaml
sed -i.bak 's/value: ""/value: "{{ .Values.kubernetesMinVersion }}"/g' ${TARGET_DIR}/templates/operator.yaml
sed -i.bak "/containers:/{
        s/containers://g 
        r ${CI_ROOT}/templates/operator-deployment-patches.yaml
    }" ${TARGET_DIR}/templates/operator.yaml

rm ${TARGET_DIR}/templates/operator.yaml.bak

cp ${CI_ROOT}/templates/operator-values.yaml ${TARGET_DIR}/values.yaml

sed -i.bak "s/{{ version }}/${VERSION}/g" ${TARGET_DIR}/Chart.yaml
sed -i.bak "s/{{ tag }}/${VERSION}/g" ${TARGET_DIR}/values.yaml

rm ${TARGET_DIR}/Chart.yaml.bak
rm ${TARGET_DIR}/values.yaml.bak

cd ${CHARTS_DIR}
helm package knative-operator
rm -rf knative-operator
tar xvzf knative-operator-${VERSION}.tgz
rm -f knative-operator-${VERSION}.tgz
cd -