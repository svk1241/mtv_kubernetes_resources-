#!/bin/bash -e
# TODO: ADD HELP MESSAGE
#################################
# Fetch new charts versions     #
#################################

# Paths used in update proccess
COMMON_CHART_ROOT='charts/knative-istio'
KNATIVE_OPERATOR_REPO_CLONE_PATH='tmp/operator'
CI_ROOT='./ci/charts'

# Istio helm repository
ISTIO_HELM_REPO_URL='https://istio-release.storage.googleapis.com/charts'
ISTIO_HELM_REPO_NAME='istio'
ISTIO_BASE_CHART_NAME='base'
ISTIO_ISTIOD_CHART_NAME='istiod'
ISTIO_GATEWAY_CHART_NAME='gateway'

ISTIO_BASE_TARGET_NAME='istio-base'
ISTIO_GATEWAY_TARGET_NAME='istio-gateway'
ISTIO_ISTIOD_TARGET_NAME='istiod'

# Knative charts parameters
KNATIVE_OPERATOR_CHART_NAME='knative-operator'
KNATIVE_SERVING_CHART_NAME='knative-serving'

# Parameters provided via cli
ISTIO_BASE_VERSION=''
ISTIO_ISTIOD_VERSION=''
ISTIO_GATWAY_VERSION=''
KNATIVE_OPERATOR_VERSION=''
KNATIVE_SERVING_VERSION=''

# Function to check that all parameters are provided
function check_required_parameters() {
    if [[ -z "${ISTIO_BASE_VERSION}" ]]; then
        echo 'ERROR: --istio-base-version is mandatory'
        exit 1
    fi
    if [[ -z "${ISTIO_ISTIOD_VERSION}" ]]; then
        echo 'ERROR: --istio-istiod-version is mandatory'
        exit 1
    fi
    if [[ -z "${ISTIO_GATEWAY_VERSION}" ]]; then
        echo 'ERROR: --istio-gateway-version is mandatory'
        exit 1
    fi
    if [[ -z "${KNATIVE_OPERATOR_VERSION}" ]]; then
        echo 'ERROR: --knative-operator-version is mandatory'
        exit 1
    fi
    if [[ -z "${KNATIVE_SERVING_VERSION}" ]]; then
        echo 'ERROR: --knative-serving-version is mandatory'
        exit 1
    fi
}

# paramters:
# 1. UNTAR_DIR
# 2. CHART_VERSION
# 3. HELM_REPO
# 4. CHART_NAME
# 5. TARGET_NAME - to rename chart directory once pulled
function pull_chart_from_helm_repo() {
    # Dir to untar
    UNTAR_DIR=$1
    # Chart's version
    CHART_VERSION=$2
    # Helm repository name
    HELM_REPO=$3
    # Helm chart name
    CHART_NAME=$4
    # Desired chart directory name
    TARGET_NAME=$5

    echo "${TARGET_NAME}"

    echo ''
    echo "Fetching ${HELM_REPO}/${CHART_NAME} chart of version ${CHART_VERSION}"
    echo 'Removing old chart if exists'
    rm -rf "${UNTAR_DIR}/${CHART_NAME}"
    echo "Pulling ${HELM_REPO}/${CHART_NAME} chart"
    helm pull --untar --untardir "${UNTAR_DIR}" --version "${CHART_VERSION}" "${HELM_REPO}/${CHART_NAME}"
    if [[ "${CHART_NAME}" != "${TARGET_NAME}" ]]; then
        rm -rf "${UNTAR_DIR}/${TARGET_NAME}"
        mv "${UNTAR_DIR}/${CHART_NAME}" "${UNTAR_DIR}/${TARGET_NAME}"
    fi
    echo 'Done'
}

help() {
    echo "USAGE: ${BASH_SOURCE[0]} --istio-istiod-version ISTIOD_VERSION --istio-base-version ISTIO_BASE_VERSION --istio-gateway-version ISTIO_GATEWAY_VERSION"
    echo "                         --knative-operator-version KNATIVE_OPERATOR_VERSION --knative-serving-version KNATIVE_SERVING_VERSION [-h|--help]"
    echo "PARAMETERS:"
    echo "  1. --istio-istiod-version ISTIOD_VERSION (required) - version of istio/istiod chart"
    echo "  2. --istio-base-version ISTIO_BASE_VERSION (required) - version of istio/base chart"
    echo "  3. --istio-gateway-version ISTIO_GATEWAY_VERSION (required) - version of istio/gateway chart"
    echo "  4. --knative-operator-version KNATIVE_OPERATOR_VERSION (required) - version of Knative operator"
    echo "  5. --knative-serving-version KNATIVE_SERVING_VERSION (required) - version of Knative serving"
    echo "  6. -h | --help (optional, flag) - if set, print this message and exit"
}

while [[ "$#" -gt 0 ]]; do
    case $1 in
        --istio-istiod-version) ISTIO_ISTIOD_VERSION="$2"; shift ;;
        --istio-base-version) ISTIO_BASE_VERSION="$2"; shift ;;
        --istio-gateway-version) ISTIO_GATEWAY_VERSION="$2"; shift ;;
        --knative-operator-version) KNATIVE_OPERATOR_VERSION="$2"; shift ;;
        --knative-serving-version) KNATIVE_SERVING_VERSION="$2"; shift ;;
        -h|--help) help; exit 0 ;;
        *) echo "Unknown parameter: $1"; help; exit 1 ;;
    esac
    shift
done

check_required_parameters

echo 'Will fetch new versions of components:'
echo ''
echo "ISTIO_BASE_VERSION:       ${ISTIO_BASE_VERSION}"
echo "ISTIO_ISTIOD_VERSION:     ${ISTIO_ISTIOD_VERSION}"
echo "ISTIO_GATEWAY_VERSION:    ${ISTIO_GATEWAY_VERSION}"
echo "KNATIVE_OPERATOR_VERSION: ${KNATIVE_OPERATOR_VERSION}"
echo "KNATIVE_SERVING_VERSION:  ${KNATIVE_SERVING_VERSION}"
echo '==================================================='
echo ''

# Fetch provided component's versions
# Fetch istio's charts

echo 'Adding istio helm repository'
helm repo add "${ISTIO_HELM_REPO_NAME}" "${ISTIO_HELM_REPO_URL}"
helm repo update

pull_chart_from_helm_repo "${COMMON_CHART_ROOT}" "${ISTIO_BASE_VERSION}" "${ISTIO_HELM_REPO_NAME}" "${ISTIO_BASE_CHART_NAME}" "${ISTIO_BASE_TARGET_NAME}"
pull_chart_from_helm_repo "${COMMON_CHART_ROOT}" "${ISTIO_ISTIOD_VERSION}" "${ISTIO_HELM_REPO_NAME}" "${ISTIO_ISTIOD_CHART_NAME}" "${ISTIO_ISTIOD_TARGET_NAME}"
pull_chart_from_helm_repo "${COMMON_CHART_ROOT}" "${ISTIO_GATEWAY_VERSION}" "${ISTIO_HELM_REPO_NAME}" "${ISTIO_GATEWAY_CHART_NAME}" "${ISTIO_GATEWAY_TARGET_NAME}"

echo ''
echo 'Generating knative-operator helm chart'
echo 'Pulling official knative-repository'
# Clear directory if it already exists
rm -rf "${KNATIVE_OPERATOR_REPO_CLONE_PATH}"
mkdir -p "${KNATIVE_OPERATOR_REPO_CLONE_PATH}"
git clone --branch knative-v1.15.2 --depth 1 https://github.com/knative/operator.git "${KNATIVE_OPERATOR_REPO_CLONE_PATH}"

${CI_ROOT}/generate-knative-operator-chart.sh --name "${KNATIVE_OPERATOR_CHART_NAME}" --version "${KNATIVE_OPERATOR_VERSION}" --charts-dir "${COMMON_CHART_ROOT}" --knative-operator-repo-path "${KNATIVE_OPERATOR_REPO_CLONE_PATH}"
rm -rf "${KNATIVE_OPERATOR_REPO_CLONE_PATH}"

echo ''
echo 'Updating knative-serving chart'
rm -rf "${COMMON_CHART_ROOT}/${KNATIVE_SERVING_CHART_NAME}"
cp -r "${CI_ROOT}/templates/chart-templates/${KNATIVE_SERVING_CHART_NAME}" "${COMMON_CHART_ROOT}"
sed -i "s/version: .*/version: \"${KNATIVE_SERVING_VERSION}\"/g" "${COMMON_CHART_ROOT}/${KNATIVE_SERVING_CHART_NAME}/values.yaml"
sed -i "s/appVersion: .*/appVersion: \"${KNATIVE_SERVING_VERSION}\"/g" "${COMMON_CHART_ROOT}/${KNATIVE_SERVING_CHART_NAME}/Chart.yaml"
