#!/bin/bash -e

# TODO: ADD HELP MESSAGE

#############################################
# This script creates a deliverable package #
#############################################

# CLI parameters
PACKAGE_VERSION=''
VALUES_FILE=''
PACKAGE_PREFIX='knative-deliverable'
CREATE_PATH='tmp/knative-istio-deliverable'

# Constants
CHARTS_ROOT='charts/knative-istio'
RELATIVE_VALUES_FILE_PATH='project-specific-values'
DIRS_TO_COPY='istio-base istio-gateway istiod knative-operator knative-serving'
CI_ROOT='ci/charts'

function check_required_parameters() {
    if [[ -z "${PACKAGE_VERSION}" ]]; then
        echo 'ERROR: --package-version is mandatory'
        exit 1
    fi
}

function help() {
    echo "USAGE: ${BASH_SOURCE[0]} --package-version PACKAGE_VERSION [--output OUTPUT_PATH] [-h|--help]"
    echo "PARAMETERS:"
    echo "  1. --package-version PACKAGE_VERSION (required) - version suffix that will be appended to resulting artifact."
    echo "                      Resulting archive name is constructed as follows: ${PACKAGE_PREFIX}-<PACKAGE_VERSION>.zip"
    echo "  2. --output OUTPUT_PATH (optional) - path where resulting archive will be put. Default: '${CREATE_PATH}'"
    echo "  3. -h | --help (optional, flag) - if set, print this message and exit"
}

while [[ "$#" -gt 0 ]]; do
    case $1 in
        --package-version) PACKAGE_VERSION="$2"; shift ;;
        --output) CREATE_PATH="$2"; shift ;; # Not required
        -h|--help) help; exit 0 ;;
        *) echo "Unknown parameter: $1"; help; exit 1 ;;
    esac
    shift
done

check_required_parameters

PACKAGE_NAME="${PACKAGE_PREFIX}-${PACKAGE_VERSION}"

rm -rf "${CREATE_PATH}"
mkdir -p "${CREATE_PATH}/${PACKAGE_NAME}"

for CHART_DIR in ${DIRS_TO_COPY}; do
    cp -r "${CHARTS_ROOT}/${CHART_DIR}" "${CREATE_PATH}/${PACKAGE_NAME}"
done

cp "${CHARTS_ROOT}/release-values.gotmpl" "${CREATE_PATH}/${PACKAGE_NAME}/release-values.gotmpl"
cp "${CHARTS_ROOT}/check-knative.sh" "${CREATE_PATH}/${PACKAGE_NAME}/check-knative.sh"
cp "${CHARTS_ROOT}/export-images.sh" "${CREATE_PATH}/${PACKAGE_NAME}/export-images.sh"
cp "${CHARTS_ROOT}/delete-knative.sh" "${CREATE_PATH}/${PACKAGE_NAME}/delete-knative.sh"
cp "${CHARTS_ROOT}/README.md" "${CREATE_PATH}/${PACKAGE_NAME}/README.md"
cp "${CI_ROOT}/templates/template-helmfile-for-package.yaml" "${CREATE_PATH}/${PACKAGE_NAME}/helmfile.yaml"

# Create empty values directory
mkdir -p "${CREATE_PATH}/${PACKAGE_NAME}/values"
cp "${CHARTS_ROOT}/values/default-values.yaml" "${CREATE_PATH}/${PACKAGE_NAME}/values/helmfile-values.yaml"

# Render default values for charts
cd "${CREATE_PATH}/${PACKAGE_NAME}"

helmfile write-values --output-file-template='values/{{ .Release.Name }}-values.yaml'

cd -

cd "${CREATE_PATH}"

zip -r "${PACKAGE_NAME}.zip" "${PACKAGE_NAME}"
rm -rf "${PACKAGE_NAME}"

echo "RESULTING PACKAGE: ${CREATE_PATH}/${PACKAGE_NAME}.zip"

cd - >/dev/null