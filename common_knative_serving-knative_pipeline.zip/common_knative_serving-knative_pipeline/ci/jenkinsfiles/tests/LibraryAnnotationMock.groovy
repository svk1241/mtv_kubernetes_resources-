/**
 * Library is a mock interface for jenkins pipeline
 */
@interface Library {

    String value()

}
