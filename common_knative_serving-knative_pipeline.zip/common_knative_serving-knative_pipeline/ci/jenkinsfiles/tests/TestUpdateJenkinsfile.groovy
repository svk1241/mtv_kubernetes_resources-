package tests

import static org.junit.jupiter.api.Assertions.assertEquals
import static com.lesfurets.jenkins.unit.global.lib.LibraryConfiguration.library

import groovy.json.JsonSlurper
import com.lesfurets.jenkins.unit.BasePipelineTest
import groovy.transform.CompileDynamic
import org.junit.jupiter.api.DisplayName
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.BeforeEach
import org.codehaus.groovy.runtime.InvokerHelper

/**
 * Class TestUpdateJenkinsfile contains unit tests for utility methods used in pipeline sourced in ci/jenkinsfiles/update.jenkinsfile
 */
@Tag('update.jenkinsfile')
@CompileDynamic
class TestUpdateJenkinsfile extends BasePipelineTest {

    static String pipelinePath = 'create-update-pr.jenkinsfile'

    @BeforeEach
    void setUp() {
        super.setUp()
    }

    /**
     * Helper method to load pipeline as a script with properly mocked @Library annotation
     */
    Script loadPipeline() {
        GroovyScriptEngine engine = new GroovyScriptEngine('.')
        engine.loadScriptByName('tests/LibraryAnnotationMock.groovy')
        Script script = InvokerHelper.createScript(engine.loadScriptByName(pipelinePath), new Binding())
        return script
    }

    @Test
    @DisplayName('Test checking if generatePRDescription method works as expected when all versions change')
    void testGeneratePRDescriptionEverythingChanges() {
        Script script = loadPipeline()
        script.currentKnative = '1.1.1'
        script.latestKnative = '1.2.3'
        script.currentIstio = '2.3.4'
        script.latestIstio = '3.2.1'
        script.currentK8S = '1.22.0'
        script.latestK8S = '1.33.0'
        String expected = 'Available updates: knative v1.1.1 --> 1.2.3; istio v2.3.4 --> 3.2.1; tested on k8s v1.22.0, then on v1.33.0.'
        assertEquals(expected, script.generatePRDescription())
    }

    @Test
    @DisplayName('Test checking if generatePRDescription method works as expected when no versions change')
    void testGeneratePRDescriptionNothingChanges() {
        Script script = loadPipeline()
        script.currentKnative = '1.1.1'
        script.latestKnative = '1.1.1'
        script.currentIstio = '2.2.2'
        script.latestIstio = '2.2.2'
        script.currentK8S = '3.3.3'
        script.latestK8S = '3.3.3'
        String expected = 'Available updates: knative v1.1.1 (no changes); istio v2.2.2 (no changes); tested on k8s v3.3.3.'
        assertEquals(expected, script.generatePRDescription())
    }

    @Test
    @DisplayName('Test checking if generatePRDescription method works as expected when only knative version changes')
    void testGeneratePRDescriptionKnativeVersionChanges() {
        Script script = loadPipeline()
        script.currentKnative = '1.1.1'
        script.latestKnative = '1.1.2'
        script.currentIstio = '2.2.2'
        script.latestIstio = '2.2.2'
        script.currentK8S = '3.3.3'
        script.latestK8S = '3.3.3'
        String expected = 'Available updates: knative v1.1.1 --> 1.1.2; istio v2.2.2 (no changes); tested on k8s v3.3.3.'
        assertEquals(expected, script.generatePRDescription())
    }

    @Test
    @DisplayName('Test checking if generatePRDescription method works as expected when only istio version changes')
    void testGeneratePRDescriptionIstioVersionChanges() {
        Script script = loadPipeline()
        script.currentKnative = '1.1.1'
        script.latestKnative = '1.1.1'
        script.currentIstio = '2.2.2'
        script.latestIstio = '2.2.3'
        script.currentK8S = '3.3.3'
        script.latestK8S = '3.3.3'
        String expected = 'Available updates: knative v1.1.1 (no changes); istio v2.2.2 --> 2.2.3; tested on k8s v3.3.3.'
        assertEquals(expected, script.generatePRDescription())
    }

    @Test
    @DisplayName('Test checking if generatePRDescription method works as expected when only aks k8s version changes')
    void testGeneratePRDescriptionAksK8SVersionChanges() {
        Script script = loadPipeline()
        script.currentKnative = '1.1.1'
        script.latestKnative = '1.1.1'
        script.currentIstio = '2.2.2'
        script.latestIstio = '2.2.2'
        script.currentK8S = '3.3.3'
        script.latestK8S = '3.3.4'
        String expected = 'Available updates: knative v1.1.1 (no changes); istio v2.2.2 (no changes); tested on k8s v3.3.3, then on v3.3.4.'
        assertEquals(expected, script.generatePRDescription())
    }

}
