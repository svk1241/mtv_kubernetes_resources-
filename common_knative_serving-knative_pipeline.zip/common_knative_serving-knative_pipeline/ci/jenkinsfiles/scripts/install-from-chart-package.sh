#!/bin/bash -e

knativeVersion=$1
operatorVersion=$2
istioVersion=$3

rm -rf ./tmp/installer
mkdir -p ./tmp
mv tmp/knative-istio-deliverable/knative-deliverable-serving-${knativeVersion}-operator-${operatorVersion}.zip . 
unzip knative-deliverable-serving-${knativeVersion}-operator-${operatorVersion}.zip
rm knative-deliverable-serving-${knativeVersion}-operator-${operatorVersion}.zip
mv knative-deliverable-serving-${knativeVersion}-operator-${operatorVersion} ./tmp/installer
cp ./ci/charts/templates/test-helmfile-values.yaml ./tmp/installer/values/helmfile-values.yaml
sed -i -e "s/<serving-version>/${knativeVersion}/g" ./tmp/installer/values/helmfile-values.yaml
sed -i -e "s/<operator-version>/${operatorVersion}/g" ./tmp/installer/values/helmfile-values.yaml
sed -i -e "s/<istio-version>/${istioVersion}/g" ./tmp/installer/values/helmfile-values.yaml
cd ./tmp/installer
helmfile sync --args=--wait
cd -
sleep 40