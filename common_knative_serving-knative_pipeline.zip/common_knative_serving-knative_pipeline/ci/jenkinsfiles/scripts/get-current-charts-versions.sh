#!/bin/bash -e


SHOW_ISTIO=false
SHOW_KNATIVE_SERVING=false
SHOW_KNATIVE_OPERATOR=false
VERBOSE=false
PATH_TO_CHARTS='charts/knative-istio'

help() {
    echo "Usage: script.sh [OPTIONS]"
    echo
    echo "Options:"
    echo "  --show-istio               Show Istio version."
    echo "  --show-knative-serving     Show Knative version."
    echo "  --show-knative-operator    Show Knative Operator version."
    echo "  --path-to-charts <path> (Optional)    Specify the path to Helm charts. Provide an absolute or relative path after this flag."
    echo
    echo "Example:"
    echo "  script.sh --show-istio --path-to-charts /path/to/charts"
    echo
    echo "Note: Using an unknown parameter will terminate the script with an error."
    exit 0
}

while [[ "$#" -gt 0 ]]; do
    case $1 in
        --show-istio) SHOW_ISTIO=true ;;
        --show-knative-serving) SHOW_KNATIVE_SERVING=true ;;
        --show-knative-operator) SHOW_KNATIVE_OPERATOR=true ;;
        --path-to-charts) PATH_TO_CHARTS=$2 ; shift ;;
        *) echo "UNKNOWN PARAMETER: ${1}"; exit 1 ;;
    esac
    shift
done


# echo "PARAMETERS:"
# echo "SHOW_ISTIO: ${SHOW_ISTIO}"
# echo "SHOW_KNATIVE_SERVING: ${SHOW_KNATIVE_SERVING}"
# echo "SHOW_KNATIVE_OPERATOR: ${SHOW_KNATIVE_OPERATOR}"
# echo "PATH_TO_CHARTS: ${PATH_TO_CHARTS}"

ISTIO_VERSION=$(cat "${PATH_TO_CHARTS}/istio-base/Chart.yaml" | grep -Po '(?<=version: ).*' | tr -d '"')
KNATIVE_OPERATOR_VERSION=$(cat "${PATH_TO_CHARTS}/knative-operator/Chart.yaml" | grep -Po '(?<=version: ).*' | tr -d '"')
KNATIVE_SERVING_VERSION=$(cat "${PATH_TO_CHARTS}/knative-serving/Chart.yaml" | grep -Po '(?<=appVersion: ).*' | tr -d '"' )

if [[ "${SHOW_ISTIO}" == true ]]; then
    echo "${ISTIO_VERSION}"
    exit 0
fi

if [[ "${SHOW_KNATIVE_OPERATOR}" == true ]]; then
    echo "${KNATIVE_OPERATOR_VERSION}"
    exit 0
fi

if [[ "${SHOW_KNATIVE_SERVING}" == true ]]; then
    echo "${KNATIVE_SERVING_VERSION}"
    exit 0
fi