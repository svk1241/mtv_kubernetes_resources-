#!/bin/bash

INSTALLER_PATH="./installer"
TEMPLATES_PATH="./ci/templates"

help() {
  echo "USAGE: ${BASH_SOURCE[0]} -k <knative-version> -i <istio-version> -o <operator-versions> -c <conatiner-registry> -u <username> -p <password>"
  echo "PARAMETERS:"
  echo "-k (REQUIRED): Knative Serving version"
  echo "-i (REQUIRED): Istio version"
  echo "-o (REQUIRED): Knative operator version"
  echo "-n (REQUIRED): Net-istio release version"
  echo "-c (OPTIONAL): Container registry url to push images to"
  echo "-u (OPTIONAL): Username for container registry"
  echo "-p (OPTIONAL): Password for container registry"
  echo "-h           : Show this message (help)"
}

knative_version=""
istio_version=""
operator_version=""
target_container_registry=""
crUsername=""
crPassword=""
net_istio_release_version=""

while getopts ":k:i:o:c:u:p:n:h" o; do
  case "${o}" in
  i)
    istio_version="${OPTARG}"
    ;;
  k)
    knative_version="${OPTARG}"
    ;;
  o)
    operator_version="${OPTARG}"
    ;;
  c)
    target_container_registry="${OPTARG}"
    ;;
  u)
    crUsername="${OPTARG}"
    ;;
  p)
    crPassword="${OPTARG}"
    ;;
  n)
    net_istio_release_version="${OPTARG}"
    ;;
  h)
    help
    exit 0
    ;;
  *)
    echo "Unknown option $o"
    help
    exit 1
    ;;
  esac
done

if [[ "${knative_version}" = "" || "${istio_version}" = "" || "${operator_version}" = "" || ${net_istio_release_version} = "" ]]; then
  echo "All required options must be set, use -h option to see help message"
  help
  exit 1
fi

echo "Updating installer: knative serving v${knative_version}, istio v${istio_version}, operator v${operator_version}"

echo "!!!!!!!!!!!!!!!!!!!!!"
ls "${INSTALLER_PATH}"

if [ ! -d "${INSTALLER_PATH}/versions/${knative_version}" ]; then
  mkdir ${INSTALLER_PATH}/versions/${knative_version}
  mkdir ${INSTALLER_PATH}/versions/${knative_version}/istio
  mkdir ${INSTALLER_PATH}/versions/${knative_version}/operator
  version="${knative_version}" envsubst '${version}' <"${TEMPLATES_PATH}/template-serving-for-operator.yaml" >"${INSTALLER_PATH}/versions/${knative_version}/config-serving.yaml"
  cp ${TEMPLATES_PATH}/custom-gateway-istio.yaml ${INSTALLER_PATH}/versions/${knative_version}/istio/istio-gateway.yaml
fi

curl -L https://github.com/knative/operator/releases/download/knative-v$operator_version/operator.yaml -o ${INSTALLER_PATH}/versions/${knative_version}/operator/operator_tmpl.yaml && \
sed -i'' -e 's+gcr.io+${knative_registry}+g' ${INSTALLER_PATH}/versions/${knative_version}/operator/operator_tmpl.yaml
sed -i'' -e "s+containers:+imagePullSecrets:\n        - name: knative-hub-secret\n      containers:+g" ${INSTALLER_PATH}/versions/${knative_version}/operator/operator_tmpl.yaml
sed -i'' -e 's/namespace: default/namespace: knative-operator/g' ${INSTALLER_PATH}/versions/${knative_version}/operator/operator_tmpl.yaml

echo "Updating knative version to ${knative_version}"
sed -i'' -e "s/version: .*/version: ${knative_version}/g" ${INSTALLER_PATH}/versions/${knative_version}/knative-serving_tmpl.yaml

echo "Pulling istio helm charts of version ${istio_version}"
mkdir ${INSTALLER_PATH}/versions/${knative_version}/istio/${istio_version}
helm repo add istio https://istio-release.storage.googleapis.com/charts
helm repo update
helm pull istio/base --untar=true --version=$istio_version -d ${INSTALLER_PATH}/versions/${knative_version}/istio/${istio_version}
helm pull istio/gateway --untar=true --version=$istio_version -d ${INSTALLER_PATH}/versions/${knative_version}/istio/${istio_version}
helm pull istio/istiod --untar=true --version=$istio_version -d ${INSTALLER_PATH}/versions/${knative_version}/istio/${istio_version}

# Update image version in custom values
sed -i'' -e "s+image: .*+image: \${istio_registry}/istio/pilot:${istio_version}+g" ${INSTALLER_PATH}/versions/${knative_version}/istio/values/istiod-values_tmpl.yaml
if [[ "${target_container_registry}" != "" && "${crUsername}" != "" && "${crPassword}" != "" ]]; then
  ./ci/update/copy-images-to-registry.sh -t $target_container_registry -u $crUsername -p $crPassword -k $knative_version -i $istio_version -o $operator_version -n $net_istio_release_version
fi
./ci/update/update-images.sh -k $knative_version -i $istio_version -o $operator_version -n $net_istio_release_version