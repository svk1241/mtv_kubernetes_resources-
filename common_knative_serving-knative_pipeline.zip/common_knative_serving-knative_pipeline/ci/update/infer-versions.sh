#!/bin/bash -e

VERSION_TYPE=${1:?"Provide either 'LATEST' or 'BASELINE'"}
VERSION_COMPONENT=${2:?"Provide component to find version for, e.g. 'Serving', 'Istio', 'kubernetes' etc"}

if [[ "${VERSION_TYPE}" != 'LATEST' && "${VERSION_TYPE}" != 'BASELINE' ]]; then
    echo 'VERSION_TYPE must be either "LATEST" or "BASELINE"'
fi

if [[ "${VERSION_TYPE}" = 'LATEST' ]]; then
    VERSION_STRING=$(cat VERSIONS.md | grep -Pv '$^' | tail -n 1)
else
    VERSION_STRING=$(cat VERSIONS.md | grep -Pv '$^' | tail -n 2 | head -n 1)
fi
echo "${VERSION_STRING}" | grep -Pio "(?<=${VERSION_COMPONENT}: )[^,]+"