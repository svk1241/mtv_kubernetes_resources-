#!/bin/bash -e

help() {
  echo "USAGE: <script> -k <knative version> -i <istio version> -o <knative operator version>"
  echo "OPTIONS:"
  echo "-k (REQUIRED): Knative Serving version"
  echo "-i (REQUIRED): Istio version"
  echo "-n (REQUIRED): Net-istio release version"
  echo "-o (REQUIRED): Knative operator version"
}

knativeVersion=""
istioVersion=""
operatorVersion=""
netIstioReleaseVersion=""

while getopts ":k:i:o:n:h" o; do
  case "$o" in
  k)
    knativeVersion="${OPTARG}"
    ;;
  i)
    istioVersion="${OPTARG}"
    ;;
  o)
    operatorVersion="${OPTARG}"
    ;;
  n)
    netIstioReleaseVersion="${OPTARG}"
    ;;
  h)
    help
    exit 0
    ;;
  *)
    echo "Unknown option ${o}, use -h to get the reference"
    exit 1
    ;;
  esac
done

if [[ "${knativeVersion}" = "" || "${istioVersion}" = "" || "${operatorVersion}" = "" || "${netIstioReleaseVersion}" = "" ]]; then
  echo "Error: all options must be set!"
  help
  exit 1
fi

curl -L https://github.com/knative/serving/releases/download/knative-v$knativeVersion/serving-core.yaml | grep 'image: .*' -o | grep 'gcr.io/.*' -o | uniq
curl -L https://github.com/knative/serving/releases/download/knative-v$knativeVersion/serving-hpa.yaml | grep 'image: .*' -o | grep 'gcr.io/.*' -o | uniq
curl -L https://github.com/knative/operator/releases/download/knative-v$operatorVersion/operator.yaml | grep 'image: .*' -o | grep 'gcr.io/.*' -o | uniq
curl -L https://github.com/knative/net-istio/releases/download/knative-v$netIstioReleaseVersion/net-istio.yaml | grep 'image: .*' -o | grep 'gcr.io/.*' -o | uniq
echo docker.io/istio/pilot:${istioVersion}
echo docker.io/istio/proxyv2:${istioVersion}