#!/bin/bash -e

function help() {
  echo "USAGE: ${BASH_SOURCE[0]} -k <Knative serving version> -i <Istio version> -o <Knative operator version>"
  echo "PARAMETERS:"
  echo "-k (REQUIRED): Knative serving version"
  echo "-i (REQUIRED): Istio version"
  echo "-n (REQUIRED): Net-istio release version"
  echo "-o (REQUIRED): Knative operator version"
}

knative_version=""
istio_version=""
operator_version=""
net_istio_release_version=""

while getopts ":k:i:o:n:h" o; do
  case "$o" in
  k)
    knative_version="${OPTARG}"
    ;;
  i)
    istio_version="${OPTARG}"
    ;;
  o)
    operator_version="${OPTARG}"
    ;;
  n)
    net_istio_release_version="${OPTARG}"
    ;;
  h)
    help
    exit 0
    ;;
  *)
    echo "Unknown option $o"
    help
    exit 1
    ;;
  esac
done

echo "Updating images to following versions: "
echo "knative: v${knative_version}, istio: v${istio_version}, operator: v${operator_version}"

if [[ "${knative_version}" = "" || "${istio_version}" = "" || "${operator_version}" = "" || "${net_istio_release_version}" = "" ]]; then
  echo "All required parameters must be set"
  help
  exit 1
fi

INSTALLER_PATH="./installer"
SERVING_TEMPLATE="${INSTALLER_PATH}/versions/${knative_version}/config-serving.yaml"

activator=$(./ci/update/get-images.sh -i $istio_version -k $knative_version -o $operator_version -n $net_istio_release_version | grep 'serving/cmd/activator@' | sed 's/gcr.io/${knative_registry}/')
sed -i'' -e "s+activator: .*+activator: ${activator}+g" ${SERVING_TEMPLATE}

autoscaler=$(./ci/update/get-images.sh -i $istio_version -k $knative_version -o $operator_version -n $net_istio_release_version | grep 'serving/cmd/autoscaler@' | sed 's/gcr.io/${knative_registry}/')
sed -i'' -e "s+autoscaler: .*+autoscaler: ${autoscaler}+g" ${SERVING_TEMPLATE}

autoscaler_hpa=$(./ci/update/get-images.sh -i $istio_version -k $knative_version -o $operator_version -n $net_istio_release_version | grep 'serving/cmd/autoscaler-hpa@' | sed 's/gcr.io/${knative_registry}/')
sed -i'' -e "s+autoscaler-hpa: .*+autoscaler-hpa: ${autoscaler_hpa}+g" ${SERVING_TEMPLATE}

serving_controller=$(./ci/update/get-images.sh -i $istio_version -k $knative_version -o $operator_version -n $net_istio_release_version | grep 'serving/cmd/controller@' | sed 's/gcr.io/${knative_registry}/')
sed -i'' -e "s+controller: .*+controller: ${serving_controller}+g" ${SERVING_TEMPLATE}

istio_controller=$(./ci/update/get-images.sh -i $istio_version -k $knative_version -o $operator_version -n $net_istio_release_version | grep 'net-istio/cmd/controller@' | sed 's/gcr.io/${knative_registry}/')
sed -i'' -e "s+net-istio-controller/controller: .*+net-istio-controller/controller: ${istio_controller}+g" ${SERVING_TEMPLATE}

serving_webhook=$(./ci/update/get-images.sh -i $istio_version -k $knative_version -o $operator_version -n $net_istio_release_version | grep 'serving/cmd/webhook@' | sed 's/gcr.io/${knative_registry}/')
sed -i'' -e "s+webhook: .*+webhook: ${serving_webhook}+g" ${SERVING_TEMPLATE}

istio_webhook=$(./ci/update/get-images.sh -i $istio_version -k $knative_version -o $operator_version -n $net_istio_release_version | grep 'net-istio/cmd/webhook@' | sed 's/gcr.io/${knative_registry}/')
sed -i'' -e "s+net-istio-webhook/webhook: .*+net-istio-webhook/webhook: ${istio_webhook}+g" ${SERVING_TEMPLATE}

queue=$(./ci/update/get-images.sh -i $istio_version -k $knative_version -o $operator_version -n $net_istio_release_version | grep 'serving/cmd/queue@' | sed 's/gcr.io/${knative_registry}/')
sed -i'' -e "s+queue-proxy: .*+queue-proxy: ${queue}+g" ${SERVING_TEMPLATE}