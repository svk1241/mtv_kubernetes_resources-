#!/bin/bash -e

help() {
  echo "USAGE: <exec-name> -t <target-registry> -u <username> -p <password>"
  echo "PARAMETERS:"
  echo "-t (REQUIRED):   Registry to copy to (e.g. docker.io)"
  echo "-k (REQUIRED):   Knative serving version"
  echo "-i (REQUIRED):   Istio version"
  echo "-o (REQUIRED):   Operator version"
  echo "-n (REQUIRED):   Net-istio release version"
  echo "EXAMPLE: ./copy-new-images-to-registry.sh -t docker.io -u my-username -p my-password"
}

targetRegistry=""
knativeVersion=""
istioVersion=""
operatorVersion=""
netIstioReleaseVersion=""

while getopts ":t:u:p:k:i:o:n:h" o; do
  case "${o}" in
    t)
      targetRegistry="${OPTARG}"
      ;;
    k)
      knativeVersion="${OPTARG}"
      ;;
    i)
      istioVersion="${OPTARG}"
      ;;
    o)
      operatorVersion="${OPTARG}"
      ;;
    n)
      netIstioReleaseVersion="${OPTARG}"
      ;;
    h)
      help
      exit 0
      ;;
    *)
      echo "Unknown option ${o}"
      help
      exit 1
      ;;
    esac
done

echo $targetRegistry

if [[ "${targetRegistry}" = "" ]]; then
  echo "Target registry must be provided"
  help
  exit 1
fi

./ci/update/get-images.sh -k $knativeVersion -i $istioVersion -o $operatorVersion -n $netIstioReleaseVersion | grep -v domain | while read line; do
  targetImage=$(echo ${line} | sed -E -e "s#(docker.io/|gcr.io/|@sha.+)##g"  )
  if [[ $(echo "${line}" | grep -o 'operator') ]]; then
    echo "Tagging ${target} with ${operatorVersion}"
    targetImage="${targetImage}:${operatorVersion}"
  elif [[ $(echo "${line}" | grep -Po '(serving|net-istio)') ]]; then
    echo "Tagging ${target} with ${knativeVersion}"
    targetImage="${targetImage}:${knativeVersion}"
  fi
  echo "Copying ${line} to ${targetRegistry}/${targetImage}"
  echo "Executing: az acr import --name ${targetRegistry} --source ${line} --image ${targetImage} --force"
  az acr import --name ${targetRegistry} --source ${line} --image ${targetImage} --force
done