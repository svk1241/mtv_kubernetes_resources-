#!/bin/bash -e

help() {
  echo "USAGE: ${BASH_SOURCE[0]} -k <knative-version> -i <istio-version> -c <k8s version>"
  echo "PARAMETERS:"
  echo "-k (REQUIRED): Currently used knative version"
  echo "-i (REQUIRED): Currently used istio version"
  echo "-o (REQUIRED): Currently used operator version"
  echo "-c (REQUIRED): Kubernetes version, used to test current knative and istio"
  echo "-h: Show this message"
}

get_certmanager_version() {
  ls -d installer/*/ | grep -E -o 'certmanager_v[0-9]+\.[0-9]+\.[0-9]+' | grep -E -o '[0-9]+\.[0-9]+\.[0-9]+'
}

knativeVersion=""
istioVersion=""
k8sVersion=""
operatorVersion=""
certmanagerVersion=$(get_certmanager_version)

while getopts ":k:i:o:c:h" o; do
  case "${o}" in
    k)
      knativeVersion="${OPTARG}"
      ;;
    i)
      istioVersion="${OPTARG}"
      ;;
    c)
      k8sVersion="${OPTARG}"
      ;;
    o)
      operatorVersion="${OPTARG}"
      ;;
    h)
      help
      exit 0
      ;;
    *)
      echo "Unknown option ${o}, see usage:"
      help
      exit 1
      ;;
  esac
done

if [[ "${knativeVersion}" = '' || "${istioVersion}" = '' || "${operatorVersion}" = '' || "${k8sVersion}" = '' ]]; then
  echo "Not all required parameters are provided"
  help
  exit 1
fi

versions="* Knative Serving: ${knativeVersion}, Knative Operator: ${operatorVersion}, Istio: ${istioVersion}, Certmanager: ${certmanagerVersion}, tested on kubernetes: ${k8sVersion}"

echo "${versions}"
echo "" >> VERSIONS.md
echo "${versions}" >> VERSIONS.md
