#!/bin/bash -e

CERTMANAGER_VERSION="1.13.3"
INSTALLER_PATH="installer"
TEMPLATES_PATH="ci/templates"

help() {
  echo "USAGE: ${BASH_SOURCE[0]} -k <knative-version> -i <istio-version>"
  echo "PARAMETERS:"
  echo "  -k - knative version"
  echo "  -i - istio version"
}

knative_version="1.12.0"
istio_version="1.19.3"

while getopts ":k:i:o:dh" o; do
  case "${o}" in
  k)
    knative_version="${OPTARG}"
    ;;
  i)
    istio_version="${OPTARG}"
    ;;
  h)
    help
    exit 0
    ;;
  *)
    echo "Error: unknown parameter ${o}"
    help
    exit 1
    ;;
  esac
done

# Create temprorary directory
rm -rf ./tmp
mkdir tmp

mkdir tmp/installer
mkdir -p tmp/installer/operator
mkdir -p tmp/installer/istio
# mkdir -p tmp/installer/manifests/certmanager_v${CERTMANAGER_VERSION}

cp ${INSTALLER_PATH}/install-knative.sh tmp/installer
cp ${INSTALLER_PATH}/delete-knative.sh tmp/installer
cp ${INSTALLER_PATH}/basic-config.yaml tmp/installer
cp ${INSTALLER_PATH}/config-serving.yaml tmp/installer
mkdir tmp/installer/certmanager
cp ${INSTALLER_PATH}/certmanager_v${CERTMANAGER_VERSION}/* tmp/installer/certmanager/
cp ${INSTALLER_PATH}/versions/${knative_version}/config-serving.yaml tmp/installer/operator
cp ${INSTALLER_PATH}/versions/${knative_version}/operator/operator_tmpl.yaml tmp/installer/operator
cp ${INSTALLER_PATH}/versions/${knative_version}/istio/istio-gateway.yaml tmp/installer/istio/
cp -r ${INSTALLER_PATH}/certificates tmp/installer

cp -r ${TEMPLATES_PATH}/kustomize/lb-annotations/* tmp/installer/istio

knative_version="${knative_version}" \
  istio_version="${istio_version}" \
  envsubst '${knative_version} ${istio_version}' <"${TEMPLATES_PATH}/docs/README_template.md" >"tmp/installer/README.md"

yq -i ".knative.version |= \"${knative_version}\", .istio.version |= \"${istio_version}\"" tmp/installer/basic-config.yaml

cat './ci/templates/helm-values/base-values_tmpl.yaml' >tmp/values.yaml
helm template istio-base ${INSTALLER_PATH}/versions/${knative_version}/istio/${istio_version}/base --include-crds --output-dir tmp/rendered --values tmp/values.yaml --namespace="istio-system"

cat './ci/templates/helm-values/istiod-values_tmpl.yaml' >tmp/values.yaml
helm template istiod ${INSTALLER_PATH}/versions/${knative_version}/istio/${istio_version}/istiod --include-crds --output-dir tmp/rendered --values tmp/values.yaml --namespace="istio-system"

cat './ci/templates/helm-values/gateway-values_tmpl.yaml' >tmp/values.yaml
helm template istio-ingressgateway ${INSTALLER_PATH}/versions/${knative_version}/istio/${istio_version}/gateway --include-crds --output-dir tmp/rendered --values tmp/values.yaml --namespace="istio-system"

rm tmp/values.yaml
cat tmp/rendered/base/crds/*.yaml >tmp/installer/istio/base-all.yaml
cat tmp/rendered/base/templates/*.yaml >>tmp/installer/istio/base-all.yaml
cat tmp/rendered/istiod/templates/*.yaml >tmp/installer/istio/istiod-all.yaml
cat tmp/rendered/gateway/templates/*.yaml >tmp/installer/istio/gateway-all.yaml
rm -rf out
mkdir out

cd tmp
tar czf "../out/installer-knative_v${knative_version}-istio_v${istio_version}.tgz" ./installer
cd -

rm -rf tmp
