import sys
import json
from parser_models import *


if __name__ == '__main__':

    JSON_FILE_PATH: str = "<folder>\\<filename>.json"
    json = json.load(open(JSON_FILE_PATH, "r"))

    for item in json:
        info = BatchInfo()
        info.name = item['name']
        info.cycle_name = item['cycle_name']
        info.job_prefix = item['job_prefix']
        info.multi_stream = item['multi_stream']
        info.order = item['order']
        info.module = item['module']

        info.try_save()

    sys.stdout.flush()
