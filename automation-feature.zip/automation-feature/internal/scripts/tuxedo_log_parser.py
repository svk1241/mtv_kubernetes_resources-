from datetime import datetime
import os
import sys
import json

from sys import argv
from typing import List
from parser_models import RunModel, TuxedoTransactionLogModel

time_format = '%Y-%m-%dT%H:%M:%S.%f+00:00'


class EnvArgs():
    def __init__(self, args: List[str]) -> None:
        self.log_root = args[1] if len(args) > 1 else 'C:\\MTV\\Logs\\performance'
        self.log_folder = os.getenv('LOG_FOLDER', 'C:\\MTV\\Logs\\tuxedo')
        self.environment = os.getenv('ENVIRONMENT', 'm210p10DD')
        self.service = os.getenv('SERVICE', 'tux210rs')
        self.container = os.getenv('CONTAINER', 'tuxedo-backend')
        self.run = os.getenv('TEST_RUN', '')


def compute_elapsed_time(start_time: int, end_time: int) -> int:
    """Computes elapsed time in msec

    :param start_time: start time in ticks
    :param end_time: end time in ticks
    :return: elapsed time in msec
    """
    return 10 * (end_time - start_time)


def to_dict(line: str) -> dict:
    spl = line.split()
    end_time = datetime.utcfromtimestamp(float(f"{spl[4]}.{spl[5]}"))
    dict = {'Context': 'SRV',
            'Date': end_time.strftime(time_format),
            'environment': args.environment,
            'Service': args.service,
            'container': args.container,
            'TransactionId': spl[0][1:5],
            'PID': int(spl[1]),
            'Sdate': int(spl[2]),
            'Stime': int(spl[3]),
            'Edate': int(spl[4]),
            'Etime': int(spl[5]),
            'ElapsedTime': compute_elapsed_time(int(spl[3]), int(spl[5]))}
    return dict


def to_model(dict: dict) -> TuxedoTransactionLogModel:
    log = TuxedoTransactionLogModel()
    log.process_date = dict['Date']
    log.transaction = dict['TransactionId']
    log.elapsed_time = dict['ElapsedTime']
    log.pid = dict['PID']
    log.service = dict['Service']
    log.environment = dict['environment']
    return log


def bulk_insert(logs):
    service = logs[0]['Service']
    run = get_run()
    item = TuxedoTransactionLogModel.select(TuxedoTransactionLogModel.process_date) \
                                    .where(TuxedoTransactionLogModel.service == service) \
                                    .order_by(TuxedoTransactionLogModel.process_date.desc()) \
                                    .get_or_none()

    start = datetime.min if item is None else item.process_date
    print(f"Cutoff date {start}")

    filtered_logs = []
    for log in logs:
        process_date = datetime.strptime(log['Date'], time_format)
        if process_date > start:
            if not run:
                if process_date > run.start_time and process_date < run.end_time:
                    log.with_run(run)
            filtered_logs.append(to_model(log))

    print(f'Filtered logs count {len(filtered_logs)}')
    TuxedoTransactionLogModel.bulk_create(filtered_logs, 5000)


def get_run() -> RunModel:
    if args.run is None:
        return None
    try:
        return RunModel.get_by_id(int(args.run))
    except ValueError:
        return RunModel.get(RunModel.name == args.run)


args = EnvArgs(argv)


if __name__ == '__main__':
    logs = []
    with open(os.path.join(args.log_root, 'stderr')) as f:
        for line in f:
            if line[0] != '@':
                continue
            logs.append(to_dict(line.rstrip()))

    serialized_file = '\n'.join([json.dumps(log) for log in logs])

    if not os.path.exists(args.log_folder):
        os.makedirs(args.log_folder)
    with open(os.path.join(args.log_folder, 'tuxedo.log'), mode='w') as f:
        f.write(serialized_file)

    print(f'Logs count {len(logs)}')
    bulk_insert(logs)

sys.stdout.flush()
