from json.decoder import JSONDecodeError
import os
import json
from requests import auth, Request, Session
from requests.models import Response
from settings import Settings

user, password = str(os.getenv('mtv_grafana_credentials')).split('::')  # pragma: allowlist secret
settings = Settings()


class HttpLokiAdapter:
    """Public class ..."""

    def __init__(self):
        self.init_urls()
        self.session = Session()
        self.auth = auth.HTTPBasicAuth(user, password)

    def init_urls(self):
        self.postfix = 'api/datasources/proxy/1/loki/api/v1'
        self.api = settings.get_test_cfg('loki', 'base_uri', default=settings.cfg('loki', 'base_uri')) + self.postfix
        self.query_range = f'{self.api}/query_range'
        
    def execute(self, url: str, method: str = None, headers=None, data=None, params=None) -> Response:
        request = Request(method=method, url=url, headers=headers, params=params, data=data)
        request.auth = self.auth
        response = self.session.send(request.prepare())
        return response

    def get_query_range(self, selector: str, start: int, end: int, limit: int = 1000) -> list:
        print(f"Loki selector: {selector}")

        logs = []
        params = {'query': selector, 'start': start, 'end': end, 'limit': limit}
        res = self.execute(self.query_range, "GET", params=params)
        print(f"GET request:{res.request.url}")

        json_res = json.loads(res.content.decode())
        print(f"Json items count: {len(json_res['data']['result'])}")

        if not len(json_res['data']['result']):
            return list()

        for result in json_res['data']['result']:
            for value in result['values']:
                try:
                    logs.append(json.loads(value[1]))
                except JSONDecodeError as e:
                    print(f"{value}: {e}")
        return logs

    def get_server_logs(self, namespace: str, start: int, end: int) -> list:
        return self.get_query_range(f'{{container="https-wrapper", namespace="{namespace}"}}|json |LogLevel="Information"', start, end)

    def get_client_logs(self, env: str, host: str, start: int, end: int) -> list:
        filename_filter = settings.cfg('loki', 'filter', 'filename')
        return self.get_query_range(f'{{environment="{env}", server="{host}", filename=~"{filename_filter}"}}|json |LogLevel="Information"', start, end)
