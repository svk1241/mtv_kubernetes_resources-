1. Run db_operations.py in case generating db tables and/or applying changes in indexes. Indexes changes can be applied even tables already have been created
2. python_log_parser.py - parsing python log - Isolated or Concurrency mode
3. jmeter_log_parser.py - parsing jmeter log
4. The following arguments are applicable for parsers:
        self.log_root = args[1] if len(args) > 1 else "C:\\MTV\\Logs\\performance"
        self.app_version = args[2] if len(args) > 2 else '1.0.001'
        self.app_server = args[3] if len(args) > 3 else 'ddmtv-app-001'
        self.db_server = args[4] if len(args) > 4 else 'ddmtv-db-001'
        self.report = args[5] if len(args) > 5 else None
5. Isolated transactions log parser requires mandatory input parameters:
        self.run_id_or_name = args[1]  # int or string: Run id or name, Exmaple 175 or "IsolatedTest::19.20.0.245"
        self.api_host = args[2]  # string: Example "auto-api-002"
        self.be_namespace = args[3]  # string: "online-regression"