from dict_enum import TestStatus, TestType
from parser_models import *


def create_tables():
    AreaTypeModel.create_table()
    TestStatusModel.create_table()
    SettingsModel.create_table()
    RunModel.create_table()
    FunctionalTestingModel.create_table()
    PerformanceResultModel.create_table()
    IsolatedBatchJobResultModel.create_table()
    IsolatedApiResultModel.create_table()
    ExtensionsApiResultModel.create_table()
    ConcurrencyTestingModel.create_table()
    ConcurrencyResultModel.create_table()
    IsolatedTransactionLogModel.create_table()
    TuxedoTransactionLogModel.create_table()
    BatchInfo.create_table()


def add_indexes():
    SettingsModel.add_index(SettingsModel.name, SettingsModel.test_case_id, SettingsModel.area_type, unique=True)
    FunctionalTestingModel.add_index(FunctionalTestingModel.settings, FunctionalTestingModel.log, unique=True)
    PerformanceResultModel.add_index(PerformanceResultModel.functional_testing, PerformanceResultModel.transaction,
                                     unique=True)
    IsolatedBatchJobResultModel.add_index(IsolatedBatchJobResultModel.functional_testing,
                                          IsolatedBatchJobResultModel.name, unique=True)
    IsolatedApiResultModel.add_index(IsolatedApiResultModel.functional_testing, IsolatedApiResultModel.name,
                                     unique=True)
    ExtensionsApiResultModel.add_index(ExtensionsApiResultModel.functional_testing, ExtensionsApiResultModel.name,
                                     unique=True)
    ConcurrencyTestingModel.add_index(ConcurrencyTestingModel.settings, ConcurrencyTestingModel.log, unique=True)
    ConcurrencyResultModel.add_index(ConcurrencyResultModel.concurrency_testing, ConcurrencyResultModel.transaction,
                                     unique=True)
    BatchInfo.add_index(BatchInfo.module, BatchInfo.name)


def populate_guides():
    AreaTypeModel.bulk_create([AreaTypeModel().with_id(TestType.NONE.value).with_area_type('N/A'),
                               AreaTypeModel().with_id(TestType.API.value).with_area_type('External API'),
                               AreaTypeModel().with_id(TestType.GUI.value).with_area_type('GUI'),
                               AreaTypeModel().with_id(TestType.BATCH.value).with_area_type('BATCH'),
                               AreaTypeModel().with_id(TestType.GUI_API.value).with_area_type('GUI-API'),
                               AreaTypeModel().with_id(TestType.EXTENSIONS.value).with_area_type('EXTENSIONS'),
                               AreaTypeModel().with_id(TestType.REAL_EXTENSIONS.value).with_area_type('REAL-EXTENSIONS'),
                               AreaTypeModel().with_id(TestType.DUMMY_EXTENSIONS.value).with_area_type('DUMMY-EXTENSIONS'),
                               AreaTypeModel().with_id(TestType.MOCK_EXTENSIONS.value).with_area_type('MOCK-EXTENSIONS'),
                               AreaTypeModel().with_id(TestType.MQ.value).with_area_type('MQ'),
                               AreaTypeModel().with_id(TestType.BATCH_SMOKE.value).with_area_type('BATCH-SMOKE'),
                               AreaTypeModel().with_id(TestType.BATCH_DITX_DATA.value).with_area_type('BATCH-DITX-DATA')])
    TestStatusModel.bulk_create([TestStatusModel().with_id(TestStatus.NOT_RUN.value).with_test_status('NotRun'),
                                 TestStatusModel().with_id(TestStatus.FAILED.value).with_test_status('Failed'),
                                 TestStatusModel().with_id(TestStatus.PASSED.value).with_test_status('Passed')])


if __name__ == '__main__':
    add_indexes()
    create_tables()
    populate_guides()
