import json
from os import path


class Settings():
    """Public class .."""

    __cfg = {}

    def __init__(self):
        self.__parse()

    @staticmethod
    def set(**kwargs):
        """

        :param **kwargs:
        :type **kwargs:

        """
        Settings.__cfg.update(**kwargs)

    def __parse(self):
        if len(Settings.__cfg) > 0:
            return

        with open('settings.json') as config_file:
            cfg = json.load(config_file)

        Settings.__cfg = cfg

    @staticmethod
    def cfg(*params, default: str = None, throwExceptionIfNotFound: bool = False):
        value = Settings.__cfg
        for param in params:
            if param not in value:
                if throwExceptionIfNotFound:
                    raise ValueError(f"No '{param}' in settings")
                return default
            value = value[param]

        return value

    @staticmethod
    def get_test_cfg(*params, default: str = None, throwExceptionIfNotFound: bool = False):
        return Settings.cfg('test', *params, default=default, throwExceptionIfNotFound=throwExceptionIfNotFound)

    @staticmethod
    def upload_test_settings(folder: str):
        with open(path.join(folder, 'settings.json')) as config_file:
            cfg = json.load(config_file)
            Settings.set(test=cfg)
