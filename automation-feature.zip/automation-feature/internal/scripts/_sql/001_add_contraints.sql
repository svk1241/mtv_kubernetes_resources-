ALTER TABLE auto.settings RENAME COLUMN "type" TO type_id;
ALTER TABLE auto.functional_testing RENAME COLUMN "result" TO result_id;
ALTER TABLE auto.concurrency_testing RENAME COLUMN "result" TO result_id;

ALTER TABLE concurrency_testing
    ADD CONSTRAINT concurrency_testing_result_id_fkey FOREIGN KEY (result_id) REFERENCES dict_test_status (id);

ALTER TABLE functional_testing
    ADD CONSTRAINT functional_testing_result_id_fkey FOREIGN KEY (result_id) REFERENCES dict_test_status (id);

ALTER TABLE settings
    ADD CONSTRAINT settings_type_id_fkey FOREIGN KEY (type_id) REFERENCES dict_area_type (id);
