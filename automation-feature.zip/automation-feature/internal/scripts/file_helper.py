import os


def get_files(folder: str, extension: str):
    files = set()
    for file in os.listdir(folder):
        if file.endswith(extension):
            files.add(os.path.join(folder, file))
    return files


def get_test_files(folder: str, extension: str):
    files = set()
    for file in os.listdir(folder):
        if file.startswith("test_") and file.endswith(extension):
            files.add(os.path.join(folder, file))
    return files


def get_test_sub_folders(root_folder: str):
    folders = set()
    for root, dirs, files in os.walk(root_folder):
        for dir in dirs:
            if dir.startswith("test_"):
                folders.add(os.path.join(root, dir))
    return folders


def get_filename_without_ext(file_path: str):
    name, ext = os.path.splitext(os.path.basename(file_path))
    return name
