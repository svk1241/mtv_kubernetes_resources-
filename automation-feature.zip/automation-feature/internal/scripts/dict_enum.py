from enum import Enum


class TestType(Enum):
    NONE = -1
    API = 0
    GUI = 1
    BATCH = 2
    GUI_API = 3
    EXTENSIONS = 4
    MQ = 5
    BATCH_SMOKE = 6
    BATCH_DITX_DATA = 7
    REAL_EXTENSIONS = 8
    DUMMY_EXTENSIONS = 9
    MOCK_EXTENSIONS = 10

class TranType(Enum):
    API = 0
    BATCH = 1
    EXTENSIONS_SERVICE = 2

class TestStatus(Enum):
    NOT_RUN = -1
    FAILED = 0
    PASSED = 1
