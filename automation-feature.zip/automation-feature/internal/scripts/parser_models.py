import datetime
from operator import index
import os
import socket
from settings import Settings
from peewee import *

hostname = socket.gethostname()


#user, password = str(os.getenv('mtv_postgre_credentials')).split('::')  # pragma: allowlist secret
user = 'postgres'
password = 'Automate@321'
settings = Settings()

db = PostgresqlDatabase(settings.cfg('db', 'name'),
                        host=settings.cfg('db', 'host'),
                        user=user,
                        port=settings.cfg('db', 'port'),
                        password=password)  # pragma: allowlist secret


class BaseModel(Model):
    """A base model that will use our Postgresql database"""
    class Meta:
        schema = 'auto'
        database = db

    created_at = DateTimeField(default=datetime.datetime.now())
    created_by = CharField(default=hostname)

    def try_get_item(self, *expressions):
        try:
            return self.select().where(*expressions).get()
        except DoesNotExist:
            raise

    def try_save(self, *expressions, **kwargs):
        try:
            self.try_get_item(*expressions)
            return False
        except DoesNotExist:
            obj, success = self._internal_save(**kwargs)
            return success

    def _internal_save(self, **kwargs):
        for field, value in kwargs.items():
            setattr(self, field, value)

        self.save(force_insert=True)
        return self, True


class AreaTypeModel(BaseModel):
    class Meta:
        table_name = 'dict_area_type'

    id = IntegerField(primary_key=True)
    name = CharField()

    def with_id(self, id: int):
        self.id = id
        return self

    def with_area_type(self, area_type: str):
        self.name = area_type
        return self


class TestStatusModel(BaseModel):
    class Meta:
        table_name = 'dict_test_status'

    id = IntegerField(primary_key=True)
    status = CharField()

    def with_id(self, id: int):
        self.id = id
        return self

    def with_test_status(self, status: str):
        self.status = status
        return self


class SettingsModel(BaseModel):
    class Meta:
        table_name = 'settings'

    id = PrimaryKeyField()
    name = CharField()
    test_case_id = IntegerField(default=0)
    path = TextField(null=True)
    area_type = ForeignKeyField(AreaTypeModel, field="id", backref='relationships')
    functionality = CharField(null=True)
    module = CharField(null=True)
    tool = SmallIntegerField()

    def with_name(self, name: str):
        self.name = name.strip()
        return self

    def with_area_type(self, type: int):
        self.area_type = type
        return self

    def with_functionality(self, functionality: str):
        self.functionality = functionality
        return self

    def with_module(self, module: str):
        self.module = module
        return self

    def with_agg_item(self, item):
        self.area_type = int(item['test_type'][0])
        self.functionality = item['test_functionality'][0]
        self.module = item['test_module'][0]
        self.test_case_id = int(item['test_case_id'][0])
        return self

    def get_or_save(self, **kwargs):
        try:
            return self.try_get_item(SettingsModel.name == self.name, SettingsModel.area_type == self.area_type, SettingsModel.test_case_id == self.test_case_id)
        except DoesNotExist as de:
            self._internal_save(**kwargs)
            return self


class RunModel(BaseModel):
    class Meta:
        table_name = 'run'

    id = PrimaryKeyField()
    name = CharField()
    description = TextField(null=True)
    start_time = DateTimeField()
    end_time = DateTimeField()
    duration = IntegerField(default=0)
    app_server = CharField()
    db_server = CharField()
    app_version = CharField()
    test_host = CharField(default=hostname)
    report = TextField(null=True)

    def with_env_args(self, args):
        self.app_server = args.app_server
        self.db_server = args.db_server
        self.app_version = args.app_version
        self.report = args.report
        self.name = args.name
        self.description = args.description
        return self

    def with_run_time(self, start_time: datetime.datetime, end_time: datetime.datetime):
        self.start_time = start_time
        self.end_time = end_time
        self.duration = round(1000 * (end_time - start_time).total_seconds())
        return self


class BaseTestingModel(BaseModel):
    id = PrimaryKeyField()
    settings = ForeignKeyField(SettingsModel, field="id", backref='relationships')
    run = ForeignKeyField(RunModel, field="id", backref='relationships')
    test_status = ForeignKeyField(TestStatusModel, field="id", backref='relationships')
    start_time = DateTimeField()
    end_time = DateTimeField()
    duration = IntegerField(default=0)
    log = TextField(unique=True)

    def with_settings(self, settings):
        self.settings = settings
        return self

    def with_run(self, run):
        self.run = run
        return self

    def with_log(self, log: str):
        self.log = log
        return self

    def with_agg_item(self, item):
        self.start_time = item['test_start_time'][0]
        self.end_time = item['test_end_time'][0]
        self.log = item['test_log_file'][0]
        self.test_status = item['test_result'][0]
        self.duration = round(1000 * (self.end_time - self.start_time).total_seconds())

        return self

    def get_or_save(self, **kwargs):
        try:
            return self.try_get_item(self.__class__.settings == self.settings, self.__class__.log == self.log)
        except DoesNotExist:
            self._internal_save(**kwargs)
            return self


class BaseResultModel(BaseModel):
    id = PrimaryKeyField()
    transaction = TextField()
    samples = IntegerField()
    min = IntegerField()
    max = IntegerField()
    avg = IntegerField()
    median = IntegerField()
    quantile_90 = IntegerField(null=True)
    quantile_95 = IntegerField(null=True)
    quantile_99 = IntegerField(null=True)
    std = FloatField()

    def with_agg_item(self, transaction: str, item):
        self.transaction = transaction
        self.samples = item['size']
        self.min = item['amin']
        self.max = item['amax']
        self.avg = item['mean']
        self.median = item['median']
        self.quantile_90 = get_value_or_default(item, 'quantile_90')
        self.quantile_95 = get_value_or_default(item, 'quantile_95')
        self.quantile_99 = get_value_or_default(item, 'quantile_99')
        self.std = item['std']
        return self


class FunctionalTestingModel(BaseTestingModel):
    class Meta:
        table_name = 'functional_testing'


class PerformanceResultModel(BaseResultModel):
    class Meta:
        table_name = 'performance_result'

    functional_testing = ForeignKeyField(FunctionalTestingModel, field="id", backref='relationships')

    def with_functional_testing(self, functional_testing):
        self.functional_testing = functional_testing
        return self

    def try_save(self, **kwargs):
        if self.transaction == 'fake_element':
            return
        return super().try_save(self.__class__.functional_testing == self.functional_testing, self.__class__.transaction == self.transaction, **kwargs)


class BaseIsolatedResultModel(BaseModel):
    id = PrimaryKeyField()
    functional_testing = ForeignKeyField(FunctionalTestingModel, field="id", backref='relationships')
    name = TextField()
    is_code_valid = IntegerField(default=0)
    time_real = IntegerField(default=0)

    def with_functional_testing(self, functional_testing):
        self.functional_testing = functional_testing
        return self

    def try_save(self, **kwargs):
        return super().try_save(self.__class__.functional_testing == self.functional_testing, self.__class__.name == self.name, **kwargs)


class IsolatedBatchJobResultModel(BaseIsolatedResultModel):
    class Meta:
        table_name = 'isolated_batch_job_result'

    return_code = IntegerField(default=-1)
    time_sys = IntegerField(default=0)
    time_user = IntegerField(default=0)


class IsolatedApiResultModel(BaseIsolatedResultModel):
    class Meta:
        table_name = 'isolated_api_result'

    http_code = IntegerField(default=-1)

class ExtensionsApiResultModel(BaseIsolatedResultModel):
    class Meta:
        table_name = 'extensions_api_result'

    http_code = IntegerField(default=-1)

class ConcurrencyTestingModel(BaseTestingModel):
    class Meta:
        table_name = 'concurrency_testing'

    threads = IntegerField(default=1)


class ConcurrencyResultModel(BaseResultModel):
    class Meta:
        table_name = 'concurrency_result'

    concurrency_testing = ForeignKeyField(ConcurrencyTestingModel, field="id", backref='relationships')
    error = FloatField(default=0)
    throughput = FloatField(default=0)

    def with_concurrency_testing(self, concurrency_testing):
        self.concurrency_testing = concurrency_testing
        return self

    def try_save(self, **kwargs):
        if self.transaction == 'fake_element':
            return
        return super().try_save(self.__class__.concurrency_testing == self.concurrency_testing, self.__class__.transaction == self.transaction, **kwargs)


class IsolatedTransactionLogModel(BaseModel):
    class Meta:
        table_name = 'isolated_transaction_log'

    id = PrimaryKeyField()
    functional_testing = ForeignKeyField(FunctionalTestingModel, field="id", backref='relationships')
    process_date = DateTimeField()
    client = CharField()
    request = CharField()
    transaction = TextField()
    client_elapsed_time = IntegerField(default=0)
    server_elapsed_time = IntegerField(default=0)

    def with_functional_testing(self, functional_testing):
        self.functional_testing = functional_testing
        return self

    def try_save(self, **kwargs):
        return super().try_save(self.__class__.functional_testing == self.functional_testing, self.__class__.request == self.request, **kwargs)


class TuxedoTransactionLogModel(BaseModel):
    class Meta:
        table_name = 'tuxedo_transaction_log'

    id = PrimaryKeyField()
    run = ForeignKeyField(RunModel, field="id", backref='relationships', null=True)
    functional_testing = ForeignKeyField(FunctionalTestingModel, field="id", backref='relationships', null=True)
    process_date = DateTimeField(index=True)
    transaction = TextField(index=True)
    elapsed_time = IntegerField()
    pid = IntegerField()
    service = TextField()
    environment = TextField()

    # TODO run_id is going to be added to IsolatedTransactionLogModel also. There are cases when no linked functional_testing
    def with_run(self, run):
        self.run = run
        return self

    def with_functional_testing(self, functional_testing):
        self.functional_testing = functional_testing
        return self


class BatchInfo(BaseModel):
    class Meta:
        table_name = 'batch_info'

    id = PrimaryKeyField()
    name = TextField()
    job_prefix = TextField(index=True)
    cycle_name = TextField(index=True)
    multi_stream = BooleanField()
    order = IntegerField()
    module = TextField()

    def try_save(self, **kwargs):
        return super().try_save(self.__class__.name == self.name, self.__class__.module == self.module, **kwargs)

def get_value_or_default(item, param, default=None):
    return item[param] if param in item else default
