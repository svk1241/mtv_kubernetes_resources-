import sys
import numpy as np
import re
import json
import pandas as pd
from sys import argv
from enum import Enum
from typing import List, Union
from datetime import datetime as dt

from pandas.core.frame import DataFrame

from parser_models import *
from file_helper import *
from dict_enum import TestType, TranType


settings = Settings()


class LevelType(Enum):
    """Type of Performance Logger Level Enum"""
    NONE = 0
    TEST = 10
    INFO = 20
    STAGE = 30
    TRAN = 40
    ACTION = 50


class PointType(Enum):
    """Type of Performance Logger Point Enum"""
    START = 'START'
    END = 'END'
    INFO = 'INFO'
    NONE = ''


class LogItem():

    def __init__(self, row: str):
        tmp = row.split('\t')
        self.timestamp = float(tmp[0])
        self.level = tmp[1]
        self.point = tmp[2]
        self.transaction = tmp[3]


class ElementItem():

    def __init__(self, transaction: str, start_time: Union[float, dt]) -> None:
        self.init_start_data(transaction, start_time)

    def init_start_data(self, transaction: str, start_time: Union[float, dt]):
        self.transaction = transaction
        self.start_time = dt.fromtimestamp(start_time) if isinstance(start_time, float) else start_time
        # TODO Set end date in the future in case no value in the log file. dt.max doesn't work for timestamp()
        self.set_end_time(datetime.datetime(2100, 1, 1).timestamp())
        self.description = ''

    def set_end_time(self, end_time: float):
        self.end_time = dt.fromtimestamp(end_time)
        self._milliseconds = int(1000 * (self.end_time - self.start_time).total_seconds())

    def set_result(self, result: bool):
        self.result = result

    def to_dict(self, **kwargs):
        dct = {'transaction': self.transaction,
               'start_time': self.start_time,
               'end_time': self.end_time,
               'milliseconds': self._milliseconds,
               'description': self._description}

        dct.update(**kwargs)
        return dct

    @property
    def milliseconds(self):
        return self._milliseconds

    @milliseconds.setter
    def milliseconds(self, value):
        self._milliseconds = value

    @property
    def description(self):
        return self._description

    @description.setter
    def description(self, value):
        self._description = value


class TestLog(ElementItem):

    def __init__(self) -> None:
        self.action = []
        self.info = []
        self.case_id = 0
        self.log_file = ''
        self.result = 0
        self.functionality = ''
        self.module = ''
        self.type = TestType.NONE
        self.path = ''
        self.dict_tran = {}

    @property
    def tran(self):
        return list(self.dict_tran.values())

    def items(self) -> List[ElementItem]:
        return self.tran + self.action + self.info

    def parse_test_info(self, full_test_name: str):
        patterns = (r'(test_[_a-z0-9]+)_([0-9]+)$', r'(test_[_a-z0-9]+)$', r'(test_[_a-z0-9]+)\[([0-9]+)')
        tmp = full_test_name.split('::')
        test_name = tmp[-1]
        self.path = full_test_name

        for p in patterns:
            values = re.findall(p, test_name)
            if len(values):
                if len(values[0]) == 2:
                    self.name, self.case_id = values[0]
                    break
                self.name = values[0]
                break

    def to_dict(self, **kwargs):
        dct = {'test_name': self.name,
               'test_start_time': self.start_time,
               'test_end_time': self.end_time,
               'test_type': self.type.value,
               'test_functionality': self.functionality,
               'test_module': self.module,
               'test_case_id': self.case_id,
               'test_log_file': self.log_file,
               'test_result': self.result,
               'test_path': self.path}

        dct.update(**kwargs)
        return dct

    def has_items(self):
        if len(self.action + self.tran + self.info) > 0:
            return True
        else:
            return False

    def add_fake_element_item(self):
        self.dict_tran['fake_element'] = ElementItem('fake_element', 0.0)
        self.dict_tran['fake_element'].set_end_time(0.1)

    def set_test_type(self, val: str):
        if val == 'api':
            self.type = TestType.API
        elif val == 'gui':
            self.type = TestType.GUI
        elif val == 'batch':
            self.type = TestType.BATCH
        elif val == 'gui-api':
            self.type = TestType.GUI_API
        elif val == 'extensions':
            self.type = TestType.EXTENSIONS
        elif val == 'real-extensions':
            self.type = TestType.REAL_EXTENSIONS
        elif val == 'dummy-extensions':
            self.type = TestType.DUMMY_EXTENSIONS
        elif val == 'mock-extensions':
            self.type = TestType.MOCK_EXTENSIONS
        elif val == 'mq':
            self.type = TestType.MQ
        elif val == 'batch-smoke':
            self.type = TestType.BATCH_SMOKE
        elif val == 'batch-ditx-data':
            self.type = TestType.BATCH_DITX_DATA
        else:
            self.type = TestType.NONE


def parse_log(log_file) -> List[TestLog]:
    with open(log_file) as f:
        test_log = TestLog()
        logs = []

        for line in f:
            item = LogItem(line.rstrip())
            if item.level in (LevelType.STAGE.name):
                continue

            if item.level == LevelType.TEST.name:
                if item.point == PointType.START.name:
                    test_log.init_start_data(item.transaction, item.timestamp)
                    test_log.parse_test_info(item.transaction)
                    test_log.log_file = log_file
                elif item.point == PointType.END.name:
                    test_log.set_end_time(item.timestamp)
                    if not test_log.has_items():
                        test_log.add_fake_element_item()
                    logs.append(test_log)
                    test_log = TestLog()
                elif item.point == PointType.INFO.name:
                    test_type, test_log.functionality, test_log.module = item.transaction.split('::')
                    test_log.set_test_type(str(test_type).lower())
                else:
                    if 'MAKE_REPORT PASSED' in item.transaction:
                        test_log.result = int('PASSED:True' in item.transaction)

            if item.level == LevelType.TRAN.name:
                if item.point == PointType.START.name:
                    if item.transaction not in test_log.dict_tran:
                        test_log.dict_tran[item.transaction] = ElementItem(item.transaction, item.timestamp)
                    else:
                        test_log.dict_tran[str(datetime.datetime.now())] = test_log.dict_tran[item.transaction]
                        test_log.dict_tran[item.transaction] = ElementItem(item.transaction, item.timestamp)

                elif item.point == PointType.END.name:
                    test_log.dict_tran[item.transaction].set_end_time(item.timestamp)
                else:
                    raise Exception(f'Invalid PointType "{item.point}": {item.level} - {item.transaction}')

            if item.level == LevelType.ACTION.name:
                if item.point == PointType.START.name:
                    test_log.action.append(ElementItem(item.transaction, item.timestamp))
                elif item.point == PointType.END.name:
                    test_log.action[-1].set_end_time(item.timestamp)
                else:
                    raise Exception(f'Invalid PointType "{item.point}": {item.level} - {item.transaction}')

            if item.level == LevelType.INFO.name:
                info_data = parse_info_data(item.transaction)
                if 'name' not in info_data:
                    print(f"No 'name' key in parsed line '{item.transaction}")
                    continue
                el = ElementItem(info_data['name'], test_log.start_time)
                el.milliseconds = int(info_data['time_real'])
                el.description = item.transaction
                test_log.info.append(el)
    return logs


def parse_info_data(transaction: str) -> dict:
    values = re.findall(info_pattern, transaction)
    if len(values):
        return json.loads(values[0])
    return {}


def quantile_90(x):
    return x.quantile(0.9)


def quantile_95(x):
    return x.quantile(0.95)


def quantile_99(x):
    return x.quantile(0.99)


def aggregate(test_logs: List[TestLog], group_by: list) -> DataFrame:
    lst = []
    for test_log in test_logs:
        items = test_log.items()
        lst = lst + [i.to_dict(**test_log.to_dict()) for i in items]

    return pd.DataFrame(lst).groupby(group_by).agg(
        {'milliseconds': [np.size, np.min, np.max, np.mean, np.median, quantile_90, quantile_95, quantile_99, np.std],
         'test_start_time': np.min,
         'test_end_time': np.max,
         'test_type': np.max,
         'test_functionality': np.max,
         'test_module': np.max,
         'test_case_id': np.max,
         'test_log_file': np.max,
         'test_result': np.min,
         'test_path': np.max,
         'description': np.max})


def parse_logs_in_folder(folder) -> List[TestLog]:
    log_files = get_test_files(folder, '.log')
    print(f"Log files count in folder '{folder}': {len(log_files)}")

    logs = []
    for log_file in log_files:
        for log in parse_log(log_file):
            logs.append(log)
    return logs


def insert_perf_metrics(df: DataFrame, threads: int = 1):
    run = save_run_data(df)
    settings = SettingsModel()
    testing = BaseTestingModel().with_settings(settings)
    for group_by, row in df.fillna(0).iterrows():
        transaction = group_by[-1]
        test_name = group_by[-2]
        settings = get_settings(test_name, row, settings)

        if len(group_by) == 3:
            testing = get_functional_testing(settings, run, row, testing)
            if PerformanceResultModel().with_functional_testing(testing).with_agg_item(transaction, row['milliseconds']).try_save():
                insert_isolated_result(row['description'][0], testing)
        else:
            testing = get_concurrency_testing(settings, run, row, testing, threads)
            ConcurrencyResultModel().with_concurrency_testing(testing).with_agg_item(transaction, row['milliseconds']).try_save()


def get_settings(test_name: str, row, prev_settings: SettingsModel):
    current_settings = SettingsModel().with_name(test_name).with_agg_item(row)
    if current_settings.test_case_id == prev_settings.test_case_id and \
       prev_settings.area_type_id is not None and \
       current_settings.area_type == prev_settings.area_type and \
       current_settings.name == prev_settings.name:
        return prev_settings

    current_settings = current_settings.get_or_save(tool=args.tool)
    try_update_setting(current_settings, row)
    return current_settings


def get_functional_testing(settings: SettingsModel, run: RunModel, row, prev_testing: FunctionalTestingModel):
    current_testing = FunctionalTestingModel().with_settings(settings).with_run(run).with_agg_item(row)
    if current_testing.settings == prev_testing.settings and \
       current_testing.log == prev_testing.log:
        return prev_testing
    return current_testing.get_or_save()


def get_concurrency_testing(settings: SettingsModel, run: RunModel, row, prev_testing: ConcurrencyTestingModel, threads: int):
    current_testing = ConcurrencyTestingModel().with_settings(settings).with_run(run).with_agg_item(row)
    if current_testing.settings == prev_testing.settings and \
       current_testing.log == prev_testing.log:
        return prev_testing
    return current_testing.get_or_save(threads=threads)


def try_update_setting(settings: SettingsModel, row):
    if settings.path is None and row['test_path'][0] is not None:
        settings.path = row['test_path'][0]
        settings.save()

    if settings.path != row['test_path'][0]:
        print(f'Settings {settings.id} has incorrect path: '
              f'{settings.path} => {row["test_path"][0]}')
        print(f"update {BaseModel._meta.schema}.{SettingsModel._meta.table_name} "
              f"set path = \'{row['test_path'][0]}\' "
              f"where id = {settings.id}")

    if settings.functionality != row['test_functionality'][0] or settings.module != row['test_module'][0]:
        print(f'Settings {settings.id} has incorrect functionality or model: '
              f'{settings.functionality} => {row["test_functionality"][0]}; '
              f'{settings.module} => {row["test_module"][0]}')
        print(f"update {BaseModel._meta.schema}.{SettingsModel._meta.table_name} "
              f"set functionality = \'{row['test_functionality'][0]}\', \"module\" = '{row['test_module'][0]}' "
              f"where id = {settings.id}")


def insert_isolated_result(description: str, testing: FunctionalTestingModel):
    info_data = parse_info_data(description)
    if "type" in info_data:
        if info_data["type"] == TranType.BATCH.name.lower():
            IsolatedBatchJobResultModel().with_functional_testing(testing).try_save(**info_data)
        elif info_data["type"] == TranType.API.name.lower():
            IsolatedApiResultModel().with_functional_testing(testing).try_save(**info_data)
        elif info_data["type"] == TranType.EXTENSIONS_SERVICE.name.lower():
            ExtensionsApiResultModel().with_functional_testing(testing).try_save(**info_data)
        else:
            print(f"Invalid type '{info_data['type']}' in description: {description}")


def process_logs_and_insert_data(folder: str, concurrency_run: bool):
    group_by = ['test_name', 'transaction'] if concurrency_run else ['test_start_time', 'test_name', 'transaction']

    logs = parse_logs_in_folder(folder)
    if len(logs):
        print(f"Logs count in root folder '{folder}': {len(logs)}")
        df = aggregate(logs, group_by)
        insert_perf_metrics(df)
    else:
        print(f"No logs in folder '{folder}'")


def save_run_data(df: DataFrame):
    run_start_time = df['test_start_time'].min()[0]
    run_end_time = df['test_end_time'].max()[0]
    run = RunModel().with_env_args(args).with_run_time(run_start_time, run_end_time)
    run.save()
    return run


def update_args():
    settings.upload_test_settings(args.log_root)
    args.app_server = settings.get_test_cfg('backend', 'server', default=args.app_server)
    args.db_server = settings.get_test_cfg('db', 'dsn', default=args.db_server)


class EnvArgs():
    def __init__(self, args: List[str]) -> None:
        self.app_version = os.getenv('APP_VERSION', '1.0.001')
        self.app_server = os.getenv('APP_SERVER', 'uschsmvcx115')
        self.db_server = os.getenv('DB_SERVER', 'uschsmvcx115')

        self.log_root = args[1] if len(args) > 1 else "C:\\MTV\\Logs\\performance"
        self.report = args[2] if len(args) > 2 else "no_data"
        self.name = args[3] if len(args) > 3 else self.app_version
        self.description = args[4] if len(args) > 4 else None
        self.tool = 0  # (0 - python, 1 - JMeter)


args = EnvArgs(argv)
info_pattern = re.compile(r"(\{.*\})")

if __name__ == '__main__':
    update_args()
    process_logs_and_insert_data(args.log_root, False)
    folders = get_test_sub_folders(args.log_root)
    for folder in folders:
        process_logs_and_insert_data(folder, True)

    sys.stdout.flush()
