import re
import sys
import json

from sys import argv
from typing import List
from http_loki_adapter import HttpLokiAdapter
from parser_models import *
from dateutil import tz

DEFAULT_ELAPSED_TIME: int = 0
PROCESS_SPLIT_PERIOD: int = 5 * 60 * 1e+9  # split run period by 5 min
adapter = HttpLokiAdapter()
settings = Settings()


class EnvArgs():
    def __init__(self, args: List[str]) -> None:
        self.log_root = args[1] if len(args) > 1 else "C:\\MTV\\Logs\\performance"
        self.run_id_or_name = args[2] if len(args) > 2 else 1  # int or string: Run id or name, Exmaple 175 or "IsolatedTest::19.20.0.245"
        self.api_host = ''
        self.be_namespace = ''
        self.env = ''


def get_local_timestamp_ns(dt: datetime.datetime):
    return round(1e+9 * dt.replace(tzinfo=tz.UTC).astimezone(tz.tzlocal()).timestamp())


def get_timestamp_ns(dt: datetime.datetime):
    return round(1e+9 * dt.timestamp())


def get_elapsed_time(log: dict) -> int:
    """Returns elapsed time in msec

    :param string: log data with ElapsedMs key
    :return: time in msec
    """
    try:
        return int(log['ElapsedMs'])
    except:
        return DEFAULT_ELAPSED_TIME


def get_cli_log_elapsed_time(srv: list, request_id: str):
    for log in srv:
        if log['RequestId'] == request_id:
            return get_elapsed_time(log)
    return DEFAULT_ELAPSED_TIME


def get_run(arg) -> RunModel:
    try:
        return RunModel.get_by_id(int(arg))
    except ValueError:
        return RunModel.get(RunModel.name == arg)


def update_args():
    settings.upload_test_settings(args.log_root)
    adapter.init_urls()
    args.api_host = settings.cfg('test', 'api', 'server', default='auto-api-002')
    args.be_namespace = settings.cfg('test', 'loki', 'online_namespace', default='online-regression')
    args.env = settings.cfg('test', 'loki', 'environment', default='regression')


args = EnvArgs(argv)

if __name__ == '__main__':
    update_args()
    run = get_run(args.run_id_or_name)
    run_start = get_timestamp_ns(run.start_time)
    run_end = get_timestamp_ns(run.end_time)
    start = run_start
    end = start

    settings = SettingsModel()
    api_cases_count = settings.select().join(FunctionalTestingModel)\
        .where((FunctionalTestingModel.run_id == run.id) & (SettingsModel.area_type == 0)).count()
    client_cases_count = settings.select().join(FunctionalTestingModel)\
        .where((FunctionalTestingModel.run_id == run.id) & (SettingsModel.area_type << [1,2,3,4,5,6,8])).count()
    is_api_cases = True if api_cases_count != 0 else False
    is_client_cases = True if client_cases_count != 0 else False
    is_api_logs_found = False
    is_client_logs_found = False
    is_server_logs_found = False

    while end != run_end:
        if start + PROCESS_SPLIT_PERIOD < run_end:
            end = round(start + PROCESS_SPLIT_PERIOD)
        else:
            end = run_end

        srv = adapter.get_server_logs(args.be_namespace, start, end)
        if not is_server_logs_found and len(srv):
            is_server_logs_found = True
        client_logs = adapter.get_client_logs(args.env, run.test_host, start, end)
        if not is_client_logs_found and len(client_logs):
            is_client_logs_found = True
        client_api_logs = adapter.get_client_logs(args.env, args.api_host, start, end)
        if not is_api_logs_found and len(client_api_logs):
            is_api_logs_found = True
        cli = client_logs + client_api_logs

        for log in srv:
            try:
                testing = FunctionalTestingModel.get(FunctionalTestingModel.run == run, FunctionalTestingModel.start_time < log['Date'], FunctionalTestingModel.end_time > log['Date'])
            except DoesNotExist:
                print(f'No testing instance found for log: {json.dumps(log)}')
                continue

            tranLog = IsolatedTransactionLogModel()
            tranLog.client = log['ClientId']
            tranLog.request = log['RequestId']
            tranLog.transaction = log['TransactionId']
            tranLog.process_date = log['Date']
            tranLog.client_elapsed_time = get_cli_log_elapsed_time(cli, log['RequestId'])
            tranLog.server_elapsed_time = get_elapsed_time(log)
            tranLog.with_functional_testing(testing).try_save()

        start = end
    if not is_server_logs_found:
        raise Exception('!!! **** NO SERVER TRAN LOGS *** !!!')
    if is_client_cases and not is_client_logs_found:
        raise Exception('!!! **** NO CLIENT TRAN LOGS *** !!!')
    if is_api_cases and not is_api_logs_found:
        raise Exception('!!! **** NO CLIENT API TRAN LOGS *** !!!')

sys.stdout.flush()
