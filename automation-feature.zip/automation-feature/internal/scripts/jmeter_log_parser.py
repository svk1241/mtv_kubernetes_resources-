from sys import argv
import csv
import re
import subprocess
from parser_models import *
from file_helper import *
from python_log_parser import *


class TestInfo():
    def __init__(self, start_time: int, end_time: int, threads: int, log_path: str) -> None:
        """Initializes TestInfo object

        :param start_time: test start time
        :param end_time: test end time
        :param log_path: path to test log
        """
        self.threads = threads
        self.start_time = TestInfo.__to_datetime(start_time)
        self.end_time = TestInfo.__to_datetime(end_time)
        self.log_path = log_path
        self.name = get_filename_without_ext(log_path)

    @staticmethod
    def __to_datetime(val: int):
        return datetime.datetime.fromtimestamp(val / 1000)


def csv_to_dict(file):
    reader = csv.DictReader(open(file, 'r'))
    dict_list = []
    for line in reader:
        dict_list.append(line)
    return dict_list


def process(test_info: TestInfo, dct: dict):
    run = save_run_data(test_info)
    uid = round(datetime.datetime.now().timestamp())
    settings = SettingsModel().with_name(test_info.name).with_area_type(TestType.API.value).get_or_save(tool=args.tool)
    testing = ConcurrencyTestingModel().with_settings(settings).with_run(run).with_log(f"{test_info.log_path}-{uid}").get_or_save(
        start_time=test_info.start_time,
        end_time=test_info.end_time,
        threads=test_info.threads,
        test_status_id=1)

    err = 0
    for item in dct:
        item = map_item(item)
        ConcurrencyResultModel().with_concurrency_testing(testing).with_agg_item(item['transaction'], item).try_save(
            error=item['error'],
            throughput=item['throughput'])
        err = err + item['error']
    if err > 0:
        testing.test_status_id = 0
        testing.save()


def map_item(item: dict):
    """Maps serialized jmeter log to peewee suitable format

    :param item: serialized jmeter log item
    :return: peewee suitable item
    """
    item['transaction'] = item.pop('Label')
    item['size'] = item.pop('# Samples')
    item['amin'] = item.pop('Min')
    item['amax'] = item.pop('Max')
    item['mean'] = item.pop('Average')
    item['median'] = item.pop('Median')
    item['quantile_90'] = item.pop(r'90% Line')
    item['quantile_95'] = item.pop(r'95% Line')
    item['quantile_99'] = item.pop(r'99% Line')
    item['error'] = float(item.pop(f'Error %').replace('%', ''))
    item['throughput'] = item.pop('Throughput')
    item['std'] = item.pop('Std. Dev.')

    return item


def get_test_param(log_path: str):
    log_file = str(log_path).replace('.jtl', '.log')
    starting_pattern = re.compile(r'Starting standalone test (.*) \(([\d]+)\)')
    ending_pattern = re.compile(r'Tidying up (.*) \(([0-9]+)\)$')
    threads_pattern = re.compile(r'Active: ([\d]+) Started: [\d]+ Finished: [\d]+')

    threads = 0
    start_time = 0
    end_time = 0
    with open(log_file) as f:
        for line in f:
            matched = re.search(threads_pattern, line)
            if matched is not None:
                if threads < int(matched[1]):
                    threads = int(matched[1])
                continue

            matched = re.search(starting_pattern, line)
            if matched is not None:
                start_time = int(matched[2])
                continue

            matched = re.search(ending_pattern, line)
            if matched is not None:
                end_time = int(matched[2])
                continue
    return TestInfo(start_time, end_time, threads, log_path)


def save_run_data(testInfo: TestInfo):
    run = RunModel().with_env_args(args).with_run_time(testInfo.start_time, testInfo.end_time)
    run.save()
    return run


args = EnvArgs(argv)
args.tool = 1

if __name__ == '__main__':
    logs = get_files(args.log_root, '.jtl')
    print(f'Logs count = {len(logs)}')
    for jtl_file in logs:
        file_name = get_filename_without_ext(jtl_file)
        csv_file = str(jtl_file).replace('.jtl', '.csv')
        subprocess.run(f'JMeterPluginsCMD.bat --generate-csv {csv_file} --input-jtl {jtl_file} --plugin-type AggregateReport')
        dct = csv_to_dict(csv_file)
        test_info = get_test_param(jtl_file)
        process(test_info, dct)
    sys.stdout.flush()
