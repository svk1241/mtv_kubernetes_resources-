
Set-Alias -Name sed -Value "C:\Program Files\Git\usr\bin\sed.exe"

Write-Host 'Clean docs folder...'
Set-Location ./docs
Remove-Item -Recurse -path ./*

Write-Host 'Generating config files...'
sphinx-quickstart -p Automation -a Luxoft --ext-autodoc -q

Write-Host  'Updating config files...'
Copy-Item "../internal/ci/sphinx_conf.py" -Destination "./conf.py"
Remove-Item -Recurse -path ./_static/
Remove-Item -Recurse -path ./_templates/
sed -i '13,13 s/^/   modules/g' ./index.rst
sed -i 's/_build/build_html/g' ./Makefile
sed -i 's/_build/build_html/g' ./make.bat

Write-Host 'Generating .rst files...'
sphinx-apidoc -o . ../src
sed -i '/Module contents/,+7 d' ./*.rst
sed -i '/:show-inheritance:/d' ./*.rst
sed -i '/Subpackages/,+1 d' ./*.rst
sed -i '/Submodules/,+1 d' ./*.rst

Write-Host 'Generating html files....'
./make.bat html

Write-Host  'Deleting doctree files...'
Remove-Item -Recurse -path ./build_html/doctrees/

Set-Location ..\