automation.api.adapter package
==============================


automation.api.adapter.application\_security\_adapter module
------------------------------------------------------------

.. automodule:: automation.api.adapter.application_security_adapter
   :members:
   :undoc-members:

automation.api.adapter.benefits\_adapter module
-----------------------------------------------

.. automodule:: automation.api.adapter.benefits_adapter
   :members:
   :undoc-members:

automation.api.adapter.billing\_accounts\_receivable\_adapter module
--------------------------------------------------------------------

.. automodule:: automation.api.adapter.billing_accounts_receivable_adapter
   :members:
   :undoc-members:

automation.api.adapter.claims\_adjudication\_adapter module
-----------------------------------------------------------

.. automodule:: automation.api.adapter.claims_adjudication_adapter
   :members:
   :undoc-members:

automation.api.adapter.coordination\_of\_benefits\_adapter module
-----------------------------------------------------------------

.. automodule:: automation.api.adapter.coordination_of_benefits_adapter
   :members:
   :undoc-members:

automation.api.adapter.correspondence\_generator\_adapter module
----------------------------------------------------------------

.. automodule:: automation.api.adapter.correspondence_generator_adapter
   :members:
   :undoc-members:

automation.api.adapter.http\_adapter module
-------------------------------------------

.. automodule:: automation.api.adapter.http_adapter
   :members:
   :undoc-members:

automation.api.adapter.http\_request module
-------------------------------------------

.. automodule:: automation.api.adapter.http_request
   :members:
   :undoc-members:

automation.api.adapter.membership\_adapter module
-------------------------------------------------

.. automodule:: automation.api.adapter.membership_adapter
   :members:
   :undoc-members:

automation.api.adapter.membership\_structures\_adapter module
-------------------------------------------------------------

.. automodule:: automation.api.adapter.membership_structures_adapter
   :members:
   :undoc-members:

automation.api.adapter.payment\_adapter module
----------------------------------------------

.. automodule:: automation.api.adapter.payment_adapter
   :members:
   :undoc-members:

automation.api.adapter.person\_adapter module
---------------------------------------------

.. automodule:: automation.api.adapter.person_adapter
   :members:
   :undoc-members:

automation.api.adapter.practice\_location\_adapter module
---------------------------------------------------------

.. automodule:: automation.api.adapter.practice_location_adapter
   :members:
   :undoc-members:

automation.api.adapter.pricing\_management\_adapter module
----------------------------------------------------------

.. automodule:: automation.api.adapter.pricing_management_adapter
   :members:
   :undoc-members:

automation.api.adapter.provider\_adapter module
-----------------------------------------------

.. automodule:: automation.api.adapter.provider_adapter
   :members:
   :undoc-members:

automation.api.adapter.provider\_contract\_adapter module
---------------------------------------------------------

.. automodule:: automation.api.adapter.provider_contract_adapter
   :members:
   :undoc-members:

automation.api.adapter.reference\_controls\_adapter module
----------------------------------------------------------

.. automodule:: automation.api.adapter.reference_controls_adapter
   :members:
   :undoc-members:

