tests.gui.research package
==========================


tests.gui.research.test\_research\_menu module
----------------------------------------------

.. automodule:: tests.gui.research.test_research_menu
   :members:
   :undoc-members:

