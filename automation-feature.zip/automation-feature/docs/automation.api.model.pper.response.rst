automation.api.model.pper.response package
==========================================


automation.api.model.pper.response.pper1ar5\_person\_read\_t\_response module
-----------------------------------------------------------------------------

.. automodule:: automation.api.model.pper.response.pper1ar5_person_read_t_response
   :members:
   :undoc-members:

automation.api.model.pper.response.pper1ar6\_person\_read\_t\_response module
-----------------------------------------------------------------------------

.. automodule:: automation.api.model.pper.response.pper1ar6_person_read_t_response
   :members:
   :undoc-members:

automation.api.model.pper.response.pper1bs1\_psn\_contact\_info\_list\_t\_response module
-----------------------------------------------------------------------------------------

.. automodule:: automation.api.model.pper.response.pper1bs1_psn_contact_info_list_t_response
   :members:
   :undoc-members:

automation.api.model.pper.response.pper1bu4\_maint\_person\_addr\_t\_response module
------------------------------------------------------------------------------------

.. automodule:: automation.api.model.pper.response.pper1bu4_maint_person_addr_t_response
   :members:
   :undoc-members:

automation.api.model.pper.response.pper1py1\_addr\_phn\_eml\_maint\_t\_response module
--------------------------------------------------------------------------------------

.. automodule:: automation.api.model.pper.response.pper1py1_addr_phn_eml_maint_t_response
   :members:
   :undoc-members:

