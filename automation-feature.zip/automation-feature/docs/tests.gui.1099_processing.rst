tests.gui.1099\_processing package
==================================


tests.gui.1099\_processing.test\_deducation\_configuration\_maintenance module
------------------------------------------------------------------------------

.. automodule:: tests.gui.1099_processing.test_deducation_configuration_maintenance
   :members:
   :undoc-members:

tests.gui.1099\_processing.test\_list\_payment\_deductions module
-----------------------------------------------------------------

.. automodule:: tests.gui.1099_processing.test_list_payment_deductions
   :members:
   :undoc-members:

tests.gui.1099\_processing.test\_tax\_identifiers module
--------------------------------------------------------

.. automodule:: tests.gui.1099_processing.test_tax_identifiers
   :members:
   :undoc-members:

