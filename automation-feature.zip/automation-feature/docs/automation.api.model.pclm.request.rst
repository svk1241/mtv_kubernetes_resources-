automation.api.model.pclm.request package
=========================================


automation.api.model.pclm.request.pclm1al7\_claims\_list\_t\_request module
---------------------------------------------------------------------------

.. automodule:: automation.api.model.pclm.request.pclm1al7_claims_list_t_request
   :members:
   :undoc-members:

automation.api.model.pclm.request.pclm1ar5\_claim\_read\_t\_request module
--------------------------------------------------------------------------

.. automodule:: automation.api.model.pclm.request.pclm1ar5_claim_read_t_request
   :members:
   :undoc-members:

