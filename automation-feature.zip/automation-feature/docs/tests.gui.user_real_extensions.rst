tests.gui.user\_real\_extensions package
========================================


tests.gui.user\_real\_extensions.conftest module
------------------------------------------------

.. automodule:: tests.gui.user_real_extensions.conftest
   :members:
   :undoc-members:

tests.gui.user\_real\_extensions.test\_cas\_bundle\_unbundle\_online module
---------------------------------------------------------------------------

.. automodule:: tests.gui.user_real_extensions.test_cas_bundle_unbundle_online
   :members:
   :undoc-members:

tests.gui.user\_real\_extensions.test\_external\_pricing\_online module
-----------------------------------------------------------------------

.. automodule:: tests.gui.user_real_extensions.test_external_pricing_online
   :members:
   :undoc-members:

tests.gui.user\_real\_extensions.test\_incentive\_level\_online module
----------------------------------------------------------------------

.. automodule:: tests.gui.user_real_extensions.test_incentive_level_online
   :members:
   :undoc-members:

tests.gui.user\_real\_extensions.test\_manual\_override\_process module
-----------------------------------------------------------------------

.. automodule:: tests.gui.user_real_extensions.test_manual_override_process
   :members:
   :undoc-members:

tests.gui.user\_real\_extensions.test\_mg\_code module
------------------------------------------------------

.. automodule:: tests.gui.user_real_extensions.test_mg_code
   :members:
   :undoc-members:

