tests.api.pper package
======================


tests.api.pper.test\_pper1ar5\_person\_read\_t module
-----------------------------------------------------

.. automodule:: tests.api.pper.test_pper1ar5_person_read_t
   :members:
   :undoc-members:

tests.api.pper.test\_pper1ar6\_person\_read\_t module
-----------------------------------------------------

.. automodule:: tests.api.pper.test_pper1ar6_person_read_t
   :members:
   :undoc-members:

tests.api.pper.test\_pper1bs1\_psn\_contact\_info\_list\_t module
-----------------------------------------------------------------

.. automodule:: tests.api.pper.test_pper1bs1_psn_contact_info_list_t
   :members:
   :undoc-members:

tests.api.pper.test\_pper1bu4\_maint\_person\_addr\_t module
------------------------------------------------------------

.. automodule:: tests.api.pper.test_pper1bu4_maint_person_addr_t
   :members:
   :undoc-members:

tests.api.pper.test\_pper1py1\_addr\_phn\_eml\_maint\_t module
--------------------------------------------------------------

.. automodule:: tests.api.pper.test_pper1py1_addr_phn_eml_maint_t
   :members:
   :undoc-members:

