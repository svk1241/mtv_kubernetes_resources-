automation.api.model.pref package
=================================


.. toctree::
   :maxdepth: 4

   automation.api.model.pref.request
   automation.api.model.pref.response

