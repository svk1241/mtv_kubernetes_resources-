automation.api.model.pclm.response package
==========================================


automation.api.model.pclm.response.pclm1al7\_claims\_list\_t\_response module
-----------------------------------------------------------------------------

.. automodule:: automation.api.model.pclm.response.pclm1al7_claims_list_t_response
   :members:
   :undoc-members:

automation.api.model.pclm.response.pclm1ar5\_claim\_read\_t\_response module
----------------------------------------------------------------------------

.. automodule:: automation.api.model.pclm.response.pclm1ar5_claim_read_t_response
   :members:
   :undoc-members:

