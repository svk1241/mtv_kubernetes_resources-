tests.gui.main\_screen package
==============================


tests.gui.main\_screen.test\_main\_screen module
------------------------------------------------

.. automodule:: tests.gui.main_screen.test_main_screen
   :members:
   :undoc-members:

