automation.api.model.pref.response package
==========================================


automation.api.model.pref.response.pref1bs2\_list\_code\_values\_t\_response module
-----------------------------------------------------------------------------------

.. automodule:: automation.api.model.pref.response.pref1bs2_list_code_values_t_response
   :members:
   :undoc-members:

automation.api.model.pref.response.pref1bs3\_list\_code\_values\_t\_response module
-----------------------------------------------------------------------------------

.. automodule:: automation.api.model.pref.response.pref1bs3_list_code_values_t_response
   :members:
   :undoc-members:

automation.api.model.pref.response.pref1dl2\_list\_codeval\_keyword\_t\_response module
---------------------------------------------------------------------------------------

.. automodule:: automation.api.model.pref.response.pref1dl2_list_codeval_keyword_t_response
   :members:
   :undoc-members:

automation.api.model.pref.response.pref1hl6\_list\_contacts\_t\_response module
-------------------------------------------------------------------------------

.. automodule:: automation.api.model.pref.response.pref1hl6_list_contacts_t_response
   :members:
   :undoc-members:

automation.api.model.pref.response.pref1im2\_list\_address\_t\_response module
------------------------------------------------------------------------------

.. automodule:: automation.api.model.pref.response.pref1im2_list_address_t_response
   :members:
   :undoc-members:

