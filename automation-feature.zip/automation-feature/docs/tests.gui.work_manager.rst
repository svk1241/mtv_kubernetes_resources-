tests.gui.work\_manager package
===============================


tests.gui.work\_manager.test\_work\_manager module
--------------------------------------------------

.. automodule:: tests.gui.work_manager.test_work_manager
   :members:
   :undoc-members:

