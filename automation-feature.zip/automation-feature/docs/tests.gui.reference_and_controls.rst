tests.gui.reference\_and\_controls package
==========================================


tests.gui.reference\_and\_controls.fixtures module
--------------------------------------------------

.. automodule:: tests.gui.reference_and_controls.fixtures
   :members:
   :undoc-members:

tests.gui.reference\_and\_controls.test\_reference\_codes module
----------------------------------------------------------------

.. automodule:: tests.gui.reference_and_controls.test_reference_codes
   :members:
   :undoc-members:

