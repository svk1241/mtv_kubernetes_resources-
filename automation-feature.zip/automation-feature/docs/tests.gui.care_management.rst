tests.gui.care\_management package
==================================


tests.gui.care\_management.test\_external\_criteria module
----------------------------------------------------------

.. automodule:: tests.gui.care_management.test_external_criteria
   :members:
   :undoc-members:

tests.gui.care\_management.test\_list\_remark module
----------------------------------------------------

.. automodule:: tests.gui.care_management.test_list_remark
   :members:
   :undoc-members:

tests.gui.care\_management.test\_work\_manager\_criteria module
---------------------------------------------------------------

.. automodule:: tests.gui.care_management.test_work_manager_criteria
   :members:
   :undoc-members:

