tests.api.pref package
======================


tests.api.pref.test\_pref1bs2\_list\_code\_values\_t module
-----------------------------------------------------------

.. automodule:: tests.api.pref.test_pref1bs2_list_code_values_t
   :members:
   :undoc-members:

tests.api.pref.test\_pref1bs3\_list\_code\_values\_t module
-----------------------------------------------------------

.. automodule:: tests.api.pref.test_pref1bs3_list_code_values_t
   :members:
   :undoc-members:

tests.api.pref.test\_pref1dl2\_list\_codeval\_keyword\_t module
---------------------------------------------------------------

.. automodule:: tests.api.pref.test_pref1dl2_list_codeval_keyword_t
   :members:
   :undoc-members:

tests.api.pref.test\_pref1hl6\_list\_contacts\_t module
-------------------------------------------------------

.. automodule:: tests.api.pref.test_pref1hl6_list_contacts_t
   :members:
   :undoc-members:

tests.api.pref.test\_pref1im2\_list\_address\_t module
------------------------------------------------------

.. automodule:: tests.api.pref.test_pref1im2_list_address_t
   :members:
   :undoc-members:

