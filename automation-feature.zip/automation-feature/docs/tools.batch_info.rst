tools.batch\_info package
=========================


tools.batch\_info.test\_batch\_props module
-------------------------------------------

.. automodule:: tools.batch_info.test_batch_props
   :members:
   :undoc-members:

