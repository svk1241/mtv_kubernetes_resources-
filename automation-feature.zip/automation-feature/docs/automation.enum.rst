automation.enum package
=======================


automation.enum.screenshot\_level module
----------------------------------------

.. automodule:: automation.enum.screenshot_level
   :members:
   :undoc-members:

automation.enum.transactions module
-----------------------------------

.. automodule:: automation.enum.transactions
   :members:
   :undoc-members:

