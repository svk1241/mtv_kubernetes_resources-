tests.batch.user\_real\_extensions package
==========================================


tests.batch.user\_real\_extensions.conftest module
--------------------------------------------------

.. automodule:: tests.batch.user_real_extensions.conftest
   :members:
   :undoc-members:

tests.batch.user\_real\_extensions.test\_cas\_bundle\_unbundle\_batch module
----------------------------------------------------------------------------

.. automodule:: tests.batch.user_real_extensions.test_cas_bundle_unbundle_batch
   :members:
   :undoc-members:

tests.batch.user\_real\_extensions.test\_external\_pricing\_claim module
------------------------------------------------------------------------

.. automodule:: tests.batch.user_real_extensions.test_external_pricing_claim
   :members:
   :undoc-members:

tests.batch.user\_real\_extensions.test\_incentive\_level\_batch module
-----------------------------------------------------------------------

.. automodule:: tests.batch.user_real_extensions.test_incentive_level_batch
   :members:
   :undoc-members:

tests.batch.user\_real\_extensions.test\_mg\_code module
--------------------------------------------------------

.. automodule:: tests.batch.user_real_extensions.test_mg_code
   :members:
   :undoc-members:

