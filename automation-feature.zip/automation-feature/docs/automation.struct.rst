automation.struct package
=========================


automation.struct.authorization module
--------------------------------------

.. automodule:: automation.struct.authorization
   :members:
   :undoc-members:

