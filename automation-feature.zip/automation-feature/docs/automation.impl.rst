automation.impl package
=======================


automation.impl.custom\_exception module
----------------------------------------

.. automodule:: automation.impl.custom_exception
   :members:
   :undoc-members:

automation.impl.performance\_logger module
------------------------------------------

.. automodule:: automation.impl.performance_logger
   :members:
   :undoc-members:

automation.impl.singleton module
--------------------------------

.. automodule:: automation.impl.singleton
   :members:
   :undoc-members:

automation.impl.soft\_assertion module
--------------------------------------

.. automodule:: automation.impl.soft_assertion
   :members:
   :undoc-members:

