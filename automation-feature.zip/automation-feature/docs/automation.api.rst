automation.api package
======================


.. toctree::
   :maxdepth: 4

   automation.api.adapter
   automation.api.model

