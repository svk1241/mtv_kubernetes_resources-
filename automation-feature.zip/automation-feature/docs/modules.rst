src
===

.. toctree::
   :maxdepth: 4

   automation
   conftest
   test_preconditions
   tests
   tests_ditx_data
   tools
