automation.parser package
=========================


.. toctree::
   :maxdepth: 4

   automation.parser.impl


automation.parser.html\_parser module
-------------------------------------

.. automodule:: automation.parser.html_parser
   :members:
   :undoc-members:

automation.parser.txt\_parser module
------------------------------------

.. automodule:: automation.parser.txt_parser
   :members:
   :undoc-members:

automation.parser.txt\_record\_field module
-------------------------------------------

.. automodule:: automation.parser.txt_record_field
   :members:
   :undoc-members:

