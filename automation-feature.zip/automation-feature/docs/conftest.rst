conftest module
===============

.. automodule:: conftest
   :members:
   :undoc-members:
