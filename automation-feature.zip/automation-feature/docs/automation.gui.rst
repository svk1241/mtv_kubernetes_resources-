automation.gui package
======================


.. toctree::
   :maxdepth: 4

   automation.gui.common
   automation.gui.po

