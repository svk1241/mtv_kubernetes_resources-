tests.gui.customer\_service package
===================================


tests.gui.customer\_service.test\_list\_contacts module
-------------------------------------------------------

.. automodule:: tests.gui.customer_service.test_list_contacts
   :members:
   :undoc-members:

