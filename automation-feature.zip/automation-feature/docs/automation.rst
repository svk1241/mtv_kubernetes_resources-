automation package
==================


.. toctree::
   :maxdepth: 4

   automation.api
   automation.enum
   automation.gui
   automation.helper
   automation.impl
   automation.parser
   automation.struct
   automation.test_common
   automation.unit_tests
   automation.util


automation.settings module
--------------------------

.. automodule:: automation.settings
   :members:
   :undoc-members:

automation.test\_data module
----------------------------

.. automodule:: automation.test_data
   :members:
   :undoc-members:

