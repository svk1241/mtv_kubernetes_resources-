export MTV_INIT_SCRIPT=mtv-batch-init.sh

for job in "$@"
do
    time /opt/MTV/m210/common/$job.cmd DEFAULT /opt/MTV/m210/batch/
done