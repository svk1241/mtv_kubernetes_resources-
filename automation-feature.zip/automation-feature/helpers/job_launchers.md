# Job Launchers

## Contents

* [Summary](#a-summary)
  * [Summary Table](#a-summary-table)
  * [Table Description](#a-table-description)
  * [POSIX tools description](#a-posix-tools-description)
    * [nohup(1p)](#a-posix-nohup-1p)
    * [time(1p)](#a-posix-time-1p)
* [Details](#a-details)
  * [run_job_test.sh](#a-run_job_test)
  * [run_job_test_nohup.sh](#a-run_job_test_nohup)


## <a id="a-summary" name="a-summary"></a> Summary

### <a id="a-summary-table" name="a-summary-table"></a> Summary Table

| Launcher              | CLI arguments       | `nohup` | `time(1p)` | fg / bg | Location | Database | Job StdOut target | Job StdErr target |
|-----------------------|---------------------|---------|------------|---------|----------|----------|-------------------|-------------------|
| run_job_test.sh       | job1[, job2[, ...]] | No      | Yes        | fg      | Any      | DEFAULT  | Console           | Console           |
| run_job_test_nohup.sh | job1[, job2[, ...]] | Yes     | Yes        | bg      | Any      | DEFAULT  | ${JOB}.out        | ${JOB}.err        |

### <a id="a-table-description" name="a-table-description"></a> Table Description

| Column            | Description                                                                                                      |
|-------------------|------------------------------------------------------------------------------------------------------------------|
| Launcher          | Name of the launcher-script.                                                                                     |
| CLI arguments     | Script's command-line interface description.                                                                     |
| `nohup`           | Whether launched jobs are wrapped in `nohup` or not.                                                             |
| `time(1p)`        | Whether launched jobs are wrapped in `time(1p)` or not.                                                          |
| fg / bg           | Whether launched jobs are started in foreground or background. **Background jobs run in parallel**.              |
| Location          | Where the script must be located / launched from. _Any_ --- script in absolutely independent of locations.       |
| Database          | What database configuration is passed to launched jobs (literally). Note that `DEFAULT` means DB from `DS*` EVs. |
| Job StdOut target | Where launched jobs' stdout streams go.                                                                          |
| Job StdErr target | Where launched jobs' stderr streams go.                                                                          |

### <a id="a-posix-tools-description" name="a-posix-tool-description"></a> POSIX tools description

#### <a id="a-posix-nohup-1p" name="a-posix-nohup-1p"></a> nohup(1p)

Quote from [documentation](https://man7.org/linux/man-pages/man1/nohup.1p.html):
```text
The nohup utility shall invoke the utility named by the utility
operand with arguments supplied as the argument operands. At the
time the named utility is invoked, the SIGHUP signal shall be set
to be ignored.
```

Quote from [documentation](https://man7.org/linux/man-pages/man7/signal.7.html):
```text
SIGHUP       P1990      Term    Hangup detected on controlling terminal
                                        or death of controlling process
```

#### <a id="a-posix-time-1p" name="a-posix-time-1p"></a> time(1p)

Quote from [documentation](https://man7.org/linux/man-pages/man1/time.1p.html):
```text
The time utility shall invoke the utility named by the utility
operand with arguments supplied as the argument operands and
write a message to standard error that lists timing statistics
for the utility. The message shall include the following
information:
    
    *  The elapsed (real) time between invocation of utility and its
       termination.
    
    *  The User CPU time, equivalent to the sum of the tms_utime and
       tms_cutime fields returned by the times() function defined in
       the System Interfaces volume of POSIX.1‐2017 for the process
       in which utility is executed.
    
    *  The System CPU time, equivalent to the sum of the tms_stime
       and tms_cstime fields returned by the times() function for
       the process in which utility is executed.
```

Example:
```text
real	5m47.133s
user	0m35.119s
sys	1m15.022s
```


## <a id="a-details" name="a-details"></a> Details

### <a id="a-run_job_test" name="a-run_job_test"></a> run_job_test.sh

Script is used for sequential batch job launching. Takes list of job names as arguments.
Example:
```shell
run_job_test.sh MVPPJOB1 MVPPJOB2
```
will run job `MVPPJOB1`, then (after `MVPPJOB1`'s end) `MVPPJOB2`.
All stdout and stderr outputs will be present in console.

### <a id="a-run_job_test_nohup" name="a-run_job_test_nohup"></a> run_job_test_nohup.sh

Script is used for parallel and HUP-immune batch job launching. Takes list of job names as arguments.
Example:
```shell
run_job_test_nohup.sh MVPPJOB1 MVPPJOB2
```
will run jobs `MVPPJOB1` and `MVPPJOB2` in parallel.
All stdout and stderr outputs will be redirected to corresponding files (`${JOB}.out` and `${JOB}.err`).
