from automation.api.adapter.http_adapter import HttpMTVAdapter
from automation.api.adapter.http_request import Method
from automation.api.model.phme.request.phme1ac2_834_id_card_request_t_request import Phme1ac2834IdCardRequestTRequest
from automation.api.model.phme.response.phme1ac2_834_id_card_request_t_response import Phme1ac2834IdCardRequestTResponse
from automation.api.model.pmbr.request.pmbr1am1_list_members_t_request import Pmbr1am1ListMembersTRequest
from automation.api.model.pmbr.request.pmbr1av3_member_search_t_request import Pmbr1av3MemberSearchTRequest
from automation.api.model.pmbr.request.pmbr1ce4_coverage_employer_lst_t_request import \
    Pmbr1ce4CoverageEmployerLstTRequest
from automation.api.model.pmbr.request.pmbr1cq4_list_cvg_type_span_t_request import Pmbr1cq4ListCvgTypeSpanTRequest
from automation.api.model.pmbr.request.pmbr1ct2_contract_term_t_request import Pmbr1ct2ContractTermTRequest
from automation.api.model.pmbr.request.pmbr1di1_mbr_mpna_list_t_request import Pmbr1di1MbrMpnaListTRequest
from automation.api.model.pmbr.request.pmbr1dj1_mbr_mpna_validate_t_request import Pmbr1dj1MbrMpnaValidateTRequest
from automation.api.model.pmbr.request.pmbr1dl4_list_member_networks_t_request import Pmbr1dl4ListMemberNetworksTRequest
from automation.api.model.pmbr.request.pmbr1em1_mbr_alert_maint_t_request import Pmbr1em1MbrAlertMaintTRequest
from automation.api.model.pmbr.request.pmbr1gr1_display_member_info_t_request import Pmbr1gr1DisplayMemberInfoTRequest
from automation.api.model.pmbr.request.pmbr1gr2_display_member_info_t_request import Pmbr1gr2DisplayMemberInfoTRequest
from automation.api.model.pmbr.request.pmbr1ju1_member_status_maint_t_request import Pmbr1ju1MemberStatusMaintTRequest
from automation.api.model.pmbr.request.pmbr1jy3_member_status_list_t_request import Pmbr1jy3MemberStatusListTRequest
from automation.api.model.pmbr.request.pmbr1mi6_member_info_list_t_request import Pmbr1mi6MemberInfoListTRequest
from automation.api.model.pmbr.request.pmbr1mi7_member_info_list_t_request import Pmbr1mi7MemberInfoListTRequest
from automation.api.model.pmbr.request.pmbr1pm7_member_info_maint_t_request import Pmbr1pm7MemberInfoMaintTRequest
from automation.api.model.pmbr.request.pmbr1pm8_member_info_maint_t_request import Pmbr1pm8MemberInfoMaintTRequest
from automation.api.model.pmbr.request.pmbr1qa7_family_enrollment_t_request import Pmbr1qa7FamilyEnrollmentTRequest
from automation.api.model.pmbr.request.pmbr1qa8_family_enrollment_t_request import Pmbr1qa8FamilyEnrollmentTRequest
from automation.api.model.pmbr.request.pmbr1qm2_cov_cont_info_maint_t_request import Pmbr1qm2CovContInfoMaintTRequest
from automation.api.model.pmbr.request.pmbr1ul1_mbr_alt_id_list_t_request import Pmbr1ul1MbrAltIdListTRequest
from automation.api.model.pmbr.request.pmbr1ul2_mbr_alt_id_list_t_request import Pmbr1ul2MbrAltIdListTRequest
from automation.api.model.pmbr.request.pmbr1vy2_mbr_elig_cov_list_t_request import Pmbr1vy2MbrEligCovListTRequest
from automation.api.model.pmbr.request.pmbr1yl1_cond_dsblty_list_t_request import Pmbr1yl1CondDsbltyListTRequest
from automation.api.model.pmbr.request.pmbr1yl2_cond_dsblty_list_t_request import Pmbr1yl2CondDsbltyListTRequest
from automation.api.model.pmbr.request.pmbr1yu2_cond_dsblty_maint_t_request import Pmbr1yu2CondDsbltyMaintTRequest
from automation.api.model.pmbr.request.pmbrcnl3_mbrshp_contact_list_t_request import Pmbrcnl3MbrshpContactListTRequest
from automation.api.model.pmbr.request.pmbrcnl4_mbrshp_contact_list_t_request import Pmbrcnl4MbrshpContactListTRequest
from automation.api.model.pmbr.request.pmbrcnu3_mbrshp_contact_maint_t_request import Pmbrcnu3MbrshpContactMaintTRequest
from automation.api.model.pmbr.request.pmbrcnu4_mbrshp_contact_maint_t_request import Pmbrcnu4MbrshpContactMaintTRequest
from automation.api.model.pmbr.request.pmbridr2_get_mbr_id_card_t_request import Pmbridr2GetMbrIdCardTRequest
from automation.api.model.pmbr.request.pmbridu2_id_card_ben_sum_maint_t_request import Pmbridu2IdCardBenSumMaintTRequest
from automation.api.model.pmbr.response.pmbr1am1_list_members_t_response import Pmbr1am1ListMembersTResponse
from automation.api.model.pmbr.response.pmbr1av3_member_search_t_response import Pmbr1av3MemberSearchTResponse
from automation.api.model.pmbr.response.pmbr1ce4_coverage_employer_lst_t_response import \
    Pmbr1ce4CoverageEmployerLstTResponse
from automation.api.model.pmbr.response.pmbr1cq4_list_cvg_type_span_t_response import Pmbr1cq4ListCvgTypeSpanTResponse
from automation.api.model.pmbr.response.pmbr1ct2_contract_term_t_response import Pmbr1ct2ContractTermTResponse
from automation.api.model.pmbr.response.pmbr1di1_mbr_mpna_list_t_response import Pmbr1di1MbrMpnaListTResponse
from automation.api.model.pmbr.response.pmbr1dj1_mbr_mpna_validate_t_response import Pmbr1dj1MbrMpnaValidateTResponse
from automation.api.model.pmbr.response.pmbr1dl4_list_member_networks_t_response import \
    Pmbr1dl4ListMemberNetworksTResponse
from automation.api.model.pmbr.response.pmbr1em1_mbr_alert_maint_t_response import Pmbr1em1MbrAlertMaintTResponse
from automation.api.model.pmbr.response.pmbr1gr1_display_member_info_t_response import \
    Pmbr1gr1DisplayMemberInfoTResponse
from automation.api.model.pmbr.response.pmbr1gr2_display_member_info_t_response import \
    Pmbr1gr2DisplayMemberInfoTResponse
from automation.api.model.pmbr.response.pmbr1ju1_member_status_maint_t_response import \
    Pmbr1ju1MemberStatusMaintTResponse
from automation.api.model.pmbr.response.pmbr1jy3_member_status_list_t_response import Pmbr1jy3MemberStatusListTResponse
from automation.api.model.pmbr.response.pmbr1mi6_member_info_list_t_response import Pmbr1mi6MemberInfoListTResponse
from automation.api.model.pmbr.response.pmbr1mi7_member_info_list_t_response import Pmbr1mi7MemberInfoListTResponse
from automation.api.model.pmbr.response.pmbr1pm7_member_info_maint_t_response import Pmbr1pm7MemberInfoMaintTResponse
from automation.api.model.pmbr.response.pmbr1pm8_member_info_maint_t_response import Pmbr1pm8MemberInfoMaintTResponse
from automation.api.model.pmbr.response.pmbr1qa7_family_enrollment_t_response import Pmbr1qa7FamilyEnrollmentTResponse
from automation.api.model.pmbr.response.pmbr1qa8_family_enrollment_t_response import Pmbr1qa8FamilyEnrollmentTResponse
from automation.api.model.pmbr.response.pmbr1qm2_cov_cont_info_maint_t_response import Pmbr1qm2CovContInfoMaintTResponse
from automation.api.model.pmbr.response.pmbr1ul1_mbr_alt_id_list_t_response import Pmbr1ul1MbrAltIdListTResponse
from automation.api.model.pmbr.response.pmbr1ul2_mbr_alt_id_list_t_response import Pmbr1ul2MbrAltIdListTResponse
from automation.api.model.pmbr.response.pmbr1vy2_mbr_elig_cov_list_t_response import Pmbr1vy2MbrEligCovListTResponse
from automation.api.model.pmbr.response.pmbr1yl1_cond_dsblty_list_t_response import Pmbr1yl1CondDsbltyListTResponse
from automation.api.model.pmbr.response.pmbr1yl2_cond_dsblty_list_t_response import Pmbr1yl2CondDsbltyListTResponse
from automation.api.model.pmbr.response.pmbr1yu2_cond_dsblty_maint_t_response import Pmbr1yu2CondDsbltyMaintTResponse
from automation.api.model.pmbr.response.pmbrcnl3_mbrshp_contact_list_t_response import \
    Pmbrcnl3MbrshpContactListTResponse
from automation.api.model.pmbr.response.pmbrcnl4_mbrshp_contact_list_t_response import \
    Pmbrcnl4MbrshpContactListTResponse
from automation.api.model.pmbr.response.pmbrcnu3_mbrshp_contact_maint_t_response import \
    Pmbrcnu3MbrshpContactMaintTResponse
from automation.api.model.pmbr.response.pmbrcnu4_mbrshp_contact_maint_t_response import \
    Pmbrcnu4MbrshpContactMaintTResponse
from automation.api.model.pmbr.response.pmbridr2_get_mbr_id_card_t_response import Pmbridr2GetMbrIdCardTResponse
from automation.api.model.pmbr.response.pmbridu2_id_card_ben_sum_maint_t_response import \
    Pmbridu2IdCardBenSumMaintTResponse


# TODO: Create unit tests
class MembershipAdapter(HttpMTVAdapter):
    """Public class ..."""

    def __init__(self):
        super().__init__()

    def pmbr1mi6_member_info_list_t(self, message: Pmbr1mi6MemberInfoListTRequest) -> Pmbr1mi6MemberInfoListTResponse:
        """

        :param message: request model for API
        :returns: response model for API

        """

        self.api = 'Pmbr1mi6MemberInfoListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1mi6MemberInfoListTResponse(response.content)

        return model

    def pmbr1av3_member_search_t(self, message: Pmbr1av3MemberSearchTRequest) -> Pmbr1av3MemberSearchTResponse:
        """

        :param message: request model for API
        :returns: response model for API

        """

        self.api = 'Pmbr1av3MemberSearchT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1av3MemberSearchTResponse(response.content)

        return model

    def pmbr1yl1_cond_dsblty_list_t(self, message: Pmbr1yl1CondDsbltyListTRequest) -> Pmbr1yl1CondDsbltyListTResponse:
        """

        :param message: request model for API
        :returns: response model for API

        """

        self.api = 'Pmbr1yl1CondDsbltyListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1yl1CondDsbltyListTResponse(response.content)

        return model

    def pmbr1yl2_cond_dsblty_list_t(self, message: Pmbr1yl2CondDsbltyListTRequest) -> Pmbr1yl2CondDsbltyListTResponse:
        """

        :param message: request model for API
        :returns: response model for API

        """

        self.api = 'Pmbr1yl2CondDsbltyListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1yl2CondDsbltyListTResponse(response.content)

        return model

    def pmbrcnl4_mbrshp_contact_list_t(self, message: Pmbrcnl4MbrshpContactListTRequest) -> Pmbrcnl4MbrshpContactListTResponse:
        """

        :param message: request model for API
        :returns: response model for API

        """

        self.api = 'Pmbrcnl4MbrshpContactListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbrcnl4MbrshpContactListTResponse(response.content)

        return model

    def phme1ac2_834_id_card_request_t(self, message: Phme1ac2834IdCardRequestTRequest) -> Phme1ac2834IdCardRequestTResponse:
        """
        :param message: request model for API
        :returns: response model for API
        """

        self.api = 'Phme1ac2834IdCardRequestT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Phme1ac2834IdCardRequestTResponse(response.content)

        return model

    def pmbr1am1_list_members_t(self, message: Pmbr1am1ListMembersTRequest) -> Pmbr1am1ListMembersTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1am1ListMembersT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1am1ListMembersTResponse(response.content)

        return model

    def pmbr1dj1_mbr_mpna_validate_t(self, message: Pmbr1dj1MbrMpnaValidateTRequest) -> Pmbr1dj1MbrMpnaValidateTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1dj1MbrMpnaValidateT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1dj1MbrMpnaValidateTResponse(response.content)

        return model

    def pmbr1dl4_list_member_networks_t(self, message: Pmbr1dl4ListMemberNetworksTRequest) -> Pmbr1dl4ListMemberNetworksTResponse:
        """
        :param message: request model for API
        :returns: response model for API
        """

        self.api = 'Pmbr1dl4ListMemberNetworksT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1dl4ListMemberNetworksTResponse(response.content)

        return model

    def pmbr1ul1_mbr_alt_id_list_t(self, message: Pmbr1ul1MbrAltIdListTRequest) -> Pmbr1ul1MbrAltIdListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1ul1MbrAltIdListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1ul1MbrAltIdListTResponse(response.content)

        return model

    def pmbr1mi7_member_info_list_t(self, message: Pmbr1mi7MemberInfoListTRequest) -> Pmbr1mi7MemberInfoListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1mi7MemberInfoListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1mi7MemberInfoListTResponse(response.content)

        return model

    def pmbr1ct2_contract_term_t(self, message: Pmbr1ct2ContractTermTRequest) -> Pmbr1ct2ContractTermTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1ct2ContractTermT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1ct2ContractTermTResponse(response.content)

        return model

    def pmbr1ul2_mbr_alt_id_list_t(self, message: Pmbr1ul2MbrAltIdListTRequest) -> Pmbr1ul2MbrAltIdListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1ul2MbrAltIdListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1ul2MbrAltIdListTResponse(response.content)

        return model

    def pmbr1vy2_mbr_elig_cov_list_t(self, message: Pmbr1vy2MbrEligCovListTRequest) -> Pmbr1vy2MbrEligCovListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1vy2MbrEligCovListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1vy2MbrEligCovListTResponse(response.content)

        return model

    def pmbr1di1_mbr_mpna_list_t(self, message: Pmbr1di1MbrMpnaListTRequest) -> Pmbr1di1MbrMpnaListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1di1MbrMpnaListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1di1MbrMpnaListTResponse(response.content)

        return model

    def pmbr1cq4_list_cvg_type_span_t(self, message: Pmbr1cq4ListCvgTypeSpanTRequest) -> Pmbr1cq4ListCvgTypeSpanTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1cq4ListCvgTypeSpanT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1cq4ListCvgTypeSpanTResponse(response.content)

        return model

    def pmbr1ce4_coverage_employer_lst_t(self, message: Pmbr1ce4CoverageEmployerLstTRequest) -> Pmbr1ce4CoverageEmployerLstTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1ce4CoverageEmployerLstT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1ce4CoverageEmployerLstTResponse(response.content)

        return model

    def pmbr1qm2_cov_cont_info_maint_t(self, message: Pmbr1qm2CovContInfoMaintTRequest) -> Pmbr1qm2CovContInfoMaintTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1qm2CovContInfoMaintT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1qm2CovContInfoMaintTResponse(response.content)

        return model

    def pmbr1ju1_member_status_maint_t(self, message: Pmbr1ju1MemberStatusMaintTRequest) -> Pmbr1ju1MemberStatusMaintTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1ju1MemberStatusMaintT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1ju1MemberStatusMaintTResponse(response.content)

        return model

    def pmbr1jy3_member_status_list_t(self, message: Pmbr1jy3MemberStatusListTRequest) -> Pmbr1jy3MemberStatusListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1jy3MemberStatusListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1jy3MemberStatusListTResponse(response.content)

        return model

    def pmbr1yu2_cond_dsblty_maint_t(self, message: Pmbr1yu2CondDsbltyMaintTRequest) -> Pmbr1yu2CondDsbltyMaintTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1yu2CondDsbltyMaintT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1yu2CondDsbltyMaintTResponse(response.content)

        return model

    def pmbrcnu4_mbrshp_contact_maint_t(self, message: Pmbrcnu4MbrshpContactMaintTRequest) -> Pmbrcnu4MbrshpContactMaintTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbrcnu4MbrshpContactMaintT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbrcnu4MbrshpContactMaintTResponse(response.content)

        return model

    def pmbr1qa8_family_enrollment_t(self, message: Pmbr1qa8FamilyEnrollmentTRequest) -> Pmbr1qa8FamilyEnrollmentTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1qa8FamilyEnrollmentT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1qa8FamilyEnrollmentTResponse(response.content)

        return model

    def pmbr1qa7_family_enrollment_t(self, message: Pmbr1qa7FamilyEnrollmentTRequest) -> Pmbr1qa7FamilyEnrollmentTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1qa7FamilyEnrollmentT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1qa7FamilyEnrollmentTResponse(response.content)

        return model

    def pmbr1pm8_member_info_maint_t(self, message: Pmbr1pm8MemberInfoMaintTRequest) -> Pmbr1pm8MemberInfoMaintTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1pm8MemberInfoMaintT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1pm8MemberInfoMaintTResponse(response.content)

        return model

    def pmbr1pm7_member_info_maint_t(self, message: Pmbr1pm7MemberInfoMaintTRequest) -> Pmbr1pm7MemberInfoMaintTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1pm7MemberInfoMaintT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1pm7MemberInfoMaintTResponse(response.content)

        return model

    def pmbridu2_id_card_ben_sum_maint_t(self, message: Pmbridu2IdCardBenSumMaintTRequest) -> Pmbridu2IdCardBenSumMaintTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbridu2IdCardBenSumMaintT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbridu2IdCardBenSumMaintTResponse(response.content)

        return model

    def pmbr1gr2_display_member_info_t(self, message: Pmbr1gr2DisplayMemberInfoTRequest) -> Pmbr1gr2DisplayMemberInfoTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1gr2DisplayMemberInfoT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1gr2DisplayMemberInfoTResponse(response.content)

        return model

    def pmbr1gr1_display_member_info_t(self, message: Pmbr1gr1DisplayMemberInfoTRequest) -> Pmbr1gr1DisplayMemberInfoTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1gr1DisplayMemberInfoT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1gr1DisplayMemberInfoTResponse(response.content)

        return model

    def pmbrcnl3_mbrshp_contact_list_t(self, message: Pmbrcnl3MbrshpContactListTRequest) -> Pmbrcnl3MbrshpContactListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbrcnl3MbrshpContactListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbrcnl3MbrshpContactListTResponse(response.content)

        return model

    def pmbr1em1_mbr_alert_maint_t(self, message: Pmbr1em1MbrAlertMaintTRequest) -> Pmbr1em1MbrAlertMaintTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbr1em1MbrAlertMaintT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbr1em1MbrAlertMaintTResponse(response.content)

        return model

    def pmbrcnu3_mbrshp_contact_maint_t(self, message: Pmbrcnu3MbrshpContactMaintTRequest) -> Pmbrcnu3MbrshpContactMaintTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbrcnu3MbrshpContactMaintT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbrcnu3MbrshpContactMaintTResponse(response.content)

        return model

    def pmbridr2_get_mbr_id_card_t(self, message: Pmbridr2GetMbrIdCardTRequest) -> Pmbridr2GetMbrIdCardTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmbridr2GetMbrIdCardT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmbridr2GetMbrIdCardTResponse(response.content)

        return model
