from automation.api.adapter.http_adapter import HttpMTVAdapter
from automation.api.adapter.http_request import Method
from automation.api.model.pclm.request.pclm1al7_claims_list_t_request import Pclm1al7ClaimsListTRequest
from automation.api.model.pclm.request.pclm1ar5_claim_read_t_request import Pclm1ar5ClaimReadTRequest
from automation.api.model.phcl.request.phcl1wd4837_web_dental_claim_t_request import Phcl1wd4837WebDentalClaimTRequest
from automation.api.model.phcl.request.phcl1wd6837_web_dental_claim_t_request import Phcl1wd6837WebDentalClaimTRequest
from automation.api.model.phcl.request.phcl1wd7837_web_dental_claim_t_request import Phcl1wd7837WebDentalClaimTRequest
from automation.api.model.pclm.response.pclm1al7_claims_list_t_response import Pclm1al7ClaimsListTResponse
from automation.api.model.pclm.response.pclm1ar5_claim_read_t_response import Pclm1ar5ClaimReadTResponse
from automation.api.model.phcl.response.phcl1wd4837_web_dental_claim_t_response import Phcl1wd4837WebDentalClaimTResponse
from automation.api.model.phcl.response.phcl1wd6837_web_dental_claim_t_response import Phcl1wd6837WebDentalClaimTResponse
from automation.api.model.phcl.response.phcl1wd7837_web_dental_claim_t_response import Phcl1wd7837WebDentalClaimTResponse


class ClaimsAdjudicationAdapter(HttpMTVAdapter):
    """Public class extends HttpAdapter for specific API."""

    def __init__(self):
        super().__init__()

    def pclm1al7_claims_list_t(self, message: Pclm1al7ClaimsListTRequest) -> Pclm1al7ClaimsListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pclm1al7ClaimsListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pclm1al7ClaimsListTResponse(response.content)

        return model

    def pclm1ar5_claim_read_t(self, message: Pclm1ar5ClaimReadTRequest) -> Pclm1ar5ClaimReadTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pclm1ar5ClaimReadT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pclm1ar5ClaimReadTResponse(response.content)

        return model

    def phcl1wd4837_web_dental_claim_t(self, message: Phcl1wd4837WebDentalClaimTRequest) -> Phcl1wd4837WebDentalClaimTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Phcl1wd4837WebDentalClaimT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Phcl1wd4837WebDentalClaimTResponse(response.content)

        return model

    def phcl1wd6837_web_dental_claim_t(self, message: Phcl1wd6837WebDentalClaimTRequest) -> Phcl1wd6837WebDentalClaimTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Phcl1wd6837WebDentalClaimT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Phcl1wd6837WebDentalClaimTResponse(response.content)

        return model

    def phcl1wd7837_web_dental_claim_t(self, message: Phcl1wd7837WebDentalClaimTRequest) -> Phcl1wd7837WebDentalClaimTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Phcl1wd7837WebDentalClaimT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Phcl1wd7837WebDentalClaimTResponse(response.content)

        return model
