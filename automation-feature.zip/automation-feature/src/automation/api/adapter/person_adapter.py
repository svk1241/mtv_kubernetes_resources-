from automation.api.adapter.http_adapter import HttpMTVAdapter
from automation.api.adapter.http_request import Method
from automation.api.model.pper.request.pper1ar5_person_read_t_request import Pper1ar5PersonReadTRequest
from automation.api.model.pper.request.pper1ar6_person_read_t_request import Pper1ar6PersonReadTRequest
from automation.api.model.pper.request.pper1bs1_psn_contact_info_list_t_request import Pper1bs1PsnContactInfoListTRequest
from automation.api.model.pper.request.pper1bu4_maint_person_addr_t_request import Pper1bu4MaintPersonAddrTRequest
from automation.api.model.pper.request.pper1py1_addr_phn_eml_maint_t_request import Pper1py1AddrPhnEmlMaintTRequest
from automation.api.model.pper.response.pper1bs1_psn_contact_info_list_t_response import Pper1bs1PsnContactInfoListTResponse
from automation.api.model.pper.response.pper1ar5_person_read_t_response import Pper1ar5PersonReadTResponse
from automation.api.model.pper.response.pper1ar6_person_read_t_response import Pper1ar6PersonReadTResponse
from automation.api.model.pper.response.pper1bu4_maint_person_addr_t_response import Pper1bu4MaintPersonAddrTResponse
from automation.api.model.pper.response.pper1py1_addr_phn_eml_maint_t_response import Pper1py1AddrPhnEmlMaintTResponse


class PersonAdapter(HttpMTVAdapter):
    """Public class ..."""

    def __init__(self):
        super().__init__()

    def pper1bs1_psn_contact_info_list_t(self, message: Pper1bs1PsnContactInfoListTRequest) -> Pper1bs1PsnContactInfoListTResponse:
        """

        :param message: model Pper1bs1PsnContactInfoListTRequest
        :returns: model Pper1bs1PsnContactInfoListTResponse

        """

        self.api = 'Pper1bs1PsnContactInfoListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pper1bs1PsnContactInfoListTResponse(response.content)

        return model

    def pper1ar5_person_read_t(self, message: Pper1ar5PersonReadTRequest) -> Pper1ar5PersonReadTResponse:
        """

        :param message: model Pper1ar5PersonReadTRequest
        :returns: model Pper1ar5PersonReadTResponse

        """
        self.api = 'Pper1ar5PersonReadT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pper1ar5PersonReadTResponse(response.content)

        return model

    def pper1ar6_person_read_t(self, message: Pper1ar6PersonReadTRequest) -> Pper1ar6PersonReadTResponse:
        """

        :param message: model Pper1ar6PersonReadTRequest
        :returns: model Pper1ar6PersonReadTResponse

        """
        self.api = 'Pper1ar6PersonReadT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pper1ar6PersonReadTResponse(response.content)

        return model

    def pper1bu4_maint_person_addr_t(self, message: Pper1bu4MaintPersonAddrTRequest) -> Pper1bu4MaintPersonAddrTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pper1bu4MaintPersonAddrT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pper1bu4MaintPersonAddrTResponse(response.content)

        return model

    def pper1py1_addr_phn_eml_maint_t(self, message: Pper1py1AddrPhnEmlMaintTRequest) -> Pper1py1AddrPhnEmlMaintTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pper1py1AddrPhnEmlMaintT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pper1py1AddrPhnEmlMaintTResponse(response.content)

        return model
