from automation.api.adapter.http_adapter import HttpMTVAdapter
from automation.api.adapter.http_request import Method
from automation.api.model.pmst.request.pmst1cr6_display_group_info_t_request import Pmst1cr6DisplayGroupInfoTRequest
from automation.api.model.pmst.request.pmst1cr7_display_group_info_t_request import Pmst1cr7DisplayGroupInfoTRequest
from automation.api.model.pmst.request.pmst1dl1_list_divisions_t_request import Pmst1dl1ListDivisionsTRequest
from automation.api.model.pmst.request.pmst1ts3_tier_structure_list_t_request import Pmst1ts3TierStructureListTRequest
from automation.api.model.pmst.request.pmst1vl2_eglx_id_crd_msc_list_t_request import Pmst1vl2EglxIdCrdMscListTRequest
from automation.api.model.pmst.request.pmst1do1_div_by_status_list_t_request import Pmst1do1DivByStatusListTRequest
from automation.api.model.pmst.request.pmst1bp4_egl_x_bene_pkg_list_t_request import Pmst1bp4EglXBenePkgListTRequest
from automation.api.model.pmst.request.pmst1ll1_dpndt_ag_rul_list_t_request import Pmst1ll1DpndtAgRulListTRequest
from automation.api.model.pmst.request.pmstwsl1_waitng_period_set_lst_t_request import Pmstwsl1WaitngPeriodSetLstTRequest
from automation.api.model.pmst.request.pmst1nl1_document_route_list_t_request import Pmst1nl1DocumentRouteListTRequest
from automation.api.model.pmst.request.pmst1jl3_bus_lvl_netwrk_list_t_request import Pmst1jl3BusLvlNetwrkListTRequest
from automation.api.model.pmst.request.pmst1ht1_list_eglx_span_t_request import Pmst1ht1ListEglxSpanTRequest
from automation.api.model.pmst.request.pmst1dr9_emp_grp_level2_read_t_request import Pmst1dr9EmpGrpLevel2ReadTRequest
from automation.api.model.pmst.request.pmst1nu1_document_route_maint_t_request import Pmst1nu1DocumentRouteMaintTRequest
from automation.api.model.pmst.request.pmst1jl2_bus_lvl_netwrk_list_t_request import Pmst1jl2BusLvlNetwrkListTRequest
from automation.api.model.pmst.response.pmst1cr6_display_group_info_t_response import Pmst1cr6DisplayGroupInfoTResponse
from automation.api.model.pmst.response.pmst1cr7_display_group_info_t_response import Pmst1cr7DisplayGroupInfoTResponse
from automation.api.model.pmst.response.pmst1dl1_list_divisions_t_response import Pmst1dl1ListDivisionsTResponse
from automation.api.model.pmst.response.pmst1ts3_tier_structure_list_t_response import Pmst1ts3TierStructureListTResponse
from automation.api.model.pmst.response.pmst1vl2_eglx_id_crd_msc_list_t_response import Pmst1vl2EglxIdCrdMscListTResponse
from automation.api.model.pmst.response.pmst1do1_div_by_status_list_t_response import Pmst1do1DivByStatusListTResponse
from automation.api.model.pmst.response.pmst1bp4_egl_x_bene_pkg_list_t_response import Pmst1bp4EglXBenePkgListTResponse
from automation.api.model.pmst.response.pmst1ll1_dpndt_ag_rul_list_t_response import Pmst1ll1DpndtAgRulListTResponse
from automation.api.model.pmst.response.pmstwsl1_waitng_period_set_lst_t_response import Pmstwsl1WaitngPeriodSetLstTResponse
from automation.api.model.pmst.response.pmst1nl1_document_route_list_t_response import Pmst1nl1DocumentRouteListTResponse
from automation.api.model.pmst.response.pmst1jl3_bus_lvl_netwrk_list_t_response import Pmst1jl3BusLvlNetwrkListTResponse
from automation.api.model.pmst.response.pmst1ht1_list_eglx_span_t_response import Pmst1ht1ListEglxSpanTResponse
from automation.api.model.pmst.response.pmst1dr9_emp_grp_level2_read_t_response import Pmst1dr9EmpGrpLevel2ReadTResponse
from automation.api.model.pmst.response.pmst1nu1_document_route_maint_t_response import Pmst1nu1DocumentRouteMaintTResponse
from automation.api.model.pmst.response.pmst1jl2_bus_lvl_netwrk_list_t_response import Pmst1jl2BusLvlNetwrkListTResponse


class MembershipStructuresAdapter(HttpMTVAdapter):
    """Public class extends HttpAdapter for specific API."""

    def __init__(self):
        super().__init__()

    def pmst1dl1_list_divisions_t(self, message: Pmst1dl1ListDivisionsTRequest) -> Pmst1dl1ListDivisionsTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmst1dl1ListDivisionsT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmst1dl1ListDivisionsTResponse(response.content)

        return model

    def pmst1cr6_display_group_info_t(self, message: Pmst1cr6DisplayGroupInfoTRequest) -> Pmst1cr6DisplayGroupInfoTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmst1cr6DisplayGroupInfoT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmst1cr6DisplayGroupInfoTResponse(response.content)

        return model

    def pmst1cr7_display_group_info_t(self, message: Pmst1cr7DisplayGroupInfoTRequest) -> Pmst1cr7DisplayGroupInfoTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmst1cr7DisplayGroupInfoT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmst1cr7DisplayGroupInfoTResponse(response.content)

        return model

    def pmst1ts3_tier_structure_list_t(self, message: Pmst1ts3TierStructureListTRequest) -> Pmst1ts3TierStructureListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmst1ts3TierStructureListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmst1ts3TierStructureListTResponse(response.content)

        return model

    def pmst1vl2_eglx_id_crd_msc_list_t(self, message: Pmst1vl2EglxIdCrdMscListTRequest) -> Pmst1vl2EglxIdCrdMscListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmst1vl2EglxIdCrdMscListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmst1vl2EglxIdCrdMscListTResponse(response.content)

        return model

    def pmst1do1_div_by_status_list_t(self, message: Pmst1do1DivByStatusListTRequest) -> Pmst1do1DivByStatusListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmst1do1DivByStatusListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmst1do1DivByStatusListTResponse(response.content)

        return model

    def pmst1bp4_egl_x_bene_pkg_list_t(self, message: Pmst1bp4EglXBenePkgListTRequest) -> Pmst1bp4EglXBenePkgListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmst1bp4EglXBenePkgListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmst1bp4EglXBenePkgListTResponse(response.content)

        return model

    def pmst1ll1_dpndt_ag_rul_list_t(self, message: Pmst1ll1DpndtAgRulListTRequest) -> Pmst1ll1DpndtAgRulListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmst1ll1DpndtAgRulListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmst1ll1DpndtAgRulListTResponse(response.content)

        return model

    def pmstwsl1_waitng_period_set_lst_t(self, message: Pmstwsl1WaitngPeriodSetLstTRequest) -> Pmstwsl1WaitngPeriodSetLstTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmstwsl1WaitngPeriodSetLstT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmstwsl1WaitngPeriodSetLstTResponse(response.content)

        return model

    def pmst1nl1_document_route_list_t(self, message: Pmst1nl1DocumentRouteListTRequest) -> Pmst1nl1DocumentRouteListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmst1nl1DocumentRouteListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmst1nl1DocumentRouteListTResponse(response.content)

        return model

    def pmst1jl3_bus_lvl_netwrk_list_t(self, message: Pmst1jl3BusLvlNetwrkListTRequest) -> Pmst1jl3BusLvlNetwrkListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmst1jl3BusLvlNetwrkListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmst1jl3BusLvlNetwrkListTResponse(response.content)

        return model

    def pmst1ht1_list_eglx_span_t(self, message: Pmst1ht1ListEglxSpanTRequest) -> Pmst1ht1ListEglxSpanTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmst1ht1ListEglxSpanT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmst1ht1ListEglxSpanTResponse(response.content)

        return model

    def pmst1dr9_emp_grp_level2_read_t(self, message: Pmst1dr9EmpGrpLevel2ReadTRequest) -> Pmst1dr9EmpGrpLevel2ReadTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmst1dr9EmpGrpLevel2ReadT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmst1dr9EmpGrpLevel2ReadTResponse(response.content)

        return model

    def pmst1nu1_document_route_maint_t(self, message: Pmst1nu1DocumentRouteMaintTRequest) -> Pmst1nu1DocumentRouteMaintTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmst1nu1DocumentRouteMaintT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmst1nu1DocumentRouteMaintTResponse(response.content)

        return model

    def pmst1jl2_bus_lvl_netwrk_list_t(self, message: Pmst1jl2BusLvlNetwrkListTRequest) -> Pmst1jl2BusLvlNetwrkListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pmst1jl2BusLvlNetwrkListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pmst1jl2BusLvlNetwrkListTResponse(response.content)

        return model
