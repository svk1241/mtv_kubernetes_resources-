from automation.api.adapter.http_adapter import HttpMTVAdapter
from automation.api.adapter.http_request import Method
from automation.api.model.pben.response.pben1am7_list_ben_counter_mbr_t_response import Pben1am7ListBenCounterMbrTResponse
from automation.api.model.pben.response.pben1ap2_list_ben_counter_prsn_t_response import Pben1ap2ListBenCounterPrsnTResponse
from automation.api.model.pben.request.pben1am7_list_ben_counter_mbr_t_request import Pben1am7ListBenCounterMbrTRequest
from automation.api.model.pben.request.pben1ap2_list_ben_counter_prsn_t_request import Pben1ap2ListBenCounterPrsnTRequest


class BenefitsAdapter(HttpMTVAdapter):
    """Public class extends HttpAdapter for specific API."""

    def __init__(self):
        super().__init__()

    def pben1am7_list_ben_counter_mbr_t(self, message: Pben1am7ListBenCounterMbrTRequest) -> Pben1am7ListBenCounterMbrTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pben1am7ListBenCounterMbrT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pben1am7ListBenCounterMbrTResponse(response.content)

        return model

    def pben1ap2_list_ben_counter_prsn_t(self, message: Pben1ap2ListBenCounterPrsnTRequest) -> Pben1ap2ListBenCounterPrsnTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pben1ap2ListBenCounterPrsnT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pben1ap2ListBenCounterPrsnTResponse(response.content)

        return model
