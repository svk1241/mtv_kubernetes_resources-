from automation.api.adapter.http_adapter import HttpMTVAdapter
from automation.api.adapter.http_request import Method
from automation.api.model.pref.response.pref1hl6_list_contacts_t_response import Pref1hl6ListContactsTResponse
from automation.api.model.pref.response.pref1dl2_list_codeval_keyword_t_response import Pref1dl2ListCodevalKeywordTResponse
from automation.api.model.pref.response.pref1bs3_list_code_values_t_response import Pref1bs3ListCodeValuesTResponse
from automation.api.model.pref.response.pref1im2_list_address_t_response import Pref1im2ListAddressTResponse
from automation.api.model.pref.response.pref1bs2_list_code_values_t_response import Pref1bs2ListCodeValuesTResponse
from automation.api.model.pref.request.pref1hl6_list_contacts_t_request import Pref1hl6ListContactsTRequest
from automation.api.model.pref.request.pref1dl2_list_codeval_keyword_t_request import Pref1dl2ListCodevalKeywordTRequest
from automation.api.model.pref.request.pref1bs3_list_code_values_t_request import Pref1bs3ListCodeValuesTRequest
from automation.api.model.pref.request.pref1im2_list_address_t_request import Pref1im2ListAddressTRequest
from automation.api.model.pref.request.pref1bs2_list_code_values_t_request import Pref1bs2ListCodeValuesTRequest


class ReferenceControlsAdapter(HttpMTVAdapter):
    """Public class extends HttpAdapter for specific API."""

    def __init__(self):
        super().__init__()

    def pref1hl6_list_contacts_t(self, message: Pref1hl6ListContactsTRequest) -> Pref1hl6ListContactsTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pref1hl6ListContactsT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pref1hl6ListContactsTResponse(response.content)

        return model

    def pref1dl2_list_codeval_keyword_t(self, message: Pref1dl2ListCodevalKeywordTRequest) -> Pref1dl2ListCodevalKeywordTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pref1dl2ListCodevalKeywordT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pref1dl2ListCodevalKeywordTResponse(response.content)

        return model

    def pref1bs3_list_code_values_t(self, message: Pref1bs3ListCodeValuesTRequest) -> Pref1bs3ListCodeValuesTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pref1bs3ListCodeValuesT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pref1bs3ListCodeValuesTResponse(response.content)

        return model

    def pref1im2_list_address_t(self, message: Pref1im2ListAddressTRequest) -> Pref1im2ListAddressTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pref1im2ListAddressT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pref1im2ListAddressTResponse(response.content)

        return model

    def pref1bs2_list_code_values_t(self, message: Pref1bs2ListCodeValuesTRequest) -> Pref1bs2ListCodeValuesTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pref1bs2ListCodeValuesT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pref1bs2ListCodeValuesTResponse(response.content)

        return model
