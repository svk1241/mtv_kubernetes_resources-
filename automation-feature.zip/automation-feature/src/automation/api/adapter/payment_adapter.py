from automation.api.adapter.http_adapter import HttpMTVAdapter
from automation.api.adapter.http_request import Method
from automation.api.model.pcpy.response.pcpy1fl3_payment_register_list_t_response import Pcpy1fl3PaymentRegisterListTResponse
from automation.api.model.pcpy.request.pcpy1fl3_payment_register_list_t_request import Pcpy1fl3PaymentRegisterListTRequest


class PaymentAdapter(HttpMTVAdapter):
    """Public class ..."""

    def __init__(self):
        super().__init__()

    def pcpy1fl3_payment_register_list_t(self, message: Pcpy1fl3PaymentRegisterListTRequest) -> Pcpy1fl3PaymentRegisterListTResponse:
        """
        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pcpy1fl3PaymentRegisterListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pcpy1fl3PaymentRegisterListTResponse(response.content)

        return model
