from automation.api.adapter.http_adapter import HttpMTVAdapter
from automation.api.adapter.http_request import Method
from automation.api.model.ppmf.response.ppmf1fl3_ffs_fee_sched_list_t_response import Ppmf1fl3FfsFeeSchedListTResponse
from automation.api.model.ppmf.response.ppmf1fl1_ffs_fee_sched_list_t_response import Ppmf1fl1FfsFeeSchedListTResponse
from automation.api.model.ppmf.response.ppmf1fr1_fee_schedule_read_t_response import Ppmf1fr1FeeScheduleReadTResponse
from automation.api.model.ppmf.response.ppmf1fu1_ffs_fee_sched_maint_t_response import Ppmf1fu1FfsFeeSchedMaintTResponse
from automation.api.model.ppmf.request.ppmf1fl3_ffs_fee_sched_list_t_request import Ppmf1fl3FfsFeeSchedListTRequest
from automation.api.model.ppmf.request.ppmf1fl1_ffs_fee_sched_list_t_request import Ppmf1fl1FfsFeeSchedListTRequest
from automation.api.model.ppmf.request.ppmf1fr1_fee_schedule_read_t_request import Ppmf1fr1FeeScheduleReadTRequest
from automation.api.model.ppmf.request.ppmf1fu1_ffs_fee_sched_maint_t_request import Ppmf1fu1FfsFeeSchedMaintTRequest


class PricingManagementAdapter(HttpMTVAdapter):
    """Public class extends HttpAdapter for specific API."""

    def __init__(self):
        super().__init__()

    def ppmf1fl3_ffs_fee_sched_list_t(self, message: Ppmf1fl3FfsFeeSchedListTRequest) -> Ppmf1fl3FfsFeeSchedListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Ppmf1fl3FfsFeeSchedListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Ppmf1fl3FfsFeeSchedListTResponse(response.content)

        return model

    def ppmf1fl1_ffs_fee_sched_list_t(self, message: Ppmf1fl1FfsFeeSchedListTRequest) -> Ppmf1fl1FfsFeeSchedListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Ppmf1fl1FfsFeeSchedListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Ppmf1fl1FfsFeeSchedListTResponse(response.content)

        return model

    def ppmf1fr1_fee_schedule_read_t(self, message: Ppmf1fr1FeeScheduleReadTRequest) -> Ppmf1fr1FeeScheduleReadTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Ppmf1fr1FeeScheduleReadT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Ppmf1fr1FeeScheduleReadTResponse(response.content)

        return model

    def ppmf1fu1_ffs_fee_sched_maint_t(self, message: Ppmf1fu1FfsFeeSchedMaintTRequest) -> Ppmf1fu1FfsFeeSchedMaintTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Ppmf1fu1FfsFeeSchedMaintT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Ppmf1fu1FfsFeeSchedMaintTResponse(response.content)

        return model
