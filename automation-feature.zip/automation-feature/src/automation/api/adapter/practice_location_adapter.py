from automation.api.adapter.http_adapter import HttpMTVAdapter
from automation.api.adapter.http_request import Method
from automation.api.model.pplc.request.pplc1al3_practice_locn_list_t_request import Pplc1al3PracticeLocnListTRequest
from automation.api.model.pplc.request.pplc1al4_practice_locn_list_t_request import Pplc1al4PracticeLocnListTRequest
from automation.api.model.pplc.response.pplc1al3_practice_locn_list_t_response import Pplc1al3PracticeLocnListTResponse
from automation.api.model.pplc.response.pplc1al4_practice_locn_list_t_response import Pplc1al4PracticeLocnListTResponse


class PracticeLocationAdapter(HttpMTVAdapter):
    """Public class ..."""

    def __init__(self):
        super().__init__()

    def pplc1al3_practice_locn_list_t(self, message: Pplc1al3PracticeLocnListTRequest) -> Pplc1al3PracticeLocnListTResponse:
        """
        :param message: request model for API
        :returns: response model for API
        """

        self.api = 'Pplc1al3PracticeLocnListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pplc1al3PracticeLocnListTResponse(response.content)

        return model

    def pplc1al4_practice_locn_list_t(self, message: Pplc1al4PracticeLocnListTRequest) -> Pplc1al4PracticeLocnListTResponse:
        """
        :param message: request model for API
        :returns: response model for API
        """

        self.api = 'Pplc1al4PracticeLocnListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pplc1al4PracticeLocnListTResponse(response.content)

        return model
