import abc

import allure
from requests import Session

from automation.api.adapter.http_request import HttpStatusCode, Method, Request
from automation.helper.allure_helper import AllureHelper
from automation.helper.json_helper import JsonHelper
from automation.impl.custom_exception import ApiException
from automation.impl.performance_logger import PerformanceLogger
from automation.settings import SettingsHelper


class Response:
    def __init__(self, response):
        self.result_code = response.status_code
        self.is_code_valid = None
        self.__set_content(response)
        self.response_status = None
        self.error_code = None
        self.elapsed_time = round(response.elapsed.total_seconds() * 1000)
        self.result = None

    def __set_content(self, response):
        self.content = response.content.decode(response.encoding) if response.encoding else response.content.decode()


class BaseHttpAdapter(metaclass=abc.ABCMeta):
    """Base HTTP adapter class"""

    api = ''

    def __init__(self):
        self.headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        self.valid_codes = {HttpStatusCode.OK}
        self.__init_session()

    @abc.abstractmethod
    def execute(self, method: Method, **kwargs):
        raise NotImplementedError

    def __init_session(self):
        self.session = Session()

    def __get_log_info(self, response: Response, test_type: str):
        dict_log = {
            'name': self.api,
            'http_code': response.result_code,
            'is_code_valid': int(response.is_code_valid is True),
            'time_real': response.elapsed_time,
            'type': test_type,
        }
        return f'{JsonHelper.serialize(dict_log)}'

    def _get_response(self, request: 'Request', original_req: 'Request', test_type: str = 'api') -> 'Response':
        """Sends request and gets Response object

        :param request: request to send
        :param original_req: original request
        :param test_type: type of the test; defaults to 'api'
        :raises ApiException: if code is not valid
        :return: Response object
        """
        response = Response(self.session.send(request))
        response.is_code_valid = response.result_code in self.valid_codes

        PerformanceLogger.log_info(self.__get_log_info(response, test_type))
        AllureHelper.attach_curl_from_request(request=original_req.request)
        AllureHelper.attach_text(text=str(response.content), displayed_name='RAW response')

        if not response.is_code_valid:
            if response.result_code == HttpStatusCode.INTERNAL_SERVER_ERROR:
                raise ApiException(response.content)
            raise ValueError(response.content)

        return response


# TODO: Create unit tests
class HttpMTVAdapter(BaseHttpAdapter):
    """HTTP adapter for MTV API tests"""

    def __init__(self):
        super().__init__()
        self.url = SettingsHelper.get_api_setting('url')
        self.auth = SettingsHelper.get_authorization('api')

    @allure.step('Execute request')
    def execute(self, method: Method, **kwargs):
        """
        :param method:
        :type method:
        :param **kwargs:
        :type **kwargs:
        :returns:

        """
        req = Request(f'{self.url}{self.api}.jsp', method)
        req.update(**kwargs)
        req.prepare()

        request = req.request.copy()
        if request.body:
            body = request.body.replace(self.auth.password, self.auth.password.value)
            request.prepare_body(body, None)

        response = self._get_response(request, req)
        return response


class HttpExtServiceAdapter(BaseHttpAdapter):
    """HTTP adapter for extensions service tests"""

    def __init__(self):
        super().__init__()
        self.headers = {'Content-Type': 'application/json'}
        self.url = SettingsHelper.get_extensions_service_setting('url')
        self.ddext1 = 'delta_extension_1'
        self.ddext2 = 'delta_extension_2'

    @allure.step('Execute request')
    def execute(self, endpoint: str, method: Method, **kwargs):
        """Executes HTTP request
        :param endpoint: extensions service endpoint
        :param method: method to execute
        :return: Response object
        """
        self.api = endpoint
        req = Request(f'{self.url}/{endpoint}', method)
        req.update(**kwargs)
        req.prepare()

        request = req.request.copy()

        response = self._get_response(request, req, 'extensions_service')
        return response
