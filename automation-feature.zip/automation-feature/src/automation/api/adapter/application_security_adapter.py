from automation.api.adapter.http_adapter import HttpMTVAdapter
from automation.api.adapter.http_request import Method
from automation.api.model.psec.response.psec1ep1_change_password_t_response import Psec1ep1ChangePasswordTResponse   # pragma: allowlist secret
from automation.api.model.psec.request.psec1ep1_change_password_t_request import Psec1ep1ChangePasswordTRequest   # pragma: allowlist secret


class ApplicationSecurityAdapter(HttpMTVAdapter):
    """Public class extends HttpAdapter for specific API."""

    def __init__(self):
        super().__init__()

    def psec1ep1_change_password_t(self, message: Psec1ep1ChangePasswordTRequest) -> Psec1ep1ChangePasswordTResponse:    # pragma: allowlist secret
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Psec1ep1ChangePasswordT'     # pragma: allowlist secret
        response = self.execute(Method.POST, message=message.to_dict())
        model = Psec1ep1ChangePasswordTResponse(response.content)    # pragma: allowlist secret

        return model
