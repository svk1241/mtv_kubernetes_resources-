from automation.api.adapter.http_adapter import HttpMTVAdapter
from automation.api.adapter.http_request import Method
from automation.api.model.pprv.response.pprv1jl3_list_prov_sec_id_t_response import Pprv1jl3ListProvSecIdTResponse
from automation.api.model.pprv.response.pprv1jl4_list_prov_sec_id_t_response import Pprv1jl4ListProvSecIdTResponse
from automation.api.model.pprv.response.pprv1jn2_xref_provider_id_t_response import Pprv1jn2XrefProviderIdTResponse
from automation.api.model.pprv.response.pprv1jn3_xref_provider_id_t_response import Pprv1jn3XrefProviderIdTResponse
from automation.api.model.pprv.response.pprv1ml3_list_prov_affiliation_t_response import Pprv1ml3ListProvAffiliationTResponse
from automation.api.model.pprv.response.pprv1vr5_provider_validate_t_response import Pprv1vr5ProviderValidateTResponse
from automation.api.model.pprv.response.pprv1hl4_provider_on_review_t_response import Pprv1hl4ProviderOnReviewTResponse
from automation.api.model.pprv.response.pprv1ar7_provider_read_t_response import Pprv1ar7ProviderReadTResponse
from automation.api.model.pprv.response.pprv1ar5_provider_read_t_response import Pprv1ar5ProviderReadTResponse
from automation.api.model.pprv.response.pprv1apd1_provider_data_t_response import Pprv1apd1ProviderDataTResponse
from automation.api.model.pprv.response.pprv1ml2_list_prov_affiliation_t_response import Pprv1ml2ListProvAffiliationTResponse
from automation.api.model.pprv.response.pprv1yr3_read_fed_rpting_entit_t_response import Pprv1yr3ReadFedRptingEntitTResponse
from automation.api.model.pprv.request.pprv1jl3_list_prov_sec_id_t_request import Pprv1jl3ListProvSecIdTRequest
from automation.api.model.pprv.request.pprv1jl4_list_prov_sec_id_t_request import Pprv1jl4ListProvSecIdTRequest
from automation.api.model.pprv.request.pprv1jn2_xref_provider_id_t_request import Pprv1jn2XrefProviderIdTRequest
from automation.api.model.pprv.request.pprv1jn3_xref_provider_id_t_request import Pprv1jn3XrefProviderIdTRequest
from automation.api.model.pprv.request.pprv1ml3_list_prov_affiliation_t_request import Pprv1ml3ListProvAffiliationTRequest
from automation.api.model.pprv.request.pprv1vr5_provider_validate_t_request import Pprv1vr5ProviderValidateTRequest
from automation.api.model.pprv.request.pprv1hl4_provider_on_review_t_request import Pprv1hl4ProviderOnReviewTRequest
from automation.api.model.pprv.request.pprv1ar7_provider_read_t_request import Pprv1ar7ProviderReadTRequest
from automation.api.model.pprv.request.pprv1ar5_provider_read_t_request import Pprv1ar5ProviderReadTRequest
from automation.api.model.pprv.request.pprv1apd1_provider_data_t_request import Pprv1apd1ProviderDataTRequest
from automation.api.model.pprv.request.pprv1ml2_list_prov_affiliation_t_request import Pprv1ml2ListProvAffiliationTRequest
from automation.api.model.pprv.request.pprv1yr3_read_fed_rpting_entit_t_request import Pprv1yr3ReadFedRptingEntitTRequest


class ProviderAdapter(HttpMTVAdapter):
    """Public class extends HttpAdapter for specific API."""

    def __init__(self):
        super().__init__()

    def pprv1jl3_list_prov_sec_id_t(self, message: Pprv1jl3ListProvSecIdTRequest) -> Pprv1jl3ListProvSecIdTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pprv1jl3ListProvSecIdT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pprv1jl3ListProvSecIdTResponse(response.content)

        return model

    def pprv1jl4_list_prov_sec_id_t(self, message: Pprv1jl4ListProvSecIdTRequest) -> Pprv1jl4ListProvSecIdTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pprv1jl4ListProvSecIdT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pprv1jl4ListProvSecIdTResponse(response.content)

        return model

    def pprv1jn2_xref_provider_id_t(self, message: Pprv1jn2XrefProviderIdTRequest) -> Pprv1jn2XrefProviderIdTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pprv1jn2XrefProviderIdT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pprv1jn2XrefProviderIdTResponse(response.content)

        return model

    def pprv1jn3_xref_provider_id_t(self, message: Pprv1jn3XrefProviderIdTRequest) -> Pprv1jn3XrefProviderIdTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pprv1jn3XrefProviderIdT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pprv1jn3XrefProviderIdTResponse(response.content)

        return model

    def pprv1ml3_list_prov_affiliation_t(self, message: Pprv1ml3ListProvAffiliationTRequest) -> Pprv1ml3ListProvAffiliationTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pprv1ml3ListProvAffiliationT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pprv1ml3ListProvAffiliationTResponse(response.content)

        return model

    def pprv1vr5_provider_validate_t(self, message: Pprv1vr5ProviderValidateTRequest) -> Pprv1vr5ProviderValidateTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pprv1vr5ProviderValidateT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pprv1vr5ProviderValidateTResponse(response.content)

        return model

    def pprv1hl4_provider_on_review_t(self, message: Pprv1hl4ProviderOnReviewTRequest) -> Pprv1hl4ProviderOnReviewTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pprv1hl4ProviderOnReviewT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pprv1hl4ProviderOnReviewTResponse(response.content)

        return model

    def pprv1ar7_provider_read_t(self, message: Pprv1ar7ProviderReadTRequest) -> Pprv1ar7ProviderReadTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pprv1ar7ProviderReadT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pprv1ar7ProviderReadTResponse(response.content)

        return model

    def pprv1ar5_provider_read_t(self, message: Pprv1ar5ProviderReadTRequest) -> Pprv1ar5ProviderReadTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pprv1ar5ProviderReadT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pprv1ar5ProviderReadTResponse(response.content)

        return model

    def pprv1apd1_provider_data_t(self, message: Pprv1apd1ProviderDataTRequest) -> Pprv1apd1ProviderDataTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pprv1apd1ProviderDataT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pprv1apd1ProviderDataTResponse(response.content)

        return model

    def pprv1yr3_read_fed_rpting_entit_t(self, message: Pprv1yr3ReadFedRptingEntitTRequest) -> Pprv1yr3ReadFedRptingEntitTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pprv1yr3ReadFedRptingEntitT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pprv1yr3ReadFedRptingEntitTResponse(response.content)

        return model

    def pprv1ml2_list_prov_affiliation_t(self, message: Pprv1ml2ListProvAffiliationTRequest) -> Pprv1ml2ListProvAffiliationTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pprv1ml2ListProvAffiliationT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pprv1ml2ListProvAffiliationTResponse(response.content)

        return model
