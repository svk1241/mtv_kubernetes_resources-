from requests import Request as HttpRequest


# TODO: Create unit tests
class Method:
    """Public class .."""
    GET = 'GET'
    POST = 'POST'


class RequestParam:
    """Public class ..."""
    PARAMS = 'params'
    MESSAGE = 'message'
    HEADERS = 'headers'
    JSON = 'json'


class Request:
    """Public class .."""

    def __init__(self, url, method: Method):
        self.__create(url, method)

    def update(self, **kwargs):
        """

        :param **kwargs:
        :type **kwargs:

        """
        if RequestParam.PARAMS in kwargs:
            self.request.params = kwargs[RequestParam.PARAMS]
        if RequestParam.MESSAGE in kwargs:
            self.request.data = kwargs[RequestParam.MESSAGE]
        if RequestParam.HEADERS in kwargs:
            self.request.headers = kwargs[RequestParam.HEADERS]
        if RequestParam.JSON in kwargs:
            self.request.json = kwargs[RequestParam.JSON]

    def prepare(self):
        """

        """
        self.request = self.request.prepare()

    def __create(self, url, method: Method):
        self.request = HttpRequest(method, url)


class HttpStatusCode:
    OK = 200
    BAD_REQUEST = 400
    METHOD_NOT_ALLOWED = 405
    UNSUPPORTED_MEDIA_TYPE = 415
    INTERNAL_SERVER_ERROR = 500
