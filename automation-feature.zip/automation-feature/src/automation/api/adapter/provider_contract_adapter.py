from automation.api.adapter.http_adapter import HttpMTVAdapter
from automation.api.adapter.http_request import Method
from automation.api.model.ppcn.request.ppcn1cm2_list_prov_contract_t_request import Ppcn1cm2ListProvContractTRequest
from automation.api.model.ppcn.request.ppcn1fl3_list_bl_cont_assn_t_request import Ppcn1fl3ListBlContAssnTRequest
from automation.api.model.ppcn.request.ppcn1bm3_list_prov_cont_info_t_request import Ppcn1bm3ListProvContInfoTRequest
from automation.api.model.ppcn.request.ppcn1bm5_list_prov_cont_info_t_request import Ppcn1bm5ListProvContInfoTRequest
from automation.api.model.ppcn.request.ppcn1cm1_list_prov_contract_t_request import Ppcn1cm1ListProvContractTRequest
from automation.api.model.ppcn.response.ppcn1cm2_list_prov_contract_t_response import Ppcn1cm2ListProvContractTResponse
from automation.api.model.ppcn.response.ppcn1fl3_list_bl_cont_assn_t_response import Ppcn1fl3ListBlContAssnTResponse
from automation.api.model.ppcn.response.ppcn1bm3_list_prov_cont_info_t_response import Ppcn1bm3ListProvContInfoTResponse
from automation.api.model.ppcn.response.ppcn1bm5_list_prov_cont_info_t_response import Ppcn1bm5ListProvContInfoTResponse
from automation.api.model.ppcn.response.ppcn1cm1_list_prov_contract_t_response import Ppcn1cm1ListProvContractTResponse


class ProviderContractAdapter(HttpMTVAdapter):
    """Public class ..."""

    def __init__(self):
        super().__init__()

    def ppcn1cm2_list_prov_contract_t(self, message: Ppcn1cm2ListProvContractTRequest) -> Ppcn1cm2ListProvContractTResponse:
        """
        :param message: request model for API
        :returns: response model for API

        """

        self.api = 'Ppcn1cm2ListProvContractT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Ppcn1cm2ListProvContractTResponse(response.content)

        return model

    def ppcn1fl3_list_bl_cont_assn_t(self, message: Ppcn1fl3ListBlContAssnTRequest) -> Ppcn1fl3ListBlContAssnTResponse:
        """
        :param message: request model for API
        :returns: response model for API

        """

        self.api = 'Ppcn1fl3ListBlContAssnT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Ppcn1fl3ListBlContAssnTResponse(response.content)

        return model

    def ppcn1bm3_list_prov_cont_info_t(self, message: Ppcn1bm3ListProvContInfoTRequest) -> Ppcn1bm3ListProvContInfoTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Ppcn1bm3ListProvContInfoT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Ppcn1bm3ListProvContInfoTResponse(response.content)

        return model

    def ppcn1bm5_list_prov_cont_info_t(self, message: Ppcn1bm5ListProvContInfoTRequest) -> Ppcn1bm5ListProvContInfoTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Ppcn1bm5ListProvContInfoT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Ppcn1bm5ListProvContInfoTResponse(response.content)

        return model

    def ppcn1cm1_list_prov_contract_t(self, message: Ppcn1cm1ListProvContractTRequest) -> Ppcn1cm1ListProvContractTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Ppcn1cm1ListProvContractT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Ppcn1cm1ListProvContractTResponse(response.content)

        return model
