from automation.api.adapter.http_adapter import HttpMTVAdapter
from automation.api.adapter.http_request import Method
from automation.api.model.pcob.response.pcob1fl6_other_subscriber_list_t_response import Pcob1fl6OtherSubscriberListTResponse
from automation.api.model.pcob.response.pcob1fl8_other_subscriber_list_t_response import Pcob1fl8OtherSubscriberListTResponse
from automation.api.model.pcob.response.pcob1lm4_cob_info_maint_t_response import Pcob1lm4CobInfoMaintTResponse
from automation.api.model.pcob.request.pcob1fl6_other_subscriber_list_t_request import Pcob1fl6OtherSubscriberListTRequest
from automation.api.model.pcob.request.pcob1fl8_other_subscriber_list_t_request import Pcob1fl8OtherSubscriberListTRequest
from automation.api.model.pcob.request.pcob1lm4_cob_info_maint_t_request import Pcob1lm4CobInfoMaintTRequest


class CoordinationOfBenefitsAdapter(HttpMTVAdapter):
    """Public class extends HttpAdapter for specific API."""

    def __init__(self):
        super().__init__()

    def pcob1fl6_other_subscriber_list_t(self, message: Pcob1fl6OtherSubscriberListTRequest) -> Pcob1fl6OtherSubscriberListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pcob1fl6OtherSubscriberListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pcob1fl6OtherSubscriberListTResponse(response.content)

        return model

    def pcob1fl8_other_subscriber_list_t(self, message: Pcob1fl8OtherSubscriberListTRequest) -> Pcob1fl8OtherSubscriberListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pcob1fl8OtherSubscriberListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pcob1fl8OtherSubscriberListTResponse(response.content)

        return model

    def pcob1lm4_cob_info_maint_t(self, message: Pcob1lm4CobInfoMaintTRequest) -> Pcob1lm4CobInfoMaintTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pcob1lm4CobInfoMaintT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pcob1lm4CobInfoMaintTResponse(response.content)

        return model
