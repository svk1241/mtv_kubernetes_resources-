from automation.api.adapter.http_adapter import HttpMTVAdapter
from automation.api.adapter.http_request import Method
from automation.api.model.pcor.request.pcor1al3_list_trig_event_stat_t_request import Pcor1al3ListTrigEventStatTRequest
from automation.api.model.pcor.request.pcor1da1_triggered_event_add_t_request import Pcor1da1TriggeredEventAddTRequest
from automation.api.model.pcor.request.pcor1au2_trig_event_stat_maint_t_request import Pcor1au2TrigEventStatMaintTRequest
from automation.api.model.pcor.response.pcor1al3_list_trig_event_stat_t_response import Pcor1al3ListTrigEventStatTResponse
from automation.api.model.pcor.response.pcor1da1_triggered_event_add_t_response import Pcor1da1TriggeredEventAddTResponse
from automation.api.model.pcor.response.pcor1au2_trig_event_stat_maint_t_response import Pcor1au2TrigEventStatMaintTResponse


# TODO: Create unit tests
class CorrespondenceGeneratorAdapter(HttpMTVAdapter):
    """Public class ..."""

    def __init__(self):
        super().__init__()

    def pcor1al3_list_trig_event_stat_t(self, message: Pcor1al3ListTrigEventStatTRequest) -> Pcor1al3ListTrigEventStatTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pcor1al3ListTrigEventStatT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pcor1al3ListTrigEventStatTResponse(response.content)

        return model

    def pcor1da1_triggered_event_add_t(self, message: Pcor1da1TriggeredEventAddTRequest) -> Pcor1da1TriggeredEventAddTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pcor1da1TriggeredEventAddT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pcor1da1TriggeredEventAddTResponse(response.content)

        return model

    def pcor1au2_trig_event_stat_maint_t(self, message: Pcor1au2TrigEventStatMaintTRequest) -> Pcor1au2TrigEventStatMaintTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pcor1au2TrigEventStatMaintT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pcor1au2TrigEventStatMaintTResponse(response.content)

        return model
