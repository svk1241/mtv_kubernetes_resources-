from automation.api.adapter.http_adapter import HttpMTVAdapter
from automation.api.adapter.http_request import Method
from automation.api.model.pbil.response.pbil1am6_billing_config_list_t_response import Pbil1am6BillingConfigListTResponse
from automation.api.model.pbil.request.pbil1am6_billing_config_list_t_request import Pbil1am6BillingConfigListTRequest


class BillingAccountsReceivableAdapter(HttpMTVAdapter):
    """Public class extends HttpAdapter for specific API."""

    def __init__(self):
        super().__init__()

    def pbil1am6_billing_config_list_t(self, message: Pbil1am6BillingConfigListTRequest) -> Pbil1am6BillingConfigListTResponse:
        """Method for sending request and getting response for specified API.

        :param message: request model for API
        :returns: response model for API
        """
        self.api = 'Pbil1am6BillingConfigListT'
        response = self.execute(Method.POST, message=message.to_dict())
        model = Pbil1am6BillingConfigListTResponse(response.content)

        return model
