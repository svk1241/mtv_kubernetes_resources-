from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Numerable, Table


class Pcob1lm4CobInfoMaintTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorGIcob1Interface'
        super().__init__(content, response_status=ResponseStatusExtended)
        self.regex_carrierid = 'identifier'  # TODO: "['export_icob1_mbr_othr_sub_as']['identifier']"
        self.regex_mosa_createtimestamp = 't_creation_timestamp'  # TODO: "['export_icob1_mbr_othr_sub_as']['t_creation_timestamp_1']['t_creation_timestamp']"
        self.regex_mosa_lasttimestamp = 't_last_maintenance_timestamp'  # TODO:"['export_icob1_mbr_othr_sub_as']['t_last_maintenance_timestamp_1']['t_last_maintenance_timestamp']"
        self.regex_enddate = 't_end_date'  # TODO: "['export_icob1_mbr_othr_sub_as']['t_end_date']"

        self.export_g_ief_supplied = self._htmlParser.table_to_obj(ExportGIefSupplied)
        self.export_g_ief_supplied.length = self._htmlParser.get_table_length("ExportGroupServices", "export_export_group_services_length")
        self.export_g_icob1_ief_supplied = self._htmlParser.table_to_obj(ExportGIcob1IefSupplied)
        self.export_g_icob1_ief_supplied.length = self._htmlParser.get_table_length("ExportIcob1OtherCoverageType", "export_export_icob1_other_coverage_type_length")
        self.export_icob1_cob_member = self._htmlParser.table_to_obj(ExportIcob1CobMember, True)
        self.export_icob1_mbr_othr_sub_assn = self._htmlParser.table_to_obj(ExportIcob1MbrOthrSubAssn, True)


@dataclass
class ExportGIefSuppliedItem:
    """Public class which describes item structure for table ExportGIefSupplied"""

    select_char: str
    t_claim_service_number: str
    t_claim_sequence_number: str


@dataclass
class ExportGIefSupplied(Numerable):
    """Public class which describes dataclass for table ExportGIefSupplied"""

    items: List[ExportGIefSuppliedItem]
    table_name: str = "ExportGIefSupplied"


@dataclass
class ExportGIcob1IefSuppliedItem:
    """Public class which describes item structure for table ExportGIcob1IefSupplied"""

    select_char: str
    coverage_type_code: str
    operator_identifier: str
    t_creation_timestamp: str
    t_last_maintenance_timestamp: str


@dataclass
class ExportGIcob1IefSupplied(Numerable):
    """Public class which describes dataclass for table ExportGIcob1IefSupplied"""

    items: List[ExportGIcob1IefSuppliedItem]
    table_name: str = "ExportGIcob1IefSupplied"


@dataclass
class ExportIcob1CobMember(Table):
    """Public class which describes dataclass for table ExportIcob1CobMember"""

    contract_id2: str
    member_id: str
    status_indicator: str
    signature_on_file_flag: str
    recent_nofault_flag: str
    worker_comp_flag: str
    subrogation_flag: str
    operator_identifier: str
    t_other_covrge_last_ver_date: str
    t_creation_timestamp: str
    t_last_maintenance_timestamp: str
    who_type_indicator: str
    status_indicator_1: str
    carrier_indentifier: str
    policy_identifier2: str
    claim_identfier: str
    claim_facsimile_flag: str
    letter_form_code: str
    reason_code: str
    communications_description: str
    type_followup_indicator: str
    communication_type_indicator: str
    operator_identifier_1: str
    t_date_of_communications: str
    t_followup_date: str
    t_phone_number: str
    t_follow_up_days: str
    t_creation_timestamp_1: str
    t_last_maintenance_timestamp_1: str
    t_amount2: str
    table_name: str = "ExportIcob1CobMember"


@dataclass
class ExportIcob1MbrOthrSubAssn(Table):
    """Public class which describes dataclass for table ExportIcob1MbrOthrSubAssn"""

    void_flag: str
    calculation_liability_indicator: str
    liability_override_indicator: str
    type_of_liability_code: str
    relation_to_member_code: str
    relation_to_contract_code: str
    relation_carrier_to_member: str
    operator_identifier: str
    t_effective_date: str
    t_end_date: str
    t_last_maintenance_timestamp: str
    t_creation_timestamp: str
    identifier: str
    carrier_name: str
    address_line1: str
    address_line2: str
    city: str
    state_code: str
    zip: str
    contact_name1: str
    contact_name2: str
    carrier_type_code: str
    liability_rule_indicator: str
    operator_identifier_1: str
    t_phone1: str
    t_phone2: str
    t_follow_up_days: str
    t_creation_timestamp_1: str
    t_last_maintenance_timestamp_1: str
    policy_identifier2: str
    address_line1_1: str
    address_line2_1: str
    city_1: str
    state_code_1: str
    zip_1: str
    home_phone: str
    business_phone: str
    member_address_flag: str
    birth_date: str
    sex_code: str
    employer_group_identifier: str
    employer_group_name: str
    creation_timestamp: str
    operator_identifier_2: str
    last_maintenance_timestamp: str
    t_home_phone: str
    t_business_phone: str
    t_birth_date: str
    t_creation_timestamp_2: str
    t_last_maintenance_timestamp_2: str
    complete_last_name: str
    complete_first_name: str
    complete_middle_name: str
    complete_subscriber_title: str
    complete_name_suffix: str
    void_flag_1: str
    eligibility_status_code: str
    subscriber_to_contract_hldr_rel: str
    employment_status_code: str
    contract_type_code: str
    group_coverage_flag: str
    cob_provision_code: str
    language_code: str
    first_legislation_code: str
    second_legislation_code: str
    operator_identifier_3: str
    t_effective_date_1: str
    t_end_date_1: str
    t_last_maintenance_timestamp_3: str
    t_creation_timestamp_3: str
    table_name: str = "ExportIcob1MbrOthrSubAssn"


@dataclass
class ResponseStatusExtended(Table):
    """Public class which describes dataclass for table ExportIcob1Interface"""

    severity_code: str
    data_store_status: str
    origin_servid: str
    context_string: str
    return_code: str
    reason_code: str
    checksum: str
    return_address: str
    action_indicator: str
    table_name: str = "ExportIcob1Interface"
