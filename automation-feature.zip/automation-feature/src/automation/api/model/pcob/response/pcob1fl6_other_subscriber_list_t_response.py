from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Numerable, Table


class Pcob1fl6OtherSubscriberListTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorsGIcob1Interface'
        ErrorCode.name_length_table = 'ExportErrorsGroup'
        ErrorCode.name_length_field = 'export_export_errors_group_length'
        super().__init__(content, response_status=ResponseStatusExtended)
        self.export_g_icob1_cob_member = self._htmlParser.table_to_obj(ExportGIcob1CobMember)
        self.export_g_icob1_cob_member.length = self._htmlParser.get_table_length("ExportListGroup", "export_export_list_group_length")


@dataclass
class ExportGIcob1CobMemberItem:
    """Public class which describes item structure for table ExportGIcob1CobMember"""

    member_id: str
    last_name: str
    first_name: str
    middle_name: str
    sex_code: str
    t_birth_date: str
    t_social_security_number: str
    policy_identifier2: str
    last_name_1: str
    first_name_1: str
    middle_name_1: str
    address_line1: str
    address_line2: str
    address_line3: str
    city: str
    state_code: str
    zip: str
    sex_code_1: str
    employer_group_identifier: str
    employer_group_name: str
    member_address_flag: str
    t_home_phone: str
    t_business_phone: str
    t_birth_date_1: str
    t_creation_timestamp: str
    t_last_maintenance_timestamp: str
    eligibility_status_code: str
    subscriber_to_contract_hldr_rel: str
    employment_status_code: str
    contract_type_code: str
    group_coverage_flag: str
    cob_provision_code: str
    language_code: str
    first_legislation_code: str
    second_legislation_code: str
    t_effective_date: str
    t_end_date: str
    carrier_name: str
    identifier: str
    carrier_type_code: str
    carrier_type_code_translated: str
    carrier_type_code_desc: str
    product_type_code: str
    product_type_code_description: str
    calculation_liability_indicator: str
    liability_override_indicator: str
    relation_to_member_code: str
    relation_to_contract_code: str
    relation_carrier_to_member: str
    type_of_liability_code: str
    t_effective_date_1: str
    t_end_date_1: str
    t_last_maintenance_timestamp_1: str
    t_creation_timestamp_1: str
    report_description: str
    report_description_1: str
    report_description_2: str
    report_description_3: str


@dataclass
class ExportGIcob1CobMember(Numerable):
    """Public class which describes dataclass for table ExportGIcob1CobMember"""

    items: List[ExportGIcob1CobMemberItem]
    table_name: str = "ExportGIcob1CobMember"


@dataclass
class ResponseStatusExtended(Table):
    """Public class which describes dataclass for table ExportListControlsIefSupplied"""

    command: str
    count: str
    member_id: str
    policy_identifier2: str
    identifier: str
    t_effective_date: str
    t_effective_date_1: str
    return_address: str
    severity_code: str
    origin_servid: str
    context_string: str
    data_store_status: str
    return_code: str
    reason_code: str
    checksum: str
    table_name: str = "ExportListControlsIefSupplied"
