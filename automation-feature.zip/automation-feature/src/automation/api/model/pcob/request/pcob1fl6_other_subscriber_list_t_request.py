from automation.api.model.common.base_request_model import BaseRequestModel


class Pcob1fl6OtherSubscriberListTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportIcob1InterfaceSecurityId = ''
    ImportImportIcob1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportIcob1InterfaceRequestorId = ''
    ImportImportIcob1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportIcob1InterfaceReturnAddress = ''
    ImportImportIcob1InterfaceReturnReportDescriptionFlag = ''
    ImportImportQualifyIcob1CobMemberContractId2 = ''
    ImportImportQualifyIcob1CobMemberMemberId = ''
    ImportImportStartIcob1CobMemberMemberId = ''
    ImportImportStartIcob1OtherSubscriberPolicyIdentifier2 = ''
    ImportImportStartIcob1OtherCarrierIdentifier = ''
    ImportImportStartIcob1OtherSubPolicyTEffectiveDate = ''
    ImportImportStartIcob1MbrOthrSubAssnTEffectiveDate = ''
    ImportImportListControlsIefSuppliedCount = ''
    ImportImportIref1CodeXslationTranslationTable = ''
