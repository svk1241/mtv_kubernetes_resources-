from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Numerable


class Pcpy1fl3PaymentRegisterListTResponse(BaseResponseModel):
    """Public class .."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorGIcpy1Interface'
        ResponseStatus.table_name = 'ExportIcpy1Interface'
        super().__init__(content)
        self.export_list_payment_reg_g_icpy1_payment_register = self._htmlParser.table_to_obj(ExportListPaymentRegGIcpy1PaymentRegister)
        self.export_list_payment_reg_g_icpy1_payment_register.length = self._htmlParser.get_table_length("ExportListPaymentRegGroup", "export_export_list_payment_reg_group_length")


@dataclass
class ExportListPaymentRegGIcpy1PaymentRegisterItem:
    """Public class .."""

    payment_type: str
    payment_type_identifier: str
    t_issue_date: str
    t_payment_amount: str
    payment_status_text: str
    t_status_date: str
    account_payable_code2: str
    t_tax_identifier: str
    pay_to_indicator: str
    payee_identifier2: str
    payee_member_id: str
    status_change_indicator: str
    table_name: str = 'ExportListPaymentRegGIcpy1PaymentRegisterItem'


@dataclass
class ExportListPaymentRegGIcpy1PaymentRegister(Numerable):
    """Public class .."""

    items: List[ExportListPaymentRegGIcpy1PaymentRegisterItem]
    table_name: str = 'ExportListPaymentRegGIcpy1PaymentRegister'
