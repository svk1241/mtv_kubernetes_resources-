from automation.api.model.common.base_request_model import BaseRequestModel


class Pcpy1fl3PaymentRegisterListTRequest(BaseRequestModel):
    """Public class .."""

    ImportImportIcpy1InterfaceSecurityId = ''
    ImportImportIcpy1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportIcpy1InterfaceRequestorId = ''
    ImportImportIcpy1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportIcpy1InterfaceActionIndicator = ''
    ImportImportIcpy1InterfaceReturnAddress = ''
    ImportImportKeyIcpy1PaymentRegisterPaymentTypeIdentifier = ''
    ImportImportEndDateIcpy1PaymentRegisterTIssueDate = ''
    ImportImportStartDateIcpy1PaymentRegisterTIssueDate = ''
    ImportImportProviderIdIcpy1PaymentRegisterPayeeIdentifier2 = ''
    ImportImportIcpy1PaymentRegisterPayeeMemberId = ''
