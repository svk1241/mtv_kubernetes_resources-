from typing import List
from dataclasses import dataclass

from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.numerable import Table, Numerable


class Pmbr1av3MemberSearchTResponse(BaseResponseModel):
    """Public class .."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = "ExportErrorGImbr1Interface"
        ResponseStatus.table_name = "ExportImbr1Interface"
        super().__init__(content)
        self.export_rows_returned_ief_supplied_text = self._htmlParser.table_to_obj(ExportRowsReturnedIefSuppliedText, True)
        self.export_member_group = self._htmlParser.table_to_obj(ExportMemberGroup, True)
        self.export_g_imbr1_member = self._htmlParser.table_to_obj(ExportGImbr1Member)
        self.export_start_imbr1_member = self._htmlParser.table_to_obj(ExportStartImbr1Member, True)


@dataclass
class ExportRowsReturnedIefSuppliedText(Table):
    """Public class .."""

    t_count: str
    command: str
    table_name: str = 'ExportRowsReturnedIefSuppliedText'


@dataclass
class ExportMemberGroup(Table):
    """Public class .."""

    export_export_member_group_length: str
    table_name: str = 'ExportMemberGroup'


@dataclass
class ExportGImbr1MemberItem:
    """Public class .."""

    contract_id3: str
    member_id: str
    complete_first_name: str
    complete_middle_name: str
    complete_last_name: str
    sex_code: str
    person_identifier: str
    t_birth_date: str
    t_social_security_number: str
    record_status: str
    remarks_flag: str
    coverage_contract_holder_flag: str
    complete_person_title: str
    complete_name_suffix: str
    void_flag: str
    business_level4_id: str
    business_level5_id: str
    business_level6_id: str
    business_level7_id: str
    type_code: str
    class_code: str
    benefit_package_identifier: str
    t_effective_date: str
    t_end_date: str
    multiple_benefit_pkgs_flag: str
    line_of_business: str
    benefit_package_type_code: str
    provider_identifier: str
    t_effective_date_1: str
    t_end_date_1: str
    provider_name: str
    status_code: str
    contract_cross_ref_flag: str
    employer_group_level1_id: str
    zip: str


@dataclass
class ExportGImbr1Member(Numerable):
    """Public class .."""

    items: List[ExportGImbr1MemberItem]
    table_name: str = 'ExportGImbr1Member'


@dataclass
class ExportStartImbr1Member(Table):
    """Public class .."""

    contract_id3: str
    member_id: str
    complete_first_name: str
    complete_middle_name: str
    complete_last_name: str
    t_birth_date: str
    sex_code: str
    alternate_id_type_code: str
    table_name: str = 'ExportStartImbr1Member'
