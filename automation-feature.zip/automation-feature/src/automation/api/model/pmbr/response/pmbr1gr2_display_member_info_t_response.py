from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Table


class Pmbr1gr2DisplayMemberInfoTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorGImbr1Interface'
        ResponseStatus.table_name = 'ExportImbr1Interface'
        super().__init__(content)
        self.export_ihme1_subscriber_lvl = self._htmlParser.table_to_obj(ExportIhme1SubscriberLvl, True)


@dataclass
class ExportIhme1SubscriberLvl(Table):
    """Public class which describes dataclass for table ExportIhme1SubscriberLvl"""

    ref02_subid_subscriber_id: str
    ref02_mbrid_subscriber_sup_id: str
    employment_status_code: str
    employment_status_description: str
    nm109_mbr_nm_sub_identifier: str
    nm103_mbr_nm_sub_last_name2: str
    nm104_mbr_nm_sub_first_name2: str
    nm105_mbr_nm_sub_middle_name2: str
    nm106_mbr_nm_sub_name_prefix2: str
    nm107_mbr_nm_sub_name_suffix2: str
    dmg04_mbr_demo_gender_code: str
    t_dmg02_mbr_demo_sub_birth_date: str
    t_hire_date: str
    address_type_description: str
    address_code: str
    address_code_description: str
    t_effective_date: str
    t_end_date: str
    address3: str
    county_code: str
    county_code_description: str
    country_code_description: str
    n301_address_line1: str
    n302_address_line2: str
    n401_city_name: str
    n402_state_or_province_code: str
    n403_postal_code: str
    n404_country_code: str
    phone_type: str
    phone_code: str
    phone_code_description: str
    country_id: str
    pager_pin_id: str
    extension: str
    t_phone_number: str
    electronic_address_code: str
    electronic_address_code_desc: str
    electronic_address: str
    business_level4_id: str
    business_level5_id: str
    business_level6_id: str
    business_level7_id: str
    type_code: str
    type_code_description: str
    class_code: str
    class_code_description: str
    benefit_package_identifier: str
    benefit_package_description: str
    t_dtp03_hlth_cov_effective_date: str
    t_dtp03_hlth_cov_end_date: str
    contract_type_description: str
    rate_package_identifier_code: str
    rate_package_id_description: str
    t_effective_date_1: str
    t_end_date_1: str
    hd05_coverage_level_code: str
    ref02_mbr_plcy_id_ins_group_num: str
    ref02_mbr_id_department_number: str
    name: str
    name_1: str
    table_name: str = "ExportIhme1SubscriberLvl"
