from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Numerable, Table


class Pmbr1cq4ListCvgTypeSpanTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorGImbr1Interface'
        ResponseStatus.table_name = 'ExportImbr1Interface'
        super().__init__(content)
        self.export_cvg_type_span_g_imbr1_coverage_type_span = self._htmlParser.table_to_obj(ExportCvgTypeSpanGImbr1CoverageTypeSpan)
        self.export_cvg_type_span_g_imbr1_coverage_type_span.length = self._htmlParser.get_table_length("ExportCvgTypeSpanGroup",
                                                                                                        "export_export_cvg_type_span_group_length")
        self.export_start_imbr1_coverage_type_span = self._htmlParser.table_to_obj(ExportStartImbr1CoverageTypeSpan, True)
        self.export_list_controls_ief_supplied = self._htmlParser.table_to_obj(ExportListControlsIefSupplied, True)


@dataclass
class ExportCvgTypeSpanGImbr1CoverageTypeSpanItem:
    """Public class which describes item structure for table ExportCvgTypeSpanGImbr1CoverageTypeSpan"""

    employer_group_level1_id: str
    employer_group_level2_id: str
    business_level4_id: str
    business_level5_id: str
    business_level6_id: str
    business_level7_id: str
    contract_type_code: str
    contract_type_code_description: str
    rate_package_identifier_code: str
    rate_package_id_cd_description: str
    t_creation_timestamp: str
    t_last_maintenance_timestamp: str
    t_effective_date: str
    t_end_date: str
    t_coverage_request_date: str
    t_enrollment_date: str
    timely_enrollment_indicator: str
    enrollment_type: str
    special_event_code: str
    special_event_cd_description: str
    disenrollment_reason_code: str
    disenrollment_rsn_cd_description: str
    t_receipt_date: str
    qualifying_event_code: str
    qualifying_event_cd_description: str
    t_notification_date: str
    employment_class_code: str
    employment_class_cd_description: str
    void_flag: str


@dataclass
class ExportCvgTypeSpanGImbr1CoverageTypeSpan(Numerable):
    """Public class which describes dataclass for table ExportCvgTypeSpanGImbr1CoverageTypeSpan"""

    items: List[ExportCvgTypeSpanGImbr1CoverageTypeSpanItem]
    table_name: str = "ExportCvgTypeSpanGImbr1CoverageTypeSpan"


@dataclass
class ExportStartImbr1CoverageTypeSpan(Table):
    """Public class which describes dataclass for table ExportStartImbr1CoverageTypeSpan"""

    t_end_date: str
    table_name: str = "ExportStartImbr1CoverageTypeSpan"


@dataclass
class ExportListControlsIefSupplied(Table):
    """Public class which describes dataclass for table ExportListControlsIefSupplied"""

    command: str
    t_count: str
    member_id: str
    table_name: str = "ExportListControlsIefSupplied"
