from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.numerable import Numerable, Table


class Pmbr1qm2CovContInfoMaintTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        self.regex_timestamp = '.+timestamp'
        self.regex_contract_id = 'contract_id'
        self.regex_receipt_date = 't_receipt_date'
        self.regex_end_date = 't_end_date'
        super().__init__(content, response_status=ResponseStatusExtended, error_code=ErrorCodeExtended)
        self.export_g_imbr1_coverage_contract_status = self._htmlParser.table_to_obj(ExportGImbr1CoverageContractStatus)
        self.export_g_imbr1_coverage_contract_status.length = self._htmlParser.get_table_length(
            "ExportCovContStatusGroup", "export_export_cov_cont_status_group_length")
        self.export_g_imbr1_cov_cont_cross_reference = self._htmlParser.table_to_obj(ExportGImbr1CovContCrossReference)
        self.export_g_imbr1_cov_cont_cross_reference.length = self._htmlParser.get_table_length(
            "ExportCovContXRefGroup", "export_export_cov_cont_x_ref_group_length")
        self.export_g_imbr1_coverage_employer_info = self._htmlParser.table_to_obj(ExportGImbr1CoverageEmployerInfo)
        self.export_g_imbr1_coverage_employer_info.length = self._htmlParser.get_table_length("ExportCovEmpInfoGroup",
                                                                                              "export_export_cov_emp_info_group_length")
        self.export_g_imbr1_coverage_type_span = self._htmlParser.table_to_obj(ExportGImbr1CoverageTypeSpan)
        self.export_g_imbr1_coverage_type_span.length = self._htmlParser.get_table_length("ExportCovTypSpanGroup",
                                                                                          "export_export_cov_typ_span_group_length")
        self.export_header_imbr1_coverage_type_span = self._htmlParser.table_to_obj(ExportHeaderImbr1CoverageTypeSpan,
                                                                                    True)


@dataclass
class ExportGImbr1CoverageContractStatusItem:
    """Public class which describes item structure for table ExportGImbr1CoverageContractStatus"""

    status_code: str
    t_effective_date: str
    t_end_date: str
    t_last_maintenance_timestamp: str
    operator_identifier: str
    void_flag: str
    t_creation_timestamp: str


@dataclass
class ExportGImbr1CoverageContractStatus(Numerable):
    """Public class which describes dataclass for table ExportGImbr1CoverageContractStatus"""

    items: List[ExportGImbr1CoverageContractStatusItem]
    table_name: str = "ExportGImbr1CoverageContractStatus"


@dataclass
class ExportGImbr1CovContCrossReferenceItem:
    """Public class which describes item structure for table ExportGImbr1CovContCrossReference"""

    new_coverage_contract_id2: str
    reason_code: str
    void_flag: str
    disenrollment_reason_code: str
    operator_identifier: str
    t_effective_date: str
    t_end_date: str
    t_creation_timestamp: str
    t_last_maintenance_timestamp: str


@dataclass
class ExportGImbr1CovContCrossReference(Numerable):
    """Public class which describes dataclass for table ExportGImbr1CovContCrossReference"""

    items: List[ExportGImbr1CovContCrossReferenceItem]
    table_name: str = "ExportGImbr1CovContCrossReference"


@dataclass
class ExportGImbr1CoverageEmployerInfoItem:
    """Public class which describes item structure for table ExportGImbr1CoverageEmployerInfo"""

    t_effective_date: str
    t_end_date: str
    employer_reference_identifier: str
    payroll_department_identifier: str
    t_hire_date: str
    t_salary: str
    t_salary_effective_date: str
    employment_status_code: str
    employee_occupation: str
    t_life_volume: str
    t_override_life_volume: str
    void_flag: str
    t_last_maintenance_timestamp: str
    operator_identifier: str
    t_creation_timestamp: str
    t_receipt_date: str


@dataclass
class ExportGImbr1CoverageEmployerInfo(Numerable):
    """Public class which describes dataclass for table ExportGImbr1CoverageEmployerInfo"""

    items: List[ExportGImbr1CoverageEmployerInfoItem]
    table_name: str = "ExportGImbr1CoverageEmployerInfo"


@dataclass
class ExportGImbr1CoverageTypeSpanItem:
    """Public class which describes item structure for table ExportGImbr1CoverageTypeSpan"""

    contract_type_code: str
    disenrollment_reason_code: str
    rate_package_identifier_code: str
    business_level4_id: str
    business_level5_id: str
    business_level6_id: str
    business_level7_id: str
    employer_group_level1_id: str
    employer_group_level2_id: str
    enrollment_type: str
    special_event_code: str
    timely_enrollment_indicator: str
    qualifying_event_code: str
    notification_date: str
    employment_class_code: str
    void_flag: str
    operator_identifier: str
    t_effective_date: str
    t_end_date: str
    t_coverage_request_date: str
    t_notification_date: str
    t_enrollment_date: str
    t_creation_timestamp: str
    t_last_maintenance_timestamp: str
    t_receipt_date: str


@dataclass
class ExportGImbr1CoverageTypeSpan(Numerable):
    """Public class which describes dataclass for table ExportGImbr1CoverageTypeSpan"""

    items: List[ExportGImbr1CoverageTypeSpanItem]
    table_name: str = "ExportGImbr1CoverageTypeSpan"


@dataclass
class ExportHeaderImbr1CoverageTypeSpan(Table):
    """Public class which describes dataclass for table ExportHeaderImbr1CoverageTypeSpan"""

    contract_id2: str
    table_name: str = "ExportHeaderImbr1CoverageTypeSpan"


@dataclass
class ResponseStatusExtended(Table):
    """Public class which describes dataclass for table ExportImst1Interface"""

    severity_code: str
    data_store_status: str
    origin_servid: str
    context_string: str
    return_code: str
    reason_code: str
    checksum: str
    return_address: str
    invalid_dates_flag: str
    table_name: str = "ExportImbr1Interface"


@dataclass
class ErrorCodeItemExtended:
    """Public class which describes item structure for table ExportErrorsGImbr1Interface"""

    error_code: str
    error_record_type: str
    t_error_occurrence: str


@dataclass
class ErrorCodeExtended(Numerable):
    """Public class which describes dataclass for table ExportErrorsGImbr1Interface"""

    items: List[ErrorCodeItemExtended]
    table_name: str = "ExportErrorsGImbr1Interface"
    name_length_table: str = "ExportErrorsGroup"
    name_length_field: str = "export_export_errors_group_length"
