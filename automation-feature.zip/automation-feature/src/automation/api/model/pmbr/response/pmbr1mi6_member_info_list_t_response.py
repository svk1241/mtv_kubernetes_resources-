from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Numerable, Table


class Pmbr1mi6MemberInfoListTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorsGImbr1Interface'
        ErrorCode.name_length_table = 'ExportErrorsGroup'
        ErrorCode.name_length_field = 'export_export_errors_group_length'
        ResponseStatus.table_name = 'ExportImbr1Interface'
        super().__init__(content)
        self.export_person_name_g_iper1_person_name = self._htmlParser.table_to_obj(ExportPersonNameGIper1PersonName)
        self.export_person_name_g_iper1_person_name.length = self._htmlParser.get_table_length("ExportPersonNameListGroup", "export_export_person_name_list_group_length")
        self.export_member_g_imbr1_member = self._htmlParser.table_to_obj(ExportMemberGImbr1Member)
        self.export_member_g_imbr1_member.length = self._htmlParser.get_table_length("ExportMemberInfoListGroup", "export_export_member_info_list_group_length")
        self.export_start_imbr1_member = self._htmlParser.table_to_obj(ExportStartImbr1Member, True)


@dataclass
class ExportPersonNameGIper1PersonNameItem:
    """Public class which describes item structure for table ExportPersonNameGIper1PersonName"""

    t_last_maintenance_timestamp: str
    t_effective_date: str
    t_end_date: str
    t_creation_timestamp: str
    person_identifier: str
    last_name: str
    first_name: str
    middle_name: str
    person_name_title: str
    name_suffix: str
    nickname: str
    operator_id: str


@dataclass
class ExportPersonNameGIper1PersonName(Numerable):
    """Public class which describes dataclass for table ExportPersonNameGIper1PersonName"""

    items: List[ExportPersonNameGIper1PersonNameItem]
    table_name: str = "ExportPersonNameGIper1PersonName"


@dataclass
class ExportMemberGImbr1MemberItem:
    """Public class which describes item structure for table ExportMemberGImbr1Member"""

    adoption_date: str
    t_adoption_date: str
    contract_id3: str
    contract_id: str
    coverage_contract_holder_flag: str
    t_creation_timestamp: str
    disease_management_indicator: str
    information: str
    internal_case_identifier: str
    t_last_maintenance_timestamp: str
    medical_service_area_code: str
    medical_service_area_code_desc: str
    member_id: str
    operator_identifier: str
    person_identifier: str
    region_code: str
    region_code_desc: str
    native_american_identifier: str
    native_american_indicator: str
    member_hardcopy_eob_flag: str
    t_user_defined_date1: str
    incentive_level: str
    incentive_level_desc: str
    t_original_effective_date: str
    language_code: str
    language_desc: str
    language_code2: str
    language_desc2: str
    t_creation_timestamp_1: str
    t_death_date: str
    t_death_notification_date: str
    cause_of_death_indicator: str
    t_receipt_date: str
    desired_communication_key: str
    desired_communication_method_ind: str
    directive_on_file_flag: str
    medical_no_prior_covg_flag: str
    dental_no_prior_covg_flag: str
    first_name: str
    language_code_1: str
    language_code_desc: str
    t_last_maintenance_timestamp_1: str
    last_name: str
    marital_status_code: str
    marital_status_description: str
    middle_name: str
    name_suffix: str
    nickname: str
    operator_id: str
    person_identifier_1: str
    personal_identifier: str
    sex_code: str
    sex_description: str
    t_social_security_number: str
    title: str
    ethnicity_code: str
    void_flag: str
    t_birth_date: str
    person_name_switch: str
    language_code2_1: str
    language_code_desc2: str
    race_code: str
    customer_courtesy: str


@dataclass
class ExportMemberGImbr1Member(Numerable):
    """Public class which describes dataclass for table ExportMemberGImbr1Member"""

    items: List[ExportMemberGImbr1MemberItem]
    table_name: str = "ExportMemberGImbr1Member"


@dataclass
class ExportStartImbr1Member(Table):
    """Public class which describes dataclass for table ExportStartImbr1Member"""

    member_id: str
    t_end_date: str
    command: str
    t_count: str
    table_name: str = "ExportStartImbr1Member"
