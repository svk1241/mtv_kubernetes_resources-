from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Numerable, Table


class Pmbr1di1MbrMpnaListTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorGImbr1Interface'
        ResponseStatus.table_name = 'ExportImbr1Interface'
        super().__init__(content)
        self.export_g_imbr1_member_prov_association = self._htmlParser.table_to_obj(ExportGImbr1MemberProvAssociation)
        self.export_g_imbr1_member_prov_association.length = self._htmlParser.get_table_length("ExportMpnaGroup", "export_export_mpna_group_length")
        self.export_list_controls_ief_supplied = self._htmlParser.table_to_obj(ExportListControlsIefSupplied, True)


@dataclass
class ExportGImbr1MemberProvAssociationItem:
    """Public class which describes item structure for table ExportGImbr1MemberProvAssociation"""

    provider_identifier: str
    providers_reason_code: str
    continuing_provider_flag: str
    network_identifier: str
    t_effective_date: str
    t_end_date: str
    country_id: str
    pager_pin_id: str
    extension: str
    t_phone_number: str
    last_name: str
    referral_circle_code: str


@dataclass
class ExportGImbr1MemberProvAssociation(Numerable):
    """Public class which describes dataclass for table ExportGImbr1MemberProvAssociation"""

    items: List[ExportGImbr1MemberProvAssociationItem]
    table_name: str = "ExportGImbr1MemberProvAssociation"


@dataclass
class ExportListControlsIefSupplied(Table):
    """Public class which describes dataclass for table ExportListControlsIefSupplied"""

    command: str
    t_count: str
    t_end_date: str
    table_name: str = "ExportListControlsIefSupplied"
