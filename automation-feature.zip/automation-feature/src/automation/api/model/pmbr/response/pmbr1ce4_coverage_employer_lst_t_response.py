from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Numerable, Table


class Pmbr1ce4CoverageEmployerLstTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorsGImbr1Interface'
        ErrorCode.name_length_table = 'ExportErrorsGroup'
        ErrorCode.name_length_field = 'export_export_errors_group_length'
        super().__init__(content, response_status=ResponseStatusExtended)
        self.export_coverage_employer_info_g_imbr1_coverage_employer_info = self._htmlParser.table_to_obj(
            ExportCoverageEmployerInfoGImbr1CoverageEmployerInfo)
        self.export_coverage_employer_info_g_imbr1_coverage_employer_info.length = self._htmlParser.get_table_length(
            "ExportCoverageEmployerGroup", "export_export_coverage_employer_group_length")
        self.export_paging_controls_ief_supplied = self._htmlParser.table_to_obj(ExportPagingControlsIefSupplied, True)
        self.export_coverage_employer_info_imbr1_coverage_employer_info = self._htmlParser.table_to_obj(
            ExportCoverageEmployerInfoImbr1CoverageEmployerInfo, True)


@dataclass
class ExportCoverageEmployerInfoGImbr1CoverageEmployerInfoItem:
    """Public class which describes item structure for table ExportCoverageEmployerInfoGImbr1CoverageEmployerInfo"""

    t_creation_timestamp: str
    t_effective_date: str
    employee_occupation: str
    employer_group_level1_id: str
    employer_group_level2_id: str
    employer_group_level3_id: str
    employer_group_level4_id: str
    employer_reference_identifier: str
    employment_status_code: str
    employment_status_description: str
    t_end_date: str
    t_receipt_date: str
    t_hire_date: str
    t_last_maintenance_timestamp: str
    life_volume: str
    life_volume_source: str
    operator_identifier: str
    override_life_volume: str
    payroll_department_identifier: str
    salary: str
    t_salary_effective_date: str
    void_flag: str


@dataclass
class ExportCoverageEmployerInfoGImbr1CoverageEmployerInfo(Numerable):
    """Public class which describes dataclass for table ExportCoverageEmployerInfoGImbr1CoverageEmployerInfo"""

    items: List[ExportCoverageEmployerInfoGImbr1CoverageEmployerInfoItem]
    table_name: str = "ExportCoverageEmployerInfoGImbr1CoverageEmployerInfo"


@dataclass
class ExportPagingControlsIefSupplied(Table):
    """Public class which describes dataclass for table ExportPagingControlsIefSupplied"""

    command: str
    t_count: str
    table_name: str = "ExportPagingControlsIefSupplied"


@dataclass
class ExportCoverageEmployerInfoImbr1CoverageEmployerInfo(Table):
    """Public class which describes dataclass for table ExportCoverageEmployerInfoImbr1CoverageEmployerInfo"""

    contract_id2: str
    table_name: str = "ExportCoverageEmployerInfoImbr1CoverageEmployerInfo"


@dataclass
class ResponseStatusExtended(Table):
    """Public class which describes dataclass for table ExportIpmf1Interface"""

    severity_code: str
    data_store_status: str
    origin_servid: str
    context_string: str
    return_code: str
    reason_code: str
    checksum: str
    return_address: str
    t_creation_timestamp: str
    t_end_date: str
    void_flag: str
    table_name: str = "ExportImbr1Interface"
