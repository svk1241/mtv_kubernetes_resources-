from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Numerable, Table


class Pmbr1jy3MemberStatusListTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorsGImbr1Interface'
        ErrorCode.name_length_table = 'ExportErrorsGroup'
        ErrorCode.name_length_field = 'export_export_errors_group_length'
        ResponseStatus.table_name = 'ExportImbr1Interface'
        super().__init__(content)
        self.export_member_status_g_imbr1_member_status = self._htmlParser.table_to_obj(ExportMemberStatusGImbr1MemberStatus)
        self.export_member_status_g_imbr1_member_status.length = self._htmlParser.get_table_length("ExportMemberStatusGroup", "export_export_member_status_group_lengt")
        self.export_imbr1_member_status = self._htmlParser.table_to_obj(ExportImbr1MemberStatus, True)


@dataclass
class ExportMemberStatusGImbr1MemberStatusItem:
    """Public class which describes item structure for table ExportMemberStatusGImbr1MemberStatus"""

    member_id: str
    status_code: str
    status_code_report_description: str
    status_type: str
    t_effective_date: str
    t_end_date: str
    t_last_maintenance_timestamp: str
    operator_identifier: str
    t_creation_timestamp: str
    void_flag: str


@dataclass
class ExportMemberStatusGImbr1MemberStatus(Numerable):
    """Public class which describes dataclass for table ExportMemberStatusGImbr1MemberStatus"""

    items: List[ExportMemberStatusGImbr1MemberStatusItem]
    table_name: str = "ExportMemberStatusGImbr1MemberStatus"


@dataclass
class ExportImbr1MemberStatus(Table):
    """Public class which describes dataclass for table ExportImbr1MemberStatus"""

    contract_id2: str
    member_id: str
    status_code: str
    t_effective_date: str
    void_flag: str
    t_creation_timestamp: str
    command: str
    t_count: str
    table_name: str = "ExportImbr1MemberStatus"
