from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.numerable import Numerable, Table


class Pmbr1pm7MemberInfoMaintTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ResponseStatus.table_name = 'ExportImbr1Interface'
        super().__init__(content, error_code=ErrorCodeExtended)
        self.regex_lsttimestamp1 = 't_last_maintenance_timestamp_1'  # TODO: "['export_qualify_imbr1_member']['t_last_maintenance_timestamp_1']"
        self.regex_lsttimestamp = 't_last_maintenance_timestamp'  # TODO: "['export_mbr_eligibility_g_imbr1_member_eligibility']['export_qualify_imbr1_member']['t_last_maintenance_timestamp']"
        self.regex_crttimestamp = 't_creation_timestamp'  # TODO: "['export_mbr_eligibility_g_imbr1_member_eligibility']['t_creation_timestamp']"
        self.regex_identifier = 't_identifier'  # TODO: "['export_mbr_eligibility_g_imbr1_member_eligibility']['t_identifier']"
        self.regex_pidentifier = 'person_identifier'  # TODO: "['export_qualify_imbr1_member']['person_identifier']"
        self.regex_memberid = 'member_id'  # TODO: "['export_qualify_imbr1_member']['member_id']"
        self.regex_adoptiondate = 't_adoption_date'  # TODO: "['export_qualify_imbr1_member']['t_adoption_date']"
        self.regex_trecdate = 't_receipt_date'  # TODO: "['export_mbr_eligibility_g_imbr1_member_eligibility']['export_qualify_imbr1_member']['t_receipt_date']"
        self.export_alt_id_g_imbr1_mbr_alternate_id = self._htmlParser.table_to_obj(ExportAltIdGImbr1MbrAlternateId)
        self.export_alt_id_g_imbr1_mbr_alternate_id.length = self._htmlParser.get_table_length("ExportAltIdGroup", "export_export_alt_id_group_length")
        self.export_status_g_imbr1_member_status = self._htmlParser.table_to_obj(ExportStatusGImbr1MemberStatus)
        self.export_status_g_imbr1_member_status.length = self._htmlParser.get_table_length("ExportStatusGroup", "export_export_status_group_length")
        self.export_mpna_g_imbr1_member_prov_association = self._htmlParser.table_to_obj(ExportMpnaGImbr1MemberProvAssociation)
        self.export_mpna_g_imbr1_member_prov_association.length = self._htmlParser.get_table_length("ExportMpnaGroup", "export_export_mpna_group_length")
        self.export_pre_exist_g_imbr1_pre_exist_cond_wait_pd = self._htmlParser.table_to_obj(ExportPreExistGImbr1PreExistCondWaitPd)
        self.export_pre_exist_g_imbr1_pre_exist_cond_wait_pd.length = self._htmlParser.get_table_length("ExportPreExistGroup", "export_export_pre_exist_group_length")
        self.export_mbr_cov_g_imbr1_member_coverage = self._htmlParser.table_to_obj(ExportMbrCovGImbr1MemberCoverage)
        self.export_mbr_cov_g_imbr1_member_coverage.length = self._htmlParser.get_table_length("ExportMbrCovGroup", "export_export_mbr_cov_group_length")
        self.export_mbr_eligibility_g_imbr1_member_eligibility = self._htmlParser.table_to_obj(ExportMbrEligibilityGImbr1MemberEligibility)
        self.export_mbr_eligibility_g_imbr1_member_eligibility.length = self._htmlParser.get_table_length("ExportMbrEligibilityGroup", "export_export_mbr_eligibility_group_length")
        self.export_history_g_iper1_person_coverage_history = self._htmlParser.table_to_obj(ExportHistoryGIper1PersonCoverageHistory)
        self.export_history_g_iper1_person_coverage_history.length = self._htmlParser.get_table_length("ExportHistoryGroup", "export_export_history_group_length")
        self.export_address_g_iref1_metavance_address_assn = self._htmlParser.table_to_obj(ExportAddressGIref1MetavanceAddressAssn)
        self.export_address_g_iref1_metavance_address_assn.length = self._htmlParser.get_table_length("ExportAddressGroup", "export_export_address_group_length")
        self.export_qualify_imbr1_member = self._htmlParser.table_to_obj(ExportQualifyImbr1Member, True)


@dataclass
class ExportAltIdGImbr1MbrAlternateIdItem:
    """Public class which describes item structure for table ExportAltIdGImbr1MbrAlternateId"""

    alternate_id_type_code: str
    alternate_id_source_code: str
    alternate_id: str
    void_flag: str
    operator_id: str
    t_effective_date: str
    t_end_date: str
    t_creation_timestamp: str
    t_last_maintenance_timestamp: str


@dataclass
class ExportAltIdGImbr1MbrAlternateId(Numerable):
    """Public class which describes dataclass for table ExportAltIdGImbr1MbrAlternateId"""

    items: List[ExportAltIdGImbr1MbrAlternateIdItem]
    table_name: str = "ExportAltIdGImbr1MbrAlternateId"


@dataclass
class ExportStatusGImbr1MemberStatusItem:
    """Public class which describes item structure for table ExportStatusGImbr1MemberStatus"""

    status_code: str
    status_type: str
    t_effective_date: str
    t_end_date: str
    t_last_maintenance_timestamp: str
    operator_identifier: str
    t_creation_timestamp: str
    void_flag: str


@dataclass
class ExportStatusGImbr1MemberStatus(Numerable):
    """Public class which describes dataclass for table ExportStatusGImbr1MemberStatus"""

    items: List[ExportStatusGImbr1MemberStatusItem]
    table_name: str = "ExportStatusGImbr1MemberStatus"


@dataclass
class ExportMpnaGImbr1MemberProvAssociationItem:
    """Public class which describes item structure for table ExportMpnaGImbr1MemberProvAssociation"""

    service_type: str
    pcp_flag: str
    provider_identifier: str
    providers_reason_code: str
    continuing_provider_flag: str
    network_identifier: str
    void_flag: str
    operator_identifier: str
    t_effective_date: str
    t_end_date: str
    t_provider_contract_id: str
    t_last_maintenance_timestamp: str
    t_identifier: str
    t_prov_qualifier_id: str
    t_receipt_date: str


@dataclass
class ExportMpnaGImbr1MemberProvAssociation(Numerable):
    """Public class which describes dataclass for table ExportMpnaGImbr1MemberProvAssociation"""

    items: List[ExportMpnaGImbr1MemberProvAssociationItem]
    table_name: str = "ExportMpnaGImbr1MemberProvAssociation"


@dataclass
class ExportPreExistGImbr1PreExistCondWaitPdItem:
    """Public class which describes item structure for table ExportPreExistGImbr1PreExistCondWaitPd"""

    condition_code: str
    t_effective_date: str
    t_end_date: str
    condition_type: str
    explanation_code: str
    investigation_type_indicator: str
    t_disability_date: str
    accident_claim_bypass_flag: str
    person_prior_covg_reduction_ind: str
    member_eligibility_reduction_ind: str
    t_last_maintenance_timestamp: str
    void_flag: str
    operator_identifier: str
    t_creation_timestamp: str


@dataclass
class ExportPreExistGImbr1PreExistCondWaitPd(Numerable):
    """Public class which describes dataclass for table ExportPreExistGImbr1PreExistCondWaitPd"""

    items: List[ExportPreExistGImbr1PreExistCondWaitPdItem]
    table_name: str = "ExportPreExistGImbr1PreExistCondWaitPd"


@dataclass
class ExportMbrCovGImbr1MemberCoverageItem:
    """Public class which describes item structure for table ExportMbrCovGImbr1MemberCoverage"""

    benefit_package_identifier: str
    operator_identifier: str
    t_member_eligibility_identifier: str
    t_effective_date: str
    t_end_date: str
    t_receipt_date: str
    t_last_maintenance_timestamp: str
    t_creation_timestamp: str


@dataclass
class ExportMbrCovGImbr1MemberCoverage(Numerable):
    """Public class which describes dataclass for table ExportMbrCovGImbr1MemberCoverage"""

    items: List[ExportMbrCovGImbr1MemberCoverageItem]
    table_name: str = "ExportMbrCovGImbr1MemberCoverage"


@dataclass
class ExportMbrEligibilityGImbr1MemberEligibilityItem:
    """Public class which describes item structure for table ExportMbrEligibilityGImbr1MemberEligibility"""

    void_flag: str
    business_level4_id: str
    business_level5_id: str
    business_level6_id: str
    business_level7_id: str
    operator_identifier: str
    type_code: str
    class_code: str
    disenrollment_reason_code: str
    benefit_package_identifier: str
    apply_waiting_period_flag: str
    enrollment_type: str
    timely_enrollment_indicator: str
    special_event_code: str
    discount_identifier: str
    health_saving_acct_vendor_id: str
    flex_spending_acct_vendor_id: str
    health_reimburse_ineligible_fg: str
    user_defined_vendor_id1: str
    user_defined_vendor_id2: str
    t_identifier: str
    t_effective_date: str
    t_end_date: str
    t_creation_timestamp: str
    t_last_maintenance_timestamp: str
    t_eligibility_request_date: str
    t_enrollment_event_date: str
    t_receipt_date: str
    cdh_product_type_cd: str


@dataclass
class ExportMbrEligibilityGImbr1MemberEligibility(Numerable):
    """Public class which describes dataclass for table ExportMbrEligibilityGImbr1MemberEligibility"""

    items: List[ExportMbrEligibilityGImbr1MemberEligibilityItem]
    table_name: str = "ExportMbrEligibilityGImbr1MemberEligibility"


@dataclass
class ExportHistoryGIper1PersonCoverageHistoryItem:
    """Public class which describes item structure for table ExportHistoryGIper1PersonCoverageHistory"""

    other_carrier_identifier: str
    t_effective_date: str
    t_end_date: str
    incomplete_flag: str
    orthodontia_coverage_flag: str
    t_last_maintenance_timestamp: str
    void_flag: str
    operator_identifier: str
    t_creation_timestamp: str


@dataclass
class ExportHistoryGIper1PersonCoverageHistory(Numerable):
    """Public class which describes dataclass for table ExportHistoryGIper1PersonCoverageHistory"""

    items: List[ExportHistoryGIper1PersonCoverageHistoryItem]
    table_name: str = "ExportHistoryGIper1PersonCoverageHistory"


@dataclass
class ExportAddressGIref1MetavanceAddressAssnItem:
    """Public class which describes item structure for table ExportAddressGIref1MetavanceAddressAssn"""

    address_type: str
    address_code: str
    primary_flag: str
    void_flag: str
    operator_identifier: str
    t_address_identifier: str
    t_last_maintenance_timestamp: str
    t_effective_date: str
    t_end_date: str
    t_receipt_date: str
    address1: str
    address2: str
    address3: str
    city: str
    state_code: str
    zip: str
    county_code: str
    country_code: str
    shared_address_flag: str
    address_status_code: str
    t_last_maintenance_timestamp_1: str


@dataclass
class ExportAddressGIref1MetavanceAddressAssn(Numerable):
    """Public class which describes dataclass for table ExportAddressGIref1MetavanceAddressAssn"""

    items: List[ExportAddressGIref1MetavanceAddressAssnItem]
    table_name: str = "ExportAddressGIref1MetavanceAddressAssn"


@dataclass
class ExportQualifyImbr1Member(Table):
    """Public class which describes dataclass for table ExportQualifyImbr1Member"""

    member_id: str
    contract_id3: str
    person_identifier: str
    medical_service_area_code: str
    information: str
    region_code: str
    native_american_identifier: str
    native_american_indicator: str
    internal_case_identifier: str
    member_hardcopy_eob_flag: str
    marital_status_code: str
    language_code: str
    operator_identifier: str
    t_last_maintenance_timestamp: str
    t_adoption_date: str
    t_original_effective_date: str
    t_social_security_number: str
    disease_management_indicator: str
    t_user_defined_date1: str
    incentive_level: str
    language_code2: str
    nickname: str
    sex_code: str
    directive_on_file_flag: str
    medical_no_prior_covg_flag: str
    operator_id: str
    t_death_date: str
    t_last_maintenance_timestamp_1: str
    t_birth_date: str
    t_receipt_date: str
    dental_no_prior_covg_flag: str
    ethnicity_code: str
    race_code: str
    customer_courtesy: str
    complete_last_name: str
    complete_first_name: str
    complete_middle_name: str
    complete_person_title: str
    complete_name_suffix: str
    table_name: str = "ExportQualifyImbr1Member"


@dataclass
class ErrorCodeItemExtended:
    """Public class which describes item structure for table ExportErrorGImbr1Interface"""

    error_code: str
    error_record_type: str
    t_error_occurrence: str


@dataclass
class ErrorCodeExtended(Numerable):
    """Public class which describes dataclass for table ExportErrorGImbr1Interface"""

    items: List[ErrorCodeItemExtended]
    table_name: str = "ExportErrorGImbr1Interface"
    name_length_table: str = "ExportErrorGroup"
    name_length_field: str = "export_export_error_group_length"
