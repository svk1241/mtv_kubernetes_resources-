from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode


class Pmbr1ct2ContractTermTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorsGImbr1Interface'
        ErrorCode.name_length_table = 'ExportErrorsGroup'
        ErrorCode.name_length_field = 'export_export_errors_group_length'
        ResponseStatus.table_name = 'ExportImbr1Interface'
        super().__init__(content)
