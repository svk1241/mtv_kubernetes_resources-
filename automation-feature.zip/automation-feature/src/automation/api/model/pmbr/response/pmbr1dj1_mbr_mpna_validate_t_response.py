from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Table


class Pmbr1dj1MbrMpnaValidateTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorGImbr1Interface'
        ResponseStatus.table_name = 'ExportImbr1Interface'
        super().__init__(content)
        self.export_iprv1_provider = self._htmlParser.table_to_obj(ExportIprv1Provider, True)


@dataclass
class ExportIprv1Provider(Table):
    """Public class which describes dataclass for table ExportIprv1Provider"""

    last_name: str
    table_name: str = "ExportIprv1Provider"
