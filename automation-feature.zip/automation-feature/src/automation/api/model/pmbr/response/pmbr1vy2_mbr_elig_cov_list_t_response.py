from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Numerable, Table


class Pmbr1vy2MbrEligCovListTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportGErrorImbr1Interface'
        super().__init__(content, response_status=ResponseStatusExtended)
        self.export_g_imbr1_member_eligibility = self._htmlParser.table_to_obj(ExportGImbr1MemberEligibility)
        self.export_g_imbr1_member_eligibility.length = self._htmlParser.get_table_length("ExportGroupMemberEligibility",
                                                                                          "export_export_group_member_eligibility_length")
        self.export_g_imbr1_member_coverage = self._htmlParser.table_to_obj(ExportGImbr1MemberCoverage)
        self.export_g_imbr1_member_coverage.length = self._htmlParser.get_table_length("ExportGroupMemberCoverage",
                                                                                       "export_export_group_member_coverage_length")
        self.export_start_imbr1_member_eligibility = self._htmlParser.table_to_obj(ExportStartImbr1MemberEligibility, True)


@dataclass
class ExportGImbr1MemberEligibilityItem:
    """Public class which describes item structure for table ExportGImbr1MemberEligibility"""

    t_identifier: str
    t_effective_date: str
    t_end_date: str
    business_level_quick_id: str
    business_level4_id: str
    business_level5_id: str
    business_level6_id: str
    business_level7_id: str
    type_code: str
    type_code_description: str
    class_code: str
    class_code_description: str
    disenrollment_reason_code: str
    disenrollment_reason_description: str
    benefit_package_identifier: str
    benefit_package_description: str
    apply_waiting_period_flag: str
    enrollment_type: str
    t_eligibility_request_date: str
    t_enrollment_event_date: str
    timely_enrollment_indicator: str
    special_event_code: str
    special_event_code_description: str
    t_receipt_date: str
    health_saving_acct_vendor_id: str
    flex_spending_acct_vendor_id: str
    health_reimburse_ineligible_fg: str
    user_defined_vendor_id1: str
    user_defined_vendor_id2: str
    discount_identifier: str
    void_flag: str
    operator_identifier: str
    cdh_product_type_cd: str
    t_last_maintenance_timestamp: str
    t_creation_timestamp: str
    t_count: str


@dataclass
class ExportGImbr1MemberEligibility(Numerable):
    """Public class which describes dataclass for table ExportGImbr1MemberEligibility"""

    items: List[ExportGImbr1MemberEligibilityItem]
    table_name: str = "ExportGImbr1MemberEligibility"


@dataclass
class ExportGImbr1MemberCoverageItem:
    """Public class which describes item structure for table ExportGImbr1MemberCoverage"""

    t_member_eligibility_identifier: str
    benefit_package_identifier: str
    benefit_package_type_code: str
    t_effective_date: str
    t_end_date: str
    t_receipt_date: str
    void_flag: str
    operator_identifier: str
    t_last_maintenance_timestamp: str
    t_creation_timestamp: str


@dataclass
class ExportGImbr1MemberCoverage(Numerable):
    """Public class which describes dataclass for table ExportGImbr1MemberCoverage"""

    items: List[ExportGImbr1MemberCoverageItem]
    table_name: str = "ExportGImbr1MemberCoverage"


@dataclass
class ExportStartImbr1MemberEligibility(Table):
    """Public class which describes dataclass for table ExportStartImbr1MemberEligibility"""

    t_end_date: str
    void_flag: str
    t_identifier: str
    t_count: str
    command: str
    count: str
    table_name: str = "ExportStartImbr1MemberEligibility"


@dataclass
class ResponseStatusExtended(Table):
    """Public class which describes dataclass for table ExportImst1Interface"""

    severity_code: str
    context_string: str
    return_code: str
    reason_code: str
    checksum: str
    return_address: str
    table_name: str = "ExportImbr1Interface"
