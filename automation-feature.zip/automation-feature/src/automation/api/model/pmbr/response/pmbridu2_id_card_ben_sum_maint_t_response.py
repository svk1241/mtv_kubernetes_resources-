from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Table


class Pmbridu2IdCardBenSumMaintTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportGImbr1Interface'
        ResponseStatus.table_name = 'ExportImbr1Interface'
        ErrorCode.name_length_table = 'ExportErrorsGroup'
        ErrorCode.name_length_field = 'export_export_errors_group_length'
        self.regex_latesttimestamp = 't_last_maintenance_timestamp'
        self.regex_creationtimestamp = 't_creation_timestamp'
        super().__init__(content)
        self.export_imbr1_id_card_request = self._htmlParser.table_to_obj(ExportImbr1IdCardRequest, True)


@dataclass
class ExportImbr1IdCardRequest(Table):
    """Public class which describes dataclass for table ExportImbr1IdCardRequest"""

    coverage_contract_identifier: str
    member_id: str
    employer_group_level1_id: str
    employer_group_level2_id: str
    request_level: str
    request_type: str
    id_card_format: str
    materials_pkg_code: str
    request_reason_indicator: str
    issue_card_code: str
    network_identifier: str
    held_flag: str
    override_hold_flag: str
    benefit_package_identifier: str
    void_flag: str
    operator_identifier: str
    t_request_effective_date: str
    t_cards_produced_count: str
    t_issue_date: str
    t_requested_date: str
    t_last_maintenance_timestamp: str
    t_creation_timestamp: str
    table_name: str = "ExportImbr1IdCardRequest"
