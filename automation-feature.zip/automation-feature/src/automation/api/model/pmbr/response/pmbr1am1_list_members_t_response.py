from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Numerable, Table


class Pmbr1am1ListMembersTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorGImbr1Interface'
        ResponseStatus.table_name = 'ExportImbr1Interface'
        super().__init__(content)
        self.export_list_controls_ief_supplied_text = self._htmlParser.table_to_obj(ExportListControlsIefSuppliedText, True)
        self.export_member_g_ihme1_subscriber_lvl = self._htmlParser.table_to_obj(ExportMemberGIhme1SubscriberLvl)
        self.export_member_g_ihme1_subscriber_lvl.length = self._htmlParser.get_table_length("ExportMembersGroup", "export_export_members_group_length")


@dataclass
class ExportListControlsIefSuppliedText(Table):
    """Public class .."""

    t_count: str
    table_name: str = 'ExportListControlsIefSuppliedText'


@dataclass
class ExportMemberGIhme1SubscriberLvlItem:
    """Public class .."""

    ref02_subid_subscriber_id: str
    ref02_mbrid_subscriber_sup_id: str
    coverage_contract_holder_flag: str


@dataclass
class ExportMemberGIhme1SubscriberLvl(Numerable):
    """Public class .."""

    items: List[ExportMemberGIhme1SubscriberLvlItem]
    table_name: str = 'ExportMemberGIhme1SubscriberLvl'
