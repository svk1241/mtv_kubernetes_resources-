from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Table


class Pmbr1ju1MemberStatusMaintTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorsGImbr1Interface'
        ErrorCode.name_length_table = 'ExportErrorsGroup'
        ErrorCode.name_length_field = 'export_export_errors_group_length'
        ResponseStatus.table_name = 'ExportImbr1Interface'
        super().__init__(content)
        self.regex_lsttimestamp = 't_last_maintenance_timestamp'
        self.regex_enddate = 't_end_date'
        self.regex_crttimestamp = 't_creation_timestamp'
        self.regex_effectdate = 't_effective_date'
        self.export_imbr1_member_status = self._htmlParser.table_to_obj(ExportImbr1MemberStatus, True)


@dataclass
class ExportImbr1MemberStatus(Table):
    """Public class which describes dataclass for table ExportImbr1MemberStatus"""

    contract_id2: str
    member_id: str
    status_code: str
    status_type: str
    t_effective_date: str
    t_end_date: str
    t_last_maintenance_timestamp: str
    operator_identifier: str
    t_creation_timestamp: str
    void_flag: str
    table_name: str = "ExportImbr1MemberStatus"
