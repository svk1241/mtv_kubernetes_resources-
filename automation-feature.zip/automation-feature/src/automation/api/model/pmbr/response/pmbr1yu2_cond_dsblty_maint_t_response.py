from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Table


class Pmbr1yu2CondDsbltyMaintTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        self.regex_timestamp = '.+timestamp'
        self.regex_date = '.+date'
        ErrorCode.table_name = 'ExportErrorGImbr1Interface'
        ResponseStatus.table_name = 'ExportImbr1Interface'
        super().__init__(content)
        self.export_imbr1_pre_exist_cond_wait_pd = self._htmlParser.table_to_obj(ExportImbr1PreExistCondWaitPd, True)


@dataclass
class ExportImbr1PreExistCondWaitPd(Table):
    """Public class which describes dataclass for table ExportImbr1PreExistCondWaitPd"""

    contract_id2: str
    member_id: str
    condition_code: str
    void_flag: str
    condition_type: str
    explanation_code: str
    investigation_type_indicator: str
    accident_claim_bypass_flag: str
    operator_identifier: str
    person_prior_covg_reduction_ind: str
    member_eligibility_reduction_ind: str
    t_effective_date: str
    t_end_date: str
    t_disability_date: str
    t_last_maintenance_timestamp: str
    t_creation_timestamp: str
    provider_id: str
    table_name: str = "ExportImbr1PreExistCondWaitPd"
