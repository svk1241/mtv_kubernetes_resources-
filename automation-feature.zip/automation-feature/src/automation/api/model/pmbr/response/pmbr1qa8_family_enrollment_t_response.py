from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.numerable import Numerable, Table


class Pmbr1qa8FamilyEnrollmentTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ResponseStatus.table_name = 'ExportImbr1Interface'
        self.regex_timestamp = '.+timestamp'
        self.regex_contractid = '.+contract_id2'
        self.regex_receiptdate = 't_receipt_date'
        super().__init__(content, error_code=ErrorCodeExtended)
        self.export_g_imbr1_life_vol_info = self._htmlParser.table_to_obj(ExportGImbr1LifeVolInfo)
        self.export_g_imbr1_life_vol_info.length = self._htmlParser.get_table_length("ExportMbrlifVolumeGroup", "export_export_mbrlif_volume_group_length")
        self.export_g_imbr1_member_coverage = self._htmlParser.table_to_obj(ExportGImbr1MemberCoverage)
        self.export_g_imbr1_member_coverage.length = self._htmlParser.get_table_length("ExportMbrCovgGroup", "export_export_mbr_covg_group_length")
        self.export_psn_cvg_hstry_g_imbr1_member = self._htmlParser.table_to_obj(ExportPsnCvgHstryGImbr1Member)
        self.export_psn_cvg_hstry_g_imbr1_member.length = self._htmlParser.get_table_length("ExportPsnCvgHstryGroup", "export_export_psn_cvg_hstry_group_length")
        self.export_g_iper1_person = self._htmlParser.table_to_obj(ExportGIper1Person)
        self.export_g_iper1_person.length = self._htmlParser.get_table_length("ExportMemberGroup", "export_export_member_group_length")
        self.export_imbr1_coverage_type_span = self._htmlParser.table_to_obj(ExportImbr1CoverageTypeSpan, True)


@dataclass
class ExportGImbr1LifeVolInfoItem:
    """Public class which describes item structure for table ExportGImbr1LifeVolInfo"""

    member_id: str
    volume_type: str
    operator_identifier: str
    void_flag: str
    t_effective_date: str
    t_end_date: str
    t_volume_amount: str
    t_age_reduction_level: str
    t_original_volume_amount: str
    t_date_of_birth: str
    t_last_maintenance_timestamp: str
    override_volume_flag: str


@dataclass
class ExportGImbr1LifeVolInfo(Numerable):
    """Public class which describes dataclass for table ExportGImbr1LifeVolInfo"""

    items: List[ExportGImbr1LifeVolInfoItem]
    table_name: str = "ExportGImbr1LifeVolInfo"


@dataclass
class ExportGImbr1MemberCoverageItem:
    """Public class which describes item structure for table ExportGImbr1MemberCoverage"""

    member_id: str
    benefit_package_identifier: str
    benefit_package_type_code: str
    void_flag: str
    operator_identifier: str
    t_effective_date: str
    t_end_date: str
    t_receipt_date: str
    t_last_maintenance_timestamp: str


@dataclass
class ExportGImbr1MemberCoverage(Numerable):
    """Public class which describes dataclass for table ExportGImbr1MemberCoverage"""

    items: List[ExportGImbr1MemberCoverageItem]
    table_name: str = "ExportGImbr1MemberCoverage"


@dataclass
class ExportPsnCvgHstryGImbr1MemberItem:
    """Public class which describes item structure for table ExportPsnCvgHstryGImbr1Member"""

    member_id: str
    person_identifier: str
    other_carrier_identifier: str
    t_effective_date: str
    t_end_date: str
    incomplete_flag: str
    orthodontia_coverage_flag: str
    operator_identifier: str
    t_last_maintenance_timestamp: str


@dataclass
class ExportPsnCvgHstryGImbr1Member(Numerable):
    """Public class which describes dataclass for table ExportPsnCvgHstryGImbr1Member"""

    items: List[ExportPsnCvgHstryGImbr1MemberItem]
    table_name: str = "ExportPsnCvgHstryGImbr1Member"


@dataclass
class ExportGIper1PersonItem:
    """Public class which describes item structure for table ExportGIper1Person"""

    person_identifier: str
    complete_last_name: str
    complete_first_name: str
    complete_middle_name: str
    complete_person_title: str
    complete_name_suffix: str
    nickname: str
    sex_code: str
    directive_on_file_flag: str
    operator_id: str
    ethnicity_code: str
    race_code: str
    customer_courtesy: str
    t_death_date: str
    t_last_maintenance_timestamp: str
    t_birth_date: str
    t_social_security_number: str
    t_receipt_date: str
    member_id: str
    medical_service_area_code: str
    information: str
    region_code: str
    native_american_identifier: str
    native_american_indicator: str
    internal_case_identifier: str
    member_hardcopy_eob_flag: str
    marital_status_code: str
    language_code: str
    operator_identifier: str
    contract_id3: str
    t_adoption_date: str
    t_original_effective_date: str
    t_last_maintenance_timestamp_1: str
    disease_management_indicator: str
    t_user_defined_date1: str
    incentive_level: str
    language_code2: str
    business_level4_id: str
    business_level5_id: str
    business_level6_id: str
    business_level7_id: str
    operator_identifier_1: str
    type_code: str
    class_code: str
    disenrollment_reason_code: str
    benefit_package_identifier: str
    apply_waiting_period_flag: str
    enrollment_type: str
    timely_enrollment_indicator: str
    special_event_code: str
    t_identifier: str
    t_effective_date: str
    t_end_date: str
    t_last_maintenance_timestamp_2: str
    t_eligibility_request_date: str
    t_enrollment_event_date: str
    t_receipt_date_1: str
    discount_identifier: str
    health_saving_acct_vendor_id: str
    flex_spending_acct_vendor_id: str
    health_reimburse_ineligible_fg: str
    user_defined_vendor_id1: str
    user_defined_vendor_id2: str
    cdh_product_type_cd: str
    address_type: str
    address_code: str
    primary_flag: str
    void_flag: str
    operator_identifier_2: str
    t_address_identifier: str
    t_last_maintenance_timestamp_3: str
    t_effective_date_1: str
    t_end_date_1: str
    t_receipt_date_2: str
    address1: str
    address2: str
    address3: str
    city: str
    state_code: str
    zip: str
    county_code: str
    country_code: str
    shared_address_flag: str
    t_last_maintenance_timestamp_4: str
    address_status_code: str
    geo_code: str
    service_type: str
    member_id_1: str
    pcp_flag: str
    provider_identifier: str
    providers_reason_code: str
    continuing_provider_flag: str
    network_identifier: str
    void_flag_1: str
    operator_identifier_3: str
    t_effective_date_2: str
    t_end_date_2: str
    t_prov_qualifier_id: str
    t_business_lvl_contract_assn_id: str
    t_provider_contract_id: str
    t_last_maintenance_timestamp_5: str
    t_receipt_date_3: str
    t_identifier_1: str
    override_cutoff_flag: str
    override_capacity_flag: str
    group_provider_id: str
    provider_organization_id: str
    practice_location_id: str
    prov_group_match_on_spaces_flg: str
    provider_org_match_on_spaces_flg: str
    practice_loc_match_on_spaces_flg: str
    alternate_id_type_code: str
    alternate_id_source_code: str
    alternate_id: str
    operator_id_1: str
    t_effective_date_3: str
    t_end_date_3: str
    t_last_maintenance_timestamp_6: str


@dataclass
class ExportGIper1Person(Numerable):
    """Public class which describes dataclass for table ExportGIper1Person"""

    items: List[ExportGIper1PersonItem]
    table_name: str = "ExportGIper1Person"


@dataclass
class ExportImbr1CoverageTypeSpan(Table):
    """Public class which describes dataclass for table ExportImbr1CoverageTypeSpan"""

    contract_id2: str
    contract_type_code: str
    disenrollment_reason_code: str
    rate_package_identifier_code: str
    business_level4_id: str
    business_level5_id: str
    business_level6_id: str
    business_level7_id: str
    employer_group_level1_id: str
    employer_group_level2_id: str
    enrollment_type: str
    special_event_code: str
    timely_enrollment_indicator: str
    qualifying_event_code: str
    employment_class_code: str
    void_flag: str
    operator_identifier: str
    t_effective_date: str
    t_end_date: str
    t_coverage_request_date: str
    t_notification_date: str
    t_enrollment_date: str
    t_last_maintenance_timestamp: str
    t_receipt_date: str
    t_effective_date_1: str
    t_end_date_1: str
    employer_reference_identifier: str
    payroll_department_identifier: str
    t_hire_date: str
    t_salary: str
    t_salary_effective_date: str
    employment_status_code: str
    employee_occupation: str
    t_life_volume: str
    t_override_life_volume: str
    contract_id2_1: str
    void_flag_1: str
    t_last_maintenance_timestamp_1: str
    operator_identifier_1: str
    t_receipt_date_1: str
    table_name: str = "ExportImbr1CoverageTypeSpan"


@dataclass
class ErrorCodeItemExtended:
    """Public class which describes item structure for table ExportErrorsGImbr1Interface"""

    error_code: str
    t_error_occurrence: str
    error_record_type: str


@dataclass
class ErrorCodeExtended(Numerable):
    """Public class which describes dataclass for table ExportErrorsGImbr1Interface"""

    items: List[ErrorCodeItemExtended]
    table_name: str = "ExportErrorsGImbr1Interface"
    name_length_table: str = "ExportErrorsGroup"
    name_length_field: str = "export_export_errors_group_length"
