from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Table, Numerable


class Pmbr1yl1CondDsbltyListTResponse(BaseResponseModel):
    """Public class .."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportGErrorsImbr1Interface'
        ErrorCode.name_length_table = 'ExportGroupErrors'
        ErrorCode.name_length_field = 'export_export_group_errors_length'
        ResponseStatus.table_name = 'ExportImbr1Interface'
        super().__init__(content)
        self.export_g_imbr1_pre_exist_cond_wait_pd = self._htmlParser.table_to_obj(ExportGImbr1PreExistCondWaitPd)
        self.export_g_imbr1_pre_exist_cond_wait_pd.length = self._htmlParser.get_table_length("ExportConditionsGroup", "export_export_conditions_group_length")
        self.export_member_imbr1_pre_exist_cond_wait_pd = self._htmlParser.table_to_obj(ExportMemberImbr1PreExistCondWaitPd, True)


@dataclass
class ExportGImbr1PreExistCondWaitPdItem:
    """Public class .."""

    condition_code: str
    void_flag: str
    condition_type: str
    explanation_code: str
    investigation_type_indicator: str
    accident_claim_bypass_flag: str
    operator_identifier: str
    person_prior_covg_reduction_ind: str
    member_eligibility_reduction_ind: str
    explanation_code_description: str
    condition_code_description: str
    t_effective_date: str
    t_end_date: str
    t_disability_date: str
    t_last_maintenance_timestamp: str
    t_creation_timestamp: str
    table_name: str = 'ExportGImbr1PreExistCondWaitPdItem'


@dataclass
class ExportGImbr1PreExistCondWaitPd(Numerable):
    """Public class .."""

    items: List[ExportGImbr1PreExistCondWaitPdItem]
    table_name: str = 'ExportGImbr1PreExistCondWaitPd'


@dataclass
class ExportMemberImbr1PreExistCondWaitPd(Table):
    """Public class .."""

    contract_id2: str
    member_id: str
    condition_code: str
    void_flag: str
    condition_type: str
    t_end_date: str
    t_creation_timestamp: str
    t_count: str
    command: str
    table_name: str = 'ExportMemberImbr1PreExistCondWaitPd'
