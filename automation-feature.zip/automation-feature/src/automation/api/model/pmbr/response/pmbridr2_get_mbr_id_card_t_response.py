from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Numerable, Table


class Pmbridr2GetMbrIdCardTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorGIsec1Interface'
        ResponseStatus.table_name = 'ExportIsec1Interface'
        super().__init__(content)
        self.export_imbr1_member = self._htmlParser.table_to_obj(ExportImbr1Member)
        self.export_imbr1_member.length = self._htmlParser.get_table_length("ExportImbr1Member", "export_export_imbr1_member_length")
        self.export_g_dental_imbr1_id_card = self._htmlParser.table_to_obj(ExportGDentalImbr1IdCardRequest)
        self.export_g_dental_imbr1_id_card.length = self._htmlParser.get_table_length("ExportGDentalImbr1IdCardRequest", "export_export_g_dental_imbr1_id_card_request_length")
        self.export_g_carrier_imbr1_id_card = self._htmlParser.table_to_obj(ExportGCarrierImbr1IdCardRequest)
        self.export_g_carrier_imbr1_id_card.length = self._htmlParser.get_table_length("ExportGCarrierImbr1IdCardRequest", "export_export_g_carrier_imbr1_id_card_request_length")
        self.view_data = self._htmlParser.table_to_obj(ViewData, True)
        self.export_dental_message_group = self._htmlParser.table_to_obj(ExportDentalMessageGroup, True)
        self.export_result_imbr1_member = self._htmlParser.table_to_obj(ExportResultImbr1Member, True)
        self.export_carrier_message_group = self._htmlParser.table_to_obj(ExportCarrierMessageGroup, True)
        self.export_member_group = self._htmlParser.table_to_obj(ExportMemberGroup, True)


@dataclass
class ExportImbr1MemberItem:
    """Public class which describes item structure for table ExportImbr1Member"""

    member_id: str
    complete_last_name: str
    complete_first_name: str
    t_birth_date: str


@dataclass
class ExportImbr1Member(Numerable):
    """Public class which describes dataclass for table ExportImbr1Member"""

    items: List[ExportImbr1MemberItem]
    table_name: str = "ExportImbr1Member"


@dataclass
class ExportGDentalImbr1IdCardRequestItem:
    """Public class which describes item structure for table ExportGDentalImbr1IdCardRequest"""

    id_card_message: str


@dataclass
class ExportGDentalImbr1IdCardRequest(Numerable):
    """Public class which describes dataclass for table ExportGDentalImbr1IdCardRequest"""

    items: List[ExportGDentalImbr1IdCardRequestItem]
    table_name: str = "ExportGDentalImbr1IdCardRequest"


@dataclass
class ExportGCarrierImbr1IdCardRequestItem:
    """Public class which describes item structure for table ExportGCarrierImbr1IdCardRequest"""

    id_card_message: str


@dataclass
class ExportGCarrierImbr1IdCardRequest(Numerable):
    """Public class which describes dataclass for table ExportGCarrierImbr1IdCardRequest"""

    items: List[ExportGCarrierImbr1IdCardRequestItem]
    table_name: str = "ExportGCarrierImbr1IdCardRequest"


@dataclass
class ViewData(Table):
    """Public class which describes dataclass for table View Data"""

    table_name: str = "View Data"


@dataclass
class ExportDentalMessageGroup(Table):
    """Public class which describes dataclass for table ExportDentalMessageGroup"""

    export_export_dental_message_group_length: str
    table_name: str = "ExportDentalMessageGroup"


@dataclass
class ExportResultImbr1Member(Table):
    """Public class which describes dataclass for table ExportResultImbr1Member"""

    contract_id3: str
    member_id: str
    medical_service_area_code: str
    medical_service_area_code_desc: str
    t_birth_date: str
    complete_first_name: str
    complete_middle_name: str
    complete_last_name: str
    complete_person_title: str
    complete_name_suffix: str
    group_provider_id: str
    network_identifier: str
    network_name: str
    provider_address1: str
    provider_address2: str
    provider_address3: str
    provider_city: str
    provider_identifier: str
    provider_name: str
    provider_role_code: str
    provider_role_code_description: str
    provider_state_code: str
    t_provider_contract_id: str
    t_provider_phone_number: str
    t_provider_zip: str
    t_prov_qualifier_id: str
    business_level4_id: str
    business_level4_name: str
    business_level5_id: str
    business_level5_name: str
    business_level6_id: str
    business_level6_name: str
    business_level7_id: str
    business_level7_name: str
    class_code: str
    class_code_description: str
    benefit_package_identifier: str
    benefit_package_description: str
    t_effective_date: str
    t_end_date: str
    employer_group_level1_id: str
    employer_group_level2_id: str
    employer_group_level2_name: str
    employer_group_level1_name: str
    alternate_id: str
    t_primary_customer_service_phone: str
    t_primary_mental_health_phone: str
    table_name: str = "ExportResultImbr1Member"


@dataclass
class ExportCarrierMessageGroup(Table):
    """Public class which describes dataclass for table ExportCarrierMessageGroup"""

    export_export_carrier_message_group_length: str
    table_name: str = "ExportCarrierMessageGroup"


@dataclass
class ExportMemberGroup(Table):
    """Public class which describes dataclass for table ExportMemberGroup"""

    export_export_member_group_length: str
    table_name: str = "ExportMemberGroup"