from typing import List
from dataclasses import dataclass

from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Numerable, Table


class Pmbr1dl4ListMemberNetworksTResponse(BaseResponseModel):
    """Public class .."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = "ExportErrorsGImbr1Interface"
        ResponseStatus.table_name = "ExportImbr1Interface"
        super().__init__(content)
        self.export_member_network_g_imbr1_member_prov_association = self._htmlParser.table_to_obj(ExportMemberNetworkGImbr1MemberProvAssociation)
        self.export_i_mbr1_member_prov_association = self._htmlParser.table_to_obj(ExportImbr1MemberProvAssociation, True)
        self.export_start_i_mbr1_member_prov_association = self._htmlParser.table_to_obj(ExportStartImbr1MemberProvAssociation, True)
        self.export_member_network_g_imbr1_member_prov_association.length = self._htmlParser.get_table_length("ExportMemberNetworkGroup", "export_export_member_network_group_length")


@dataclass
class ExportMemberNetworkGImbr1MemberProvAssociationItem:
    """Public class .."""

    t_identifier: str
    service_type: str
    pcp_flag: str
    provider_identifier: str
    t_prov_qualifier_id: str
    t_effective_date: str
    t_end_date: str
    providers_reason_code: str
    continuing_provider_flag: str
    network_identifier: str
    t_business_lvl_contract_assn_id: str
    t_provider_contract_id: str
    t_receipt_date: str
    void_flag: str
    operator_identifier: str
    t_creation_timestamp: str
    t_last_maintenance_timestamp: str
    providers_reason_cd_description: str
    provider_category: str
    provider_category_description: str
    provider_name: str
    provider_role_code: str
    provider_role_code_description: str
    network_name: str
    business_level4_id: str
    business_level5_id: str
    business_level6_id: str
    business_level7_id: str
    business_level_quick_id: str
    group_provider_id: str
    provider_organization_id: str
    practice_location_id: str
    override_cutoff_flag: str
    override_capacity_flag: str
    network_id_bus_lvl_contr_assn: str


@dataclass
class ExportMemberNetworkGImbr1MemberProvAssociation(Numerable):
    """Public class .."""

    items: List[ExportMemberNetworkGImbr1MemberProvAssociationItem]
    table_name: str = 'ExportMemberNetworkGImbr1MemberProvAssociation'


@dataclass
class ExportStartImbr1MemberProvAssociation(Table):
    """Public class .."""

    t_identifier: str
    service_type: str
    pcp_flag: str
    provider_identifier: str
    t_end_date: str
    network_identifier: str
    void_flag: str
    t_count: str
    command: str
    table_name: str = 'ExportStartImbr1MemberProvAssociation'


@dataclass
class ExportImbr1MemberProvAssociation(Table):
    """Public class .."""

    contract_id3: str
    member_id: str
    table_name: str = 'ExportImbr1MemberProvAssociation'
