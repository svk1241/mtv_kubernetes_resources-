from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Table


class Pmbrcnu3MbrshpContactMaintTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorGImbr1Interface'
        ResponseStatus.table_name = 'ExportImbr1Interface'
        super().__init__(content)
        self.regex_lsttimestamp = 't_last_maintenance_timestamp'
        self.regex_crttimestamp = 't_creation_timestamp'
        self.regex_identifier = 't_identifier'
        self.export_iref1_metavance_contact = self._htmlParser.table_to_obj(ExportIref1MetavanceContact, True)


@dataclass
class ExportIref1MetavanceContact(Table):
    """Public class which describes dataclass for table ExportIref1MetavanceContact"""

    who_type_indicator: str
    who_identifier2: str
    t_identifier: str
    complete_last_name: str
    complete_first_name: str
    complete_middle_name: str
    complete_contact_title: str
    complete_name_suffix: str
    contact_type_code: str
    role: str
    t_last_maintenance_timestamp: str
    contact_category_code: str
    rate_package_code: str
    from_alpha: str
    to_alpha: str
    void_flag: str
    operator_identifier: str
    t_creation_timestamp: str
    who_identifier3: str
    address1: str
    address2: str
    address3: str
    city: str
    state_code: str
    zip: str
    county_code: str
    country_code: str
    t_last_maintenance_timestamp_1: str
    electronic_address: str
    t_last_maintenance_timestamp_2: str
    t_phone_number: str
    country_id: str
    pager_pin_id: str
    extension: str
    t_last_maintenance_timestamp_3: str
    table_name: str = "ExportIref1MetavanceContact"
