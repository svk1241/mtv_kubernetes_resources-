from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Numerable, Table


class Pmbrcnl3MbrshpContactListTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorGImbr1Interface'
        ResponseStatus.table_name = 'ExportImbr1Interface'
        super().__init__(content)
        self.export_g_iref1_metavance_contact = self._htmlParser.table_to_obj(ExportGIref1MetavanceContact)
        self.export_g_iref1_metavance_contact.length = self._htmlParser.get_table_length("ExportGroupContactData", "export_export_group_contact_data_length")
        self.export_list_controls_ief_supplied = self._htmlParser.table_to_obj(ExportListControlsIefSupplied, True)
        self.export_start_iref1_metavance_contact = self._htmlParser.table_to_obj(ExportStartIref1MetavanceContact, True)


@dataclass
class ExportGIref1MetavanceContactItem:
    """Public class which describes item structure for table ExportGIref1MetavanceContact"""

    complete_last_name: str
    complete_first_name: str
    complete_middle_name: str
    complete_contact_title: str
    complete_name_suffix: str
    who_type_indicator: str
    who_identifier2: str
    t_identifier: str
    contact_type_code: str
    contact_type_code_description: str
    role: str
    t_effective_date: str
    t_end_date: str
    operator_identifier: str
    t_last_maintenance_timestamp: str
    who_identifier3: str
    t_identifier_1: str
    address1: str
    address2: str
    address3: str
    city: str
    state_code: str
    zip: str
    county_code: str
    county_code_description: str
    country_code: str
    operator_identifier_1: str
    t_last_maintenance_timestamp_1: str
    t_identifier_2: str
    electronic_address_code: str
    electronic_address: str
    operator_identifier_2: str
    t_last_maintenance_timestamp_2: str
    t_identifier_3: str
    phone_code: str
    country_id: str
    t_phone_number: str
    pager_pin_id: str
    extension: str
    operator_identifier_3: str
    t_last_maintenance_timestamp_3: str


@dataclass
class ExportGIref1MetavanceContact(Numerable):
    """Public class which describes dataclass for table ExportGIref1MetavanceContact"""

    items: List[ExportGIref1MetavanceContactItem]
    table_name: str = "ExportGIref1MetavanceContact"


@dataclass
class ExportListControlsIefSupplied(Table):
    """Public class which describes dataclass for table ExportListControlsIefSupplied"""

    command: str
    t_count: str
    table_name: str = "ExportListControlsIefSupplied"


@dataclass
class ExportStartIref1MetavanceContact(Table):
    """Public class which describes dataclass for table ExportStartIref1MetavanceContact"""

    contact_type_code: str
    t_effective_date: str
    t_identifier: str
    complete_last_name: str
    table_name: str = "ExportStartIref1MetavanceContact"
