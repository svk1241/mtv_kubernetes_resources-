from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Numerable, Table


class Pmbr1ul1MbrAltIdListTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorGImbr1Interface'
        ResponseStatus.table_name = 'ExportImbr1Interface'
        super().__init__(content)
        self.export_g_imbr1_mbr_alternate_id = self._htmlParser.table_to_obj(ExportGImbr1MbrAlternateId)
        self.export_g_imbr1_mbr_alternate_id.length = self._htmlParser.get_table_length("ExportGroup", "export_export_group_length")
        self.export_start_imbr1_mbr_alternate_id = self._htmlParser.table_to_obj(ExportStartImbr1MbrAlternateId, True)


@dataclass
class ExportGImbr1MbrAlternateIdItem:
    """Public class which describes item structure for table ExportGImbr1MbrAlternateId"""

    alternate_id: str
    alternate_id_type_code: str
    alternate_id_source_code: str
    void_flag: str
    t_effective_date: str
    t_end_date: str
    t_creation_timestamp: str
    operator_id: str
    t_last_maintenance_timestamp: str


@dataclass
class ExportGImbr1MbrAlternateId(Numerable):
    """Public class which describes dataclass for table ExportGImbr1MbrAlternateId"""

    items: List[ExportGImbr1MbrAlternateIdItem]
    table_name: str = "ExportGImbr1MbrAlternateId"


@dataclass
class ExportStartImbr1MbrAlternateId(Table):
    """Public class which describes dataclass for table ExportStartImbr1MbrAlternateId"""

    alternate_id: str
    alternate_id_type_code: str
    void_flag: str
    t_effective_date: str
    t_creation_timestamp: str
    t_count: str
    command: str
    table_name: str = "ExportStartImbr1MbrAlternateId"
