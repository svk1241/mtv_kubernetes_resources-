from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbrcnl3MbrshpContactListTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportImbr1InterfaceSecurityId = ''
    ImportImportImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceRequestorId = ''
    ImportImportImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceReturnAddress = ''
    ImportImportImbr1InterfaceReturnReportDescriptionFlag = ''
    ImportImport1Iref1MetavanceContactWhoTypeIndicator = ''
    ImportImport1Iref1MetavanceContactWhoIdentifier2 = ''
    ImportImport2Iref1MetavanceContactWhoIdentifier2 = ''
    ImportImport2Iref1MetavanceContactTEffectiveDate = ''
    ImportImport2Iref1MetavanceContactTEndDate = ''
    ImportImport2Iref1MetavanceContactContactTypeCode = ''
    ImportImportListControlsIefSuppliedCommand = ''
    ImportImportStartIref1MetavanceContactContactTypeCode = ''
    ImportImportStartIref1MetavanceContactTEffectiveDate = ''
    ImportImportStartIref1MetavanceContactTIdentifier = ''
    ImportImportStartIref1MetavanceContactCompleteLastName = ''
    ImportImportRowsRequestedIefSuppliedTextTCount = ''
