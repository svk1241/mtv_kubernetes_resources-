from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbr1ct2ContractTermTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportImbr1InterfaceSecurityId = ''
    ImportImportImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceRequestorId = ''
    ImportImportImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceReturnAddress = ''
    ImportImportImbr1InterfaceRetroLimitOverrideFlag = ''
    ImportImportQualifyIh8341InsSegmentIns04MbrLvlDtlMntRsnCd = ''
    ImportImportQualifyIhme1SubscriberLvlRef02SubidSubscriberId = ''
    ImportImportImbr1CoverageTypeTEndDate = ''
    ImportImportImbr1CoverageTypeTReceiptDate = ''
    ImportImportQualifyIref1CodeXslationTranslationTable = ''
