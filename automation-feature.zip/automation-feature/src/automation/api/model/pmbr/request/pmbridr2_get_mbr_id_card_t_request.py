from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbridr2GetMbrIdCardTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportIsec1InterfaceSecurityId = ''
    ImportImportIsec1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportIsec1InterfaceRequestorId = ''
    ImportImportIsec1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportIsec1InterfaceReturnAddress = ''
    ImportImportIsec1InterfaceReturnDescriptionFlag = ''
    ImportImportIsec1InterfaceTranslationTableName = ''
    ImportImportQualifyImbr1MemberContractId3 = ''
    ImportImportQualifyImbr1MemberMemberId = ''
    ImportImportQualifyImbr1IdCardRequestRequestLevel = ''
