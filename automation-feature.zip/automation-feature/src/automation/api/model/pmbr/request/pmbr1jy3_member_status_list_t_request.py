from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbr1jy3MemberStatusListTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportImbr1InterfaceSecurityId = ''
    ImportImportImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceRequestorId = ''
    ImportImportImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceReturnReportDescriptionFlag = ''
    ImportImportImbr1InterfaceReturnAddress = ''
    ImportImportQualifyImbr1MemberStatusContractId2 = ''
    ImportImportQualifyImbr1MemberStatusMemberId = ''
    ImportImportQualifyImbr1MemberStatusTEffectiveDate = ''
    ImportImportQualifyImbr1MemberStatusTEndDate = ''
    ImportImportQualifyImbr1MemberStatusVoidFlag = ''
    ImportImportStartImbr1MemberStatusMemberId = ''
    ImportImportStartImbr1MemberStatusStatusCode = ''
    ImportImportStartImbr1MemberStatusTEffectiveDate = ''
    ImportImportStartImbr1MemberStatusVoidFlag = ''
    ImportImportStartImbr1MemberStatusTCreationTimestamp = ''
    ImportImportPagingIefSuppliedCommand = ''
    ImportImportMaxRowsIefSuppliedTextTCount = ''
