from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbr1dl4ListMemberNetworksTRequest(BaseRequestModel):
    """Public class .."""

    ImportImportImbr1InterfaceSecurityId = ''
    ImportImportImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceRequestorId = ''
    ImportImportImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceReturnReportDescriptionFlag = ''
    ImportImportImbr1InterfaceReturnAddress = ''
    ImportImportQualifyImbr1MemberProvAssociationContractId3 = ''
    ImportImportQualifyImbr1MemberProvAssociationMemberId = ''
    ImportImportQualifyImbr1MemberProvAssociationTEndDate = ''
    ImportImportQualifyImbr1MemberProvAssociationServiceType = ''
    ImportImportQualifyImbr1MemberProvAssociationPcpFlag = ''
    ImportImportQualifyImbr1MemberProvAssociationTEffectiveDate = ''
    ImportImportQualifyImbr1MemberProvAssociationVoidFlag = ''
    ImportImportStartImbr1MemberProvAssociationTIdentifier = ''
    ImportImportStartImbr1MemberProvAssociationServiceType = ''
    ImportImportStartImbr1MemberProvAssociationPcpFlag = ''
    ImportImportStartImbr1MemberProvAssociationProviderIdentifier = ''
    ImportImportStartImbr1MemberProvAssociationTEndDate = ''
    ImportImportStartImbr1MemberProvAssociationNetworkIdentifier = ''
    ImportImportStartImbr1MemberProvAssociationVoidFlag = ''
    ImportImportPagingIefSuppliedCommand = ''
    ImportImportMaxRowsIefSuppliedTextTCount = ''
