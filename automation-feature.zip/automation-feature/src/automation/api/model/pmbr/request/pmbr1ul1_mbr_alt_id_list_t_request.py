from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbr1ul1MbrAltIdListTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportSecurityImbr1InterfaceSecurityId = ''
    ImportImportSecurityImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportSecurityImbr1InterfaceRequestorId = ''
    ImportImportSecurityImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportSecurityImbr1InterfaceReturnAddress = ''
    ImportImportQualifyImbr1MbrAlternateIdCoverageContractIdentifier = ''
    ImportImportQualifyImbr1MbrAlternateIdMemberId = ''
    ImportImportQualifyImbr1MbrAlternateIdAlternateIdTypeCode = ''
    ImportImportQualifyImbr1MbrAlternateIdAlternateIdSourceCode = ''
    ImportImportQualifyImbr1MbrAlternateIdVoidFlag = ''
    ImportImportQualifyImbr1MbrAlternateIdTEffectiveDate = ''
    ImportImportQualifyImbr1MbrAlternateIdTEndDate = ''
    ImportImportStartImbr1MbrAlternateIdAlternateId = ''
    ImportImportStartImbr1MbrAlternateIdAlternateIdTypeCode = ''
    ImportImportStartImbr1MbrAlternateIdVoidFlag = ''
    ImportImportStartImbr1MbrAlternateIdTEffectiveDate = ''
    ImportImportStartImbr1MbrAlternateIdTCreationTimestamp = ''
    ImportImportRequestedIefSuppliedTextTCount = ''
    ImportImportPagingIefSuppliedCommand = ''
