from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbr1su1MaintMbrMedRecT(BaseRequestModel):
    """Public class .."""

    ImportImportImbr1InterfaceSecurityId = ''
    ImportImportImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceRequestorId = ''
    ImportImportImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceActionIndicator = ''
    ImportImportImbr1InterfaceReturnAddress = ''
    ImportImportImbr1MemberMedicalRecordContractId = ''
    ImportImportImbr1MemberMedicalRecordMemberId = ''
    ImportImportImbr1MemberMedicalRecordMedicalRecordIdentifier = ''
    ImportImportImbr1MemberMedicalRecordMedicalRecordLocation = ''
    ImportImportImbr1MemberMedicalRecordOldRecordIndicator = ''
    ImportImportImbr1MemberMedicalRecordTEffectiveDate = ''
    ImportImportImbr1MemberMedicalRecordTEndDate = ''
    ImportImportImbr1MemberMedicalRecordTLastMaintenanceTimestamp = ''
