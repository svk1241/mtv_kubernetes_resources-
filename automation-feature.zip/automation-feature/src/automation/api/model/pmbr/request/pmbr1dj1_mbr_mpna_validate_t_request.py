from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbr1dj1MbrMpnaValidateTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportSecurityImbr1InterfaceSecurityId = ''
    ImportImportSecurityImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportSecurityImbr1InterfaceRequestorId = ''
    ImportImportSecurityImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportSecurityImbr1InterfaceReturnAddress = ''
    ImportImportImbr1MemberProvAssociationProviderIdentifier = ''
    ImportImportImbr1MemberProvAssociationNetworkIdentifier = ''
    ImportImportImbr1MemberProvAssociationContinuingProviderFlag = ''
    ImportImportImbr1MemberProvAssociationTEffectiveDate = ''
    ImportImportImbr1MemberEligibilityBusinessLevel4Id = ''
    ImportImportImbr1MemberEligibilityBusinessLevel5Id = ''
    ImportImportImbr1MemberEligibilityBusinessLevel6Id = ''
    ImportImportImbr1MemberEligibilityBusinessLevel7Id = ''
    ImportImportIper1PersonSexCode = ''
    ImportImportIper1PersonTBirthDate = ''
