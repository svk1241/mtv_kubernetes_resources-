from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbr1av3MemberSearchTRequest(BaseRequestModel):
    """Public class .."""

    ImportImportImbr1InterfaceSecurityId = ''
    ImportImportImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceRequestorId = ''
    ImportImportImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceReturnAddress = ''
    ImportImportImbr1InterfaceSearchType = ''
    ImportImportImbr1InterfacePartialSearchFlag = ''
    ImportImportQualifyImbr1MemberContractId3 = ''
    ImportImportQualifyImbr1MemberMemberId = ''
    ImportImportQualifyImbr1MemberCompleteFirstName = ''
    ImportImportQualifyImbr1MemberCompleteMiddleName = ''
    ImportImportQualifyImbr1MemberCompleteLastName = ''
    ImportImportQualifyImbr1MemberSexCode = ''
    ImportImportQualifyImbr1MemberPersonIdentifier = ''
    ImportImportQualifyImbr1MemberTBirthDate = ''
    ImportImportQualifyImbr1MemberTSocialSecurityNumber = ''
    ImportImportQualifyImbr1MemberTSsnLastFour = ''
    ImportImportQualifyImbr1MbrAlternateIdAlternateIdTypeCode = ''
    ImportImportQualifyImbr1MbrAlternateIdAlternateId = ''
    ImportImportQualifyIref1MetavanceAddressZip = ''
    ImportImportQualifyImbr1CoverageTypeSpanEmployerGroupLevel1Id = ''
    ImportImportStartImbr1MemberContractId3 = ''
    ImportImportStartImbr1MemberMemberId = ''
    ImportImportStartImbr1MemberCompleteFirstName = ''
    ImportImportStartImbr1MemberCompleteMiddleName = ''
    ImportImportStartImbr1MemberCompleteLastName = ''
    ImportImportStartImbr1MemberTBirthDate = ''
    ImportImportStartImbr1MemberSexCode = ''
    ImportImportStartImbr1MbrAlternateIdAlternateIdTypeCode = ''
    ImportImportPagingIefSuppliedCommand = ''
    ImportImportMaxRowsIefSuppliedTextTCount = ''
