from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbr1yl2CondDsbltyListTRequest(BaseRequestModel):
    """Public class .."""

    ImportImportImbr1InterfaceReturnReportDescriptionFlag = ''
    ImportImportImbr1InterfaceSecurityId = ''
    ImportImportImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceRequestorId = ''
    ImportImportImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceReturnAddress = ''
    ImportImportQualifyImbr1PreExistCondWaitPdContractId2 = ''
    ImportImportQualifyImbr1PreExistCondWaitPdMemberId = ''
    ImportImportQualifyImbr1PreExistCondWaitPdConditionType = ''
    ImportImportQualifyImbr1PreExistCondWaitPdVoidFlag = ''
    ImportImportQualifyImbr1PreExistCondWaitPdTEffectiveDate = ''
    ImportImportQualifyImbr1PreExistCondWaitPdTEndDate = ''
    ImportImportListControlsIefSuppliedCommand = ''
    ImportImportMaxRowsReturnedIefSuppliedTextTCount = ''
    ImportImportStartImbr1PreExistCondWaitPdConditionCode = ''
    ImportImportStartImbr1PreExistCondWaitPdVoidFlag = ''
    ImportImportStartImbr1PreExistCondWaitPdConditionType = ''
    ImportImportStartImbr1PreExistCondWaitPdTEndDate = ''
    ImportImportStartImbr1PreExistCondWaitPdTCreationTimestamp = ''
