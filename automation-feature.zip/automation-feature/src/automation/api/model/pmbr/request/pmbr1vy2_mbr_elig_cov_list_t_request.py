from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbr1vy2MbrEligCovListTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportImbr1InterfaceSecurityId = ''
    ImportImportImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceRequestorId = ''
    ImportImportImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceReturnAddress = ''
    ImportImportImbr1InterfaceReturnReportDescriptionFlag = ''
    ImportImportQualifyImbr1MemberEligibilityContractId3 = ''
    ImportImportQualifyImbr1MemberEligibilityMemberId = ''
    ImportImportQualifyImbr1MemberEligibilityTEffectiveDate = ''
    ImportImportQualifyImbr1MemberEligibilityTEndDate = ''
    ImportImportQualifyImbr1MemberEligibilityVoidFlag = ''
    ImportImportStartImbr1MemberEligibilityTEndDate = ''
    ImportImportStartImbr1MemberEligibilityVoidFlag = ''
    ImportImportStartImbr1MemberEligibilityIdentifier = ''
    ImportImportStartImbr1MemberEligibilityTIdentifier = ''
    ImportImportRequestedIefSuppliedTextTCount = ''
    ImportImportListControlsIefSuppliedCommand = ''
    ImportImportListControlsIefSuppliedCount = ''
