from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbr1yu2CondDsbltyMaintTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportImbr1InterfaceSecurityId = ''
    ImportImportImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceRequestorId = ''
    ImportImportImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceReturnAddress = ''
    ImportImportImbr1InterfaceActionIndicator = ''
    ImportImportImbr1PreExistCondWaitPdContractId2 = ''
    ImportImportImbr1PreExistCondWaitPdMemberId = ''
    ImportImportImbr1PreExistCondWaitPdConditionCode = ''
    ImportImportImbr1PreExistCondWaitPdConditionType = ''
    ImportImportImbr1PreExistCondWaitPdExplanationCode = ''
    ImportImportImbr1PreExistCondWaitPdInvestigationTypeIndicator = ''
    ImportImportImbr1PreExistCondWaitPdAccidentClaimBypassFlag = ''
    ImportImportImbr1PreExistCondWaitPdPersonPriorCovgReductionInd = ''
    ImportImportImbr1PreExistCondWaitPdMemberEligibilityReductionInd = ''
    ImportImportImbr1PreExistCondWaitPdTEffectiveDate = ''
    ImportImportImbr1PreExistCondWaitPdTEndDate = ''
    ImportImportImbr1PreExistCondWaitPdTDisabilityDate = ''
    ImportImportImbr1PreExistCondWaitPdTCreationTimestamp = ''
    ImportImportImbr1PreExistCondWaitPdProviderId = ''
