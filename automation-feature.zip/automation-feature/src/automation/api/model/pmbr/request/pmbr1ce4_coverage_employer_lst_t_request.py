from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbr1ce4CoverageEmployerLstTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportImbr1InterfaceSecurityId = ''
    ImportImportImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceRequestorId = ''
    ImportImportImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceReturnReportDescriptionFlag = ''
    ImportImportImbr1InterfaceReturnAddress = ''
    ImportImportQualifyImbr1CoverageEmployerInfoContractId2 = ''
    ImportImportQualifyImbr1CoverageEmployerInfoTEffectiveDate = ''
    ImportImportQualifyImbr1CoverageEmployerInfoTEndDate = ''
    ImportImportQualifyImbr1CoverageEmployerInfoVoidFlag = ''
    ImportImportStartImbr1CoverageEmployerInfoTCreationTimestamp = ''
    ImportImportStartImbr1CoverageEmployerInfoTEndDate = ''
    ImportImportStartImbr1CoverageEmployerInfoVoidFlag = ''
    ImportImportPagingControlsIefSuppliedCommand = ''
    ImportImportPagingControlsIefSuppliedTextTCount = ''
