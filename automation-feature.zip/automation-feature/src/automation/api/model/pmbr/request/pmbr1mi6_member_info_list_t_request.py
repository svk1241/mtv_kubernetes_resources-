from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbr1mi6MemberInfoListTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportSecurityImbr1InterfaceSecurityId = ''
    ImportImportSecurityImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportSecurityImbr1InterfaceRequestorId = ''
    ImportImportSecurityImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportSecurityImbr1InterfaceReturnAddress = ''
    ImportImportSecurityImbr1InterfaceReturnReportDescriptionFlag = ''
    ImportImportQualifyImbr1MemberContractId3 = ''
    ImportImportQualifyImbr1MemberMemberId = ''
    ImportImportQualifyPersonNameSwIefSuppliedFlag = 'Y'
    ImportImportQualifyIper1PersonNameTEffectiveDate = ''
    ImportImportQualifyIper1PersonNameTEndDate = ''
    ImportImportStartImbr1MemberMemberId = ''
    ImportImportStartIper1PersonNameTEndDate = ''
    ImportImportPagingIefSuppliedCommand = ''
    ImportImportMaxRowsIefSuppliedTextTCount = ''
