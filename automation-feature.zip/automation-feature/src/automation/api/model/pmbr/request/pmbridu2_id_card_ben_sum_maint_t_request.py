from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbridu2IdCardBenSumMaintTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportImbr1InterfaceSecurityId = ''
    ImportImportImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceRequestorId = ''
    ImportImportImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceReturnAddress = ''
    ImportImportImbr1InterfaceActionIndicator = ''
    ImportImportImbr1IdCardRequestCoverageContractIdentifier = ''
    ImportImportImbr1IdCardRequestMemberId = ''
    ImportImportImbr1IdCardRequestEmployerGroupLevel1Id = ''
    ImportImportImbr1IdCardRequestEmployerGroupLevel2Id = ''
    ImportImportImbr1IdCardRequestRequestLevel = ''
    ImportImportImbr1IdCardRequestRequestType = ''
    ImportImportImbr1IdCardRequestIssueCardCode = ''
    ImportImportImbr1IdCardRequestNetworkIdentifier = ''
    ImportImportImbr1IdCardRequestOverrideHoldFlag = ''
    ImportImportImbr1IdCardRequestBenefitPackageIdentifier = ''
    ImportImportImbr1IdCardRequestTRequestEffectiveDate = ''
    ImportImportImbr1IdCardRequestTIssueDate = ''
    ImportImportImbr1IdCardRequestTRequestedDate = ''
    ImportImportImbr1IdCardRequestTLastMaintenanceTimestamp = ''
    ImportImportImbr1IdCardRequestTCreationTimestamp = ''
