from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbr1di1MbrMpnaListTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportImbr1InterfaceSecurityId = ''
    ImportImportImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceRequestorId = ''
    ImportImportImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceReturnAddress = ''
    ImportImportQualifyImbr1MemberProvAssociationContractId3 = ''
    ImportImportQualifyImbr1MemberProvAssociationMemberId = ''
    ImportImportQualifyImbr1MemberProvAssociationTEffectiveDate = ''
    ImportImportQualifyImbr1MemberProvAssociationTEndDate = ''
    ImportImportStartImbr1MemberProvAssociationTEndDate = ''
    ImportImportListControlsIefSuppliedTextTCount = ''
    ImportImportListControlsIefSuppliedCommand = ''
