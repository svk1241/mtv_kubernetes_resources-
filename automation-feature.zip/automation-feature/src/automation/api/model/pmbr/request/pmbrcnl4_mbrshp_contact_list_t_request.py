from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbrcnl4MbrshpContactListTRequest(BaseRequestModel):
    """Public class .."""

    ImportImportImbr1InterfaceSecurityId = ''
    ImportImportImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceRequestorId = ''
    ImportImportImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceReturnAddress = ''
    ImportImportImbr1InterfaceReturnReportDescriptionFlag = ''
    ImportImportQualify1Iref1MetavanceContactWhoTypeIndicator = ''
    ImportImportQualify1Iref1MetavanceContactWhoIdentifier2 = ''
    ImportImportQualify2Iref1MetavanceContactWhoIdentifier2 = ''
    ImportImportQualify2Iref1MetavanceContactTEffectiveDate = ''
    ImportImportQualify2Iref1MetavanceContactTEndDate = ''
    ImportImportQualify2Iref1MetavanceContactContactTypeCode = ''
    ImportImportStartIref1MetavanceContactContactTypeCode = ''
    ImportImportStartIref1MetavanceContactCompleteLastName = ''
    ImportImportStartIref1MetavanceContactTEffectiveDate = ''
    ImportImportStartIref1MetavanceContactTIdentifier = ''
    ImportImportListControlsIefSuppliedCommand = ''
    ImportImportRowsRequestedIefSuppliedTextTCount = ''
