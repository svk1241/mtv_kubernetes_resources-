from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbr1em1MbrAlertMaintTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportImbr1InterfaceSecurityId = ''
    ImportImportImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceRequestorId = ''
    ImportImportImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceActionIndicator = ''
    ImportImportImbr1InterfaceReturnAddress = ''
    ImportImportImbr1MemberAlertContractId3 = ''
    ImportImportImbr1MemberAlertMemberId = ''
    ImportImportImbr1MemberAlertTEffectiveDate = ''
    ImportImportImbr1MemberAlertTEndDate = ''
    ImportImportImbr1MemberAlertAlertCode = ''
    ImportImportImbr1MemberAlertTLastMaintenanceTimestamp = ''
