from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbr1cq4ListCvgTypeSpanTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportImbr1InterfaceSecurityId = ''
    ImportImportImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceRequestorId = ''
    ImportImportImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceReturnAddress = ''
    ImportImportImbr1InterfaceReturnReportDescriptionFlag = ''
    ImportImportQualifyImbr1CoverageTypeSpanEmployerGroupLevel1Id = ''
    ImportImportQualifyImbr1CoverageTypeSpanEmployerGroupLevel2Id = ''
    ImportImportQualifyImbr1CoverageTypeSpanContractId2 = ''
    ImportImportQualifyImbr1CoverageTypeSpanTEffectiveDate = ''
    ImportImportQualifyImbr1CoverageTypeSpanTEndDate = ''
    ImportImportQualifyImbr1CoverageTypeSpanVoidFlag = ''
    ImportImportStartImbr1CoverageTypeSpanTEndDate = ''
    ImportImportListControlsIefSuppliedCommand = ''
