from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbr1gr1DisplayMemberInfoTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportImbr1InterfaceSecurityId = ''
    ImportImportImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceRequestorId = ''
    ImportImportImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceReturnAddress = ''
    ImportImportQualifyIhme1SubscriberLvlRef02SubidSubscriberId = ''
    ImportImportQualifyIhme1MemberLvlRef02MbridSubscriberSupId = ''
    ImportImportQualifyImbr1MemberEligibilityTEffectiveDate = ''
    ImportImportQualifyIref1CodeXslationTranslationTable = ''
