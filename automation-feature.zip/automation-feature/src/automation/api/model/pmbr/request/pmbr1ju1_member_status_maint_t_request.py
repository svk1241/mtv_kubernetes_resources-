from automation.api.model.common.base_request_model import BaseRequestModel


class Pmbr1ju1MemberStatusMaintTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportImbr1InterfaceSecurityId = ''
    ImportImportImbr1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceRequestorId = ''
    ImportImportImbr1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImbr1InterfaceActionIndicator = ''
    ImportImportImbr1InterfaceReturnAddress = ''
    ImportImportImbr1MemberStatusContractId2 = ''
    ImportImportImbr1MemberStatusMemberId = ''
    ImportImportImbr1MemberStatusStatusCode = ''
    ImportImportImbr1MemberStatusStatusType = ''
    ImportImportImbr1MemberStatusTEffectiveDate = ''
    ImportImportImbr1MemberStatusTEndDate = ''
    ImportImportImbr1MemberStatusTCreationTimestamp = ''
    ImportImportImbr1MemberStatusTLastMaintenanceTimestamp = ''
