from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Numerable, Table


class Pben1am7ListBenCounterMbrTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportGIben1Interface'
        ErrorCode.name_length_table = 'ExportGroupErrors'
        ErrorCode.name_length_field = 'export_export_group_errors_length'
        super().__init__(content, response_status=ResponseStatusExtended)
        self.export_g_iben1_benefit_counter = self._htmlParser.table_to_obj(ExportGIben1BenefitCounter)
        self.export_g_iben1_benefit_counter.length = self._htmlParser.get_table_length("ExportGroupBenefitCounters", "export_export_group_benefit_counters_length")


@dataclass
class ExportGIben1BenefitCounterItem:
    """Public class which describes item structure for table ExportGIben1BenefitCounter"""

    accumulation_period_desc: str
    counter_accumulation_period: str
    counter_class_code: str
    counter_class_usage: str
    counter_date_type: str
    counter_description2: str
    counter_name: str
    counter_super_key_code_desc: str
    counter_super_key_code_value: str
    counter_super_key_data: str
    counter_who_type: str
    coverage_contract_identifier2: str
    member_identifier: str
    multiple_limit_indicator: str
    rollover_max_counter_id: str
    rollover_max_rule_id: str
    transferred_indicator: str
    t_accum_create_date: str
    t_accum_period_begin_date: str
    t_accum_period_end_date: str
    t_accum_period_given_date: str
    t_accum_period_latest_given_date: str
    t_counter_amount_used: str
    t_counter_available_amount: str
    t_counter_carryover_amount: str
    t_counter_date: str
    t_counter_first_activity_date: str
    t_counter_last_activity_date: str
    t_counter_limit_amount: str
    t_counter_summary_surrogate_id2: str
    t_rollover_max_elig_payout_delay: str
    t_rollover_max_priority: str


@dataclass
class ExportGIben1BenefitCounter(Numerable):
    """Public class which describes dataclass for table ExportGIben1BenefitCounter"""

    items: List[ExportGIben1BenefitCounterItem]
    table_name: str = "ExportGIben1BenefitCounter"


@dataclass
class ResponseStatusExtended(Table):
    """Public class which describes dataclass for table ResponseStatusExtended"""

    checksum: str
    context_string: str
    data_store_status: str
    origin_servid: str
    reason_code: str
    return_code: str
    severity_code: str
    command: str
    count: str
    counter_accumulation_period: str
    counter_name: str
    counter_super_key_data: str
    counter_who_type: str
    t_counter_date: str
    table_name: str = "ExportIben1Interface"
