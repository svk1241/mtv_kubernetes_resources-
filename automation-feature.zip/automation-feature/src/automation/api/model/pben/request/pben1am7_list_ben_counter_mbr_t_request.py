from automation.api.model.common.base_request_model import BaseRequestModel


class Pben1am7ListBenCounterMbrTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportIben1InterfaceAllCountersFlag = ''
    ImportImportIben1InterfaceBatchModeFlag = ''
    ImportImportIben1InterfaceCalendarYearDisplayFlag = ''
    ImportImportIben1InterfaceCallMode = ''
    ImportImportIben1InterfaceMonthlyDisplayFlag = ''
    ImportImportIben1InterfaceRequestorId = ''
    ImportImportIben1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportIben1InterfaceSearchLevelType = ''
    ImportImportIben1InterfaceSecurityId = ''
    ImportImportIben1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportIben1InterfaceZeroCountersFlag = ''
    ImportImportListControlsIefSuppliedCommand = ''
    ImportImportQualifyIben1BenefitCounterCounterName = ''
    ImportImportQualifyIben1BenefitCounterCoverageContractIdentifier2 = ''
    ImportImportQualifyIben1BenefitCounterMemberIdentifier = ''
    ImportImportQualifyIben1BenefitCounterTAccumulationAsOfDate = ''
    ImportImportQualifyIben1BenefitCounterTBeginSearchDate = ''
    ImportImportQualifyIben1BenefitCounterTEndSearchDate = ''
    ImportImportStartIben1BenefitCounterCounterAccumulationPeriod = ''
    ImportImportStartIben1BenefitCounterCounterName = ''
    ImportImportStartIben1BenefitCounterCounterSuperKeyData = ''
    ImportImportStartIben1BenefitCounterCounterWhoType = ''
    ImportImportStartIben1BenefitCounterTCounterDate = ''
