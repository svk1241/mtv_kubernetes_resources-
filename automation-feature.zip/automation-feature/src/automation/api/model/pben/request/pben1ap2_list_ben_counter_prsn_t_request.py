from automation.api.model.common.base_request_model import BaseRequestModel


class Pben1ap2ListBenCounterPrsnTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportIben1InterfaceSecurityId = ''
    ImportImportIben1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportIben1InterfaceRequestorId = ''
    ImportImportIben1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportIben1InterfaceCallMode = ''
    ImportImportIben1InterfaceAllCountersFlag = ''
    ImportImportIben1InterfaceCalendarYearDisplayFlag = ''
    ImportImportIben1InterfaceBatchModeFlag = ''
    ImportImportIben1InterfaceMonthlyDisplayFlag = ''
    ImportImportQualifyIben1BenefitCounterPersonIdentifier = ''
    ImportImportQualifyIben1BenefitCounterCounterName = ''
    ImportImportQualifyIben1BenefitCounterTBeginSearchDate = ''
    ImportImportQualifyIben1BenefitCounterTEndSearchDate = ''
    ImportImportQualifyIben1BenefitCounterTAccumulationAsOfDate = ''
    ImportImportStartIben1BenefitCounterCounterName = ''
    ImportImportStartIben1BenefitCounterCounterSuperKeyData = ''
    ImportImportStartIben1BenefitCounterCounterAccumulationPeriod = ''
    ImportImportStartIben1BenefitCounterTCounterYear = ''
    ImportImportStartIben1BenefitCounterTCounterDate = ''
    ImportImportListControlsIefSuppliedCommand = ''
