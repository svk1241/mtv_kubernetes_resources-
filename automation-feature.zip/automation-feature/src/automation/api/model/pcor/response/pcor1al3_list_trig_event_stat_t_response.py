from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Numerable, Table


class Pcor1al3ListTrigEventStatTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorsGIcor1Interface'
        ErrorCode.name_length_table = 'ExportErrorsGroup'
        ErrorCode.name_length_field = 'export_export_errors_group_length'
        super().__init__(content, response_status=ResponseStatusExtended)
        self.export_g_icor1_trig_event_status = self._htmlParser.table_to_obj(ExportGIcor1TrigEventStatus)
        self.export_g_icor1_trig_event_status.length = self._htmlParser.get_table_length("ExportTrigEventStatusGroup",
                                                                                         "export_export_trig_event_status_group_length")
        self.export_list_controls_ief_supplied_text = self._htmlParser.table_to_obj(ExportListControlsIefSuppliedText,
                                                                                    True)
        self.export_icor1_trig_event_status = self._htmlParser.table_to_obj(ExportIcor1TrigEventStatus, True)


@dataclass
class ExportGIcor1TrigEventStatusItem:
    """Public class which describes item structure for table ExportGIcor1TrigEventStatus"""

    event_name: str
    event_status: str
    business_level4_id: str
    business_level5_id: str
    business_level6_id: str
    business_level7_id: str
    void_flag: str
    operator_identifier: str
    t_event_status_date: str
    t_creation_timestamp: str
    t_last_maint_timestamp: str
    event_status_desc: str


@dataclass
class ExportGIcor1TrigEventStatus(Numerable):
    """Public class which describes dataclass for table ExportGIcor1TrigEventStatus"""

    items: List[ExportGIcor1TrigEventStatusItem]
    table_name: str = "ExportGIcor1TrigEventStatus"


@dataclass
class ExportListControlsIefSuppliedText(Table):
    """Public class which describes dataclass for table ExportListControlsIefSuppliedText"""

    t_count: str
    table_name: str = "ExportListControlsIefSuppliedText"


@dataclass
class ExportIcor1TrigEventStatus(Table):
    """Public class which describes dataclass for table ExportIcor1TrigEventStatus"""

    name: str
    t_event_status_date: str
    t_creation_timestamp: str
    table_name: str = "ExportIcor1TrigEventStatus"


@dataclass
class ResponseStatusExtended(Table):
    """Public class which describes dataclass for table ExportImst1Interface"""

    command: str
    severity_code: str
    data_store_status: str
    origin_servid: str
    context_string: str
    return_code: str
    reason_code: str
    checksum: str
    return_address: str
    table_name: str = "ExportListControlsIefSupplied"
