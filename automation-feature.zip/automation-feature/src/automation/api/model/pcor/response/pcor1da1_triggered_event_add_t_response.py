from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Table


class Pcor1da1TriggeredEventAddTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorGIsec1Interface'
        ResponseStatus.table_name = 'ExportIsec1Interface'
        super().__init__(content)
        self.export_result_icor1_triggered_event = self._htmlParser.table_to_obj(ExportResultIcor1TriggeredEvent, True)


@dataclass
class ExportResultIcor1TriggeredEvent(Table):
    """Public class which describes dataclass for table ExportResultIcor1TriggeredEvent"""

    business_level1_id: str
    business_level2_id: str
    business_level3_id: str
    business_level4_id: str
    business_level5_id: str
    event_name: str
    who_identifier: str
    who_identifier_suffix: str
    who_type_code: str
    operator_identifier: str
    t_creation_timestamp: str
    table_name: str = "ExportResultIcor1TriggeredEvent"
