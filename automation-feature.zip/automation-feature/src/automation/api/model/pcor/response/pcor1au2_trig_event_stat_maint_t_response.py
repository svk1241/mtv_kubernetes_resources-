from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Table


class Pcor1au2TrigEventStatMaintTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorsGIcor1Interface'
        ErrorCode.name_length_table = 'ExportErrorsGroup'
        ErrorCode.name_length_field = 'export_export_errors_group_length'
        ResponseStatus.table_name = 'ExportIcor1Interface'
        super().__init__(content)
        self.export_icor1_trig_event_status = self._htmlParser.table_to_obj(ExportIcor1TrigEventStatus, True)


@dataclass
class ExportIcor1TrigEventStatus(Table):
    """Public class which describes dataclass for table ExportIcor1TrigEventStatus"""

    who_identifier3: str
    who_identifier2: str
    event_status: str
    event_name: str
    business_level4_id: str
    business_level5_id: str
    business_level6_id: str
    business_level7_id: str
    void_flag: str
    operator_identifier: str
    t_event_status_date: str
    t_creation_timestamp: str
    t_last_maint_timestamp: str
    table_name: str = "ExportIcor1TrigEventStatus"
