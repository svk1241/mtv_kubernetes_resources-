from automation.api.model.common.base_request_model import BaseRequestModel


class Pcor1au2TrigEventStatMaintTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportIcor1InterfaceSecurityId = ''
    ImportImportIcor1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportIcor1InterfaceRequestorId = ''
    ImportImportIcor1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportIcor1InterfaceActionIndicator = ''
    ImportImportIcor1InterfaceReturnAddress = ''
    ImportImportIcor1TrigEventStatusWhoIdentifier3 = ''
    ImportImportIcor1TrigEventStatusWhoIdentifier2 = ''
    ImportImportIcor1TrigEventStatusEventName = ''
    ImportImportIcor1TrigEventStatusEventStatus = ''
    ImportImportIcor1TrigEventStatusBusinessLevel4Id = ''
    ImportImportIcor1TrigEventStatusBusinessLevel5Id = ''
    ImportImportIcor1TrigEventStatusBusinessLevel6Id = ''
    ImportImportIcor1TrigEventStatusBusinessLevel7Id = ''
    ImportImportIcor1TrigEventStatusTEventStatusDate = ''
    ImportImportIcor1TrigEventStatusTCreationTimestamp = ''
    ImportImportIcor1TrigEventStatusTLastMaintTimestamp = ''
