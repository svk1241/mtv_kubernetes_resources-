from automation.api.model.common.base_request_model import BaseRequestModel


class Pcor1al3ListTrigEventStatTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportIcor1InterfaceSecurityId = ''
    ImportImportIcor1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportIcor1InterfaceRequestorId = ''
    ImportImportIcor1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportIcor1InterfaceReturnReportDescriptionFlag = ''
    ImportImportIcor1InterfaceReturnAddress = ''
    ImportImportQualifyIcor1TrigEventStatusWhoTypeCode = ''
    ImportImportQualifyIcor1TrigEventStatusWhoIdentifier2 = ''
    ImportImportQualifyIcor1TrigEventStatusVoidFlag = ''
    ImportImportQualifyIcor1TrigEventStatusWhoIdentifier3 = ''
    ImportImportStartIcor1TrigEventStatusTEventStatusDate = ''
    ImportImportStartIcor1TrigEventStatusTCreationTimestamp = ''
    ImportImportListControlsIefSuppliedTextTCount = ''
    ImportImportListControlsIefSuppliedCommand = ''
