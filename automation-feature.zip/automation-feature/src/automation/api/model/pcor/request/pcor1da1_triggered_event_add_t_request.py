from automation.api.model.common.base_request_model import BaseRequestModel


class Pcor1da1TriggeredEventAddTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportIsec1InterfaceSecurityId = ''
    ImportImportIsec1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportIsec1InterfaceRequestorId = ''
    ImportImportIsec1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportIsec1InterfaceReturnAddress = ''
    ImportImportQualifyIcor1TriggeredEventBusinessLevel1Id = ''
    ImportImportQualifyIcor1TriggeredEventBusinessLevel2Id = ''
    ImportImportQualifyIcor1TriggeredEventBusinessLevel3Id = ''
    ImportImportQualifyIcor1TriggeredEventBusinessLevel4Id = ''
    ImportImportQualifyIcor1TriggeredEventBusinessLevel5Id = ''
    ImportImportQualifyIcor1TriggeredEventEventName = ''
    ImportImportQualifyIcor1TriggeredEventWhoIdentifier = ''
    ImportImportQualifyIcor1TriggeredEventWhoIdentifierSuffix = ''
    ImportImportQualifyIcor1TriggeredEventWhoTypeCode = ''
