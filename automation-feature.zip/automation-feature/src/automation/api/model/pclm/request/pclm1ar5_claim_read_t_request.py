from automation.api.model.common.base_request_model import BaseRequestModel


class Pclm1ar5ClaimReadTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportInQualifyIclm1ClaimClaimIdentifier = ''
    ImportInSecurityIclm1InterfaceRequestorId = ''
    ImportInSecurityIclm1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportInSecurityIclm1InterfaceReturnAddress = ''
    ImportInSecurityIclm1InterfaceSecurityId = ''
    ImportInSecurityIclm1InterfaceSecurityPassword = ''  # pragma: allowlist secret
