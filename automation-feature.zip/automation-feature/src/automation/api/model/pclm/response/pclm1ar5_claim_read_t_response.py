from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.numerable import Numerable, Table


class Pclm1ar5ClaimReadTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        super().__init__(content, error_code=None, response_status=ResponseStatusExtended)
        self.export_g_iclm1_surgical_procedure_assn = self._htmlParser.table_to_obj(ExportGIclm1SurgicalProcedureAssn)
        self.export_g_iclm1_surgical_procedure_assn.length = self._htmlParser.get_table_length("ExportSurgProcGroup", "export_export_surg_proc_group_length")
        self.export_g_iclm1_claim_other_carrier = self._htmlParser.table_to_obj(ExportGIclm1ClaimOtherCarrier)
        self.export_g_iclm1_claim_other_carrier.length = self._htmlParser.get_table_length("ExportClaimOthrCarrier", "export_export_claim_othr_carrier_length")
        self.export_preconvert_g_iclm1_surgical_procedure_assn = self._htmlParser.table_to_obj(ExportPreconvertGIclm1SurgicalProcedureAssn)
        self.export_preconvert_g_iclm1_surgical_procedure_assn.length = self._htmlParser.get_table_length("ExportPrecnvrtSurgProcGroup", "export_export_precnvrt_surg_proc_group_length")


@dataclass
class ExportGIclm1SurgicalProcedureAssnItem:
    """Public class which describes item structure for table ExportGIclm1SurgicalProcedureAssn"""

    coding_scheme: str
    surgical_procedure_code_id: str


@dataclass
class ExportGIclm1SurgicalProcedureAssn(Numerable):
    """Public class which describes dataclass for table ExportGIclm1SurgicalProcedureAssn"""

    items: List[ExportGIclm1SurgicalProcedureAssnItem]
    table_name: str = "ExportGIclm1SurgicalProcedureAssn"


@dataclass
class ExportGIclm1ClaimOtherCarrierItem:
    """Public class which describes item structure for table ExportGIclm1ClaimOtherCarrier"""

    other_carrier_id: str


@dataclass
class ExportGIclm1ClaimOtherCarrier(Numerable):
    """Public class which describes dataclass for table ExportGIclm1ClaimOtherCarrier"""

    items: List[ExportGIclm1ClaimOtherCarrierItem]
    table_name: str = "ExportGIclm1ClaimOtherCarrier"


@dataclass
class ExportPreconvertGIclm1SurgicalProcedureAssnItem:
    """Public class which describes item structure for table ExportPreconvertGIclm1SurgicalProcedureAssn"""

    coding_scheme: str
    surgical_procedure_code_id: str


@dataclass
class ExportPreconvertGIclm1SurgicalProcedureAssn(Numerable):
    """Public class which describes dataclass for table ExportPreconvertGIclm1SurgicalProcedureAssn"""

    items: List[ExportPreconvertGIclm1SurgicalProcedureAssnItem]
    table_name: str = "ExportPreconvertGIclm1SurgicalProcedureAssn"


@dataclass
class ResponseStatusExtended(Table):
    """Public class which describes dataclass for table ResponseStatusExtended"""

    adjustment_type_code: str
    cash_control_identifier: str
    alpha_prefix: str
    accident_flag: str
    accounts_payable_bank_code2: str
    adjustment_sequence_number: str
    admission_diagnosis_class_code: str
    admission_diagnosis_code: str
    admission_diag_code_set_ind: str
    admission_diag_code_invalid_flag: str
    apg_whole_claim_priced_flag: str
    attending_provider_data_invld_fg: str
    attending_provider_id: str
    automatch_off_flag: str
    billing_provider_data_invalid_fg: str
    billing_provider_id: str
    billing_prov_specialty_code: str
    billing_prov_type_code: str
    business_level1_id: str
    business_level2_id: str
    business_level3_id: str
    business_level4_id: str
    business_level5_id: str
    business_level6_id: str
    business_level7_id: str
    carrier_type_ca_code: str
    cas_process_indicator: str
    cause_of_illness_code: str
    claim_identifier: str
    claim_reference_number: str
    claim_submitter_identifier: str
    cob_bypass_code: str
    cob_type_indicator: str
    contract_identifier2: str
    coordination_of_benefits_flag: str
    coordination_of_benefits_type: str
    early_pre_screening_dx_test_flag: str
    emergency_flag: str
    episode_of_care_identifier: str
    family_planning_flag: str
    first_name: str
    hsp_diagnosis_related_grping_cd: str
    icd_code_scheme_processed: str
    info_ex_code: str
    interchange_sender_id: str
    last_name: str
    location_event_flag: str
    medicaid_identifier: str
    medical_record_identifier2: str
    medicare_assignment_indicator: str
    member_class_code: str
    member_identifier: str
    middle_name: str
    oic_pymt_status_code: str
    operator_identifier: str
    order_admit_provider_id: str
    order_admit_prov_data_invalid_fg: str
    order_admit_prov_specialty_code: str
    order_admit_prov_type_code: str
    original_operator_identifier: str
    originator_application_trans_id: str
    other_insurance_carrier_code: str
    patient_identifier2: str
    pay_to_provider: str
    person_identifier: str
    precertification_number: str
    predetermination_claim_flag: str
    predetermination_reopen_ind: str
    primary_diagnosis_class: str
    primary_diagnosis_code: str
    pre_cnvrsn_admission_diag_code: str
    primary_diag_code_invalid_flag: str
    provider_remit_reported_flag: str
    remarks_flag: str
    security_empl_grp1_id: str
    security_provider_id: str
    service_destination_area1: str
    service_destination_area2: str
    sex_code: str
    source: str
    status: str
    submitted_billing_id_type: str
    submitted_billing_provider_id: str
    submitted_orderadmit_provider_id: str
    submitted_order_admit_id_type: str
    sub_address1: str
    sub_address2: str
    sub_address3: str
    sub_city: str
    sub_first_name: str
    sub_last_name: str
    sub_middle_name: str
    sub_state: str
    sub_zip: str
    transaction_set_control_number: str
    type: str
    type_bill_code: str
    t_adjustment_sequence_number: str
    t_admission_date: str
    t_admission_hour: str
    t_allowed_based_copay_amt: str
    t_allowed_based_deductible_amt: str
    t_birth_date: str
    t_charge_based_copay_amt: str
    t_charge_based_deductible_amt: str
    t_covered_from_date: str
    t_covered_thru_date: str
    t_discharge_date: str
    t_entered_timestamp: str
    t_hold_file_identifier: str
    t_initial_injury_date: str
    t_oic_allowed_amount: str
    t_oic_coinsurance_amount: str
    t_oic_deductible_amount: str
    t_oic_paid_amt: str
    t_original_processed_ts: str
    t_paid_timestamp: str
    t_patient_responsibility_amount: str
    t_pend_count: str
    t_received_timestamp: str
    t_recycle_count: str
    t_resolved_timestamp: str
    t_services_number: str
    t_status_timestamp: str
    t_total_allowed_amount2: str
    t_total_applied_reserve_amount2: str
    t_total_charges_amount: str
    t_total_coins_amount2: str
    t_total_copay_amount2: str
    t_total_copay_coins_amount2: str
    t_total_deduct_amount2: str
    t_total_denied_amount2: str
    t_total_discount_amount2: str
    t_total_ocl_amount2: str
    t_total_out_of_pocket_amount2: str
    t_total_paid_amount2: str
    t_total_risk_amount2: str
    t_unresolved_services_number: str
    whole_claim_adjudication_flag: str
    checksum: str
    context_string: str
    data_store_status: str
    origin_servid: str
    reason_code: str
    return_address: str
    return_code: str
    severity_code: str
    table_name: str = "ExportIclm1CashClaimAdj"
