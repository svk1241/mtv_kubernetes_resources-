from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.numerable import Numerable, Table


class Pclm1al7ClaimsListTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        super().__init__(content, error_code=None, response_status=ResponseStatusExtended)
        self.export_claim_g_iclm1_claim = self._htmlParser.table_to_obj(ExportClaimGIclm1Claim)
        self.export_claim_g_iclm1_claim.length = self._htmlParser.get_table_length("ExportClaimGroup", "export_export_claim_group_length")
        self.export_list_controls_ief_supplied = self._htmlParser.table_to_obj(ExportListControlsIefSupplied, True)


@dataclass
class ExportClaimGIclm1ClaimItem:
    """Public class which describes item structure for table ExportClaimGIclm1Claim"""

    claim_identifier: str
    type: str
    status: str
    contract_identifier2: str
    member_identifier: str
    last_name: str
    first_name: str
    middle_name: str
    sex_code: str
    member_class_code: str
    emp_group_level1_id: str
    emp_group_level2_id: str
    billing_provider_id: str
    billing_prov_type_code: str
    billing_first_name: str
    billing_last_name: str
    billing_middle_initial: str
    security_provider_id: str
    security_prov_first_name: str
    security_prov_last_name: str
    primary_diagnosis_code: str
    primary_diagnosis_class: str
    predetermination_claim_flag: str
    business_level4_id: str
    business_level5_id: str
    business_level6_id: str
    business_level7_id: str
    source: str
    caused_by_employment_flag: str
    auto_accident_flag: str
    other_accident_flag: str
    network_indicator: str
    pay_to_provider: str
    precertification_number: str
    icd_code_scheme_processed: str
    t_covered_from_date: str
    t_covered_thru_date: str
    t_status_timestamp: str
    t_received_timestamp: str
    t_paid_timestamp: str
    t_total_charges_amount: str
    t_birth_date: str
    t_total_deduct_amount2: str
    t_total_risk_amount2: str
    t_total_paid_amount2: str
    t_total_discount_amount2: str
    t_total_applied_reserve_amount2: str
    t_patient_responsibility_amount: str
    t_total_copay_amount2: str
    t_total_coins_amount2: str
    t_total_out_of_pocket_amount2: str
    check_number3: str
    place_of_service_code: str
    pay_to_indicator: str
    treatment_type_code: str
    status_explanation: str
    procedure_code_identifier2: str
    alpha_prefix: str
    sccf_claim_number: str
    sccf_cross_reference_number: str


@dataclass
class ExportClaimGIclm1Claim(Numerable):
    """Public class which describes dataclass for table ExportClaimGIclm1Claim"""

    items: List[ExportClaimGIclm1ClaimItem]
    table_name: str = "ExportClaimGIclm1Claim"


@dataclass
class ExportListControlsIefSupplied(Table):
    """Public class which describes dataclass for table ExportListControlsIefSupplied"""

    command: str
    count: str
    table_name: str = "ExportListControlsIefSupplied"


@dataclass
class ResponseStatusExtended(Table):
    """Public class which describes dataclass for table ResponseStatusExtended"""

    claim_identifier: str
    t_covered_from_date: str
    severity_code: str
    data_store_status: str
    origin_servid: str
    context_string: str
    return_code: str
    reason_code: str
    checksum: str
    return_address: str
    table_name: str = "ExportStartIclm1Claim"
