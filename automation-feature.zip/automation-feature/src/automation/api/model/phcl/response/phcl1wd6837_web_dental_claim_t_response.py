from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Numerable, Table


class Phcl1wd6837WebDentalClaimTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        self.regex_claim_control_number = 'clp07_payer_claim_control_number'
        ErrorCode.table_name = 'ExportErrorsGIclm1Interface'
        ResponseStatus.table_name = 'ExportIclm1Interface'
        ErrorCode.name_length_table = 'ExportErrorsGroup'
        ErrorCode.name_length_field = 'export_export_errors_group_length'
        super().__init__(content)
        self.export_svc_line_g_ihipaa_lx_assigned_number = self._htmlParser.table_to_obj(ExportSvcLineGIhipaaLxAssignedNumber)
        self.export_svc_line_g_ihipaa_lx_assigned_number.length = self._htmlParser.get_table_length("ExportSvcLineGroup", "export_export_svc_line_group_length")
        self.export_iclm1_claim = self._htmlParser.table_to_obj(ExportIclm1Claim, True)


@dataclass
class ExportSvcLineGIhipaaLxAssignedNumberItem:
    """Public class which describes item structure for table ExportSvcLineGIhipaaLxAssignedNumber"""

    lx01_line_counter: str
    stc992_health_care_clm_stat_cd: str
    cas02_claim_adjustment_reason_cd: str
    explanation_code: str
    t_allowed_amount: str
    t_denied_amount: str
    t_discount_amount: str
    t_risk_amount: str
    t_deductible_amount: str
    t_paid_amount: str
    t_pricing_penalty_amount: str
    t_patient_responsibility_amount: str
    t_copayment_amount: str
    t_coinsurance_amount: str
    t_auth_penalty_amount2: str
    t_approved_amount: str


@dataclass
class ExportSvcLineGIhipaaLxAssignedNumber(Numerable):
    """Public class which describes dataclass for table ExportSvcLineGIhipaaLxAssignedNumber"""

    items: List[ExportSvcLineGIhipaaLxAssignedNumberItem]
    table_name: str = "ExportSvcLineGIhipaaLxAssignedNumber"


@dataclass
class ExportIclm1Claim(Table):
    """Public class which describes dataclass for table ExportIclm1Claim"""

    t_patient_responsibility_amount: str
    hipaa_transaction_version: str
    stc991_hlth_car_clm_stat_ctg_cd: str
    stc992_health_care_clm_stat_cd: str
    clp04_claim_payment_amount: str
    clp07_payer_claim_control_number: str
    cas03_adjustment_amount: str
    cas03_adjustment_amount_1: str
    cas03_adjustment_amount_2: str
    cas03_adjustment_amount_3: str
    cas03_adjustment_amount_4: str
    cas03_adjustment_amount_5: str
    cas03_adjustment_amount_6: str
    cas03_adjustment_amount_7: str
    cas03_adjustment_amount_8: str
    cas03_adjustment_amount_9: str
    table_name: str = "ExportIclm1Claim"
