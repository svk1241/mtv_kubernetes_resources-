from automation.api.model.common.numerable import Numerable
from dataclasses import dataclass
from typing import List


@dataclass
class ErrorCodeItem:
    """Public class .."""

    error_code: str


@dataclass
class ErrorCode(Numerable):
    """Public class .."""

    items: List[ErrorCodeItem]
    table_name: str = "should_be_override_in_child"
    name_length_table: str = "ExportErrorGroup"
    name_length_field: str = "export_export_error_group_length"
