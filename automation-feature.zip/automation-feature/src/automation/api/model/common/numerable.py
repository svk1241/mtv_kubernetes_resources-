from dataclasses import dataclass
from typing import List


@dataclass
class Table:
    """Public class .."""

    None


@dataclass
class Numerable(Table):
    items: List
    length: int = None

    @property
    def total_count(self) -> int:
        """
        Get total count for items

        :returns: count (int)

        """

        return len(self.items)
