import inspect
from automation.helper.json_helper import JsonHelper
from automation.settings import SettingsHelper


class BaseRequestModel:
    """Public class .."""
    ImportCommand = ''
    ImportClientId = ''
    ImportClientPassword = ''  # pragma: allowlist secret
    ImportNextLocation = ''
    ImportDialect = ''
    ImportExitState = '0'
    ImportCommConfig = ''
    Action = 'Execute'

    def __init__(self) -> None:
        self.set_default()

    def to_dict(self):
        """

        :returns:

        """
        attributes = inspect.getmembers(self, lambda a: isinstance(a, str))
        not_ignore_attributes = {}
        for a in attributes:
            if a[0] not in {'__module__', '__doc__'}:
                not_ignore_attributes.update({a[0]: a[1]})
        return not_ignore_attributes

    def to_json(self):
        """

        :returns:

        """
        dict = self.to_dict()
        return JsonHelper.serialize(dict)

    def set_default(self):
        attributes = inspect.getmembers(self, lambda a: isinstance(a, str))
        user = SettingsHelper.get_authorization('api')

        for a, v in attributes:
            if a.endswith('InterfaceRequestorId') or a.endswith('InterfaceUserId'):
                setattr(self, a, user.username)

            if a.endswith('InterfaceRequestorPassword') or a.endswith('InterfacePassword'):
                setattr(self, a, user.password)
