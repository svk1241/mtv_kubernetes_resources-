from automation.api.model.common.numerable import Table
from dataclasses import dataclass


@dataclass
class ResponseStatus(Table):
    """Public class .."""

    severity_code: str
    data_store_status: str
    origin_servid: str
    context_string: str
    return_code: str
    reason_code: str
    checksum: str
    return_address: str
    table_name: str = "should_be_override_in_child"
