import allure
import inspect

from automation.helper.allure_helper import AllureHelper
from automation.impl.soft_assertion import SoftAssertion
from automation.helper.assert_helper import AssertHelper
from automation.helper.string_helper import StringHelper
from automation.helper.resource_helper import ResourceHelper, ResponseHelper
from automation.parser.html_parser import HtmlParser
from automation.api.model.common.numerable import Table, Numerable
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.system_data import SystemData


class FluentAssertion:
    """Public class to provide fluent assertion interface"""

    def __init__(self, response) -> None:
        """Initialize class object

        :param response: response model
        :type response: depends on response model type
        """
        self.response = response
        self.soft_assertion = SoftAssertion()

    @allure.step("Validate response")
    def be_equal_to_expected(self, table_name: str = None, exclude_regex_field=None):
        """Perform soft assertions between actual and expected data tables

        :param expected: expected response model
        :returns: self

        :param exclude_regex_field: regex pattern for field(s) that will be ignored in html-response
        """

        ResponseHelper.save(self.response.content)
        expected_html = HtmlParser(ResourceHelper.load())

        if table_name is not None:
            attr_name = self.__get_attr_name(table_name)
            act_table = vars(self.response)[attr_name]
            self.__softassert_table(act_table, expected_html, table_name, exclude_regex_field)
        else:
            for a in inspect.getmembers(self.response, lambda a: isinstance(a, Table)):
                self.__softassert_table(a[1], expected_html, a[0], exclude_regex_field)

        self.soft_assertion.assert_all()
        return self

    def __softassert_table(self, actual, expected_html: HtmlParser, table_name: str, exclude_regex_field):
        """Get differs for input tables and perform soft assertion

        :param actual: data table
        :type actual: depends on data table type
        """
        with allure.step(f"Validate table '{table_name}'"):
            expected = self.__get_table_obj(expected_html, actual)

            AllureHelper.attach_dataclass_as_json(data=expected, displayed_name="Expected result")
            AllureHelper.attach_dataclass_as_json(data=actual, displayed_name="Actual data")

            if hasattr(actual, 'items'):
                actual = actual.items
                expected = expected.items
            self.soft_assertion.assert_differs(table_name,
                                               AssertHelper.find_differs(actual, expected, exclude_regex_field))

    def __get_attr_name(self, table_name: str):
        if table_name == SystemData.table_name:
            attr_name = SystemData.__name__
        elif table_name == ResponseStatus.table_name:
            attr_name = ResponseStatus.__name__
        elif table_name == ErrorCode.table_name:
            attr_name = ErrorCode.__name__
        else:
            attr_name = table_name

        return StringHelper.camel_to_snake(attr_name)

    def __get_table_obj(self, html: HtmlParser, src_table_type):
        """Get table object

        :param src_table_type: data table
        :type response: depends on data table type
        """
        table_type = type(src_table_type)
        transpose_dict = not issubclass(table_type, Numerable)
        return html.table_to_obj(table_type, transpose_dict)
