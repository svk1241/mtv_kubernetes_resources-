from automation.api.model.common.numerable import Table
from dataclasses import dataclass


@dataclass
class SystemData(Table):
    """Public class .."""

    export_command: str
    export_exit_state_type: str
    export_exit_state: str
    export_exit_state_message: str
    table_name: str = "System Data"
