from typing import Type, Optional
from automation.api.model.common.fluent_assertion import FluentAssertion
from automation.parser.html_parser import HtmlParser
from automation.api.model.common.numerable import Numerable, Table
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.system_data import SystemData


table = Optional[Type[Table]]
numerable = Optional[Type[Numerable]]


class BaseResponseModel:
    """Public class .."""

    def __new__(cls, *args, **kwargs):
        """Reset System Tables attributes before initialization
        """
        SystemData.table_name = "System Data"
        ErrorCode.name_length_table = "ExportErrorGroup"
        ErrorCode.name_length_field = "export_export_error_group_length"
        return super(BaseResponseModel, cls).__new__(cls)

    def __init__(self, content: str, error_code: numerable = ErrorCode, response_status: table = ResponseStatus) -> None:
        """Base response model creation.

        @dataclasses ErrorCode and ResponseStatus can be overwritten from inheritance classes

        :param error_code: @dataclass for ErrorCode table. Can be None
        :param response_status:  @dataclass for ResponseStatus table. Can be None
        """
        self.content = content
        self._htmlParser = HtmlParser(content)

        if error_code is not None:
            self.error_code = self._htmlParser.table_to_obj(error_code)
            self.error_code.length = self._htmlParser.get_table_length(error_code.name_length_table, error_code.name_length_field)

        if response_status is not None:
            self.response_status = self._htmlParser.table_to_obj(response_status, True)

        self.system_data = self._htmlParser.table_to_obj(SystemData, True)

    def should(self):
        """Fluent assertion interface

        :returns: FluentAssertion
        """
        return FluentAssertion(self)
