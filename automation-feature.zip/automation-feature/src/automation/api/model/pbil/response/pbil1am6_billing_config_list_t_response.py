from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Numerable, Table


class Pbil1am6BillingConfigListTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrGIbil1Interface'
        ErrorCode.name_length_table = 'ExportGroupErrors'
        ErrorCode.name_length_field = 'export_export_group_errors_length'
        ResponseStatus.table_name = 'ExportIbil1Interface'
        super().__init__(content)
        self.export_bill_g_ibil1_billing_span = self._htmlParser.table_to_obj(ExportBillGIbil1BillingSpan)
        self.export_bill_g_ibil1_billing_span.length = self._htmlParser.get_table_length("ExportGroupBilling", "export_export_group_billing_length")
        self.export_start_ibil1_billing_span = self._htmlParser.table_to_obj(ExportStartIbil1BillingSpan, True)
        self.export_bill_cycle_ibil1_billing_cycle = self._htmlParser.table_to_obj(ExportBillCycleIbil1BillingCycle, True)


@dataclass
class ExportBillGIbil1BillingSpanItem:
    """Public class which describes item structure for table ExportBillGIbil1BillingSpan"""

    void_flag: str
    bill_code: str
    premium_rate_key: str
    invoice_format: str
    invoice_sort_sequence: str
    enrollment_status: str
    bill_to_indicator: str
    rollup_identifier: str
    operator_identifier: str
    aso_fee_schedule_identifier: str
    aso_enroll_fee_print_ind: str
    aso_clm_cap_bill_incur_print_ind: str
    aso_clm_cap_info_print_ind: str
    aso_flat_fee_print_ind: str
    aso_other_charges_print_ind: str
    aso_payment_arrangement_ind: str
    aso_claim_fee_print_ind: str
    premium_rate_level: str
    paid_trhu_dt_calculation_method: str
    variable_print_data: str
    as_of_day: str
    billing_type_code: str
    presentment_link_code: str
    fee_inclusion_day: str
    bill_category: str
    t_effective_date: str
    t_end_date: str
    t_percent_required: str
    t_auto_adjustment_supression_dat: str
    t_creation_timestamp: str
    t_last_maintenance_timestamp: str
    t_outstanding_amount: str
    t_payment_arrangement_amount: str
    t_deposit_settlement_frequency: str
    t_deposit_charge_count: str
    t_settlement_begin_month: str
    t_admin_charge_count_month: str


@dataclass
class ExportBillGIbil1BillingSpan(Numerable):
    """Public class which describes dataclass for table ExportBillGIbil1BillingSpan"""

    items: List[ExportBillGIbil1BillingSpanItem]
    table_name: str = "ExportBillGIbil1BillingSpan"


@dataclass
class ExportStartIbil1BillingSpan(Table):
    """Public class which describes dataclass for table ExportStartIbil1BillingSpan"""

    void_flag: str
    t_effective_date: str
    t_creation_timestamp: str
    command: str
    t_count: str
    table_name: str = "ExportStartIbil1BillingSpan"


@dataclass
class ExportBillCycleIbil1BillingCycle(Table):
    """Public class which describes dataclass for table ExportBillCycleIbil1BillingCycle"""

    cycle_description: str
    cycle_identifier: str
    billing_arrangement: str
    frequency_unit: str
    direct_pay_flag: str
    operator_id: str
    override_bill_optn: str
    t_frequency_count: str
    t_cycle_begin_day: str
    t_invoice_due_day: str
    t_bill_thru_date: str
    t_secondary_bill_thru_date: str
    t_start_billing_thru_date: str
    t_secondary_start_bill_thru_dt: str
    t_last_maintenance_timestamp: str
    t_creation_timestamp: str
    t_secndry_inv_due_day: str
    billing_entity_identifier2: str
    billing_entity_type: str
    employer_group_level1_id: str
    employer_group_level2_id: str
    employer_group_level2_name: str
    operator_identifier: str
    delinquency_notification_ind: str
    delinquency_auto_terminate_ind: str
    delinquency_billing_message_ind: str
    print_invoice_flag: str
    billing_status_ind: str
    billing_arrangement_indicator: str
    aso_cycle_code: str
    billing_status_operator_id: str
    t_grace_period: str
    t_bill_thru_date_1: str
    t_creation_timestamp_1: str
    t_last_maintenance_timestamp_1: str
    t_secondary_bill_thru_date_1: str
    t_aso_bill_thru_date: str
    t_aso_bill_from_date: str
    t_aso_billing_term_days: str
    t_last_deposit_settlement_date: str
    t_billing_status_date: str
    t_late_payment_charge: str
    t_late_paymnt_chrge_grace_period: str
    t_aso_admin_bill_from_date: str
    t_aso_admin_bill_thru_date: str
    t_deposit_bill_thru_date: str
    t_last_cap_settlement_date: str
    table_name: str = "ExportBillCycleIbil1BillingCycle"
