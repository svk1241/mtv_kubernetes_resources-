from automation.api.model.common.base_request_model import BaseRequestModel


class Pbil1am6BillingConfigListTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportIbil1InterfaceSecurityId = ''
    ImportImportIbil1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportIbil1InterfaceRequestorId = ''
    ImportImportIbil1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportIbil1InterfaceReturnAddress = ''
    ImportImportQualifyIbil1BillingEntityBillingEntityIdentifier2 = ''
    ImportImportQualifyIbil1BillingEntityBillingEntityType = ''
    ImportImportQualifyIbil1BillingEntityEmployerGroupLevel1Id = ''
    ImportImportQualifyIbil1BillingSpanVoidFlag = ''
    ImportImportQualifyIbil1BillingSpanTEffectiveDate = ''
    ImportImportQualifyIbil1BillingSpanTEndDate = ''
    ImportImportStartIbil1BillingSpanVoidFlag = ''
    ImportImportStartIbil1BillingSpanTEffectiveDate = ''
    ImportImportStartIbil1BillingSpanTCreationTimestamp = ''
    ImportImportListControlsIefSuppliedCommand = ''
    ImportImportListControlsIefSuppliedTextTCount = ''
