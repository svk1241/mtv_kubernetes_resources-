from automation.api.model.common.base_request_model import BaseRequestModel


class Phme1ac2834IdCardRequestTRequest(BaseRequestModel):
    """Public class .."""

    ImportImportIhme1InterfaceSecurityId = ''
    ImportImportIhme1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportIhme1InterfaceRequestorId = ''
    ImportImportIhme1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportIhme1InterfaceReturnAddress = ''
    ImportImportIhme1IdcIdc01IdCardPlanCoverageDesc = ''
    ImportImportIhme1IdcIdc02IdCardTypeCode = ''
    ImportImportIhme1IdcIdc04IdCardActionCode = ''
    ImportImportIhme1IdcTIdc03IdCardCount = ''
    ImportImportIhme1IdcIdc01OverrideHoldFlag = ''
    ImportImportIhme1SubscriberLvlRef02SubidSubscriberId = ''
    ImportImportIhme1MemberLvlRef02MbridSubscriberSupId = ''
