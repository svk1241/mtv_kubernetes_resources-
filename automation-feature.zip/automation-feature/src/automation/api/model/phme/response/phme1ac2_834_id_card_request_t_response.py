from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.response_status import ResponseStatus
from automation.api.model.common.error_code import ErrorCode


class Phme1ac2834IdCardRequestTResponse(BaseResponseModel):
    """Public class .."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorGIhme1Interface'
        ResponseStatus.table_name = 'ExportIhme1Interface'
        super().__init__(content)
