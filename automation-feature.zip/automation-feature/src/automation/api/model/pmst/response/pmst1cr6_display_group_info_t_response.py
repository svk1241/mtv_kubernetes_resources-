from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Table


class Pmst1cr6DisplayGroupInfoTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorGImst1Interface'
        super().__init__(content, response_status=ResponseStatusExtended)
        self.export_imst1_employer_group_level1 = self._htmlParser.table_to_obj(ExportImst1EmployerGroupLevel1, True)


@dataclass
class ExportImst1EmployerGroupLevel1(Table):
    """Public class which describes dataclass for table ExportImst1EmployerGroupLevel1"""

    identifier: str
    name: str
    information: str
    region_code: str
    region_code_desc: str
    group_type_code: str
    group_type_code_desc: str
    national_account_prefix: str
    national_account_identifier: str
    standard_industry_code: str
    std_industry_code_desc: str
    operator_identifier: str
    group_approval_required_flag: str
    assumed_eligibility_indicator: str
    national_employer_identifier: str
    group_rep_id: str
    group_size_cat_cd: str
    group_size_cat_cd_desc: str
    group_rep_id_desc: str
    primary_payer65_indicator: str
    coverage_continuation_indicator: str
    dental_pred_accepted_flag: str
    newborn_initial_coverage_flag: str
    internal_reinsurer_flag: str
    medical_waive_new_gp_wait_p_flag: str
    dental_waive_new_gp_wait_pe_flag: str
    submission_type_indicator: str
    disease_management_indicator: str
    prior_carrier_name: str
    prior_dental_coverage_ind: str
    prior_orthodontia_coverage_ind: str
    legal_entity_code: str
    legal_entity_code_desc: str
    cob_liability_rule: str
    del_delinquency_status: str
    third_party_admn_clm_dt_used_ind: str
    assignment_of_benefits_ind: str
    t_employees_on_payroll_number: str
    t_dental_eligible_employees_coun: str
    t_dental_initial_enrollment_coun: str
    t_original_effective_date: str
    t_renewal_date: str
    t_last_enroll_date: str
    del_t_pending_termination_date: str
    t_creation_timestamp: str
    t_surrogate_id: str
    t_medical_eligible_employees_num: str
    t_medical_enrolled_employees_num: str
    t_last_maintenance_timestamp: str
    table_name: str = "ExportImst1EmployerGroupLevel1"


@dataclass
class ResponseStatusExtended(Table):
    """Public class which describes dataclass for table ExportImst1Interface"""

    return_address: str
    severity_code: str
    data_store_status: str
    origin_srevid: str
    context_string: str
    return_code: str
    reason_code: str
    checksum: str
    table_name: str = "ExportImst1Interface"
