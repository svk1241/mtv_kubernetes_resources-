from typing import List
from dataclasses import dataclass
from automation.api.model.common.base_response_model import BaseResponseModel
from automation.api.model.common.error_code import ErrorCode
from automation.api.model.common.numerable import Numerable, Table


class Pmst1bp4EglXBenePkgListTResponse(BaseResponseModel):
    """Public class extends BaseResponseModel and describes response model for specific API."""

    def __init__(self, content) -> None:
        ErrorCode.table_name = 'ExportErrorsGImst1Interface'
        ErrorCode.name_length_table = 'ExportErrorsGroup'
        ErrorCode.name_length_field = 'export_export_errors_group_length'
        super().__init__(content, response_status=ResponseStatusExtended)
        self.export_eglx_ben_pkg_remark_g_iben1_benefit_package = self._htmlParser.table_to_obj(ExportEglxBenPkgRemarkGIben1BenefitPackage)
        self.export_eglx_ben_pkg_remark_g_iben1_benefit_package.length = self._htmlParser.get_table_length("ExportEglxBenPkgRemarkGroup", "export_export_eglx_ben_pkg_remark_group_length")
        self.export_eglx_ben_pkg_g_imst1_egl_x_ben_pkg = self._htmlParser.table_to_obj(ExportEglxBenPkgGImst1EglXBenPkg)
        self.export_eglx_ben_pkg_g_imst1_egl_x_ben_pkg.length = self._htmlParser.get_table_length("ExportEglxBenPkgGroup", "export_export_eglx_ben_pkg_group_length")
        self.export_start_imst1_egl_x_ben_pkg = self._htmlParser.table_to_obj(ExportStartImst1EglXBenPkg, True)


@dataclass
class ExportEglxBenPkgRemarkGIben1BenefitPackageItem:
    """Public class which describes item structure for table ExportEglxBenPkgRemarkGIben1BenefitPackage"""

    benefit_package_id: str
    remark_text: str
    remark_code_value: str
    t_sequence_number: str


@dataclass
class ExportEglxBenPkgRemarkGIben1BenefitPackage(Numerable):
    """Public class which describes dataclass for table ExportEglxBenPkgRemarkGIben1BenefitPackage"""

    items: List[ExportEglxBenPkgRemarkGIben1BenefitPackageItem]
    table_name: str = "ExportEglxBenPkgRemarkGIben1BenefitPackage"


@dataclass
class ExportEglxBenPkgGImst1EglXBenPkgItem:
    """Public class which describes item structure for table ExportEglxBenPkgGImst1EglXBenPkg"""

    employer_group_level1_id: str
    employer_group_level2_id: str
    benefit_package_id: str
    funding_type: str
    employment_class_code: str
    class_code: str
    employment_status_code: str
    void_flag: str
    operator_identifier: str
    t_effective_date: str
    t_end_date: str
    t_creation_timestamp: str
    t_last_maintenance_timestamp: str
    benefit_package_type_code: str
    line_of_business_code: str
    coverage_id_state: str
    coverage_id_modifier: str
    information: str
    medical_pcp_required_flag: str
    dental_pcp_required_flag: str
    network_required_flag: str
    dental_network_required_flag: str
    pcp_contract_required_ind: str
    benefit_package_cross_reference: str
    operator_identifier_1: str
    t_pricing_priority: str
    t_creation_timestamp_1: str
    t_last_maintenance_timestamp_1: str
    drug_level_code: str
    information1_code: str


@dataclass
class ExportEglxBenPkgGImst1EglXBenPkg(Numerable):
    """Public class which describes dataclass for table ExportEglxBenPkgGImst1EglXBenPkg"""

    items: List[ExportEglxBenPkgGImst1EglXBenPkgItem]
    table_name: str = "ExportEglxBenPkgGImst1EglXBenPkg"


@dataclass
class ResponseStatusExtended(Table):
    """Public class which describes dataclass for table ExportImst1Interface"""

    return_address: str
    severity_code: str
    data_store_status: str
    origin_srevid: str
    context_string: str
    return_code: str
    reason_code: str
    checksum: str
    table_name: str = "ExportImst1Interface"


@dataclass
class ExportStartImst1EglXBenPkg(Table):
    """Public class which describes dataclass for table ExportStartImst1EglXBenPkg"""

    employer_group_level2_id: str
    benefit_package_id: str
    void_flag: str
    t_end_date: str
    t_creation_timestamp: str
    t_sequence_number: str
    command: str
    t_count: str
    table_name: str = "ExportStartImst1EglXBenPkg"
