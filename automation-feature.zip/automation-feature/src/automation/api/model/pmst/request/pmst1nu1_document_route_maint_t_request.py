from automation.api.model.common.base_request_model import BaseRequestModel


class Pmst1nu1DocumentRouteMaintTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportImst1InterfaceSecurityId = ''
    ImportImportImst1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImst1InterfaceRequestorId = ''
    ImportImportImst1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImst1InterfaceReturnAddress = ''
    ImportImportImst1InterfaceActionIndicator = ''
    ImportImportImst1DocumentRoutingWhoTypeIndicator = ''
    ImportImportImst1DocumentRoutingWhoIdentifier = ''
    ImportImportImst1DocumentRoutingVoidFlag = ''
    ImportImportImst1DocumentRoutingDocumentCategoryType = ''
    ImportImportImst1DocumentRoutingRouteToIndicator = ''
    ImportImportImst1DocumentRoutingRouteToType = ''
    ImportImportImst1DocumentRoutingAddressCode = ''
    ImportImportImst1DocumentRoutingAlternateAddressFlag = ''
    ImportImportImst1DocumentRoutingTEffectiveFromMonth = ''
    ImportImportImst1DocumentRoutingTEffectiveFromDay = ''
    ImportImportImst1DocumentRoutingTEffectiveThruMonth = ''
    ImportImportImst1DocumentRoutingTEffectiveThruDay = ''
    ImportImportImst1DocumentRoutingTLastMaintenanceTimestamp = ''
    ImportImportDivMbrImst1DocumentRoutingWhoIdentifier = ''
