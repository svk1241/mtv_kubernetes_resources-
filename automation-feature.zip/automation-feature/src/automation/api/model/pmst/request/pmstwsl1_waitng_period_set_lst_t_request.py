from automation.api.model.common.base_request_model import BaseRequestModel


class Pmstwsl1WaitngPeriodSetLstTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportIsec1InterfaceSecurityId = ''
    ImportImportIsec1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportIsec1InterfaceRequestorId = ''
    ImportImportIsec1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportIsec1InterfaceReturnAddress = ''
    ImportImportIsec1InterfaceSearchType = ''
    ImportImportQualifyImst1WaitingPeriodSetVoidFlag = ''
    ImportImportQualifyImst1WaitingPeriodSetWaitingPeriodSetDescription = ''
    ImportImportQualifyImst1WaitingPeriodSetWaitingPeriodSetId = ''
    ImportImportQualifyImst1WaitingPeriodSetWaitingPeriodType = ''
    ImportImportQualify1Imst1EmployerGroupLevelEmployerGroupLevel1Id = ''
    ImportImportQualify1Imst1EmployerGroupLevelEmployerGroupLevel2Id = ''
    ImportImportStartImst1WaitingPeriodSetWaitingPeriodSetDescription = ''
    ImportImportStartImst1WaitingPeriodSetWaitingPeriodSetId = ''
    ImportImportListControlsIefSuppliedCommand = ''
    ImportImportListControlsIefSuppliedTextTCount = ''
