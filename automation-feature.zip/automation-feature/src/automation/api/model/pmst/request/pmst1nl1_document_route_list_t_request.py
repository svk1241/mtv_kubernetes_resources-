from automation.api.model.common.base_request_model import BaseRequestModel


class Pmst1nl1DocumentRouteListTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportImst1InterfaceSecurityId = ''
    ImportImportImst1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImst1InterfaceRequestorId = ''
    ImportImportImst1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImst1InterfaceReturnDescriptionsFlag = ''
    ImportImportImst1InterfaceReturnAddress = ''
    ImportImportQualifyImst1DocumentRoutingWhoTypeIndicator = ''
    ImportImportQualifyImst1DocumentRoutingWhoIdentifier = ''
    ImportImportQualifyImst1DocumentRoutingVoidFlag = ''
    ImportImportQualifyDivMbrImst1DocumentRoutingWhoIdentifier = ''
    ImportImportStartImst1DocumentRoutingDocumentCategoryType = ''
    ImportImportStartImst1DocumentRoutingTCreationTimestamp = ''
    ImportImportStartImst1DocumentRoutingVoidFlag = ''
    ImportImportPagingControlsIefSuppliedCommand = ''
    ImportImportPagingControlsIefSuppliedTextTCount = ''
