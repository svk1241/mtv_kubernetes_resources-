from automation.api.model.common.base_request_model import BaseRequestModel


class Pmst1bp4EglXBenePkgListTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportSecurityImst1InterfaceSecurityId = ''
    ImportImportSecurityImst1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportSecurityImst1InterfaceRequestorId = ''
    ImportImportSecurityImst1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportSecurityImst1InterfaceReturnAddress = ''
    ImportImportQualifyImst1EglXBenPkgEmployerGroupLevel1Id = ''
    ImportImportQualifyImst1EglXBenPkgEmployerGroupLevel2Id = ''
    ImportImportQualifyImst1EglXBenPkgVoidFlag = ''
    ImportImportQualifyImst1EglXBenPkgTEffectiveDate = ''
    ImportImportQualifyImst1EglXBenPkgTEndDate = ''
    ImportImportStartImst1EglXBenPkgEmployerGroupLevel2Id = ''
    ImportImportStartImst1EglXBenPkgBenefitPackageId = ''
    ImportImportStartImst1EglXBenPkgVoidFlag = ''
    ImportImportStartImst1EglXBenPkgTEndDate = ''
    ImportImportStartImst1EglXBenPkgTCreationTimestamp = ''
    ImportImportStartIben1BenefitPackageRemarkTSequenceNumber = ''
    ImportImportPagingControlsIefSuppliedCommand = ''
    ImportImportPagingControlsIefSuppliedTextTCount = ''
