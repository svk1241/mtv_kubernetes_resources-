from automation.api.model.common.base_request_model import BaseRequestModel


class Pmst1jl2BusLvlNetwrkListTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportImst1InterfaceSecurityId = ''
    ImportImportImst1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImst1InterfaceRequestorId = ''
    ImportImportImst1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImst1InterfaceReturnAddress = ''
    ImportImportListCommandsIefSuppliedCommand = ''
    ImportImportListControlsIefSuppliedTextTCount = ''
    ImportImportQualifyImst1EglXBusLvlNtwkAssnEmployerGroupLevel1Id = ''
    ImportImportQualifyImst1EglXBusLvlNtwkAssnEmployerGroupLevel2Id = ''
    ImportImportQualifyImst1EglXBusLvlNtwkAssnVoidFlag = ''
    ImportImportQualifyImst1EglXBusLvlNtwkAssnTEffectiveDate = ''
    ImportImportQualifyImst1EglXBusLvlNtwkAssnTEndDate = ''
    ImportImportStartImst1EglXBusLvlNtwkAssnVoidFlag = ''
    ImportImportStartImst1EglXBusLvlNtwkAssnBusinessLevel4Id = ''
    ImportImportStartImst1EglXBusLvlNtwkAssnBusinessLevel5Id = ''
    ImportImportStartImst1EglXBusLvlNtwkAssnBusinessLevel6Id = ''
    ImportImportStartImst1EglXBusLvlNtwkAssnBusinessLevel7Id = ''
    ImportImportStartImst1EglXBusLvlNtwkAssnNetworkIdentifier = ''
    ImportImportStartImst1EglXBusLvlNtwkAssnTEndDate = ''
