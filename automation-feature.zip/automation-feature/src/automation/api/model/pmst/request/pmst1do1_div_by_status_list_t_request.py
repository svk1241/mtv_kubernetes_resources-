from automation.api.model.common.base_request_model import BaseRequestModel


class Pmst1do1DivByStatusListTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportSecurityImst1InterfaceSecurityId = ''
    ImportImportSecurityImst1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportSecurityImst1InterfaceRequestorId = ''
    ImportImportSecurityImst1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportSecurityImst1InterfaceReturnAddress = ''
    ImportImportListControlsIefSuppliedTextTCount = ''
    ImportImportListControlsIefSuppliedCommand = ''
    ImportImportQualifyImst1EmployerGroupLevel2Identifier = ''
    ImportImportQualifyImst1EmployerGroupLevel2EmployerGroupLevel1Id = ''
    ImportImportQualifyEmpGrpLevel2Imst1InterfaceEntityStatus = ''
    ImportImportQualifyImst1EmployerGrpLvlXSpanTEffectiveDate = ''
    ImportImportQualifyImst1EmployerGrpLvlXSpanTEndDate = ''
    ImportImportStartPagingImst1EmployerGroupLevel2Identifier = ''
