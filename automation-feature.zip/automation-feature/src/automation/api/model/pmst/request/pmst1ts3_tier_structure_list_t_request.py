from automation.api.model.common.base_request_model import BaseRequestModel


class Pmst1ts3TierStructureListTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportSecurityImst1InterfaceSecurityId = ''
    ImportImportSecurityImst1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportSecurityImst1InterfaceRequestorId = ''
    ImportImportSecurityImst1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportSecurityImst1InterfaceReturnAddress = ''
    ImportImportQualifyImst1EglXEmpClsTierStrctEmployerGroupLevel1Id = ''
    ImportImportQualifyImst1EglXEmpClsTierStrctEmployerGroupLevel2Id = ''
    ImportImportQualifyImst1EglXEmpClsTierStrctTEffectiveDate = ''
    ImportImportQualifyImst1EglXEmpClsTierStrctTEndDate = ''
    ImportImportQualifyImst1EglXEmpClsTierStrctVoidFlag = ''
    ImportImportStartImst1EglXEmpClsTierStrctTierStructureCode = ''
    ImportImportStartImst1EglXEmpClsTierStrctTEndDate = ''
    ImportImportListControlsIefSuppliedCommand = ''
    ImportImportListControlsIefSuppliedTextTCount = ''
