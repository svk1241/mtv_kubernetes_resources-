from automation.api.model.common.base_request_model import BaseRequestModel


class Pmst1ht1ListEglxSpanTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportImst1InterfaceSecurityId = ''
    ImportImportImst1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImst1InterfaceRequestorId = ''
    ImportImportImst1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImst1InterfaceReturnAddress = ''
    ImportImportQualifyImst1EmployerGrpLvlXSpanEmployerGroupLevel = ''
    ImportImportQualifyImst1EmployerGrpLvlXSpanEmployerGroupLevel1Id = ''
    ImportImportQualifyImst1EmployerGrpLvlXSpanEmployerGroupLevel2Id = ''
    ImportImportQualifyImst1EmployerGrpLvlXSpanVoidFlag = ''
    ImportImportQualifyImst1EmployerGrpLvlXSpanTEffectiveDate = ''
    ImportImportQualifyImst1EmployerGrpLvlXSpanTEndDate = ''
    ImportImportStartImst1EmployerGrpLvlXSpanVoidFlag = ''
    ImportImportStartImst1EmployerGrpLvlXSpanTEffectiveDate = ''
    ImportImportStartImst1EmployerGrpLvlXSpanTCreationTimestamp = ''
    ImportImportPagingControlIefSuppliedCommand = ''
    ImportImportPagingControlIefSuppliedTextTCount = ''
