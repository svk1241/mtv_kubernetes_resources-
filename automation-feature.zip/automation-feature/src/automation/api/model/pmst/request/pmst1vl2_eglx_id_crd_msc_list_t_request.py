from automation.api.model.common.base_request_model import BaseRequestModel


class Pmst1vl2EglxIdCrdMscListTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportImst1InterfaceSecurityId = ''
    ImportImportImst1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImst1InterfaceRequestorId = ''
    ImportImportImst1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImst1InterfaceReturnAddress = ''
    ImportImportImst1InterfaceReturnDescriptionsFlag = ''
    ImportImportQualifyImst1EglXIdCardInfoEmployerGroupLevel1Id = ''
    ImportImportQualifyImst1EglXIdCardInfoEmployerGroupLevel2Id = ''
    ImportImportQualifyImst1EglXIdCardInfoVoidFlag = ''
    ImportImportQualifyImst1EglXIdCardInfoBenefitPackageId = ''
    ImportImportQualifyImst1EglXIdCardInfoTEffectiveDate = ''
    ImportImportQualifyImst1EglXIdCardInfoTEndDate = ''
    ImportImportStartImst1EglXIdCardInfoEmployerGroupLevel2Id = ''
    ImportImportStartImst1EglXIdCardInfoVoidFlag = ''
    ImportImportStartImst1EglXIdCardInfoBenefitPackageId = ''
    ImportImportStartImst1EglXIdCardInfoTEndDate = ''
    ImportImportStartImst1EglXIdCardInfoTCreationTimestamp = ''
    ImportImportPagingControlsIefSuppliedTextTCount = ''
    ImportImportPagingControlsIefSuppliedCommand = ''
