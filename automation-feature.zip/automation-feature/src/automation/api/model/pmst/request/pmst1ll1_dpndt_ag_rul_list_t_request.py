from automation.api.model.common.base_request_model import BaseRequestModel


class Pmst1ll1DpndtAgRulListTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportImst1InterfaceSecurityId = ''
    ImportImportImst1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImst1InterfaceRequestorId = ''
    ImportImportImst1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImst1InterfaceReturnAddress = ''
    ImportImportQualifyImst1EglXDependentAgeRulesBenefitPackageId = ''
    ImportImportQualifyImst1EglXDependentAgeRulesVoidFlag = ''
    ImportImportQualifyImst1EglXDependentAgeRulesEmployerGroupLevel2Id = ''
    ImportImportQualifyImst1EglXDependentAgeRulesEmployerGroupLevel1Id = ''
    ImportImportQualifyImst1EglXDependentAgeRulesTEndDate = ''
    ImportImportQualifyImst1EglXDependentAgeRulesTEffectiveDate = ''
    ImportImportStartImst1EglXDependentAgeRulesBenefitPackageId = ''
    ImportImportStartImst1EglXDependentAgeRulesBusinessLevel7Id = ''
    ImportImportStartImst1EglXDependentAgeRulesBusinessLevel6Id = ''
    ImportImportStartImst1EglXDependentAgeRulesBusinessLevel5Id = ''
    ImportImportStartImst1EglXDependentAgeRulesBusinessLevel4Id = ''
    ImportImportStartImst1EglXDependentAgeRulesVoidFlag = ''
    ImportImportStartImst1EglXDependentAgeRulesTCreationTimestamp = ''
    ImportImportStartImst1EglXDependentAgeRulesTEndDate = ''
    ImportImportPagingListControlsIefSuppliedCommand = ''
    ImportImportPagingListControlsIefSuppliedTextTCount = ''
