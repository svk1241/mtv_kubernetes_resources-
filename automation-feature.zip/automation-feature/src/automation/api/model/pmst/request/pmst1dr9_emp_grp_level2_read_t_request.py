from automation.api.model.common.base_request_model import BaseRequestModel


class Pmst1dr9EmpGrpLevel2ReadTRequest(BaseRequestModel):
    """Public class extends BaseRequestModel and describes request model for specific API."""

    ImportImportImst1InterfaceSecurityId = ''
    ImportImportImst1InterfaceSecurityPassword = ''  # pragma: allowlist secret
    ImportImportImst1InterfaceRequestorId = ''
    ImportImportImst1InterfaceRequestorPassword = ''  # pragma: allowlist secret
    ImportImportImst1InterfaceReturnAddress = ''
    ImportImportQualifyIh8341RefSegmentRef02MbrPlcyIdInsGroupNum = ''
    ImportImportQualifyIh8341RefSegmentRef02MbrIdDepartmentNumber = ''
