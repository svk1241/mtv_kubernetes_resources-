/**
 * This is template of terraform pipeline for projects
 * Copy it and fill with your settings
 */

/* groovylint-disable-next-line NoDef, UnusedVariable, VariableName, VariableTypeRequired */
@Library('shared_devops') _

// For local execution for GCP set key to start work: `export GOOGLE_CREDENTIALS=../terraform-service-account.json`
// where ../terraform-service-account.json is yor account key
String checkovVersion = '2.3.316'
String terraformVersion = '1.8.4'
String azureCliVersion = '2.61.0'
String tfDocsVersion = '0.18.0'
String infracostVersion = '0.3.18'
String registryUrl = 'https://lxftlmshubacr.azurecr.io'
String registryCredentialsId = 'lxftlmshubacr_credentials'

// jenkins node
terraformPipeline.nodelabel = 'smop-linux'
// Agent settings
// During pipeline execution, every container will be run with option `--user=root`
// terraform docker agent properties
Map<String,String> terraformAgent  = [
    image : "terraform-azure-cli:${terraformVersion}-${azureCliVersion}-${tfDocsVersion}",
    registryUrl : registryUrl,
    registryCredentialsId : registryCredentialsId,
    args : '',
    nodeLabel : terraformPipeline.nodelabel
]

// checkov docker agent properties
Map<String,String> checkovAgent  = [
    image : "bridgecrew/checkov:${checkovVersion}",
    registryUrl : registryUrl,
    registryCredentialsId : registryCredentialsId,
    args : '',
    nodeLabel : terraformPipeline.nodelabel
]

Map<String,String> infracostAgent = [
    image : "infracost/infracost:${infracostVersion}",
    registryUrl : registryUrl,
    registryCredentialsId : registryCredentialsId,
    args : '',
    nodeLabel : terraformPipeline.nodelabel
]

//Steps for Terraform pipeline.
terraformPipeline.terraformSteps = [
    'plan' : true,
    'validate': true,
    'fmt' : true,
    'docsCreate' : false,
    'docsCheck' : false,
    'checkov' : false,
    'infracost' : false
]

// Project structure
terraformPipeline.folders = [
    'terraform' : ['terraform', 'init'],    // folders where terraform code can be found except modules
    'ci' : ['jenkinsfiles'],                // folders where ci code can be found
    'ciTest' : 'init-intfrastructure',      // [Optional] folder which can be used for tests against ci changes. Can be empty if no tests needed
    'tfModules': ['modules'],               // folders where terraform modules can be found if they are not inside main terraform folder
    'tfModulesTest': 'terraform-test',      // [Optional] folder which can be used for tests against modules changes. Can be empty if no tests needed
    'tfDocsRoot': 'terraform1'               // [Optional] folder for terraform-docs tool, should contain terraform modules
]

// If you're specifying credentials for downloading modules from other git repositories,
// make sure to either provide '--user=root' to terraformAgent.args,
// or that you can edit ~/.netrc file in terraform-cli container
// Use this functionality with caution outside containers - credentials are stored in plaintext
//
// Example:
// terraformPipeline.externalModulesAuthData = [
//     'luxproject.luxoft.com': 'lms_git_access'
// ]
terraformPipeline.externalModulesAuthData = [:]

// Project name in BB
terraformPipeline.project = 'SMOP'
// Project repository name in BB
terraformPipeline.repo = 'terraform_infrastructure'
// Credentials for git clone from BB
/* groovylint-disable-next-line DuplicateStringLiteral */
terraformPipeline.repoCreds = 'lms_git_access'
// Cloud type for terraform. Can be 'AWS', 'GCP' or 'Azure'
terraformPipeline.cloudType = 'GCP'
// Cloud credentials for terraform.
// For Azure should be file, contains variables: ARM_CLIENT_ID,ARM_CLIENT_SECRET,ARM_TENANT_ID,ARM_SUBSCRIPTION_ID
// For GCP should be a file with GCP json key
// for AWS should be file, contains variables AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY and optionally AWS_SESSION_TOKEN when you use temporary credentials
terraformPipeline.cloudCredentials = 'jenkins_cloud_credentials_name'
// infracost settings
terraformPipeline.infracostApiKeyCredentialsId = 'infracost_self_hosted_api_key'
terraformPipeline.infracostApiEndpoint = 'https://infracost.lms-team.org'
// Set to true if PR should have 1 or more approves before merging
terraformPipeline.isNeedApprove = false
// Set to true if PR can be approved with service account in case of absent approve for PR
terraformPipeline.allowApproveWithServiceAccount = false
//Start execution of pipeline
terraformPipeline(terraformAgent, checkovAgent, infracostAgent)
