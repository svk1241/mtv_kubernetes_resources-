package vars

import static org.junit.jupiter.api.Assertions.assertEquals

import com.lesfurets.jenkins.unit.BasePipelineTest
import groovy.transform.CompileDynamic
import org.junit.jupiter.api.DisplayName
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.BeforeEach

/**
 * Class TestTeams contains unit tests for jenkins shared library (library/vars/teams.groovy)
 */
@Tag('teams')
@CompileDynamic
class TestTeams extends BasePipelineTest {

    static String scriptPath = 'library/vars/teams.groovy'

    /**
     * Stores output of `sh` jenkins method
     */
    String shOutput

    /**
     * Jenkins methods names
     */
    String shell = 'sh'

    /**
     * Mock jenkins methods for testing
     */
    void addAllowedMethods() {
        helper.registerAllowedMethod(shell, [String]) { x ->
            shOutput = x as String
            return { -> x }
        }
        helper.registerAllowedMethod('writeJSON', [Map]) { m ->
            return
        }
    }

    /**
     * Set all output variables to initial state, call before each test
     */
    void initOutputVars() {
        shOutput = null
    }

    String replaceMultipleWhitespaces(String s) {
        return s.replaceAll('\s+', ' ')
    }

    /**
     * setUp is called before each test, it ensures that all needed jenkins methods are mocked and output variables are set to empty
     */
    @BeforeEach
    void setUp() {
        super.setUp()
        initOutputVars()
        addAllowedMethods()
    }

    /**
     * Tests shell command invoked in `sendChannelNotificationWithIncomingWebhook`
     */
    @Test
    @DisplayName('Test send channel notification via Incoming webhook')
    @Tag('teams')
    void testSendChannelNotificationWithIncomingWebhook() {
        Script script = loadScript(scriptPath)
        String testIncomingWebhookUrl = 'https://test.webhook.url'
        String testTitle = 'Test title'
        String testText = 'Test text'

        // shOutput stores output from tested method
        script.sendChannelNotificationWithIncomingWebhook(testIncomingWebhookUrl, testTitle, testText)
        String expected = """curl -vvv --fail -H 'Content-Type: application/json' \
        --data @./tmp-ms-teams-webhook-notification.json ${testIncomingWebhookUrl} && \
        rm ./tmp-ms-teams-webhook-notification.json"""
        assertEquals(replaceMultipleWhitespaces(expected), replaceMultipleWhitespaces(shOutput))
    }

    @Test
    @DisplayName('Test sending notification with custom json structure')
    @Tag('teams')
    void testSendChannelNotificationWithIncomingWebhookCustomPayload() {
        Script script = loadScript(scriptPath)
        String testIncomingWebhookUrl = 'https://test.webhook.url'
        String testJsonPayload = '{"title": "Test title", "text": "Test text"}'

        script.sendChannelNotificationWithIncomingWebhookCustomPayload(testIncomingWebhookUrl, testJsonPayload)
        String expected = """curl -vvv --fail -H 'Content-Type: application/json' \
                            --data '${testJsonPayload}' ${testIncomingWebhookUrl}"""
        assertEquals(replaceMultipleWhitespaces(expected), replaceMultipleWhitespaces(shOutput))
    }

}
