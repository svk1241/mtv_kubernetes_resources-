package vars

import static org.junit.jupiter.api.Assertions.assertEquals
import static org.junit.Assert.assertTrue

import com.lesfurets.jenkins.unit.BasePipelineTest
import groovy.transform.CompileDynamic
import org.junit.jupiter.api.DisplayName
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.BeforeEach

/**
 * Class TestJira contains unit tests for jenkins shared library (jenkinsfiles/vars/bitbucket.groovy)
 */
@Tag('GitHelper')
@CompileDynamic
class TestGitHelper extends BasePipelineTest {

    static String scriptPath = 'library/vars/gitHelper.groovy'
    Script script

    /**
     * Jenkins methods names
     */
    String shell = 'sh'

    /**
     * Mock jenkins methods for testing
     */
    void addAllowedMethods() {
        helper.registerAllowedMethod(shell, [String]) { script ->
            switch (script) {
                case 'git diff --name-only origin/terraform_test1':
                    return ['terraform/main.tf','terraform/main.tfvars'].join('\n')
                case 'git diff --name-only origin/terraform_test2':
                    return ['terraform-init/main.tf','terraform/main.tfvars'].join('\n')
                case 'git diff --name-only origin/terraform_test3':
                    return ['jenkinsfiles/pr.jenkinsfile','terraform/main.tfvars'].join('\n')
                case 'git diff --name-only origin/terraform_test4':
                    return ['jenkinsfiles/pr.jenkinsfile'].join('\n')
                default:
                    return script
            }
        }
        helper.registerAllowedMethod(shell, [Map]) { m ->
            switch ( m.script) {
                case 'git diff --name-only origin/terraform_test1':
                    return ['terraform/main.tf','terraform/main.tfvars'].join('\n')
                case 'git diff --name-only origin/terraform_test2':
                    return ['terraform-init/main.tf','terraform/main.tfvars'].join('\n')
                case 'git diff --name-only origin/terraform_test3':
                    return ['jenkinsfiles/pr.jenkinsfile','terraform/main.tfvars'].join('\n')
                case 'git diff --name-only origin/terraform_test4':
                    return ['jenkinsfiles/pr.jenkinsfile'].join('\n')
                default:
                    return m.script
            }
        }
    }

    /**
     * setUp is called before each test, it ensures that all needed jenkins methods are mocked and output variables are set to empty
     */
    @BeforeEach
    void setUp() {
        super.setUp()
        addAllowedMethods()
        script = loadScript(scriptPath)
    }

    /**
     * Tests method `getPrChangedFiles`
     */
    @Test
    @DisplayName('Test getPrChangedFiles')
    @Tag('getPrChangedFiles')
    void testGetPrChangedFiles() {
        Script script = loadScript(scriptPath)
        String expected1 = ['terraform/main.tf','terraform/main.tfvars']
        String expected2 = ['terraform-init/main.tf','terraform/main.tfvars']
        String expected3 = ['jenkinsfiles/pr.jenkinsfile','terraform/main.tfvars']
        String expected4 = ['jenkinsfiles/pr.jenkinsfile']
        String result = script.getPrChangedFiles('terraform_test1')
        assertEquals(expected1, result)
        result = script.getPrChangedFiles('terraform_test2')
        assertEquals(expected2, result)
        result = script.getPrChangedFiles('terraform_test3')
        assertEquals(expected3, result)
        result = script.getPrChangedFiles('terraform_test4')
        assertEquals(expected4, result)
    }

    @Test
    @DisplayName('Test testCommitToGit')
    @Tag('testCommitToGit')
    void testCommitToGit() {
        // Arrange
        String repoFolder = './testRepo'
        String commitMessage = 'Test commit message'

        // Mock the sh method to simulate git commands
        helper.registerAllowedMethod('sh', [GString], { GString shScript ->
            if (shScript.contains('git add')) {
                assertTrue(shScript.contains(repoFolder))
            }
            if (shScript.contains('git commit')) {
                assertTrue(shScript.contains(commitMessage))
            }
            if (shScript.contains('git push')) {
                assertTrue(shScript.contains('git push origin1'))
            }
        })

        // Act
        script.commitToGit(repoFolder, commitMessage)

        // Assert
        // Assertions are done within the mock sh method
        printCallStack()
    }

}
