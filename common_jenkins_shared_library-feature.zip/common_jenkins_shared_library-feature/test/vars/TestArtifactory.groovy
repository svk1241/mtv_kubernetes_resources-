package vars

import static org.junit.jupiter.api.Assertions.assertEquals

import groovy.transform.CompileDynamic
import com.lesfurets.jenkins.unit.BasePipelineTest
import groovy.json.JsonSlurper
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.DisplayName
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test

/**
 * TestArtifactory contains unit tests of methods defined in jenkins shared library (library/vars/jfrog.groovy)
 */
@Tag('jfrog')
@CompileDynamic
class TestArtifactory extends BasePipelineTest {

    static String scriptPath = 'library/vars/jfrog.groovy'

    /**
     * Stores output of `sh` jenkins method
     */
    String shOutput

    /**
     * Stores error message passed to `error` jenkins method
     */
    String errorMessage

    /**
     * Common method parameters used for testing
     */
    String testOldFolderName = 'test-old-folder'
    String testOldFileName = 'test-old-file-name'
    String testNewFileName = 'test-new-file-name'
    String testNewFolderName = 'test-new-folder-name'
    String testExistingFolderName = 'test-folder'
    String testExistingFileName = 'test-file'
    String artifactory = 'https://artifactory.url'

    /**
     * Jenkins shell method name
     */
    String shell = 'sh'

    /**
     * Set all output variables to initial state, call before each test
     */
    void initOutputVars() {
        shOutput = null
        errorMessage = null
    }

    /**
     * Mock jenkins methods for testing
     */
    void addAllowedMethods() {
        helper.registerAllowedMethod('error', [String]) { x ->
            errorMessage = x
        }
        helper.registerAllowedMethod(shell, [String]) { x ->
            shOutput = x
            return x
        }
        helper.registerAllowedMethod(shell, [Map]) { x ->
            shOutput = x.script
            if (x.returnStatus != null && x.returnStatus) {
                return 0
            }
            return x.script
        }

        helper.registerAllowedMethod('readJSON', [Map]) { x ->
            Object jsonObj = new JsonSlurper().parseText(x.text as String)
            return jsonObj
        }
    }

    void mockUseArtifactoryCredentials(Script script) {
        script.metaClass.useArtifactoryCredentials = { Closure x ->
            x.API_TOKEN = 'API_TOKEN'
            return x.call()
        }
    }

    /**
     * setUp is called before each test, it ensures that all needed jenkins methods are mocked and output variables are set to empty
     */
    @BeforeEach
    void setUp() {
        super.setUp()
        initOutputVars()
        addAllowedMethods()
    }

    /**
     * Tests that method `uploadToArtifactory` generates proper request
     */
    @Test
    @DisplayName('Test uploading to artifactory')
    @Tag('uploadToArtifactory')
    void testUploadToArtifactory() {
        String expected = "curl --fail -H 'X-JFrog-Art-Api:API_TOKEN' -X PUT \"${testExistingFolderName}\" -T ${testExistingFileName}"
        Script script = loadScript(scriptPath)
        mockUseArtifactoryCredentials(script)
        script.uploadToArtifactory(testExistingFolderName, testExistingFileName)
        assertEquals(expected, shOutput)
    }

    /**
     * Tests that method `downloadFromArtifactory` generates proper request
     */
    @Test
    @DisplayName('Test downloading from artifactory')
    @Tag('downloadFromArtifactory')
    void testDownloadFromArtifactory() {
        String expected = "curl --fail -H 'X-JFrog-Art-Api:API_TOKEN' -O  \"${testExistingFolderName}\"${testExistingFileName}"
        Script script = loadScript(scriptPath)
        mockUseArtifactoryCredentials(script)
        script.downloadFromArtifactory(testExistingFolderName, testExistingFileName)
        assertEquals(expected, shOutput)
    }

    /**
     * Tests that method `moveArtifactoryFile` generates proper request
     */
    @Test
    @DisplayName('Test moving artifactory file')
    @Tag('moveArtifactoryFile')
    void testMoveArtifactoryFile() {
        String expected = "curl -H 'X-JFrog-Art-Api:API_TOKEN' --fail -X POST " +
                "\"${artifactory}/api/move${testOldFolderName}/${testOldFileName}?to=${testNewFolderName}/${testNewFileName}\""
        Script script = loadScript(scriptPath)
        mockUseArtifactoryCredentials(script)
        script.moveArtifactoryFile(artifactory, testOldFolderName, testOldFileName, testNewFolderName, testNewFileName)
        assertEquals(expected, shOutput)
    }

    /**
     * Tests that method `copyArtifactoryFile` generates proper request
     */
    @Test
    @DisplayName('Test copying artifactory file')
    @Tag('copyArtifactoryFile')
    void testCopyArtifactoryFile() {
        /* groovylint-disable-next-line */
        String expected = "curl -H 'X-JFrog-Art-Api:API_TOKEN' --fail -X POST " +
                "\"${artifactory}/api/copy${testOldFolderName}/${testOldFileName}?to=${testNewFolderName}/${testNewFileName}\""
        Script script = loadScript(scriptPath)
        mockUseArtifactoryCredentials(script)
        script.copyArtifactoryFile(artifactory, testOldFolderName, testOldFileName, testNewFolderName, testNewFileName)
        assertEquals(expected, shOutput)
    }

    /**
     * Tests that method `existsInArtifactory` generates proper request
     */
    @Test
    @DisplayName('Test checking if artifact exists in artifactory')
    @Tag('existsInArtifactory')
    void testExistsInArtifactory() {
        String artifact = 'test-artifact'
        String expected = "curl -H 'X-JFrog-Art-Api:API_TOKEN' --fail --head -X GET \"${artifact}\""
        Script script = loadScript(scriptPath)
        mockUseArtifactoryCredentials(script)
        script.existsInArtifactory(artifact)
        assertEquals(expected, shOutput)
    }

    /**
     * Tests method `getArtifactsList`, if it successfully retrieved response from artifactory, check if it handles the request properly,
     * and returns list with desired links
     */
    @Test
    @DisplayName('Test retrieving artifacts list')
    @Tag('getArtifactsList')
    void testGetArtifactsList() {
        helper.registerAllowedMethod(shell, [Map]) { x ->
            return '''{"children": [{"uri": "url1"}, {"uri": "url2"}]}'''
        }
        Script script = loadScript(scriptPath)
        mockUseArtifactoryCredentials(script)
        List<String> result = script.getArtifactsList(artifactory, testExistingFolderName)
        List<String> expectedLinks = ['url1', 'url2']
        assertEquals(null, errorMessage)
        assertEquals(expectedLinks.class, result.class)
        [expectedLinks, result].transpose().each { x ->
            assertEquals(x[0], x[1])
        }
    }

    /**
     * Test that method `getArtifactsList`, if response from artifactory did not contain `children` field, fails with error
     */
    @Test
    @DisplayName('Test error handling when retrieving artifacts list')
    @Tag('getArtifactsList')
    void testGetArtifactsListError() {
        helper.registerAllowedMethod(shell, [Map]) { x ->
            return '{}'
        }
        Script script = loadScript(scriptPath)
        mockUseArtifactoryCredentials(script)
        script.getArtifactsList(artifactory, testExistingFolderName)
        String expectedErrorMessage = "Unable to find any artifact at path: ${testExistingFolderName}"
        assertEquals(expectedErrorMessage, errorMessage)
    }

}
