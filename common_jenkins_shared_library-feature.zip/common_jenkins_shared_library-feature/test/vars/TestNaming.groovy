package vars

import com.lesfurets.jenkins.unit.BasePipelineTest
import groovy.transform.CompileDynamic
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.DisplayName
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test

import static org.junit.jupiter.api.Assertions.assertEquals

/**
 * TestNaming contains unit tests of methods defined in jenkins shared library (library/vars/namingHelper.groovy')
 */
@Tag('naming')
@CompileDynamic
class TestNaming extends BasePipelineTest {

    static String scriptPath = 'library/vars/namingHelper.groovy'
    static String gitCrredentials = 'lms_git_access'

   @BeforeEach
    void setUp() {
        println("Setting up...")
        try {
            super.setUp()
            // Create a mock gitHelper object
            def gitHelper = [getLastGitTag: { String paramForGetLastGitTag, String credentials ->
                switch (paramForGetLastGitTag) {
                    case 'development':
                        return ['2.5.99', 'abc123']
                    case 'Task/MPC-1_perfect-name_of_A_BrAnCh':
                        return ['', 'def456']
                    case 'ghi7890sha0without0tag321':
                        return ['', 'ghi789']
                    case 'asd7650sha0with0tag321':
                        return ['7.8.9', 'asd765']
                    case 'Task/MPC-1_perfect-name_of_A_BrAnCh_repeat_repeat_repeat_repeat_repeat_repeat-MPC-1_perfect-name_of_A_BrAnCh_repeat_repeat_repeat_repeat_repeat_repeat':
                        return ['', 'def456']
                    default:
                        return ['ERROR-SHA', 'ERROR-TAG']
                }
            }]
            // Set the gitHelper object in the script
            getBinding().setVariable('gitHelper', gitHelper)
        } catch (Exception e) {
            println("Error in setUp: ${e}")
        }
        println("Setup complete.")
    }

    @Test
    @DisplayName('Generate Version for PR')
    @Tag('prNaming')
    void testPrName() {
        def script = loadScript(scriptPath)
        def expected = 'PR-12.b.5'

        def shOutput = script.getVersion('', '', '12', '5')
        assertEquals(expected, shOutput)
    }

    @Test
    @DisplayName('Generate Version for branch')
    @Tag('branchNaming')
    void testBranchName() {
        def script = loadScript(scriptPath)

        def shOutput = script.getVersion('development', '', '', '')
        assertEquals('2.5.99', shOutput)

        shOutput = script.getVersion('Task/MPC-1_perfect-name_of_A_BrAnCh', '', '', '')
        assertEquals('Task-MPC-1_perfect-name_of_A_BrAnCh-SHA-def456', shOutput)

        shOutput = script.getVersion('development', 'ghi7890sha0without0tag321', '', '')
        assertEquals('development-SHA-ghi789', shOutput)

        shOutput = script.getVersion('development', 'asd7650sha0with0tag321', '', '')
        assertEquals('7.8.9', shOutput)
    }

    @Test
    @DisplayName('Generate Artifact Name')
    @Tag('artifactNaming')
    void testArtifactName() {
        def script = loadScript(scriptPath)

        // Branch versions
        def shOutput = script.getArtifactName('development', '', '', '', 'Test', 'zip')
        assertEquals('Test.v.2.5.99.zip', shOutput)

        shOutput = script.getArtifactName('Task/MPC-1_perfect-name_of_A_BrAnCh', '', '', '', 'Test', 'zip')
        assertEquals('Test.v.Task-MPC-1_perfect-name_of_A_BrAnCh-SHA-def456.zip', shOutput)

        shOutput = script.getArtifactName('development', 'ghi7890sha0without0tag321', '', '', 'Test', 'zip')
        assertEquals('Test.v.development-SHA-ghi789.zip', shOutput)

        shOutput = script.getArtifactName('development', 'asd7650sha0with0tag321', '', '', 'Test', 'zip')
        assertEquals('Test.v.7.8.9.zip', shOutput)

        // PR versions
        shOutput = script.getArtifactName('', '', '12', '5', 'Test', 'zip')
        assertEquals('Test.v.PR-12.b.5.zip', shOutput)

    }

    @Test
    @DisplayName('Generate Image Name')
    @Tag('imageNaming')
    void testImageName() {
        def script = loadScript(scriptPath)

        // Branch versions
        def shOutput = script.getImageName('development', '', '', '', 'registry', 'Test')
        assertEquals('registry/Test:2.5.99', shOutput)

        shOutput = script.getImageName('Task/MPC-1_perfect-name_of_A_BrAnCh', '', '', '', 'registry', 'Test')
        assertEquals('registry/Test:Task-MPC-1_perfect-name_of_A_BrAnCh-SHA-def456', shOutput)

        shOutput = script.getImageName('development', 'ghi7890sha0without0tag321', '', '', 'registry', 'Test')
        assertEquals('registry/Test:development-SHA-ghi789', shOutput)

        shOutput = script.getImageName('development', 'asd7650sha0with0tag321', '', '', 'registry', 'Test')
        assertEquals('registry/Test:7.8.9', shOutput)

        shOutput = script.getImageName('Task/MPC-1_perfect-name_of_A_BrAnCh_repeat_repeat_repeat_repeat_repeat_repeat-MPC-1_perfect-name_of_A_BrAnCh_repeat_repeat_repeat_repeat_repeat_repeat','', '', '', 'registry', 'Test')
        assertEquals('registry/Test:t_repeat_repeat_repeat_repeat_repeat-MPC-1_perfect-name_of_A_BrAnCh_repeat_repeat_repeat_repeat_repeat_repeat-SHA-def456', shOutput)

        // PR versions
        shOutput = script.getImageName('', '', '12', '5', 'registry', 'Test')
        assertEquals('registry/Test:PR-12.b.5', shOutput)

        shOutput = script.getImageName('Task/MPC-1_perfect-name_of_A_BrAnCh_repeat_repeat_repeat_repeat_repeat_repeat-MPC-1_perfect-name_of_A_BrAnCh_repeat_repeat_repeat_repeat_repeat_repeat','', '', '', 'registry', 'Test')
        assertEquals('registry/Test:t_repeat_repeat_repeat_repeat_repeat-MPC-1_perfect-name_of_A_BrAnCh_repeat_repeat_repeat_repeat_repeat_repeat-SHA-def456', shOutput)
    }
}
