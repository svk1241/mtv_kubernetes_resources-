package vars

import static org.junit.jupiter.api.Assertions.assertEquals
import static org.junit.jupiter.api.Assertions.assertTrue

import com.lesfurets.jenkins.unit.BasePipelineTest
import groovy.transform.CompileDynamic
import org.junit.jupiter.api.DisplayName
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.BeforeEach

/**
 * Class TestAzureApi contains unit tests for jenkins shared library (library/vars/azureApi.groovy)
 */
@Tag('azure')
@CompileDynamic
class TestAzureApi extends BasePipelineTest {

    static String scriptPath = 'library/vars/azureApi.groovy'

    /**
     * Test variables used as parameters to some library methods
     */
    String testFolder = 'testFolder'
    String testRegistry = 'testRegistry'
    String testImage = 'testImage'
    String testTag = 'testTag'
    String testSourceRegistry = 'sourceRegistry'
    String testSourceImage = 'sourceImage'
    String testTargetRegistry = 'targetRegistry'
    String testTargetImage = 'targetImage'
    Boolean testForce = true
    Map testArgs = [arg1: 'value1', arg2: 'value2']

    /**
     * Stores output of `sh` jenkins method
     */
    String shOutput

    /**
     * Jenkins methods names
     */
    String shell = 'sh'

    /**
     * Mock jenkins methods for testing
     */
    void addAllowedMethods() {
        helper.registerAllowedMethod(shell, [String]) { x ->
            shOutput = x as String
            return { -> x }
        }
        helper.registerAllowedMethod(shell, [Map]) { m ->
            shOutput = m.script as String
            return m.script
        }
    }

    /**
     * Helper method, used to mock credentials binding to emulate jenkins behaviour
     * @param script Script object to mock method on
     */
    void mockWithAzureCli(Script script) {
        script.metaClass.withAzureCli = { Closure x ->
            x.call()
        }
    }

    /**
     * Set all output variables to initial state, call before each test
     */
    void initOutputVars() {
        shOutput = null
    }

    /**
     * setUp is called before each test, it ensures that all needed jenkins methods are mocked and output variables are set to empty
     */
    @BeforeEach
    void setUp() {
        super.setUp()
        initOutputVars()
        addAllowedMethods()
    }

    /**
     * Tests method `buildImage`
     */
    @Test
    @DisplayName('Test buildImage')
    @Tag('buildImage')
    void testBuildImage() {
        String expectedCommand = "az acr build --registry ${testRegistry} --image ${testImage}:${testTag} --build-arg arg1=value1 --build-arg arg2=value2 ."

        helper.registerAllowedMethod('sh', [String], { script ->
            assertTrue(script.contains(expectedCommand))
        })

        helper.registerAllowedMethod('dir', [String, Closure], { folder, body ->
            assertEquals(testFolder, folder)
            body.call()
        })

        Script script = loadScript(scriptPath)
        mockWithAzureCli(script)

        script.buildImage(testFolder, testRegistry, testImage, testTag, testArgs)
    }

    /**
     * Tests method `withAzureCli`
     */
    @Test
    @DisplayName('Test withAzureCli')
    @Tag('withAzureCli')
    void testWithAzureCli() {

        String secretFile = 'ARM_CLIENT_ID=client_id\nARM_CLIENT_SECRET=client_secret\nARM_TENANT_ID=tenant_id'
        helper.registerAllowedMethod('withCredentials', [List, Closure], { creds, body ->
            print "creds=${creds}"
            assertEquals(secretFile, creds[0])
            body.call()
        })

        helper.registerAllowedMethod('withEnv', [List, Closure], { envVars, body ->
            binding.setVariable('ARM_CLIENT_ID', 'client_id')
            binding.setVariable('ARM_CLIENT_SECRET', 'client_secret')
            binding.setVariable('ARM_TENANT_ID', 'tenant_id')
            body.call()
        })

        helper.registerAllowedMethod('sh', [String], { script ->
            assertTrue(script.contains('az login --service-principal'))
        })
        helper.registerAllowedMethod('file', [Map], { m ->
            echo  "credentialsId=${m.credentialsId}, variable=${m.variable}"
            binding.setVariable('AZURE_SERVICE_PRINCIPAL', secretFile)
            return secretFile
        })
        Script script = loadScript(scriptPath)

        script.withAzureCli {
            // Test body execution
            assertTrue(true)
        }
    }

    /**
     * Tests method `importImage` with source registry and source image
     */
    @Test
    @DisplayName('Test importImage with source registry and source image')
    @Tag('importImage')
    void testImportImageWithSourceRegistry() {
        String expectedCommand = "az acr import --force --name ${testTargetRegistry} --source ${testSourceRegistry}/${testSourceImage} --image ${testTargetImage}"

        helper.registerAllowedMethod('sh', [String], { script ->
            assertTrue(script.contains(expectedCommand))
        })

        Script script = loadScript(scriptPath)
        mockWithAzureCli(script)

        script.importImage(testSourceRegistry, testSourceImage, testTargetRegistry, testTargetImage, testForce)
    }

    /**
     * Tests method `importImage` with full source image URL
     */
    @Test
    @DisplayName('Test importImage with full source image URL')
    @Tag('importImage')
    void testImportImageWithFullSourceImage() {
        String testSourceImageUrl = "https://${testSourceRegistry}/${testSourceImage}"
        String expectedCommand = "az acr import --force --name ${testTargetRegistry} --source ${testSourceRegistry}/${testSourceImage} --image ${testTargetImage}"

        helper.registerAllowedMethod('sh', [String], { script ->
            assertTrue(script.contains(expectedCommand))
        })

        Script script = loadScript(scriptPath)
        mockWithAzureCli(script)

        script.importImage(testSourceImageUrl, testTargetRegistry, testTargetImage, testForce)
    }

}
