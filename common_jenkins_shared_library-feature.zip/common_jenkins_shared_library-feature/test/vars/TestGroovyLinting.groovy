package vars

import static org.junit.jupiter.api.Assertions.assertThrows

import com.lesfurets.jenkins.unit.BasePipelineTest
import groovy.transform.CompileDynamic
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.DisplayName
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test

@Tag('GroovyLinting')
@CompileDynamic
class TestGroovyLinting extends BasePipelineTest {

    @BeforeEach
    void setUp() {
        super.setUp()
        // Mock necessary methods and objects
        helper.registerAllowedMethod('sh', [String], { String script ->
            if (script.contains('rm -rf')) {
                return
            }
            if (script.contains('npm-groovy-lint')) {
                return 0 // Simulate successful linting
            }
        })
        helper.registerAllowedMethod('unstable', [Map], { Map args ->
            println "Unstable: ${args.message}"
        })
        helper.registerAllowedMethod('error', [String], { String message ->
            throw new Exception(message)
        })
        helper.registerAllowedMethod('dir', [String, Closure], { String dir, Closure closure ->
            closure.call()
        })
        helper.registerAllowedMethod('echo', [String], { String message ->
            println message
        })

        // Mock gitHelper and bitbucket objects
        binding.setVariable('gitHelper', [
            checkoutWithGit: { String repoUrl, String branchName, String repoName, String credentials ->
                println "Checked out ${repoUrl} on branch ${branchName}"
            },
            configureGitLocalCreds: { String credentialsId ->
                println "Configured Git local credentials with ID: ${credentialsId}"
            },
            commitToGit: { String workDirectory, String commitMessage ->
                println "Committed to Git with message: ${commitMessage}"
            },
            jenkinsCredentialsName: 'jenkins-credentials'
        ])
        binding.setVariable('bitbucket', [
            bitbucketUrl: 'https://bitbucket.example.com',
            sendBitBucketPRComment: { String commentText, String prUrl ->
                println "Sent BitBucket PR comment: ${commentText} to ${prUrl}"
            },
            bitBucketCredentialsId: 'bitbucket-credentials'
        ])
    }

    @Test
    @DisplayName('Test Happy path')
    @Tag('lintAndFixGroovyCode')
    void testLintAndFixGroovyCode() {
        // Arrange
        Script script = loadScript('vars/groovyLinting.groovy')
        String projectName = 'TestProject'
        String repoName = 'TestRepo'
        String prName = '1'
        String branchName = 'development'
        String credentialsId = 'jenkins_creds'

        // Act
        script.lintAndFixGroovyCode(projectName, repoName, prName, branchName, credentialsId)

        // Assert
        // Assertions are done within the mock methods
    }

    @Test
    @DisplayName('Test handle gg errors situation')
    @Tag('lintAndFixGroovyCode')
    void testLintAndFixGroovyCodeException() {
        // Arrange
        Script script = loadScript('vars/groovyLinting.groovy')
        String projectName = 'TestProject'
        String repoName = 'TestRepo'
        String prName = '1'
        String branchName = 'development'
        String credentialsId = 'jenkins_creds'

        script.metaClass.hasGroovyLintErrors = { String r, String l  ->
            println "Mocked hasGroovyLintErrors called with repoName=${r}, lintCommand=${l})"
            return true // Simulate linting errors found
        }
        script.metaClass.runGrooveGuard = { String workDirectory, String lintCommand, String filesToLint ->
            println "Run GrooveGuard with command: ${lintCommand} on files: ${filesToLint}"
            throw new Exception("Test exception")
        }
        // Act and Assert
        // Assertions are done within the mock methods
        Exception exception = assertThrows(Exception.class, () -> {
            script.lintAndFixGroovyCode(projectName, repoName, prName, branchName, credentialsId)
        })
    }

}
