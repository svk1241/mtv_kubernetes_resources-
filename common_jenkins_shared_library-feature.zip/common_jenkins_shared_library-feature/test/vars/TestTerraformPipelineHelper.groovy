package variables

import static com.lesfurets.jenkins.unit.global.lib.LibraryConfiguration.library
import static com.lesfurets.jenkins.unit.global.lib.ProjectSource.projectSource
import static org.junit.jupiter.api.Assertions.assertEquals

import groovy.json.JsonSlurper
import com.lesfurets.jenkins.unit.BasePipelineTest
import groovy.transform.CompileDynamic
import org.junit.jupiter.api.DisplayName
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.BeforeEach

/**
 * Class TestJira contains unit tests for jenkins shared library (library/vars/jira.groovy)
 */
@Tag('terraformPipelineHelper')
@CompileDynamic
class TestTerraformPipelineHelper extends BasePipelineTest {

    static String scriptPath = 'library/vars/terraformPipelineHelper.groovy'

    /**
     * Stores output of `sh` jenkins method
     */
    String shOutput

    /**
     * Jenkins methods names
     */
    String shell = 'sh'

    /**
     * Mock jenkins methods for testing
     */
    void addAllowedMethods() {
        helper.registerAllowedMethod('error', [String]) { s ->
            throw new Exception(s)
        }
        helper.registerAllowedMethod('writeJSON', [Map]) { m ->
            return
        }
        helper.registerAllowedMethod(shell, [String]) { script ->
            println ("${script}")
        }
        helper.registerAllowedMethod(shell, [Map]) { m ->
            switch ( m.script) {
                case 'git diff --name-only origin/terraform_test1':
                    return ['terraform/main.tf','terraform/main.tfvars'].join('\n')
                case 'git diff --name-only origin/terraform_test2':
                    return ['terraform-init/main.tf','terraform/main.tfvars'].join('\n')
                case 'git diff --name-only origin/terraform_test3':
                    return ['jenkinsfiles/pr.jenkinsfile','terraform/main.tfvars'].join('\n')
                case 'git diff --name-only origin/terraform_test4':
                    return ['jenkinsfiles/pr.jenkinsfile'].join('\n')
                case 'git diff --name-only origin/terraform_test5':
                    return ['modules/main.tf','terraform/main.tfvars'].join('\n')
                case 'git diff --name-only origin/terraform_test6':
                    return ['jenkinsfiles/main.tf','terraform-init/main.tfvars'].join('\n')
                case 'git diff --name-only origin/terraform_test7':
                    return ['modules/main.tf','terraform-init/main.tfvars'].join('\n')
                default:
                    println ("${m.script}")
            }
        }

    }

    /**
     * Helper method, used to mock credentials binding to emulate jenkins behaviour
     * @param script Script object to mock method on
     */
    void mockUseJiraCredentials(Script script) {
        script.metaClass.useJiraCredentials = { Closure x ->
            x.ACCESS_TOKEN_USERNAME = testUsername
            x.ACCESS_TOKEN_PASSWORD = testPassword
            return x.call()
        }
    }

    /**
     * Set all output variables to initial state, call before each test
     */
    void init() {
        binding.getVariable('env').CHANGE_TARGET = "development"
    }

    /**
     * setUp is called before each test, it ensures that all needed jenkins methods are mocked and output variables are set to empty
     */
    @BeforeEach
    void setUp() {
        super.setUp()
        Object library = library()
            .name('commons')
            .defaultVersion('<notNeeded>')
            .allowOverride(true)
            .implicit(true)
            .targetPath('<notNeeded>')
            .retriever(projectSource())
            .build()
        helper.registerSharedLibrary(library)
        init()
        addAllowedMethods()
    }

    /**
     * Tests method `getChangedTerraformFolders`
     */
    @Test
    @DisplayName('Test getChangedFolders')
    @Tag('getChangedFolders')
    void testGetChangedFolders() {
        Script script = loadScript(scriptPath)
        List<String> folders = ['terraform-init', 'terraform']
        String expected1 = ['terraform']
        String expected2 = ['terraform-init', 'terraform']
        String expected3 = ['terraform']
        String expected4 = []
        String expected6 = ['terraform-init']
        binding.getVariable('env').CHANGE_TARGET = "terraform_test1"

        String result = script.getChangedFolders(folders)
        assertEquals(expected1, result)
        binding.getVariable('env').CHANGE_TARGET = "terraform_test2"
        result = script.getChangedFolders(folders)
        assertEquals(expected2, result)
        binding.getVariable('env').CHANGE_TARGET = "terraform_test3"
        result = script.getChangedFolders(folders)
        assertEquals(expected3, result)
        binding.getVariable('env').CHANGE_TARGET = "terraform_test4"
        result = script.getChangedFolders(folders)
        assertEquals(expected4, result)
        binding.getVariable('env').CHANGE_TARGET = "terraform_test6"
        result = script.getChangedFolders(folders)
        assertEquals(expected6, result)
    }

    /**
     * Tests method `getWorkingFolder`
     */
    @Test
    @DisplayName('Test getWorkingFolder')
    @Tag('getWorkingFolder')
    void testGetWorkingFolder() {
        Map folders = [
            'terraform': ['terraform', 'terraform-init'],
            'ci': ['jenkinsfiles'],
            'ciTest': 'terraform-init',
            'tfModules': ['modules'],
            'tfModulesTest': 'terraform'
        ]
        Script script = loadScript(scriptPath)
        String expected1 = 'terraform'
        String expected3 = 'terraform'
        String expected4 = 'terraform-init'
        String expected5 = 'terraform'
        String expected6 = 'terraform-init'
        String expected7 = 'terraform-init'
        binding.getVariable('env').CHANGE_TARGET = "terraform_test1"
        String result = script.getWorkingFolder(folders)
        assertEquals(expected1, result)
        binding.getVariable('env').CHANGE_TARGET = "terraform_test2"
        try {
            script.getWorkingFolder(folders)
            fail( "Should throw error" );
        } catch (ex) {
        }
        binding.getVariable('env').CHANGE_TARGET = "terraform_test3"
        try {
            script.getWorkingFolder(folders)
            fail( "Should throw error" );
        } catch (ex) {
        }
        binding.getVariable('env').CHANGE_TARGET = "terraform_test4"
        result = script.getWorkingFolder(folders)
        assertEquals(expected4, result)
        binding.getVariable('env').CHANGE_TARGET = "terraform_test5"
        result = script.getWorkingFolder(folders)
        assertEquals(expected5, result)
        binding.getVariable('env').CHANGE_TARGET = "terraform_test6"
        result = script.getWorkingFolder(folders)
        assertEquals(expected6, result)
        binding.getVariable('env').CHANGE_TARGET = "terraform_test7"
        try {
            script.getWorkingFolder(folders)
            fail( "Should throw error" );
        } catch (ex) {
        }
        folders = [
            'terraform': ['terraform', 'terraform-init'],
            'ci': ['jenkinsfiles'],
            'ciTest': '',
            'tfModules': ['modules'],
            'tfModulesTest': ''
        ]
        binding.getVariable('env').CHANGE_TARGET = "terraform_test3"
        result = script.getWorkingFolder(folders)
        assertEquals(expected3, result)
        binding.getVariable('env').CHANGE_TARGET = "terraform_test7"
        result = script.getWorkingFolder(folders)
        assertEquals(expected7, result)
    }

}
