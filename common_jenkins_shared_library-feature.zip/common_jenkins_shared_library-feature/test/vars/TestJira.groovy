package vars

import static org.junit.jupiter.api.Assertions.assertEquals

import groovy.json.JsonSlurper
import com.lesfurets.jenkins.unit.BasePipelineTest
import groovy.transform.CompileDynamic
import org.junit.jupiter.api.DisplayName
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.BeforeEach

/**
 * Class TestJira contains unit tests for jenkins shared library (library/vars/jira.groovy)
 */
@Tag('jira')
@CompileDynamic
class TestJira extends BasePipelineTest {

    static String scriptPath = 'library/vars/jira.groovy'

    /**
     * Test username and password to bind credentials
     */
    String testUsername = 'ACCESS_TOKEN_USERNAME'
    String testPassword = 'ACCESS_TOKEN_PASSWORD'

    /**
     * Test variables used as parameters to some library methods
     */
    String testProject = 'MPC'
    String testJiraUrl = 'luxproject.luxoft.com/jira'
    String testApiVersion = 'latest'
    String testIssueID = 'MPC-323'
    String testVersionValue = 'test_release'

    /**
     * Stores output of `sh` jenkins method
     */
    String shOutput

    /**
     * Jenkins methods names
     */
    String shell = 'sh'

    /**
     * Mock jenkins methods for testing
     */
    void addAllowedMethods() {
        helper.registerAllowedMethod(shell, [String]) { x ->
            shOutput = x as String
            return { -> x }
        }
        helper.registerAllowedMethod(shell, [Map]) { m ->
            shOutput = m.script as String
            return m.script
        }
        helper.registerAllowedMethod('readJSON', [Map]) { args ->
            /* groovylint-disable-next-line JavaIoPackageAccess */
            return new JsonSlurper().parse(new File(args['file']))
        }
    }

    /**
     * Helper method, used to mock credentials binding to emulate jenkins behaviour
     * @param script Script object to mock method on
     */
    void mockUseJiraCredentials(Script script) {
        script.metaClass.useJiraCredentials = { Closure x ->
            x.ACCESS_TOKEN_USERNAME = testUsername
            x.ACCESS_TOKEN_PASSWORD = testPassword
            return x.call()
        }
    }

    /**
     * Set all output variables to initial state, call before each test
     */
    void initOutputVars() {
        shOutput = null
    }

    /**
     * setUp is called before each test, it ensures that all needed jenkins methods are mocked and output variables are set to empty
     */
    @BeforeEach
    void setUp() {
        super.setUp()
        initOutputVars()
        addAllowedMethods()
    }

    /**
     * Tests global variables
     */
    @Test
    @DisplayName('Test global variables values')
    @Tag('globals')
    void testGlobals() {
        assertEquals(testJiraUrl, loadScript(scriptPath).jiraUrl)
        assertEquals(testApiVersion, loadScript(scriptPath).apiVersion)
    }

    /**
     * Tests method `getJiraIssueDetails`
     */
    @Test
    @DisplayName('Test getJiraIssueDetails')
    @Tag('getJiraIssueDetails')
    void testgetJiraIssueDetails() {
        String resultFile = 'jira_issue_details.json'
        Script script = loadScript(scriptPath)
        mockUseJiraCredentials(script)
        String expected = """curl --fail -u ACCESS_TOKEN_USERNAME:ACCESS_TOKEN_PASSWORD -H \"Content-Type: application/json\" \
            https://${testJiraUrl}/rest/api/${testApiVersion}/issue/${testIssueID} > ${resultFile}"""
        script.getJiraIssueDetails(testIssueID, resultFile)
        assertEquals(shOutput, expected)
    }

    /**
     * Tests method `getJiraIssueSummary`
     */
    @Test
    @DisplayName('Test getJiraIssueSummary')
    @Tag('getJiraIssueSummary')
    void testGetJiraIssueSummary() {
        Script script = loadScript(scriptPath)
        mockUseJiraCredentials(script)
        String expected = 'Changelog post-processing'
        String result = script.getJiraIssueSummary(testIssueID, 'test/resources/jira_issue_details.json')
        assertEquals(expected, result)
    }

    /**
     * Tests method `createJiraRelease`
     */
    @Test
    @DisplayName('Test createJiraRelease')
    @Tag('createJiraRelease')
    void testCreateJiraRelease() {
        Script script = loadScript(scriptPath)
        mockUseJiraCredentials(script)
        String expected = """curl -D- -u ACCESS_TOKEN_USERNAME:ACCESS_TOKEN_PASSWORD -X POST -H \"Content-Type: application/json\" \
            --data '{
            \"archived\": false,
            \"description\": \"Automatically created release\",
            \"name\": \"${testVersionValue}\",
            \"project\": \"${testProject}\",
            \"released\": false
            }' https://${testJiraUrl}/rest/api/${testApiVersion}/version"""
        script.createJiraRelease(testProject, testVersionValue)
        assertEquals(expected, shOutput)
    }

    /**
     * Tests method `addVersionToIssue`
     */
    @Test
    @DisplayName('Test addVersionToIssue')
    @Tag('addVersionToIssue')
    void testAddVersionToIssue() {
        Script script = loadScript(scriptPath)
        mockUseJiraCredentials(script)
        String expected = """curl -D- -u ACCESS_TOKEN_USERNAME:ACCESS_TOKEN_PASSWORD -X PUT \
            --data '{\"update\": {\"fixVersions\": [{\"add\": {\"name\": \"${testVersionValue}\"}}]}}' \
            -H 'Content-Type: application/json' \
            https://${testJiraUrl}/rest/api/${testApiVersion}/issue/${testIssueID}"""
        script.addVersionToIssue(testIssueID, testVersionValue)
        assertEquals(expected, shOutput)
    }

}

class TestJiraException extends Exception {

    TestJiraException(String message) {
        super(message)
    }

}
