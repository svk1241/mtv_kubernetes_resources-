package vars

import static org.junit.jupiter.api.Assertions.assertEquals
import static org.junit.jupiter.api.Assertions.assertFalse
import static org.junit.jupiter.api.Assertions.assertTrue

import groovy.json.JsonSlurper
import groovy.json.JsonBuilder
import com.lesfurets.jenkins.unit.BasePipelineTest
import groovy.transform.CompileDynamic
import org.junit.jupiter.api.DisplayName
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.BeforeEach

/**
 * Class TestBitBucket contains unit tests for jenkins shared library (library/vars/bitbucket.groovy)
 */
@Tag('bitbucket')
@CompileDynamic
class TestBitBucket extends BasePipelineTest {

    static String scriptPath = 'library/vars/bitbucket.groovy'

    /**
     * Test username and password to bind credentials
     */
    String testUsername = 'ACCESS_TOKEN_USERNAME'
    String testPassword = 'ACCESS_TOKEN_PASSWORD'

    /**
     * Test variables used as parameters to some library methods
     */
    String testUrl = 'fake.url'
    String testContent = 'Content'
    String testProject = 'MPC'
    String testRepository = 'common'
    String testPRTitle = 'test pull request'
    String testPRDescription = 'test description'
    String testSourceBranch = 'source'
    String testTargetBranch = 'target'
    String testBitBucketUrl = 'https://luxproject.luxoft.com/stash'
    String testPRLink = 'https://pr.link'

    /**
     * Stores output of `sh` jenkins method
     */
    String shOutput

    /**
     * Stores output of `writeJSON` jenkins method
     */
    String fileContent

    /**
     * Jenkins methods names
     */
    String shell = 'sh'
    String readJson = 'readJSON'
    String writeJSON = 'writeJSON'

    /**
     * Mock jenkins methods for testing
     */
    void addAllowedMethods() {
        helper.registerAllowedMethod('libraryResource', [String]) {
            /* groovylint-disable-next-line GStringExpressionWithinString */
            return '''{
              "title": "${name}",
              "description": "${description}",
              "state": "OPEN",
              "open": true,
              "closed": false,
              "fromRef": {
                "id": "refs/heads/${sourceBranch}"
              },
              "toRef": {
                "id": "refs/heads/${targetBranch}"
              },
              "locked": false
            }'''
        }
        helper.registerAllowedMethod(shell, [String]) { x ->
            shOutput = x as String
            return { -> x }
        }
        helper.registerAllowedMethod(shell, [Map]) { m ->
            shOutput = m.script as String
            return m.script
        }
        helper.registerAllowedMethod('writeJSON', [Map]) { m ->
            return
        }
        helper.registerAllowedMethod(readJson, [Map]) { m ->
            return new JsonSlurper().parseText(m.text) as Object
        }
    }

    /**
     * Helper method, used to mock credentials binding to emulate jenkins behaviour
     * @param script Script object to mock method on
     */
    void mockUseBBCredentials(Script script) {
        script.metaClass.useBBCredentials = { Closure x ->
            x.ACCESS_TOKEN_USERNAME = testUsername
            x.ACCESS_TOKEN_PASSWORD = testPassword
            return x.call()
        }
    }

    /**
     * Set all output variables to initial state, call before each test
     */
    void initOutputVars() {
        shOutput = null
    }

    /**
     * setUp is called before each test, it ensures that all needed jenkins methods are mocked and output variables are set to empty
     */
    @BeforeEach
    void setUp() {
        super.setUp()
        initOutputVars()
        addAllowedMethods()
    }

    /**
     * Tests global variable `bitbucketUrl` to be equal to actual relevant url
     */
    @Test
    @DisplayName('Test global variables values')
    @Tag('globals')
    void testGlobals() {
        assertEquals(testBitBucketUrl, loadScript(scriptPath).bitbucketUrl)
    }

    /**
     * Tests that method `sendBitBucketPRComment` generates proper request
     */
    @Test
    @DisplayName('Test sending comment to Pull Request')
    @Tag('sendComment')
    void testSendComment() {
        String url = "${testUrl}/comments"
        String expected = """curl --fail -v -HContent-Type:application/json -HAccept:application/json \
            --user 'ACCESS_TOKEN_USERNAME:ACCESS_TOKEN_PASSWORD' \
            --data '@./comment.json' -X POST ${url} && \
            rm ./comment.json""" as String
        Script script = loadScript(scriptPath)
        mockUseBBCredentials(script)
        script.sendBitBucketPRComment(testContent, testUrl)
        assertEquals(shOutput, expected)
    }

    /**
     * Tests that method `pullRequestVersion` generates proper request
     */
    @Test
    @DisplayName('Test retrieving Pull Request version')
    @Tag('pullRequestVersion')
    void testPullRequestVersion() {
        Script script = loadScript(scriptPath)
        mockUseBBCredentials(script)
        String expected = '''curl --fail -H "Content-Type:application/json" -H "Accept:application/json" \
                        --user ACCESS_TOKEN_USERNAME:ACCESS_TOKEN_PASSWORD \
                        -X GET fake.url | jq .version'''
        script.pullRequestVersion(testUrl)
        assertEquals(expected, shOutput)
    }

    /**
     * Tests that method `mergePullRequest` generates proper request
     */
    @Test
    @DisplayName('Test Pull Request merging')
    @Tag('mergePullRequest')
    void testMergePullRequest() {
        Script script = loadScript(scriptPath)
        mockUseBBCredentials(script)
        script.metaClass.pullRequestVersion = { String s -> return '10' }
        String expected = '''curl --fail -H "Content-Type:application/json" -H "Accept:application/json" \
                        --user ACCESS_TOKEN_USERNAME:ACCESS_TOKEN_PASSWORD \
                        -X POST fake.url/merge?version=10'''
        script.mergePullRequest(testUrl)
        assertEquals(expected, shOutput)
    }

    /**
     * Tests that method `deleteBranch` generates proper request
     */
    @Test
    @DisplayName('Test Branch Deletion')
    @Tag('deleteBranch')
    void testDeleteBranch() {
        Script script = loadScript(scriptPath)
        mockUseBBCredentials(script)
        String expected = """curl --fail -H \"Content-Type:application/json\" -H \"Accept:application/json\" \
                        --user ACCESS_TOKEN_USERNAME:ACCESS_TOKEN_PASSWORD \
                        --data '{\"name\": \"${testTargetBranch}\" ,\"dryRun\": false}' \
                        -X DELETE ${testBitBucketUrl}/rest/branch-utils/1.0/projects/${testProject}/repos/${testRepository}/branches"""
        script.deleteBranch(testProject, testRepository, testTargetBranch)
        assertEquals(expected, shOutput)
    }

    /**
     * Tests that method `createPr` returns expected `Map` if PR was created successfully
     */
    @Test
    @DisplayName('Test create Pull Request, success path')
    @Tag('createPr')
    void testCreatePrSuccess() {
        helper.registerAllowedMethod(shell, [Map]) {
            return '''{"links":{
                        "self": [
                                {"href": "https://pr.link"}
                            ]
                        }}'''
        }
        Script script = loadScript(scriptPath)
        mockUseBBCredentials(script)
        Map result = script.createPr(testProject, testRepository, testPRTitle, testPRDescription, testSourceBranch, testTargetBranch)
        assertEquals('Created', result.code)
        assertEquals(true, result.successful)
        assertEquals(testPRLink, result.url)
    }

    @Test
    @DisplayName('Test that createPr sends valid api request')
    @Tag('createPr')
    void testCreatePrRequestValidity() {
        Script script = loadScript(scriptPath)
        mockUseBBCredentials(script)
        helper.registerAllowedMethod(shell, [Map]) { Map m ->
            shOutput = m.script
            return '{"error": "com.atlassian.bitbucket.pull.EmptyPullRequestException"}'
        }
        /* groovylint-disable-next-line JavaIoPackageAccess */
        String expected = new File('test/resources/createPrExpectedOutput.txt').text
                /* groovylint-disable-next-line DuplicateStringLiteral */
                .replace('\r', '').split('\n').each { String s -> s.trim() }.join(' ')
        script.createPr(testProject, testRepository, testPRTitle, testPRDescription, testSourceBranch, testTargetBranch)
        /* groovylint-disable-next-line DuplicateStringLiteral */
        String result = shOutput.split('\n').each { String s -> s.trim() }.join(' ')
        assertEquals(expected, result)
    }

    /**
     * Test that method `createPr` returns proper Map with corresponding values when PR is not created successfully (it already exists)
     */
    @Test
    @DisplayName('Test create Pull Request, when it already exists')
    @Tag('createPr')
    void testCreatePrAlreadyExists() {
        helper.registerAllowedMethod(shell, [Map]) {
            return '''{"errors":[{
                            "error": "com.atlassian.bitbucket.pull.DuplicatePullRequestException",
                            "existingPullRequest": {
                                "links": {
                                    "self": [
                                        {"href": "https://pr.link"}
                                    ]
                                }
                            }
                            }]}'''
        }
        Script script = loadScript(scriptPath)
        mockUseBBCredentials(script)
        Map result = script.createPr(testProject, testRepository, testPRTitle, testPRDescription, testSourceBranch, testTargetBranch)
        assertEquals(false, result.successful)
        assertEquals('Exist', result.code)
        assertEquals(testPRLink, result.url)
    }

    /**
     * Test that method `createPr` returns proper Map with corresponding values when PR is not created successfully (invalid branch names)
     */
    @Test
    @DisplayName('Test create Pull Request without either of source/target branches')
    @Tag('createPr')
    void testCreatePrNoSuchCommit() {
        helper.registerAllowedMethod(shell, [Map]) {
            return '''{"errors":[{
                        "error": "com.atlassian.bitbucket.commit.NoSuchCommitException",
                        "existingPullRequest": {
                            "links": {
                                "self": [
                                    {"href": "https://pr.link"}
                                ]
                            }
                        }
                        }]}'''
        }
        Script script = loadScript(scriptPath)
        mockUseBBCredentials(script)
        Map result = script.createPr(testProject, testRepository, testPRTitle, testPRDescription, testSourceBranch, testTargetBranch)
        assertEquals(false, result.successful)
        assertEquals('NoSuchBranch', result.code)
        assertEquals('', result.url)
    }

    /**
     * Test that method `createPr` returns proper Map with corresponding values when PR is not created successfully (empty pull request)
     */
    @Test
    @DisplayName('Test create Pull Request with empty diff')
    @Tag('createPr')
    void testCreatePrEmptyDiff() {
        helper.registerAllowedMethod(shell, [Map]) {
            return '''{"errors":[{
                        "error": "com.atlassian.bitbucket.pull.EmptyPullRequestException",
                        "existingPullRequest": {
                            "links": {
                                "self": [
                                    {"href": "https://pr.link"}
                                ]
                            }
                        }
                        }]}'''
        }
        Script script = loadScript(scriptPath)
        mockUseBBCredentials(script)
        Map result = script.createPr(testProject, testRepository, testPRTitle, testPRDescription, testSourceBranch, testTargetBranch)
        assertEquals(false, result.successful)
        assertEquals('NoChanges', result.code)
        assertEquals('', result.url)
    }

    @Test
    @DisplayName('Test checking if branch exists, no such branch path')
    @Tag('isBranchExists')
    void testBranchExistsNoSuchBranch() {
        helper.registerAllowedMethod(shell, [String]) { s ->
            shOutput = s
        }
        helper.registerAllowedMethod(readJson, [Map]) { m ->
            return new JsonSlurper().parseText('''{"size":1,"limit":25,"isLastPage":true,
                        "values":[{"id":"refs/heads/develop","displayId":"develop","type":"BRANCH",
                        "latestCommit":"5b2829ca3bd98e1ea469a43a23092c2800cefd96","latestChangeset":
                        "5b2829ca3bd98e1ea469a43a23092c2800cefd96","isDefault":true}],"start":0}''') as Object
        }
        String expectedRequest = "curl --fail --user ACCESS_TOKEN_USERNAME:ACCESS_TOKEN_PASSWORD -H 'Accept: application/json' " +
                "-X GET https://luxproject.luxoft.com/stash/rest/api/1.0/projects/${testProject}/repos/${testRepository}" +
                "/branches?filterText=${testTargetBranch} --output branchesCurlOutput.json"
        Script script = loadScript(scriptPath)
        mockUseBBCredentials(script)
        Boolean result = script.isBranchExists(testProject, testRepository, testTargetBranch)
        assertEquals(false, result)
        assertEquals(shOutput, expectedRequest)
    }

    @Test
    @DisplayName('Test checking if branch exists, and it actually exists')
    @Tag('isBranchExists')
    void testBranchExistsSuccess() {
        helper.registerAllowedMethod(shell, [String]) { s ->
            shOutput = s
        }
        helper.registerAllowedMethod(readJson, [Map]) { m ->
            return new JsonSlurper().parseText("""{"size":1,"limit":25,"isLastPage":true,
                        "values":[{"id":"refs/heads/${testTargetBranch}","displayId":"develop","type":"BRANCH",
                        "latestCommit":"5b2829ca3bd98e1ea469a43a23092c2800cefd96","latestChangeset":
                        "5b2829ca3bd98e1ea469a43a23092c2800cefd96","isDefault":true}],"start":0}""") as Object
        }
        Script script = loadScript(scriptPath)
        mockUseBBCredentials(script)
        Boolean result = script.isBranchExists(testProject, testRepository, testTargetBranch)
        assertEquals(true, result)
    }

    @Test
    @DisplayName('Test checking retrieve tags request')
    @Tag('retrieveTags')
    void testRetrieveTags() {
        helper.registerAllowedMethod(shell, [String]) { s ->
            /* groovylint-disable-next-line DuplicateStringLiteral */
            shOutput = s.replaceAll('  ', '')
        }

        helper.registerAllowedMethod(readJson, [Map]) { m ->
            return new JsonSlurper().parseText('''{"size":3,"limit":25,"isLastPage":true,"values":
                        [{"id":"refs/tags/k8s-aks-1.28.0","displayId":"k8s-aks-1.28.0","type":"TAG",
                        "latestCommit":"2f37492b06896b7c6d14bf05bc493d4ab8ed7e37","latestChangeset":
                        "2f37492b06896b7c6d14bf05bc493d4ab8ed7e37","hash":"9b8a6bfc75aeb32e20ad5755f0fc57222a0bd07b"},
                        {"id":"refs/tags/istio-1.19.3","displayId":"istio-1.19.3","type":"TAG",
                        "latestCommit":"2f37492b06896b7c6d14bf05bc493d4ab8ed7e37","latestChangeset":
                        "2f37492b06896b7c6d14bf05bc493d4ab8ed7e37","hash":"030033441e2a544fe01d077995e74123f518371c"},
                        {"id":"refs/tags/knative-1.12.0","displayId":"knative-1.12.0","type":"TAG",
                        "latestCommit":"2f37492b06896b7c6d14bf05bc493d4ab8ed7e37","latestChangeset":"2f37492b06896b7c6d14bf05bc493d4ab8ed7e37",
                        "hash":"7cad5203b3d57a4539c15593a256cfc8297b5470"}],"start":0}''')
        }
        Script script = loadScript(scriptPath)
        mockUseBBCredentials(script)
        List<String> result = script.retrieveTags(testProject, testRepository, 'MODIFICATION')
        String expected = 'curl --fail --user ACCESS_TOKEN_USERNAME:ACCESS_TOKEN_PASSWORD -H \'Accept: application/json\' -X GET ' +
        "'${script.bitbucketUrl}/rest/api/1.0/projects/${testProject}/repos/${testRepository}/tags?orderBy=MODIFICATION' " +
                '-o tmp_tags.json'
        assertEquals(expected, shOutput)
        List<String> expectedResult = ['k8s-aks-1.28.0', 'istio-1.19.3', 'knative-1.12.0']
        assertEquals(expectedResult.size(), result.size())
        assertEquals("${expectedResult}", "${result}")
    }

    /**
     * Tests that method `getPullRequestOwner` retrieves the correct owner
     */
    @Test
    @DisplayName('Test retrieving Pull Request owner')
    @Tag('getPullRequestOwner')
    void testGetPullRequestOwner() {
        String mockResponse = '''
        {
            "author": {
                "user": {
                    "name": "test-owner"
                }
            }
        }
        '''
        helper.registerAllowedMethod(readJson, [Map]) { m ->
            return new JsonSlurper().parseText(mockResponse) as Object
        }
        helper.registerAllowedMethod(shell, [Map]) { m ->
            shOutput = m.script
            return mockResponse
        }
        Script script = loadScript(scriptPath)
        mockUseBBCredentials(script)
        String owner = script.getPullRequestOwner(testProject, testRepository, '123')
        assertEquals('test-owner', owner)
    }

    /**
     * Tests that method `getCommentsFromPR` retrieves comments from a specific pull request
     */
    @Test
    @DisplayName('Test retrieving comments from Pull Request')
    @Tag('getCommentsFromPR')
    void testGetCommentsFromPR() {
        String mockResponse = '''
        {
            "values": [
                {
                    "action": "COMMENTED",
                    "comment": {
                        "text": "First comment"
                    }
                },
                {
                    "action": "COMMENTED",
                    "comment": {
                        "text": "Second comment"
                    }
                },
                {
                    "action": "APPROVED"
                }
            ]
        }
        '''
        helper.registerAllowedMethod(shell, [Map]) { m ->
            shOutput = m.script
            return mockResponse
        }
        helper.registerAllowedMethod(readJson, [Map]) { m ->
            return new JsonSlurper().parseText(mockResponse) as Object
        }
        Script script = loadScript(scriptPath)
        mockUseBBCredentials(script)
        List<String> result = script.getCommentsFromPR(testProject, testRepository, '123')
        assertEquals(['First comment', 'Second comment'], result)
    }

    /**
     * Tests that method `getCommentsFromPR` handles no comments case
     */
    @Test
    @DisplayName('Test retrieving comments from Pull Request with no comments')
    @Tag('getCommentsFromPR')
    void testGetCommentsFromPRNoComments() {
        String mockResponse = '''
        {
            "values": []
        }
        '''
        helper.registerAllowedMethod(shell, [Map]) { m ->
            shOutput = m.script
            return mockResponse
        }
        helper.registerAllowedMethod(readJson, [Map]) { m ->
            return new JsonSlurper().parseText(mockResponse) as Object
        }
        Script script = loadScript(scriptPath)
        mockUseBBCredentials(script)
        List<String> result = script.getCommentsFromPR(testProject, testRepository, '123')
        assertTrue(result.isEmpty())
    }

    /**
     * Tests that method `checkCommentExists` checks for an existing comment in a pull request
     */
    @Test
    @DisplayName('Test checking for an existing comment in Pull Request')
    @Tag('checkCommentExists')
    void testCheckCommentExists() {
        String mockResponse = '''
        {
            "values": [
                {
                    "action": "COMMENTED",
                    "comment": {
                        "text": "/apply"
                    }
                },
                {
                    "action": "COMMENTED",
                    "comment": {
                        "text": "Second comment"
                    }
                },
                {
                    "action": "APPROVED"
                }
            ]
        }
        '''
        helper.registerAllowedMethod(shell, [Map]) { m ->
            shOutput = m.script
            return mockResponse
        }
        helper.registerAllowedMethod(readJson, [Map]) { m ->
            return new JsonSlurper().parseText(mockResponse) as Object
        }
        Script script = loadScript(scriptPath)
        mockUseBBCredentials(script)
        boolean exists = script.checkCommentExists(testProject, testRepository, '123', '/apply')
        assertTrue(exists)
        exists = script.checkCommentExists(testProject, testRepository, '123', 'Non-existent comment')
        assertFalse(exists)
    }

    @Test
    @DisplayName('Test updating the description of a Bitbucket pull request')
    @Tag('updatePRDescription')
    void testUpdatePRDescription() {
        String mockFetchResponse = '''
        {
            "description": "Current description",
            "version": 1
        }
        '''
        String mockUpdateResponse = '''
        {
            "description": "New description",
            "version": 2
        }
        '''
        helper.registerAllowedMethod(shell, [Map]) { m ->
            shOutput = m.script
            if (m.script.contains('curl -v --fail -u')) {
                return mockFetchResponse
            } else if (m.script.contains('curl -v --fail -X PUT -u')) {
                return mockUpdateResponse
            }
            return ''
        }
        helper.registerAllowedMethod(readJson, [Map]) { m ->
            return new JsonSlurper().parseText(mockFetchResponse) as Object
        }
        helper.registerAllowedMethod(writeJSON, [Map]) { m ->
            fileContent = new JsonBuilder(m.json).toPrettyString()
        }
        Script script = loadScript(scriptPath)
        mockUseBBCredentials(script)

        // Test replacing the current description
        script.updatePRDescription(testProject, testRepository, '123', 'New description', true)
        assertTrue(fileContent.indexOf('New description') > 0)

        // Test appending to the current description
        script.updatePRDescription(testProject, testRepository, '123', 'Additional info', false)
        assertTrue(fileContent.indexOf('Current description\\n\\n----- AUTOGENERATED TEXT: -----\\n\\nAdditional info') > 0)
        mockFetchResponse = '''
        {
            "description": "Current description\\n\\n----- AUTOGENERATED TEXT: -----\\n\\nPrevios info",
            "version": 1
        }
        '''
        script.updatePRDescription(testProject, testRepository, '123', 'Additional info', false)
        assertTrue(fileContent.indexOf('Current description\\n\\n----- AUTOGENERATED TEXT: -----\\n\\nAdditional info') > 0)
    }

}

class TestBitBucketException extends Exception {

    TestBitBucketException(String message) {
        super(message)
    }

}
