
import groovy.transform.Field

@Field String planName = ''
@Field Integer terraformPlanStatusCode = 0
@Field String project = ''
@Field String repo = ''
@Field String changeId = ''
@Field String prUrl = ''
@Field String terraformOutput = ''
@Field Map<String, String> externalModulesAuthData = [:]
@Field final String TERRAFORM_DOC_FILENAME = 'README.md'

void init(String project, String repo, String creds, Map<String, String> externalModulesAuthData) {
    bitbucket.bitBucketCredentialsId = creds
    this.project = project
    this.repo = repo
    this.planName = "plan_pr_${env.CHANGE_ID}.tfplan"
    this.prUrl = "${bitbucket.bitbucketUrl}/projects/${project}/repos/${repo}/pull-requests/${env.CHANGE_ID}"
    this.externalModulesAuthData = externalModulesAuthData
}

Boolean skipApply(String title) {
    return "${title}".trim().matches('(?i)^\\[DO NOT MERGE\\].*$')
}

/**
 * Checks approvals on PR, returns true if there is at least one approval
 */
Boolean isPullRequestApproved() {
    return bitbucket.isPullRequestApproved(project, repo, env.CHANGE_ID)
}

Boolean isAutoApplyComment() {
    return bitbucket.checkCommentExists(project, repo, env.CHANGE_ID, '/apply')
}
/**
 * Approves pull request
 */
void approvePullRequest() {
    bitbucket.approvePullRequest(project, repo, env.CHANGE_ID)
}

void uploadAttachment(String attachment) {
    bitbucket.uploadAttachment(project, repo, attachment)
}

void sendPlanToComment(String planText, String attachment) {
    String commentText = "```${planText}``` \n [plan_pr_${env.CHANGE_ID}.tfplan](${attachment}) \n[Go to Jenkins for approve](${env.BUILD_URL})"
    bitbucket.sendBitBucketPRComment(commentText, prUrl)
}

void sendApplyResultToComment(String applyText) {
    bitbucket.sendBitBucketPRComment(applyText, prUrl)
}

void sendCheckovToComment(String checkovText) {
    Map resultJson = readJSON text: checkovText
    resultJson = resultJson?.summary ?: ['Checkov scan error': 'result doesn\'t have summary element']
    String result = resultJson.collect { k, v -> "${k}: ${v}" }.join('\n')
    String commentText = "Checkov Results: \n```\n${result} \n```\n[Go to Jenkins for detailed report](${env.BUILD_URL})"
    bitbucket.sendBitBucketPRComment(commentText, prUrl)
}

void mergePullRequest() {
    bitbucket.mergePullRequest(prUrl, env.GIT_BRANCH)
}

void initCommand(String folder) {
    updateNetrcWithGitCredentials()
    sh """cd ${folder}
            terraform init """
}

/**
 * Adds entry to .netrc file with provided host and credentials
 * Use with caution outside containers - credentials are stored in plaintext
 */
void updateNetrcWithGitCredentials() {
    externalModulesAuthData.each { credEntry ->
        withCredentials([usernamePassword(
            credentialsId: credEntry.value,
            usernameVariable: 'ACCESS_TOKEN_USERNAME',
            passwordVariable: 'ACCESS_TOKEN_PASSWORD',
        )]) {
            sh """echo 'machine ${credEntry.key} login ${ACCESS_TOKEN_USERNAME} password ${ACCESS_TOKEN_PASSWORD}' >> ~/.netrc"""
        }
    }
}

void planCommand(String folder) {
    terraformPlanStatusCode = sh(script: """cd ${folder}
        terraform plan -detailed-exitcode -lock=false -out=${planName}""", returnStatus: true)
    if (terraformPlanStatusCode == 1) { // Error occured during `terraform plan`
        error 'terraform plan failed'
    }
    sh """cd ${folder}
        terraform show -no-color -json ${planName} > ./${planName}.json
        terraform show -no-color ./${planName} > ./shown
    """
}

void validateCommand(String folder) {
    sh """cd ${folder}
            terraform validate"""
}

void fmtCommand(String folder) {
    sh """cd ${folder}
             terraform fmt -recursive -check"""
}

void showCommand(String folder) {
    sh """cd ${folder}
            terraform show ./${planName}"""
}

String applyCommand(String folder) {
    sh """#!/bin/bash
            cd ${folder}
            set -e
            set -o pipefail
            terraform apply -auto-approve ./${planName} | tee ./output
            set +o pipefail"""
    terraformOutput = readFile(file: "${folder}/output")
}

void docsCheckCommand(String folder) {
    sh(label: 'Check terraform docs',
       script: """cd ${folder}
                terraform-docs markdown table --recursive --output-file README.md --output-check ./""")
}

void docsCreateCommand(String folder) {
    sh(label: 'Create terraform docs',
       script: """cd ${folder}
            terraform-docs markdown table --recursive --output-file README.md ./""")
}

/**
 * If doc files were updated, commits and pushes them to remote repo, returing `true`
 * If doc files were not updated, returns `false`
 */
void commitAndPushIfDocsChanged(String folder) {
    // Assuming that only changes we can encounter are changes in docs
    List<String> changed = gitHelper.getChangedAndUntrackedFiles(folder)
    if (changed.size() != 0) {
        sh """cd ${folder}
            git config user.name "ddmtv_service_account"
            git config user.email "ddmtv_service_account@luxoft.com" """
        gitHelper.commitToGit(folder, '[JENKINS-CI]::[TF-PIPELINE]:: update docs')
        error('Updates in terraform docs, restart needed')
    }
}

Closure executeTerraform(String cloudType, String cloudCredentials, String folder, String command) {
    switch (cloudType) {
        case 'AWS':
            withCredentials([file(credentialsId: cloudCredentials, variable: 'AWS_CREDENTIALS')]) {
                /* groovylint-disable-next-line DuplicateStringLiteral */
                withEnv(readFile(AWS_CREDENTIALS).split('\n') as List) {
                    this."${command}Command"(folder)
                }
            }
            break
        case 'GCP':
            withCredentials([file(credentialsId: cloudCredentials, variable: 'GOOGLE_CREDENTIALS')]) {
                this."${command}Command"(folder)
            }
            break
        case 'Azure':
            withCredentials([file(credentialsId: cloudCredentials, variable: 'AZURE_SERVICE_PRINCIPAL')]) {
                /* groovylint-disable-next-line DuplicateStringLiteral */
                withEnv(readFile(AZURE_SERVICE_PRINCIPAL).split('\n') as List) {
                    this."${command}Command"(folder)
                }
            }
            break
        default:
            error("Type ${cloudType} is not implemented")
    }
}

/**
 * Calculate PR changeset and compare folders with inputed list of folders
 * Ignores folder where only README.md files are changed
 * return: intersection in form of list of unique folders
 */
Set<String> getChangedFolders(List<String> folders) {
    List<String> changeset = gitHelper.getPrChangedFiles(env.CHANGE_TARGET)
    Set<String> l = [] as Set
    folders.each { folder ->
        changeset.each { ch ->
            if ((ch.endsWith(folder) || ch.find("${folder}/")) && !ch.find(TERRAFORM_DOC_FILENAME)) {
                l.add(folder)
            }
        }
    }
    return l
}

/**
 * Get folder with terraform code we want to execute our CI against
 * If module folder is modified, we also add module test folder to the list
 * If CI folder is modified, we also add ci test folder to the list
 * Final list should contain one folder or less
 * return: folder name
 */
String getWorkingFolder(Map projectFolders) {
    Set<String> modifiedFolders = getChangedFolders(projectFolders.terraform)
    Set<String> modifiedModulesFolders = getChangedFolders(projectFolders.tfModules)
    Set<String> modifiedCIFolders = getChangedFolders(projectFolders.ci)
    String workingFolder = ''
    if ( modifiedModulesFolders.size() > 0 && projectFolders?.tfModulesTest) {
        modifiedFolders.add(projectFolders.tfModulesTest)
    }
    if (modifiedCIFolders.size() > 0 && projectFolders?.ciTest) {
        modifiedFolders.add(projectFolders.ciTest)
    }
    if (modifiedFolders.size() == 1) {
        workingFolder = modifiedFolders[0]
        String commentText = "Peforming actions on '${workingFolder}' folder"
        echo commentText
        bitbucket.sendBitBucketPRComment(commentText, prUrl)
    }
    if (modifiedFolders.size() > 1) {
        String commentText = 'ERROR: Only one directory with terraform configs may be modified per pull request. CI also should be modified separately'
        bitbucket.sendBitBucketPRComment(commentText, prUrl)
        error(commentText)
    }
    return workingFolder
}

void checkovScan(String folder, String junitxml, String commentContent) {
    updateNetrcWithGitCredentials()
    sh(label: 'Run Chekov scan',
       script: """checkov --soft-fail \
            -d ${folder} --skip-path ${planName}.json \
            --download-external-modules True -o junitxml > ${junitxml}""")
    sh(label: 'Get Checkov json results',
      script: "checkov --soft-fail -f ${folder}/${planName}.json -o json > ${commentContent}")
}

void sendInfracostPRComment(String changeId) {
    bitbucket.useBBCredentials {
        sh """infracost comment bitbucket \
                --path infracost.json \
                --bitbucket-token ${ACCESS_TOKEN_USERNAME}:${ACCESS_TOKEN_PASSWORD} \
                --repo ${project}/${repo} \
                --pull-request ${changeId} \
                --behavior delete-and-new \
                --bitbucket-server-url ${bitbucket.bitbucketUrl}"""
    }
}

void infracostBreakdown(String planFile) {
    sh "infracost breakdown --path ${planFile} --out-file infracost.json --format json"
}
