import groovy.transform.Field

@Field String nodelabel = 'smop-linux'
@Field String project = ''
@Field String repo = ''
@Field String repoCreds = ''
@Field Boolean isNeedApprove = false
@Field Boolean isAutoApplyComment = false
@Field Boolean allowApproveWithServiceAccount = false
@Field String infracostApiEndpoint = 'https://infracost.lms-team.org'
@Field String infracostApiKeyCredentialsId = 'infracost_api_key'
@Field final Integer TERRAFORM_APPLY_NEEDED = 2
@Field final String TERRAFORM_PLAN_FILE_STASH_NAME = 'tfplan'
// In create docs stage repository will be cloned in dir TERRAFORM_DOCS_TMP_REPO_PATH_PREFIX/<repo-name>
@Field final String TERRAFORM_DOCS_TMP_REPO_PATH_PREFIX = '/tmp'

/* groovylint-disable-next-line ImplementationAsType */
@Field LinkedHashMap<String,Boolean> terraformSteps = [
    'plan' : true,
    'validate': true,
    'fmt' : false,
    'docsCreate' : false,
    'docsCheck' : false,
    'show' : true,
    'checkov' : false,
    'infracost' : false
]

@Field String cloudType = 'GCP'
@Field String cloudCredentials = 'terraformLuxoft'
@Field String workingFolder
@Field Boolean doesChangesDetected = false

@Field Map folders = [
    'terraform' : [],                       // folders where terraform code can be found except modules
    'ci' : [],                              // folders where ci code can be found
    'ciTest' : '',                          // [Optional] folder which can be used for tests against ci changes. Can be empty if no tests needed
    'tfModules': [],                        // folders where terraform modules can be found if they are not inside main terraform folder
    'tfModulesTest': '',                    // [Optional] folder which can be used for tests against modules changes. Can be empty if no tests needed
    'tfDocsRoot': 'terraform'               // [Optional] folder for terraform-docs tool, should contain terraform modules
]

/**
 * Stores hosts and associated credentials for authenticating when terraform downloads modules from git repositories that require authentication
 * keys must be hostnames on which repository is hosted, e.g. 'luxproject.luxoft.com',
 * values are credentials that are used to access referred repository on host
 * Credentials are expected to be username-password
 */
@Field Map<String,String> externalModulesAuthData = [:]

/* groovylint-disable-next-line MethodSize */
void call(Map<String,String> terraformAgent, Map<String,String> checkovAgent, Map<String,String> infracostAgent) {
    pipeline {
        agent none
        options {
            disableConcurrentBuilds abortPrevious: true
            skipDefaultCheckout()
        }
        stages {
            stage('Detect modified directory') {
                agent {
                    label nodelabel
                }
                steps {
                    script {
                        checkout scm
                        terraformPipelineHelper.init(project, repo, repoCreds, externalModulesAuthData)
                        workingFolder = terraformPipelineHelper.getWorkingFolder(folders)
                        if (workingFolder != '') {
                            doesChangesDetected = true
                        }
                    }
                }
            }
            stage('Terraform') {
                when {
                    beforeAgent true
                    expression {
                        return doesChangesDetected && terraformSteps.plan
                    }
                }
                agent {
                    docker {
                        alwaysPull true
                        image terraformAgent.image
                        registryUrl terraformAgent.registryUrl
                        registryCredentialsId terraformAgent.registryCredentialsId
                        args "--user=root ${terraformAgent.args}"
                        label terraformAgent.nodeLabel
                    }
                }
                stages {
                    stage('Terraform init') {
                        when {
                            expression { terraformSteps.plan }
                        }
                        steps {
                            script {
                                checkout scm
                                terraformPipelineHelper.executeTerraform(cloudType, cloudCredentials, workingFolder, 'init')
                            }
                        }
                    }
                    stage('Terraform plan') {
                        when {
                            expression { terraformSteps.plan }
                        }
                        steps {
                            script {
                                terraformPipelineHelper.executeTerraform(cloudType, cloudCredentials, workingFolder, 'plan')
                                String planFile = "${workingFolder}/${terraformPipelineHelper.planName}.json"
                                String planText = readFile(file: "${workingFolder}/shown")
                                String planFileLink = terraformPipelineHelper.uploadAttachment(planFile)
                                terraformPipelineHelper.sendPlanToComment(planText, planFileLink)
                                stash includes: "${planFile},${workingFolder}/${terraformPipelineHelper.planName}", name: TERRAFORM_PLAN_FILE_STASH_NAME
                            }
                        }
                    }
                    stage('Terraform validate') {
                        when {
                            expression { terraformSteps.validate }
                        }
                        steps {
                            script {
                                terraformPipelineHelper.executeTerraform(cloudType, cloudCredentials, workingFolder, 'validate')
                            }
                        }
                    }
                    stage('Terraform fmt') {
                        when {
                            expression { terraformSteps.fmt }
                        }
                        steps {
                            script {
                                terraformPipelineHelper.executeTerraform(cloudType, cloudCredentials, workingFolder, 'fmt')
                            }
                        }
                    }
                    stage('Terraform show') {
                        when {
                            expression { terraformSteps.plan }
                        }
                        steps {
                            script {
                                terraformPipelineHelper.executeTerraform(cloudType, cloudCredentials, workingFolder, 'show')
                            }
                        }
                    }
                    /**
                     * This stage will checkout repository to new directory
                     * It assumes that remote repository is hosted on bitbucket
                     * It also assumes that env.CHANGE_BRANCH is defined (since this pipeline is
                     * to be triggered on PRs)
                     */
                    stage('Terraform docs create') {
                        when {
                            expression { terraformSteps.docsCreate }
                        }
                        steps {
                            script {
                                String localRepoPath = "${TERRAFORM_DOCS_TMP_REPO_PATH_PREFIX}/${repo}"
                                gitHelper.checkoutWithGit(
                                    gitHelper.remoteBaseUrl + "/${project}/${repo}",
                                    env.CHANGE_BRANCH,
                                    localRepoPath,
                                    repoCreds
                                )
                                terraformPipelineHelper.executeTerraform(
                                    cloudType,
                                    cloudCredentials,
                                    localRepoPath + '/' + folders.tfDocsRoot,
                                    'docsCreate'
                                )
                                // If terraformPipelineHelper.commitAndPushIfDocsChanged(localRepoPath) commits and pushes, build fails with error
                                // to allow new build to start
                                terraformPipelineHelper.commitAndPushIfDocsChanged(localRepoPath)
                                // Otherwise no changes were made
                                echo 'No changes to docs'
                            }
                        }
                    }
                    stage('Terraform docs check') {
                        when {
                            expression { terraformSteps.docsCheck }
                        }
                        steps {
                            script {
                                terraformPipelineHelper.executeTerraform(cloudType, cloudCredentials, folders.tfDocsRoot, 'docsCheck')
                            }
                        }
                    }
                }
                post {
                    always {
                        cleanWs()
                    }
                }
            }
            stage('Checkov scan') {
                when {
                    beforeAgent true
                    expression { terraformSteps.checkov }
                }
                agent {
                    docker {
                        image checkovAgent.image
                        registryUrl checkovAgent.registryUrl
                        registryCredentialsId checkovAgent.registryCredentialsId
                        args "--user=root ${checkovAgent.args}"
                        label checkovAgent.nodeLabel
                    }
                }
                steps {
                    script {
                        checkout scm
                        String checkovReport = 'result.json'
                        String junitReport = 'results.xml'
                        unstash TERRAFORM_PLAN_FILE_STASH_NAME
                        terraformPipelineHelper.checkovScan(workingFolder, junitReport, checkovReport)
                        junit allowEmptyResults: true, testResults: junitReport, skipPublishingChecks: true, skipMarkingBuildUnstable: true
                        terraformPipelineHelper.sendCheckovToComment(readFile(checkovReport))
                    }
                }
                post {
                    always {
                        cleanWs()
                    }
                }
            }
            stage('Infracost impact') {
                when {
                    beforeAgent true
                    expression { return terraformSteps.infracost && terraformSteps.plan }
                }
                agent {
                    docker {
                        image infracostAgent.image
                        registryUrl infracostAgent.registryUrl
                        registryCredentialsId infracostAgent.registryCredentialsId
                        args "--user=root ${infracostAgent.args}"
                        label infracostAgent.nodeLabel
                    }
                }
                environment {
                    INFRACOST_API_KEY = credentials("${infracostApiKeyCredentialsId}")
                    INFRACOST_PRICING_API_ENDPOINT = "${infracostApiEndpoint}"
                }
                steps {
                    script {
                        unstash TERRAFORM_PLAN_FILE_STASH_NAME
                        terraformPipelineHelper.infracostBreakdown("${workingFolder}/${terraformPipelineHelper.planName}.json")
                        terraformPipelineHelper.sendInfracostPRComment(CHANGE_ID)
                    }
                }
                post {
                    always {
                        cleanWs()
                    }
                }
            }

            stage('Pre-merge checks') {
                agent {
                    docker {
                        image terraformAgent.image
                        registryUrl terraformAgent.registryUrl
                        registryCredentialsId terraformAgent.registryCredentialsId
                        args "--user=root ${terraformAgent.args}"
                        label terraformAgent.nodeLabel
                    }
                }
                steps {
                    script {
                        echo "CHANGE_TITLE: ${env.CHANGE_TITLE}"
                        Boolean skipFlag = terraformPipelineHelper.skipApply(env.CHANGE_TITLE)
                        echo "Skip applying: ${skipFlag}"
                        if (skipFlag) {
                            error('This PR is marked as [DO NOT MERGE], cancel it in order to prevent applying the configuration and merging the PR')
                        }
                        //Check for autoapply comments:
                        isAutoApplyComment = terraformPipelineHelper.isAutoApplyComment()
                        //We assume that if there is an autoapply comment, we don't need to ask for approval
                        if (isAutoApplyComment) {
                            isNeedApprove = false
                        }
                    }
                }
            }
            stage('Confirm') {
                agent none
                when {
                    beforeAgent true
                    expression {
                        return doesChangesDetected
                    }
                }
                options {
                    timeout(time: 12, unit: 'HOURS')
                }
                steps {
                    script {
                        // Ask for apply and merge if there are something to apply via terraform
                        if (terraformPipelineHelper.terraformPlanStatusCode == TERRAFORM_APPLY_NEEDED && !isAutoApplyComment) {
                            input(message: 'Apply?', ok: 'apply and merge', id: 'APPLY')
                        }
                    }
                }
            }
            stage('Check PR approvements status') {
                when {
                    beforeAgent true
                    expression {
                        return isNeedApprove &&
                            terraformPipelineHelper.terraformPlanStatusCode == TERRAFORM_APPLY_NEEDED &&
                            doesChangesDetected
                    }
                }
                agent {
                    docker {
                        image terraformAgent.image
                        registryUrl terraformAgent.registryUrl
                        registryCredentialsId terraformAgent.registryCredentialsId
                        args "--user=root ${terraformAgent.args}"
                        label terraformAgent.nodeLabel
                    }
                }
                options {
                    /* groovylint-disable-next-line DuplicateStringLiteral */
                    timeout(time: 4, unit: 'HOURS')
                }
                steps {
                    script {
                        // If pull request is not approved, explicitly ask for approval on behalf of service account
                        if (!terraformPipelineHelper.isPullRequestApproved()) {
                            // Input leads to either procceeding or abortion of the pipeline, so unless user clicked 'Approve' further steps won't be performed
                            if (allowApproveWithServiceAccount) {
                                input(message: 'Pull request is not approved, approve it on behalf of service account?', ok: 'Approve')
                                terraformPipelineHelper.approvePullRequest()
                            } else {
                                error('PR is not approved, aborting the pipeline')
                            }
                        }
                    }
                }
            }
            stage('Terraform apply and merge') {
                when {
                    beforeAgent true
                    expression {
                        return terraformPipelineHelper.terraformPlanStatusCode == TERRAFORM_APPLY_NEEDED && doesChangesDetected
                    }
                }
                agent {
                    docker {
                        image terraformAgent.image
                        registryUrl terraformAgent.registryUrl
                        registryCredentialsId terraformAgent.registryCredentialsId
                        args "--user=root ${terraformAgent.args}"
                        label terraformAgent.nodeLabel
                    }
                }
                steps {
                    script {
                        checkout scm
                        unstash TERRAFORM_PLAN_FILE_STASH_NAME
                        // Run init command to cache required providers. Not stashing .terraform folder bc it may be very large
                        /* groovylint-disable-next-line DuplicateStringLiteral */
                        terraformPipelineHelper.executeTerraform(cloudType, cloudCredentials, workingFolder, 'init')
                        terraformPipelineHelper.executeTerraform(cloudType, cloudCredentials, workingFolder, 'apply')
                        terraformPipelineHelper.sendApplyResultToComment(terraformPipelineHelper.terraformOutput)
                        terraformPipelineHelper.mergePullRequest()
                    }
                }
                post {
                    always {
                        cleanWs()
                    }
                }
            }
        }
    }
}
