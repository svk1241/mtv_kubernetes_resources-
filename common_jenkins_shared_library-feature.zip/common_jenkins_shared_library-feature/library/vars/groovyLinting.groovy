import groovy.transform.Field

@Field final String GG_ARTIFACTORY_URL = 'https://luxproject.luxoft.com/artifactory/MPC-generic/GrooveGuard/builds/'

@Field String ggVersion = 'v.1.0.0+build'
@Field String ggArtifactoryCreds = 'artifactory_token'
@Field String ggAiCreds = 'ai_azure_genaipilot_gpt_4_omni'

/**
 * Runs npm-groovy-lint on the specified repository folder and captures the output.
 *
 * This method performs the following steps:
 * 1. Copies the .groovylintrc.json file from the specified repository folder to the current directory if exists.
 * 2. Executes the npm-groovy-lint command with specified options and captures the output.
 * 3. Returns the result of the linting command.
 *
 * @param repoFolder The path to the repository folder containing the files to be linted.
 * @param command Optional custom linting command to be executed. If not provided, a default command is used.
 * @return true if no linting errors are found, false otherwise.
 */
Boolean hasGroovyLintErrors(String repoFolder, String command = '') {
    sh("cp ${repoFolder}/.groovylintrc.json . || true")
    String lintCommand = command ?: """npm-groovy-lint --verbose --insight=false \
                            --noserver=true --failon=info \
                            --ignorepattern "**/test/**/*.groovy" \
                            "${repoFolder}/**/*.groovy,${repoFolder}/**/*.jenkinsfile,${repoFolder}/**/Jenkinsfile"
                        """
    Integer result = sh(script: lintCommand, returnStatus: true)
    return result.asBoolean()
}

/**
 * Executes GrooveGuard to fix linting issues.
 *
 * This method performs the following steps:
 * 1. Downloads the GrooveGuard archive from Artifactory.
 * 2. Unzips the GrooveGuard archive.
 * 3. Sets the necessary permissions for the GrooveGuard script.
 * 4. Executes the GrooveGuard script with the specified or default linting command.
 *
 * @param workDirectory The directory where the GrooveGuard archive will be unzipped and executed.
 * @param command Optional custom linting command to be executed. If not provided, a default command is used.
 */
@Deprecated //use runGrooveGuard(String workDirectory, String command, Map args) instead
void runGrooveGuard(String workDirectory, String lintCommand='', String filesToLint='') {
    String files = filesToLint ?: "${repoFolder}/**/*.groovy,${repoFolder}/**/*.jenkinsfile,${repoFolder}/**/Jenkinsfile"
    String lc = lintCommand ?: '''npm-groovy-lint --verbose --insight=false --noserver=true --failon=none --output=json \
                                                     --ignorepattern="**/test/**/*.groovy"'''
    Map<String, String> args = ['linter-command': lc, 'files': files]
    String command = 'exec'
    runGrooveGuard(workDirectory, command, args)
}

/**
 * Runs the GrooveGuard tool with the specified command and arguments.
 *
 * @param workDirectory The directory where GrooveGuard will be executed.
 * @param command The command to run with GrooveGuard.
 * @param args A map of arguments to pass to the GrooveGuard command.
 */
void runGrooveGuard(String workDirectory, String command, Map args) {
    jfrog.artifactoryCredentialsName = ggArtifactoryCreds
    String ggArchive = "GrooveGuard.${ggVersion}.zip"
    jfrog.downloadFromArtifactory(GG_ARTIFACTORY_URL, ggArchive)
    unzip zipFile: ggArchive, dir: workDirectory
    sh("chmod +x ${workDirectory}/groove-guard")
    String argsString = args.collect { k, v -> "--${k}='${v}'" }.join(' ')
    withCredentials([usernamePassword(credentialsId: ggAiCreds,
                                      passwordVariable: 'AZURE_OPENAI_API_KEY',
                                      usernameVariable: 'AZURE_OPENAI_ENDPOINT')]) {
        sh("${workDirectory}/groove-guard ${command} ${argsString}")
    }
}

/**
 * Adds a pull request description by running the GrooveGuard tool and sending the output to Bitbucket.
 *
 * @param workDirectory The directory where GrooveGuard will be executed.
 * @param extraArgs Additional arguments to pass to the GrooveGuard command. Example: ['language':'python']
 */
void addPRDescription(String projectName, String repoName, String prName,
                      String sourceBranch, String targetBranch, String credentialsId,
                      Map extraArgs=[:]) {
    String workDirectory = './'
    gitHelper.jenkinsCredentialsName = credentialsId
    bitbucket.bitBucketCredentialsId = credentialsId
    String repoUrl = "luxproject.luxoft.com/stash/scm/${projectName.toLowerCase()}/${repoName.toLowerCase()}.git"
    sh("rm -rf ${env.WORKSPACE}/*")
    gitHelper.checkoutWithGit(repoUrl,
                              sourceBranch,
                              repoName,
                              gitHelper.jenkinsCredentialsName)
    String prDescriptionFile = 'pr_review.txt'
    Map<String, String> args = ['change-branch': sourceBranch, 'target-branch': targetBranch,
                                'code-dir': repoName, 'output-file': prDescriptionFile]
    args += extraArgs
    String command = 'pr-review'
    try {
        runGrooveGuard(workDirectory, command, args)
        bitbucket.updatePRDescription(projectName, repoName, prName, readFile("${workDirectory}/${prDescriptionFile}"), false)
    } catch (e) {
        echo "Error: Couldn't generate PR review by GrooveGuard. Please, see details below."
        error(e.getMessage())
    }
}

/**
 * Lints and fixes Groovy code in a specified repository and branch.
 * This method performs the following steps:
 * 1. Constructs the repository URL and pull request URL.
 * 2. Cleans the workspace.
 * 3. Checks out the specified branch from the repository.
 * 4. Runs npm-groovy-lint to check for linting issues.
 * 5. If linting issues are found, posts a comment on the pull request and attempts to fix the issues using GrooveGuard.
 * 6. If GrooveGuard successfully fixes the issues, commits the changes and posts a comment on the pull request.
 * 7. If GrooveGuard fails, posts an error comment on the pull request.
 *
 * @param projectName The name of the project.
 * @param repoName The name of the repository.
 * @param prName The name of the pull request.
 * @param branchName The name of the branch to lint and fix.
 */
void lintAndFixGroovyCode(String projectName, String repoName, String prName, String branchName, String credentialsId) {
    gitHelper.jenkinsCredentialsName = credentialsId
    bitbucket.bitBucketCredentialsId = credentialsId
    String repoUrl = "luxproject.luxoft.com/stash/scm/${projectName.toLowerCase()}/${repoName.toLowerCase()}.git"
    String prUrl = "${bitbucket.bitbucketUrl}/projects/${projectName.toUpperCase()}/repos/${repoName.toLowerCase()}/pull-requests/${prName}"
    sh("rm -rf ${env.WORKSPACE}/*")
    /* groovylint-disable-next-line DuplicateStringLiteral */
    String workDirectory = './'
    gitHelper.checkoutWithGit(repoUrl,
                              branchName,
                              repoName,
                              gitHelper.jenkinsCredentialsName)
    String lintCommand = """npm-groovy-lint --verbose --insight=false \
            --noserver=true --failon=info \
            --ignorepattern "**/test/**/*.groovy" \
            "${repoName}/**/*.groovy,${repoName}/**/*.jenkinsfile,${repoName}/**/Jenkinsfile"
        """
    if (hasGroovyLintErrors(repoName, lintCommand)) {
        String commentText = '### Some linting issues found in the code.  \n***GrooveGuard*** will try to fix them.'
        bitbucket.sendBitBucketPRComment(commentText, prUrl)
        lintCommand = '''npm-groovy-lint --verbose --insight=false --noserver=true --failon=none --output=json \
                       --ignorepattern="**/test/**/*.groovy"'''
        String filesToLint = "${repoName}/**/*.groovy,${repoName}/**/*.jenkinsfile,${repoName}/**/Jenkinsfile"
        try {
            runGrooveGuard(workDirectory, lintCommand, filesToLint)
            isCodeChanged = true
            unstable(message: 'Code was changed with GrooveGuard')
        } catch (e) {
            commentText = '### Error! The ***GrooveGuard*** failed.  \nPlease check the last job logs for details.'
            bitbucket.sendBitBucketPRComment(commentText, prUrl)
            error(e.getMessage())
        }
        if (isCodeChanged) {
            dir(repoName) {
                String commitMessage = '[GrooveGuard]: fix : Automated fixes of linting'
                gitHelper.configureGitLocalCreds(bitbucket.bitBucketCredentialsId)
                gitHelper.commitToGit(workDirectory, commitMessage)
            }
            commentText = '## **IMPORTANT**! This PR was fixed with *GrooveGuard*!  \nPlease check the changes in the last commit'
            bitbucket.sendBitBucketPRComment(commentText, prUrl)
        }
    }
}
