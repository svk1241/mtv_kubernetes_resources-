/**
 * Common Jenkins library
 */
import groovy.transform.Field

@Field String jenkinsCredentialsId = 'lms_git_access'
@Field String jenkinsUrl = 'luxproject.luxoft.com/jenkins'

Closure useJenkinsCredentials(Closure body) {
    withCredentials([usernamePassword(
            credentialsId: jenkinsCredentialsId,
            usernameVariable: 'ACCESS_TOKEN_USERNAME',
            passwordVariable: 'ACCESS_TOKEN_PASSWORD',
    )
    ]) {
        return body.call()
    }
}

void getLastBuildArtifact(String jenkinsJobPath) {
    useJenkinsCredentials {
        sh """curl -L -u '${ACCESS_TOKEN_USERNAME}:${ACCESS_TOKEN_PASSWORD}' \
-o 'archive.zip' \
'https://${jenkinsUrl}/${jenkinsJobPath}/lastSuccessfulBuild/artifact/*zip*/archive.zip' """
    }
}

String getLastSuccessfulBuildId(String jenkinsJobPath) {
    useJenkinsCredentials {
        String buildId = ''
        String buildInfo = sh(
            script: "curl -L -u ${ACCESS_TOKEN_USERNAME}:${ACCESS_TOKEN_PASSWORD} 'https://${jenkinsUrl}/${jenkinsJobPath}/lastSuccessfulBuild/api/json'",
            returnStdout: true
        ).trim()

        try {
            Map buildInfoMap = readJSON(text: buildInfo)
            buildId = buildInfoMap.id
        /* groovylint-disable-next-line CatchException */
        } catch (Exception e) {
            echo "There are no successful build id. Build Info: ${buildInfo}"
        }
        echo "Last successful build id: ${buildId}"
        return buildId
    }
}
