//TODO: we need to split it to shared part and monitoring part and move monitoring testing to corresponding repo
@groovy.transform.Field
String gitCredentials = 'lms_git_access'
@groovy.transform.Field
String cloudCredentialsVariable = 'AZURE_SERVICE_PRINCIPAL'

/**
 * Creates or deletes cluster manifest in common_infrastructure repository.
 *
 * @param command 'create' or 'delete' cluster
 * @param sendNotifications is needed to sent notification to teams chennel
 * @param teamsWebhookUrl webhook url to teams channel
 */
void manageCluster(String infrastructureType,
                   String command,
                   Boolean autoApply = false,
                   Boolean sendNotifications = false,
                   String teamsWebhookUrl) {
    // TODO: need to try to move it to jenkinsfile
    bitbucket.bitBucketCredentialsId = gitCredentials
    String createCommand = 'create'
    String deleteCommand = 'delete'
    if (![createCommand, deleteCommand].contains(command)) {
        echo "Unknown command ${command}. Valid commands for this method: create, delete"
        return
    }
    String checkoutDestination = './common_infrastructure'
    String project = 'MPC'
    String repoName = 'common_infrastructure'
    String checkoutBranch = 'develop'
    gitHelper.checkoutWithGit('luxproject.luxoft.com/stash/scm/mpc/common_infrastructure.git', checkoutBranch, checkoutDestination, gitCredentials)
    bitbucket.deleteBranch(project, repoName, "${command}_monitoring_cluster")
    dir(checkoutDestination) {
        sh """
            git checkout -b '${command}_monitoring_cluster'
            git push --set-upstream origin ${command}_monitoring_cluster"""
        if (command == createCommand) {
            sh "cp ../ci/terraform/monitoring.tf ./modernization_presale/terraform/$infrastructureType/"
        } else if (command == deleteCommand) {
            sh "rm ./modernization_presale/terraform/$infrastructureType/monitoring.tf"
        }
        gitHelper.commitToGit('./', "[Jenkins]::[CI/CD]: ${command} cluster for observability platform")
        Map pr = bitbucket.createPr(
            project,
            repoName,
            "${command} monitoring cluster",
            'automatically created PR',
            "${command}_monitoring_cluster",
            checkoutBranch)
        if (autoApply) {
            bitbucket.sendBitBucketPRComment('/apply', pr.url)
        }
        if (sendNotifications && !autoApply) {
            teams.sendChannelNotificationWithIncomingWebhook(teamsWebhookUrl, "Pull request '${command} monitoring cluster' available", pr.url)
        }
        String changeId = pr.url.tokenize('/').last()
        timeout(time: 4, unit: 'HOURS') {
            while (true) {
                sleep time: 5, unit: 'MINUTES'
                String status = bitbucket.getPullRequestStatus(project, repoName, changeId)
                echo status
                if (status == 'MERGED') {
                    break
                }
            }
        }
    }
}

/**
 * Stes k8s version in monitoring aks manifest and calls cluster creation.
 *
 * @param k8sVersion k8s version to install
 * @param sendNotifications is needed to sent notification to teams chennel
 */
void addClusterToCommonInfrastructure(String infrastructureType,
                                      String k8sVersion,
                                      Boolean autoApply = false,
                                      Boolean sendNotification = false,
                                      String teamsWebhookUrl ) {
    sh "sed -i 's/{{K8S_VERSION}}/${k8sVersion}/' ./ci/terraform/monitoring.tf"
    /* groovylint-disable-next-line DuplicateStringLiteral */
    manageCluster(infrastructureType, 'create', autoApply, sendNotification, teamsWebhookUrl)
}

/**
 * Download knative archive with installer from artifactory and install it to aks.
 *
 * @param cloudCredentialsId cloud credentials to use
 * @param knativeInstallersUrl link to knative installers in artifactory
 * @param knativeVersion knative archive name
 */
void deployKnative(String cloudCredentialsId, String knativeInstallersUrl, String knativeVersion) {
    // TODO: need to try to move it to jenkinsfile
    jfrog.artifactoryCredentialsName = 'artifactory_token'
    jfrog.downloadFromArtifactory(knativeInstallersUrl, knativeVersion)
    sh "tar -xzvf ${knativeVersion}"
    dir('./installer') {
        azureApi.azurePrincipal = cloudCredentialsId
        azureApi.withAzureCli {
            sh """
                yq eval '.spec.config.observability."metrics.backend-destination" = "opencensus" |
                        .spec.config.observability."metrics.opencensus-address" = "monitoring-opentelemetry-collector.monitoring:55678"' \
                    -i "./config-serving.yaml"
                az login --service-principal -u ${env.ARM_CLIENT_ID} -p ${env.ARM_CLIENT_SECRET} --tenant ${env.ARM_TENANT_ID}
                az aks get-credentials --resource-group rg-monitoring-testing --name monitoring-aks
                ./install-knative.sh -n knode:kn-node -c -k lxftlmshubacr.azurecr.io -i lxftlmshubacr.azurecr.io -u ${DOCKER_CRED_USR} -p ${DOCKER_CRED_PSW}
            """
        }
    }
}

/**
 * Checkout monitoring repository of specific version and install it to aks.
 *
 * @param cloudCredentialsId cloud credentials to use
 * @param monitoringVersion version of monitoring to install
 */
void deployMonitoring(String cloudCredentialsId, String monitoringVersion) {
    String checkoutDestination = './cloned_monitoring'
    gitHelper.checkoutWithGit(
        'luxproject.luxoft.com/stash/scm/mpc/monitoring_solution_internal.git',
        monitoringVersion,
        checkoutDestination,
        gitCredentials)
    dir(checkoutDestination) {
        azureApi.azurePrincipal = cloudCredentialsId
        azureApi.withAzureCli {
            sh 'az aks get-credentials --resource-group rg-monitoring-testing --name monitoring-aks'
            String releaseName = 'monitoring'
            /* groovylint-disable-next-line DuplicateStringLiteral */
            String namespace = 'monitoring'
            String storageAccountName = 'presalemonitoringstorage'
            String storageKey = sh(script: '''
                az storage account keys list -g rg-monitoring-testing -n presalemonitoringstorage | \
                jq -r '.[] | select(.keyName == "key1") | .value'
            ''', returnStdout: true).trim()
            sh """
                sed -i'' -e "s|<RELEASE>|${releaseName}|g" ./values.yaml
                sed -i'' -e "s|<NAMESPACE>|${namespace}|g" ./values.yaml
                sed -i'' -e "s|<STORAGE_ACCOUNT_NAME_PLACEHOLDER>|${storageAccountName}|g" ./storage_configuration.yaml
                sed -i'' -e "s|<AZURE_KEY_PLACEHOLDER>|${storageKey}|g" ./storage_configuration.yaml
                helm upgrade --install ${releaseName} --namespace ${namespace} --create-namespace -f ./storage_configuration.yaml .
            """
            /* groovylint-disable-next-line DuplicateStringLiteral */
            sleep time: 15, unit: 'MINUTES'
        }
    }
}

/**
 * Perform specific configmap fixes.
 *
 * @param cloudCredentialsId cloud credentials to use
 */
void configureConfigMaps(String cloudCredentialsId) {
    azureApi.azurePrincipal = cloudCredentialsId
    azureApi.withAzureCli {
        sh """
            az aks get-credentials --resource-group rg-monitoring-testing --name monitoring-aks
            kubectl -n knative-serving get configmap config-tracing -o yaml | \
            yq e '.data["zipkin-endpoint"] = "http://monitoring-grafana-tempo-distributor.monitoring.svc.cluster.local:9411/api/v2/spans"' - | \
            kubectl apply -f -
            kubectl -n istio-system get configmap istio -o yaml | \
            yq e '.data.mesh |= sub("zipkin.istio-system:9411", "monitoring-grafana-tempo-distributor.monitoring.svc.cluster.local:9411")' - | \
            kubectl apply -f -
        """
    }
}

/**
 * Creates testing-workload namespace if not present. Installs testing apps to aks.
 *
 * @param cloudCredentialsId cloud credentials to use
 */
void deployWorkload(String cloudCredentialsId) {
    azureApi.azurePrincipal = cloudCredentialsId
    azureApi.withAzureCli {
        sh """
            az aks get-credentials --resource-group rg-monitoring-testing --name monitoring-aks
            kubectl get namespace testing-workload || kubectl create namespace testing-workload
            kubectl create configmap k6-load-test-script --from-file='./ci/tests/load-test.js' --namespace=testing-workload --dry-run=client -o yaml | \
                kubectl apply -f -
            kubectl apply -f ./ci//manifests
        """
    }
}

/**
 * Generates workload using k6 pod.
 *
 * @param cloudCredentialsId cloud credentials to use
 * @param loadDuration load duration
 * @param loadVus load vus
 * @param loadRps load rps
 */
void generateData(String cloudCredentialsId, String loadDuration, String loadVus, String loadRps) {
    azureApi.azurePrincipal = cloudCredentialsId
    azureApi.withAzureCli {
        sh """
            az aks get-credentials --resource-group rg-monitoring-testing --name monitoring-aks
            kubectl wait --for=condition=ready pod/k6-test-pod --timeout=120s -n testing-workload
            kubectl exec -n testing-workload k6-test-pod -- \
                env TEST_DURATION="${loadDuration}" TEST_VUS="${loadVus}" TEST_RPS="${loadRps}" \
                k6 run /scripts/load-test.js
        """
    }
}
