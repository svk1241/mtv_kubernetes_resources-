/**
 * Common jenkins shared library
 * This file contains generic methods for interacting with MS Teams
 */

/**
 * Sends notification to MS Teams channel
 * New post with specified title and text will appear in a channel associated with provided webhook URL
 * @param incomingWebhookUrl Incoming webhook url for channel to send notification to
 * @param title Desired title
 * @param text Desired text content
 */
void sendChannelNotificationWithIncomingWebhook(String incomingWebhookUrl, String title, String text) {
    Map<String,String> notificationBodyObject = ['title': title, 'text': text]
    String tmpFileName = './tmp-ms-teams-webhook-notification.json'
    writeJSON file: tmpFileName, json: notificationBodyObject
    sh """curl -vvv --fail -H 'Content-Type: application/json' \
        --data @${tmpFileName} ${incomingWebhookUrl} && \
        rm ${tmpFileName}"""
}

/**
 * Sends notification to MS Teams channel
 * New post with formatting specified in `notificationJsonData` will appear in a channel associated with provided webhook url
 * Check MS documentation to learn about `notificationJsonData` supported formats and shemas:
 * https://learn.microsoft.com/en-us/microsoftteams/platform/webhooks-and-connectors/how-to/connectors-using
 * @param incomingWebhookUrl Incoming webhook url for channel to send notification to
 * @param notificationJsonData JSON payload for new post (see documentation for details)
 */
void sendChannelNotificationWithIncomingWebhookCustomPayload(String incomingWebhookUrl, String notificationJsonData) {
    sh """curl -vvv --fail -H 'Content-Type: application/json' \
        --data '${notificationJsonData}' ${incomingWebhookUrl}"""
}
