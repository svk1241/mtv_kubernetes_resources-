import groovy.transform.Field

@Field
String jenkinsCredentialsName = 'lms_git_access'

/**
 * This is an umbrella function to save the existing interface.
 * In future we might consider to migrate to a specific functions, or to use new functions for new cases
 * Creates an artifact name depending on the branch name.
 *
 * @param branchName The name of the branch (e.g., PR-*, development, master).
 * @param shaCommit The full SHA commit.
 * @param changeId The change ID (e.g., 1).
 * @param buildId The build ID (e.g., 1).
 * @param baseName The base name of the artifact (e.g., Test).
 * @param extension The extension of the artifact (e.g., zip, tar).
 * @param credentials The credentials to use for accessing the repository (default is jenkinsCredentialsName).
 * @return The generated artifact name.
 */
String getArtifactName(String branchName, String shaCommit, String changeId, String buildId,
                       String baseName, String extension, String credentials=jenkinsCredentialsName) {
    String version = getVersion(branchName, shaCommit, changeId, buildId, credentials)
    String archiveName = "${baseName}.v.${version}.${extension}"

    echo "Archive name: ${archiveName}"
    return archiveName
}

/**
 * This is an umbrella function to mimic existing getArtifactName interface.
 * In future we might consider to migrate to a specific functions, or to use new functions for new cases
 * Creates an image name depending on the branch name.
 *
 * @param branchName The name of the branch (e.g., PR-*, development, master).
 * @param shaCommit The full SHA commit.
 * @param changeId The change ID (e.g., 1).
 * @param buildId The build ID (e.g., 1).
 * @param registry The registry where the image will be stored.
 * @param baseName The base name of the image.
 * @param credentials The credentials to use for accessing the repository (default is jenkinsCredentialsName).
 * @return The generated image name.
 */
String getImageName(String branchName, String shaCommit, String changeId, String buildId, String registry,
                    String baseName, String credentials=jenkinsCredentialsName) {
    String version = getVersion(branchName, shaCommit, changeId, buildId, credentials)
    if (version.length() > 127) {
        version = version.substring(version.length() - 120)
    }
    String imageName = "${registry}/${baseName}:${version}"

    echo "Image name: ${imageName}"
    return imageName
}

/**
 * Gets the version depending on the branch name and commit information.
 *
 * @param branchName The name of the branch (e.g., PR-*, development, master).
 * @param shaCommit The full SHA commit.
 * @param changeId The change ID (e.g., 1).
 * @param buildId The build ID (e.g., 1).
 * @param credentials The credentials to use for accessing the repository (default is jenkinsCredentialsName).
 * @return The generated version.
 */
String getVersion(String branchName, String shaCommit, String changeId, String buildId, String credentials=jenkinsCredentialsName) {
    String version
    if (changeId && buildId) {
        version = prVersion(changeId, buildId)
    } else {
        version = branchVersion(branchName, shaCommit, credentials)
    }

    echo "Version: ${version}"
    return version
}

/**
 * Gets the version for a branch depending on the branch name and commit information.
 *
 * @param branchName The name of the branch (e.g., PR-*, development, master).
 * @param shaCommit The full SHA commit.
 * @param credentials The credentials to use for accessing the repository (default is jenkinsCredentialsName).
 * @return The generated version for the branch.
 */
String branchVersion(String branchName, String shaCommit, String credentials=jenkinsCredentialsName) {
    String branchSlug = branchName.replaceAll('/', '-')
    String paramForGetLastGitTag = shaCommit ?: branchName
    echo "paramForGetLastGitTag: ${paramForGetLastGitTag}"

    List<String> result = gitHelper.getLastGitTag(paramForGetLastGitTag, credentials)
    String newGitTag = result[0]
    String shortShaOfTopCommit = result[1]
    String version
    if (newGitTag.length() > 0) {
        version = "${newGitTag}"
    } else {
        version = "${branchSlug}-SHA-${shortShaOfTopCommit}"
    }

    return version
}

/**
 * Gets the version for a pull request depending on the change ID and build ID.
 *
 * @param changeId The change ID (e.g., 1).
 * @param buildId The build ID (e.g., 1).
 * @return The generated version for the pull request.
 */
String prVersion(String changeId, String buildId) {
    String version = "PR-${changeId}.b.${buildId}"
    return version
}
