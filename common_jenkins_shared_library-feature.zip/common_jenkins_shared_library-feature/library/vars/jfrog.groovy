import net.sf.json.JSONObject

@groovy.transform.Field
String artifactoryCredentialsName = 'artifactory_api_token'

/**
 * wrapper for methods using Artifactory credentials in their work
 */
Closure useArtifactoryCredentials(Closure body) {
    withCredentials([string(credentialsId: artifactoryCredentialsName, variable: 'API_TOKEN')]) {
        return body.call()
    }
}

/**
 * Uploads provided file to specified artifactory path
 *
 * @param folder String URL path to folder in Jfrog artifactory to upload file
 * @param file String full or relative path to file on local machine
 */
void uploadToArtifactory(String folder, String file) {
    useArtifactoryCredentials {
        sh "curl --fail -H 'X-JFrog-Art-Api:${API_TOKEN}' -X PUT \"$folder\" -T ${file}"
    }
}

/**
 * Download specified file from provided artifactory path to current workdir
 *
 * @param folder String URL path to folder in Jfrog artifactory to upload file
 * @param file String full or relative path to file on local machine
 */
void downloadFromArtifactory(String folder, String file) {
    useArtifactoryCredentials {
        sh "curl --fail -H 'X-JFrog-Art-Api:${API_TOKEN}' -O  \"$folder\"${file}"
    }
}

/**
 * Moves provided artifactory file to speciied artifactory path
 *
 * @param artifactory String Jfrog artifactory URL
 * @param oldFolderName String old folder
 * @param oldFileName String old filename
 * @param newFolderName String new folder
 * @param newFileName String new filename
 */
void moveArtifactoryFile(String artifactory, String oldFolderName, String oldFileName, String newFolderName, String newFileName) {
    useArtifactoryCredentials {
        sh "curl -H 'X-JFrog-Art-Api:${API_TOKEN}' --fail -X POST \"${artifactory}/api/move${oldFolderName}/${oldFileName}?to=${newFolderName}/${newFileName}\""
    }
}

/**
 * Copies provided artifactory file to speciied artifactory path
 *
 * @param artifactory String Jfrog artifactory URL
 * @param oldFolderName String old folder
 * @param oldFileName String old filename
 * @param newFolderName String new folder
 * @param newFileName String new filename
 */
void copyArtifactoryFile(String artifactory, String oldFolderName, String oldFileName, String newFolderName, String newFileName) {
    useArtifactoryCredentials {
        sh "curl -H 'X-JFrog-Art-Api:${API_TOKEN}' --fail -X POST \"${artifactory}/api/copy${oldFolderName}/${oldFileName}?to=${newFolderName}/${newFileName}\""
    }
}

/**
 * Checks if specified file exists in Jfrog artifactory
 *
 * @param artifact String URL of file to verify
 */
boolean existsInArtifactory(String artifact) {
    return useArtifactoryCredentials {
        return !sh(script:"curl -H 'X-JFrog-Art-Api:${API_TOKEN}' --fail --head -X GET \"${artifact}\"", returnStatus: true)
    }
}

/**
 * Returns list of all artifacts for specified path
 *
 * @param artifactory String Jfrog artifactory URL
 * @param folder String path to folder
 */
List getArtifactsList(String artifactory, String folder) {
    List result = []
    useArtifactoryCredentials {
        String responce = sh(
                script:"curl -H 'X-JFrog-Art-Api:${API_TOKEN}' --fail -X GET \"${artifactory}/api/storage/${folder}\"",
                returnStdout: true)
        JSONObject jsonObj = readJSON text: responce.trim()
        if (!jsonObj.children) {
            if (jsonObj.errors) {
                echo "${jsonObj.errors.status}:${jsonObj.errors.message}"
            }
            error("Unable to find any artifact at path: ${folder}")
        }
        jsonObj.children.each { artifact ->
            result.add(artifact.uri)
        }
    }
    return result
}
