/**
 * Formats text for publishing as BitBucket PR comment
 * @param text String to format
 * @return Formatted text
 */
String formatText(String text) {
    return text.replace('\n', '\\n').replace('"', '\\"').replace('\r', '').replace('}', '').replace('\u001b', '').trim()
}
