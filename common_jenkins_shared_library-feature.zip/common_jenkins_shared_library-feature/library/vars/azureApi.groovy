/**
 * Azure service principal credential ID.
 */
@groovy.transform.Field
String azurePrincipal = 'azure_service_principal'

/**
 * Omits the protocol (https://) from the given URL.
 *
 * @param url The URL from which the protocol should be omitted.
 * @return The URL without the protocol.
 */
String ommitProtocol(String url) {
    return url.replaceAll('https://', '')
}

/**
 * Imports an image from a source registry to a target registry.
 *
 * @param sourceRegistry The source registry URL.
 * @param sourceImage The source image name.
 * @param targetRegistry The target registry name.
 * @param targetImage The target image name.
 * @param force If true, forces the import even if the image already exists.
 */
void importImage(String sourceRegistry, String sourceImage, String targetRegistry, String targetImage, Boolean force = false) {
    importImage("${sourceRegistry}/${sourceImage}", targetRegistry, targetImage, force)
}

/**
 * Imports an image from a source registry to a target registry.
 *
 * @param sourceImage The full source image URL.
 * @param targetRegistry The target registry name.
 * @param targetImage The target image name.
 * @param force If true, forces the import even if the image already exists.
 */
void importImage(String sourceImage, String targetRegistry, String targetImage, Boolean force = false) {
    withAzureCli {
        String forceFlag = force ? '--force' : ''
        String sImage = ommitProtocol(sourceImage)
        sh "az acr import ${forceFlag} --name ${targetRegistry} --source ${sImage} --image ${targetImage}"
    }
}

/**
 * Builds a Docker image and pushes it to an Azure Container Registry.
 *
 * @param folder The folder containing the Dockerfile.
 * @param registry The Azure Container Registry name.
 * @param image The image name.
 * @param tag The image tag.
 * @param args Additional build arguments.
 */
void buildImage(String folder, String registry, String image, String tag, Map args = [:]) {
    String buildArgs = args.collect { k, v -> "--build-arg ${k}=${v}" }.join(' ')
    String formattedRegistry = ommitProtocol(registry)
    withAzureCli {
        dir(folder) {
            sh "az acr build --registry ${formattedRegistry} --image ${image}:${tag} ${buildArgs} ."
        }
    }
}

/**
 * Executes a closure with Azure CLI authentication.
 *
 * @param body The closure to execute.
 */
ARM_CLIENT_ID = '316e2fdb-0da7-4bb8-bb3c-db4588e3081a'
ARM_CLIENT_SECRET = 'ejZ8Q~AgTOV1dd.ki25KKKVoNN6~qdl~oelB0cBf'
ARM_TENANT_ID = '93f33571-550f-43cf-b09f-cd331338d086'
Closure withAzureCli(Closure body) {
    withCredentials([azureServicePrincipal('azurePrincipal')]) {
    sh """set +x ; az login --service-principal -u ${ARM_CLIENT_ID} -p ${ARM_CLIENT_SECRET} --tenant ${ARM_TENANT_ID} > /dev/null; set -x;
                  echo 'az login successful'"""
            body.call()
        }
}


return this
