/**
 * Common Jenkins library
 * Methods for working with Bitbucket Server API.
 * Redefine bitBucketCredentialsId in your code to authenticate:
 * bitbucket.bitBucketCredentialsId = 'your_credentials_in_jenkins'
 */

import groovy.text.StreamingTemplateEngine
import net.sf.json.JSONObject

@groovy.transform.Field
String bitBucketCredentialsId = 'ddmtv_service_account'

@groovy.transform.Field
String bitbucketUrl = 'https://github.dxc.com'

/**
 * Sends a comment with provided text to a PR denoted by `prUrl`
 * @param commentText comment text to send
 * @param prUrl url to a PR, e.g.: https://luxproject.luxoft.com/stash/projects/MPC/repos/common_knative_serving/pull-requests/17
 */
void sendBitBucketPRComment(String commentText, String prUrl) {
    String commentsUrl = "${prUrl}/comments" as String
    Map<String,String> data = ['text': commentText]
    writeJSON file: './comment.json', json: data
    useBBCredentials {
        sh """curl --fail -v -HContent-Type:application/json -HAccept:application/json \
            --user '${ACCESS_TOKEN_USERNAME}:${ACCESS_TOKEN_PASSWORD}' \
            --data '@./comment.json' -X POST ${commentsUrl} && \
            rm ./comment.json"""
    }
}

/**
 * Uses provided USERNAME:PASSWORD credential name,
 * Returns closure with binded credentials
 * Assigns username to USERNAME variable, password to PASSWORD variable
 *
 * @param body closure to execute
 * @return Closure with binded credential variables, which calls provided body
 */
Closure useBBCredentials(Closure body) {
    withCredentials([usernamePassword(
            credentialsId: bitBucketCredentialsId,
            usernameVariable: 'ACCESS_TOKEN_USERNAME',
            passwordVariable: 'ACCESS_TOKEN_PASSWORD',
    )
    ]) {
        return body.call()
    }
}

/**
 * Creates pull request via bitbucket api
 *
 * @param project String project name
 * @param repository String repo name
 * @param name Pull request name
 * @param description Pull request description
 * @param sourceBranch From which branch to create Pull request
 * @param targetBranch Pull request target branch
 * @return Map containing fields: Bool successful flag, String PR URL url and String code result description
 */
Map createPr(String project, String repository, String name, String description, String sourceBranch, String targetBranch) {
    Map result = [successful: false, url: '', code: '']
    String apiUrl = "${bitbucketUrl}/rest/api/1.0/projects/${project}/repos/${repository}/pull-requests"
    useBBCredentials {
        String templateBody = libraryResource 'bitbucket/prbody.json'
        Map binding = ['name': name, 'description': description, 'sourceBranch': sourceBranch, 'targetBranch': targetBranch]
        String body = new StreamingTemplateEngine().createTemplate(templateBody).make(binding)
        String response = sh(script:
                """curl --fail -v -u $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD -H \"Content-Type:application/json\" -X POST ${apiUrl} \
                        --data-binary @- << EOF
                        ${body}
                        EOF""",
                returnStdout: true).trim()
        echo response
        if (response.contains('com.atlassian.bitbucket.pull.EmptyPullRequestException')) {
            result.code = 'NoChanges'
        } else if (response.contains('com.atlassian.bitbucket.commit.NoSuchCommitException')) {
            result.code = 'NoSuchBranch'
        } else if (response.contains('com.atlassian.bitbucket.pull.DuplicatePullRequestException')) {
            result.url = (readJSON(text: response)).errors[0].existingPullRequest.links.self[0].href
            result.code = 'Exist'
        } else {
            result.url = (readJSON(text: response)).links.self[0].href
            result.code = 'Created'
            result.successful = true
        }
    }
    return result
}

 // use textUtils.formatText() instead
@Deprecated
String formatText(String text) {
    return text.replace('\n', '\\n').replace('"', '\\"').replace('\r', '').replace('}', '').replace('\u001b', '').trim()
}

/**
 * Retrieves version of pull request
 *
 * @param prLink String link to pull request
 * @return String version of pull request
 */
String pullRequestVersion(String prLink) {
    return useBBCredentials {
        sh(label: 'Get version of pull request',
                script: """curl --fail -H \"Content-Type:application/json\" -H \"Accept:application/json\" \
                        --user $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD \
                        -X GET ${prLink} | jq .version""",
                returnStdout: true).trim()
    }
}

/**
 * Merges specified pull request
 *
 * @param prLink String link to pull request
 */
void mergePullRequest(String prLink) {
    useBBCredentials {
        String version = pullRequestVersion(prLink)
        sh(label: 'Merge pull request',
                script: """curl --fail -H \"Content-Type:application/json\" -H \"Accept:application/json\" \
                        --user $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD \
                        -X POST ${prLink}/merge?version=${version}""")
    }
}

/**
 * Merges specified pull request and deletes merged branch
 *
 * @param prLink String link to pull request
 * @param branch String name of merging branch
 */
void mergePullRequest(String prLink, String branch) {
    useBBCredentials {
        String version = pullRequestVersion(prLink)
        sh(label: 'Merge pull request before deletion',
                script: """curl --fail -H "Content-Type:application/json" -H "Accept:application/json" \
                        --user ${ACCESS_TOKEN_USERNAME}:${ACCESS_TOKEN_PASSWORD} \
                        -X POST ${prLink}/merge?version=${version}""")
        String[] parts = prLink.split('/')
        String project = parts[parts.length - 5]
        String repo = parts[parts.length - 3]
        sh(label: 'Delete branch after merge',
            script: """curl -H "Content-Type:application/json" -H "Accept:application/json" \
                        --user ${ACCESS_TOKEN_USERNAME}:${ACCESS_TOKEN_PASSWORD} \
                        --data '{"name": "${branch}" ,"dryRun": false}' \
                        -X DELETE ${bitbucketUrl}/rest/branch-utils/1.0/projects/${project}/repos/${repo}/branches""")
    }
}

/**
 * Deletes specified branch in provided bitbucket project repo
 * Note: Ensure repository allow to delete specific branch types ex. release used repository settings freak control
 *
 * @param project String project name
 * @param repository String repo name
 * @param branch String branch name
 */
void deleteBranch(String project, String repository, String branch) {
    useBBCredentials {
        sh(label: 'Delete branch',
                script: """curl --fail -H \"Content-Type:application/json\" -H \"Accept:application/json\" \
                        --user $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD \
                        --data '{\"name\": \"${branch}\" ,\"dryRun\": false}' \
                        -X DELETE ${bitbucketUrl}/rest/branch-utils/1.0/projects/${project}/repos/${repository}/branches""")
    }
}

/**
 * Determines whether branch exists in repository
 * @param project String project slug
 * @param repos String repository name
 * @param branchName String branch name
 * @return Boolean true if exists, false otherwise
 */
Boolean isBranchExists(String project, String repos, String branchName) {
    useBBCredentials {
        sh "curl --fail --user ${ACCESS_TOKEN_USERNAME}:${ACCESS_TOKEN_PASSWORD} -H 'Accept: application/json' -X GET ${bitbucketUrl}" +
                "/rest/api/1.0/projects/${project}/repos/${repos}/branches?filterText=${branchName} --output branchesCurlOutput.json"
        JSONObject res = readJSON file: 'branchesCurlOutput.json'
        return res.values.find { s -> s.id == "refs/heads/${branchName}" } != null
    }
}

/**
 * Retrieves a list of tags from specified repository
 * @param project String project slug
 * @param repos String repository name
 * @param orderBy String order for sort tags, either 'MODIFICATION', to sort from latest to oldest tags, or 'ALPHABETICAL'
 * @return List<String> a list of retrieved tags
 */
List<String> retrieveTags(String project, String repos, String orderBy) {
    useBBCredentials {
        String tmpFileName = 'tmp_tags.json'
        sh("""curl --fail --user ${ACCESS_TOKEN_USERNAME}:${ACCESS_TOKEN_PASSWORD} -H 'Accept: application/json' -X GET \
                '${bitbucketUrl}/rest/api/1.0/projects/${project}/repos/${repos}/tags?orderBy=${orderBy}' \
                -o ${tmpFileName}""")
        JSONObject tags = readJSON file: tmpFileName
        return tags.values*.displayId as List<String>
    } as List<String>
}

/**
 * Upload attachment to BB
 * @param project String project slug
 * @param repos String repository name
 * @param attachment name of the file to upload
 * @return List<String> a link to the uploaded attachment
 */
String uploadAttachment(String project, String repos, String attachment) {
    return useBBCredentials {
        sh(label: 'Get plan attachment url',
           script: """curl -u ${ACCESS_TOKEN_USERNAME}:${ACCESS_TOKEN_PASSWORD} \
                           -H "Content-Type: multipart/form-data" \
                           -F "files=@${attachment}" \
                           -X POST ${bitbucketUrl}/projects/${project}/repos/${repos}/attachments | jq -r .attachments[0].links.attachment.href""",
           returnStdout: true).trim()
    }
}

/**
 * Checks approvals on PR, returns true if there is at least one approval
 */
Boolean isPullRequestApproved(String project, String repos, String changeId) {
    useBBCredentials {
        // Count number of approvals on the PR (need at least one to consider PR approved)
        String response = sh(
            label: 'Check if pull request is approved',
            script: """curl -v --fail -u $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD \
                        ${bitbucketUrl}/rest/api/1.0/projects/${project}/repos/${repos}/pull-requests/${changeId}
            """,
            returnStdout: true
        ).trim()
        echo "Response:\n ${response}"
        JSONObject responseJson = readJSON text: response
        return responseJson.reviewers.findAll { r -> r.approved == true }.size() > 0
    }
}

/**
 * Approves pull request
 */
void approvePullRequest(String project, String repos, String changeId) {
    useBBCredentials {
        String url = "${bitbucketUrl}/rest/api/1.0/projects/${project}/repos/${repos}/pull-requests/${changeId}/participants/${ACCESS_TOKEN_USERNAME}"
        sh(label: 'Approve PR',
           script: """curl -v --fail -H "Content-Type:application/json" -H "Accept:application/json" \
                        --user ${ACCESS_TOKEN_USERNAME}:${ACCESS_TOKEN_PASSWORD} \
                        --data '{"user": {"name": "${ACCESS_TOKEN_USERNAME}"}, "approved": true, "status": "APPROVED"}' \
                        -X PUT "${url}" """)
    }
}

/**
 * Returns the status of the specified Bitbucket pull request.
 */
String getPullRequestStatus(String project, String repos, String changeId) {
    useBBCredentials {
        String response = sh(
            label: 'Get pull request status',
            script: """curl -v --fail -u ${ACCESS_TOKEN_USERNAME}:${ACCESS_TOKEN_PASSWORD} \
                        ${bitbucketUrl}/rest/api/1.0/projects/${project}/repos/${repos}/pull-requests/${changeId}
            """,
            returnStdout: true
        ).trim()
        JSONObject responseJson = readJSON text: response
        status = responseJson.state

        if (status == 'OPEN') {
            for (rev in responseJson.reviewers) {
                if (rev.status != 'APPROVED') {
                    status = rev.status
                    break
                }
                else {
                    status = rev.status
                }
            }
        }
        return status
    }
}

/**
 * Retrieves the owner of the specified Bitbucket pull request.
 *
 * @param project The Bitbucket project key.
 * @param repos The repository slug.
 * @param changeId The pull request ID.
 * @return The username of the pull request owner.
 */
String getPullRequestOwner(String project, String repos, String changeId) {
    useBBCredentials {
        String response = sh(
            label: 'Get pull request owner',
            script: """curl -v --fail -u ${ACCESS_TOKEN_USERNAME}:${ACCESS_TOKEN_PASSWORD} \
                        ${bitbucketUrl}/rest/api/1.0/projects/${project}/repos/${repos}/pull-requests/${changeId}
            """,
            returnStdout: true
        ).trim()
        JSONObject responseJson = readJSON text: response
        String owner = responseJson.author.user.name
        return owner
    }
}

/**
 * Retrieves comments from a specific Bitbucket pull request.
 *
 * @param project The Bitbucket project key.
 * @param repos The repository slug.
 * @param prNumber The pull request number.
 * @return A list of comments from the pull request.
 * @throws Exception if no comments are found for the specified pull request.
 */
List<String> getCommentsFromPR(String project, String repos, String prNumber) {
    List<String> comments = []
    useBBCredentials {
        String response = sh(
            label: 'Get pull request comments',
            script: """curl -v --fail -u ${ACCESS_TOKEN_USERNAME}:${ACCESS_TOKEN_PASSWORD} \
                        ${bitbucketUrl}/rest/api/1.0/projects/${project}/repos/${repos}/pull-requests/${prNumber}/activities""",
            returnStdout: true
        ).trim()

        JSONObject jsonResponse = readJSON text: response

        // Extract comments
        comments = jsonResponse.values.collect { activity ->
            if (activity.action == 'COMMENTED') {
                return activity.comment.text
            }
        }.findAll { text -> text != null }
    }
    return comments
}

/**
 * Checks if a specific comment exists in a Bitbucket pull request.
 *
 * @param project The Bitbucket project key.
 * @param repos The repository slug.
 * @param prNumber The pull request number.
 * @param commentText The text of the comment to check for.
 * @return True if the comment exists, false otherwise.
 */
boolean checkCommentExists(String project, String repos, String prNumber, String commentText) {
    List<String> comments = getCommentsFromPR(project, repos, prNumber)
    return comments.contains(commentText)
}

/**
 * Updates the description of a Bitbucket pull request.
 *
 * @param project The Bitbucket project key.
 * @param repos The repository slug.
 * @param prNumber The pull request number.
 * @param newDescription The new description for the pull request.
 * @param replaceCurrent If true, replace the entire description with the new description. If false, add the new information after the defined separator.
 * @param separator The separator to define where the new information should be added.
 */
void updatePRDescription(String project, String repos, String prNumber, String newDescription, boolean replaceCurrent,
                         String separator = '----- AUTOGENERATED TEXT: -----') {
    useBBCredentials {
        String prUrl = "${bitbucketUrl}/rest/api/1.0/projects/${project}/repos/${repos}/pull-requests/${prNumber}"
        // Fetch the current pull request description
        String response = sh(script: """curl -v --fail -u ${ACCESS_TOKEN_USERNAME}:${ACCESS_TOKEN_PASSWORD} \
                                                ${prUrl}""",
                                    returnStdout: true).trim()
        JSONObject jsonResponse = readJSON text: response
        String description = newDescription
        // Update the pull request description
        if (!replaceCurrent) {
            description = jsonResponse.description ?: ''
            int separatorPosition = description.indexOf(separator)
            if (separatorPosition > 0) {
                description = description.substring(0, separatorPosition)
            }
            description = description.trim()
            description = "${description}\n\n${separator}\n\n${newDescription}"
        }
        Map payload = [:]
        payload = [description: description, version: jsonResponse.version]
        writeJSON file: './description.json', json: payload
        sh(script: """curl -v --fail -X PUT -u ${ACCESS_TOKEN_USERNAME}:${ACCESS_TOKEN_PASSWORD} \
                            -H "Content-Type: application/json" \
                            --data '@./description.json' \
                            ${prUrl}""")
    }
}
