/**
 * Common Jenkins library
 */
import net.sf.json.JSONObject
import groovy.transform.Field

@Field String jiraCredentialsId = 'lms_git_access'
@Field String jiraUrl = 'luxproject.luxoft.com/jira'
@Field String apiVersion = 'latest'
@Field final String ERROR_KEY = 'errorMessages'

Closure useJiraCredentials(Closure body) {
    withCredentials([usernamePassword(
            credentialsId: jiraCredentialsId,
            usernameVariable: 'ACCESS_TOKEN_USERNAME',
            passwordVariable: 'ACCESS_TOKEN_PASSWORD',
    )
    ]) {
        return body.call()
    }
}

Boolean doesIssueExist(String issueId) {
    useJiraCredentials {
        String statusCode = sh(script: """curl -s -o /dev/null -w "%{http_code}" -u $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD \
            https://$jiraUrl/rest/api/$apiVersion/issue/$issueId""", returnStdout: true).trim()
        return statusCode == '200'
    }
}

void getJiraIssueDetails(String issueId, String jsonPath) {
    useJiraCredentials {
        sh """curl --fail -u $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD -H "Content-Type: application/json" \
            https://$jiraUrl/rest/api/$apiVersion/issue/$issueId > ${jsonPath}"""
    }
}

String getJiraIssueSummary(String issueId, String jsonPath = 'jira_issue_details.json') {
    getJiraIssueDetails(issueId, jsonPath)
    JSONObject jsonMap = readJSON file: jsonPath
    String summary = jsonMap.fields.summary
    summary = summary?.trim()
    return summary
}

void createJiraRelease(String projectKey, String versionValue) {
    useJiraCredentials {
        sh """curl -D- -u $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD -X POST -H "Content-Type: application/json" \
            --data '{
            "archived": false,
            "description": "Automatically created release",
            "name": "${versionValue}",
            "project": "${projectKey}",
            "released": false
            }' https://$jiraUrl/rest/api/$apiVersion/version"""
    }
}

void addVersionToIssue(String issueId, String versionValue) {
    useJiraCredentials {
        sh """curl -D- -u $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD -X PUT \
            --data '{"update": {"fixVersions": [{"add": {"name": "${versionValue}"}}]}}' \
            -H 'Content-Type: application/json' \
            https://$jiraUrl/rest/api/$apiVersion/issue/$issueId"""
    }
}

void pushCommentToJira(String issueId, String commentMessage) {
    formattedCommentMessage = jiraCommentFormatText(commentMessage)
    useJiraCredentials {
        sh """curl -D- -u $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD -X POST \
            -H 'Content-Type: application/json' \
            --data '{"body": "${formattedCommentMessage}"}' \
            https://${jiraUrl}/rest/api/${apiVersion}/issue/${issueId}/comment
        """
    }
}

String jiraCommentFormatText(String text) {
    // don't change places of replace
    /* groovylint-disable-next-line DuplicateStringLiteral */
    return text.replace('\\', '').replace('\n', '\\n').replace('"', '\\"').replace("'", "'\\'\'").replace('\r', '').replace('\u001b', '').trim()
}

// use textUtils.formatText() instead
@Deprecated
String formatText(String text) {
    /* groovylint-disable-next-line DuplicateStringLiteral */
    return text.replace('\n', '\\n').replace('"', '\\"').replace('\r', '').replace('}', '').replace('\u001b', '').trim()
}

