
import groovy.transform.Field

@Field
String jenkinsCredentialsName = 'knative_cred'

@Field
String remoteBaseUrl = 'https://github.dxc.com/MetaVance-Base'

/**
 * Returns list of changed files in PR
 *
 * @param target String target branch name
 * @return List of changed files
 */
List<String> getPrChangedFiles(String target) {
    return sh(returnStdout: true, script: "git diff --name-only origin/${target}").split('\n')
}

/**
 * Returns GitTag and shortShaOfTopCommit
 *
 * @param branchName String name of the branch/tag/sha commit from which the checkout will be performed
 */

List<String> getLastGitTag(String branchName, String credentials=jenkinsCredentialsName) {
    configureGitLocalCreds(credentials)
    sh(label: 'Pulling latest tags',
        script: """\
            git pull origin "$branchName"
            git fetch --tags
        """
    )
    String shortShaOfTopCommit = sh(script: 'git rev-parse --short HEAD', returnStdout: true).trim()
    String lastGitTag = sh(script: """\
                                    git for-each-ref 'refs/tags/?*.?*.?*' \
                                        --points-at ${shortShaOfTopCommit} \
                                        --format='%(refname:short)' \
                                        --sort='-version:refname' \
                                        --count=1 | cut -d '/' -f 2
                                    """, returnStdout: true).trim()
    echo "shortShaOfTopCommit: ${shortShaOfTopCommit}"
    echo "lastGitTag: ${lastGitTag}"
    return [lastGitTag, shortShaOfTopCommit]
}

String getVersionFromGitRepo(String branchName, String credentials=jenkinsCredentialsName) {
    List<String> result = getLastGitTag(branchName, credentials)
    String lastGitTag = result[0]
    String shortShaOfTopCommit = result[1]
    return lastGitTag ?: shortShaOfTopCommit
}

/**
 * Performs git checkout with detached HEAD
 *
 * @param repo String name of the repository from which the checkout will be performed
 * @param branch String name of the branch from which the checkout will be performed
 * @param relativeTargetDir String path of the relative target dir
 * @param credentials Credentials to use for the checkout default=jenkinsCredentialsName can be changed separately
 */
void checkout(String repo='',
              String branch='feature',
              String relativeTargetDir='./',
              String credentials=jenkinsCredentialsName) {
    echo "Checkout from ${repo} with branch ${branch} to ${relativeTargetDir}"
    checkout scm: [$class: 'GitSCM', userRemoteConfigs: [
            [url: repo, credentialsId: credentials]
        ],
        extensions: [
            [$class: 'RelativeTargetDirectory', relativeTargetDir: relativeTargetDir]
        ],
        branches: [[name: branch]]], poll: false
}

/**
 * Performs git clone
 *
 * @param repo String name of the repository from which the checkout will be performed
 * @param branch String name of the branch from which the checkout will be performed
 * @param relativeTargetDir String path of the relative target dir
 */
void checkoutWithGit(String repo, String branch='development', String relativeTargetDir='./', String jenkinsCredentialsName) {
    withCredentials([usernamePassword(credentialsId: jenkinsCredentialsName,
                                    passwordVariable: 'BB_PASSWORD',
                                    usernameVariable: 'BB_USER')]) {
        sh(label:"Checkout ${repo} into ${relativeTargetDir}",
            script: """
                [ -d "${relativeTargetDir}" ] && rm -r "${relativeTargetDir}"
                git clone https://${BB_USER}:${BB_PASSWORD}@${repo} -b ${branch} ${relativeTargetDir}
                cd ${relativeTargetDir} && git fetch && cd -
            """
        )
    }
}

/**
 * Performs commiting changes and sending to remote repo
 *
 * @param repoFolder String path of the relative target dir
 * @param commitMessage String Commit message for changes
 */
void commitToGit(String repoFolder='./', String commitMessage='') {
    sh(label:"Commit and push to BB. Source folder: ${repoFolder}",
        script: """
            cd ${repoFolder}
            git add .
            git status
            if ! git diff-index --quiet HEAD;
            then
                git commit -m "${commitMessage}"
                git push
            else
                echo "No changes"
            fi
        """
    )
}

/**
 * Returns list of modified and untracked files
 *
 * @param repoFolder String path of the relative target dir
 */
List<String> getChangedAndUntrackedFiles(String repoFolder='./') {
    return sh(
        script: """cd ${repoFolder}
        git ls-files --modified && git ls-files --other""",
        returnStdout: true
    /* groovylint-disable-next-line DuplicateStringLiteral */
    ).split('\n').findAll { x -> x != '' }
}

/**
 * Create new branch and push it to git
 *
 * @param branchName String name of the branch from which the push will be performed
 */
void pushBranch(String branchName, String credentials=jenkinsCredentialsName) {
    configureGitLocalCreds(credentials)
    sh(label: 'Pushing PR branch',
        script: """\
            git checkout -b ${branchName}
            git push origin ${branchName}
        """)
}

/**
 * Rewrites https git url to url with credentials
 * This method can be utilized to allow third-party tools that perform e.g. `git clone`
 * to access remote repository without access issues.
 * (for example, terraform performs `git clone` when downlonads modules referenced as git repositories)
 *
 * @param credentialsUsername String Username used to authenticate to remote repository
 * @param credentialsPassword String Password used to authenticate to remote repository
 */
void configureGitCredentials(String credentialsUsername, String credentialsPassword) {
    sh(
        label: 'Configuring git credentials',
        script: """git config --global url."https://${credentialsUsername}:${credentialsPassword}@${remoteBaseUrl}".insteadOf https://${remoteBaseUrl}"""
    )
}

void configureGitLocalCreds(String credentials=jenkinsCredentialsName) {
    withCredentials([usernamePassword(credentialsId: credentials,
                        passwordVariable: 'ACCESS_TOKEN_PASSWORD',
                        usernameVariable: 'ACCESS_TOKEN_USERNAME')]) {
        sh(label: 'Configuring git local credentials',
            script: """\
                git config --local credential.username "$ACCESS_TOKEN_USERNAME"
                git config --local credential.helper '!f() { echo password="$ACCESS_TOKEN_PASSWORD"; }; f'
                git config --local user.email "s.sankarshna@dxc.com"
                git config --local user.name "ssankarshna"
        """)
    }
}
