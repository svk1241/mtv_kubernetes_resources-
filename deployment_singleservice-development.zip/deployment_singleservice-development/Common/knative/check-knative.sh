#!/bin/bash
is_error=0

check_resource_exist(){
    kubectl get $1 $2 $3 1>&- 2>&-
    if [ $? -eq 0 ]
    then
        echo " Success: $2 created."
    else
        echo " Failure: $2 not found."
        is_error=1
    fi
}

check_deployment_status(){
    ready=`kubectl get deployment $1 $2 -o=jsonpath='{.status.readyReplicas}'`
    total=`kubectl get deployment $1 $2 -o=jsonpath='{.status.replicas}'`
    if [ "$ready" -eq "$total" ]
    then
        echo " Success: $1: Ready: $ready; Expected: $total"
    else
        echo " Failure: $1: Ready: $ready; Expected: $total"
        is_error=1
    fi
}


##CRD
crds=(
    "authorizationpolicies.security.istio.io"
    "destinationrules.networking.istio.io"
    "envoyfilters.networking.istio.io"
    "gateways.networking.istio.io"
    "istiooperators.install.istio.io"
    "peerauthentications.security.istio.io"
    "requestauthentications.security.istio.io"
    "serviceentries.networking.istio.io"
    "sidecars.networking.istio.io"
    "telemetries.telemetry.istio.io"
    "virtualservices.networking.istio.io"
    "workloadentries.networking.istio.io"
    "workloadgroups.networking.istio.io"
    "certificates.networking.internal.knative.dev"
    "configurations.serving.knative.dev"
    "domainmappings.serving.knative.dev"
    "ingresses.networking.internal.knative.dev"
    "metrics.autoscaling.internal.knative.dev"
    "podautoscalers.autoscaling.internal.knative.dev"
    "revisions.serving.knative.dev"
    "routes.serving.knative.dev"
    "serverlessservices.networking.internal.knative.dev"    
    "services.serving.knative.dev"
    "images.caching.internal.knative.dev"
    "clusterdomainclaims.networking.internal.knative.dev"
)


echo -e "\nCRD existence check:"
for ITEM in ${crds[@]}
do 
    check_resource_exist "crd" "$ITEM"
done


##Namespaces
namespaces=(
    "istio-system"
    "knative-serving"
)
echo -e "\nNamespace existence check:"
for ITEM in ${namespaces[@]}
do 
    check_resource_exist "ns" "$ITEM"
done



##MutatingWebhookConfiguration
mwcs=(
    "webhook.istio.networking.internal.knative.dev"
    "webhook.serving.knative.dev"
    "webhook.domainmapping.serving.knative.dev"
    "istio-sidecar-injector"
)

echo -e "\nMutatingWebhookConfiguration existence check:"
for ITEM in ${mwcs[@]}
do 
    check_resource_exist "MutatingWebhookConfiguration" $ITEM
done

##ValidatingWebhookConfiguration
vwcs=(
    "config.webhook.istio.networking.internal.knative.dev"
    "config.webhook.serving.knative.dev"
    "validation.webhook.domainmapping.serving.knative.dev"
    "validation.webhook.serving.knative.dev"
    "istio-validator-istio-system"
)

echo -e "\nValidatingWebhookConfiguration existence check:"
for ITEM in ${vwcs[@]}
do 
    check_resource_exist "ValidatingWebhookConfiguration" $ITEM
done


##Secrets
secrets=(
    "domainmapping-webhook-certs"
    "webhook-certs"
    "net-istio-webhook-certs"
)

echo -e "\nSecrets existence check:"
for ITEM in ${secrets[@]}
do 
    check_resource_exist "secret" "$ITEM" "-n knative-serving"
done


##PeerAuthentication
pas=(
    "net-istio-webhook"
    "domainmapping-webhook"
    "webhook"
)

echo -e "\nPeerAuthentication existence check:"
for ITEM in ${pas[@]}
do 
    check_resource_exist "PeerAuthentication" "$ITEM" "-n knative-serving"
done

##ClusterRole
cluster_roles=(
    "knative-serving-aggregated-addressable-resolver"
    "knative-serving-addressable-resolver"
    "knative-serving-namespaced-admin"
    "knative-serving-namespaced-edit"
    "knative-serving-namespaced-view"
    "knative-serving-core"
    "knative-serving-podspecable-binding"
    "knative-serving-admin"
)

echo -e "\nClusterRole existence check:"
for ITEM in ${cluster_roles[@]}
do 
    check_resource_exist "ClusterRole" "$ITEM"
done

##ConfigMap
config_maps_istio=(
    "istio"
    "istio-sidecar-injector"
)

config_maps_knative=(
    "config-istio"
    "config-autoscaler"
    "config-defaults"
    "config-deployment"
    "config-domain"
    "config-features"
    "config-gc"
    "config-leader-election"
    "config-logging"
    "config-network"
    "config-observability"
    "config-tracing"
)

echo -e "\nIstio ConfigMap existence check:"
for ITEM in ${config_maps_istio[@]}
do 
    check_resource_exist "ConfigMap" "$ITEM" "-n istio-system"
done

echo -e "\nKnative ConfigMap existence  check:"
for ITEM in ${config_maps_knative[@]}
do 
    check_resource_exist "ConfigMap" "$ITEM" "-n knative-serving"
done

##HorizontalPodAutoscaler
hpas=(
    "activator"
    "webhook"
)

echo -e "\nHorizontalPodAutoscaler existence check:"
check_resource_exist "HorizontalPodAutoscaler" "istiod" "-n istio-system"
for ITEM in ${hpas[@]}
do 
    check_resource_exist "HorizontalPodAutoscaler" "$ITEM" "-n knative-serving"
done

##Service
services_istio=(
    "istio-ingressgateway"
    "istiod"
    "knative-local-gateway"
)
services_knative=(
    "net-istio-webhook"
    "activator-service"
    "autoscaler"
    "controller"
    "domainmapping-webhook"
    "webhook"
)

echo -e "\nService existence check:"
for ITEM in ${services_istio[@]}
do 
    check_resource_exist "Service" "$ITEM" "-n istio-system"
done
for ITEM in ${services_knative[@]}
do 
    check_resource_exist "Service" "$ITEM" "-n knative-serving"
done

##PodDisruptionBudget
budgets_istio=(
    "istio-ingressgateway"
    "istiod"
)
budgets_knative=(
    "activator-pdb"
    "webhook-pdb"
)
echo -e "\nPodDisruptionBudget existence check:"
for ITEM in ${budgets_istio[@]}
do 
    check_resource_exist "PodDisruptionBudget" "$ITEM" "-n istio-system"
done
for ITEM in ${budgets_knative[@]}
do 
    check_resource_exist "PodDisruptionBudget" "$ITEM" "-n knative-serving"
done

##EnvoyFilter
envoyfilters=(
	"stats-filter-1.11"
	"stats-filter-1.12"
	"stats-filter-1.13"
	"tcp-stats-filter-1.11"
	"tcp-stats-filter-1.12"
	"tcp-stats-filter-1.13"
)
echo -e "\nEnvoyFilter existence check:"
for ITEM in ${envoyfilters[@]}
do 
    check_resource_exist "EnvoyFilter" "$ITEM" "-n istio-system"
done

##Gateway
gateways=(
    "knative-ingress-gateway"
    "knative-local-gateway"
)
echo -e "\nGateway existence check:"
for ITEM in ${gateways[@]}
do 
    check_resource_exist "Gateway" "$ITEM" "-n knative-serving"
done

##Image
images=(
    "queue-proxy"
)
echo -e "\nImage existence check:"
for ITEM in ${images[@]}
do 
    check_resource_exist "Image" "$ITEM" "-n knative-serving"
done

##Deployment
deployments_knative=(
    "net-istio-controller"
    "net-istio-webhook"
    "activator"
    "autoscaler"
    "controller"
    "domain-mapping"
    "domainmapping-webhook"
    "webhook"
)
deployments_istio=(
    "istio-ingressgateway"
    "istiod"
)
echo -e "\nDeployment status check:"
for ITEM in ${deployments_istio[@]}
do 
    check_deployment_status "$ITEM" "-n istio-system"
done
for ITEM in ${deployments_knative[@]}
do 
    check_deployment_status "$ITEM" "-n knative-serving"
done


if [ $is_error -eq 0 ]
then
    echo -e "\nStatus check success. All resources were created and ready"
else
    echo -e "\nStatus check Failed. Some resources are not created or not ready."
fi

exit $is_error






