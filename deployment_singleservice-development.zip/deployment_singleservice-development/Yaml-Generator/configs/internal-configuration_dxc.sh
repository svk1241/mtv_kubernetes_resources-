#!/bin/bash

# Main cluster environmental variables
export ingress_host=onlineregression.mtv.com.ddmtv.private.ddmtv.private
export knative_domain=knative.mtv.com
export https_wrapper_image=acreastuspublicdd.azurecr.io/mtv-backend-https-wrapper-deltadental:v.44.10
export transaction_enabler_image=acreastuspublicdd.azurecr.io/mtv-transaction-enabler-deltadental:v.44.10
export batch_image=acreastuspublicdd.azurecr.io/mtv-backend-batch-deltadental:v.44.10
export infrastructure_image=acreastuspublicdd.azurecr.io/mtv-backend-infrastructure:v.44.10
export batch_claim_name=batch-storager
export batch_temp_claim_name=batch-tempstorager
export batch_namespace=batchregression
#export batch_node_selector="Type: batch"
#export infrastructure_namespace=${batch_namespace}
#export infrastructure_ingress_host=...
export infrastructure_node_selector="kubernetes.azure.com/mode: system"
export online_namespace=onlineregression
#export online_node_selector="Type: regression"
export environment_label=Sprint


# Request and limits settings

# Online

export https_wrapper_cpu_request="50m"
export https_wrapper_cpu_limit="100m"
export https_wrapper_memory_request="50Mi"
export https_wrapper_memory_limit="100Mi"

export transaction_enabler_cpu_request="100m"
export transaction_enabler_cpu_limit="300m"
export transaction_enabler_memory_request="200Mi"
export transaction_enabler_memory_limit="500Mi"

# Batch

export batch_cpu_request="2"
export batch_cpu_limit="2.5"
export batch_memory_request="2Gi"
export batch_memory_limit="2.5Gi"

# Optional variable
# export online_toleration=...
# export batch_toleration=...

# Optional parameters for MTVRules
# export mtvrules_namespace=...
# export mtvrules_image=...
# export mtvrules_replicas=...
