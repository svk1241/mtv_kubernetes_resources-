#!/bin/bash

if [[ $# < 1 ]];then
  echo "Invalid number of arguments!"
  echo "Usage: ./autogenerator.sh [output yaml folder path]"
  echo
  exit 1
fi

# Setup
BASE_PATH="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
RESULT_PATH=$1

# Clean-up
rm -r $RESULT_PATH > /dev/null 2>&1

BATCH_PATH=${RESULT_PATH}/batch
ONLINE_PATH=${RESULT_PATH}/online
INFRASTRUCTURE_PATH=${RESULT_PATH}/infrastructure
NAMESPACES_PATH=${RESULT_PATH}/namespaces
MTVRULES_PATH=${RESULT_PATH}/mtvrules
AEENV_PATH=${BASE_PATH}/configs/aeenv.tux
CONFIGS_PATH=${BASE_PATH}/configs
TEMPLATES_PATH=${BASE_PATH}/templates

#export namespace=${2:-default}
source $CONFIGS_PATH/internal-configuration.sh

mkdir -p $BATCH_PATH > /dev/null 2>&1
mkdir -p $ONLINE_PATH > /dev/null 2>&1
mkdir -p $INFRASTRUCTURE_PATH > /dev/null 2>&1
mkdir -p $NAMESPACES_PATH > /dev/null 2>&1

if [[ ! -d $RESULT_PATH ]]; then
  echo "can't create output folder!"
  exit 1
fi

# Generation of KNative services and VirtualService
groups=$(cat $AEENV_PATH | cut -d ' ' -f3 | uniq)

for group in $groups; do
  transactions=$(cat $AEENV_PATH | grep " $group " |cut -d ' ' -f2)

  if cat $CONFIGS_PATH/service.conf | grep -q "$group" ; then
    min_scale=$(cat $CONFIGS_PATH/service.conf | grep "$group" | cut -d ' ' -f2 | cut -d '=' -f2)
    max_scale=$(cat $CONFIGS_PATH/service.conf | grep "$group" | cut -d ' ' -f3 | cut -d '=' -f2)
  else
# Set default values if group is not presented in config file
    min_scale=$(cat $CONFIGS_PATH/service.conf | grep "DEFAULT_SCALING" | cut -d ' ' -f2 | cut -d '=' -f2)
    max_scale=$(cat $CONFIGS_PATH/service.conf | grep "DEFAULT_SCALING" | cut -d ' ' -f3 | cut -d '=' -f2)
  fi

 # to lower-case
  group="${group,,}"

  export knservice=${group}
  export min_scale
  export max_scale
  export toleration=$online_toleration
  export namespace=$online_namespace

  envsubst < ${TEMPLATES_PATH}/vs-header-tmpl.yaml > ${ONLINE_PATH}/${group}-routing.yaml

  for transaction in ${transactions}; do
    export transaction
    envsubst < ${TEMPLATES_PATH}/vs-body-tmpl.yaml >> ${ONLINE_PATH}/${group}-routing.yaml
  done

  envsubst < ${TEMPLATES_PATH}/vs-footer-tmpl.yaml >> ${ONLINE_PATH}/${group}-routing.yaml

envsubst < ${TEMPLATES_PATH}/toleration-tmpl.yaml >> ${ONLINE_PATH}/toleration.yaml
envsubst < ${TEMPLATES_PATH}/kn-service-tmpl.yaml > ${ONLINE_PATH}/${group}-service.yaml
envsubst < ${TEMPLATES_PATH}/ns-tmpl.yaml > ${NAMESPACES_PATH}/online-ns.yaml
envsubst < ${TEMPLATES_PATH}/online-conf.yaml > ${ONLINE_PATH}/online-conf.yaml
  
  if [[ -f ${ONLINE_PATH}/toleration.yaml && -n $online_toleration ]]; then
    # Insert extra two spaces to match the manifest format
    sed -i -e "s/^/  /g" ${ONLINE_PATH}/toleration.yaml
    sed -i -e "/<toleration-placeholder>/r ${ONLINE_PATH}/toleration.yaml" ${ONLINE_PATH}/${group}-service.yaml
  fi
  
  unset toleration
  unset namespace
  
  rm -f ${ONLINE_PATH}/toleration.yaml
  
  sed -i -e "/<toleration-placeholder>/d" ${ONLINE_PATH}/${group}-service.yaml
done

# generate batch container

batch_disk_name=${batch_disk_uri##*/}
batch_temp_disk_name=${batch_temp_disk_uri##*/}

export batch_disk_name
export batch_temp_disk_name
export toleration=$batch_toleration
export namespace=$batch_namespace

envsubst < ${TEMPLATES_PATH}/batch-tmpl.yaml > ${BATCH_PATH}/batch.yaml
envsubst < ${TEMPLATES_PATH}/batch-conf.yaml > ${BATCH_PATH}/batch-conf.yaml
envsubst < ${TEMPLATES_PATH}/toleration-tmpl.yaml >> ${BATCH_PATH}/toleration.yaml
envsubst < ${TEMPLATES_PATH}/ns-tmpl.yaml > ${NAMESPACES_PATH}/batch-ns.yaml

if [[ -f ${BATCH_PATH}/toleration.yaml && -n $batch_toleration ]]; then
    sed -i -e "/<toleration-placeholder>/r ${BATCH_PATH}/toleration.yaml" ${BATCH_PATH}/batch.yaml
fi
rm -f ${BATCH_PATH}/toleration.yaml
sed -i -e "/<toleration-placeholder>/d" ${BATCH_PATH}/batch.yaml

unset namespace

export namespace=$infrastructure_namespace

envsubst < ${TEMPLATES_PATH}/infrastructure-tmpl.yaml > ${INFRASTRUCTURE_PATH}/infrastructure.yaml
envsubst < ${TEMPLATES_PATH}/toleration-tmpl.yaml >> ${INFRASTRUCTURE_PATH}/toleration.yaml
envsubst < ${TEMPLATES_PATH}/ns-tmpl.yaml > ${NAMESPACES_PATH}/infrastructure-ns.yaml

if [[ -f ${INFRASTRUCTURE_PATH}/toleration.yaml && -n $batch_toleration ]]; then
    sed -i -e "/<toleration-placeholder>/r ${INFRASTRUCTURE_PATH}/toleration.yaml" ${INFRASTRUCTURE_PATH}/infrastructure.yaml
fi
rm -f ${INFRASTRUCTURE_PATH}/toleration.yaml
sed -i -e "/<toleration-placeholder>/d" ${INFRASTRUCTURE_PATH}/infrastructure.yaml

# Create sources for MTVRules if variable is set
if [[ -n $mtvrules_namespace ]]; then
    mkdir -p $MTVRULES_PATH > /dev/null 2>&1
    envsubst < ${TEMPLATES_PATH}/vs-mtvrules-tmpl.yaml > ${MTVRULES_PATH}/vs-mtvrules.yaml
    envsubst < ${TEMPLATES_PATH}/mtvrules-tmpl.yaml > ${MTVRULES_PATH}/mtvrules.yaml
fi
exit 0
