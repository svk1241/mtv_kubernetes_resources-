# Changelog

## 1.6.0

### Tasks


* [MPC-555] - Optionally make a release name with prefix, to distinguish between services/components ***(in status Open)***
### Defects



## 1.5.1

### Tasks


### Defects


* [MPC-454] - Incorrect version in artifacts for build release ***(in status Open)***

## 1.5.0

### Tasks

* [MPC-447] - check if last commit in branch (in status In Progress)

### Defects



## 1.4.0

### Tasks

* [SBRTALK-69] - reorganize jobs (in status Open)

### Defects



## 1.3.2

### Tasks

* [MPC-447] - check if last commit in branch (in status In Progress)

### Defects



## 1.3.0

### Tasks

* [MPC-309] - Use configurable branch as base branch (without collapsed version qualifier) in nyx versioning. (in status In Progress)

### Defects



## 1.2.6

### Tasks

* [MPC-439] - No changelog rewrite (in status In Progress)

### Defects
