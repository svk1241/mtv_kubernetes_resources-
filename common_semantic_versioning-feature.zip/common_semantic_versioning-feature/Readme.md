## Automated semantic versioning for repositories

### Usage:
In order to version a repository, the repository must give read and write prermissions to `svc_ddmtv_cicd` account

Go to [Jenkins](https://luxproject.luxoft.com/jenkins/job/MPC/job/Versioning/job/semantic_versioning/build?delay=0sec)

In `repositoryUrl` specify the url to the repository to version.

The pipeline will perform versioning on branch specified in parameter `branchName`.

If the parameter `commitToVersion` is specified, the pipeline will tag specific commit, and will no produce changelog, version files updates, or other commits to the repository. IMPORTANT: Yous still need to specify the brach.

Optionally, you can specify a path to custom nyx configuration file. It should be put into versioning target repository and relative path to it should be provided in `nyx_config_file` parameter. If none is specified the generic .nyx.json file will be used, located in common_semantic_versioning repository.

The pipeline will inspect the existing tags in the specified branch of provided repository, and produce a new tag in format `X.Y.Z`, where `X`, `Y` and `Z` are Major, Minor and Patch version correspondingly.

If issue type of the branch specified to be versioned is a task, feature, bugfix or defect, then the pipeline will produce a new tag in format `X.Y.Z-branchName.A`, where `X.Y.Z` is a generated collapsed version, `branchName` is a name of the branch and `A` is a number of version tags with `X.Y.Z` collapsed version.

The pipeline also generates changelog. It will commit and push it, if `commitChangelog` parameter set to `true`.

If Jira issues from commit messages included in new version are not in their final status (default list of final statuses is: stable_status_list = ['Closed', 'Resolved']), there will ba a warning about it in the output and a mark in the changelog (e.g. 'In status In Progress'). If `markAsUnstable` param is set to true, the build will be marked as unstable additionally.

The pipeline can also perform substitution of version values in files, specified in `versionFilePaths` parameter. You can specify which version values to look for in `versionValues` parameter, if need to change multiple. The pipeline will always look for previous semver version in the branch.

The pipeline can also update JIRA for issues, that were marked in commits, that were included in the new version. For this feature to work, match the `UpdateJira` parameter and specify your project key in `projectKey` parameter. The pipeline then will create a relese with a generated version in the specified project and add it to `Affects Version/s` field of issues.


### Branching and Commit messages conventions:
See [MPC confluence](https://luxproject.luxoft.com/confluence/display/MPC/Conventions+for+SemVer)


### BitBucket configuration
About merge commits.
It is important, that merge commits have a list of all commits from a merged branch in its body. In that case change type of the merge commit will be decided based on all commit massages that were merged. This can be configured in BitBucket settings for each specific repository.

About changelog generation and substitutions.
It is common that commits into main branches, such as development/master, can only be performed via PR. When the pipeline generates changelog or performs substitutions in version files, it will try to push the changes (if relevant parameters were chosen) into the verioned branch. So, to allow this to happen, you need to make an exception in "commit only via PR" rule for `svc_ddmtv_cicd` account in BitBucket setting of your repository.

## Automated semantic versioning for multiple repositories

### Usage:
In order to version a repository, the repository must give read and write prermissions to `svc_ddmtv_cicd` account

Go to [Jenkins](https://luxproject.luxoft.com/jenkins/job/MPC/job/Versioning/job/multiple_repos_semver/build?delay=0sec)

In `repositoryUrl` specify the urls to the repos to version, divided by commas.

In `repositoryBranch` specify the branches in this repos to version, divided by commas. The first branch in this parameter corresponds to the first repository in `repositoryUrl` and so on.

In `appName` specify the name of project, shared by this repos. This parameter is contained in this projects global tag.

The pipeline will inspect the existing global tags in all provided repos, inspect all tags, that follow semver convension, in these repositories since last global tag, and produce a new global tag in format `appName-X.Y.Z`, where `X`, `Y` and `Z` are Major, Minor and Patch version correspondingly.
