#!/bin/bash
regex="\[[a-fA-F0-9]+]"
filename="NYX_CHANGELOG.md"
declare -a commit_hashes=()
while IFS= read -r line; do
    if [[ $line =~ $regex ]]; then
        commit_hash="${BASH_REMATCH[0]:1:-1}"
        if [[ ! " ${commit_hashes[@]} " =~ " $commit_hash " ]]; then
            commit_hashes+=("$commit_hash")
        fi
    fi
done < <(grep -E -o "$regex" "$filename")
jira_regex="\[[A-Z]+-[0-9]+\]"
declare -a jira_identifiers=()
for unique_commit_hash in "${commit_hashes[@]}"; do
    commit_message=$(git show --pretty=format:%B -s "$unique_commit_hash")
    while [[ $commit_message =~ $jira_regex ]]; do
        jira_identifier="${BASH_REMATCH[0]}"
        jira_identifier=$(echo "$jira_identifier" | tr -d '[]')
        if [[ ! " ${jira_identifiers[@]} " =~ " $jira_identifier " ]]; then
            jira_identifiers+=("$jira_identifier")
        fi
        commit_message=${commit_message//"$jira_identifier"}
    done
done
echo "${jira_identifiers[@]}"