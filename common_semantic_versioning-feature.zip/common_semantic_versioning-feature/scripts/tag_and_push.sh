nyxConfigFilePath=$1
if [[ "$nyxConfigFilePath" == '' ]]; then
    nyx_config_file='/opt/ci/.nyx.json'
else
    nyx_config_file=$nyxConfigFilePath
fi
latest_tag=$(git describe --tags --abbrev=0)
collapsed_version_qualifier=${branchName//[._\/]/-}
export collapsed_version_qualifier latest_tag
if [[ "$commitToVersion" == '' ]]; then
    git branch --set-upstream-to origin/$branchName
    git fetch --all 
    branch_is_behind=$(git status -sb | grep -E "\\[(ahead [0-9]+, )?behind [0-9]+\\]")
    if [[ "$branch_is_behind" != '' ]]; then
        branch_is_ahead=$(git status -sb | grep -E "\\[ahead [0-9]+.*\\]")
        if [[ "$branch_is_ahead" != '' ]]; then
            echo "WARNING: commits that were not present on checkout detected at remote. Won't commit anything."
            commits_ahead=$(echo "$branch_is_ahead" | grep -o 'ahead [0-9]\+' | grep -o '[0-9]\+')
            echo "commits_ahead - $commits_ahead"
            git reset --hard HEAD~$commits_ahead
        fi
    fi
fi
nyx --configuration-file="$nyx_config_file" --state-file=state.json --dry-run=false mark
if [[ "$branch_is_behind" == '' && "$commitToVersion" == '' ]]; then
    git push
fi
git push --tags