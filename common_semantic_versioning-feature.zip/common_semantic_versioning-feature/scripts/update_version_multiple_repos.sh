#!/bin/bash
git config --local credential.username "$ACCESS_TOKEN_USERNAME"
git config --local credential.helper '!f() { echo password="$ACCESS_TOKEN_PASSWORD"; }; f'
git config --local user.email "s.sankarshna@dxc.com"
git config --local user.name "ssankarshna"
appName=$1
repositoryUrls=$2
IFS=',' read -ra repoArray <<< "$repositoryUrls"
change_types=("breaking" "feature" "patch" "unchanged" "uninitialized")
change_types_indexes=(0 1 2 3 4)
default_change_type_index=3
change_type_index=$default_change_type_index
global_tag="0.0.0"
for url in "${repoArray[@]}"; do
    echo "# Processing: ${url}"
    repoName=$(basename "$url" .git)
    cd "./cloned_repos/${repoName}" || exit 1
    git fetch --all --tags
    echo "All tags:"
    git tag -l
    echo "Looking for global application tag: $appName-*"
    last_global_tag=$(git describe --tags --all --match "$appName*" --abbrev=0)
    echo "Latest global application tag is: $last_global_tag"
    last_global_tag=${last_global_tag#*$appName-}
    echo "Latest global application version is: $last_global_tag"
    echo ""
    if [ "$last_global_tag" == "" ] && [ "$global_tag" == "0.0.0" ]; then
        change_type_index=4
        echo "Resulting change type after processing $repoName - ${change_types[change_type_index]} (index = $change_type_index)" # no global tag => not checking for changes in this repo && assume it is uninitialized => if resulting change type is uninitialized (in all repos) then set global tag to 1.0.0
    elif [ "$last_global_tag" != "" ]; then
        IFS=.
        ver1=($last_global_tag)
        ver2=($global_tag)
        echo "# Comparing global application version components with highest global application verion across repositories"
        for ((i=0; i<${#ver1[@]}; i++)); do
            echo "$i: Comparing ${ver1[i]} and ${ver2[i]}"
            if [ ${ver1[i]} -gt ${ver2[i]} ]; then
                global_tag=$last_global_tag
                echo "Setting highest global application verion as: $last_global_tag"
                break
            elif [ ${ver1[i]} -lt ${ver2[i]} ]; then
                break
            fi
        done
        echo ""
        echo "# Processing repository versions"
        commit_hash=$(git rev-list -n 1 "$appName-$last_global_tag")
        previous_version=$(git describe --tags --match '[0-9]*.[0-9]*.[0-9]*' --abbrev=0 "$commit_hash") # repo nyx version
        latest_version=$(git describe --tags --match '[0-9]*.[0-9]*.[0-9]*' --abbrev=0)
        echo "Latest repository version is: $latest_version"
        echo "Previous repository version is: $previous_version"
        IFS='.' read -ra previous_components <<< "$previous_version"
        IFS='.' read -ra latest_components <<< "$latest_version"
        echo "Determing change type between latest and previous repository versions"
        for ((i = ${#latest_components[@]} - 1; i >= 0; i--)); do
            echo "$i: Comparing ${latest_components[i]} and ${previous_components[i]}"
            if [ "$((latest_components[i] - previous_components[i]))" -gt 0 ]; then
                if [ ${change_types_indexes[i]} -lt $change_type_index ]; then
                    change_type_index=${change_types_indexes[i]}
                    echo "Change type was set to: ${change_types[change_type_index]} (index = $change_type_index)"
                fi
            fi
        done
        echo ""
        echo "Resulting change type after processing $repoName - ${change_types[change_type_index]} (index = $change_type_index)"
    fi
    cd ..
    cd ..
    echo "#####################################################################"
    echo ""
done
echo ""
IFS='.' read -ra product_version <<< "$global_tag"
result_change_type=${change_types[change_type_index]}
echo "LATEST GLOBAL APPLICATION VERSION IS: $global_tag"
echo "RESULT CHANGE TYPE IS: $result_change_type"
case $result_change_type in
    "breaking")
        product_version[0]=$((product_version[0] + 1))
        product_version[1]=0
        product_version[2]=0
        ;;
    "feature")
        product_version[1]=$((product_version[1] + 1))
        product_version[2]=0
        ;;
    "patch")
        product_version[2]=$((product_version[2] + 1))
        ;;
    "unchanged")
        ;;
    "uninitialized")
        product_version=(1 0 0)
        ;;
esac
echo ""
IFS='.' global_tag="${product_version[*]}"
if [ $result_change_type != "unchanged" ]; then
    for url in "${repoArray[@]}"; do
        echo "Tagging: ${url}"
        repoName=$(basename "$url" .git)
        cd "./cloned_repos/${repoName}" || exit 1
        git tag "$appName-$global_tag"
        echo "tag $appName-$global_tag"
        git push --tags
        cd ..
        cd ..
    done
fi
