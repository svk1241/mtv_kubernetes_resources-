#!/bin/bash
# Check if CHANGELOG.md exists
if [[ ! -f "CHANGELOG.md" ]]; then
    touch CHANGELOG.md
fi
# copy CHANGELOG.md content to tmp file
if [[ "$(head -n 1 CHANGELOG.md)" == "# Changelog" ]]; then
    tail -n +2 CHANGELOG.md > tmp.md
else
    cat CHANGELOG.md > tmp.md
fi
TASK_ISSUES=$(echo "$TASK_ISSUES" | sort)
DEFECT_ISSUES=$(echo "$DEFECT_ISSUES" | sort)
UNKNOWN_ISSUES=$(echo "$UNKNOWN_ISSUES" | sort)
# Overwrite CHANGELOG.md
{
    echo -e "# Changelog\n"
    echo -e "## ${GENERATED_VERSION}\n"
    echo -e "### Tasks\n"
    echo -e "${TASK_ISSUES}"
    echo -e "### Defects\n"
    echo -e "${DEFECT_ISSUES}"
    if [[ -n "$UNKNOWN_ISSUES" ]]; then
        echo -e "### Unknown issues\n"
        echo -e "${UNKNOWN_ISSUES}"
    fi
    cat tmp.md
} > CHANGELOG.md
# Cleanup
rm tmp.md