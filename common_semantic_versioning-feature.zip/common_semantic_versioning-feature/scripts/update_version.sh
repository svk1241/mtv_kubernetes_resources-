nyxConfigFilePath=$1
if [[ "$nyxConfigFilePath" == '' ]]; then
    nyx_config_file='/opt/ci/.nyx.json'
else
    nyx_config_file=$nyxConfigFilePath
fi
echo "Using nyx config file: $nyx_config_file"
git config --local credential.username "$ACCESS_TOKEN_USERNAME"
git config --local credential.helper '!f() { echo password="$ACCESS_TOKEN_PASSWORD"; }; f'
git config --local user.email "s.sankarshna@dxc.com"
git config --local user.name "ssankarshna"
git fetch --all --tags
latest_tag=$(git describe --tags --abbrev=0)
collapsed_version_qualifier=${branchName//[._\/]/-}
export collapsed_version_qualifier latest_tag
nyx --configuration-file="$nyx_config_file" --state-file=state.json --verbosity=DEBUG --dry-run=false infer 2>&1 | tee -a ./nyx_debug_output.txt
previous_versions=""
if [[ $versionValues ]]; then
    previous_versions=$(echo $versionValues | tr ',' ' ')
fi
previous_versions="$previous_versions $(jq -r '.releaseScope.previousVersion' state.json)"
generated_version=$(jq -r ".version" state.json)
if [[ "$buildRelease" != 'false' ]]; then
    versionFilePaths=''
    echo "WARNING: will not perform substitutions for build release."
fi
if [[ "$commitToVersion" != '' ]]; then
    versionFilePaths=''
    echo "Won't commit version files when versioning specified commit."
fi
versionFilePaths=$(echo $versionFilePaths | sed 's/ *$//g')
for fileName in $(echo $versionFilePaths | tr ',' ' '); do
    echo "Processing file: $fileName"
    echo "Looking for versions - $previous_versions. New version - $generated_version"
    for version in $previous_versions; do
        sed -i "s/$version/$generated_version/g" "$fileName"
        git stage -f $fileName
    done
done
git commit -m 'Update version'
nyx --configuration-file="$nyx_config_file" --state-file=state.json --dry-run=false make

stateJsonContent=`cat state.json`  
echo "State.json contains: $stateJsonContent" 
