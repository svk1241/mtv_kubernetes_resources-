#!/bin/bash
mkdir ./cloned_common_semantic_versioning
cd ./cloned_common_semantic_versioning
git clone -b feature https://$ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD@github.dxc.com/MetaVance-Base/common_semantic_versioning.git
cd ./common_semantic_versioning
git config --local credential.username "$ACCESS_TOKEN_USERNAME"
git config --local credential.helper '!f() { echo password="$ACCESS_TOKEN_PASSWORD"; }; f'
git config --local user.email "s.sankarshna@dxc.com"
git config --local user.name "ssankarshna"
fileName='./versioned_repositories.txt'
if [ ! -e "$fileName" ]; then
    touch $fileName
fi
echo $repositoryUrl >> $fileName
sort -u -o $fileName $fileName
git add $fileName
git commit -m "Update versioned repositories list"
echo "test100"
git push 
echo "test101"
cat $fileName
echo "test102"
