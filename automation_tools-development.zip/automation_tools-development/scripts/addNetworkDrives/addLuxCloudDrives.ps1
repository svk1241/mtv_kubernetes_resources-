Get-PSDrive I, R, X, T, K | Remove-PSDrive
$cred = Get-Credential -Credential USERNAME
New-PSDrive -Name "I" -Root "\\smb-server.ddmtv.private\batch86" -Persist -PSProvider "FileSystem" -Credential $cred -Scope Global
New-PSDrive -Name "R" -Root "\\smb-server.ddmtv.private\batchregression" -Persist -PSProvider "FileSystem" -Credential $cred -Scope Global
New-PSDrive -Name "X" -Root "\\smb-server.ddmtv.private\batchconcurrency" -Persist -PSProvider "FileSystem" -Credential $cred -Scope Global
New-PSDrive -Name "T" -Root "\\smb-server.ddmtv.private\batchextensions" -Persist -PSProvider "FileSystem" -Credential $cred -Scope Global
New-PSDrive -Name "K" -Root "\\smb-server.ddmtv.private\dev" -Persist -PSProvider "FileSystem" -Credential $cred -Scope Global