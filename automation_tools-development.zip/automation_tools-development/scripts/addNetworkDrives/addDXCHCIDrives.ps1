Get-PSDrive B, G | Remove-PSDrive
$cred = Get-Credential -Credential USERNAME
New-PSDrive -Name "B" -Root "\\130.174.218.240\batchblu" -Persist -PSProvider "FileSystem" -Credential $cred
New-PSDrive -Name "G" -Root "\\130.174.218.240\batchgrn" -Persist -PSProvider "FileSystem" -Credential $cred