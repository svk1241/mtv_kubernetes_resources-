param(
    [Parameter()]
    [string]$Name='batchdev',
    [Parameter()]
    [string]$Path='C:\Storage\dev\batch',
    [Parameter()]
    [int]$AvailableSeconds=30,
    [Parameter()]
    [int]$UnavailableSeconds=5,
    [Parameter()]
    [switch]$Restore=$false
)

function New-Share($ShareName, $SharePath){
   try {
       $Parameters = @{
           Name = $ShareName
           Path = $SharePath
           FullAccess = 'Everyone'
       }
       New-SmbShare @Parameters -ErrorAction Stop | Out-Null
       Assign-Acl $SharePath
   } catch [Microsoft.Management.Infrastructure.CimException] {
       write-host "Share $name already exist"
   }
}

function Assign-Acl($SharePath){
    $rights = 'FullControl'
    $inheritance = 'ContainerInherit, ObjectInherit'
    $propagation = 'None'
    $type = 'Allow'
    $Acl = Get-Acl -Path $SharePath
    foreach ($identity in 'smb-server\azadmin', 'smb-server\smbuser'){
        $ACE = New-Object System.Security.AccessControl.FileSystemAccessRule($identity,$rights,$inheritance,$propagation, $type)
        $Acl.AddAccessRule($ACE)
    }
    Set-Acl -Path $SharePath -AclObject $Acl
}


New-Share -ShareName $Name -SharePath $Path

if($Restore){
   write-host "Share $name restored"
   Exit
}

write-host "Script will infinitely delete and then create share $Name on path $Path"
write-host -ForegroundColor Green "Available interval: $AvailableSeconds seconds"
write-host -ForegroundColor Red "Unavailable interval: $UnavailableSeconds seconds"
write-host -ForegroundColor Yellow "Press Ctrl-C to stop"
try {
   while ($true){
       Start-Sleep -Seconds $AvailableSeconds
       Remove-SmbShare -Name $Name -Force | Out-Null
       Write-Host "$(Get-Date -Format "MM/dd/yyyy HH:mm:ss K"): Share $Name stopped"
       Start-Sleep -Seconds $UnavailableSeconds
       New-Share -ShareName $Name -SharePath $Path
       Write-Host "$(Get-Date -Format "MM/dd/yyyy HH:mm:ss K"): Share $Name started"
   }
}
finally
{
   write-host "Script interrupted, restoring share $Name on path $Path"
   New-Share -ShareName $Name -SharePath $Path
}
