﻿namespace Edi837D
{
    public class FileReader
    {
        private IEnumerable<string> lines;

        private IEnumerator<string> enumarator;

        public FileReader(string file) { 
            this.lines = File.ReadAllLines(file);
            this.enumarator = this.lines.GetEnumerator();
            this.enumarator.Reset();
        }

        public string GetNextItem()
        {
            try
            {
                this.enumarator.MoveNext();
                return this.enumarator.Current;
            }
            catch (InvalidOperationException) {
                this.enumarator.Reset();
                this.enumarator.MoveNext();
                return this.enumarator.Current;
            }
        }
    }
}
