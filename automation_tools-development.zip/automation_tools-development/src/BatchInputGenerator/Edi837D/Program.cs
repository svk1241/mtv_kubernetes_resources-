﻿using Edi837D.Engine;
using Edi837D.Helpers;
using EdiEngine;
using EdiEngine.Runtime;

namespace Edi837D
{
    internal class Program
    {
        private const string folder = "C:\\_work\\MTV\\Resources";
        private const string fileName = $"{folder}\\B2B_5010_837D\\PPMEC1.PMNEIC00.20220725043956.I837";
        private const string contractResource = $"{folder}\\member_id_contract_id_concatenated_exclude_extension_related.txt";

        static void Main(string[] args)
        {
            var content = File.ReadAllText(fileName);
            var batch = new EdiDataReader().FromString(content);

            UpdateTransactions(batch, 25000);
            SaveToFile(batch, 5);
        }

        public static void UpdateTransactions(EdiBatch batch, int claimsCount)
        {
            var content = File.ReadAllText(fileName);

            var fileReader = new FileReader(contractResource);

            var group = batch.Interchanges[0].Groups[0];

            while (group.Transactions.Count < claimsCount)
            {
                var tran = new EdiDataReader().FromString(content).Interchanges[0].Groups[0].Transactions;
                group.Transactions.AddRange(tran);
                group.Transactions = group.Transactions.Take(claimsCount).ToList();
            }

            var transCount = 0;

            foreach (var transaction in group.Transactions)
            {
                transaction.ST.Content[2].Val = StringHelper.PadLeftZeroes(++transCount, 9);
                transaction.SE.Content[2].Val = transaction.ST.Content[2].Val;

                foreach (var elements in transaction.ElementsList)
                {
                    if (elements[0] == "NM1" && elements.Length > 8)
                    {
                        if (elements[8] == "MI")
                        {
                            elements[9] = fileReader.GetNextItem().Trim();
                        }
                    }
                }
            }
        }

        public static void SaveToFile(EdiBatch batch, int transactionCountInFile)
        {
            var interchange = batch.Interchanges[0];
            var group = interchange.Groups[0];

            var header = new List<string>()
                {
                    interchange.ISA.ToString(),
                    group.GS.ToString(),
                };

            var tailer = new List<string>()
            {
                group.GE.ToString(),
                interchange.IEA.ToString()
            };

            for (var i = 0; i < group.Transactions.Count / transactionCountInFile; i++) 
            {
                var list = new List<string>();

                list.AddRange(header);

                var transactionSet = GetTransactionSet(group.Transactions, transactionCountInFile * i, transactionCountInFile);

                list.AddRange(transactionSet);
                list.AddRange(tailer);

                var fileContent = string.Join(Constants.SegmentSeparator, list) + "~";

                File.WriteAllText($"{folder}\\generated\\Gen_{transactionCountInFile}_{i}.txt", fileContent);
            }
        }

        private static List<string> GetTransactionSet(List<EdiTrans> transactions, int skip, int count)
        {
            var items = transactions.Skip(skip).Take(count);
            var list = new List<string>();

            foreach (var transaction in items)
            {
                list.Add(transaction.ST.ToString());
                list.AddRange(transaction.ElementsList.Select(i => string.Join(Constants.ElementSeparator, i)));
                list.Add(transaction.SE.ToString());
            }

            return list;
        }
    }
}