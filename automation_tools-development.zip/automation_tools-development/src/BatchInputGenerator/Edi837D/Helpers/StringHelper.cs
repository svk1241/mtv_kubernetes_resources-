﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Edi837D.Helpers
{
    public class StringHelper
    {
        public static string PadLeftZeroes(int value, int length)
        {
            return value.ToString().PadLeft(length, '0');
        }
    }
}
