﻿namespace Edi837D.Engine
{
    public static class Constants
    {
        public const string SegmentSeparator = "~";
        public const string ElementSeparator = "*";
    }
}
