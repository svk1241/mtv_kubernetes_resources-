﻿using EdiEngine.Runtime;
using EdiEngine.Validation;
using Edi837D.Engine;


namespace EdiEngine
{
    public class EdiDataReader
    {
        public EdiBatch FromStream(Stream fileContent)
        {
            string stringContent;
            using (StreamReader sr = new StreamReader(fileContent))
            {
                stringContent = sr.ReadToEnd();
            }

            return FromString(stringContent);
        }

        public EdiBatch FromString(string fileContent)
        {
            if (string.IsNullOrWhiteSpace(fileContent))
                throw new EdiParsingException("Empty File");

            if (!fileContent.StartsWith("ISA"))
                throw new EdiParsingException("ISA NOT FOUND");

            string[] segments = fileContent.Split(new [] { Constants.SegmentSeparator }, StringSplitOptions.RemoveEmptyEntries);

            EdiBatch batch = new EdiBatch();

            EdiInterchange currentInterchange = null;
            EdiGroup currentGroup = null;
            EdiTrans currentTrans = null;

            int tranSegCount = 0;
            int groupsCount = 0;
            int transCount = 0;

            foreach (string seg in segments)
            {
                string[] elements = seg.Split(new [] { Constants.ElementSeparator }, StringSplitOptions.None);
                switch (elements[0])
                {
                    case "ISA":
                        groupsCount = 0;
                        currentInterchange = new EdiInterchange
                        {
                            SegmentSeparator = Constants.SegmentSeparator,
                            ElementSeparator = Constants.ElementSeparator
                        };

                        currentInterchange.ISA = new ISA(elements);

                        break;

                    case "IEA":
                        if (currentInterchange == null)
                            throw new EdiParsingException("MALFORMED  DATA");

                        currentInterchange.IEA = new IEA(elements);

                        batch.Interchanges.Add(currentInterchange);

                        int declaredGroupCount;
                        int.TryParse(elements[1], out declaredGroupCount);

                        if (declaredGroupCount != groupsCount)
                        {
                            AddValidationError(currentInterchange, $"Expected {declaredGroupCount} groups. Found {groupsCount}. Interchange # {elements[2]}.");
                        }

                        if (!CheckControlNumbersAreEgual(currentInterchange.ISA.Content[12].Val, elements[2]))
                        {
                            AddValidationError(currentInterchange, $"Control numbers do not match. ISA {currentInterchange.ISA.Content[12].Val}. IEA {elements[2]}.");
                        }

                        currentInterchange = null;

                        break;

                    case "GS":
                        groupsCount++;
                        transCount = 0;
                        currentGroup = new EdiGroup(elements[1]);
                        currentGroup.GS = new GS(elements);

                        break;

                    case "GE":
                        if (currentInterchange == null || currentGroup == null)
                            throw new EdiParsingException("MALFORMED DATA");

                        currentGroup.GE = new GE(elements);
                        currentInterchange.Groups.Add(currentGroup);

                        int declaredTransCount;
                        int.TryParse(elements[1], out declaredTransCount);

                        if (declaredTransCount != transCount)
                        {
                            AddValidationError(currentGroup, $"Expected {declaredTransCount} transactions. Found {transCount}. Group # {elements[2]}.");
                        }

                        if (!CheckControlNumbersAreEgual(currentGroup.GS.Content[5].Val, elements[2]))
                        {
                            AddValidationError(currentGroup, $"Control numbers do not match. GS {currentGroup.GS.Content[5].Val}. GE {elements[2]}.");
                        }

                        currentGroup = null;
                        break;

                    case "ST":
                        if (currentInterchange == null || currentGroup == null)
                            throw new EdiParsingException("MALFORMED DATA");

                        transCount++;

                        currentTrans = new EdiTrans();

                        currentTrans.ST = new ST(elements);

                        tranSegCount = 1;
                        break;

                    case "SE":
                        if (currentInterchange == null || currentGroup == null || currentTrans == null)
                            throw new EdiParsingException("MALFORMED DATA");

                        tranSegCount++;

                        int declaredSegCount;
                        int.TryParse(elements[1], out declaredSegCount);

                        if (declaredSegCount != tranSegCount)
                        {
                            AddValidationError(currentTrans, $"Expected {declaredSegCount} segments. Found {tranSegCount}. Trans # {elements[2]}.");
                        }

                        if (!CheckControlNumbersAreEgual(currentTrans.ST.Content[1].Val, elements[2]))
                        {
                            AddValidationError(currentTrans, $"Control numbers do not match. ST {currentTrans.ST.Content[1].Val}. SE {elements[2]}.");
                        }

                        currentTrans.SE = new SE(elements);

                        currentGroup.Transactions.Add(currentTrans);
                        currentTrans = null;
                        break;
                    default:
                        tranSegCount++;
                        currentTrans?.ElementsList.Add(elements);
                        break;
                }
            }
            return batch;
        }

        private void AddValidationError(IValidatedEntity obj, string message)
        {
            ValidationError err = new ValidationError()
            {
                Message = message
            };

            obj?.ValidationErrors.Add(err);
        }

        private bool CheckControlNumbersAreEgual(string headerIcn, string footerIcn)
        {
            int icn1, icn2;

            var res = int.TryParse(headerIcn, out icn1);
            res = int.TryParse(footerIcn, out icn2) & res;

            return res && icn1 == icn2;
        }
    }
}
