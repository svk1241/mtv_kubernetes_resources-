from dat_adapter.to_dat_mixin import ToDat
from dat_adapter.txt_records_serializer import Serializer
from jsf import JSF
from fields.custom import ReplacebleConStr
from models.bmi.mbra import Mbra
from models.bmi.mbra_input import MbraInput
from models.model_modifyer import FieldModifyer
from models.modifyers_callbacks import get_string_slice_with_len, datetime_to_ccyymmdd
from pydantic.error_wrappers import ValidationError
from reader.preprocessor import CsvPreprocessor


covg_schema = Mbra.schema()
generator = JSF(covg_schema)
covg_instance = generator.generate(1)


pps = CsvPreprocessor("C:\\Users\\azadmin\\Desktop\\datain_bmi\\MBRA_INPUT.csv")
covgs_anger = []
covgs = []

validation_errors = []

# keys_to_reuse = ["sort_number", "record_type", "run_date", "member_id", "bypass_process_flag", "filler", ]
keys_to_reuse = {k for k in Mbra.__annotations__.keys()}
keys_to_reuse.difference_update(
    {
        "contract_id",
        "member_id",
        "address_line_1",
        "city",
        "state",
        "address_type",
        "effective_date"
    }
)

for row in pps.rows(MbraInput.__annotations__.keys()):
    c_anger = MbraInput(**row)
    md = c_anger.modify(
        FieldModifyer("CONTRACT_ID", "contract_id", get_string_slice_with_len(Mbra.get_field_length("contract_id"))),
        FieldModifyer("MEMBER_ID", "member_id", get_string_slice_with_len(Mbra.get_field_length("member_id"))),
        FieldModifyer("ADDRESS_1", "address_line_1", get_string_slice_with_len(Mbra.get_field_length("address_line_1"))),
        FieldModifyer("CITY", "city", get_string_slice_with_len(Mbra.get_field_length("city"))),
        FieldModifyer("STATE_CODE", "state", get_string_slice_with_len(Mbra.get_field_length("state"))),
        FieldModifyer("ADDRESS_TYPE", "address_type", get_string_slice_with_len(Mbra.get_field_length("address_type"))),
        FieldModifyer("EFFECTIVE_DATE", "effective_date", datetime_to_ccyymmdd)
    )
    for key in keys_to_reuse:
        md[key] = covg_instance[key]
    try:
        cvg = Mbra(**md)
        cvg = ReplacebleConStr.to_spaced_string(cvg)
        covgs.append(cvg)
    except ValidationError as e:
        validation_errors.append((e, md))

dats = []
for cvg in covgs:
    dat = ToDat.get_txt_record_fields(cvg)
    dats.append(dat)


Serializer(dats, 2000).save("mbra.dat")
