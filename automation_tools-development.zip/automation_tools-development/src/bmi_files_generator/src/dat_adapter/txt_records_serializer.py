from pathlib import Path
from typing import Iterable, Union
from .txt_record_field import TxtRecordField

ObjectToSerialize = Iterable[TxtRecordField]


class Serializer:
    def __init__(self, objects_to_serialize: Iterable[ObjectToSerialize], string_length: int, chunks: int = 1000) -> None:
        self._objects_to_serialize = objects_to_serialize
        self._string_length = string_length
        self._chunks = chunks

    def save(self, filepath: Union[str, Path], *, fill_empty_space: bool = True, fill_with: str = " ") -> None:

        with open(filepath, 'w') as file:
            chunks = []

            for obj in self._objects_to_serialize:
                result = "".join(map(lambda x: x.value, sorted(obj, key=lambda x: x.start)))
                if len(result) < self._string_length and fill_empty_space:
                    filer_length = self._string_length - len(result)
                    result += fill_with * filer_length
                result += "\n"
                chunks.append(result)

                if len(chunks) >= self._chunks:
                    file.writelines(chunks)
                    chunks.clear()

            if len(chunks) > 0 and len(chunks) < self._chunks:
                file.writelines(chunks)

        file.close()
