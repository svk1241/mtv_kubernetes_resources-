class TxtRecordField:
    """Public class to help with txt records"""

    def __init__(self, start, length):
        self.start = start
        self.length = length
        self.value = None

    @property
    def __end(self):
        return self.start + self.length

    def init_value(self, record: str) -> None:
        """Parses given record using start/end positions and sets value

        :param record:
        """
        self.value = record[self.start:self.__end]

    def set_value(self, val: str) -> None:
        if val is None:
            return

        if len(val) == self.length:
            self.value = val
        elif len(val) < self.length:
            self.value = val + self.value[len(val) - self.length:]
        else:
            raise ValueError(f'Given value "{val}" length is more than expected {self.length}')
