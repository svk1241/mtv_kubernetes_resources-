from random import choice
from typing import Any, List, get_args
from pydantic import BaseModel

from .txt_record_field import TxtRecordField


class ToDat:
    @classmethod
    def get_txt_record_fields(cls, model: BaseModel) -> List[TxtRecordField]:
        initial_position = 1
        accumulated_fields_length = 0

        txt_record_fields = []
        for field in model.__fields__:
            posotion = initial_position + accumulated_fields_length

            annotation = model.__annotations__[field]
            if "Literal" in str(annotation):
                record_field_literal = cls._get_literal_record_field(annotation, posotion)
                txt_record_fields.append(record_field_literal)
                accumulated_fields_length += record_field_literal.length
            elif type(None) in get_args(annotation): # proceed optional
                pass
            else:
                if not annotation.min_length == annotation.max_length:
                    raise
                length = annotation.min_length

                record_field = TxtRecordField(start=posotion, length=length)
                record_field.set_value(getattr(model, field))
                txt_record_fields.append(record_field)
                accumulated_fields_length += length

        return txt_record_fields
    
    @classmethod
    def _get_literal_record_field(cls, annotation: Any, position: int) -> TxtRecordField:
        type_arguments = get_args(annotation)
        value = str(choice(type_arguments))
        record_field = TxtRecordField(start=position, length=len(value))
        record_field.set_value(value)
        return record_field
