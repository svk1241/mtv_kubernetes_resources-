from typing import List, Optional

from reader.csv_reader import CsvReader


class CsvPreprocessor:
    def __init__(self, csv_file: str) -> None:
        self._reader = CsvReader(csv_file)

    def rows(self, colmuns_include: Optional[List[str]]):
        if colmuns_include:
            # include only selected
            columns_to_be_included = colmuns_include
        else:
            # include everything
            columns_to_be_included = self._reader.header
        for row in self._reader.rows:
            yield {key: value for key, value in row.items() if key in columns_to_be_included}
