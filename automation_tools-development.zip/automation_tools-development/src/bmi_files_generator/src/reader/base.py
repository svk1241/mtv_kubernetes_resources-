
class BaseReader:
    pass
