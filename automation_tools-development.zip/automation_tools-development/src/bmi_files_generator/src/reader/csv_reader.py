import csv
from pathlib import Path
from typing import Any, Dict, Iterable, List, Union

from .base import BaseReader


class CsvReader(BaseReader):
    def __init__(self, filepath: Union[str, Path]) -> None:
        self._file = open(filepath, "r")
        self._header = next(csv.reader(self._file))
        self._datareader = csv.DictReader(self._file, self._header)

    def __del__(self):
        self._file.close()

    @property
    def header(self) -> List[str]:
        return self._header

    @property
    def rows(self) -> Iterable[Dict[str, Any]]:
        return self._datareader
