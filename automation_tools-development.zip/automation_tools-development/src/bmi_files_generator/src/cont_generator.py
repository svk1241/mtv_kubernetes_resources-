from dat_adapter.to_dat_mixin import ToDat
from dat_adapter.txt_records_serializer import Serializer
from jsf import JSF
from fields.custom import ReplacebleConStr
from models.bmi.cont import Cont
from models.bmi.cont_input import ContInput
from models.model_modifyer import FieldModifyer
from models.modifyers_callbacks import get_string_slice_with_len, datetime_to_ccyymmdd
from pydantic.error_wrappers import ValidationError
from reader.preprocessor import CsvPreprocessor


covg_schema = Cont.schema()
generator = JSF(covg_schema)
covg_instance = generator.generate(1)


pps = CsvPreprocessor("C:\\Users\\azadmin\\Desktop\\datain_bmi\\CONT_INPUT.csv")
covgs_anger = []
covgs = []

validation_errors = []

# keys_to_reuse = ["sort_number", "record_type", "run_date", "member_id", "bypass_process_flag", "filler", ]
keys_to_reuse = {k for k in Cont.__annotations__.keys()}
keys_to_reuse.difference_update(
    {
        "employee_group_level_1_id",
        "contact_type",
        "last_name",
        "first_name"
    }
)

for row in pps.rows(ContInput.__annotations__.keys()):
    c_anger = ContInput(**row)
    md = c_anger.modify(
        FieldModifyer("EMPGRP_LEVEL_1_ID", "employee_group_level_1_id", get_string_slice_with_len(Cont.get_field_length("employee_group_level_1_id"))),
        FieldModifyer("CONTACT_TYPE_CODE", "contact_type", get_string_slice_with_len(Cont.get_field_length("contact_type"))),
        FieldModifyer("LAST_NAME", "last_name", get_string_slice_with_len(Cont.get_field_length("last_name"))),
        FieldModifyer("FIRST_NAME", "first_name", get_string_slice_with_len(Cont.get_field_length("first_name")))
    )
    for key in keys_to_reuse:
        md[key] = covg_instance[key]
    try:
        cvg = Cont(**md)
        cvg = ReplacebleConStr.to_spaced_string(cvg)
        covgs.append(cvg)
    except ValidationError as e:
        validation_errors.append((e, md))

dats = []
breakpoint()
for cvg in covgs:
    dat = ToDat.get_txt_record_fields(cvg)
    dats.append(dat)


Serializer(dats, 2000).save("cont.dat")

