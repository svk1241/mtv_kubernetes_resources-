from dat_adapter.to_dat_mixin import ToDat
from dat_adapter.txt_records_serializer import Serializer
from models.covg import Covg
from reader.csv_reader import CsvReader

reader = CsvReader("C:\\Users\\azadmin\\Projects\\automation\\internal\\batch_data\\mock_covg.csv")

for row in reader.rows:
    covg_instance = Covg(**row)
    records = ToDat.get_txt_record_fields(covg_instance)
    Serializer([records], 2000).save("csv_to_dat.dat")

    
