import re
from typing import Any, Dict

from pydantic.fields import ModelField
from pydantic import constr


ccyymmdd_regex = re.compile(r'[0-9]{4}([0][0-9]|[1][0-2])([0-2][0-9]|[3][0-1])')


class CcYyMmDd(str):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate

    @classmethod
    def __modify_schema__(cls, field_schema: Dict[str, Any]):
        field_schema.update(pattern='[0-9]{4}([0][0-9]|[1][0-2])([0-2][0-9]|[3][0-1])', examples=['20220104', '20070822', '19840413'])

    @classmethod
    def validate(cls, v: ModelField):
        if not isinstance(v, str):
            raise TypeError("must be str")
        if not v.isdigit():
            raise ValueError("must be digits")

        m = ccyymmdd_regex.fullmatch(v)

        if not m:
            raise ValueError("invalide value format")

        return cls(v)


def ccyymmdd(presented=False):
    return constr(min_length=8, max_length=8, regex=r'[0-9]{4}([0][0-9]|[1][0-2])([0-2][0-9]|[3][0-1])')
