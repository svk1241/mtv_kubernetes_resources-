from typing import TypeVar

from models.base import BaseDDMTVModel
from pydantic import constr
from pydantic.types import ConstrainedStr, _registered

T = TypeVar("T", bound=BaseDDMTVModel)


class ReplacebleConStr(ConstrainedStr):
    ispresented = False

    @classmethod
    def get_spaced(cls) -> str:
        return cls.min_length * " "

    @classmethod
    def to_spaced_string(cls, model: T) -> T:
        for field in model.__fields__.keys():
            annotation = model.__annotations__[field]
            if str(annotation) == str(cls) and not annotation.ispresented:
                assert hasattr(annotation, "get_spaced")
                new_value = annotation.get_spaced()
                setattr(model, field, new_value)
        return model


def alphanumeric(length: int, presented: bool = False):
    expr = '[\w| ]{' + f'{length}' + '}'
    return _registered(
        type(
            "ReplacebleConStr",
            (ReplacebleConStr,),
            dict(min_length=length, max_length=length, regex=expr, ispresented=presented),
        )
    )


def fractional(int_pt_len: int, frac_pt_lem: int = 2, presented: bool = False):
    expr = "".join(['[0-9]{', f'{int_pt_len}', '}\.', '[0-9]{', f'{frac_pt_lem}', '}'])
    total_len = int_pt_len + frac_pt_lem + 1
    return _registered(
        type(
            "ReplacebleConStr",
            (ReplacebleConStr,),
            dict(min_length=total_len, max_length=total_len, regex=expr, ispresented=presented),
        )
    )


def whitespaces(length: int):
    expr = "".join([' {', str(length), '}'])
    return constr(min_length=length, max_length=length, regex=expr)
