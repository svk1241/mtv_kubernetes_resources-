from dat_adapter.to_dat_mixin import ToDat
from dat_adapter.txt_records_serializer import Serializer
from jsf import JSF
from fields.custom import ReplacebleConStr
from models.bmi.covg import Covg
from models.bmi.covg_input import CovgInput
from models.model_modifyer import FieldModifyer
from models.modifyers_callbacks import get_string_slice_with_len, datetime_to_ccyymmdd
from pydantic.error_wrappers import ValidationError
from reader.preprocessor import CsvPreprocessor


covg_schema = Covg.schema()
generator = JSF(covg_schema)
covg_instance = generator.generate(1)


pps = CsvPreprocessor("C:\\Users\\azadmin\\Desktop\\BMI_COVG.csv")
covgs_anger = []
covgs = []

validation_errors = []

# keys_to_reuse = ["sort_number", "record_type", "run_date", "member_id", "bypass_process_flag", "filler", ]
keys_to_reuse = {k for k in Covg.__annotations__.keys()}
keys_to_reuse.difference_update(
    {
        "contract_id",
        "contract_type_code",
        "soft_effective_date",
        "end_date",
        "disenrollment_reason",
        "rate_package_id",
        "empl_group_level_1_id",
        "empl_group_level_2_id",
    }
)

for row in pps.rows(CovgInput.__annotations__.keys()):
    c_anger = CovgInput(**row)
    md = c_anger.modify(
        FieldModifyer("CONTRACT_ID", "contract_id", get_string_slice_with_len(Covg.get_field_length("contract_id"))),
        FieldModifyer("CONTRACT_TYPE_CD", "contract_type_code", get_string_slice_with_len(Covg.get_field_length("contract_type_code"))),
        FieldModifyer("EFFECTIVE_DATE", "soft_effective_date", datetime_to_ccyymmdd),
        FieldModifyer("END_DATE", "end_date", datetime_to_ccyymmdd),
        FieldModifyer("DISENROLL_RESN_CD", "disenrollment_reason", get_string_slice_with_len(Covg.get_field_length("disenrollment_reason"))),
        FieldModifyer("RATE_PKG_ID_CD", "rate_package_id", get_string_slice_with_len(Covg.get_field_length("rate_package_id"))),
        FieldModifyer("EMPGRP_LVL_1_ID", "empl_group_level_1_id", get_string_slice_with_len(Covg.get_field_length("empl_group_level_1_id"))),
        FieldModifyer("EMPGRP_LVL_2_ID", "empl_group_level_2_id", get_string_slice_with_len(Covg.get_field_length("empl_group_level_2_id"))),
    )
    for key in keys_to_reuse:
        md[key] = covg_instance[key]
    try:
        cvg = Covg(**md)
        cvg = ReplacebleConStr.to_spaced_string(cvg)
        covgs.append(cvg)
    except ValidationError as e:
        validation_errors.append((e, md))

dats = []

for cvg in covgs:
    dat = ToDat.get_txt_record_fields(cvg)
    dats.append(dat)


Serializer(dats, 2000).save("from_db.dat")

