from contextlib import contextmanager
import csv
from io import TextIOWrapper
from os.path import exists

from pathlib import Path
from typing import Callable, Dict, Generic, Iterator, List, Type, TypeVar, Union

from pydantic import BaseModel

from .base import BaseWriter

T = TypeVar("T", bound=BaseModel)


class CsvWriter(BaseWriter, Generic[T]):
    def __init__(self, model_type: Type[T], chunk_size: int, write_cycles: int) -> None:
        self._model = model_type
        self._chunk_size = chunk_size
        self._cycles = write_cycles

    def get_header(self) -> List[str]:
        return list(self._model.__fields__.keys())

    @contextmanager
    def _append_or_create_file(self, dst: Union[str, Path]) -> Iterator[TextIOWrapper]:
        if exists(dst):
            file = open(dst, 'a')
            # TODO validate here?
        else:
            file = open(dst, 'w')
        yield file
        file.close()

    def save(self, producer: Callable[[int], List[Dict]], destination: Union[str, Path]) -> None:
        fields = self.get_header()
        with self._append_or_create_file(destination) as csvfile:
            # TODO validate and check if headers exists
            writer = csv.DictWriter(csvfile, fields)
            writer.writeheader()    # write header anyway for a while
            for _ in range(self._cycles):
                chunk = producer(self._chunk_size)
                writer.writerows(chunk)
