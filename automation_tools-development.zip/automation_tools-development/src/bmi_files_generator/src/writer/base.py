from pathlib import Path
from typing import Callable, Protocol, Union


class BaseWriter(Protocol):
    def save(self, producer: Callable, destination: Union[str, Path]) -> None:
        ...
