import csv

from jsf import JSF
from models.covg import Covg



covg_schema = Covg.schema()
generator = JSF(covg_schema)
covgs = generator.generate(1000)

fields = list(covgs[0].keys())
covg_instance = Covg(**covgs[0])
breakpoint()
filename = "mock_covg.csv"
with open(filename, "w") as csvfile:
    writer = csv.DictWriter(csvfile, fieldnames=fields)
    writer.writeheader()
    writer.writerows(covgs)

for i in range(99):
    rows = generator.generate(1000)
    with open(filename, 'a') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fields)
        writer.writerows(rows)
    print(i+1)