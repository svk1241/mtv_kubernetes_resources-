from dat_adapter.to_dat_mixin import ToDat
from dat_adapter.txt_records_serializer import Serializer
from jsf import JSF
from fields.custom import ReplacebleConStr
from models.bmi.ccei import Ccei
from models.bmi.ccei_input import CceiInput
from models.model_modifyer import FieldModifyer
from models.modifyers_callbacks import get_string_slice_with_len, datetime_to_ccyymmdd
from pydantic.error_wrappers import ValidationError
from reader.preprocessor import CsvPreprocessor


covg_schema = Ccei.schema()
generator = JSF(covg_schema)
covg_instance = generator.generate(1)


pps = CsvPreprocessor("C:\\Users\\azadmin\\Desktop\\datain_bmi\\CCEI_INPUT_1000.csv")
covgs_anger = []
covgs = []

validation_errors = []

# keys_to_reuse = ["sort_number", "record_type", "run_date", "member_id", "bypass_process_flag", "filler", ]
keys_to_reuse = {k for k in Ccei.__annotations__.keys()}
keys_to_reuse.difference_update(
    {
        "contract_id",
        "effective_date"
    }
)

for row in pps.rows(CceiInput.__annotations__.keys()):
    c_anger = CceiInput(**row)
    md = c_anger.modify(
        FieldModifyer("CONTRACT_ID", "contract_id", get_string_slice_with_len(Ccei.get_field_length("contract_id"))),
        FieldModifyer("EFFECTIVE_DATE", "effective_date", datetime_to_ccyymmdd),
         )
    for key in keys_to_reuse:
        md[key] = covg_instance[key]
    try:
        cvg = Ccei(**md)
        cvg = ReplacebleConStr.to_spaced_string(cvg)
        covgs.append(cvg)
    except ValidationError as e:
        validation_errors.append((e, md))

dats = []
for cvg in covgs:
    dat = ToDat.get_txt_record_fields(cvg)
    dats.append(dat)


Serializer(dats, 2000).save("ccei.dat")

