from dat_adapter.to_dat_mixin import ToDat
from dat_adapter.txt_records_serializer import Serializer
from jsf import JSF
from fields.custom import ReplacebleConStr
from models.bmi.memb import Memb
from models.bmi.memb_input import MembInput
from models.model_modifyer import FieldModifyer
from models.modifyers_callbacks import get_string_slice_with_len, datetime_to_ccyymmdd
from pydantic.error_wrappers import ValidationError
from reader.preprocessor import CsvPreprocessor


covg_schema = Memb.schema()
generator = JSF(covg_schema)
covg_instance = generator.generate(1)


pps = CsvPreprocessor("C:\\Users\\azadmin\\Desktop\\datain_bmi\\MEMB_INPUT.csv")
covgs_anger = []
covgs = []

validation_errors = []

# keys_to_reuse = ["sort_number", "record_type", "run_date", "member_id", "bypass_process_flag", "filler", ]
keys_to_reuse = {k for k in Memb.__annotations__.keys()}
keys_to_reuse.difference_update(
    {
        "contract_id",
        "member_id",
        "address_line_1",
        "city",
        "state",
        "address_type",
        "effective_date"
    }
)

for row in pps.rows(MembInput.__annotations__.keys()):
    c_anger = MembInput(**row)
    md = c_anger.modify(
        FieldModifyer("CONTRACT_ID", "contract_id", get_string_slice_with_len(Memb.get_field_length("contract_id"))),
        FieldModifyer("MEMBER_ID", "member_id", get_string_slice_with_len(Memb.get_field_length("member_id"))),
        FieldModifyer("FIRST_NAME", "first_name", get_string_slice_with_len(Memb.get_field_length("first_name"))),
        FieldModifyer("LAST_NAME", "last_name", get_string_slice_with_len(Memb.get_field_length("last_name"))),
        FieldModifyer("BIRTH_DATE", "date_of_birth", datetime_to_ccyymmdd),
        FieldModifyer("SEX_CODE", "sex", get_string_slice_with_len(Memb.get_field_length("sex"))),
    )
    for key in keys_to_reuse:
        md[key] = covg_instance[key]
    try:
        cvg = Memb(**md)
        cvg = ReplacebleConStr.to_spaced_string(cvg)
        covgs.append(cvg)
    except ValidationError as e:
        validation_errors.append((e, md))

dats = []
for cvg in covgs:
    dat = ToDat.get_txt_record_fields(cvg)
    dats.append(dat)


Serializer(dats, 2000).save("Memb.dat")
