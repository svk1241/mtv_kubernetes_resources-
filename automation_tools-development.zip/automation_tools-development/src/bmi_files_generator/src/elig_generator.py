from dat_adapter.to_dat_mixin import ToDat
from dat_adapter.txt_records_serializer import Serializer
from jsf import JSF
from fields.custom import ReplacebleConStr
from models.bmi.elig import Elig
from models.bmi.elig_input import EligInput
from models.model_modifyer import FieldModifyer
from models.modifyers_callbacks import get_string_slice_with_len, datetime_to_ccyymmdd
from pydantic.error_wrappers import ValidationError
from reader.preprocessor import CsvPreprocessor


covg_schema = Elig.schema()
generator = JSF(covg_schema)
covg_instance = generator.generate(1)


pps = CsvPreprocessor("C:\\Users\\azadmin\\Desktop\\datain_bmi\\ELIG_INPUT.csv")
covgs_anger = []
covgs = []

validation_errors = []

# keys_to_reuse = ["sort_number", "record_type", "run_date", "member_id", "bypass_process_flag", "filler", ]
keys_to_reuse = {k for k in Elig.__annotations__.keys()}
keys_to_reuse.difference_update(
    {
        "contract_id",
        "member_id",
        "business_level_4_id",
        "business_level_5_id",
        "business_level_7_id",
        "class_code",
    }
)

for row in pps.rows(EligInput.__annotations__.keys()):
    c_anger = EligInput(**row)
    md = c_anger.modify(
        FieldModifyer("CONTRACT_ID", "contract_id", get_string_slice_with_len(Elig.get_field_length("contract_id"))),
        FieldModifyer("MEMBER_ID", "member_id", get_string_slice_with_len(Elig.get_field_length("member_id"))),
        FieldModifyer("BUS_LEVEL_4_ID", "business_level_4_id", get_string_slice_with_len(Elig.get_field_length("business_level_4_id"))),
        FieldModifyer("BUS_LEVEL_5_ID", "business_level_5_id", get_string_slice_with_len(Elig.get_field_length("business_level_5_id"))),
        FieldModifyer("BUS_LEVEL_7_ID", "business_level_7_id", get_string_slice_with_len(Elig.get_field_length("business_level_7_id"))),
        FieldModifyer("CLASS_CODE", "class_code", get_string_slice_with_len(Elig.get_field_length("class_code")))
    )
    for key in keys_to_reuse:
        md[key] = covg_instance[key]
    try:
        cvg = Elig(**md)
        cvg = ReplacebleConStr.to_spaced_string(cvg)
        covgs.append(cvg)
    except ValidationError as e:
        validation_errors.append((e, md))

dats = []
breakpoint()
for cvg in covgs:
    dat = ToDat.get_txt_record_fields(cvg)
    dats.append(dat)


Serializer(dats, 2000).save("elig.dat")
