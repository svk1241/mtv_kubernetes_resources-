from dat_adapter.to_dat_mixin import ToDat
from dat_adapter.txt_records_serializer import Serializer
from jsf import JSF
from fields.custom import ReplacebleConStr
from models.bmi.maid import Maid
from models.bmi.maid_input import MaidInput
from models.model_modifyer import FieldModifyer
from models.modifyers_callbacks import get_string_slice_with_len, datetime_to_ccyymmdd
from pydantic.error_wrappers import ValidationError
from reader.preprocessor import CsvPreprocessor


covg_schema = Maid.schema()
generator = JSF(covg_schema)
covg_instance = generator.generate(1)


pps = CsvPreprocessor("C:\\Users\\azadmin\\Desktop\\datain_bmi\\MAID_INPUT.csv")
covgs_anger = []
covgs = []

validation_errors = []

# keys_to_reuse = ["sort_number", "record_type", "run_date", "member_id", "bypass_process_flag", "filler", ]
keys_to_reuse = {k for k in Maid.__annotations__.keys()}
keys_to_reuse.difference_update(
    {
        "contract_id",
        "member_id",
        "alternate_id_type_code",
        "alternate_id_source_code",
        "alternate_id",
        "effective_date"
    }
)

for row in pps.rows(MaidInput.__annotations__.keys()):
    c_anger = MaidInput(**row)
    md = c_anger.modify(
        FieldModifyer("CVG_CONTRACT_ID", "contract_id", get_string_slice_with_len(Maid.get_field_length("contract_id"))),
        FieldModifyer("MEMBER_ID", "member_id", get_string_slice_with_len(Maid.get_field_length("member_id"))),
        FieldModifyer("ALTERNAT_ID_TYP_CD", "alternate_id_type_code", get_string_slice_with_len(Maid.get_field_length("alternate_id_type_code"))),
        FieldModifyer("ALTERNAT_ID_SRC_CD", "alternate_id_source_code", get_string_slice_with_len(Maid.get_field_length("alternate_id_source_code"))),
        FieldModifyer("ALTERNATE_ID", "alternate_id", get_string_slice_with_len(Maid.get_field_length("alternate_id"))),
        FieldModifyer("EFFECTIVE_DATE", "effective_date", datetime_to_ccyymmdd)
    )
    for key in keys_to_reuse:
        md[key] = covg_instance[key]
    try:
        cvg = Maid(**md)
        cvg = ReplacebleConStr.to_spaced_string(cvg)
        covgs.append(cvg)
    except ValidationError as e:
        validation_errors.append((e, md))

dats = []
for cvg in covgs:
    dat = ToDat.get_txt_record_fields(cvg)
    dats.append(dat)


Serializer(dats, 2000).save("Maid.dat")
