from writer.csv_writer import CsvWriter
from reader.csv_reader import CsvReader

reader = CsvReader("C:\\Users\\azadmin\\Projects\\automation\\internal\\batch_data\\mock_covg.csv")
row_num = 0
for row in reader.rows:
    row_num += 1
    print(row)
    if row_num > 10000000:
        break
