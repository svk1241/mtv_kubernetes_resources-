from datetime import datetime

from ..base import BaseInputModel


"""
SELECT CVG_CONTRACT_ID, MEMBER_ID, ALTERNAT_ID_TYP_CD, ALTERNAT_ID_SRC_CD, ALTERNATE_ID, EFFECTIVE_DATE
FROM R210TSTRL.MBR_ALTERNATE_ID
FETCH NEXT 150 ROWS ONLY;
"""


class MaidInput(BaseInputModel):
    CVG_CONTRACT_ID: str
    MEMBER_ID: str
    ALTERNAT_ID_TYP_CD: str
    ALTERNAT_ID_SRC_CD: str
    ALTERNATE_ID: str
    EFFECTIVE_DATE: datetime
