from fields.ccyymmdd import ccyymmdd
from fields.custom import alphanumeric, whitespaces
from models.base import BaseDDMTVModel
from typing_extensions import Literal


class Mbra(BaseDDMTVModel):
    sort_number: Literal["4500"]
    sort_effective_date: ccyymmdd()
    record_type: Literal["MBRA"]
    run_date: ccyymmdd()
    employee_group_level_1_id: alphanumeric(12)
    employee_group_level_2_id: alphanumeric(12)
    contract_id: alphanumeric(16, presented=True)
    member_id: alphanumeric(2, presented=True)
    bypass_process_flag: alphanumeric(1)
    filler_1: whitespaces(32)
    filler_2: whitespaces(2)
    address_line_1: alphanumeric(55, presented=True)
    address_line_2: alphanumeric(55)
    address_line_3: alphanumeric(55)
    city: alphanumeric(30, presented=True)
    state: alphanumeric(2, presented=True)
    zip_code: alphanumeric(15, presented=True)
    county: alphanumeric(3)
    country: alphanumeric(3)
    address_type: alphanumeric(2)
    address_code: alphanumeric(8)
    effective_date: ccyymmdd()
    end_date: ccyymmdd()
    primary_flag: alphanumeric(1)
    filler_3: whitespaces(8)
    shared_addr_flag: alphanumeric(1)
    address_identifier: alphanumeric(12)  # Format: 999999999999
    mail_indicator: alphanumeric(1)
    address_status_code: alphanumeric(2)
