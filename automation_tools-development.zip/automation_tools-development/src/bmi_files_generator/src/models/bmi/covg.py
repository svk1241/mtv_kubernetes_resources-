from fields.ccyymmdd import ccyymmdd
from fields.custom import alphanumeric, whitespaces
from models.base import BaseDDMTVModel
from typing_extensions import Literal


class Covg(BaseDDMTVModel):
    sort_number: Literal["3000"]
    soft_effective_date: ccyymmdd()
    record_type: Literal["COVG"]
    run_date: ccyymmdd()
    empl_group_level_1_id: alphanumeric(12, presented=True)
    empl_group_level_2_id: alphanumeric(12, presented=True)
    contract_id: alphanumeric(16, presented=True)
    member_id: alphanumeric(2)
    bypass_process_flag: Literal["N"]
    filler: whitespaces(32)
    contract_type_code: alphanumeric(4, presented=True)
    effective_date: ccyymmdd(presented=True)
    end_date: ccyymmdd(presented=True)
    disenrollment_reason: alphanumeric(4, presented=True)
    rate_package_id: alphanumeric(4, presented=True)
    terminate_flag: alphanumeric(1)
    reinstate_flag: alphanumeric(1)
    enrollment_type: alphanumeric(2)
    coverage_request_date: ccyymmdd()
    enrollment_event_date: ccyymmdd()
    timely_enrollment_indicator: alphanumeric(1)
    qualifying_event_code: alphanumeric(12)
    notification_date: ccyymmdd()
    special_event: alphanumeric(12)
    business_level_4: alphanumeric(12)
    business_level_5: alphanumeric(12)
    business_level_6: alphanumeric(12)
    business_level_7: alphanumeric(12)
    employee_class_code: alphanumeric(4)
    auto_calculation_flag: alphanumeric(1)  # This field is only used in the MVPPPMIR batch job
    pre_enrollment_indicator: alphanumeric(1)
