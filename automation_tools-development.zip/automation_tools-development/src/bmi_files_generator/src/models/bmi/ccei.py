from fields.ccyymmdd import ccyymmdd
from fields.custom import alphanumeric, fractional, whitespaces 
from models.base import BaseDDMTVModel
from typing_extensions import Literal

class Ccei(BaseDDMTVModel):
    sort_number: Literal["3010"]
    sort_effective_date: ccyymmdd()
    record_type: Literal["CCEI"]
    run_date: ccyymmdd()
    employee_group_level_1_id: alphanumeric(12)
    employee_group_level_2_id:alphanumeric(12)
    contract_id: alphanumeric(16, presented=True)
    member_id: alphanumeric(2)
    pass_process_flag: alphanumeric(1)
    filler: whitespaces(32)
    effective_date: ccyymmdd(presented=True)
    end_date: ccyymmdd()
    employer_reference_id: alphanumeric(12)
    payroll_department_id: alphanumeric(10)
    hire_date: ccyymmdd()
    salary: fractional(int_pt_len=8, frac_pt_lem=2)
    salary_effective_date: ccyymmdd()
    employment_status_code: alphanumeric(4)
    employee_occupation: alphanumeric(50)
    life_volume_amount: fractional(int_pt_len=8, frac_pt_lem=2)
    override_life_volume: fractional(int_pt_len=8, frac_pt_lem=2)
    life_volume_source: alphanumeric(1)
