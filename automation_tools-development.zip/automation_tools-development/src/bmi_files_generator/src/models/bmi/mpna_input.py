from datetime import datetime

from ..base import BaseInputModel

"""
SELECT CONTRACT_ID, MEMBER_ID, EFFECTIVE_DATE, SERVICE_TYPE
FROM R210TSTRL.MBR_PROV_NTWK_ASSN
FETCH NEXT 150 ROWS ONLY;
"""

class MpnaInput(BaseInputModel):
    CONTRACT_ID: str
    MEMBER_ID: str
    SERVICE_TYPE: str
    EFFECTIVE_DATE: datetime
