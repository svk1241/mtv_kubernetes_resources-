from ..base import BaseInputModel


"""
SELECT 
	cei.EMPGRP_LEVEL_1_ID,
	mc.WHO_TYPE_INDICATOR,
	mc.CONTACT_TYPE_CODE,
	mc.LAST_NAME,
	mc.FIRST_NAME 
FROM MEMBER m
JOIN metavance_contact mc ON m.PERSON_ID = mc.who_identifier
JOIN CVRG_EMPLR_INFO cei ON m.CONTRACT_ID = cei.CONTRACT_ID
WHERE cei.EMPGRP_LEVEL_1_ID IS NOT NULL
FETCH NEXT 50 ROWS ONLY;
"""


class ContInput(BaseInputModel):
    EMPGRP_LEVEL_1_ID: str
    WHO_TYPE_INDICATOR: str
    CONTACT_TYPE_CODE: str
    LAST_NAME: str
    FIRST_NAME: str
