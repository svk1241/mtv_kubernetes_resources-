from datetime import datetime

from ..base import BaseInputModel


"""
SELECT CONTRACT_ID, EFFECTIVE_DATE
FROM R210TSTRL.CVRG_EMPLR_INFO
FETCH NEXT 150 ROWS ONLY;
"""

class CceiInput(BaseInputModel):
    CONTRACT_ID: str
    EFFECTIVE_DATE: datetime
