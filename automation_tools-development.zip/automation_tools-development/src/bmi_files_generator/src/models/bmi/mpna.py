from fields.ccyymmdd import ccyymmdd
from fields.custom import alphanumeric, whitespaces
from models.base import BaseDDMTVModel
from typing_extensions import Literal


class Mpna(BaseDDMTVModel):
    sort_number: Literal["4320"]
    sort_effective_date: ccyymmdd()
    record_type: Literal["MPNA"]
    run_date: ccyymmdd()
    employee_group_level_1_id: alphanumeric(12)
    employee_group_level_2_id: alphanumeric(12)
    contract_id: alphanumeric(16, presented=True)
    member_id: alphanumeric(2, presented=True)
    bypass_process_flag: alphanumeric(1)
    filler: whitespaces(32)
    mpna_type: alphanumeric(1, presented=True)
    primary_flag: alphanumeric(1)
    provider_identifier: alphanumeric(12)
    effective_date: ccyymmdd(presented=True)
    end_date: ccyymmdd()
    provider_reason_code: alphanumeric(4)
    continuing_provider_flag: alphanumeric(1)
    network_id: alphanumeric(12)
    override_cutoff: alphanumeric(1)
    override_capacity: alphanumeric(1)
    practice_location: alphanumeric(12)
    practice_location_match_on_spaces_indicator: alphanumeric(1)
    provider_group: alphanumeric(12)
    provider_group_match_on_spaces_indicator: alphanumeric(1)
    provider_organization: alphanumeric(12)
    provider_organization_match_on_spaces_indicator: alphanumeric(1)
