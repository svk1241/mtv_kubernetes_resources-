from fields.ccyymmdd import ccyymmdd
from fields.custom import alphanumeric, whitespaces
from models.base import BaseDDMTVModel
from typing_extensions import Literal


class Maid(BaseDDMTVModel):
    sort_number: Literal["4200"]
    sort_effective_date: ccyymmdd()
    record_type: Literal["MAID"]
    run_date: ccyymmdd()
    employee_group_level_1_id: alphanumeric(12)
    employee_group_level_2_id: alphanumeric(12)
    contract_id: alphanumeric(16, presented=True)
    member_id: alphanumeric(2, presented=True)
    bypass_process_flag: alphanumeric(1)
    filler: whitespaces(32)
    alternate_id_type_code: alphanumeric(4, presented=True)
    alternate_id_source_code: alphanumeric(10, presented=True)
    alternate_id: alphanumeric(25, presented=True)
    effective_date: ccyymmdd(presented=True)
    end_date: ccyymmdd()
