from datetime import datetime

from ..base import BaseInputModel


class CovgInput(BaseInputModel):
    CONTRACT_ID: str
    CONTRACT_TYPE_CD: str
    EFFECTIVE_DATE: datetime
    END_DATE: datetime
    DISENROLL_RESN_CD: str
    RATE_PKG_ID_CD: str
    EMPGRP_LVL_1_ID: str
    EMPGRP_LVL_2_ID: str

