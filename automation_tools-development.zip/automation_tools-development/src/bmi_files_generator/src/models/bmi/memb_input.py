from datetime import datetime

from ..base import BaseInputModel

"""
SELECT m.CONTRACT_ID , m.MEMBER_ID , p.FIRST_NAME , p.LAST_NAME , p.BIRTH_DATE , p.SEX_CODE 
FROM "MEMBER" m
INNER JOIN PERSON p ON p.IDENTIFIER = m.PERSON_ID 
FETCH NEXT 150 ROWS  ONLY ;
"""


class MembInput(BaseInputModel):
    CONTRACT_ID: str
    MEMBER_ID: str
    FIRST_NAME: str
    LAST_NAME: str
    BIRTH_DATE: datetime
    SEX_CODE: str
