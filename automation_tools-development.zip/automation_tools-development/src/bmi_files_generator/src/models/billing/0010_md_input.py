from datetime import datetime

from ..base import BaseInputModel

"""
SELECT 
	END_DATE, 
	CVG_CONT_HLDR_FLAG,
	BUS_LEVEL_4_ID,
	BUS_LEVEL_5_ID,
	BUS_LEVEL_7_ID,
	PRIMARY_BEN_PKG_FG
FROM R210TSTRL.BILNG_MEMBER_DATA
FETCH NEXT 150 ROWS ONLY;
"""


class MemberDetailInput(BaseInputModel):
    END_DATE: datetime
    CVG_CONT_HLDR_FLAG: str
    BUS_LEVEL_4_ID: str
    BUS_LEVEL_5_ID: str
    BUS_LEVEL_7_ID: str
    PRIMARY_BEN_PKG_FG: str
