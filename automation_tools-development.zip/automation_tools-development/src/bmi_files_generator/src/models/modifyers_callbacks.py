from datetime import datetime
from typing import Callable


def datetime_to_ccyymmdd(dt: datetime) -> str:
    return dt.strftime("%Y%m%d")

    
def get_string_slice_with_len(length: int) -> Callable[[str], str]:
    def to_length(value: str) -> str:
        new_val = value[0: length]
        if len(new_val) < length:
            new_val += " " * (length - len(new_val))
        return new_val
    return to_length