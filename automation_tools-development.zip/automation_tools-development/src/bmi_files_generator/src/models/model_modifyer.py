from dataclasses import dataclass
from typing import Any, Callable, Generic, Tuple, TypeVar

from pydantic import BaseModel

K = TypeVar("K")


@dataclass
class FieldModifyer(Generic[K]):
    src_field_name: str
    dst_field_name: str
    modifiyng_callback: Callable[[Any], K]

    def run(self, model: BaseModel) -> Tuple[str, K]:
        field_vaue = getattr(model, self.src_name)
        return self.dst_name, self.modifiyng_callback(field_vaue)
