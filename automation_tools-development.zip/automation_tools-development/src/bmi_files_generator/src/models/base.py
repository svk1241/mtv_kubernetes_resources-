from abc import ABC

from pydantic import BaseModel

from .model_modifyer import FieldModifyer

class BaseDDMTVModel(BaseModel, ABC):
    @classmethod
    def get_field_length(cls, field_name: str) -> int:
        field = cls.__annotations__[field_name]
        try:
            min_length = field.min_length
            max_length = field.max_length
        except AttributeError:
            raise NonLengthAttribute

        if not min_length == max_length:
            raise IncosistentLengtError(f"{min_length=}, {max_length=}")

        return min_length

    def fill_with_whitespace(self, *fields: str) -> None:
        for fld in fields:
            field = getattr(self, fld)
            f_length = self.get_field_length(fld)
            field = " " * f_length
            setattr(self, fld, field)


class BaseInputModel(BaseModel):
    def modify(self, *modifyers: FieldModifyer):
        fields = dict()
        for mf in modifyers:
            dst_name, value = mf.run(self)
            field_modified = {dst_name: value}    
            fields.update(field_modified)
        return fields


class NonLengthAttribute(Exception):
    pass


class IncosistentLengtError(Exception):
    pass
