resource "azurerm_resource_group" "spoke-poc001" {
  location   = local.location
  name       = "rg-spoke-poc001-eastus-private"
  depends_on = [module.hub.kubernetes_dns_zone_id]
}

module "spoke001_networking" {
  source                  = "./modules/spoke-networking-v1"
  resource_group_name     = azurerm_resource_group.spoke-poc001.name
  vnet_cidr_block         = "11.0.0.0/16"
  subnet_cidr_block       = "11.0.1.0/24"
  hub_resource_group_name = azurerm_resource_group.hub.name
  hub_vnet_id             = module.hub.vnet_id
  hub_vnet_name           = module.hub.vnet_name

  dns_zone_name = local.dns_zone_name

  application = "networking"
  environment = "poc001"
  location    = local.location
  visibility  = local.visibility
}
