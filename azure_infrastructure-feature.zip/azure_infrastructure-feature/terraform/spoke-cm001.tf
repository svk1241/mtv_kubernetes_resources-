resource "azurerm_resource_group" "cm_001" {
  location   = local.location
  name       = "rg-cm-001-eastus-private"
  depends_on = [module.hub.kubernetes_dns_zone_id]
}

module "cm_001_networking" {
  source                  = "./modules/spoke-networking-v1"
  resource_group_name     = azurerm_resource_group.cm_001.name
  vnet_cidr_block         = "10.7.0.0/16"
  subnet_cidr_block       = "10.7.0.0/24"
  hub_resource_group_name = azurerm_resource_group.hub.name
  hub_vnet_id             = module.hub.vnet_id
  hub_vnet_name           = module.hub.vnet_name

  dns_zone_name = local.dns_zone_name

  application = "networking"
  environment = "cm0001"
  location    = local.location
  visibility  = local.visibility
}

module "cm-build" {
  source              = "./modules/linux-vm-v2"
  resource_group_name = azurerm_resource_group.cm_001.name
  subnet_id           = module.cm_001_networking.subnet_id
  vm_size             = "Standard_B4ms"
  vm_image            = ["RedHat", "RHEL", "8_3", "latest"]
  secret              = ["rg-service-global", "kv-secrets-eastus-global", "vm-access-v2"]
  name_prefix         = "cm-build"
  instance_count      = 2
  start_count_number  = 1
  assign_public_ip    = true

  application = "build"
  environment = "cm001"
  location    = local.location
  visibility  = local.visibility
}
