module "peering" {
  source   = "./modules/peering-v1"
  vnet_tag = "spoke"
}