this file will be rewrite by CI

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.5.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.74.0 |
| <a name="requirement_random"></a> [random](#requirement\_random) | ~>3.5.1 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 3.74.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_acr"></a> [acr](#module\_acr) | ./modules/acr-v1 | n/a |
| <a name="module_acr_public"></a> [acr\_public](#module\_acr\_public) | ./modules/acr-v2 | n/a |
| <a name="module_aks001_networking"></a> [aks001\_networking](#module\_aks001\_networking) | ./modules/spoke-networking-v1 | n/a |
| <a name="module_aks001_storage"></a> [aks001\_storage](#module\_aks001\_storage) | ./modules/storage-v1 | n/a |
| <a name="module_aks001_tempostorage"></a> [aks001\_tempostorage](#module\_aks001\_tempostorage) | ./modules/storage-v1 | n/a |
| <a name="module_aks002_cluster"></a> [aks002\_cluster](#module\_aks002\_cluster) | ./modules/aks-v1 | n/a |
| <a name="module_aks002_lokistorage"></a> [aks002\_lokistorage](#module\_aks002\_lokistorage) | ./modules/storage-v1 | n/a |
| <a name="module_aks002_networking"></a> [aks002\_networking](#module\_aks002\_networking) | ./modules/spoke-networking-v1 | n/a |
| <a name="module_aks002_nodepools"></a> [aks002\_nodepools](#module\_aks002\_nodepools) | ./modules/node-pool-v1 | n/a |
| <a name="module_aks002_tempostorage"></a> [aks002\_tempostorage](#module\_aks002\_tempostorage) | ./modules/storage-v1 | n/a |
| <a name="module_aks003_lokistorage"></a> [aks003\_lokistorage](#module\_aks003\_lokistorage) | ./modules/storage-v1 | n/a |
| <a name="module_aks003_tempostorage"></a> [aks003\_tempostorage](#module\_aks003\_tempostorage) | ./modules/storage-v1 | n/a |
| <a name="module_auto_test_001_networking"></a> [auto\_test\_001\_networking](#module\_auto\_test\_001\_networking) | ./modules/spoke-networking-v1 | n/a |
| <a name="module_cm-build"></a> [cm-build](#module\_cm-build) | ./modules/linux-vm-v2 | n/a |
| <a name="module_cm_001_networking"></a> [cm\_001\_networking](#module\_cm\_001\_networking) | ./modules/spoke-networking-v1 | n/a |
| <a name="module_concurrency-oracle-database-001"></a> [concurrency-oracle-database-001](#module\_concurrency-oracle-database-001) | ./modules/oracle-db-v2 | n/a |
| <a name="module_dev-backend"></a> [dev-backend](#module\_dev-backend) | ./modules/linux-vm-v2 | n/a |
| <a name="module_dev-oracle-database-001"></a> [dev-oracle-database-001](#module\_dev-oracle-database-001) | ./modules/oracle-db-v2 | n/a |
| <a name="module_development_001_networking"></a> [development\_001\_networking](#module\_development\_001\_networking) | ./modules/spoke-networking-v1 | n/a |
| <a name="module_extensions-oracle-database-001"></a> [extensions-oracle-database-001](#module\_extensions-oracle-database-001) | ./modules/oracle-db-v2 | n/a |
| <a name="module_hub"></a> [hub](#module\_hub) | ./modules/hub-networking-v1 | n/a |
| <a name="module_integration-oracle-database-001"></a> [integration-oracle-database-001](#module\_integration-oracle-database-001) | ./modules/oracle-db-v2 | n/a |
| <a name="module_linux-rdp"></a> [linux-rdp](#module\_linux-rdp) | ./modules/linux-vm-rdp-v1 | n/a |
| <a name="module_mq_instances"></a> [mq\_instances](#module\_mq\_instances) | ./modules/mq-instances-v1 | n/a |
| <a name="module_peering"></a> [peering](#module\_peering) | ./modules/peering-v1 | n/a |
| <a name="module_postgres-db"></a> [postgres-db](#module\_postgres-db) | ./modules/postgres-db-v1 | n/a |
| <a name="module_regression-oracle-database-001"></a> [regression-oracle-database-001](#module\_regression-oracle-database-001) | ./modules/oracle-db-v2 | n/a |
| <a name="module_smb-server"></a> [smb-server](#module\_smb-server) | ./modules/smb-server-v1 | n/a |
| <a name="module_spoke001_networking"></a> [spoke001\_networking](#module\_spoke001\_networking) | ./modules/spoke-networking-v1 | n/a |
| <a name="module_win-gui-dev"></a> [win-gui-dev](#module\_win-gui-dev) | ./modules/windows-vm-auto-v2 | n/a |
| <a name="module_windows-api-proxies"></a> [windows-api-proxies](#module\_windows-api-proxies) | ./modules/windows-vm-auto-v2 | n/a |
| <a name="module_windows-gui-test"></a> [windows-gui-test](#module\_windows-gui-test) | ./modules/windows-vm-auto-v2 | n/a |
| <a name="module_windows-workstation"></a> [windows-workstation](#module\_windows-workstation) | ./modules/windows-vm-auto-v2 | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_proximity_placement_group.ppg-aks-001](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/proximity_placement_group) | resource |
| [azurerm_proximity_placement_group.ppg-automation-testing-001](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/proximity_placement_group) | resource |
| [azurerm_resource_group.automation-testing-001](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.cm_001](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.hub](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.spoke-aks001](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.spoke-dev-001](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.spoke-poc001](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |

## Inputs

No inputs.

## Outputs

No outputs.
<!-- END_TF_DOCS -->