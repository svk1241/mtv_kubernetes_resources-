#!/bin/sh
sudo yum -y update
cd /tmp
wget https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
sudo yum install -y epel-release-latest-7.noarch.rpm
sudo yum install -y xorg-x11-server-Xvfb
sudo yum install -y xdotool
sudo yum install -y freerdp
