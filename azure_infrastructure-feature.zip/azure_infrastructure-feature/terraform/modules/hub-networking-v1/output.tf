output "vnet_name" {
  value = azurerm_virtual_network.this.name
}

output "vnet_id" {
  value = azurerm_virtual_network.this.id
}

output "dns_zone_id" {
  value = azurerm_private_dns_zone.this.id
}

output "kubernetes_dns_zone_id" {
  value = azurerm_private_dns_zone.kubernetes.id
}

