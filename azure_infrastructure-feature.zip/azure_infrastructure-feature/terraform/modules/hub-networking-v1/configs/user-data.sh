#!/bin/sh

sudo cat > /etc/bind/named.conf.options << END
acl goodclients {
    10.0.0.0/16;
    0.0.0.0/0;
    localhost;
    localnets;
};
options {
        directory "/var/cache/bind";
        recursion yes;
        allow-query { goodclients; };
        forwarders {
            168.63.129.16;
        };
        forward only;
        dnssec-validation no;
        auth-nxdomain no;    # conform to RFC1035
        listen-on { any; };
};
END

sudo service bind9 restart