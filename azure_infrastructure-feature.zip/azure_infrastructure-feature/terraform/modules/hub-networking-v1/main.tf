module "subnet_addrs" {
  source = "hashicorp/subnets/cidr"

  base_cidr_block = var.vnet_cidr_block
  networks = [
    {
      name     = "SharedServicesSubnet"
      new_bits = 8
    },
    {
      name     = "AzureFirewallSubnet"
      new_bits = 10
    },
    {
      name     = "AzureBastionSubnet"
      new_bits = 11
    },
    {
      name     = "GatewaySubnet"
      new_bits = 8
    },
  ]
}

resource "azurerm_virtual_network" "this" {
  address_space       = [var.vnet_cidr_block]
  location            = var.location
  name                = module.naming.virtual_network.name
  resource_group_name = var.resource_group_name
  dns_servers         = var.dns_servers

  tags = {
    team           = "cm"
    realm          = "hub"
    resource_group = var.resource_group_name
    region         = var.location
  }
}

resource "azurerm_subnet" "SharedServicesSubnet" {
  name                 = "SharedServicesSubnet"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.this.name
  address_prefixes     = [module.subnet_addrs.network_cidr_blocks["SharedServicesSubnet"]]
}

resource "azurerm_subnet" "AzureBastionSubnet" {
  name                 = "AzureBastionSubnet"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.this.name
  address_prefixes     = [module.subnet_addrs.network_cidr_blocks["AzureBastionSubnet"]]
}

resource "azurerm_subnet" "GatewaySubnet" {
  name                 = "GatewaySubnet"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.this.name
  address_prefixes     = [module.subnet_addrs.network_cidr_blocks["GatewaySubnet"]]
}

resource "azurerm_public_ip" "bastion-public-ip" {
  name                = "pip-bastion-hub-eastus-public"
  location            = var.location
  resource_group_name = var.resource_group_name
  allocation_method   = "Static"
  sku                 = "Standard"
  zones               = ["1", "2", "3"]
}

resource "azurerm_public_ip" "vpn-public-ip" {
  name                = "pip-vpn-hub-eastus-public"
  location            = var.location
  resource_group_name = var.resource_group_name
  allocation_method   = "Static"
  sku                 = "Standard"
  zones               = ["1", "2", "3"]
}

resource "azurerm_bastion_host" "this" {
  name                = "bh-bastionhost-hub-eastus-public"
  location            = var.location
  resource_group_name = var.resource_group_name

  ip_configuration {
    name                 = "main"
    subnet_id            = azurerm_subnet.AzureBastionSubnet.id
    public_ip_address_id = azurerm_public_ip.bastion-public-ip.id
  }
}

data "azurerm_key_vault" "this" {
  resource_group_name = var.secret[0]
  name                = var.secret[1]
}

data "azurerm_key_vault_secret" "this" {
  name         = var.secret[2]
  key_vault_id = data.azurerm_key_vault.this.id
}

resource "azurerm_virtual_network_gateway" "this" {
  name                = module.naming.virtual_network_gateway.name
  location            = var.location
  resource_group_name = var.resource_group_name
  type                = "Vpn"
  vpn_type            = "RouteBased"
  active_active       = false
  enable_bgp          = false
  sku                 = "VpnGw1"

  ip_configuration {
    name                          = "vnetGatewayConfig"
    public_ip_address_id          = azurerm_public_ip.vpn-public-ip.id
    private_ip_address_allocation = "Dynamic"
    subnet_id                     = azurerm_subnet.GatewaySubnet.id
  }
  vpn_client_configuration {
    address_space = ["10.2.0.0/24"]
    aad_tenant    = jsondecode(data.azurerm_key_vault_secret.this.value)["tenant"]
    aad_audience  = jsondecode(data.azurerm_key_vault_secret.this.value)["audience"]
    aad_issuer    = jsondecode(data.azurerm_key_vault_secret.this.value)["uri"]
  }
  depends_on = [azurerm_public_ip.vpn-public-ip]
}

# Kubernetes DNS Creation

resource "azurerm_private_dns_zone" "kubernetes" {
  name                = "privatelink.eastus.azmk8s.io"
  resource_group_name = var.resource_group_name
}

resource "azurerm_private_dns_zone_virtual_network_link" "kubernetes" {
  name                  = azurerm_virtual_network.this.name
  resource_group_name   = var.resource_group_name
  private_dns_zone_name = azurerm_private_dns_zone.kubernetes.name
  virtual_network_id    = azurerm_virtual_network.this.id
  registration_enabled  = false
}

# DNS Creation

resource "azurerm_private_dns_zone" "this" {
  name                = var.dns_zone_name
  resource_group_name = var.resource_group_name
  tags = {
    team           = "cm"
    realm          = "hub"
    resource_group = var.resource_group_name
    region         = var.location
    type           = "private_dns_zone"
  }
}

resource "azurerm_private_dns_zone_virtual_network_link" "this" {
  name                  = azurerm_virtual_network.this.name
  resource_group_name   = var.resource_group_name
  private_dns_zone_name = azurerm_private_dns_zone.this.name
  virtual_network_id    = azurerm_virtual_network.this.id
  registration_enabled  = false
}

resource "azurerm_network_interface" "dns-nic" {
  name                = "nic-dns-hub-eastus-global"
  resource_group_name = var.resource_group_name
  location            = var.location

  ip_configuration {
    name                          = "primary"
    subnet_id                     = azurerm_subnet.SharedServicesSubnet.id
    private_ip_address_allocation = "Static"
    private_ip_address            = var.dns_servers[0]
  }
}

resource "azurerm_network_security_group" "dns-nsg" {
  name                = "nsg-dns-hub-eastus-global"
  location            = var.location
  resource_group_name = var.resource_group_name
  security_rule {
    access                     = "Allow"
    direction                  = "Inbound"
    name                       = "DNS"
    priority                   = 1010
    protocol                   = "*"
    source_port_range          = "*"
    source_address_prefix      = "*"
    destination_port_range     = "53"
    destination_address_prefix = azurerm_network_interface.dns-nic.private_ip_address
  }

  security_rule {
    access                     = "Allow"
    direction                  = "Inbound"
    name                       = "Webmin_Portal"
    priority                   = 1020
    protocol                   = "Tcp"
    source_port_range          = "*"
    source_address_prefix      = "*"
    destination_port_range     = "10000"
    destination_address_prefix = azurerm_network_interface.dns-nic.private_ip_address
  }

  security_rule {
    access                     = "Allow"
    direction                  = "Inbound"
    name                       = "SSH"
    priority                   = 110
    protocol                   = "Tcp"
    source_port_range          = "*"
    source_address_prefix      = "*"
    destination_port_range     = "22"
    destination_address_prefix = azurerm_network_interface.dns-nic.private_ip_address
  }
}

resource "azurerm_network_interface_security_group_association" "main" {
  network_interface_id      = azurerm_network_interface.dns-nic.id
  network_security_group_id = azurerm_network_security_group.dns-nsg.id
}

data "azurerm_key_vault" "this_hub" {
  resource_group_name = var.secret[0]
  name                = var.secret[1]
}

data "azurerm_key_vault_secret" "this_hub" {
  name         = var.secret[3]
  key_vault_id = data.azurerm_key_vault.this_hub.id
}

resource "azurerm_linux_virtual_machine" "dns-server" {
  name                            = "vm-dns-hub-eastus-global"
  resource_group_name             = var.resource_group_name
  location                        = var.location
  size                            = "Standard_B2s"
  admin_username                  = jsondecode(data.azurerm_key_vault_secret.this_hub.value)["user"]
  admin_password                  = jsondecode(data.azurerm_key_vault_secret.this_hub.value)["password"] # pragma: allowlist secret
  disable_password_authentication = false
  custom_data                     = filebase64("${path.module}/configs/user-data.sh")

  network_interface_ids = [
    azurerm_network_interface.dns-nic.id,
  ]

  source_image_reference {
    publisher = "cloud-infrastructure-services"
    offer     = "dns-ubuntu-2004"
    sku       = "dns-ubuntu-2004"
    version   = "latest"
  }

  plan {
    name      = "dns-ubuntu-2004"
    product   = "dns-ubuntu-2004"
    publisher = "cloud-infrastructure-services"
  }

  os_disk {
    storage_account_type = "Standard_LRS"
    caching              = "ReadWrite"
  }
}

module "naming" {
  source = "git::ssh://git@luxproject.luxoft.com:7999/ddmtv/terraform-azurerm-naming.git"
  suffix = [var.application, var.environment, var.location, var.visibility]
}
