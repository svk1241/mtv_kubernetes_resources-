variable "diagnostics_setting_name" {
  description = "Name of diagnostics setting visible in Azure portal"
  type        = string
}

variable "cluster_id" {
  description = "ID of AKS cluster to setup diagnostics"
  type        = string
}

variable "log_analytics_workspace_id" {
  description = "ID of log analytics workspace to setup diagnostics"
  type        = string
}

variable "retention_in_days" {
  description = "Days to retain logs in log analytics"
  type        = number
  default     = 90
}
