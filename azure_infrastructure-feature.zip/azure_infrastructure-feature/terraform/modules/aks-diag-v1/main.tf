resource "azurerm_monitor_diagnostic_setting" "this" {
  name                       = var.diagnostics_setting_name
  target_resource_id         = var.cluster_id
  log_analytics_workspace_id = var.log_analytics_workspace_id
  enabled_log {
    category = "kube-apiserver"
    retention_policy {
      days    = var.retention_in_days
      enabled = true
    }
  }
  enabled_log {
    category = "kube-audit-admin"
    retention_policy {
      days    = var.retention_in_days
      enabled = true
    }
  }
  enabled_log {
    category = "kube-controller-manager"
    retention_policy {
      days    = var.retention_in_days
      enabled = true
    }
  }
  enabled_log {
    category = "cluster-autoscaler"
    retention_policy {
      days    = var.retention_in_days
      enabled = true
    }
  }
  enabled_log {
    category = "cloud-controller-manager"
    retention_policy {
      days    = var.retention_in_days
      enabled = false
    }
  }
  metric {
    category = "AllMetrics"
    retention_policy {
      days    = var.retention_in_days
      enabled = true
    }
  }
}