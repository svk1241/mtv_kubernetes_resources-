variable "resource_group_name" {
  type        = string
  description = "Resourse group to create machines in"
}

variable "vm_size" {
  type        = string
  description = "Azure Size of VMs to create"
}

variable "vm_image" {
  type        = list(any)
  description = "List which contains [publisher, offer, sku, version] of required VM image"
}
variable "subnet_id" {
  type        = string
  description = "ID of Azure Subnet to connect network interface"
}

variable "secret" {
  type        = list(any)
  description = "List which contains [akv_resource_group_name, akv_name, secret_name] of secret which contains admin credentials to setup"
}

variable "application" {
  type        = string
  description = "Name of application which machines will be running"
}

variable "environment" {
  type        = string
  description = "Name of environment which machines will be running"
}

variable "location" {
  type        = string
  description = "Name of Azure Location to create machines in"
}

variable "visibility" {
  type        = string
  description = "Some string parameter to be included into name of machines, for example: private"
}

variable "name_prefix" {
  type        = string
  description = "Prefix for machine names"
}

variable "instance_count" {
  type        = number
  description = "Specify how many machines to create"
}

variable "start_count_number" {
  type        = number
  description = "Specify to count machines from certain number"
}

variable "ppg_id" {
  type        = string
  description = "Provide Proximity Placement Group if required"
  default     = ""
}

variable "use_accelerated_networking" {
  type        = bool
  description = "Specify to enable accelerated networking for machines or not"
  default     = false
}

variable "assign_public_ip" {
  type        = bool
  description = "Specify to assign public IP addresses for machines or not"
  default     = false
}
