<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_naming"></a> [naming](#module\_naming) | github.com/Azure/terraform-azurerm-naming | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_linux_virtual_machine.main](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/linux_virtual_machine) | resource |
| [azurerm_managed_disk.opt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/managed_disk) | resource |
| [azurerm_network_interface.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface) | resource |
| [azurerm_network_interface_security_group_association.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_security_group_association) | resource |
| [azurerm_network_security_group.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_public_ip.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_virtual_machine_data_disk_attachment.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_data_disk_attachment) | resource |
| [azurerm_key_vault.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/key_vault) | data source |
| [azurerm_key_vault_secret.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/key_vault_secret) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_application"></a> [application](#input\_application) | Name of application which machines will be running | `string` | n/a | yes |
| <a name="input_assign_public_ip"></a> [assign\_public\_ip](#input\_assign\_public\_ip) | Specify to assign public IP addresses for machines or not | `bool` | `false` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | Name of environment which machines will be running | `string` | n/a | yes |
| <a name="input_instance_count"></a> [instance\_count](#input\_instance\_count) | Specify how many machines to create | `number` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | Name of Azure Location to create machines in | `string` | n/a | yes |
| <a name="input_name_prefix"></a> [name\_prefix](#input\_name\_prefix) | Prefix for machine names | `string` | n/a | yes |
| <a name="input_ppg_id"></a> [ppg\_id](#input\_ppg\_id) | Provide Proximity Placement Group if required | `string` | `""` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | Resourse group to create machines in | `string` | n/a | yes |
| <a name="input_secret"></a> [secret](#input\_secret) | List which contains [akv\_resource\_group\_name, akv\_name, secret\_name] of secret which contains admin credentials to setup | `list(any)` | n/a | yes |
| <a name="input_start_count_number"></a> [start\_count\_number](#input\_start\_count\_number) | Specify to count machines from certain number | `number` | n/a | yes |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | ID of Azure Subnet to connect network interface | `string` | n/a | yes |
| <a name="input_use_accelerated_networking"></a> [use\_accelerated\_networking](#input\_use\_accelerated\_networking) | Specify to enable accelerated networking for machines or not | `bool` | `false` | no |
| <a name="input_visibility"></a> [visibility](#input\_visibility) | Some string parameter to be included into name of machines, for example: private | `string` | n/a | yes |
| <a name="input_vm_image"></a> [vm\_image](#input\_vm\_image) | List which contains [publisher, offer, sku, version] of required VM image | `list(any)` | n/a | yes |
| <a name="input_vm_size"></a> [vm\_size](#input\_vm\_size) | Azure Size of VMs to create | `string` | n/a | yes |

## Outputs

No outputs.
<!-- END_TF_DOCS -->