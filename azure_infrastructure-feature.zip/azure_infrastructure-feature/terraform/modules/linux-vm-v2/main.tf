module "naming" {
  source = "github.com/Azure/terraform-azurerm-naming"
  suffix = [var.application, var.environment, var.location, var.visibility]
}

resource "azurerm_public_ip" "this" {
  count               = var.assign_public_ip ? var.instance_count : 0
  name                = format("%s-%03d", module.naming.public_ip.name_unique, count.index + 1)
  location            = var.location
  resource_group_name = var.resource_group_name
  allocation_method   = "Dynamic"
  lifecycle {
    create_before_destroy = true
  }
}

resource "azurerm_network_interface" "this" {
  name                          = format("%s-%03d", module.naming.network_interface.name_unique, count.index + 1)
  location                      = var.location
  resource_group_name           = var.resource_group_name
  count                         = var.instance_count
  enable_accelerated_networking = var.use_accelerated_networking

  ip_configuration {
    name                          = module.naming.public_ip.name_unique
    subnet_id                     = var.subnet_id
    private_ip_address_allocation = "Dynamic"
    public_ip_address_id          = var.assign_public_ip ? azurerm_public_ip.this[count.index].id : null
  }
}

resource "azurerm_network_security_group" "this" {
  count               = var.assign_public_ip ? 1 : 0
  name                = module.naming.network_security_group.name_unique
  location            = var.location
  resource_group_name = var.resource_group_name

  security_rule {
    name                       = "Internal"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "10.0.0.0/8"
    destination_address_prefix = "*"
  }
}

resource "azurerm_network_interface_security_group_association" "this" {
  count                     = var.assign_public_ip ? var.instance_count : 0
  network_interface_id      = azurerm_network_interface.this[count.index].id
  network_security_group_id = azurerm_network_security_group.this[0].id
}

data "azurerm_key_vault" "this" {
  resource_group_name = var.secret[0]
  name                = var.secret[1]
}

data "azurerm_key_vault_secret" "this" {
  name         = var.secret[2]
  key_vault_id = data.azurerm_key_vault.this.id
}


resource "azurerm_linux_virtual_machine" "main" {
  name                            = format("%s-%03d", module.naming.linux_virtual_machine.name, count.index + var.start_count_number)
  computer_name                   = format("%s-%03d", var.name_prefix, count.index + var.start_count_number)
  resource_group_name             = var.resource_group_name
  location                        = var.location
  size                            = var.vm_size
  admin_username                  = jsondecode(data.azurerm_key_vault_secret.this.value)["user"]
  admin_password                  = jsondecode(data.azurerm_key_vault_secret.this.value)["password"] # pragma: allowlist secret
  count                           = var.instance_count
  disable_password_authentication = false

  proximity_placement_group_id = var.ppg_id != "" ? var.ppg_id : null


  network_interface_ids = [
    azurerm_network_interface.this[count.index].id,
  ]

  source_image_reference {
    publisher = var.vm_image[0]
    offer     = var.vm_image[1]
    sku       = var.vm_image[2]
    version   = var.vm_image[3]
  }

  os_disk {
    storage_account_type = "Standard_LRS"
    caching              = "ReadWrite"
  }
}

resource "azurerm_managed_disk" "opt" {
  name                 = "${azurerm_linux_virtual_machine.main[count.index].name}-disk1"
  location             = var.location
  resource_group_name  = var.resource_group_name
  storage_account_type = "Standard_LRS"
  create_option        = "Empty"
  disk_size_gb         = 128
  count                = var.instance_count
}

resource "azurerm_virtual_machine_data_disk_attachment" "this" {
  managed_disk_id    = azurerm_managed_disk.opt[count.index].id
  virtual_machine_id = azurerm_linux_virtual_machine.main[count.index].id
  lun                = "0"
  caching            = "ReadWrite"
  count              = var.instance_count
}
