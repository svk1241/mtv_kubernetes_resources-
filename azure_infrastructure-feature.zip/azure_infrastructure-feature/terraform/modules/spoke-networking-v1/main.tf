resource "azurerm_virtual_network" "this" {
  address_space       = [var.vnet_cidr_block]
  location            = var.location
  name                = module.naming.virtual_network.name
  resource_group_name = var.resource_group_name

  tags = {
    team           = "development"
    realm          = "spoke"
    resource_group = var.resource_group_name
    region         = var.location
  }
}

resource "azurerm_virtual_network_peering" "spoke_to_hub" {
  name                         = "peering-to-hub"
  resource_group_name          = var.resource_group_name
  virtual_network_name         = azurerm_virtual_network.this.name
  remote_virtual_network_id    = var.hub_vnet_id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  allow_gateway_transit        = false
  use_remote_gateways          = true

  depends_on = [azurerm_virtual_network_peering.hub_to_spoke]
}

resource "azurerm_virtual_network_peering" "hub_to_spoke" {
  name                         = "peering-to-spoke-${azurerm_virtual_network.this.name}"
  resource_group_name          = var.hub_resource_group_name
  virtual_network_name         = var.hub_vnet_name
  remote_virtual_network_id    = azurerm_virtual_network.this.id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  allow_gateway_transit        = true
}

resource "azurerm_subnet" "this" {
  name                                           = module.naming.subnet.name_unique
  resource_group_name                            = var.resource_group_name
  virtual_network_name                           = azurerm_virtual_network.this.name
  address_prefixes                               = [var.subnet_cidr_block]
  enforce_private_link_endpoint_network_policies = var.enforce_private_link_endpoint_network_policies
  service_endpoints                              = var.subnet_service_endpoints
}

resource "azurerm_private_dns_zone_virtual_network_link" "this" {
  name                  = azurerm_virtual_network.this.name
  resource_group_name   = var.hub_resource_group_name
  private_dns_zone_name = var.dns_zone_name
  virtual_network_id    = azurerm_virtual_network.this.id
  registration_enabled  = true
}

resource "azurerm_private_dns_zone_virtual_network_link" "kubernetes" {
  count                 = var.is_aks_vnet ? 0 : 1
  name                  = azurerm_virtual_network.this.name
  resource_group_name   = var.hub_resource_group_name
  private_dns_zone_name = "privatelink.eastus.azmk8s.io"
  virtual_network_id    = azurerm_virtual_network.this.id
  registration_enabled  = false
}

module "naming" {
  source = "git::ssh://git@luxproject.luxoft.com:7999/ddmtv/terraform-azurerm-naming.git"
  suffix = [var.application, var.environment, var.location, var.visibility]
}
