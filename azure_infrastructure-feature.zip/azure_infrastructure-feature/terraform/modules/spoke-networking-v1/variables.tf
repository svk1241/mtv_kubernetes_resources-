variable "resource_group_name" { type = string }
variable "vnet_cidr_block" { type = string }
variable "subnet_cidr_block" { type = string }

variable "hub_resource_group_name" { type = string }
variable "hub_vnet_name" { type = string }
variable "hub_vnet_id" { type = string }

variable "dns_zone_name" { type = string }

variable "is_aks_vnet" {
  type    = bool
  default = false
}

variable "application" { type = string }
variable "environment" { type = string }
variable "location" { type = string }
variable "visibility" { type = string }

variable "enforce_private_link_endpoint_network_policies" {
  type    = bool
  default = false
}

variable "subnet_service_endpoints" {
  description = "subnet service_endpoints"
  type        = list(string)
  default     = []
}
