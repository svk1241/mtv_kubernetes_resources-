
resource "azurerm_network_interface" "linux_nic" {
  name                          = "mqseries145"
  location                      = var.location
  resource_group_name           = var.resource_group_name
  enable_accelerated_networking = var.use_accelerated_networking

  ip_configuration {
    name                          = "ipconfig1"
    subnet_id                     = var.subnet_id
    private_ip_address_allocation = "Dynamic"
  }
}

resource "azurerm_network_interface" "win_nic" {
  name                          = "win-2016225"
  location                      = var.location
  resource_group_name           = var.resource_group_name
  enable_accelerated_networking = var.use_accelerated_networking

  ip_configuration {
    name                          = "ipconfig1"
    subnet_id                     = var.subnet_id
    private_ip_address_allocation = "Dynamic"
  }
}

data "azurerm_key_vault" "this" {
  resource_group_name = var.secret[0]
  name                = var.secret[1]
}

data "azurerm_key_vault_secret" "this" {
  name         = var.secret[2]
  key_vault_id = data.azurerm_key_vault.this.id
}

resource "azurerm_linux_virtual_machine" "main" {
  name                            = "mqseries"
  computer_name                   = "mqseries"
  resource_group_name             = var.resource_group_name
  location                        = var.location
  size                            = var.vm_size
  admin_username                  = jsondecode(data.azurerm_key_vault_secret.this.value)["user"]
  admin_password                  = jsondecode(data.azurerm_key_vault_secret.this.value)["password"] # pragma: allowlist secret
  disable_password_authentication = false

  proximity_placement_group_id = var.ppg_id != "" ? var.ppg_id : null


  network_interface_ids = [
    azurerm_network_interface.linux_nic.id,
  ]

  source_image_reference {
    publisher = var.linux_image[0]
    offer     = var.linux_image[1]
    sku       = var.linux_image[2]
    version   = var.linux_image[3]
  }

  os_disk {
    storage_account_type = "Standard_LRS"
    caching              = "ReadWrite"
  }
}

resource "azurerm_windows_virtual_machine" "win-vm" {
  name                = "win-2016"
  computer_name       = "win-2016"
  resource_group_name = var.resource_group_name
  location            = var.location
  size                = var.vm_size
  admin_username      = jsondecode(data.azurerm_key_vault_secret.this.value)["user"]
  admin_password      = jsondecode(data.azurerm_key_vault_secret.this.value)["password"] # pragma: allowlist-secret varable, not a secret

  network_interface_ids = [
    azurerm_network_interface.win_nic.id,
  ]

  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "Standard_LRS"
  }

  source_image_reference {
    publisher = var.win_image[0]
    offer     = var.win_image[1]
    sku       = var.win_image[2]
    version   = var.win_image[3]
  }
}

resource "azurerm_managed_disk" "linuxdisk" {
  name                 = "mqseries_DataDisk_0"
  location             = var.location
  resource_group_name  = var.resource_group_name
  storage_account_type = "Standard_LRS"
  create_option        = "Empty"
  disk_size_gb         = var.disk_size
}

resource "azurerm_virtual_machine_data_disk_attachment" "this" {
  managed_disk_id    = azurerm_managed_disk.linuxdisk.id
  virtual_machine_id = azurerm_linux_virtual_machine.main.id
  lun                = "1"
  caching            = "None"
  count              = var.instance_count
}


