variable "name" {
  description = "arc resource name"
  type        = string
}

variable "resource_group_name" {
  description = "resource_group name"
  type        = string
}

variable "location" {
  description = "acr location"
  type        = string
  default     = "eastus"
}

variable "sku" {
  description = "acr sku - Basic | Standard | Premium"
  type        = string
  default     = "Standard"
}

variable "public_network_access_enabled" {
  description = "acr - is public network access enabled"
  type        = bool
  default     = false
}

variable "admin_enabled" {
  description = "acr - is admin user enabled"
  type        = bool
  default     = false
}

variable "retention_policy" {
  description = "acr retention_policy"
  type = object({
    days    = number
    enabled = bool
  })

  default = {
    days    = 7
    enabled = true
  }
}

variable "network_rule_set" {
  description = "acr network_rule_set for subnetes / ip ranges"
  type = object({
    subnet_ids = list(string)
    ip_ranges  = list(string)
  })

  default = {
    subnet_ids = []
    ip_ranges  = []
  }
}

variable "users" {
  description = "acr additional users"
  type = list(object({
    username    = string
    permissions = string # permissions can be 'admin', 'pull', 'push'
  }))

  default = []
}

variable "roles_assignment" {
  description = "acr roles assignment"
  type = list(object({
    role      = string # role can be 'AcrPush', 'AcrPull', 'AcrDelete'
    client_id = string
  }))

  default = []
}

variable "tags" {
  description = "default resource tags"
  type        = map(string)
  default = {
    created_by = "terraform"
  }
}
