<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_container_registry.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/container_registry) | resource |
| [azurerm_container_registry_token.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/container_registry_token) | resource |
| [azurerm_role_assignment.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_container_registry_scope_map.admin](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/container_registry_scope_map) | data source |
| [azurerm_container_registry_scope_map.pull](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/container_registry_scope_map) | data source |
| [azurerm_container_registry_scope_map.push](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/container_registry_scope_map) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_admin_enabled"></a> [admin\_enabled](#input\_admin\_enabled) | acr - is admin user enabled | `bool` | `false` | no |
| <a name="input_location"></a> [location](#input\_location) | acr location | `string` | `"eastus"` | no |
| <a name="input_name"></a> [name](#input\_name) | arc resource name | `string` | n/a | yes |
| <a name="input_network_rule_set"></a> [network\_rule\_set](#input\_network\_rule\_set) | acr network\_rule\_set for subnetes / ip ranges | <pre>object({<br>    subnet_ids = list(string)<br>    ip_ranges  = list(string)<br>  })</pre> | <pre>{<br>  "ip_ranges": [],<br>  "subnet_ids": []<br>}</pre> | no |
| <a name="input_public_network_access_enabled"></a> [public\_network\_access\_enabled](#input\_public\_network\_access\_enabled) | acr - is public network access enabled | `bool` | `false` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | resource\_group name | `string` | n/a | yes |
| <a name="input_retention_policy"></a> [retention\_policy](#input\_retention\_policy) | acr retention\_policy | <pre>object({<br>    days    = number<br>    enabled = bool<br>  })</pre> | <pre>{<br>  "days": 7,<br>  "enabled": true<br>}</pre> | no |
| <a name="input_roles_assignment"></a> [roles\_assignment](#input\_roles\_assignment) | acr roles assignment | <pre>list(object({<br>    role      = string # role can be 'AcrPush', 'AcrPull', 'AcrDelete'<br>    client_id = string<br>  }))</pre> | `[]` | no |
| <a name="input_sku"></a> [sku](#input\_sku) | acr sku - Basic \| Standard \| Premium | `string` | `"Standard"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | default resource tags | `map(string)` | <pre>{<br>  "created_by": "terraform"<br>}</pre> | no |
| <a name="input_users"></a> [users](#input\_users) | acr additional users | <pre>list(object({<br>    username    = string<br>    permissions = string # permissions can be 'admin', 'pull', 'push'<br>  }))</pre> | `[]` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_acr_admin_connection_string"></a> [acr\_admin\_connection\_string](#output\_acr\_admin\_connection\_string) | acr admin connection string |
| <a name="output_acr_users_connection_string"></a> [acr\_users\_connection\_string](#output\_acr\_users\_connection\_string) | acr users connection string |
<!-- END_TF_DOCS -->