resource "azurerm_container_registry" "this" {
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  sku                 = var.sku
  admin_enabled       = var.admin_enabled

  retention_policy {
    days    = var.retention_policy.days
    enabled = var.retention_policy.enabled
  }

  network_rule_set {
    default_action = length(var.network_rule_set.ip_ranges) > 0 || length(var.network_rule_set.subnet_ids) > 0 ? "Deny" : "Allow"

    ip_rule = [
      for ip in var.network_rule_set.ip_ranges : {
        action   = "Allow"
        ip_range = ip
      }
    ]

    virtual_network = [
      for subnet in var.network_rule_set.subnet_ids : {
        action    = "Allow"
        subnet_id = subnet
      }
    ]
  }

  tags = var.tags
}
