resource "azurerm_role_assignment" "this" {
  count                = length(var.roles_assignment)
  scope                = azurerm_container_registry.this.id
  role_definition_name = var.roles_assignment[count.index].role
  principal_id         = var.roles_assignment[count.index].client_id

  depends_on = [
    azurerm_container_registry.this
  ]
}
