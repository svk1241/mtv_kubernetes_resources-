output "acr_admin_connection_string" {
  description = "acr admin connection string"
  value       = "docker login -u ${azurerm_container_registry.this.admin_username} -p ${azurerm_container_registry.this.admin_password} ${azurerm_container_registry.this.login_server}"
}

output "acr_users_connection_string" {
  description = "acr users connection string"
  value = [
    for user in var.users :
    "docker login -u ${user.username} -p please-check-the-token-at-portal ${azurerm_container_registry.this.login_server}"
  ]
}
