data "azurerm_container_registry_scope_map" "admin" {
  name                    = "_repositories_admin"
  resource_group_name     = var.resource_group_name
  container_registry_name = var.name
  depends_on              = [azurerm_container_registry.this]
}

data "azurerm_container_registry_scope_map" "pull" {
  name                    = "_repositories_pull"
  resource_group_name     = var.resource_group_name
  container_registry_name = var.name
  depends_on              = [azurerm_container_registry.this]
}

data "azurerm_container_registry_scope_map" "push" {
  name                    = "_repositories_push"
  resource_group_name     = var.resource_group_name
  container_registry_name = var.name
  depends_on              = [azurerm_container_registry.this]
}

locals {
  scopes = {
    admin = data.azurerm_container_registry_scope_map.admin.id
    pull  = data.azurerm_container_registry_scope_map.pull.id
    push  = data.azurerm_container_registry_scope_map.push.id
  }
}

resource "azurerm_container_registry_token" "this" {
  count                   = length(var.users)
  name                    = var.users[count.index].username
  container_registry_name = var.name
  resource_group_name     = var.resource_group_name
  scope_map_id            = local.scopes[var.users[count.index].permissions]
  depends_on = [
    data.azurerm_container_registry_scope_map.admin,
    data.azurerm_container_registry_scope_map.pull,
    data.azurerm_container_registry_scope_map.push,
  ]
}
