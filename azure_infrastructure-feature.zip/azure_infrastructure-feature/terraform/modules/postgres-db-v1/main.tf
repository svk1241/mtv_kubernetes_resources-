module "naming" {
  source = "github.com/Azure/terraform-azurerm-naming"
  suffix = [var.application, var.environment, var.location, var.visibility]
}

resource "azurerm_subnet" "example" {
  name                 = "postgres-subnet"
  resource_group_name  = var.resource_group_name
  virtual_network_name = var.vnet_name
  address_prefixes     = [var.prefix]

  enforce_private_link_endpoint_network_policies = true
}

data "azurerm_key_vault" "this" {
  resource_group_name = var.secret[0]
  name                = var.secret[1]
}

data "azurerm_key_vault_secret" "this" {
  name         = var.secret[2]
  key_vault_id = data.azurerm_key_vault.this.id
}

resource "azurerm_postgresql_server" "example" {
  name                             = module.naming.linux_virtual_machine.name_unique
  location                         = var.location
  resource_group_name              = var.resource_group_name
  ssl_minimal_tls_version_enforced = "TLSEnforcementDisabled"

  administrator_login          = jsondecode(data.azurerm_key_vault_secret.this.value)["user"]
  administrator_login_password = jsondecode(data.azurerm_key_vault_secret.this.value)["password"] # pragma: allowlist secret

  sku_name   = var.db_image[0]
  version    = var.db_image[1]
  storage_mb = var.storage

  backup_retention_days        = var.db_specs[0]
  geo_redundant_backup_enabled = var.db_specs[1]
  auto_grow_enabled            = var.db_specs[2]

  public_network_access_enabled = true
  ssl_enforcement_enabled       = false
}

resource "azurerm_private_endpoint" "example" {
  name                = module.naming.private_endpoint.name_unique
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = azurerm_subnet.example.id

  private_service_connection {
    name                           = azurerm_postgresql_server.example.name
    private_connection_resource_id = azurerm_postgresql_server.example.id
    subresource_names              = ["postgresqlServer"]
    is_manual_connection           = false
  }
}

resource "azurerm_postgresql_database" "this" {
  for_each            = var.db_instances
  name                = each.key
  resource_group_name = var.resource_group_name
  server_name         = azurerm_postgresql_server.example.name
  charset             = "UTF8"
  collation           = "English_United States.1252"
}

resource "azurerm_data_protection_backup_vault" "this" {
  name                = var.backup_vault_name
  resource_group_name = var.resource_group_name
  location            = var.location
  datastore_type      = "VaultStore"
  redundancy          = "LocallyRedundant"

  identity {
    type = "SystemAssigned"
  }
}

resource "azurerm_key_vault_secret" "pg_access" {
  name         = var.secret[3]
  value        = "User ID=${jsondecode(data.azurerm_key_vault_secret.this.value)["user"]};Password=${jsondecode(data.azurerm_key_vault_secret.this.value)["password"]};Server=${azurerm_postgresql_server.example.name}.postgres.database.azure.com;"
  key_vault_id = data.azurerm_key_vault.this.id
}

resource "azurerm_data_protection_backup_policy_postgresql" "this" {
  name                            = var.backup_policy_name
  resource_group_name             = var.resource_group_name
  vault_name                      = azurerm_data_protection_backup_vault.this.name
  backup_repeating_time_intervals = ["R/2022-06-06T03:00:00+00:00/P1D"]
  default_retention_duration      = "P7D"
}

resource "azurerm_role_assignment" "this" {
  scope                = azurerm_postgresql_server.example.id
  role_definition_name = "Reader"
  principal_id         = azurerm_data_protection_backup_vault.this.identity.0.principal_id
}

resource "azurerm_data_protection_backup_instance_postgresql" "this" {
  for_each                                = var.db_instances
  name                                    = replace(each.value, "\\", "-")
  location                                = var.location
  vault_id                                = azurerm_data_protection_backup_vault.this.id
  database_id                             = azurerm_postgresql_database.this[each.key].id
  backup_policy_id                        = azurerm_data_protection_backup_policy_postgresql.this.id
  database_credential_key_vault_secret_id = azurerm_key_vault_secret.pg_access.versionless_id
}
