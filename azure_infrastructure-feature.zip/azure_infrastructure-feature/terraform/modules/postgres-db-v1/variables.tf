variable "resource_group_name" { type = string }
variable "vnet_name" { type = string }
variable "prefix" { type = string }
variable "storage" { type = string }
variable "db_image" { type = list(any) }
variable "db_specs" { type = list(any) }
variable "secret" { type = list(any) }
variable "backup_vault_name" { type = string }
variable "backup_policy_name" { type = string }
variable "db_instances" { type = map(any) }

variable "application" { type = string }
variable "environment" { type = string }
variable "location" { type = string }
variable "visibility" { type = string }