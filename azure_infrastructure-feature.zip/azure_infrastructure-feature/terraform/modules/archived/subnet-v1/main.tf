module "naming" {
  source = "git::ssh://git@luxproject.luxoft.com:7999/ddmtv/terraform-azurerm-naming.git"
  suffix = [var.application, var.environment, var.location, var.visibility]
}

resource "azurerm_subnet" "subnet" {
  name                 = module.naming.subnet.name_unique
  resource_group_name  = "Experimental_Resources"
  virtual_network_name = var.network_name
  address_prefixes     = var.addr_prefix
}