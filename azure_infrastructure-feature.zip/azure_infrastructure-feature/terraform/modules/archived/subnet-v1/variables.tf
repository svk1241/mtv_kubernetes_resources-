variable "network_name" {}
variable "addr_prefix" {}
variable "application" {}
variable "environment" {}
variable "location" {}
variable "visibility" {}