module "vm-subnet" {
  source = "./modules/subnet-v1"

  network_name = "Experimental_Subnet"
  addr_prefix  = ["10.0.2.0/24"]
  application  = "mtv"
  environment  = "poc"
  location     = "eastus"
  visibility   = "private"
}

module "win-client" {
  source = "./modules/windows-vm-v1"

  subnet_id           = module.vm-subnet.subnet_id
  ip_address          = "10.0.2.5"
  application         = "mtv"
  environment         = "poc"
  location            = local.location
  visibility          = "private"
  resource_group_name = var.resource_group_name
  kv_props            = ["mtv-kv-test", "win-vm-password"] # Azure Key-Vault properties in format: key-vault name, secret name

  depends_on = [module.vm-subnet.subnet_id]
}


module "lunix-workstation" {
  source = "./modules/linux-ws-v1"

  subnet_id           = module.vm-subnet.subnet_id
  ip_address          = "10.0.2.6"
  admin_username      = "azureuser"
  location            = local.location
  environment         = "poc"
  application         = "mtv"
  vm_size             = "Standard_B1s"
  vm_image            = ["RedHat", "RHEL", "8_3", "latest"]
  kv_props            = ["mtv-kv-test", "win-vm-password"]
  resource_group_name = var.resource_group_name
  visibility          = "private"

  depends_on = [module.vm-subnet.id]
}
