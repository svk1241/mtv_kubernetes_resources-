terraform {
  required_version = "~>0.14.0"
  backend "azurerm" {
    resource_group_name  = "Experimental_Resources"
    storage_account_name = "deltadentalmtvtest"
    container_name       = "tfstate"
    key                  = "poc.terraform.tfstate"
  }

  required_providers {
    azurerm = {
      version = "~>2.0"
    }
    random = {
      version = "~> 2.2"
    }
  }
}

provider "azurerm" {
  subscription_id = "d705f4d8-7a99-4443-b7df-67187358521f"
  features {}
}

locals {
  location = "eastus"
}

variable "resource_group_name" {
  type    = string
  default = "Experimental_Resources"
}