module "naming" {
  source = "git::ssh://git@luxproject.luxoft.com:7999/ddmtv/terraform-azurerm-naming.git"
  suffix = [var.application, var.environment, var.location, var.visibility]
}

resource "random_id" "ipconf-id" {
  byte_length = 4
}

resource "random_id" "hostname-id" {
  byte_length = 2
}

resource "azurerm_network_interface" "interface" {
  name                = format("%s-%03d", module.naming.network_interface.name_unique, count.index + 1)
  location            = var.location
  resource_group_name = var.resource_group_name
  count               = var.instance_count

  ip_configuration {
    name                          = module.naming.public_ip.name_unique
    subnet_id                     = var.subnet_id
    private_ip_address_allocation = "Dynamic"
  }
}

data "azurerm_key_vault" "this" {
  resource_group_name = var.secret[0]
  name                = var.secret[1]
}

data "azurerm_key_vault_secret" "this" {
  name         = var.secret[2]
  key_vault_id = data.azurerm_key_vault.this.id
}

resource "azurerm_windows_virtual_machine" "win-vm" {
  name                = format("%s-%03d", module.naming.windows_virtual_machine.name, count.index + var.start_count_number)
  computer_name       = format("%s-%03d", var.computer_name_prefix, count.index + var.start_count_number) # Should be less than 15 symbols
  resource_group_name = var.resource_group_name
  location            = var.location
  size                = var.vm_size
  admin_username      = jsondecode(data.azurerm_key_vault_secret.this.value)["user"]
  admin_password      = jsondecode(data.azurerm_key_vault_secret.this.value)["password"] # pragma: allowlist secret
  count               = var.instance_count

  network_interface_ids = [
    azurerm_network_interface.interface[count.index].id,
  ]

  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "Standard_LRS"
  }

  source_image_reference {
    publisher = var.vm_image[0]
    offer     = var.vm_image[1]
    sku       = var.vm_image[2]
    version   = var.vm_image[3]
  }
}
