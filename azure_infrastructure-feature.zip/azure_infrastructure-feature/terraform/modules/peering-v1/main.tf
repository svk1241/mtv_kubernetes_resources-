data "azurerm_resources" "spokes" {
  type = "Microsoft.Network/virtualNetworks"
  required_tags = {
    realm = var.vnet_tag
  }
}

output "networks" {
  value = data.azurerm_resources.spokes.resources
}

resource "azurerm_virtual_network_peering" "peering-forward" {
  count                        = length(data.azurerm_resources.spokes.resources)
  name                         = "peering-to-${element(data.azurerm_resources.spokes.resources.*.name, count.index + 1)}"
  resource_group_name          = lookup(element(data.azurerm_resources.spokes.resources.*.tags, count.index), "resource_group", "")
  virtual_network_name         = element(data.azurerm_resources.spokes.resources.*.name, count.index)
  remote_virtual_network_id    = element(data.azurerm_resources.spokes.resources.*.id, count.index + 1)
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  allow_gateway_transit        = false
}

resource "azurerm_virtual_network_peering" "peering-backward" {
  count                        = length(data.azurerm_resources.spokes.resources)
  name                         = "peering-to-${element(data.azurerm_resources.spokes.resources.*.name, count.index)}"
  resource_group_name          = lookup(element(data.azurerm_resources.spokes.resources.*.tags, count.index + 1), "resource_group", "")
  virtual_network_name         = element(data.azurerm_resources.spokes.resources.*.name, count.index + 1)
  remote_virtual_network_id    = element(data.azurerm_resources.spokes.resources.*.id, count.index)
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  allow_gateway_transit        = false
}




