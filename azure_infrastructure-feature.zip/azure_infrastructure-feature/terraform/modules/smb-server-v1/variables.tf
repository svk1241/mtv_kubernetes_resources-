variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "vm_size" { type = string }
variable "vm_image" { type = list(any) }
variable "subnet_id" { type = string }
variable "secret" { type = list(any) }
variable "disk_size" { type = list(any) }

variable "ppg_id" {
  type    = string
  default = ""
}

variable "use_accelerated_networking" {
  type    = bool
  default = false
}

