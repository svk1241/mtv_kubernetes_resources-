resource "azurerm_network_interface" "this" {
  name                          = "smb-server593"
  location                      = var.location
  resource_group_name           = var.resource_group_name
  enable_accelerated_networking = var.use_accelerated_networking

  ip_configuration {
    name                          = "ipconfig1"
    subnet_id                     = var.subnet_id
    private_ip_address_allocation = "Dynamic"
  }
}

data "azurerm_key_vault" "this" {
  resource_group_name = var.secret[0]
  name                = var.secret[1]
}

data "azurerm_key_vault_secret" "this" {
  name         = var.secret[2]
  key_vault_id = data.azurerm_key_vault.this.id
}

resource "azurerm_windows_virtual_machine" "this" {
  name                = "smb-server"
  computer_name       = "smb-server"
  resource_group_name = upper(var.resource_group_name)
  location            = var.location
  size                = var.vm_size
  admin_username      = jsondecode(data.azurerm_key_vault_secret.this.value)["user"]
  admin_password      = jsondecode(data.azurerm_key_vault_secret.this.value)["password"] # pragma: allowlist-secret varable, not a secret

  network_interface_ids = [
    azurerm_network_interface.this.id,
  ]

  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "Premium_LRS"
  }

  source_image_reference {
    publisher = var.vm_image[0]
    offer     = var.vm_image[1]
    sku       = var.vm_image[2]
    version   = var.vm_image[3]
  }

  proximity_placement_group_id = var.ppg_id != "" ? var.ppg_id : null

  boot_diagnostics {
    storage_account_uri = null
  }
}

resource "azurerm_managed_disk" "concurrency" {
  name                 = "smb-volume-concurrency"
  location             = var.location
  resource_group_name  = var.resource_group_name
  storage_account_type = "Premium_LRS"
  create_option        = "Empty"
  disk_size_gb         = var.disk_size[0]
}

resource "azurerm_managed_disk" "regression" {
  name                 = "smb-volume-regression"
  location             = var.location
  resource_group_name  = var.resource_group_name
  storage_account_type = "Premium_LRS"
  create_option        = "Empty"
  disk_size_gb         = var.disk_size[1]
}

resource "azurerm_managed_disk" "integration86" {
  name                 = "smb-volume-86"
  location             = var.location
  resource_group_name  = var.resource_group_name
  storage_account_type = "Premium_LRS"
  create_option        = "Empty"
  disk_size_gb         = var.disk_size[2]
}

resource "azurerm_managed_disk" "dev1" {
  name                 = "smb-volume-dev1"
  location             = var.location
  resource_group_name  = var.resource_group_name
  storage_account_type = "Premium_LRS"
  create_option        = "Empty"
  disk_size_gb         = var.disk_size[3]
}

resource "azurerm_managed_disk" "dev" {
  name                 = "smb-volume-dev"
  location             = var.location
  resource_group_name  = var.resource_group_name
  storage_account_type = "Premium_LRS"
  create_option        = "Empty"
  disk_size_gb         = var.disk_size[4]
}

resource "azurerm_managed_disk" "extensions_mock" {
  name                 = "smb-volume-mock"
  location             = var.location
  resource_group_name  = var.resource_group_name
  storage_account_type = "Premium_LRS"
  create_option        = "Empty"
  disk_size_gb         = var.disk_size[5]
}

resource "azurerm_managed_disk" "extensions_eaas" {
  name                 = "smb-volume-eaas"
  location             = var.location
  resource_group_name  = var.resource_group_name
  storage_account_type = "Premium_LRS"
  create_option        = "Empty"
  disk_size_gb         = var.disk_size[6]
}

resource "azurerm_virtual_machine_data_disk_attachment" "concurrency" {
  managed_disk_id    = azurerm_managed_disk.concurrency.id
  virtual_machine_id = azurerm_windows_virtual_machine.this.id
  lun                = "0"
  caching            = "None"
}

resource "azurerm_virtual_machine_data_disk_attachment" "regression" {
  managed_disk_id    = azurerm_managed_disk.regression.id
  virtual_machine_id = azurerm_windows_virtual_machine.this.id
  lun                = "1"
  caching            = "None"
}

resource "azurerm_virtual_machine_data_disk_attachment" "integration86" {
  managed_disk_id    = azurerm_managed_disk.integration86.id
  virtual_machine_id = azurerm_windows_virtual_machine.this.id
  lun                = "2"
  caching            = "None"
}

resource "azurerm_virtual_machine_data_disk_attachment" "dev1" {
  managed_disk_id    = azurerm_managed_disk.dev1.id
  virtual_machine_id = azurerm_windows_virtual_machine.this.id
  lun                = "3"
  caching            = "None"
}

resource "azurerm_virtual_machine_data_disk_attachment" "dev" {
  managed_disk_id    = azurerm_managed_disk.dev.id
  virtual_machine_id = azurerm_windows_virtual_machine.this.id
  lun                = "4"
  caching            = "None"
}

resource "azurerm_virtual_machine_data_disk_attachment" "extensions_mock" {
  managed_disk_id    = azurerm_managed_disk.extensions_mock.id
  virtual_machine_id = azurerm_windows_virtual_machine.this.id
  lun                = "5"
  caching            = "None"
}

resource "azurerm_virtual_machine_data_disk_attachment" "extensions_eaas" {
  managed_disk_id    = azurerm_managed_disk.extensions_eaas.id
  virtual_machine_id = azurerm_windows_virtual_machine.this.id
  lun                = "6"
  caching            = "None"
}
