variable "location" { type = string }
variable "resource_group_name" { type = string }
variable "subnet_id" { type = string }
variable "vnet_name" { type = string }
variable "acr_id" { type = string }
variable "aks_managed_identity_name" { type = string }
variable "aks_secrets_key_vault_resource_group_name" { type = string }
variable "aks_secrets_key_vault_name" { type = string }
variable "tenant_id" { type = string }
variable "cluster_name" { type = string }
variable "aks_service_cidr" { type = string }
variable "aks_dns_service_ip" { type = string }
variable "aks_docker_bridge_cidr" { type = string }
variable "aks_agent_count" { type = number }
variable "aks_agent_vm_size" { type = string }
variable "aks_kubernetes_version" { type = string }
variable "aks_agent_pool_name" { type = string }
variable "aks_agent_pool_os_type" { type = string }
variable "aks_agent_pool_type" { type = string }
variable "aks_agent_os_disk_size" { type = string }
variable "aks_agent_pool_max_pods" { type = string }
variable "aks_enable_rbac" { type = bool }
variable "aks_cluster_admin_aad_group_name" { type = string }
variable "aks_server_secret" { type = string }
variable "aks_server_id" { type = string }
variable "prefix_name" { type = string }


variable "app_gateway_name" { type = string }
variable "app_gateway_public_ip_name" { type = string }
variable "app_gateway_public_ip_address_allocation" { type = string }
variable "app_gateway_public_ip_sku" { type = string }
variable "app_gateway_sku" { type = string }
variable "app_gateway_tier" { type = string }
variable "app_gateway_min_capacity" { type = number }
variable "app_gateway_max_capacity" { type = number }


variable "appgw_subnet_cidr_block" { type = string }
variable "platform_app_gateway_subnet_name" { type = string }

variable "subscription_id" {
  type    = string
  default = "d705f4d8-7a99-4443-b7df-67187358521f"
}


