<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |
| <a name="provider_helm"></a> [helm](#provider\_helm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_application_gateway.agw](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/application_gateway) | resource |
| [azurerm_key_vault_access_policy.uai_kv_access_policy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_access_policy) | resource |
| [azurerm_kubernetes_cluster.aks](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/kubernetes_cluster) | resource |
| [azurerm_public_ip.agw_public_ip](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_role_assignment.aks_ra_container_registry](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_subnet.subnet_app_gateway](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_user_assigned_identity.identity](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/user_assigned_identity) | resource |
| [helm_release.aad_pod_identity](https://registry.terraform.io/providers/hashicorp/helm/latest/docs/resources/release) | resource |
| [helm_release.agw_ingress](https://registry.terraform.io/providers/hashicorp/helm/latest/docs/resources/release) | resource |
| [azurerm_key_vault.secretsVault](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/key_vault) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_acr_id"></a> [acr\_id](#input\_acr\_id) | n/a | `string` | n/a | yes |
| <a name="input_aks_agent_count"></a> [aks\_agent\_count](#input\_aks\_agent\_count) | n/a | `number` | n/a | yes |
| <a name="input_aks_agent_os_disk_size"></a> [aks\_agent\_os\_disk\_size](#input\_aks\_agent\_os\_disk\_size) | n/a | `string` | n/a | yes |
| <a name="input_aks_agent_pool_max_pods"></a> [aks\_agent\_pool\_max\_pods](#input\_aks\_agent\_pool\_max\_pods) | n/a | `string` | n/a | yes |
| <a name="input_aks_agent_pool_name"></a> [aks\_agent\_pool\_name](#input\_aks\_agent\_pool\_name) | n/a | `string` | n/a | yes |
| <a name="input_aks_agent_pool_os_type"></a> [aks\_agent\_pool\_os\_type](#input\_aks\_agent\_pool\_os\_type) | n/a | `string` | n/a | yes |
| <a name="input_aks_agent_pool_type"></a> [aks\_agent\_pool\_type](#input\_aks\_agent\_pool\_type) | n/a | `string` | n/a | yes |
| <a name="input_aks_agent_vm_size"></a> [aks\_agent\_vm\_size](#input\_aks\_agent\_vm\_size) | n/a | `string` | n/a | yes |
| <a name="input_aks_cluster_admin_aad_group_name"></a> [aks\_cluster\_admin\_aad\_group\_name](#input\_aks\_cluster\_admin\_aad\_group\_name) | n/a | `string` | n/a | yes |
| <a name="input_aks_dns_service_ip"></a> [aks\_dns\_service\_ip](#input\_aks\_dns\_service\_ip) | n/a | `string` | n/a | yes |
| <a name="input_aks_docker_bridge_cidr"></a> [aks\_docker\_bridge\_cidr](#input\_aks\_docker\_bridge\_cidr) | n/a | `string` | n/a | yes |
| <a name="input_aks_enable_rbac"></a> [aks\_enable\_rbac](#input\_aks\_enable\_rbac) | n/a | `bool` | n/a | yes |
| <a name="input_aks_kubernetes_version"></a> [aks\_kubernetes\_version](#input\_aks\_kubernetes\_version) | n/a | `string` | n/a | yes |
| <a name="input_aks_managed_identity_name"></a> [aks\_managed\_identity\_name](#input\_aks\_managed\_identity\_name) | n/a | `string` | n/a | yes |
| <a name="input_aks_secrets_key_vault_name"></a> [aks\_secrets\_key\_vault\_name](#input\_aks\_secrets\_key\_vault\_name) | n/a | `string` | n/a | yes |
| <a name="input_aks_secrets_key_vault_resource_group_name"></a> [aks\_secrets\_key\_vault\_resource\_group\_name](#input\_aks\_secrets\_key\_vault\_resource\_group\_name) | n/a | `string` | n/a | yes |
| <a name="input_aks_server_id"></a> [aks\_server\_id](#input\_aks\_server\_id) | n/a | `string` | n/a | yes |
| <a name="input_aks_server_secret"></a> [aks\_server\_secret](#input\_aks\_server\_secret) | n/a | `string` | n/a | yes |
| <a name="input_aks_service_cidr"></a> [aks\_service\_cidr](#input\_aks\_service\_cidr) | n/a | `string` | n/a | yes |
| <a name="input_app_gateway_max_capacity"></a> [app\_gateway\_max\_capacity](#input\_app\_gateway\_max\_capacity) | n/a | `number` | n/a | yes |
| <a name="input_app_gateway_min_capacity"></a> [app\_gateway\_min\_capacity](#input\_app\_gateway\_min\_capacity) | n/a | `number` | n/a | yes |
| <a name="input_app_gateway_name"></a> [app\_gateway\_name](#input\_app\_gateway\_name) | n/a | `string` | n/a | yes |
| <a name="input_app_gateway_public_ip_address_allocation"></a> [app\_gateway\_public\_ip\_address\_allocation](#input\_app\_gateway\_public\_ip\_address\_allocation) | n/a | `string` | n/a | yes |
| <a name="input_app_gateway_public_ip_name"></a> [app\_gateway\_public\_ip\_name](#input\_app\_gateway\_public\_ip\_name) | n/a | `string` | n/a | yes |
| <a name="input_app_gateway_public_ip_sku"></a> [app\_gateway\_public\_ip\_sku](#input\_app\_gateway\_public\_ip\_sku) | n/a | `string` | n/a | yes |
| <a name="input_app_gateway_sku"></a> [app\_gateway\_sku](#input\_app\_gateway\_sku) | n/a | `string` | n/a | yes |
| <a name="input_app_gateway_tier"></a> [app\_gateway\_tier](#input\_app\_gateway\_tier) | n/a | `string` | n/a | yes |
| <a name="input_appgw_subnet_cidr_block"></a> [appgw\_subnet\_cidr\_block](#input\_appgw\_subnet\_cidr\_block) | n/a | `string` | n/a | yes |
| <a name="input_cluster_name"></a> [cluster\_name](#input\_cluster\_name) | n/a | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | n/a | `string` | n/a | yes |
| <a name="input_platform_app_gateway_subnet_name"></a> [platform\_app\_gateway\_subnet\_name](#input\_platform\_app\_gateway\_subnet\_name) | n/a | `string` | n/a | yes |
| <a name="input_prefix_name"></a> [prefix\_name](#input\_prefix\_name) | n/a | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | n/a | `string` | n/a | yes |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | n/a | `string` | n/a | yes |
| <a name="input_subscription_id"></a> [subscription\_id](#input\_subscription\_id) | n/a | `string` | `"d705f4d8-7a99-4443-b7df-67187358521f"` | no |
| <a name="input_tenant_id"></a> [tenant\_id](#input\_tenant\_id) | n/a | `string` | n/a | yes |
| <a name="input_vnet_name"></a> [vnet\_name](#input\_vnet\_name) | n/a | `string` | n/a | yes |

## Outputs

No outputs.
<!-- END_TF_DOCS -->