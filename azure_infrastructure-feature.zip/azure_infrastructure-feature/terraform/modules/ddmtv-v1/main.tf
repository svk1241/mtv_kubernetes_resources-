# Create User Assigned Identities 
resource "azurerm_user_assigned_identity" "identity" {
  resource_group_name = var.resource_group_name
  location            = var.location
  name                = var.aks_managed_identity_name
}

resource "azurerm_role_assignment" "aks_ra_container_registry" {
  scope                = var.acr_id
  role_definition_name = "AcrPull"
  principal_id         = azurerm_user_assigned_identity.identity.principal_id
}

data "azurerm_key_vault" "secretsVault" {
  name                = var.aks_secrets_key_vault_name
  resource_group_name = var.aks_secrets_key_vault_resource_group_name
}

resource "azurerm_key_vault_access_policy" "uai_kv_access_policy" {
  key_vault_id = data.azurerm_key_vault.secretsVault.id

  tenant_id  = var.tenant_id
  object_id  = azurerm_user_assigned_identity.identity.principal_id
  depends_on = [azurerm_user_assigned_identity.identity]
  key_permissions = [
    "get",
    "list"
  ]

  secret_permissions = [
    "get",
  ]

  certificate_permissions = [
    "get",
  ]
}

resource "azurerm_kubernetes_cluster" "aks" {
  name                = var.cluster_name
  location            = var.location
  dns_prefix          = "${var.prefix_name}-aks"
  resource_group_name = var.resource_group_name
  kubernetes_version  = var.aks_kubernetes_version

  default_node_pool {
    name            = var.aks_agent_pool_name
    node_count      = var.aks_agent_count
    vm_size         = var.aks_agent_vm_size
    max_pods        = var.aks_agent_pool_max_pods
    os_disk_size_gb = var.aks_agent_os_disk_size
    type            = var.aks_agent_pool_type
    vnet_subnet_id  = var.subnet_id
  }
  service_principal {
    client_id     = var.aks_server_id
    client_secret = var.aks_server_secret
  }


  network_profile {
    network_plugin     = "azure"
    dns_service_ip     = var.aks_dns_service_ip
    docker_bridge_cidr = var.aks_docker_bridge_cidr
    service_cidr       = var.aks_service_cidr
    network_policy     = "azure"
  }

  addon_profile {
    http_application_routing {
      enabled = false
    }
    kube_dashboard {
      enabled = false
    }
  }


}

resource "azurerm_subnet" "subnet_app_gateway" {
  resource_group_name  = var.resource_group_name
  virtual_network_name = var.vnet_name
  name                 = var.platform_app_gateway_subnet_name
  address_prefixes     = [var.appgw_subnet_cidr_block]
}



resource "azurerm_public_ip" "agw_public_ip" {
  name                = "${var.prefix_name}-pip"
  location            = var.location
  resource_group_name = var.resource_group_name
  allocation_method   = var.app_gateway_public_ip_address_allocation
  sku                 = var.app_gateway_public_ip_sku
}


resource "azurerm_application_gateway" "agw" {
  name                = var.app_gateway_name
  resource_group_name = var.resource_group_name
  location            = var.location

  sku {
    name = var.app_gateway_sku
    tier = var.app_gateway_tier
  }

  autoscale_configuration {
    min_capacity = var.app_gateway_min_capacity
    max_capacity = var.app_gateway_max_capacity
  }

  # ssl_certificate {
  #   name     = var.aks_certificate_name
  #   data     = filebase64(var.aks_certificate_path)
  #   password = var.aks_certificate_pwd # pragma: allowlist secret
  # }

  gateway_ip_configuration {
    name      = azurerm_subnet.subnet_app_gateway.name
    subnet_id = azurerm_subnet.subnet_app_gateway.id
  }

  frontend_port {
    name = "${var.vnet_name}-feport"
    port = 80
  }

  frontend_port {
    name = "https_port"
    port = 443
  }

  frontend_ip_configuration {
    name                 = "${var.vnet_name}-feip"
    public_ip_address_id = azurerm_public_ip.agw_public_ip.id
  }

  backend_address_pool {
    name = "${var.vnet_name}-beap"
  }

  backend_http_settings {
    name                  = "${var.vnet_name}-be-htst"
    cookie_based_affinity = "Disabled"
    port                  = 80
    protocol              = "http"
    request_timeout       = 1
  }

  http_listener {
    name                           = "${var.vnet_name}-httplstn"
    frontend_ip_configuration_name = "${var.vnet_name}-feip"
    frontend_port_name             = "${var.vnet_name}-feport"
    protocol                       = "http"
  }

  request_routing_rule {
    name                       = "${var.vnet_name}-rqrt"
    rule_type                  = "Basic"
    http_listener_name         = "${var.vnet_name}-httplstn"
    backend_address_pool_name  = "${var.vnet_name}-beap"
    backend_http_settings_name = "${var.vnet_name}-be-htst"
  }

}


provider "helm" {
  kubernetes {
    config_path = "./modules/ddmtv-v1/kubeconfig"
  }
}

resource "helm_release" "aad_pod_identity" {
  name             = "aad-pod-identity"
  repository       = "https://raw.githubusercontent.com/Azure/aad-pod-identity/master/charts"
  chart            = "aad-pod-identity"
  namespace        = "azure-ad"
  create_namespace = true

  depends_on = [
    azurerm_kubernetes_cluster.aks
  ]
}

resource "helm_release" "agw_ingress" {
  name             = "application-gateway-kubernetes-ingress"
  repository       = "https://appgwingress.blob.core.windows.net/ingress-azure-helm-package/"
  chart            = "ingress-azure"
  namespace        = "agw-ingress"
  create_namespace = true

  values = [
    <<EOF
verbosityLevel: 3
appgw:
    subscriptionId: ${var.subscription_id}
    resourceGroup: ${var.resource_group_name}
    name: ${azurerm_application_gateway.agw.name}
    shared: false
armAuth:
    type: aadPodIdentity
    identityResourceID: ${azurerm_user_assigned_identity.identity.id}
    identityClientID:  ${azurerm_user_assigned_identity.identity.client_id}
rbac:
    enabled: true 
aksClusterConfiguration:
    apiServerAddress: ${azurerm_kubernetes_cluster.aks.kube_config[0].host}
EOF
    ,
  ]
  depends_on = [
    helm_release.aad_pod_identity,
    azurerm_kubernetes_cluster.aks
  ]
}
