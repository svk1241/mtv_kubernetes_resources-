variable "resource_group_name" { type = string }
variable "vm_size" { type = string }
variable "vm_image" { type = list(any) }
variable "subnet_id" { type = string }
variable "secret" { type = list(any) }

variable "application" { type = string }
variable "environment" { type = string }
variable "location" { type = string }
variable "visibility" { type = string }


