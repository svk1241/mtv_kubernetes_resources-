<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_aks_diagnostics"></a> [aks\_diagnostics](#module\_aks\_diagnostics) | ../aks-diag-v1 | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_kubernetes_cluster.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/kubernetes_cluster) | resource |
| [azurerm_role_assignment.kubweb_to_acr](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_user_assigned_identity.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/user_assigned_identity) | resource |
| [azurerm_subscription.primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subscription) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_aad_integration"></a> [aad\_integration](#input\_aad\_integration) | Azure AD integration details | <pre>object({<br>    enabled                = bool<br>    managed                = optional(bool, null)<br>    azure_rbac_enabled     = optional(bool, null)<br>    admin_group_object_ids = optional(list(string), null)<br>    tenant_id              = optional(string, null)<br>  })</pre> | n/a | yes |
| <a name="input_acr_id"></a> [acr\_id](#input\_acr\_id) | n/a | `string` | n/a | yes |
| <a name="input_application"></a> [application](#input\_application) | n/a | `string` | n/a | yes |
| <a name="input_default_node_pool_name"></a> [default\_node\_pool\_name](#input\_default\_node\_pool\_name) | n/a | `string` | n/a | yes |
| <a name="input_default_nodes_vm_size"></a> [default\_nodes\_vm\_size](#input\_default\_nodes\_vm\_size) | n/a | `string` | n/a | yes |
| <a name="input_dns_service_ip"></a> [dns\_service\_ip](#input\_dns\_service\_ip) | n/a | `string` | n/a | yes |
| <a name="input_docker_bridge_cidr"></a> [docker\_bridge\_cidr](#input\_docker\_bridge\_cidr) | n/a | `string` | n/a | yes |
| <a name="input_enable_diagnostic"></a> [enable\_diagnostic](#input\_enable\_diagnostic) | Specify to enable diagnostics or not | `bool` | `false` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | n/a | `string` | n/a | yes |
| <a name="input_k8s_version"></a> [k8s\_version](#input\_k8s\_version) | n/a | `string` | n/a | yes |
| <a name="input_kubernetes_dns_zone_id"></a> [kubernetes\_dns\_zone\_id](#input\_kubernetes\_dns\_zone\_id) | variable "node\_count" { type = string } | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | n/a | `string` | n/a | yes |
| <a name="input_max_nodes_count"></a> [max\_nodes\_count](#input\_max\_nodes\_count) | n/a | `string` | n/a | yes |
| <a name="input_min_nodes_count"></a> [min\_nodes\_count](#input\_min\_nodes\_count) | n/a | `string` | n/a | yes |
| <a name="input_os_sku"></a> [os\_sku](#input\_os\_sku) | n/a | `string` | `"Ubuntu"` | no |
| <a name="input_ppg_id"></a> [ppg\_id](#input\_ppg\_id) | n/a | `string` | n/a | yes |
| <a name="input_rbac_enabled"></a> [rbac\_enabled](#input\_rbac\_enabled) | n/a | `bool` | `true` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | n/a | `string` | n/a | yes |
| <a name="input_service_cidr"></a> [service\_cidr](#input\_service\_cidr) | n/a | `string` | n/a | yes |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | n/a | `string` | n/a | yes |
| <a name="input_user_identity"></a> [user\_identity](#input\_user\_identity) | n/a | `string` | n/a | yes |
| <a name="input_visibility"></a> [visibility](#input\_visibility) | n/a | `string` | n/a | yes |
| <a name="input_workspace_id"></a> [workspace\_id](#input\_workspace\_id) | Log Analytics workspace id for container insights and diagnostic | `string` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_client_certificate"></a> [client\_certificate](#output\_client\_certificate) | n/a |
| <a name="output_cluster_id"></a> [cluster\_id](#output\_cluster\_id) | n/a |
| <a name="output_kube_config"></a> [kube\_config](#output\_kube\_config) | n/a |
| <a name="output_kubelet_identity"></a> [kubelet\_identity](#output\_kubelet\_identity) | n/a |
<!-- END_TF_DOCS -->