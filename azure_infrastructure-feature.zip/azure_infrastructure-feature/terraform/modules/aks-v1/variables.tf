variable "resource_group_name" { type = string }
variable "k8s_version" { type = string }
variable "user_identity" { type = string }
variable "default_nodes_vm_size" { type = string }
variable "subnet_id" { type = string }
variable "service_cidr" { type = string }
variable "dns_service_ip" { type = string }
variable "docker_bridge_cidr" { type = string }
variable "default_node_pool_name" { type = string }
variable "rbac_enabled" {
  type    = bool
  default = true
}
variable "ppg_id" { type = string }

variable "application" { type = string }
variable "environment" { type = string }
variable "location" { type = string }
variable "visibility" { type = string }
variable "acr_id" { type = string }

variable "min_nodes_count" { type = string }
variable "max_nodes_count" { type = string }
#variable "node_count" { type = string }
variable "kubernetes_dns_zone_id" { type = string }

variable "workspace_id" {
  description = "Log Analytics workspace id for container insights and diagnostic"
  type        = string
  default     = null
}

variable "enable_diagnostic" {
  description = "Specify to enable diagnostics or not"
  type        = bool
  default     = false
}

variable "aad_integration" {
  description = "Azure AD integration details"
  type = object({
    enabled                = bool
    managed                = optional(bool, null)
    azure_rbac_enabled     = optional(bool, null)
    admin_group_object_ids = optional(list(string), null)
    tenant_id              = optional(string, null)
  })
}
variable "os_sku" {
  type    = string
  default = "Ubuntu"
}
