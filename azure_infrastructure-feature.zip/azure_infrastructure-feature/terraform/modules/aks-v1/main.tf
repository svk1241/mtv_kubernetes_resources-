data "azurerm_subscription" "primary" {
}

resource "azurerm_user_assigned_identity" "this" {
  name                = var.user_identity
  resource_group_name = var.resource_group_name
  location            = var.location
}

resource "azurerm_role_assignment" "this" {
  scope                = data.azurerm_subscription.primary.id
  role_definition_name = "Contributor"
  principal_id         = azurerm_user_assigned_identity.this.principal_id
}

resource "azurerm_kubernetes_cluster" "this" {
  name                                = "cluster-${var.environment}-${var.location}-${var.visibility}"
  location                            = var.location
  resource_group_name                 = var.resource_group_name
  kubernetes_version                  = var.k8s_version
  dns_prefix                          = "aks"
  private_cluster_enabled             = true
  private_dns_zone_id                 = var.kubernetes_dns_zone_id
  role_based_access_control_enabled   = var.rbac_enabled
  private_cluster_public_fqdn_enabled = true

  depends_on = [
    azurerm_role_assignment.this,
  ]

  default_node_pool {
    name                         = var.default_node_pool_name
    temporary_name_for_rotation  = "defaulttemp"
    orchestrator_version         = var.k8s_version
    max_count                    = var.max_nodes_count
    min_count                    = var.min_nodes_count
    vm_size                      = var.default_nodes_vm_size
    os_sku                       = var.os_sku
    enable_auto_scaling          = true
    #node_count                  = var.node_count
    vnet_subnet_id               = var.subnet_id
    proximity_placement_group_id = var.ppg_id != "" ? var.ppg_id : null

    tags = {
      Environment = var.environment
    }
  }

  identity {
    type         = "UserAssigned"
    identity_ids = [azurerm_user_assigned_identity.this.id]
  }

  tags = {
    Environment = var.environment
  }

  network_profile {
    network_plugin     = "azure"
    service_cidr       = var.service_cidr
    dns_service_ip     = var.dns_service_ip
    docker_bridge_cidr = var.docker_bridge_cidr
  }

  dynamic "oms_agent" {
    for_each = var.workspace_id[*] # This creates exactly 1 oms_agent block if workspace specified otherwise no block is created
    content {
      log_analytics_workspace_id = var.workspace_id
    }
  }

  dynamic "azure_active_directory_role_based_access_control" {
    for_each = var.aad_integration.enabled == true ? [1] : [] # This creates exactly 1 azure_active_directory_role_based_access_control block if aad_integration enabled true flag specified otherwise no block is created
    content {
      managed                = var.aad_integration.managed
      azure_rbac_enabled     = var.aad_integration.azure_rbac_enabled
      tenant_id              = var.aad_integration.tenant_id
      admin_group_object_ids = var.aad_integration.admin_group_object_ids
    }
  }
}

resource "azurerm_role_assignment" "kubweb_to_acr" {
  scope                = var.acr_id
  role_definition_name = "AcrPull"
  principal_id         = azurerm_user_assigned_identity.this.principal_id
}

module "aks_diagnostics" {
  count                      = var.workspace_id != null && var.enable_diagnostic ? 1 : 0
  source                     = "../aks-diag-v1"
  diagnostics_setting_name   = "${azurerm_kubernetes_cluster.this.name}-diagnostics"
  cluster_id                 = azurerm_kubernetes_cluster.this.id
  log_analytics_workspace_id = var.workspace_id
  retention_in_days          = 90
}
