module "naming" {
  source = "github.com/Azure/terraform-azurerm-naming"
  suffix = [var.application, var.environment, var.location, var.visibility]
}

resource "azurerm_network_interface" "this" {
  name                          = module.naming.network_interface.name_unique
  location                      = var.location
  resource_group_name           = var.resource_group_name
  enable_accelerated_networking = var.use_accelerated_networking

  ip_configuration {
    name                          = module.naming.public_ip.name_unique
    subnet_id                     = var.subnet_id
    private_ip_address_allocation = "Dynamic"
  }
}



data "azurerm_key_vault" "this" {
  resource_group_name = var.secret[0]
  name                = var.secret[1]
}

data "azurerm_key_vault_secret" "this" {
  name         = var.secret[2]
  key_vault_id = data.azurerm_key_vault.this.id
}


resource "azurerm_linux_virtual_machine" "main" {
  name                            = module.naming.linux_virtual_machine.name
  computer_name                   = var.hostname != "" ? var.hostname : module.naming.linux_virtual_machine.name
  resource_group_name             = var.resource_group_name
  location                        = var.location
  size                            = var.vm_size
  admin_username                  = jsondecode(data.azurerm_key_vault_secret.this.value)["user"]
  admin_password                  = jsondecode(data.azurerm_key_vault_secret.this.value)["password"] # pragma: allowlist secret
  disable_password_authentication = false

  proximity_placement_group_id = var.ppg_id != "" ? var.ppg_id : null

  network_interface_ids = [
    azurerm_network_interface.this.id,
  ]

  source_image_reference {
    publisher = var.vm_image[0]
    offer     = var.vm_image[1]
    sku       = var.vm_image[2]
    version   = var.vm_image[3]
  }

  os_disk {
    storage_account_type = "StandardSSD_LRS"
    caching              = "ReadWrite"
  }
}

resource "azurerm_managed_disk" "u02" {
  name                 = "${module.naming.managed_disk.name_unique}-1"
  location             = var.location
  resource_group_name  = var.resource_group_name
  storage_account_type = "Premium_LRS"
  create_option        = "Empty"
  disk_size_gb         = var.volume_size[0]
}

resource "azurerm_virtual_machine_data_disk_attachment" "u02-attachment" {
  managed_disk_id    = azurerm_managed_disk.u02.id
  virtual_machine_id = azurerm_linux_virtual_machine.main.id
  lun                = "10"
  caching            = "ReadWrite"
}

resource "azurerm_managed_disk" "opt" {
  name                 = "${module.naming.managed_disk.name_unique}-2"
  location             = var.location
  resource_group_name  = var.resource_group_name
  storage_account_type = "Premium_LRS"
  create_option        = "Empty"
  disk_size_gb         = var.volume_size[1]
}

resource "azurerm_virtual_machine_data_disk_attachment" "opt-attachment" {
  managed_disk_id    = azurerm_managed_disk.opt.id
  virtual_machine_id = azurerm_linux_virtual_machine.main.id
  lun                = "11"
  caching            = "ReadWrite"
}
