resource "azurerm_kubernetes_cluster_node_pool" "this" {
  name                  = var.name
  kubernetes_cluster_id = var.cluster_id
  mode                  = var.mode
  vm_size               = var.nodepool_vm_size
  orchestrator_version  = var.k8s_version
  os_type               = var.os_type
  os_sku                = var.os_sku
  #node_count            = var.node_count
  enable_auto_scaling          = var.enable_auto_scaling
  min_count                    = var.min_nodes_count
  max_count                    = var.max_nodes_count
  vnet_subnet_id               = var.subnet_id
  proximity_placement_group_id = var.ppg_id != "" ? var.ppg_id : null

  tags = {
    Environment = var.environment
  }

  node_taints = var.taints != [] ? var.taints : null
  node_labels = var.labels != {} ? var.labels : null
}
