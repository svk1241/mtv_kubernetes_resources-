<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_kubernetes_cluster_node_pool.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/kubernetes_cluster_node_pool) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cluster_id"></a> [cluster\_id](#input\_cluster\_id) | n/a | `string` | n/a | yes |
| <a name="input_enable_auto_scaling"></a> [enable\_auto\_scaling](#input\_enable\_auto\_scaling) | n/a | `bool` | `true` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | n/a | `string` | n/a | yes |
| <a name="input_k8s_version"></a> [k8s\_version](#input\_k8s\_version) | n/a | `string` | n/a | yes |
| <a name="input_labels"></a> [labels](#input\_labels) | n/a | `map(any)` | n/a | yes |
| <a name="input_max_nodes_count"></a> [max\_nodes\_count](#input\_max\_nodes\_count) | n/a | `string` | n/a | yes |
| <a name="input_min_nodes_count"></a> [min\_nodes\_count](#input\_min\_nodes\_count) | variable "node\_count" { type = string } | `string` | n/a | yes |
| <a name="input_mode"></a> [mode](#input\_mode) | n/a | `string` | n/a | yes |
| <a name="input_name"></a> [name](#input\_name) | n/a | `string` | n/a | yes |
| <a name="input_nodepool_vm_size"></a> [nodepool\_vm\_size](#input\_nodepool\_vm\_size) | n/a | `string` | n/a | yes |
| <a name="input_os_sku"></a> [os\_sku](#input\_os\_sku) | n/a | `string` | `"Ubuntu"` | no |
| <a name="input_os_type"></a> [os\_type](#input\_os\_type) | n/a | `string` | `"Linux"` | no |
| <a name="input_ppg_id"></a> [ppg\_id](#input\_ppg\_id) | n/a | `string` | n/a | yes |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | n/a | `string` | n/a | yes |
| <a name="input_taints"></a> [taints](#input\_taints) | n/a | `list(string)` | n/a | yes |

## Outputs

No outputs.
<!-- END_TF_DOCS -->