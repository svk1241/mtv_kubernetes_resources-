variable "name" { type = string }
variable "k8s_version" { type = string }
variable "cluster_id" { type = string }
variable "subnet_id" { type = string }
variable "nodepool_vm_size" { type = string }
variable "taints" { type = list(string) }
#variable "node_count" { type = string }
variable "min_nodes_count" { type = string }
variable "max_nodes_count" { type = string }
variable "ppg_id" { type = string }
variable "environment" { type = string }
variable "labels" { type = map(any) }
variable "mode" { type = string }
variable "enable_auto_scaling" {
  type    = bool
  default = true
}
variable "os_sku" {
  type    = string
  default = "Ubuntu"
}

variable "os_type" {
  type    = string
  default = "Linux"
}
