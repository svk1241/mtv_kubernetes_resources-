variable "resource_group_name" { type = string }
variable "vm_size" { type = string }
variable "vm_image" { type = list(any) }
variable "subnet_id" { type = string }
variable "secret" { type = list(any) }
variable "volume_size" { type = list(any) }
variable "hostname" {
  type    = string
  default = ""
}
variable "caching_mode" {
  type    = string
  default = "ReadWrite"
}
variable "network_access_policy" {
  type    = string
  default = null
}
variable "disk_access_id" {
  type    = string
  default = null
}

variable "application" { type = string }
variable "environment" { type = string }
variable "location" { type = string }
variable "visibility" { type = string }


variable "ppg_id" {
  type    = string
  default = ""
}

variable "use_accelerated_networking" {
  type    = bool
  default = false
}