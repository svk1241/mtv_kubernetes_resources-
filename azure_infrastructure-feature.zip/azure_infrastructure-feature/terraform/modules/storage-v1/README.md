<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_managed_disk.source](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/managed_disk) | resource |
| [azurerm_storage_account.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |
| [azurerm_storage_container.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_container) | resource |
| [azurerm_storage_share.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_share) | resource |
| [random_id.this](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/id) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_access_tier"></a> [access\_tier](#input\_access\_tier) | storage account access\_tier: Hot, Cool | `string` | `"Hot"` | no |
| <a name="input_account_kind"></a> [account\_kind](#input\_account\_kind) | storage account kind: Storage, StorageV2, BlobStorage, FileStorage, BlockBlobStorage | `string` | `"StorageV2"` | no |
| <a name="input_account_replication_type"></a> [account\_replication\_type](#input\_account\_replication\_type) | storage account replication\_type: LRS, GRS, RAGRS, ZRS, GZRS and RAGZRS | `string` | `"LRS"` | no |
| <a name="input_account_tier"></a> [account\_tier](#input\_account\_tier) | storage account\_tier: Standard, Premium | `string` | `"Standard"` | no |
| <a name="input_disks"></a> [disks](#input\_disks) | storage disks | <pre>list(object({<br>    name = string<br>    size = number<br>    tier = string<br>  }))</pre> | `[]` | no |
| <a name="input_location"></a> [location](#input\_location) | storage account location | `string` | n/a | yes |
| <a name="input_name"></a> [name](#input\_name) | storage account name | `string` | n/a | yes |
| <a name="input_network_rules"></a> [network\_rules](#input\_network\_rules) | storage account network\_rules for subnetes / ip ranges | <pre>object({<br>    subnet_ids = list(string)<br>    ip_ranges  = list(string)<br>  })</pre> | <pre>{<br>  "ip_ranges": [],<br>  "subnet_ids": []<br>}</pre> | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | storage account resource\_group\_name | `string` | n/a | yes |
| <a name="input_storage_containers"></a> [storage\_containers](#input\_storage\_containers) | storage containers | `list(string)` | `[]` | no |
| <a name="input_storage_shares"></a> [storage\_shares](#input\_storage\_shares) | storage fileshares | <pre>list(object({<br>    name        = string<br>    quota       = number<br>    permissions = string # "r,w,d,l"<br>  }))</pre> | `[]` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | resource tags | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_primary_access_key"></a> [primary\_access\_key](#output\_primary\_access\_key) | storage primary\_access\_key |
<!-- END_TF_DOCS -->