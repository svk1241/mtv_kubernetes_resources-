variable "name" {
  description = "storage account name"
  type        = string
}

variable "resource_group_name" {
  description = "storage account resource_group_name"
  type        = string
}

variable "location" {
  description = "storage account location"
  type        = string
}

variable "account_tier" {
  description = "storage account_tier: Standard, Premium"
  type        = string
  default     = "Standard"
}

variable "account_kind" {
  description = "storage account kind: Storage, StorageV2, BlobStorage, FileStorage, BlockBlobStorage"
  type        = string
  default     = "StorageV2"
}

variable "account_replication_type" {
  description = "storage account replication_type: LRS, GRS, RAGRS, ZRS, GZRS and RAGZRS"
  type        = string
  default     = "LRS"
}

variable "access_tier" {
  description = "storage account access_tier: Hot, Cool"
  type        = string
  default     = "Hot"
}

variable "network_rules" {
  description = "storage account network_rules for subnetes / ip ranges"
  type = object({
    subnet_ids = list(string)
    ip_ranges  = list(string)
  })

  default = {
    subnet_ids = []
    ip_ranges  = []
  }
}

variable "storage_shares" {
  description = "storage fileshares"
  type = list(object({
    name        = string
    quota       = number
    permissions = string # "r,w,d,l"
  }))

  default = []
}

variable "disks" {
  description = "storage disks"
  type = list(object({
    name = string
    size = number
    tier = string
  }))

  default = []
}

variable "tags" {
  description = "resource tags"
  type        = map(string)
  default     = {}
}

variable "storage_containers" {
  description = "storage containers"
  type        = list(string)
  default     = []
}