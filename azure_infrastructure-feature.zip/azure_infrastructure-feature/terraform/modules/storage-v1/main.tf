resource "random_id" "this" {
  count       = length(var.storage_shares) > 0 ? 1 : 0
  byte_length = 8
}

resource "azurerm_storage_account" "this" {
  name                     = var.name
  resource_group_name      = var.resource_group_name
  location                 = var.location
  account_tier             = var.account_tier
  account_kind             = var.account_kind
  account_replication_type = var.account_replication_type
  access_tier              = var.access_tier

  network_rules {
    default_action             = length(var.network_rules.ip_ranges) > 0 || length(var.network_rules.subnet_ids) > 0 ? "Deny" : "Allow"
    ip_rules                   = var.network_rules.ip_ranges
    virtual_network_subnet_ids = var.network_rules.subnet_ids
  }

  tags = var.tags
}

resource "azurerm_storage_share" "this" {
  count = length(var.storage_shares)

  name                 = var.storage_shares[count.index].name
  storage_account_name = azurerm_storage_account.this.name
  quota                = var.storage_shares[count.index].quota

  acl {
    id = "${random_id.this[0].hex}x${var.storage_shares[count.index].name}x${var.storage_shares[count.index].quota}"
    access_policy {
      permissions = var.storage_shares[count.index].permissions
    }
  }

  depends_on = [
    azurerm_storage_account.this
  ]
}

resource "azurerm_managed_disk" "source" {
  count = length(var.disks)

  name                 = var.disks[count.index].name
  location             = var.location
  resource_group_name  = var.resource_group_name
  storage_account_type = "Premium_LRS"
  create_option        = "Empty"
  disk_size_gb         = var.disks[count.index].size
  #tier                 = var.disks[count.index].tier

  tags = {
    environment = "staging"
  }
}

resource "azurerm_storage_container" "this" {
  count                 = length(var.storage_containers)
  name                  = var.storage_containers[count.index]
  storage_account_name  = azurerm_storage_account.this.name
  container_access_type = "private"
}