output "primary_access_key" {
  description = "storage primary_access_key"
  value       = azurerm_storage_account.this.primary_access_key
}
