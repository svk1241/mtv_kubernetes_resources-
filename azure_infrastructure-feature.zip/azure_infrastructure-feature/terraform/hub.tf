resource "azurerm_resource_group" "hub" {
  location = local.location
  name     = "rg-hub-eastus-private"
}

module "hub" {
  source              = "./modules/hub-networking-v1"
  resource_group_name = azurerm_resource_group.hub.name
  vnet_cidr_block     = "10.0.0.0/16"
  secret              = ["rg-service-global", "kv-secrets-eastus-global", "vpn-client-config", "default-vm-access"]

  application = "network"
  environment = "hub"
  location    = local.location
  visibility  = local.visibility
  dns_servers = ["10.0.0.4"]

  dns_zone_name = local.dns_zone_name
}


module "acr" {
  source              = "./modules/acr-v1"
  resource_group_name = azurerm_resource_group.hub.name

  application = "registry"
  environment = "hub"
  location    = local.location
  visibility  = local.visibility
}

module "acr_public" {
  source = "./modules/acr-v2"

  name                = "acr${local.location}public001"
  resource_group_name = azurerm_resource_group.hub.name
  location            = azurerm_resource_group.hub.location
  sku                 = "Premium"
  admin_enabled       = true

  users = [{
    username    = "readonly"
    permissions = "pull"
  }]

  tags = {
    resource_group = azurerm_resource_group.hub.name
    region         = azurerm_resource_group.hub.location
    realm          = "hub"
  }
}
