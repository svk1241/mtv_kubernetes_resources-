resource "azurerm_resource_group" "spoke-dev-001" {
  location   = local.location
  name       = "rg-spoke-dev-001-eastus-private"
  depends_on = [module.hub.kubernetes_dns_zone_id]
}

module "development_001_networking" {
  source                  = "./modules/spoke-networking-v1"
  resource_group_name     = azurerm_resource_group.spoke-dev-001.name
  vnet_cidr_block         = "10.8.0.0/16"
  subnet_cidr_block       = "10.8.0.0/24"
  hub_resource_group_name = azurerm_resource_group.hub.name
  hub_vnet_id             = module.hub.vnet_id
  hub_vnet_name           = module.hub.vnet_name

  dns_zone_name = local.dns_zone_name

  application = "networking"
  environment = "dev001"
  location    = local.location
  visibility  = local.visibility

  enforce_private_link_endpoint_network_policies = true
}

module "dev-backend" {
  source              = "./modules/linux-vm-v2"
  resource_group_name = azurerm_resource_group.spoke-dev-001.name
  subnet_id           = module.development_001_networking.subnet_id
  vm_size             = "Standard_B4ms"
  vm_image            = ["RedHat", "RHEL", "8_3", "latest"]
  secret              = ["rg-service-global", "kv-secrets-eastus-global", "vm-access-v2"]
  name_prefix         = "dev-backend"
  instance_count      = 2
  start_count_number  = 1

  application = "backend"
  environment = "dev001"
  location    = local.location
  visibility  = local.visibility
}

module "win-gui-dev" {
  source              = "./modules/windows-vm-auto-v2"
  resource_group_name = azurerm_resource_group.spoke-dev-001.name
  subnet_id           = module.development_001_networking.subnet_id
  vm_size             = "Standard_D4s_v3"
  vm_image_id         = "/subscriptions/d705f4d8-7a99-4443-b7df-67187358521f/resourceGroups/rg-cm-001-eastus-private/providers/Microsoft.Compute/images/WindowsServer2016-with-mtv-v2"
  secret              = ["rg-service-global", "kv-secrets-eastus-global", "default-vm-access"]
  name_prefix         = "dev-gui"
  instance_indexes    = ["1"]

  application = "clients"
  environment = "dev001"
  location    = local.location
  visibility  = local.visibility
}
