locals {
  aks002_nodepools = {
    extpool = {
      name             = "extpool"
      k8s_version      = "1.26.6"
      os_sku           = "AzureLinux"
      nodepool_vm_size = "Standard_D4s_v3"
      taints           = ["purpose=extensions:NoSchedule"]
      labels           = { "purpose" = "extensions" }
      environment      = "aks002"
      min_nodes_count  = 0
      max_nodes_count  = 10
      mode             = "User"
    }
    extpool2 = {
      name             = "extpool2"
      k8s_version      = "1.26.6"
      os_sku           = "AzureLinux"
      nodepool_vm_size = "Standard_D4s_v3"
      taints           = ["purpose=extensions_mock:NoSchedule"]
      labels           = { "purpose" = "extensions_mock" }
      environment      = "aks002"
      min_nodes_count  = 0
      max_nodes_count  = 10
      mode             = "User"
    }
    eaaspool = {
      name             = "eaaspool"
      k8s_version      = "1.26.6"
      os_sku           = "AzureLinux"
      nodepool_vm_size = "Standard_D4s_v3"
      taints           = ["purpose=extensions-eaas:NoSchedule"]
      labels           = { "purpose" = "extensions-eaas" }
      environment      = "aks002"
      min_nodes_count  = 0
      max_nodes_count  = 10
      mode             = "User"
    }
    servicepool = {
      name             = "servicepool"
      k8s_version      = "1.26.6"
      os_sku           = "AzureLinux"
      nodepool_vm_size = "Standard_D4s_v3"
      taints           = ["purpose=service:NoSchedule"]
      labels           = { "purpose" = "service" }
      environment      = "aks002"
      min_nodes_count  = 3
      max_nodes_count  = 5
      mode             = "User"
    }
    concpool = {
      source           = "./modules/node-pool-v1"
      name             = "concpool"
      k8s_version      = "1.26.6"
      os_sku           = "AzureLinux"
      nodepool_vm_size = "Standard_D4s_v3"
      taints           = ["purpose=concurrency:NoSchedule"]
      labels           = { "purpose" = "concurrency" }
      environment      = "aks002"
      min_nodes_count  = 0
      max_nodes_count  = 10
      mode             = "User"
    }
    intpool = {
      source           = "./modules/node-pool-v1"
      name             = "intpool"
      k8s_version      = "1.26.6"
      os_sku           = "AzureLinux"
      nodepool_vm_size = "Standard_D4s_v3"
      taints           = ["purpose=integration86:NoSchedule"]
      labels           = { "purpose" = "integration86" }
      environment      = "aks002"
      min_nodes_count  = 0
      max_nodes_count  = 3
      mode             = "User"
    }
    regrpool = {
      source           = "./modules/node-pool-v1"
      name             = "regrpool"
      k8s_version      = "1.26.6"
      os_sku           = "AzureLinux"
      nodepool_vm_size = "Standard_D4s_v3"
      taints           = ["purpose=regression:NoSchedule"]
      labels           = { "purpose" = "regression" }
      environment      = "aks002"
      min_nodes_count  = 0
      max_nodes_count  = 10
      mode             = "User"
    }
    genpocpool = {
      source           = "./modules/node-pool-v1"
      name             = "genpocpool"
      k8s_version      = "1.26.6"
      os_sku           = "AzureLinux"
      nodepool_vm_size = "Standard_D4s_v3"
      taints           = ["purpose=ca_gen_migration_poc:NoSchedule"]
      labels           = { "purpose" = "ca_gen_migration_poc" }
      environment      = "aks002"
      min_nodes_count  = 0
      max_nodes_count  = 3
      mode             = "User"
    }
    devpool = {
      source           = "./modules/node-pool-v1"
      name             = "devpool"
      k8s_version      = "1.26.6"
      os_sku           = "AzureLinux"
      nodepool_vm_size = "Standard_D4s_v3"
      taints           = ["purpose=dev:NoSchedule"]
      labels           = { "purpose" = "dev" }
      environment      = "aks002"
      min_nodes_count  = 0
      max_nodes_count  = 3
      mode             = "User"
    }
  }

  aks001_nodepools = {}
  aks003_nodepools = {}

}

resource "azurerm_resource_group" "spoke-aks001" {
  location   = local.location
  name       = "rg-spoke-aks001-eastus-private"
  depends_on = [module.hub.kubernetes_dns_zone_id]
}

resource "azurerm_proximity_placement_group" "ppg-aks-001" {
  name                = "ppg-spoke-aks001-001"
  location            = local.location
  resource_group_name = azurerm_resource_group.spoke-aks001.name

  tags = {
    environment = "aks002"
  }
}

# TO-DO: Investigate if we need networking below or add networking for AKS003
# TO-DO: Investigate if private_cluster_public_fqdn_enabled should be set to false explicitly

module "aks001_networking" {
  source                   = "./modules/spoke-networking-v1"
  resource_group_name      = azurerm_resource_group.spoke-aks001.name
  vnet_cidr_block          = "10.3.0.0/16"
  subnet_cidr_block        = "10.3.0.0/20"
  subnet_service_endpoints = ["Microsoft.Storage"]
  hub_resource_group_name  = azurerm_resource_group.hub.name
  hub_vnet_id              = module.hub.vnet_id
  hub_vnet_name            = module.hub.vnet_name

  dns_zone_name = local.dns_zone_name
  is_aks_vnet   = true

  enforce_private_link_endpoint_network_policies = true

  application = "networking"
  environment = "aks001"
  location    = local.location
  visibility  = local.visibility
}

module "aks002_networking" {
  source                   = "./modules/spoke-networking-v1"
  resource_group_name      = azurerm_resource_group.spoke-aks001.name
  vnet_cidr_block          = "10.9.0.0/18"
  subnet_cidr_block        = "10.9.0.0/20"
  subnet_service_endpoints = ["Microsoft.Storage"]
  hub_resource_group_name  = azurerm_resource_group.hub.name
  hub_vnet_id              = module.hub.vnet_id
  hub_vnet_name            = module.hub.vnet_name

  dns_zone_name = local.dns_zone_name
  is_aks_vnet   = true

  enforce_private_link_endpoint_network_policies = true

  application = "networking"
  environment = "aks002"
  location    = local.location
  visibility  = local.visibility
}

#############################################################
# Accelerated clusters                                      #
#############################################################
# Additional cluster for Kubernetes upgrade validation
module "aks002_cluster" {
  source                 = "./modules/aks-v1"
  resource_group_name    = azurerm_resource_group.spoke-aks001.name
  user_identity          = "aks-identity2"
  k8s_version            = "1.26.6"
  location               = local.location
  visibility             = "private"
  application            = "k8s_cluster"
  environment            = "aks002"
  subnet_id              = module.aks001_networking.subnet_id
  default_nodes_vm_size  = "Standard_D4s_v3"
  default_node_pool_name = "systempool"
  min_nodes_count        = 3
  max_nodes_count        = 5
  os_sku                 = "AzureLinux"
  acr_id                 = module.acr.id
  service_cidr           = "10.4.0.0/16"
  dns_service_ip         = "10.4.16.10"
  docker_bridge_cidr     = "172.17.0.1/16"
  kubernetes_dns_zone_id = module.hub.kubernetes_dns_zone_id
  rbac_enabled           = true
  ppg_id                 = azurerm_proximity_placement_group.ppg-aks-001.id
  aad_integration = {
    enabled = false
  }
}

module "aks002_nodepools" {
  for_each = local.aks002_nodepools

  source           = "./modules/node-pool-v1"
  name             = each.value.name
  k8s_version      = each.value.k8s_version
  os_sku           = each.value.os_sku
  cluster_id       = module.aks002_cluster.cluster_id
  subnet_id        = module.aks001_networking.subnet_id
  nodepool_vm_size = each.value.nodepool_vm_size
  taints           = each.value.taints
  labels           = each.value.labels
  environment      = each.value.environment
  min_nodes_count  = each.value.min_nodes_count
  max_nodes_count  = each.value.max_nodes_count
  mode             = each.value.mode
  ppg_id           = azurerm_proximity_placement_group.ppg-aks-001.id
}

# TO-DO: Remove obsolete batch files shares from AKS 001 storage account
module "aks001_storage" {
  source                   = "./modules/storage-v1"
  name                     = "aks001${local.location}${local.visibility}"
  resource_group_name      = azurerm_resource_group.spoke-aks001.name
  location                 = azurerm_resource_group.spoke-aks001.location
  account_tier             = "Standard"
  account_kind             = "StorageV2"
  account_replication_type = "LRS"
  access_tier              = "Hot"

  storage_shares = [{
    name        = "aks001${local.location}share"
    quota       = 1000
    permissions = "rwdl"
  }]

  tags = {
    resource_group = azurerm_resource_group.spoke-aks001.name
    region         = azurerm_resource_group.spoke-aks001.location
    realm          = "spoke"
  }
}

module "aks001_tempostorage" {
  source                   = "./modules/storage-v1"
  name                     = "aks001tempostorage"
  resource_group_name      = azurerm_resource_group.spoke-aks001.name
  location                 = azurerm_resource_group.spoke-aks001.location
  account_tier             = "Standard"
  account_kind             = "StorageV2"
  account_replication_type = "LRS"
  access_tier              = "Hot"
  storage_containers       = ["tempo"]
}

module "aks002_lokistorage" {
  source                   = "./modules/storage-v1"
  name                     = "aks002lokistorage"
  resource_group_name      = azurerm_resource_group.spoke-aks001.name
  location                 = azurerm_resource_group.spoke-aks001.location
  account_tier             = "Standard"
  account_kind             = "StorageV2"
  account_replication_type = "LRS"
  access_tier              = "Hot"
  storage_containers       = ["loki", "loki-aks001"]
}

module "aks002_tempostorage" {
  source                   = "./modules/storage-v1"
  name                     = "aks002tempostorage"
  resource_group_name      = azurerm_resource_group.spoke-aks001.name
  location                 = azurerm_resource_group.spoke-aks001.location
  account_tier             = "Standard"
  account_kind             = "StorageV2"
  account_replication_type = "LRS"
  access_tier              = "Hot"
  storage_containers       = ["tempo"]
}

module "aks003_lokistorage" {
  source                   = "./modules/storage-v1"
  name                     = "aks003lokistorage"
  resource_group_name      = azurerm_resource_group.spoke-aks001.name
  location                 = azurerm_resource_group.spoke-aks001.location
  account_tier             = "Standard"
  account_kind             = "StorageV2"
  account_replication_type = "LRS"
  access_tier              = "Hot"
  storage_containers       = ["loki"]
}

module "aks003_tempostorage" {
  source                   = "./modules/storage-v1"
  name                     = "aks003tempostorage"
  resource_group_name      = azurerm_resource_group.spoke-aks001.name
  location                 = azurerm_resource_group.spoke-aks001.location
  account_tier             = "Standard"
  account_kind             = "StorageV2"
  account_replication_type = "LRS"
  access_tier              = "Hot"
  storage_containers       = ["tempo"]
}

module "integration-oracle-database-001" {
  source              = "./modules/oracle-db-v2"
  resource_group_name = azurerm_resource_group.spoke-aks001.name
  hostname            = "integration-oracle-001"
  subnet_id           = module.aks001_networking.subnet_id
  vm_size             = "Standard_E4s_v3"
  vm_image            = ["Oracle", "oracle-database-19-3", "oracle-database-19-0904", "latest"]
  volume_size         = ["256"]
  secret              = ["rg-service-global", "kv-secrets-eastus-global", "default-vm-access"]

  ppg_id                     = azurerm_proximity_placement_group.ppg-aks-001.id
  use_accelerated_networking = true

  application = "oracle-an"
  environment = "integration"
  location    = local.location
  visibility  = local.visibility
}

module "regression-oracle-database-001" {
  source              = "./modules/oracle-db-v2"
  resource_group_name = azurerm_resource_group.spoke-aks001.name
  hostname            = "regression-oracle-001"
  subnet_id           = module.aks001_networking.subnet_id
  vm_size             = "Standard_E4s_v3"
  vm_image            = ["Oracle", "oracle-database-19-3", "oracle-database-19-0904", "latest"]
  volume_size         = ["256"]
  secret              = ["rg-service-global", "kv-secrets-eastus-global", "default-vm-access"]

  ppg_id                     = azurerm_proximity_placement_group.ppg-aks-001.id
  use_accelerated_networking = true

  application = "oracle-an"
  environment = "regression"
  location    = local.location
  visibility  = local.visibility
}

module "concurrency-oracle-database-001" {
  source              = "./modules/oracle-db-v2"
  resource_group_name = azurerm_resource_group.spoke-aks001.name
  hostname            = "concurrency-oracle-001"
  subnet_id           = module.aks001_networking.subnet_id
  vm_size             = "Standard_D8s_v3"
  vm_image            = ["Oracle", "oracle-database-19-3", "oracle-database-19-0904", "latest"]
  volume_size         = ["256"]
  secret              = ["rg-service-global", "kv-secrets-eastus-global", "default-vm-access"]

  ppg_id                     = azurerm_proximity_placement_group.ppg-aks-001.id
  use_accelerated_networking = true

  application = "oracle-an"
  environment = "concurrency"
  location    = local.location
  visibility  = local.visibility
}

module "extensions-oracle-database-001" {
  source              = "./modules/oracle-db-v2"
  resource_group_name = azurerm_resource_group.spoke-aks001.name
  hostname            = "extensions-oracle-001"
  subnet_id           = module.aks001_networking.subnet_id
  vm_size             = "Standard_D8s_v3"
  vm_image            = ["Oracle", "oracle-database-19-3", "oracle-database-19-0904", "latest"]
  volume_size         = ["512"]
  secret              = ["rg-service-global", "kv-secrets-eastus-global", "default-vm-access"]

  ppg_id                     = azurerm_proximity_placement_group.ppg-aks-001.id
  use_accelerated_networking = true

  application = "oracle-an"
  environment = "extensions"
  location    = local.location
  visibility  = local.visibility
}

module "dev-oracle-database-001" {
  source              = "./modules/oracle-db-v2"
  resource_group_name = azurerm_resource_group.spoke-aks001.name
  hostname            = "dev-oracle-001"
  subnet_id           = module.aks001_networking.subnet_id
  vm_size             = "Standard_E4s_v3"
  vm_image            = ["Oracle", "oracle-database-19-3", "oracle-database-19-0904", "latest"]
  volume_size         = ["256"]
  secret              = ["rg-service-global", "kv-secrets-eastus-global", "default-vm-access"]

  ppg_id                     = azurerm_proximity_placement_group.ppg-aks-001.id
  use_accelerated_networking = true

  application = "oracle-an"
  environment = "dev"
  location    = local.location
  visibility  = local.visibility
}

##########################################################################
# SMB server for batch filesystems mount                                 #
##########################################################################

module "smb-server" {
  source              = "./modules/smb-server-v1"
  resource_group_name = azurerm_resource_group.spoke-aks001.name
  subnet_id           = "/subscriptions/d705f4d8-7a99-4443-b7df-67187358521f/resourceGroups/rg-cm-001-eastus-private/providers/Microsoft.Network/virtualNetworks/vnet-networking-cm0001-eastus-private/subnets/snet-networking-cm0001-eastus-private-n3pw"
  vm_size             = "Standard_D4s_v3"
  vm_image            = ["MicrosoftWindowsServer", "WindowsServer", "2016-datacenter-gensecond", "latest"]
  secret              = ["rg-service-global", "kv-secrets-eastus-global", "default-vm-access"]
  disk_size           = [256, 256, 256, 256, 256, 256, 256]

  ppg_id                     = azurerm_proximity_placement_group.ppg-aks-001.id
  use_accelerated_networking = true

  location = local.location
}
