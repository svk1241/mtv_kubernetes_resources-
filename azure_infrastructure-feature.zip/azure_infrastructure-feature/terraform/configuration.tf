terraform {
  required_version = ">=1.5.0"
  backend "azurerm" {
    resource_group_name  = "rg-service-global"
    storage_account_name = "deltadentalmtv"
    container_name       = "tfstate"
    key                  = "global.terraform.tfstate"
  }

  required_providers {
    azurerm = {
      version = "~>3.74.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "~>3.5.1"
    }
  }
}

provider "azurerm" {
  subscription_id = "d705f4d8-7a99-4443-b7df-67187358521f"
  features {}
}


locals {
  location      = "eastus"
  visibility    = "private"
  dns_zone_name = "ddmtv.private"
}
