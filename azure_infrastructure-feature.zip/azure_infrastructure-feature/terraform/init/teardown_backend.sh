#!/bin/bash

RESOURCE_GROUP_NAME=rg-service-global
STORAGE_ACCOUNT_NAME=deltadentalmtv
CONTAINER_NAME=tfstate


ACCOUNT_KEY=$(az storage account keys list --resource-group $RESOURCE_GROUP_NAME --account-name $STORAGE_ACCOUNT_NAME --query '[0].value' -o tsv)

az storage container delete --name $CONTAINER_NAME --account-name $STORAGE_ACCOUNT_NAME --account-key $ACCOUNT_KEY

az storage account delete --resource-group $RESOURCE_GROUP_NAME --name $STORAGE_ACCOUNT_NAME --yes

az group delete --name $RESOURCE_GROUP_NAME --yes