resource "azurerm_resource_group" "automation-testing-001" {
  location   = local.location
  name       = "rg-automation-testing-001-eastus-private"
  depends_on = [module.hub.kubernetes_dns_zone_id]
}

module "auto_test_001_networking" {
  source                  = "./modules/spoke-networking-v1"
  resource_group_name     = azurerm_resource_group.automation-testing-001.name
  vnet_cidr_block         = "10.6.0.0/16"
  subnet_cidr_block       = "10.6.0.0/24"
  hub_resource_group_name = azurerm_resource_group.hub.name
  hub_vnet_id             = module.hub.vnet_id
  hub_vnet_name           = module.hub.vnet_name

  dns_zone_name = local.dns_zone_name

  application                                    = "networking"
  environment                                    = "testing001"
  location                                       = local.location
  visibility                                     = local.visibility
  enforce_private_link_endpoint_network_policies = true
}


module "windows-gui-test" {
  source              = "./modules/windows-vm-auto-v2"
  resource_group_name = azurerm_resource_group.automation-testing-001.name
  subnet_id           = module.auto_test_001_networking.subnet_id
  vm_size             = "Standard_B2ms"
  vm_image_id         = "/subscriptions/d705f4d8-7a99-4443-b7df-67187358521f/resourceGroups/rg-cm-001-eastus-private/providers/Microsoft.Compute/images/WindowsServer2016-with-mtv-v2"
  secret              = ["rg-service-global", "kv-secrets-eastus-global", "default-vm-access"]
  name_prefix         = "auto-gui"
  instance_indexes    = ["2", "3", "4", "6"]

  application = "clients"
  environment = "testing001"
  location    = local.location
  visibility  = local.visibility
}

module "windows-workstation" {
  source              = "./modules/windows-vm-auto-v2"
  resource_group_name = azurerm_resource_group.automation-testing-001.name
  subnet_id           = module.auto_test_001_networking.subnet_id
  vm_size             = "Standard_B2ms"
  vm_image_id         = "/subscriptions/d705f4d8-7a99-4443-b7df-67187358521f/resourceGroups/rg-cm-001-eastus-private/providers/Microsoft.Compute/images/WindowsServer2016-with-mtv-v2"
  secret              = ["rg-service-global", "kv-secrets-eastus-global", "default-vm-access"]
  name_prefix         = "auto-work"
  instance_indexes    = ["1", "2", "3", "4", "5", "6", "10"]

  application = "workstations"
  environment = "testing001"
  location    = local.location
  visibility  = local.visibility
}

module "windows-api-proxies" {
  source              = "./modules/windows-vm-auto-v2"
  resource_group_name = azurerm_resource_group.automation-testing-001.name
  subnet_id           = module.auto_test_001_networking.subnet_id
  vm_size             = "Standard_B2ms"
  vm_image_id         = "/subscriptions/d705f4d8-7a99-4443-b7df-67187358521f/resourceGroups/rg-cm-001-eastus-private/providers/Microsoft.Compute/images/WindowsServer2016-with-mtv-v2"
  secret              = ["rg-service-global", "kv-secrets-eastus-global", "default-vm-access"]
  name_prefix         = "auto-api"
  instance_indexes    = ["1", "2"]

  application = "api"
  environment = "testing001"
  location    = local.location
  visibility  = local.visibility
}

module "postgres-db" {
  source              = "./modules/postgres-db-v1"
  resource_group_name = azurerm_resource_group.automation-testing-001.name
  db_specs            = ["7", "false", "true"] # [<backup retention days>, <geo_redundant_backup_enabled>, <auto_grow_enabled>]
  db_image            = ["GP_Gen5_2", "11"]    # [<SKU>, <version>]
  secret              = ["rg-service-global", "kv-secrets-eastus-global", "default-vm-access", "postgress-access"]
  storage             = 32768
  vnet_name           = module.auto_test_001_networking.vnet_name
  prefix              = "10.6.1.0/24"

  backup_vault_name  = "bv-automation-testing-001"
  backup_policy_name = "postgress-daily"
  db_instances = {
    mtv      = "vm-postgres-testing-001-eastus-private-k0e0\\mtv",
    metabase = "vm-postgres-testing-001-eastus-private-k0e0\\metabase"
  }

  application = "postgres"
  environment = "testing-001"
  location    = local.location
  visibility  = local.visibility
}

module "linux-rdp" {
  source              = "./modules/linux-vm-rdp-v1"
  resource_group_name = azurerm_resource_group.automation-testing-001.name
  subnet_id           = module.auto_test_001_networking.subnet_id
  vm_size             = "Standard_B2ms"
  vm_image            = ["RedHat", "RHEL", "8_3", "latest"]
  secret              = ["rg-service-global", "kv-secrets-eastus-global", "default-vm-access"]
  name_prefix         = "auto-rdp"
  instance_count      = 1
  start_count_number  = 1

  application = "rdp"
  environment = "testing001"
  location    = local.location
  visibility  = local.visibility
}

###
# Accelerated Network Latency

resource "azurerm_proximity_placement_group" "ppg-automation-testing-001" {
  name                = "ppg-automation-testing-001"
  location            = local.location
  resource_group_name = azurerm_resource_group.automation-testing-001.name

  tags = {
    environment = "automation-testing-001"
    environment = "testing001"
  }
}

###
# MQ Series Instances

module "mq_instances" {
  source              = "./modules/mq-instances-v1"
  resource_group_name = "rg-spoke-poc001-eastus-private"
  subnet_id           = "/subscriptions/d705f4d8-7a99-4443-b7df-67187358521f/resourceGroups/rg-spoke-poc001-eastus-private/providers/Microsoft.Network/virtualNetworks/vnet-networking-poc001-eastus-private/subnets/snet-networking-poc001-eastus-private-c6e0"
  vm_size             = "Standard_B4ms"
  win_image           = ["MicrosoftWindowsServer", "WindowsServer", "2016-Datacenter", "latest"]
  linux_image         = ["RedHat", "RHEL", "8.1", "latest"]
  secret              = ["rg-service-global", "kv-secrets-eastus-global", "default-vm-access"]
  instance_count      = 1
  disk_size           = 32

  location = local.location
}
