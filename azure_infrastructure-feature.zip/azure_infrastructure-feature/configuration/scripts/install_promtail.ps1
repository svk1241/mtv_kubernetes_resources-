param (
	[Parameter (Mandatory=$true, Position=1)]
    [String]$pass, # pragma: allowlist secret

    [Parameter (Mandatory=$true, Position=2)]
    [String]$promtail_port,
	
	[Parameter (Mandatory=$true, Position=3)]
    [String]$loki_ip,
    
    [Parameter (Mandatory=$true, Position=4)]
    [String]$loki_port

)

$fullpath = "C:\Promtail"

$url_promtail = "https://artifactory.luxoft.com/ddmtv-generic/Promtail/promtail-service-src.zip"
$user = 'svc_ddmtv_cicd'

$pair = "$($user):$($pass)"

$encodedCreds = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($pair))

$basicAuthValue = "Basic $encodedCreds"

$Headers = @{
    Authorization = $basicAuthValue
}

#Create a folder for Promtail
If(!(test-path $fullpath))
{
New-Item -ItemType Directory -Force -Path $fullpath
}
Write-Host ""

#Download and install Promtail
Invoke-WebRequest -Uri $url_promtail -Headers $Headers -OutFile "$fullpath\promtail-service-src.zip"
Expand-Archive  "$fullpath\promtail-service-src.zip" -DestinationPath "$fullpath" -Force
(Get-Content $fullpath\promtail-service-src\config.yaml).replace('<promtail-port>', $promtail_port) | Set-Content $fullpath\promtail-service-src\config.yaml
(Get-Content $fullpath\promtail-service-src\config.yaml).replace('<loki-ip>', $loki_ip) | Set-Content $fullpath\promtail-service-src\config.yaml
(Get-Content $fullpath\promtail-service-src\config.yaml).replace('<loki-port>', $loki_port) | Set-Content $fullpath\promtail-service-src\config.yaml


#Run Promtail Service
Start-Process -NoNewWindow -FilePath "$fullpath\promtail-service-src\promtail-service.exe" -ArgumentList "install" -passthru
Start-Sleep -Seconds 3
Start-Process -NoNewWindow -FilePath "$fullpath\promtail-service-src\promtail-service.exe" -ArgumentList "start" -passthru
Write-Host "Promtail installed successfuly!"