Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0
Start-Service sshd
Set-Service -Name sshd -StartupType 'Automatic'
$rule = Get-NetFirewallRule -DisplayName 'OpenSSH Server (sshd)' 2> $null; 
if ($rule) { 
    write-host "OpenSSH Server (sshd) rule already installed"; 
} 
else { 
    New-NetFirewallRule -Name sshd -DisplayName 'OpenSSH Server (sshd)' -Enabled True -Direction Inbound -Protocol TCP -Action Allow -LocalPort 22
    write-host "OpenSSH Server (sshd) rule was installed"; 
}
