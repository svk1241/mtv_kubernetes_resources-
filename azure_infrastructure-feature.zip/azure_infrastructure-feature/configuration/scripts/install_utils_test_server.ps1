﻿$fullpath = "C:\Distrib"

$url_vs = "https://artifactory.luxoft.com/ddmtv-generic/VS2012_prof.7z"
$url_vs_update = "https://artifactory.luxoft.com/ddmtv-generic/VS2012_update5.7z"

$cool85 = "https://artifactory.luxoft.com/ddmtv-generic/COOL85.ZIP"
$commcfg = "https://artifactory.luxoft.com/ddmtv-generic/commcfg.ini"
$mtvclient = "https://artifactory.luxoft.com/ddmtv-generic/MTV_client_with_patch_42.zip"
$httpsproxy = "https://artifactory.luxoft.com/ddmtv-generic/backend/poc2/HttpsProxy-v.mock-24155ef.zip"
$httpsproxybat = "https://artifactory.luxoft.com/ddmtv-generic/TCPIPtoHTTPSProxy.bat"


$user = 'svc_ddmtv_cicd'
$pass = $args[0] # pragma: allowlist secret

$pair = "$($user):$($pass)"

$encodedCreds = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($pair))

$basicAuthValue = "Basic $encodedCreds"

$Headers = @{
    Authorization = $basicAuthValue
}

New-Item -ItemType Directory -Force -Path $fullpath

#Download and installation 7z
Write-Host "Download and installation 7z..."
Invoke-WebRequest -Uri "https://www.7-zip.org/a/7z1900-x64.exe" -OutFile "$fullpath\7z1900-x64.exe"
Unblock-File -Path "$fullpath\7z1900-x64.exe"
Start-Process -Wait -FilePath "$fullpath\7z1900-x64.exe" -ArgumentList '/S' -passthru

#Install 7zip module
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
Set-PSRepository -Name 'PSGallery' -SourceLocation "https://www.powershellgallery.com/api/v2" -InstallationPolicy Trusted
Install-Module -Name 7Zip4PowerShell -Force


#Download and Git
Write-Host "Download and installation Git..."
Invoke-WebRequest -Uri "https://github.com/git-for-windows/git/releases/download/v2.20.1.windows.1/Git-2.20.1-64-bit.exe" -OutFile "$fullpath\Git-2.20.1.exe"
Unblock-File -Path "$fullpath\Git-2.20.1.exe"
Start-Process -Wait -FilePath "$fullpath\Git-2.20.1.exe" -ArgumentLis '/VERYSILENT /SP-' -passthru

#Download and Java SE
Write-Host "Download and installation Java SE 8..."
Invoke-WebRequest -Uri "https://download.java.net/openjdk/jdk8u41/ri/openjdk-8u41-b04-windows-i586-14_jan_2020.zip" -OutFile "$fullpath\openjdk-8u41.zip"
Expand-Archive "$fullpath\openjdk-8u41.zip" -DestinationPath 'C:\Program Files\Java' -Force 

#Download and install JDK 16.0.1 
Write-Host "Download and installation JDK 16..."
Invoke-WebRequest -Uri https://artifactory.luxoft.com/ddmtv-generic/jdk-16.0.1_windows-x64_bin.exe -Headers $Headers -Outfile "$fullpath\jdk-16.0.1_windows-x64_bin.exe"
Unblock-File -Path "$fullpath\jdk-16.0.1_windows-x64_bin.exe"
$key = "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment"
$currentPath =  (Get-ItemProperty -Path $key -name Path).Path + ';'
$javaDir = "C:\Program Files\Java\jdk-16.0.1"
& "$env:C:\Distrib\jdk-16.0.1_windows-x64_bin.exe" /qn /log "$env:C:\Distrib\jdk-install.log"  INSTALLDIR="C:\Program Files\Java\jdk-16.0.1"

#Download and installation Visual C++ Redistributable 2012x64
Write-Host "Download and installation Visual C++ Redistributable 2012x64 ..."
Invoke-WebRequest -Uri "https://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU_4/vcredist_x64.exe" -OutFile "$fullpath\vcredist_x64.exe"
Unblock-File -Path "$fullpath\vcredist_x64.exe"
Start-Process -Wait -FilePath "$fullpath\vcredist_x64.exe" -ArgumentList '/Passive' -passthru


#Download and installation Visual C++ Redistributable 2012x86
Write-Host "Download and installation Visual C++ Redistributable 2012x86 ..."
Invoke-WebRequest -Uri "https://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU_4/vcredist_x86.exe" -OutFile "$fullpath\vcredist_x86.exe"
Unblock-File -Path "$fullpath\vcredist_x86.exe"
Start-Process -Wait -FilePath "$fullpath\vcredist_x86.exe" -ArgumentList '/Passive' -passthru

#Download and installation Visual C++ Redistributable 2019x64
Write-Host "Download and installation Visual C++ Redistributable 2012x64 ..."
Invoke-WebRequest -Uri "https://aka.ms/vs/16/release/vc_redist.x64.exe" -OutFile "$fullpath\vcredist_2019_x64.exe"
Unblock-File -Path "$fullpath\vcredist_2019_x64.exe"
Start-Process -Wait -FilePath "$fullpath\vcredist_2019_x64.exe" -ArgumentList '/Passive' -passthru

#Download and installation Visual C++ Redistributable 2019x86
Write-Host "Download and installation Visual C++ Redistributable 2012x86 ..."
Invoke-WebRequest -Uri "https://aka.ms/vs/16/release/vc_redist.x86.exe" -OutFile "$fullpath\vcredist_2019_x86.exe"
Unblock-File -Path "$fullpath\vcredist_2019_x86.exe"
Start-Process -Wait -FilePath "$fullpath\vcredist_2019_x86.exe" -ArgumentList '/Passive' -passthru

#Download and installation httpsproxy 2012
Invoke-WebRequest -Uri $httpsproxy -Headers $Headers -OutFile "$fullpath\HttpsProxy-v.mock-24155ef.zip"
Expand-7Zip -ArchiveFileName "$fullpath\HttpsProxy-v.mock-24155ef.zip" -TargetPath "C:\DDMTV\HttpsProxy"

#Download and installation httpsproxybat 
Invoke-WebRequest -Uri $httpsproxybat -Headers $Headers -OutFile "C:\Users\azadmin\Desktop\TCPIPtoHTTPSProxy.bat"



#Download and installation CaGen 8.5
Invoke-WebRequest -Uri $cool85 -Headers $Headers -OutFile "$fullpath\COOL85.ZIP"
Expand-7Zip -ArchiveFileName "$fullpath\COOL85.ZIP" -TargetPath "C:\"

Invoke-WebRequest -Uri $commcfg -Headers $Headers -OutFile "$fullpath\commcfg.ini"
Copy-Item "$fullpath\commcfg.ini" -Destination "C:\cool85\gen\VS110"


Copy-Item "C:\COOL85\Gen\VS110\WRE850N.DLL" -Destination "C:\COOL85\Gen\VS110\WRE850N.orig.DLL"
Copy-Item "C:\COOL85\Gen\VS110\WRE850N.oem.DLL" -Destination "C:\COOL85\Gen\VS110\WRE850N.DLL"

#Download MTV client
Invoke-WebRequest -Uri $mtvclient -Headers $Headers -OutFile "$fullpath\MTV_client_with_patch_42.zip"
Expand-7Zip -ArchiveFileName "$fullpath\MTV_client_with_patch_42.zip" -TargetPath "$fullpath\MTV_client_with_patch_42"

#Download and installation WinSDK
Write-Host "Download and installation Win SDK"
Invoke-WebRequest -Uri "https://download.microsoft.com/download/4/d/2/4d2b7011-606a-467e-99b4-99550bf24ffc/windowssdk/winsdksetup.exe" -OutFile "$fullpath\winsdksetup.exe"
Unblock-File -Path "$fullpath\winsdksetup.exe"
Start-Process -Wait -FilePath "$fullpath\winsdksetup.exe" -ArgumentLis '/norestart /q' -passthru

#Download and installation Python 3.8.5
Write-Host "Download and installation Python 3.8.5"
Invoke-WebRequest -Uri "https://www.python.org/ftp/python/3.8.5/python-3.8.5-amd64.exe" -OutFile "$fullpath\python-3.8.5.exe"
Unblock-File -Path "$fullpath\python-3.8.5.exe"
Start-Process -Wait -FilePath "$fullpath\python-3.8.5.exe" -ArgumentLis '/passive InstallAllUsers=1 PrependPath=1' -passthru

#Download and installation Far Manager
Invoke-WebRequest -Uri "https://www.farmanager.com/files/Far30b5800.x86.20210519.msi" -OutFile "$fullpath\Far30b5800.x64.20210519.msi"
Unblock-File -Path "$fullpath\Far30b5800.x64.20210519.msi"
Start-Process -Wait -FilePath "$fullpath\Far30b5800.x64.20210519.msi" -ArgumentList '/Passive' -passthru

#Download and installation Notepad++ 8.1.1
Invoke-WebRequest -Uri "https://github.com/notepad-plus-plus/notepad-plus-plus/releases/download/v8.1.1/npp.8.1.1.Installer.x64.exe" -OutFile "$fullpath\npp.8.1.1.Installer.x64.exe"
Unblock-File -Path "$fullpath\npp.8.1.1.Installer.x64.exe"
Start-Process -Wait -FilePath "$fullpath\npp.8.1.1.Installer.x64.exe" -ArgumentList "/S"

Write-Host "Download VScode"
Invoke-WebRequest -Uri "https://az764295.vo.msecnd.net/stable/054a9295330880ed74ceaedda236253b4f39a335/VSCodeUserSetup-x64-1.56.2.exe" -OutFile "$fullpath\VSCodeUserSetup-x64-1.56.2.exe"


$ca_gen = 'GEN85'
$ca_gen_val = 'C:\COOL85\'
[System.Environment]::SetEnvironmentVariable($ca_gen,$ca_gen_val,[System.EnvironmentVariableTarget]::Machine)


$gen_java = 'GEN85JRE'
$gen_java_val = 'C:\Program Files\Java\java-se-8u41-ri\jre\bin'
[System.Environment]::SetEnvironmentVariable($gen_java,$gen_java_val,[System.EnvironmentVariableTarget]::Machine)

$java = 'JAVA_HOME'
$java_val = 'C:\Program Files\Java\java-se-8u41-ri\jre'
[System.Environment]::SetEnvironmentVariable($java,$java_val,[System.EnvironmentVariableTarget]::Machine)


$7z_path = ';C:\Program Files\7-Zip'
$gitbash_path = ';C:\Program Files\Git\mingw64\bin'
$java_path = ';C:\Program Files\Java\java-se-8u41-ri\jre\bin'
$ca_gen_path =  ';C:\COOL85\Gen;C:\COOL85\Gen\VS110'
$python_path = ';C:\Users\azadmin\AppData\Roaming\Python\Python38\Scripts'

[Environment]::SetEnvironmentVariable(
    "Path",
    [Environment]::GetEnvironmentVariable("Path", [EnvironmentVariableTarget]::Machine) + $7z_path + $gitbash_path + $java_path + $ca_gen_path + $python_path,
    [EnvironmentVariableTarget]::Machine)