﻿$scriptPath = Split-Path -parent $MyInvocation.MyCommand.Definition
$servicePath = Join-Path $scriptPath "jenkins-slave.exe"

New-service -name jenkinsslave-agent-002 -binaryPathName $servicePath 
Set-Service -Name jenkinsslave-agent-002 -Description ‘LuxProject Jenkins Agent’ -StartupType Automatic
Start-Service -Name jenkinsslave-agent-002