$hostname = hostname
$jenkinsSecrets = @{
    "auto-gui-001" = "173815be617eb9d731e3c835b643e1d569d399c49af0ce6d271676995bdcbfc9";
    "auto-gui-002" = "ff3ea93e2802c9d8fae08db07acafb9bfb2d83638c218b92a1d3ed1c3afbc8ab";
    "auto-gui-003" = "8a036c3376d9cdedad64e26829effa8949909fa2c534fba8a8106df063c6eff5";
    "auto-gui-004" = "76ab5069f3ef16629a3d3b41b3e52ec32e7bed19f02aed07ab7c7ef5ec180f7d";
    "auto-gui-005" = "ea64b8f0639f2fe1bcd8bd0a76fb0357dfe97ddd8263cf15d42352cfef95f0fd";
    "auto-gui-006" = "13eebc78675d68823c11c309861c4c05bed60e4a293550db1502067eb385de8f";
    "auto-gui-007" = "3709767c2b56a7072388e6beac0fc89e159d58d72c17d0571c5596e063b8786d";
    "auto-gui-008" = "4af17c9e149d20b37152988add81e03ccdeb3f06412d8ce53f2cf20a53e8d8d3";
    "auto-gui-009" = "75cc8bfec47498d3c2df4f2fe89f8bf4832ddf1de9b169a3f59009ab4f6013df";
    "auto-gui-010" = "c0da0d7b01da457868b1c09436f730f86c650496a33e8d7c67c4913f2bedef0e";
}
$java = "C:\Program Files\Java\jdk-16.0.1\bin\java.exe"

$hostname
& $java -Xms512m -Xmx1536m -jar "C:\DDMTV\jenkins\agent.jar" -jnlpUrl "https://luxproject.luxoft.com/jenkins/computer/$hostname/slave-agent.jnlp" -secret $jenkinsSecrets[$hostname]  -workDir "C:\DDMTV\jenkins"