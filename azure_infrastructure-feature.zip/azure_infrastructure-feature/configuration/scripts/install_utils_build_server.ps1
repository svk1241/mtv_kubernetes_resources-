﻿$fullpath = "C:\Distrib"

$url_vs = "https://artifactory.luxoft.com/ddmtv-generic/VS2012_prof.7z"
$url_vs_update = "https://artifactory.luxoft.com/ddmtv-generic/VS2012_update5.7z"
$user = 'svc_ddmtv_cicd'
$pass = $args[0] # pragma: allowlist secret

$pair = "$($user):$($pass)"

$encodedCreds = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($pair))

$basicAuthValue = "Basic $encodedCreds"

$Headers = @{
    Authorization = $basicAuthValue
}


#Create a folder for distributives
If(!(test-path $fullpath))
{
New-Item -ItemType Directory -Force -Path $fullpath
}
Write-Host ""

#Download and installation 7z
Write-Host "Download and installation 7z..."
Invoke-WebRequest -Uri "https://www.7-zip.org/a/7z1900-x64.exe" -OutFile "$fullpath\7z1900-x64.exe"
Unblock-File -Path "$fullpath\7z1900-x64.exe"
Start-Process -Wait -FilePath "$fullpath\7z1900-x64.exe" -ArgumentList '/S' -passthru

#Install 7zip module
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
Set-PSRepository -Name 'PSGallery' -SourceLocation "https://www.powershellgallery.com/api/v2" -InstallationPolicy Trusted
Install-Module -Name 7Zip4PowerShell -Force


#Download and installation Visual C++ Redistributable 2012x64
Write-Host "Download and installation Visual C++ Redistributable 2012x64 ..."
Invoke-WebRequest -Uri "https://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU_4/vcredist_x64.exe" -OutFile "$fullpath\vcredist_x64.exe"
Unblock-File -Path "$fullpath\vcredist_x64.exe"
Start-Process -Wait -FilePath "$fullpath\vcredist_x64.exe" -ArgumentList '/Passive' -passthru


#Download and installation Visual C++ Redistributable 2012x86
Write-Host "Download and installation Visual C++ Redistributable 2012x86 ..."
Invoke-WebRequest -Uri "https://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU_4/vcredist_x86.exe" -OutFile "$fullpath\vcredist_x86.exe"
Unblock-File -Path "$fullpath\vcredist_x86.exe"
Start-Process -Wait -FilePath "$fullpath\vcredist_x86.exe" -ArgumentList '/Passive' -passthru

#Download and installation Visual C++ Redistributable 2019x64
Write-Host "Download and installation Visual C++ Redistributable 2012x64 ..."
Invoke-WebRequest -Uri "https://aka.ms/vs/16/release/vc_redist.x64.exe" -OutFile "$fullpath\vcredist_2019_x64.exe"
Unblock-File -Path "$fullpath\vcredist_2019_x64.exe"
Start-Process -Wait -FilePath "$fullpath\vcredist_2019_x64.exe" -ArgumentList '/Passive' -passthru

#Download and installation Visual C++ Redistributable 2019x86
Write-Host "Download and installation Visual C++ Redistributable 2012x86 ..."
Invoke-WebRequest -Uri "https://aka.ms/vs/16/release/vc_redist.x86.exe" -OutFile "$fullpath\vcredist_2019_x86.exe"
Unblock-File -Path "$fullpath\vcredist_2019_x86.exe"
Start-Process -Wait -FilePath "$fullpath\vcredist_2019_x86.exe" -ArgumentList '/Passive' -passthru


#Download and installation BuildTools 2019
Write-Host "Download and installation BuildTools 2019..."
Invoke-WebRequest -Uri "https://download.visualstudio.microsoft.com/download/pr/9b3476ff-6d0a-4ff8-956d-270147f21cd4/ccfb9355f4f753315455542f966025f96de734292d3908c8c3717e9685b709f0/vs_BuildTools.exe" -OutFile "$fullpath\vs_buildtools.exe"
Unblock-File -Path "$fullpath\vs_buildtools.exe"
Start-Process -Wait -FilePath "$fullpath\vs_buildtools.exe" -ArgumentList '--add Microsoft.VisualStudio.Workload.MSBuildTools --add Microsoft.VisualStudio.Workload.ManagedDesktopBuildTools --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended --passive --nocache --wait' -passthru

#Download and installation Boost
Write-Host "Download and installation Boost 1.75х32..."
Invoke-WebRequest -Uri "https://deac-riga.dl.sourceforge.net/project/boost/boost-binaries/1.75.0/boost_1_75_0-msvc-14.2-32.exe" -OutFile "$fullpath\boost_1_75_0-msvc-14.2-32.exe"
Unblock-File -Path "$fullpath\boost_1_75_0-msvc-14.2-32.exe"
Start-Process -Wait -FilePath "$fullpath\boost_1_75_0-msvc-14.2-32.exe" -ArgumentList '/VERYSILENT /SP- /DIR=""C:\boost_1_75_0' -passthru

#Download and Git
Write-Host "Download and installation Git..."
Invoke-WebRequest -Uri "https://github.com/git-for-windows/git/releases/download/v2.20.1.windows.1/Git-2.20.1-64-bit.exe" -OutFile "$fullpath\Git-2.20.1.exe"
Unblock-File -Path "$fullpath\Git-2.20.1.exe"
Start-Process -Wait -FilePath "$fullpath\Git-2.20.1.exe" -ArgumentLis '/VERYSILENT /SP-' -passthru


#Download and Java SE
Write-Host "Download and installation Java SE 8..."
Invoke-WebRequest -Uri "https://download.java.net/openjdk/jdk8u41/ri/openjdk-8u41-b04-windows-i586-14_jan_2020.zip" -OutFile "$fullpath\openjdk-8u41.zip"
Expand-Archive "$fullpath\openjdk-8u41.zip" -DestinationPath 'C:\Program Files\Java' -Force 

#Download and installation VS 2012
Invoke-WebRequest -Uri $url_vs -Headers $Headers -OutFile "$fullpath\VS2012_prof.7z"
Expand-7Zip -ArchiveFileName "$fullpath\VS2012_prof.7z" -TargetPath "$fullpath"
Start-Process -Wait -FilePath "$fullpath\VS2012_prof\vs_professional.exe" -ArgumentList '/Passive /Full' -passthru

#Download and installation VS 2012 update 5
Write-Host "Download and installation VS 2012 update 5..."
Invoke-WebRequest -Uri $url_vs_update -Headers $Headers -OutFile "$fullpath\VS2012_update5.7z"
Expand-7Zip -ArchiveFileName "$fullpath\VS2012_update5.7z" -TargetPath "$fullpath"
Start-Process -Wait -FilePath "$fullpath\VS2012_update5\VS2012.5.exe" -ArgumentList '/Passive /Full' -passthru

#Set Environment variables on Machine

$boost_root = 'BOOST_ROOT'
$boost_root_val = 'C:\boost_1_75_0'
[System.Environment]::SetEnvironmentVariable($boost_root,$boost_root_val,[System.EnvironmentVariableTarget]::Machine)


$boost_lib = 'BOOST_LIB32'
$boost_lib_val = 'lib32-msvc-14.2'
[System.Environment]::SetEnvironmentVariable($boost_lib,$boost_lib_val,[System.EnvironmentVariableTarget]::Machine)

$ca_gen = 'GEN85'
$ca_gen_val = 'C:\COOL85\'
[System.Environment]::SetEnvironmentVariable($ca_gen,$ca_gen_val,[System.EnvironmentVariableTarget]::Machine)


$gen_java = 'GEN85JRE'
$gen_java_val = 'C:\Program Files\Java\java-se-8u41-ri\jre\bin'
[System.Environment]::SetEnvironmentVariable($gen_java,$gen_java_val,[System.EnvironmentVariableTarget]::Machine)

$java = 'JAVA_HOME'
$java_val = 'C:\Program Files\Java\java-se-8u41-ri\jre\bin'
[System.Environment]::SetEnvironmentVariable($java,$java_val,[System.EnvironmentVariableTarget]::Machine)


$7z_path = ';C:\Program Files\7-Zip'
$gitbash_path = ';C:\Program Files\Git\mingw64\bin'
$java_path = ';C:\Program Files\Java\java-se-8u41-ri\jre\bin'
$ca_gen_path =  ';C:\COOL85\Gen;C:\COOL85\Gen\VS110'

[Environment]::SetEnvironmentVariable(
    "Path",
    [Environment]::GetEnvironmentVariable("Path", [EnvironmentVariableTarget]::Machine) + $7z_path + $gitbash_path + $java_path + $ca_gen_path,
    [EnvironmentVariableTarget]::Machine)