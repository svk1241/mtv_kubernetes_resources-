ansible-playbook servers_configuration.yml --extra-vars "ansible_user=$1 ansible_password=$2 mtv_password=$3" # pragma: allowlist secret
