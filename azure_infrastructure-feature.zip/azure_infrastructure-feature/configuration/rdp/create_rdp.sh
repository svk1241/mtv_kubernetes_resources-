#!/bin/bash

RDP_IP=$1
USER=$2
PASS=$3 # pragma: allowlist secret



echo $RDP_IP
export DISPLAY=99
sudo Xvfb :99 -screen 0 1920x1080x24 -extension RANDR &
e=`ps ax | grep xfreerdp | grep $RDP_IP | awk '{print $1}' | xargs`; echo $e; sudo kill -9 $e
sudo xvfb-run /usr/bin/xfreerdp /u:$USER /p:$PASS /v:$RDP_IP /f /cert:ignore &
sleep 3

HWND=`xvfb-run xdotool search --name "$RDP_IP"`
echo $HWND


xvfb-run xdotool key --window "$HWND" Return
if [ $RDP_IP = "notVMmachine.ddmtv.private" -o $RDP_IP = "notVMmachine.ddmtv.private" ]
then
	xvfb-run xdotool key --window "$HWND" Return
	xvfb-run xdotool key --window "$HWND" Up
	xvfb-run xdotool key --window "$HWND" W
	xvfb-run xdotool type --window "$HWND" 'password'
	xvfb-run xdotool key --window "$HWND" Return
fi

exit 0
