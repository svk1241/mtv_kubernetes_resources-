This chart is copy of https://github.com/pmint93/helm-charts (since https://github.com/helm/charts/tree/master/stable/metabase is deprecated)

## Installing the Chart:
Update password in urrent-config.yaml:47
```
helm upgrade --install metabase -n metabase --create-namespace -f current-config.yaml ./charts/metabase/
kubectl apply -f ./metabase-routing.yaml
```


# Original README:
# Helm charts

[![Artifact HUB](https://img.shields.io/endpoint?url=https://artifacthub.io/badge/repository/pmint93)](https://artifacthub.io/packages/search?repo=pmint93)

## Add Helm repository

```
helm repo add pmint93 https://pmint93.github.io/helm-charts
helm repo update
```

You can then run `helm search repo pmint93` to see available charts.

## Charts

See [artifact hub](https://artifacthub.io/packages/search?repo=pmint93) for a complete list.

## Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md)

## License

[Apache 2.0 License](./LICENSE)
