# Steps for full build (build tools, P44(P10) code and P44DD code):

## 0. Prerequisites
* Create folder and clone git repo:
```sh
    mkdir /opt/bknd
    cd /opt/bknd

    git clone -b development https://luxproject.luxoft.com/stash/scm/ddmtv/mtv_linux_backend_build_tools.git
    git clone -b development https://luxproject.luxoft.com/stash/scm/ddmtv/mtv_linux_backend_p10.git
```
* Copy CA Gen modified files from for_CAGen86 folder (CA Gen folder: /opt/CA/CAGen/runtime):
	* this step will also copy files needed for libae_userexits_c.so lib build.
```sh
	cd /opt/bknd/mtv_linux_backend_build_tools/mtv-tools/for_CAGen86
    cp -r !(readme.md) /opt/CA/CAGen/runtime/
```
* Build libae_userexits_c.so lib to enable messages encryption:
	* this step will build lib and place it to the /opt/CA/CAGen/runtime/lib folder
```sh
	cd /opt/CA/CAGen/runtime/src
    make
```
* Check or change lib path before start build:
```sh
	cd /usr/lib/oracle (Check oracle version. Example 19.3)
    Change in /opt/bknd/mtv_linux_backend_build_tools/mtv-tools/linux/env.sh (ORA_INCL, ORA_LIBS)      
```
## 1. Prepare build tools
* Check and load env vars:
    * var BLD_THREADS sets number of threads used for build
```sh
    cd /opt/bknd/mtv_linux_backend_build_tools/mtv-tools/linux
 
    . ./env.sh
```
* build and copy build tools:
```sh
    cd ../develop
    for d in *; do cd $d; make; cp $d $BLD_SCRIPT_DIR/; cd ..; done
    cd BatchManager && cp UnixBatch.a ../../linux/ && cd ..
```

## 2. Main build:
* Go to the sources folder, create _tmp_ folder and start build:
```sh
    cd /opt/bknd/mtv_linux_backend_p10/m210p10 && mkdir tmp && cd ./tmp
    nohup $BLD_SCRIPT_DIR/make_all /opt/bknd/mtv_linux_backend_p10/m210p10 >&0mkLog &
```

## 3. Build DD code (only after main build):
* Similar to main build, go to the DD sources folder, create _tmp_ folder and start build:
```sh
    cd /opt/bknd/mtv_linux_backend_p10/m210p10DD && mkdir tmp && cd ./tmp
    nohup $BLD_SCRIPT_DIR/make_all_dd /opt/bknd/mtv_linux_backend_p10/m210p10DD >&0mkLog &
```

## 4. Update MTV installation:
* Online:
```sh
    cp /opt/bknd/mtv_linux_backend_p10/m210p10/srvr/inqload/* /opt/MTV/m210/online/inqload
    cp /opt/bknd/mtv_linux_backend_p10/m210p10DD/comp/srvr/inqload/* /opt/MTV/m210/online/inqload
```
* Batch:
```sh
   cp /opt/bknd/mtv_linux_backend_p10/m210p10/bin/* /opt/MTV/m210/bin
   # Batch update, need to copy some modules from build tools folder
   cp $BLD_SCRIPT_DIR/MVPP* /opt/MTV/m210/bin
```
* DD Libs:
```sh
   cp /opt/bknd/mtv_linux_backend_p10/m210p10/lib/* /opt/MTV/m210/lib
   cp /opt/bknd/mtv_linux_backend_p10/m210p10DD/lib/*.so /opt/MTV/m210/lib
```




# Rebuild (for mtv_linux_backend_p10 repo)

## Steps:

* Unstage uncommitted local changes 
```sh
   git restore .
```
* Clean unstaged local changes
```sh
   git clean -fd .
```


# Build the certain modules

* If changed source file includes in lib then cleaning should be done before run script below.
* Open and change $BLD_SCRIPT_DIR/make_all (At least one batch module must be builded)
```sh
    ${BLD_SCRIPT_DIR}/mass-icmbld /opt/bknd/mtv_linux_backend_p10/m210p10 type IEFAE 'module_name_1 module_name_2 ....'

    type := online | batch
    'module_name_N' := *.icm
```
