#define _GNU_SOURCE

#include <dlfcn.h>
#include <sys/socket.h>
#include <netinet/tcp.h>
#include <netinet/in.h>

int socket(int domain, int type, int protocol) {
    typedef int (*socket_t)(int, int, int);

    socket_t original_socket = (socket_t) dlsym(RTLD_NEXT, "socket");

    int sockfd = original_socket(domain, type, protocol);

    if (sockfd != -1 && type == SOCK_STREAM) {
        int flag = 1;
        if (setsockopt(sockfd, IPPROTO_TCP, TCP_NODELAY, (char *) &flag, sizeof(flag)) == -1) {
            return -1;
        }
    }

    return sockfd;
}

