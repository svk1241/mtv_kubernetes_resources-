# Preload library for forced TCP_NODELAY

## Purpose

### Problem

CA Gen TE solution (aefad & aefuf) uses localhost TCP sockets to communicate
to each other and to transaction binaries.

These sockets don't enable `TCP_NODELAY` mechanism and therefore scenarios with
a lot of small transactions experience significant delays (40-80 ms) purely in TCP networking.

### Solution

For the moment of creating this library no way of enabling `TCP_NODELAY` by vendor-provided means is known,
so this library is created for this exact purpose.

It uses `LD_PRELOAD`-mechanism for overriding `socket` standard library call with the following logic:
1. Forward call to real `socket`
2. If call is successful and socket is `SOCK_STREAM`, then enable `TCP_NODELAY` for it with `setsockopt` call.

## Prerequisites

1. make
2. GCC (version, supported by target OS)

## Build

```shell
make all
```

This will produce *preload_tcp_nodelay.so* shared library, which is ready for further use.

## Usage

```shell
LD_PRELOAD=/path/to/preload_tcp_nodelay.so aefad [ARGS...]
LD_PRELOAD=/path/to/preload_tcp_nodelay.so aefuf [ARGS...]
```
