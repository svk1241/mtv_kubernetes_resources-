/****************************************************************************
   CA Gen
   Copyright (C) 2016 CA. All rights reserved.

       Title: Cooperative Runtime Communications
              Encryption User Exit Sample Code

   Purpose:  This user exit will receive a pointer to a data area consisting
             of the application export view data to be sent on the dialog  
             flow.  This user exit can encrypt the import view data into an
             export encyrption data area. 

   Inputs:   Runtime_parm1         (unsigned char *)
             Runtime_parm2         (unsigned char *)
             TIRNCRYP_cmcb   		 (structure *)

				pDataBuffer			ptr to Decrypted Input Area
				lBufferSize			size of Decrypted Input Area
				lEncryptMaxSize		max size Encrypted Area can be
				trancode				from Server Manager
				client userod			from Server Manager via client
				pNextLocation			not used -- set to null 

	Outputs:	pDataBuffer will be reused as the Encrypted data area.
				lBufferSize will indicate the size of the Encrypted Area
				If encryption is successful, set return_code to ENCRYPTION_USED.
				If the return_code is set to ENCRYPTION_APPLICATION_ERROR, the
				application msg of choice may be moved to failure_msg for
				presentation to the client.

                             Change History
  -----+----------+----------------------------------------------------------
   Who !   When   !             Description
  -----+----------+----------------------------------------------------------
       !          !                  
  -----+----------+----------------------------------------------------------
****************************************************************************/

#include <string.h>

typedef struct
	{
	unsigned char * pDataBuffer;
	long    lBufferSize;
	long	 lEncryptMaxSize;
	char    trancode[8];
	char	 client_userid[64];
	unsigned char * pNextLocation;
	char    return_code[2];
   char    failure_msg[80];
	} TIRNCRYP_cmcb;		      

#define ENCRYPTION_USED					"  "
#define ENCRYPTION_SIZE_EXCEEDED_MAX	"01"
#define ENCRYPTION_NOT_USED			    "02"
#define ENCRYPTION_APPLICATION_ERROR	"03"

#include "target.h"
#include "mtvbf.h"

void TIRNCRYP(runtime_parm1, runtime_parm2, 
              pTIRNCRYP_cmcb)

unsigned char    * runtime_parm1;
unsigned char    * runtime_parm2;
TIRNCRYP_cmcb	 * pTIRNCRYP_cmcb;

{
    if( IsEncryptOff() )
    {
        memcpy( pTIRNCRYP_cmcb->return_code, ENCRYPTION_NOT_USED, 2 );
        return;
    }

    int iRet = 0;

    iRet = MTVBFCGE( pTIRNCRYP_cmcb->pDataBuffer,
                     &pTIRNCRYP_cmcb->lBufferSize,
                     pTIRNCRYP_cmcb->lEncryptMaxSize );

    if ( 0 != iRet )
    {
        memcpy( pTIRNCRYP_cmcb->return_code, ENCRYPTION_APPLICATION_ERROR, 2 );
        strcpy( pTIRNCRYP_cmcb->failure_msg, "Failed to encrypt message." );
    }
    else
    {
        memcpy( pTIRNCRYP_cmcb->return_code, ENCRYPTION_USED, 2 );
        strcpy( pTIRNCRYP_cmcb->failure_msg, "" );
    }
}
