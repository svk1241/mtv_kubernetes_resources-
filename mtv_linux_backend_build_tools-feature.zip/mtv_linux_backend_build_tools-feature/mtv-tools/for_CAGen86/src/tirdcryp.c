/****************************************************************************
   CA Gen
   Copyright (C) 2016 CA. All rights reserved. 

   Title: Runtime Cooperative Communications
          Decryption User Exit Sample Code

   Purpose:  This user exit will receive a pointer to a data area consisting
             of the application import view data to be received on via dialog
             flow.  This user exit can decrypt the import view data into an
             export decyrption data area. 

   Inputs:   Runtime_parm1         (unsigned char *)
             Runtime_parm2         (unsigned char *)
             TIRDCRYP_cmcb   		 (structure *)

				pDataBuffer pts to Encrypted Input Area
				lBufferSize is size of Encrypted Area (bytes)
				lDecryptMaxSize is max size that the Decrypted Area can be
					after decryption

	Outputs:  The ptr to DataBuffer will be reused for the Decrypted Data area.
				lBufferSize needs to be set	to the size of the 
             decrypted data area.  If the return_code
				is set to DECRYPTION_APPLICATION_ERROR then the failure_msg
				may be populated with an application msg of choice to be
				presented to the client.  If decryption is successful please
				indicate by setting the return_code to DECRYPTION_USED.


                             Change History
  -----+----------+----------------------------------------------------------
   Who !   When   !             Description
  -----+----------+----------------------------------------------------------
       !          !                  
  -----+----------+----------------------------------------------------------
****************************************************************************/

#include <string.h>

typedef struct
	{
	unsigned char * pDataBuffer;
	long    lBufferSize;
	long 	 lDecryptMaxSize;
	char    return_code[2];
   char    failure_msg[80];
	} TIRDCRYP_cmcb;		      

#define DECRYPTION_USED					"  "
#define DECRYPTION_SIZE_EXCEEDED_MAX	"01"
#define DECRYPTION_NOT_USED			"02"
#define DECRYPTION_APPLICATION_ERROR	"03"

#include "target.h"
#include "mtvbf.h"

void TIRDCRYP( 
unsigned char    * runtime_parm1,
unsigned char    * runtime_parm2,
TIRDCRYP_cmcb	 * pTIRDCRYP_cmcb)

{
    if( IsEncryptOff() )
    {
        memcpy( pTIRDCRYP_cmcb->return_code, DECRYPTION_NOT_USED, 2 );
        return;
    }

    int iRet = 0;
    
    iRet = MTVBFCGD( pTIRDCRYP_cmcb->pDataBuffer,
                     pTIRDCRYP_cmcb->lBufferSize );

    if ( 0 != iRet )
    {
        memcpy( pTIRDCRYP_cmcb->return_code, DECRYPTION_APPLICATION_ERROR, 2 );
        strcpy( pTIRDCRYP_cmcb->failure_msg, "Failed to decrypt message." );
    }
    else
    {
        memcpy( pTIRDCRYP_cmcb->return_code, DECRYPTION_USED, 2 );
        strcpy( pTIRDCRYP_cmcb->failure_msg, "" );
    }
}

