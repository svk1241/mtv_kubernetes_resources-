/**********************************************************/
/*  CA Gen                                                */
/*  Copyright (c) 2016 CA. All rights reserved.           */
/**********************************************************/

/*************************************************************************
 *  Change Modification History:
 *
 *  RAL  | 06/10/05 |            Add new Decimal Precision Library
 *  MML  | 08/11/05 | remove definition of OPTDBG
 *  RAJA | 08/23/07 | 16097719   Modified LIBS due to TIRTRACE changes(sockets, pthreads)
 *  RAL  | 04/30/08 | 17082467   Add DBMSINC for Oracle to support oci.h
 *  mml  01/22/09  r8.0 64bits  Remove PROTO and K&R declarations    
 *  RAL  | 04/06/09 | 18109634  Use lib32 for db2 if present
 *  RAL  | 07/22/10 | 19398870  Add LNKFLAG and LNKFLAG_END
 *  RAL  | 10/03/11 | 20551327  Introdude LDFLAGS_AR_START and LDFLAGS_AR_END
 *       |          |           to resolve symbols between archive libraries
 *  RAL  | 01/10/12 | 20726198  Add GEN_BITS variables for 64bit
 *  RAL  | 03/22/12 | r8.5      Preface DBMS and COMM_TYPE macros with IEF_
 *  RAL  | 09/20/12 | r8.5       Added maxopencursors to PCFLAGS; removed
 *       |          |            from make files
 *  RAL  | 02/27/13 | 21303510  Add TUXEDO_DBMS for No DBMS
 *  RAL  | 01/25/13 | 21274157  Use GEN_BITS_32 macro set in build scripts
 *  RAL  | 02/13/13 | 21331392  Use -m31 for zLinux builds
 *  RAL  | 02/07/14 | ORACLE12  Add include dir for DBMSINC
 *************************************************************************/

/********************* Beginning of IEF_LINUX Section ***********************/

#ifdef GEN_BITS_32   /* 32 bit builds */
#ifdef IEF_ZLINUX
GEN_BITS_ENV = 31
#else
GEN_BITS_ENV = 32
#endif
#else                /* 64 bit builds */
GEN_BITS_ENV = 64
#endif

CBD_C_LINK = g++ -shared -m$(GEN_BITS_ENV)
RI_C_LINK  = g++ -shared -m$(GEN_BITS_ENV)
MAPFLAG  =  -M
MAPSTART = {
MAPEND = };
SHLSFX = .so
LNKFLAG = `cat
LNKFLAG_END = `


STD_INCL   = -I./ $(COMMON_HEAD_INC) $(SRC_INCL) -I/usr/include

#if defined(IEF_PROLOGUE)
#define  IEF_GENERATED_APPLICATION  1
#endif  /*IEF_PROLOGUE*/

SOCKLIB   =
TERMCAP   = -lncurses
RANLIB    = echo
OB        = o
COB       =
COBFLAGS  =
COBHOME   =
SQLHOME   =
CC        = cc
/*CC2       = gcc  -ansi */
CC2       = gcc
CXX       = g++
LDFLAGS   = -m$(GEN_BITS_ENV)
LDFLAGS_AR_START = -Wl,--start-group
LDFLAGS_AR_END   = -Wl,--end-group
AR        = ar
ARFLAGS   = r

#ifdef IEF_ORACLE
INAME= iname=
ONAME= oname=
IUSER=
ORAFLAGS =
DBMSINC  = -I$(ORACLE_HOME)/rdbms/public -I$(ORACLE_HOME)/precomp/public
IFLAGS= MAXLITERAL=512
PCC        = $(ORACLE_HOME)/bin/proc
PCCOB      =
PCCFLAGS   = include=$(PCCINC) ireclen=255 oreclen=255 \
             mode=ansi dbms=V7 \
             sqlcheck=syntax ltype=none
PCCINC     = $(ORACLE_HOME)/sqllib/public
PCFLAGS    = define=_XOPEN_SOURCE \
	     include=$(PCINC) ireclen=511 oreclen=511 \
             mode=ansi dbms=V7 \
             sqlcheck=syntax ltype=none parse=none maxopencursors=10
PCINC       = $(ORACLE_HOME)/precomp/public
ORACLE_INCLUDE = $(ORACLE_HOME)/precomp/public

#ifdef IEF_ORACLE32   /* ORACLE 32BIT */
ORALIBSLOC = lib32
ORAVER = 12
#else
ORALIBSLOC = lib      /* ORACLE 64BIT */
ORAVER = 12
#endif

//LIBS=   -L$(ORACLE_HOME)/$(ORALIBSLOC) \

LIBS=   -L$(ORA_LIBS) \
        -lclntsh \
        -lm -lc -ldl -lpthread -lnsl -Wl,--export-dynamic
COBLIBS=
#endif /* ORACLE */

#ifdef IEF_NODBMS
TUXEDO_DBMS =
LIBS=-lm -lc -lpthread -lnsl
#endif

#ifdef IEF_DB2
INAME    =
IUSER    =
IFLAGS   =
PCC      = $(DB2DIR)/bin/db2 prep
COBLIBS  =
DB2FLAGS =
DBMSINC  = -I$(DB2DIR)/include

#ifdef IEF_DB232
DB2LIBSLOC = lib32
#else
DB2LIBSLOC = lib64
#endif

LIBS     = -L$(DB2DIR)/$(DB2LIBSLOC) -ldb2 -lpthread -lnsl $(CXXLIB)
#endif /* DB2 */

#if defined(IEF_GENERATED_APPLICATION)
MBLIBS   = $(C_IEF)/libmbg.a $(C_IEF)/libmbx.a
GXLIB    = $(C_IEF)/libgxlate.a
CCLD      = $(CC)
IDLFLAGS = -n
CIGEN    = $(IEFH)/lib
CIREMUSE = $(CIGEN)/ciremuse.a
CIREQTOK = -L$(CIGEN) -lreqtok
CSULIBS  = -L$(CIGEN) -lcsu -lcsuvn
CFLAGS2  = -m$(GEN_BITS_ENV) -fPIC -D_XOPEN_SOURCE -D_XOPEN_SOURCE_EXTENDED=1 -D_XPG4 $(DAASYS) \
$(STD_INCL) $(DBMSINC) $(SNPLOG) $(OPTDBG) -DBM_RT

#ifdef IEF_TUX
CC = gcc
CFLAGS         =
VIEWC32  = viewc32
TUXINC   = -I$(TUXDIR)/include
COMLIBS  = -L$(CIGEN) -ltxsx
CIREMOBJ = $(CIGEN)/ciremuse.a -L$(CIGEN) -lreqtok

#ifdef IEF_ORACLE
TUXEDO_DBMS = -r Oracle_XA
LIBS=$(SOCKLIB) -lpthread
#endif

CFLAGS2 = -m$(GEN_BITS_ENV) -fPIC $(DAASYS) $(STD_INCL) \
-D_XOPEN_SOURCE_EXTENDED=1 -D_XOPEN_SOURCE \
$(DBMSINC) $(TUXINC) $(SNPLOG) $(OPTDBG) -DBM_RT
CFLAGS = -m$(GEN_BITS_ENV) -fPIC $(DAASYS) $(STD_INCL) \
-D_XOPEN_SOURCE_EXTENDED=1 -D_XOPEN_SOURCE \
$(DBMSINC) $(SNPLOG) $(OPTDBG) -DBM_RT
#else

CFLAGS2 = -m$(GEN_BITS_ENV) -fPIC $(DAASYS) $(STD_INCL) \
-D_XOPEN_SOURCE_EXTENDED=1 -D_XOPEN_SOURCE \
$(DBMSINC) $(SNPLOG) $(OPTDBG) -DBM_RT
CFLAGS = -m$(GEN_BITS_ENV) -fPIC $(DAASYS) $(STD_INCL) \
-D_XOPEN_SOURCE_EXTENDED=1 -D_XOPEN_SOURCE \
$(DBMSINC) $(SNPLOG) $(OPTDBG) -DBM_RT
#endif
#endif


#if !defined(IEF_GENERATED_APPLICATION)

CCLD      = $(CC)
CFLAGS    = -m$(GEN_BITS_ENV) -fPIC $(DAASYS) -D_XOPEN_SOURCE_EXTENDED=1 -D_XOPEN_SOURCE \
-DIEF_POSIX $(STD_INCL) $(DBMSINC) $(SNPLOG) $(OPTDBG) -DBM_RT
CFLAGS2   = -m$(GEN_BITS_ENV) -fPIC $(DAASYS) -D_XOPEN_SOURCE_EXTENDED=1 -D_XOPEN_SOURCE \
-DIEF_POSIX $(STD_INCL) $(DBMSINC) $(SNPLOG) $(OPTDBG) -DBM_RT
CXXFLAGS  = -m$(GEN_BITS_ENV) -fPIC $(DAASYS) -D_XOPEN_SOURCE_EXTENDED=1 -D_XOPEN_SOURCE \
-DIEF_POSIX $(STD_INCL) $(DBMSINC) $(SNPLOG) $(OPTDBG) -c \
-DRW_BYTES_PER_WORD=4 -DRW_BYTES_PER_PTR=4 -DBM_RT
LOC_CXXFLAGS = $(CXXFLAGS)
#endif

/********************* End of IEF_LINUX Section ***********************/
