copy this files to the CA Gen runtime folder: /opt/CA86/CAGen/runtime

#steps for build /opt/CA86/CAGen/lib/libae_userexits_c.so:

cp src/* /opt/CA86/CAGen/runtime/src
cp include/* /opt/CA86/CAGen/runtime/include

cd /opt/CA/CAGen/runtime/src
make #will build libae_userexits_c.so in /opt/CA86/CAGen/lib/