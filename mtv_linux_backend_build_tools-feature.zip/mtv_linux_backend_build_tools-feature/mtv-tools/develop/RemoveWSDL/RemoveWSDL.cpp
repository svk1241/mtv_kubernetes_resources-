
#if defined(_MSC_VER)
#define TARGET_WIN32
#endif

#if defined(TARGET_WIN32)
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <io.h>
#else
#include <libgen.h>
#include <utime.h>
#define _fileno		fileno
#define	fwprintf_s	fwprintf
#define sprintf_s	snprintf
#define	_strnicmp	strncasecmp
#define _countof(x)	(sizeof(x)/sizeof(x[0]))
#define BOOL int
#define TRUE 1
#define FALSE 0
#endif

#include <ctype.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h> 
#include <sys/stat.h> 
#include <wchar.h>
#include <errno.h>

#ifdef _DEBUG
#define STATIC
#else
#define STATIC static
#endif

/* Process return codes */
#define  PROCESS_OKAY   0      /* Process completed successfully */
#define  PROCESS_OKAY_REPLACE_FILE 4 /* OK but filetime must be updated */
#define  PROCESS_ERROR  8      /* Process error--could not execute */


STATIC   wchar_t	szSyntax[] = L"Syntax error: %s source\n\n" \
L"   Where <source> is a CA Gen Server Manager source file.\n\n" \
L"   Return codes:\n" \
L"         %d\tindicates successful completion\n" \
L"         %d\tgeneral processing error\n\n";

STATIC   wchar_t	szNoMem[]  = L"Cannot allocate memory: %s\n";
STATIC   wchar_t	szPgm[32];

static  int mainline( void );

static  bool ReplaceString( char** ppszTarget, size_t nTargetLen, const char* pszValue, size_t nValueLen );

static	bool InsertString( char** ppszTarget, const char* pszValue, size_t nValueLen );

static	bool RemoveString( char** ppszTarget, size_t nTargetLen );

static const wchar_t* GetErrorString(int error);

//GLOBALS

static	char* g_buffer = NULL;
static	size_t g_dwBufSize = 0;
static	size_t g_dwDataSize = 0; //datasize <= bufsize

#if defined(TARGET_WIN32)
int __cdecl wmain(int argc, WCHAR* argv[])
#else
int   main( int argc, char* argv[] )
#endif
{
	int   rc = PROCESS_ERROR;

#if defined(TARGET_WIN32)
	_wsplitpath_s(argv[0], NULL, 0, NULL, 0, szPgm, _countof(szPgm), NULL, 0);
#else
	char*	pszBaseName = basename(argv[0]);
	mbtowc(szPgm, pszBaseName, _countof(szPgm));
#endif

	if ( argc <= 1 )     
	{
		fwprintf_s( stdout, szSyntax, szPgm, PROCESS_OKAY, PROCESS_ERROR );
		return( rc );
	}

	rc = PROCESS_OKAY;
	for ( int i = 1; i < argc && PROCESS_OKAY == rc; ++i ) 
	{
		FILE*	fin = NULL;
#if defined(TARGET_WIN32)
		_wfopen_s(&fin, argv[i], L"rt");

		// If we do modify the source module we'll want to set
		// the times back to the way we found them.
		BOOL		haveFileTime = FALSE;
		FILETIME	ft[3];
		if (NULL != fin)
		{
			haveFileTime = GetFileTime((HANDLE)_get_osfhandle(_fileno(fin)), &ft[0], &ft[1], &ft[2]);
		}
#else
		fin = fopen(argv[i], "r");

        // If we do modify the source module we'll want to set
        // the times back to the way we found them.
        //TLB
        BOOL            haveFileTime = FALSE;
        struct stat stat_buff;
        struct utimbuf time_buff;
        if (NULL != fin)
        {
            if(stat(argv[i],&stat_buff) == 0)
            {
               haveFileTime = TRUE;
            }
        }
#endif
		if (NULL == fin)
		{
			fwprintf_s(stdout, L"%s: Cannot open '%s': (%d) %s\n",
				szPgm,
				argv[i],
				errno,
				GetErrorString(errno));
			return PROCESS_ERROR;
		}

		//get the file size
		struct stat	statBuf;
		if (0 != fstat(_fileno(fin), &statBuf))
		{
			fwprintf_s( stdout, L"%s: Cannot get file size for '%s': (%d) %s\n",
					szPgm,
					argv[i],
					errno,
					GetErrorString(errno));
			fclose(fin);
			return PROCESS_ERROR;
		}
		g_dwDataSize = statBuf.st_size;

		//we'll need a buffer bigger than the file
		g_dwBufSize = g_dwDataSize + 1024;

		//allocate the buffer
		g_buffer = (char*) malloc( g_dwBufSize );

		if ( NULL == g_buffer )
		{
			fwprintf_s( stdout, L"%s: Cannot allocate buffer for '%s'\n",
					szPgm,
					argv[i] );
			fclose(fin);
			return PROCESS_ERROR;
		}

		// In WIN32 the file is opened as "rt" meaning the \r\n pairs will be
		// translated into a single \n.  The number of bytes read will be less
		// than the total size of the file due to the translation.  Count on
		// the stream's error flag to be set if there is a read error.
		size_t	read = fread(g_buffer, 1, g_dwDataSize, fin);
		if ( ferror(fin) )
		{
			fwprintf_s( stdout, L"%s: Could not read '%s': (%d) %s\n",
					szPgm,
					argv[i],
					errno,
					GetErrorString(errno));
			fclose(fin);
			return PROCESS_ERROR;
		}
		fclose(fin);
		fin = NULL;

		// Use the number of bytes read as the initial data size; in
		// WIN32 the \r\n will be collapsed into \n making the byte count
		// of the buffer less than the byte count on disk;
		g_dwDataSize = read;

		//zero remaining portion of buffer
		memset( g_buffer + g_dwDataSize, 0L, g_dwBufSize - g_dwDataSize );

		fwprintf_s(stdout, L"\n%s...", argv[i]);

		// In UNIX carriage returns may not be stripped.  Remove them
		// now but do not consider it to be a change causing a file
		// write.
		for (size_t j = 0; j < g_dwDataSize; ++j)
		{
			if ('\r' == g_buffer[j])
			{
				char* p = &g_buffer[j];
				RemoveString(&p, 1);
				--j;
			}
		}

		rc = mainline();
		
		fwprintf_s(stdout, L"\n", argv[i]);

	    if ( rc == PROCESS_OKAY_REPLACE_FILE )
		{
			FILE*	fout = NULL;
#if defined(TARGET_WIN32)
			_wfopen_s(&fout, argv[i], L"wt");
#else
			fout = fopen(argv[i], "w");
#endif
			if (NULL == fout)
			{
				fwprintf_s(stdout, L"%s: Cannot reopen '%s': (%d) %s\n",
					szPgm,
					argv[i],
					errno,
					GetErrorString(errno));
				return PROCESS_ERROR;
			}

			// No buffering needed
			setvbuf(fout, NULL, _IONBF, 0);

			//write the buffer into the file
			fwrite(g_buffer, 1, g_dwDataSize, fout ); 
			if ( ferror(fout) )
			{
				fwprintf_s(stdout, L"%s: Could not write entire buffer into file? '%s': (%d) %s\n",
						szPgm,
						argv[i],
						errno,
						GetErrorString(errno));
			   
			   fclose( fout );
			   return PROCESS_ERROR;
			}

#if defined(TARGET_WIN32)
			// Reset time file times back to what we started with . . .
			if (haveFileTime)
			{
				SetFileTime((HANDLE)_get_osfhandle(_fileno(fout)), &ft[0], &ft[1], &ft[2]);
			}
#else
            if (haveFileTime)
            {
                 time_buff.actime=stat_buff.st_atime ;
                 time_buff.modtime=stat_buff.st_mtime ;
                 utime(argv[i],&time_buff);
            }
#endif

			fclose(fout);
			fout = NULL;
			rc = PROCESS_OKAY;
		}

		free( g_buffer );
		g_buffer = NULL;
	}

	return( rc );
}

static   int   mainline( void )
{
/*########################################################
** Variable declarations
*#######################################################*/
	int      rc = PROCESS_ERROR;
	char*    pszTarget;  //pointer to the location of the string that needs replacing
	char*    pszTarget2; //extra pointer

/*########################################################
** Literals and replacments
*#######################################################*/

	STATIC char		szWSDL[]     = "WSDL Definitions";
	//STATIC size_t   nLenWSDL     = strlen( szWSDL );
	STATIC char     szIfNDef[]   = "#ifndef EXCLUDE_WSDL    /*INSERTED BY RemoveWSDL.EXE*/\n";//needs double newline
	STATIC size_t   nLenIfNDef   = strlen( szIfNDef );
	STATIC char     szEndIf[]    = "#endif    /*INSERTED BY RemoveWSDL.EXE*/\n";
	STATIC size_t   nLenEndif    = strlen( szEndIf );
	STATIC char		szStartOf[]  = "START OF";
	//STATIC size_t   nLenStartOf  = strlen( szStartOf );
	STATIC char     szComma[]    = "_WSDL,";
	//STATIC size_t   nLenComma    = strlen( szComma );
	STATIC char     szTIRCFG[]   = "  TIRCFG(";//leading spaces to differentiate declaration from call
	//STATIC size_t   nLenTIRCFG   = strlen( szTIRCFG );
	STATIC char     szFor[]      = "for(i=0;";
	STATIC size_t   nLenFor      = strlen( szFor );
		

/*########################################################
** Helper macros
*#######################################################*/

#define THE_END g_buffer + g_dwDataSize
#define GOTO_BLOCK_END while ('}' != *pszTarget && pszTarget < THE_END) { ++pszTarget; } \
		if (pszTarget < THE_END) ++pszTarget
#define GOTO_NEXT_BLOCK while ('{' != *pszTarget && pszTarget < THE_END) { ++pszTarget; } \
		if (pszTarget < THE_END) ++pszTarget
#define GOTO_NEXT_LINE while ('\n' != *pszTarget && pszTarget < THE_END) { ++pszTarget; } \
	if (pszTarget < THE_END) ++pszTarget
#define GOTO_NEXT_STMT while (';' != *pszTarget && pszTarget < THE_END) { ++pszTarget; } \
	if (pszTarget < THE_END) ++pszTarget
#define SKIP_SPACES while (isspace(*pszTarget) && pszTarget < THE_END) ++pszTarget

/*########################################################
** Function code
*#######################################################*/

	rc = PROCESS_OKAY;

	pszTarget = strstr( g_buffer, szIfNDef );
	if ( NULL != pszTarget )
	{
		//we've already been here
		return PROCESS_OKAY;
	}

	pszTarget = strstr( g_buffer, szWSDL );
	if ( NULL != pszTarget )
	{
		while (0 != strncmp(pszTarget, "\n\n", 2))
		{
			pszTarget++;
			if ( pszTarget == THE_END )
			{
				printf( "Did not find \"[newline][newline]\" after \"WSDL Definitions\"?\n");
				return PROCESS_ERROR;
			}
		}
		pszTarget += 2; 
		
//pointing at blank line after "WSDL Definitions"; insert #ifndef
		InsertString( &pszTarget, szIfNDef, nLenIfNDef );

		//find subsequent "START OF"
		pszTarget = strstr( pszTarget, szStartOf );
		if ( NULL != pszTarget )
		{
			//retreat to blank line after actual WSDL
			while ( 0 != strncmp(--pszTarget, "\n\n", 2) );
			
			//pointing at blank line before START OF, or worst case, blank line after newly-inserted "#if not defined"
			InsertString( &pszTarget, szEndIf, nLenEndif );
		}
		else
		{
			printf( "Did not find \"START OF\" after \"WSDL Definitions\"?\n");
			return PROCESS_ERROR;
		}

		//check if there's a strcpy/strcat block for multiple WSDL strings, see for example HMPMS00C.c
		pszTarget2 = strstr( pszTarget, szComma );
		if ( NULL == pszTarget2 )
		{
			//no strcpy/strcat block, must just be the TIRCFG call, so insert #ifndef before that instead.
			//search from g_buffer, because pszTarget was just set to NULL
			pszTarget2 = strstr(pszTarget, szTIRCFG);
			if ( NULL == pszTarget2 )
			{
				printf("Did not find str*** block for multiple WSDL's, nor TIRCFG() for just one?\n");
				return PROCESS_ERROR;
			}			
		}

		pszTarget = pszTarget2;

		//may be inside a new FOR loop, see for example HVRMS03C.c.  Find semicolon and square bracket; if bracket comes first, we're there.
		{
			char* pszSemi = strchr(pszTarget, ';');
			char* pszSquare = strchr(pszTarget, '[');
			if (    NULL != pszSquare
				 && pszSemi > pszSquare )
			{
				//next semicolon comes after next square bracket; back up to FOR
				while (pszTarget > g_buffer && 0 != strncmp( pszTarget, szFor, nLenFor ) ) pszTarget--;
				if ( pszTarget == g_buffer )
				{
					printf("Looking for \"for\" loop, retreated all the way to beginning of buffer?\n");
					return PROCESS_ERROR;
				}
			}
		}

		//sitting on "_WSDL," in str*** block, or on "  TIRCFG(", or on FOR.  Retreat to just after CRLF
		while (*pszTarget != '\n') pszTarget--;
		pszTarget++;

		InsertString(&pszTarget, szIfNDef, nLenIfNDef );

		//advance to TIRCFG()
		pszTarget = strstr(pszTarget, szTIRCFG);
		if ( NULL == pszTarget )
		{
			printf("Did not find TIRCFG()?\n");
			return PROCESS_ERROR;
		}
		else
		{
			//advance to *last* TIRCFG
			while (NULL != (pszTarget2 = strstr( (pszTarget+1), szTIRCFG ) ) )
			{
				pszTarget = pszTarget2;
			}
		}

		//advance to double CRLF
		while (0 != strncmp(pszTarget, "\n\n", 2))
		{
			pszTarget++;
			if ( pszTarget == THE_END )
			{
				printf( "Did not find \"[newline][newline]\" after \"TIRCFG()\"?\n");
				return PROCESS_ERROR;
			}
		}
		pszTarget++;

		InsertString( &pszTarget, szEndIf, nLenEndif );

		rc = PROCESS_OKAY_REPLACE_FILE;
	}		

	return( rc );

#undef GOTO_BLOCK_END
#undef GOTO_NEXT_BLOCK
#undef GOTO_NEXT_LINE
#undef GOTO_NEXT_STMT
#undef SKIP_SPACES
}

bool InsertString( char** ppszTarget, const char* pszValue, size_t nValueLen )

{
	//InsertString is a synonym for replacing a string of length zero at a 
	//known position.

	bool rc = ReplaceString( ppszTarget, 0, pszValue, nValueLen );

	return( rc );
}
bool RemoveString( char** ppszTarget, size_t nTargetLen )
{
	//RemoveString is a synonym for replacing a string of a known length at a 
	//known position with a new string of length zero.
	bool rc = ReplaceString( ppszTarget, nTargetLen, "", 0 );

	return (rc);
}

bool ReplaceString( char** ppszTarget, size_t nTargetLen, const char* pszValue, size_t nValueLen )
{

	//ppszTarget = pointer to the string to be replaced.  Note this is a
	//              pointer-to-a-pointer, because if the buffer needs to be
	//				reallocated, ppszTarget needs to move with it, to point to 
	//				the same relative location in the newly-reallocated buffer
	//nTargetLen = length of string to be replaced
	//pszValue = new string to be inserted at *ppszTarget
	//nValueLen = length of new string

	//if nTargetLen = 0, new string will be inserted at *ppszTarget.

	//if nValueLen = 0, "nTargetLen" characters will be removed at **ppszTarget 

#if defined(TARGET_WIN32)
	OutputDebugStringA( pszValue );OutputDebugString( L"\n" );
#endif

	bool bReverse = false;

	size_t nShift = nValueLen - nTargetLen;

	size_t dwAdjustedDataSize = g_dwDataSize + nShift;
	
	if ( ((int)nShift) < 0 ) 
	{
		nShift = ~nShift;
		bReverse = true;
	}
	else
	{
		//forward shift.  Is buffer large enough for longer string? 
		if ( g_dwBufSize < dwAdjustedDataSize )
		{
			//first remember old buffer and "target" pointer in it
			char* ptempBuf = g_buffer;
			char* ptempTarget = *ppszTarget;

			//expand buffer size
			g_dwBufSize += 1024;

			//get new, larger buffer
			g_buffer = (char*)malloc( g_dwBufSize );
			if ( NULL == g_buffer) 
			{
				//whoops
				printf("ERROR: cannot expand buffer from %d to %d\n", g_dwBufSize - 1024, g_dwBufSize);
				exit(PROCESS_ERROR);
				//return( false );
			}
			//copy the old buffer to the new
			memcpy( g_buffer, ptempBuf, g_dwDataSize );//original un-adjusted data size
			//zero the remaining segment of the new buffer
			memset( g_buffer + g_dwDataSize, 0L, g_dwBufSize - g_dwDataSize );
			
			//calculate new "target" pointer, based on offset of old one
			*ppszTarget = g_buffer + (ptempTarget - ptempBuf);

			//free the old buffer
			free( ptempBuf );
			ptempBuf = NULL;
		}
	}

	//get a pointer to beyond the Target
	char* pszAfter = *ppszTarget + nTargetLen; 

	//and a pointer to where pszAfter has to move, forward or back
	char* pszDest = *ppszTarget + nValueLen; //where pszAfter must move

	//now move pszAfter to where it has to go, making room for new string
	memmove( pszDest, pszAfter, ((g_buffer + g_dwDataSize) - pszAfter) );
	
	//and put the new string in place
	//strncpy( *ppszTarget, pszValue, nValueLen );
	memcpy( *ppszTarget, pszValue, nValueLen );

	if ( bReverse )
	{
		//pulled string backwards;  clean up leftover characters left beyond 
		//"new" end of string

		//from destination pointer, add length of string to jump to end;
		//from there, back off the number of characters shifted;
		//from there, set characters to NULL, for the number of characters shifted.
		memset( (g_buffer + g_dwDataSize ) - nShift, 0L, nShift );
	}

	//finally, remember the length of the result
	g_dwDataSize = dwAdjustedDataSize;

	return( true );

}

static const wchar_t* GetErrorString(int error)
{
	static	wchar_t	szMessage[128];
	szMessage[0] = L'\0';

#if defined (TARGET_WIN32)
	_wcserror_s(szMessage, _countof(szMessage), error);
#else
	char*	pszError = strerror(error);
	if (NULL != pszError) mbtowc(szMessage, pszError, _countof(szMessage));
#endif

	return szMessage;
}
