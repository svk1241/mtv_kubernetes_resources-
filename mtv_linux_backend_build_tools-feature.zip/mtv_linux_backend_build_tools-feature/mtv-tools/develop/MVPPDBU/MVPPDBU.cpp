// STL
#include <algorithm>
#include <cctype>
#include <exception>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <sstream>
#include <strstream>
#include <vector> //previously included indirectly via "#include <occi.h>"
// Oracle
#ifdef  _MSC_VER
#define WIN32COMMON
#endif
#include <oci.h>

// Module data
static std::string	m_strUID;
static std::string	m_strPWD;
static std::string	m_strORCL;
static std::istream* m_strmStatements;
static std::ifstream g_fileStatements;
static std::istrstream* g_strmCommandLine = NULL;
static std::string	g_currentStatement;
static std::string g_strKeyword;
static std::string g_strTable;
static std::string g_strPartition;

class CSyntaxException
{
public:
	CSyntaxException() {}
	CSyntaxException( const CSyntaxException& ) {}
	CSyntaxException& operator =( const CSyntaxException& ) { return *this; }

	virtual ~CSyntaxException() {}
};

#define ThrowSyntaxException() \
	throw CSyntaxException()

class CAppException
{
public:
	CAppException() {}
	CAppException( const CAppException& ) {}
	CAppException& operator =( const CAppException& ) { return *this; }

	virtual ~CAppException() {}
};

#define ThrowAppException() \
	throw CAppException()

class Constraint
{
public:
	Constraint() {}
	Constraint(const Constraint& rhs) { operator =(rhs); }
	Constraint& operator =(const Constraint& rhs)
	{
		if (&rhs != this)
		{
			strOwner = rhs.strOwner;
			strTableName = rhs.strTableName;
			strConstraintName = rhs.strConstraintName;
		}
		return *this;
	}
	virtual ~Constraint() {}

	std::string strOwner;
	std::string strTableName;
	std::string strConstraintName;
};

//Common Oracle objects shared among routines
class CommonOra
{
public:
    CommonOra() {}
    CommonOra(const CommonOra& rhs) { operator = (rhs); }
    CommonOra& operator =(const CommonOra& rhs)
    {
        if (&rhs != this)
        {
            res = rhs.res;
            hEnv = rhs.hEnv;
            hSvc = rhs.hSvc;
            hStmt = rhs.hStmt;
            hErr = rhs.hErr;
        }
        return *this;
    }
    virtual ~CommonOra() {}

    sword res;
    OCIEnv* hEnv;
    OCISvcCtx* hSvc;
    OCIStmt* hStmt;
    OCIError* hErr;
};

// Forward references
static void DropPartition(CommonOra* pCO, const std::string& tableName, const std::string& partition);
static void EnableDisableConstraints(CommonOra* pCO, const std::string& tableName, bool enable);
static void GrantOrRevoke(CommonOra* pCO,
						  const std::string& tableName,
						  bool isGrant);
static void ParseOptions(int argc, char* argv[]);
static void ParseStatement(void);
static std::string SchemaOwner(CommonOra* pCO, const std::string& tableName );
static std::string TriggerSchemaOwner(CommonOra* pCO, const std::string& triggerName );
static void TruncateTable(CommonOra* pCO, std::string& tableName);
static void ReferentialIntegrityConstraints(CommonOra* pCO,
	const std::string& tableName,
    std::vector <Constraint>& constraints/*,
	bool includePrimary = false*/); //see comments in function
static void EnableDisableTrigger(CommonOra* pCO, const std::string& triggerName, bool enable);
static void SetDDLLockTimeout(CommonOra* pCO, const std::string& strValue );

//---------------------------------------------------------------------
//
// Module code
//
//---------------------------------------------------------------------
#ifdef  _MSC_VER
#define STRICMP	_stricmp
int __cdecl main( int argc, char* argv[] )
#else
#include <strings.h>
#include <string.h>
#define STRICMP	strcasecmp
int main( int argc, char* argv[] )
#endif
{
	int iRet = 0;

    CommonOra CO;
    CO.res = 0;

	try
	{
		ParseOptions(argc, argv);

        CO.res = OCIEnvCreate( &CO.hEnv, OCI_OBJECT, (void*)0, 0, 0, 0, (size_t)0, (dvoid**)0);

        if ( OCI_SUCCESS == CO.res )
        {
            CO.res = OCIHandleAlloc( CO.hEnv, (void**)&CO.hErr, OCI_HTYPE_ERROR, 0, NULL );
            CO.res = OCIHandleAlloc( CO.hEnv, (void**)&CO.hSvc, OCI_HTYPE_SVCCTX, 0, NULL );
            CO.res = OCIHandleAlloc( CO.hEnv, (void**)&CO.hStmt, OCI_HTYPE_STMT, 0, NULL);
            CO.res = OCILogon( CO.hEnv, CO.hErr, &CO.hSvc, (const OraText*)m_strUID.data(), (ub4)m_strUID.length(), (const OraText*)m_strPWD.data(), (ub4)m_strPWD.length(), (const OraText*)m_strORCL.data(), (ub4)m_strORCL.length());
        }
        if ( OCI_SUCCESS != CO.res )
        {
            ThrowAppException();
        }

		ParseStatement();

		while (0 != g_strKeyword.length())
		{
			if (0 == STRICMP(g_strKeyword.c_str(), "constraint_disable"))
			{
				EnableDisableConstraints(&CO, g_strTable, false);
			}
			else if (0 == STRICMP(g_strKeyword.c_str(), "constraint_enable"))
			{
				EnableDisableConstraints(&CO, g_strTable, true);
			}
			else if (0 == STRICMP(g_strKeyword.c_str(), "partition_drop"))
			{
				DropPartition(&CO, g_strTable, g_strPartition);
			}
			else if (0 == STRICMP(g_strKeyword.c_str(), "truncate"))
			{
				TruncateTable(&CO, g_strTable);
			}
			else if (0 == STRICMP(g_strKeyword.c_str(), "grant_update"))
			{
				GrantOrRevoke(&CO, g_strTable, true);
			}
			else if (0 == STRICMP(g_strKeyword.c_str(), "revoke_update"))
			{
				GrantOrRevoke(&CO, g_strTable, false);
			}
			else if (0 == STRICMP(g_strKeyword.c_str(), "trigger_enable"))
			{
				//g_strTable = the trigger name...not the table name
				EnableDisableTrigger(&CO, g_strTable, true);
			}
			else if (0 == STRICMP(g_strKeyword.c_str(), "trigger_disable"))
			{
				//g_strTable = the trigger name...not the table name
				EnableDisableTrigger(&CO, g_strTable, false);
			}
			else if (0 == STRICMP(g_strKeyword.c_str(), "ddl_lock_timeout"))
			{
                //g_strTable = the timeout value...not the table name
				SetDDLLockTimeout(&CO, g_strTable);
			}
			else
			{
				std::cout << "MVPPDBU: unknown operation requested: "
					<< g_strKeyword
					<< std::endl
					;
				ThrowAppException();
			}
			g_strKeyword.clear();
			ParseStatement();
		}
	}
	catch (CAppException& )
	{
		iRet = 1;
        if ( OCI_SUCCESS != CO.res )
        {
            iRet = 3;
            sb4 sb4Err = 0;
            std::string errMsg = "Unknown exception";
            char szErr[256];
            ub4 res = OCIErrorGet( CO.hErr, 1, NULL, &sb4Err, (text*)szErr, (ub4)sizeof(szErr), OCI_HTYPE_ERROR );
            if ( OCI_SUCCESS == res )
            {   
                errMsg = szErr;
            }
            std::cout << "Oracle Exception:" <<std::endl;
            std::cout << "Error code: " << CO.res << std::endl;
            std::cout << errMsg << std::endl;
            std::cout << g_currentStatement << std::endl;
        }

		std::cout << "MVPPDBU execution terminated" << std::endl;
		std::cout.flush();
	}
	catch (CSyntaxException& )
	{
		iRet = 2;
		std::cout << "Syntax error" << std::endl
			<< "Syntax: MVPPDBU <connectString> [statement | @responseFile | -]" << std::endl
			<< "where:" << std::endl
			<< "\tconnectString Oracle credentials and service.  e.g. scott/tiger@orcl" << std::endl
			<< "\tstatement     statement to execute" << std::endl
			<< "\t@responseFile file containing statements to execute" << std::endl
			<< "\t-             read statements from stdin" << std::endl
			<< std::endl
			<< "Common actions:" << std::endl
			<< "\tconstraint_disable <table>  disable RI constraints" << std::endl
			<< "\tconstraint_enable <table>   enable RI constraints" << std::endl
			<< "\tgrant_update <table>        grant update for table" << std::endl
			<< "\tpartition_drop <partition>  drop named parition" << std::endl
			<< "\trevoke_update <table>       revoke update on table" << std::endl
			<< "\ttruncate <table>            truncate table" << std::endl
			<< "\tddl_lock_timeout <value>    set DDL lock timeout" << std::endl
			<< std::endl
			<< "MVPPDBU execution terminated" << std::endl;
		std::cout.flush();
	}
	catch ( std::bad_alloc& /*e*/ )
	{
		iRet = 4;
		std::cout << "Not enough memory to complete operation." << std::endl
			<< "MVPPDBU execution terminated" << std::endl;
		std::cout.flush();
	}
	catch ( ... )
	{
		iRet = 5;
		std::cout << "Unknown exception:" << std::endl
			<< "Error code: " << errno << std::endl
				  << g_currentStatement << std::endl
				  << "MVPPDBU execution terminated" << std::endl;
		std::cout.flush();
	 }

    //could OCILogoff(CO.hSvc, CO.hErr) and OCITerminate(OCI_DEFAULT) here, but that
    //would amount to sweeping the factory floor while tearing down the building.

	if (g_fileStatements.is_open()) g_fileStatements.close();
	if (NULL != g_strmCommandLine) delete g_strmCommandLine;

	return iRet;
}

static void DropPartition(CommonOra* pCO, const std::string& tableName, const std::string& partition)
{

    // 2010-10-08 SJP: Skip this
	//EnableDisableConstraints(pCO, tableName/*, false*/);

    //Research SQL (might need to use "all_tables" etc and specify owner):
    //select table_name from user_tables where partitioned = 'YES'
    //select * from user_objects where object_name = '<table_name from 1st query>' and object_type = 'TABLE PARTITION'              
    //--then partition_drop <table_name from 1st query> <subobject_name from 2nd query>
	
	std::ostrstream sbStatement;
	sbStatement << "alter table " << SchemaOwner(pCO, tableName) << "." << tableName 
			<< " drop partition "
			<< partition
			<< " update indexes"
			<< std::ends
			;

	g_currentStatement = sbStatement.str();
    pCO->res = OCIStmtPrepare( pCO->hStmt, pCO->hErr, (text*)g_currentStatement.data(), (ub4)g_currentStatement.length(), OCI_NTV_SYNTAX, OCI_DEFAULT);
    if (OCI_SUCCESS == pCO->res) 
    {
        //nonzero iterations (4th parameter) for non-SELECT statement
        pCO->res = OCIStmtExecute( pCO->hSvc, pCO->hStmt, pCO->hErr, 1, 0, NULL, NULL, OCI_DEFAULT );
    }
    if (OCI_SUCCESS != pCO->res) ThrowAppException();


	// 2010-10-08 SJP: Skip this and it should have been EnableDisableConstraints(pConn, tableName/*, true*/);
	//EnableDisableConstraints(pCO, tableName/*, false*/);

}

static void EnableDisableConstraints(CommonOra* pCO, const std::string& tableName, bool enable)
{

    //Research SQL
    //select b.owner, a.table_name, b.table_name, b.constraint_name, b.status
    //from all_constraints a, all_constraints b
    //where a.constraint_name = b.r_constraint_name
    //and b.constraint_type = 'R'
    //and a.owner = 'CVTSTDBU'
    //and b.owner = 'CVTSTDBU'
    //order by 2
    //--then constraint_[disable|enable] <a.table_name (column 2) from query>

	// Find all the referential integrity constrainst for the given
	// table
	std::vector<Constraint> constraints;
	ReferentialIntegrityConstraints(pCO, tableName, constraints);

	// Deal with each constraint
	for (std::vector<Constraint>::const_iterator it = constraints.begin();
		it != constraints.end();
		++it)
	{
		// Enable/Disable the constraint
		std::ostrstream sbStatement;
		sbStatement << "alter table " << (*it).strOwner << "." << (*it).strTableName << " "
			<< ((enable) ? "enable" : "disable") << " constraint "
			<< (*it).strConstraintName
			<< std::ends
			;

		g_currentStatement = sbStatement.str();
        pCO->res = OCIStmtPrepare( pCO->hStmt, pCO->hErr, (text*)g_currentStatement.data(), (ub4)g_currentStatement.length(), OCI_NTV_SYNTAX, OCI_DEFAULT);
        if (OCI_SUCCESS == pCO->res) 
        {
            //nonzero iterations (4th parameter) for non-SELECT statement
            pCO->res = OCIStmtExecute( pCO->hSvc, pCO->hStmt, pCO->hErr, 1, 0, NULL, NULL, OCI_DEFAULT );
        }
        if (OCI_SUCCESS != pCO->res) ThrowAppException();
    }
}

static void GrantOrRevoke(CommonOra* pCO,
						  const std::string& tableName,
						  bool isGrant)
{

    //FYI, this grants/revokes update for role "<owner>_FULL_ACCESS".  You can create 
    //that role if necessary ("create role <owner>_FULL_ACCESS").
    //Research SQL:  
    //select * from role_tab_privs where role = '<owner>_FULL_ACCESS'"
    //--then [grant_update|revoke_update] <any table> and select again to confirm

	std::string schemaOwner = SchemaOwner(pCO, tableName);

	std::ostrstream	sbStmt;
	sbStmt << ((isGrant) ? "grant" : "revoke")
		<< " update on "
		<< schemaOwner << '.' << tableName << ' '
		<< ((isGrant) ? "to" : "from") << ' '
		<< schemaOwner << "_FULL_ACCESS"
		<< std::ends
		;

	g_currentStatement = sbStmt.str();

    pCO->res = OCIStmtPrepare( pCO->hStmt, pCO->hErr, (text*)g_currentStatement.data(), (ub4)g_currentStatement.length(), OCI_NTV_SYNTAX, OCI_DEFAULT);
    if (OCI_SUCCESS == pCO->res) 
    {   
        //nonzero iterations (4th parameter) for non-SELECT statement
        pCO->res = OCIStmtExecute( pCO->hSvc, pCO->hStmt, pCO->hErr, 1, 0, NULL, NULL, OCI_DEFAULT );
    }
    if (OCI_SUCCESS != pCO->res) ThrowAppException();
}

static void EnableDisableTrigger(CommonOra* pCO, const std::string& triggerName, bool enable)
{
	std::string schemaOwner = TriggerSchemaOwner(pCO, triggerName );

    //Research SQL:
    //select trigger_name, table_owner, table_name, status from all_triggers where owner='<owner>'
    //then [trigger_disable|trigger_enable] <trigger_name from query> and select again (with trigger name) to confirm

	// Enable/Disable the trigger
	std::ostrstream	sbStmt;
	sbStmt << "alter trigger " 
		<< schemaOwner << '.' << triggerName
		<< ((enable) ? " enable" : " disable")
		<< std::ends
		;

	g_currentStatement = sbStmt.str();

    pCO->res = OCIStmtPrepare( pCO->hStmt, pCO->hErr, (text*)g_currentStatement.data(), (ub4)g_currentStatement.length(), OCI_NTV_SYNTAX, OCI_DEFAULT);
    if (OCI_SUCCESS == pCO->res) 
    {
        //nonzero iterations (4th parameter) for non-SELECT statement
        pCO->res = OCIStmtExecute( pCO->hSvc, pCO->hStmt, pCO->hErr, 1, 0, NULL, NULL, OCI_DEFAULT );
    }
    if (OCI_SUCCESS != pCO->res) ThrowAppException();
}

static void SetDDLLockTimeout( CommonOra* pCO, const std::string& strValue )
{
	// Set the ddl_lock_timeout
	std::ostrstream	sbStmt;
	sbStmt << "alter session set ddl_lock_timeout = " << strValue
		<< std::ends
		;

	g_currentStatement = sbStmt.str();

    pCO->res = OCIStmtPrepare( pCO->hStmt, pCO->hErr, (text*)g_currentStatement.data(), (ub4)g_currentStatement.length(), OCI_NTV_SYNTAX, OCI_DEFAULT);
    if (OCI_SUCCESS == pCO->res) 
    {
        //nonzero iterations (4th parameter) for non-SELECT statement
        pCO->res = OCIStmtExecute( pCO->hSvc, pCO->hStmt, pCO->hErr, 1, 0, NULL, NULL, OCI_DEFAULT );
    }
    if (OCI_SUCCESS != pCO->res) ThrowAppException();
}
static void ParseStatement(void)
{
	g_strKeyword.clear();
	g_strTable.clear();
	g_strPartition.clear();

	std::ostringstream bufKeyword;
	std::ostringstream bufTable;

	// Skip leading whitespace
	std::ws(*m_strmStatements);

	std::istream::int_type	ch = m_strmStatements->get();
	while (EOF != ch)
	{
		// Skip to end-of-line when "--" comment indicator encountered
		if ('-' == ch && '-' == m_strmStatements->peek())
		{
			m_strmStatements->get();
			ch = m_strmStatements->get();
			while (!(EOF == ch || '\n' == ch))
			{
				ch = m_strmStatements->get();
			}

			// Skip whitespace after the comment
			std::ws(*m_strmStatements);

			ch = m_strmStatements->get();
			continue;
		}
		else
		{
			// First term
			m_strmStatements->putback(static_cast<char>(ch));
			*m_strmStatements >> g_strKeyword;

			// Whitespace between first & second term
			std::ws(*m_strmStatements);

			// Second term
			*m_strmStatements >> g_strTable;

			// Is there a third term?
			ch = m_strmStatements->get();
			while (!(EOF == ch || '\n' == ch))
			{
				if (!std::isspace(ch))
				{
					// Third term
					m_strmStatements->putback(static_cast<char>(ch));
					*m_strmStatements >> g_strPartition;
					break;
				}
				ch = m_strmStatements->get();
			}
			break;
		}
	}
}

static void ParseOptions(int argc, char* argv[])
{
	bool fError = true;

	for (int i = 1; i < argc; ++i)
	{
		switch (i)
		{
			// First argument is Oracle connect string
		case 1:
			{
				std::ostringstream bufUID;
				std::ostringstream bufPWD;
				std::ostringstream bufORCL;

				const char* psz = argv[i];
				std::ostringstream* p = &bufUID;

				while ( *psz )
				{
					if ( '/' == *psz )
					{
						p = &bufPWD;
					}
					else if ( '@' == *psz )
					{
						p = &bufORCL;
					}
					else
					{
						(*p) << *psz;
					}
					psz++;
				}

				m_strUID = bufUID.str();
				m_strPWD = bufPWD.str();
				m_strORCL = bufORCL.str();
				break;
			}
			// Second argument is statement source
		case 2:
			{
				if ('-' == argv[i][0])
				{
					// Get statements from stdin
					m_strmStatements = &std::cin;
					fError = false;
				}
				else if ('@' == argv[i][0])
				{
					// Get statements from a text file
					g_fileStatements.open(&argv[i][1]);
					if (!g_fileStatements.is_open())
					{
						std::cout << "Cannot open: " << &argv[i][1] << std::endl;
					}
					else
					{
						m_strmStatements = &g_fileStatements;
						fError = false;
					}
				}
				else
				{
					// Get statement from command line
					g_strmCommandLine = new std::istrstream(argv[i]);
					m_strmStatements = g_strmCommandLine;
					fError = false;
				}
				break;
			}
		default:
			{
				fError = true;
				break;
			}
		}
	}
	if (fError) ThrowSyntaxException(); 
}

static std::string SchemaOwner(CommonOra* pCO, const std::string& tableName )
{
	std::string		owner;
	std::ostrstream	sb;
    OCIDefine* hDef = NULL;
    char szOwner[33];
    ub2 ub2Len;
    ub2 ub2ColRes;

    memset(szOwner, 0, sizeof(szOwner));

	sb << "select distinct(table_owner) from all_synonyms where "
		//<< "owner = UPPER('" << m_strUID << "') and table_name = 'METAVANCE_ADDRESS'"
		<< "owner = UPPER('" << m_strUID << "') and table_name = '" << tableName << "'"
		<< std::ends;

	g_currentStatement = sb.str();

    pCO->res = OCIStmtPrepare( pCO->hStmt, pCO->hErr, (text*)g_currentStatement.data(), (ub4)g_currentStatement.length(), OCI_NTV_SYNTAX, OCI_DEFAULT);
    if (OCI_SUCCESS == pCO->res) 
    {
        pCO->res = OCIStmtExecute( pCO->hSvc, pCO->hStmt, pCO->hErr, 0, 0, NULL, NULL, OCI_DEFAULT );
    }
    if (OCI_SUCCESS == pCO->res) 
    {
        
        //successful execute doesn't necessarily mean we found any data
        pCO->res = OCIDefineByPos( pCO->hStmt, &hDef, pCO->hErr, 1, szOwner, sizeof(szOwner), SQLT_AFC, NULL, &ub2Len, &ub2ColRes, OCI_DEFAULT);
        if (OCI_SUCCESS != pCO->res) ThrowAppException();

        pCO->res = OCIStmtFetch2( pCO->hStmt, pCO->hErr, 1, OCI_FETCH_NEXT, 1, OCI_DEFAULT );
        if (OCI_SUCCESS == pCO->res ) 
        {
            owner = szOwner;
        }
        else if ( OCI_NO_DATA != pCO->res )
        {
            ThrowAppException();
        }
    }

	if (0 == owner.length())
	{
		std::ostrstream	sbAllTables;
		sbAllTables << "select distinct(owner) from all_tables where "
			//<< "table_name = 'METAVANCE_ADDRESS'"
			<< "table_name = '" << tableName << "'"
            << "and owner = UPPER('" << m_strUID << "')" //in case DB user has higher-than-expected rights
			<< std::ends;

		g_currentStatement = sbAllTables.str();
        pCO->res = OCIStmtPrepare( pCO->hStmt, pCO->hErr, (text*)g_currentStatement.data(), (ub4)g_currentStatement.length(), OCI_NTV_SYNTAX, OCI_DEFAULT);
        if (OCI_SUCCESS == pCO->res) 
        {
            pCO->res = OCIStmtExecute( pCO->hSvc, pCO->hStmt, pCO->hErr, 0, 0, NULL, NULL, OCI_DEFAULT );
        }
        if (OCI_SUCCESS == pCO->res) 
        {

            //successful execute doesn't necessarily mean we found any data
            pCO->res = OCIDefineByPos( pCO->hStmt, &hDef, pCO->hErr, 1, szOwner, sizeof(szOwner), SQLT_AFC, NULL, &ub2Len, &ub2ColRes, OCI_DEFAULT);
            if (OCI_SUCCESS != pCO->res) ThrowAppException();

            pCO->res = OCIStmtFetch2( pCO->hStmt, pCO->hErr, 1, OCI_FETCH_NEXT, 1, OCI_DEFAULT );
            if (OCI_SUCCESS == pCO->res) 
            {
                owner = szOwner;
            }
        }
	}

	if (0 == owner.length())
	{
		std::cout << "Cannot obtain schema owner name" << std::endl;
		ThrowAppException();
	}
	return owner;
}
static std::string TriggerSchemaOwner(CommonOra* pCO, const std::string& triggerName )
{
	std::string		owner;
	std::string		table_owner;
	std::string		table_name;
	std::ostrstream	sb;
    OCIDefine* hDef = NULL;
    OCIDefine* hDef2 = NULL;
    OCIDefine* hDef3 = NULL;
    char szOwner[33];
    char szTableName[33];
    char szTableOwner[33];
    ub2 ub2Len, ub2Len2, ub2Len3;
    ub2 ub2ColRes, ub2ColRes2, ub2ColRes3;

	std::ostrstream sbAllTriggers;
	sbAllTriggers << "select distinct(owner) from all_triggers where "
		<< "owner = UPPER('" << m_strUID << "') and trigger_name = '" << triggerName << "'"
		<< std::ends;

	g_currentStatement = sbAllTriggers.str();

    pCO->res = OCIStmtPrepare( pCO->hStmt, pCO->hErr, (text*)g_currentStatement.data(), (ub4)g_currentStatement.length(), OCI_NTV_SYNTAX, OCI_DEFAULT);
    if (OCI_SUCCESS == pCO->res) 
    {
        pCO->res = OCIStmtExecute( pCO->hSvc, pCO->hStmt, pCO->hErr, 0, 0, NULL, NULL, OCI_DEFAULT );
    }
    if (OCI_SUCCESS == pCO->res)
    {
        //successful execute doesn't necessarily mean we found any data

        memset(szOwner, 0, sizeof(szOwner));
        memset(szTableName, 0, sizeof(szTableName));
        memset(szTableOwner, 0, sizeof(szTableOwner));

        pCO->res = OCIDefineByPos( pCO->hStmt, &hDef, pCO->hErr, 1, szOwner, sizeof(szOwner), SQLT_AFC, NULL, &ub2Len, &ub2ColRes, OCI_DEFAULT );
        if (OCI_SUCCESS != pCO->res) ThrowAppException();

        pCO->res = OCIStmtFetch2( pCO->hStmt, pCO->hErr, 1, OCI_FETCH_NEXT, 1, OCI_DEFAULT );
        if (OCI_SUCCESS == pCO->res ) 
        {
            owner = szOwner;
        }
        else if ( OCI_NO_DATA != pCO->res )
        {
            ThrowAppException();
        }
    }
    
	if (0 == owner.length())
	{
		//get all triggers with this name, fetching owner, table, and table_owner; compare table_owner to SchemaOwner(table)
		std::ostrstream	sbAllTriggers;
		sbAllTriggers << "select distinct table_owner, table_name, owner from all_triggers where "
			<< "trigger_name = '" << triggerName << "'"
			<< std::ends;

		g_currentStatement = sbAllTriggers.str();
        pCO->res = OCIStmtPrepare( pCO->hStmt, pCO->hErr, (text*)g_currentStatement.data(), (ub4)g_currentStatement.length(), OCI_NTV_SYNTAX, OCI_DEFAULT);
        if (OCI_SUCCESS == pCO->res) 
        {
            pCO->res = OCIStmtExecute( pCO->hSvc, pCO->hStmt, pCO->hErr, 0, 0, NULL, NULL, OCI_DEFAULT );
        }
        if (OCI_SUCCESS == pCO->res)
        {

            pCO->res = OCIDefineByPos( pCO->hStmt, &hDef, pCO->hErr, 1, szTableOwner, sizeof(szTableOwner), SQLT_AFC, NULL, &ub2Len, &ub2ColRes, OCI_DEFAULT );
            if (OCI_SUCCESS != pCO->res) ThrowAppException();
            pCO->res = OCIDefineByPos( pCO->hStmt, &hDef2, pCO->hErr, 2, szTableName, sizeof(szTableName), SQLT_AFC, NULL, &ub2Len2, &ub2ColRes2, OCI_DEFAULT );
            if (OCI_SUCCESS != pCO->res) ThrowAppException();
            pCO->res = OCIDefineByPos( pCO->hStmt, &hDef3, pCO->hErr, 3, szOwner, sizeof(szOwner), SQLT_AFC, NULL, &ub2Len3, &ub2ColRes3, OCI_DEFAULT );
            if (OCI_SUCCESS != pCO->res) ThrowAppException();

            pCO->res = OCIStmtFetch2( pCO->hStmt, pCO->hErr, 1, OCI_FETCH_NEXT, 1, OCI_DEFAULT );
            if ( OCI_SUCCESS != pCO->res ) ThrowAppException();

            while ( OCI_NO_DATA != pCO->res )
		    {
                table_owner = szTableOwner;
                table_name = szTableName;

			    if ( 0 == table_owner.compare( SchemaOwner(pCO, table_name) ) )
			    {
                    owner = szOwner;
				    break;
			    }

                memset(szOwner, 0, sizeof(szOwner));
                memset(szTableName, 0, sizeof(szTableName));
                memset(szTableOwner, 0, sizeof(szTableOwner));

                pCO->res = OCIStmtFetch2( pCO->hStmt, pCO->hErr, 1, OCI_FETCH_NEXT, 1, OCI_DEFAULT );
                if ( OCI_SUCCESS != pCO->res && OCI_NO_DATA != pCO->res ) ThrowAppException();
		    }
        }
	}
	if (0 == owner.length())
	{
		std::cout << "Cannot obtain schema owner name" << std::endl;
		ThrowAppException();
	}
	return owner;
}

static void TruncateTable(CommonOra* pCO, std::string& tableName)
{
	std::string strOwner = SchemaOwner(pCO, tableName);

	// Obtain all the constraints for this table
	std::vector<Constraint> constraints;
	ReferentialIntegrityConstraints(pCO, tableName, constraints/*, true*/);

	for (std::vector<Constraint>::const_iterator it = constraints.begin();
		it != constraints.end();
		++it)
	{
		// Disable the constraint
		std::ostrstream sbStatement;
		sbStatement << "alter table " << (*it).strOwner << "." << (*it).strTableName << " "
			<< "disable constraint "
			<< (*it).strConstraintName
			<< std::ends
			;

		g_currentStatement = sbStatement.str();
        pCO->res = OCIStmtPrepare( pCO->hStmt, pCO->hErr, (text*)g_currentStatement.data(), (ub4)g_currentStatement.length(), OCI_NTV_SYNTAX, OCI_DEFAULT);
        if (OCI_SUCCESS == pCO->res) 
        {
            //nonzero iterations (4th parameter) for non-SELECT statement
            pCO->res = OCIStmtExecute( pCO->hSvc, pCO->hStmt, pCO->hErr, 1, 0, NULL, NULL, OCI_DEFAULT );
        }
        if (OCI_SUCCESS != pCO->res) ThrowAppException();
	}

	// Truncate the table
	{
		std::ostrstream sbStatement;
		sbStatement << "truncate table " << strOwner << "." << tableName
			<< std::ends
			;

		g_currentStatement = sbStatement.str();
        pCO->res = OCIStmtPrepare( pCO->hStmt, pCO->hErr, (text*)g_currentStatement.data(), (ub4)g_currentStatement.length(), OCI_NTV_SYNTAX, OCI_DEFAULT);
        if (OCI_SUCCESS == pCO->res) 
        {
            //nonzero iterations (4th parameter) for non-SELECT statement
            pCO->res = OCIStmtExecute( pCO->hSvc, pCO->hStmt, pCO->hErr, 1, 0, NULL, NULL, OCI_DEFAULT );
        }
        if (OCI_SUCCESS != pCO->res) ThrowAppException();
	}

	// Enable each constraint we disabled above
	for (std::vector<Constraint>::const_iterator it = constraints.begin();
		it != constraints.end();
		++it)
	{
		// Enable the constraint
		std::ostrstream sbStatement;
		sbStatement << "alter table " << (*it).strOwner << "." << (*it).strTableName << " "
			<< "enable constraint "
			<< (*it).strConstraintName
			<< std::ends
			;

		g_currentStatement = sbStatement.str();
        pCO->res = OCIStmtPrepare( pCO->hStmt, pCO->hErr, (text*)g_currentStatement.data(), (ub4)g_currentStatement.length(), OCI_NTV_SYNTAX, OCI_DEFAULT);
        if (OCI_SUCCESS == pCO->res) 
        {
            //nonzero iterations (4th parameter) for non-SELECT statement
            pCO->res = OCIStmtExecute( pCO->hSvc, pCO->hStmt, pCO->hErr, 1, 0, NULL, NULL, OCI_DEFAULT );
        }
        if (OCI_SUCCESS != pCO->res) ThrowAppException();
	}
}

static void ReferentialIntegrityConstraints(CommonOra* pCO,
	const std::string& tableName,
	std::vector<Constraint>& constraints/*,
	bool includePrimary*/)
{
	constraints.clear();

	std::string strOwner = SchemaOwner(pCO, tableName);
	std::ostrstream sb;

	// Find all the referential integrity constraints for the given
	// table
	//Note per D. Speca, b.constraint_type will always be "R",  
	//never "P", and by extension, "includePrimary" parm doesn't (can't) actually 
    //accomplish anything.  R_constraint_name is always blank when 
    //constraint_type='P', and r_constraint_name is matched to constraint_name, 
    //therefore r_constraint_name is never blank and therefore
    //constraint_type is never 'P'.
	sb << "select B.owner, B.table_name, B.constraint_name "
		<< "from all_constraints A, all_constraints B "
		<< "where A.constraint_name = B.r_constraint_name "
		//<< "  and " << (includePrimary
		//		? "(B.constraint_type = 'R' or B.constraint_type = 'P') "
		//		: "B.constraint_type = 'R' ")
        << "  and B.constraint_type = 'R' "
        << "  and A.owner = '" << strOwner << "' " //in case user has higher-than-expected authority
		<< "  and B.owner = '" << strOwner << "' "
		<< "  and A.table_name = upper('" << tableName << "')"
		<< std::ends
		;

	g_currentStatement = sb.str();

    pCO->res = OCIStmtPrepare( pCO->hStmt, pCO->hErr, (text*)g_currentStatement.data(), (ub4)g_currentStatement.length(), OCI_NTV_SYNTAX, OCI_DEFAULT);
    if (OCI_SUCCESS == pCO->res) 
    {
        pCO->res = OCIStmtExecute( pCO->hSvc, pCO->hStmt, pCO->hErr, 0, 0, NULL, NULL, OCI_DEFAULT );
    }
    if (OCI_SUCCESS != pCO->res) ThrowAppException();
    OCIDefine* hDef = NULL;
    OCIDefine* hDef2 = NULL;
    OCIDefine* hDef3 = NULL;
    char szOwner[33];
    char szTableName[33];
    char szConstraintName[33];
    ub2 ub2Len, ub2Len2, ub2Len3;
    ub2 ub2ColRes, ub2ColRes2, ub2ColRes3;

    memset(szOwner, 0, sizeof(szOwner));
    memset(szTableName, 0, sizeof(szTableName));
    memset(szConstraintName, 0, sizeof(szConstraintName));

    pCO->res = OCIDefineByPos( pCO->hStmt, &hDef, pCO->hErr, 1, szOwner, sizeof(szOwner), SQLT_AFC, NULL, &ub2Len, &ub2ColRes, OCI_DEFAULT );
    if (OCI_SUCCESS != pCO->res) ThrowAppException();
    pCO->res = OCIDefineByPos( pCO->hStmt, &hDef2, pCO->hErr, 2, szTableName, sizeof(szTableName), SQLT_AFC, NULL, &ub2Len2, &ub2ColRes2, OCI_DEFAULT );
    if (OCI_SUCCESS != pCO->res) ThrowAppException();
    pCO->res = OCIDefineByPos( pCO->hStmt, &hDef3, pCO->hErr, 3, szConstraintName, sizeof(szConstraintName), SQLT_AFC, NULL, &ub2Len3, &ub2ColRes3, OCI_DEFAULT );
    if (OCI_SUCCESS != pCO->res) ThrowAppException();

    pCO->res = OCIStmtFetch2( pCO->hStmt, pCO->hErr, 1, OCI_FETCH_NEXT, 1, OCI_DEFAULT );
    if (OCI_SUCCESS != pCO->res && OCI_NO_DATA != pCO->res) ThrowAppException();

	// Remember each constraint
    while ( OCI_NO_DATA != pCO->res )
	{
		Constraint	constraint;
        constraint.strOwner = szOwner;
        constraint.strTableName = szTableName;
        constraint.strConstraintName = szConstraintName;
		constraints.push_back(constraint);

        memset(szOwner, 0, sizeof(szOwner));
        memset(szTableName, 0, sizeof(szTableName));
        memset(szConstraintName, 0, sizeof(szConstraintName));

        pCO->res = OCIStmtFetch2( pCO->hStmt, pCO->hErr, 1, OCI_FETCH_NEXT, 1, OCI_DEFAULT );
        if ( OCI_SUCCESS != pCO->res && OCI_NO_DATA != pCO->res ) ThrowAppException();
	}
}

