
#if defined(_MSC_VER)
#define TARGET_WIN32
#endif

#if defined(TARGET_WIN32)
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <io.h>
#else
#include <libgen.h>
#ifdef TARGET_HPUX
#include <utime.h>
#endif
#define _fileno		fileno
#define	fwprintf_s	fwprintf
#define	_strnicmp	strncasecmp
#define _countof(x)	(sizeof(x)/sizeof(x[0]))
#endif

#include <ctype.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h> 
#include <sys/stat.h> 
#include <wchar.h>
#include <errno.h>

#ifdef _DEBUG
#define STATIC
#else
#define STATIC static
#endif

/* Process return codes */
#define  PROCESS_OKAY   0      /* Process completed successfully */
#define  PROCESS_OKAY_REPLACE_FILE 4 /* OK but filetime must be updated */
#define  PROCESS_ERROR  8      /* Process error--could not execute */


STATIC   wchar_t	szSyntax[] = L"Syntax error: %s source\n\n" \
L"   Where <source> is a source or RMT file mask (*.c, *.sqc, *.rmt)\n\n" \
L"   Return codes:\n" \
L"         %d\tindicates successful completion\n" \
L"         %d\tgeneral processing error\n\n";

STATIC   wchar_t	szNoMem[]  = L"Cannot allocate memory: %s\n";
STATIC   wchar_t	szPgm[32];

static  int mainline( bool *pbRmtFile );

static  bool ReplaceString( char** ppszTarget, size_t nTargetLen, const char* pszValue, size_t nValueLen );

static	bool InsertString( char** ppszTarget, const char* pszValue, size_t nValueLen );

static	bool RemoveString( char** ppszTarget, size_t nTargetLen );

static const wchar_t* GetErrorString(int error);

//GLOBALS

static	char* g_buffer = NULL;
static	size_t g_dwBufSize = 0;
static	size_t g_dwDataSize = 0; //datasize <= bufsize

#if defined(TARGET_WIN32)
int __cdecl wmain(int argc, WCHAR* argv[])
#else
int   main( int argc, char* argv[] )
#endif
{
	int   rc = PROCESS_ERROR;
	bool  bRmtFile = false;

#if defined(TARGET_WIN32)
	_wsplitpath_s(argv[0], NULL, 0, NULL, 0, szPgm, _countof(szPgm), NULL, 0);
#else
	char*	pszBaseName = basename(argv[0]);
	mbtowc(szPgm, pszBaseName, _countof(szPgm));
#endif

	if (1 == argc)
	{
		fwprintf_s(stdout, szSyntax, szPgm, PROCESS_OKAY, PROCESS_ERROR);
		return rc;
	}

	rc = PROCESS_OKAY;
	for ( int i = 1; i < argc && PROCESS_OKAY == rc; ++i ) 
	{
		FILE*	fin = NULL;
#if defined(TARGET_WIN32)

		_wfopen_s(&fin, argv[i], L"rt");

#else
		fin = fopen(argv[i], "r");
#endif
		if (NULL == fin)
		{
			fwprintf_s(stdout, L"%s: Cannot open '%s': (%d) %s\n",
				szPgm,
				argv[i],
				errno,
				GetErrorString(errno));
			return PROCESS_ERROR;
		}

		// If we modify a .RMT file module we'll want to set
		// the times back to the way we found them.  Get the 
		// file time as long as we still have the file open. 
		bool		haveFileTime = false;
#if defined(TARGET_WIN32)
		FILETIME	ft[3];
		if (NULL != fin)
		{
			haveFileTime = GetFileTime((HANDLE)_get_osfhandle(_fileno(fin)), &ft[0], &ft[1], &ft[2])
				? true : false;
		}
#elif defined(TARGET_HPUX)
		struct	utimbuf	ft;
#endif


		//get the file size
		struct stat	statBuf;
		if (0 != fstat(_fileno(fin), &statBuf))
		{
			fwprintf_s( stdout, L"%s: Cannot get file size for '%s': (%d) %s\n",
					szPgm,
					argv[i],
					errno,
					GetErrorString(errno));
			fclose(fin);
			return PROCESS_ERROR;
		}
#ifdef TARGET_HPUX
		// Save file modification time.  File create time is cannot be reset.
		ft.modtime = statBuf.st_mtime;
		haveFileTime = true;
#endif

		g_dwDataSize = statBuf.st_size;

		//we'll need a buffer bigger than the file
		g_dwBufSize = g_dwDataSize + 1024;

		//allocate the buffer
		g_buffer = (char*) malloc( g_dwBufSize );

		if ( NULL == g_buffer )
		{
			fwprintf_s( stdout, L"%s: Cannot allocate buffer for '%s'\n",
					szPgm,
					argv[i] );
			fclose(fin);
			return PROCESS_ERROR;
		}

		// In WIN32 the file is opened as "rt" meaning the \r\n pairs will be
		// translated into a single \n.  The number of bytes read will be less
		// than the total size of the file due to the translation.  Count on
		// the stream's error flag to be set if there is a read error.
		size_t	read = fread(g_buffer, 1, g_dwDataSize, fin);
		if ( ferror(fin) )
		{
			fwprintf_s( stdout, L"%s: Could not read '%s': (%d) %s\n",
					szPgm,
					argv[i],
					errno,
					GetErrorString(errno));
			fclose(fin);
			return PROCESS_ERROR;
		}
		fclose(fin);
		fin = NULL;

		// Use the number of bytes read as the initial data size; in
		// WIN32 the \r\n will be collapsed into \n making the byte count
		// of the buffer less than the byte count on disk;
		g_dwDataSize = read;

		//zero remaining portion of buffer
		memset( g_buffer + g_dwDataSize, 0L, g_dwBufSize - g_dwDataSize );

		fwprintf_s(stdout, L"%s...\n", argv[i]);

		bRmtFile = false;

		rc = mainline( &bRmtFile );

	    if ( rc == PROCESS_OKAY_REPLACE_FILE )
		{
			FILE*	fout = NULL;
#if defined(TARGET_WIN32)
			_wfopen_s(&fout, argv[i], L"wt");
#else
			fout = fopen(argv[i], "w");
#endif
			if (NULL == fout)
			{
				fwprintf_s(stdout, L"%s: Cannot reopen '%s': (%d) %s\n",
					szPgm,
					argv[i],
					errno,
					GetErrorString(errno));
				return PROCESS_ERROR;
			}

			//Performance - big fat buffer, allocated automatically, to help with writing line-by-line below
			setvbuf( fout, NULL, _IOFBF, g_dwBufSize);

			//performance - inserting 1,200 "#include "mtvd2dc1.h\n" into the buffer was very slow, as the
			//remainder of the potentially 145mb buffer had to be shifted repeatedly to the right. 
			//Expedient solution is to write the buffer to the file line-by-line, inserting those lines 
			//directly into the file as we go.  This being instead of writing the entire buffer at once.

			char* pszBuf = g_buffer;
			char* pszEOL = g_buffer - 1;

			STATIC char     szInclTiab[]    = "#include <tiabinc.h>\n";
			STATIC size_t   nLenInclTiab = strlen(szInclTiab);
			STATIC char     szInclMtvd2[]      = "#include \"mtvd2dc1.h\"\n";
			STATIC size_t   nLenInclMtvd2      = strlen( szInclMtvd2 );

			//pszBuf is current read pointer in buffer; set pszEOL to \n
			while ( NULL != (pszEOL = strchr(pszEOL+1, '\n' ) ) )
			{
				//write this line to the file
				fwrite(pszBuf, 1, pszEOL - pszBuf + 1, fout);
				//are these the droids we're looking for? 
				if (0 == _strnicmp(pszBuf, szInclTiab, nLenInclTiab ) )
				{
					//yes.  Is the next line our #include, already added somehow? 
					if ( 0 != _strnicmp( (pszEOL+1), szInclMtvd2, nLenInclMtvd2 ) )
					{
						//No.  Does this source (or source-withing-.RMT) contain a call to mtvd2dc1()? 
						char* pszFunc = strstr( pszEOL+1, "mtvd2dc1(" );
						if ( NULL != pszFunc )
						{
							//yes.  is there an :esplit?
							char* pszEsplit = strstr( pszEOL+1, ":esplit" );
							//if there is no :esplit, or the function comes before the esplit, write the #include
							if (    NULL == pszEsplit 
								 || pszFunc < pszEsplit )
							{
								//yahtzee!  Write our include
								fwrite( szInclMtvd2, 1, nLenInclMtvd2, fout );
							}
						}
					}
				}
				//set the read pointer just past what we've already written out to the file and go around again.
				pszBuf = pszEOL + 1;

			}
			if ( bRmtFile ) 
			{
				// Reset time file times back to what we started with . . .
				if (haveFileTime)
				{
#if defined( TARGET_WIN32 )
					SetFileTime((HANDLE)_get_osfhandle(_fileno(fout)), &ft[0], &ft[1], &ft[2]);
#elif defined( TARGET_HPUX )
					fclose(fout);
					fout = NULL;
					utime(argv[1], &ft);
#endif
				}
			}

			if (NULL != fout) fclose(fout);
			fout = NULL;
			rc = PROCESS_OKAY;
		}
		
		free( g_buffer );
		g_buffer = NULL;
	}
	return( rc );
}

static   int   mainline( bool* pbRmtFile )
{
	int      rc = PROCESS_ERROR;

	char*    pszTarget;  //pointer to the location of the string that needs replacing
	
	STATIC char		szTird2[] = "tird2dc1(";
	STATIC size_t   nLenTird2 = strlen( szTird2 );

	STATIC char     szMtvd2[] = "mtvd2dc1(";
	STATIC size_t   nLenMtvd2 = strlen( szMtvd2 );

	STATIC char     szEsplit[] = ":esplit";

#define THE_END g_buffer + g_dwDataSize

	rc = PROCESS_OKAY;
	
	//are we looking at a .RMT file?
	if ( NULL != strstr( g_buffer, szEsplit ) )
	{
		*pbRmtFile = true;
	}

	//performance - insert the #includes in the main program above.  Inserting them in a large buffer was just too slow.

	//now replace the function calls
	pszTarget = g_buffer - 1;
	while ( NULL != (pszTarget = strstr( pszTarget+1, szTird2 ) ) )
	{
		ReplaceString( &pszTarget, nLenTird2, szMtvd2, nLenMtvd2 );
		rc = PROCESS_OKAY_REPLACE_FILE;
	}


	return( rc );

}

bool InsertString( char** ppszTarget, const char* pszValue, size_t nValueLen )

{
	//InsertString is a synonym for replacing a string of length zero at a 
	//known position.

	bool rc = ReplaceString( ppszTarget, 0, pszValue, nValueLen );

	return( rc );
}
bool RemoveString( char** ppszTarget, size_t nTargetLen )
{
	//RemoveString is a synonym for replacing a string of a known length at a 
	//known position with a new string of length zero.
	bool rc = ReplaceString( ppszTarget, nTargetLen, "", 0 );

	return (rc);
}

bool ReplaceString( char** ppszTarget, size_t nTargetLen, const char* pszValue, size_t nValueLen )
{

	//ppszTarget = pointer to the string to be replaced.  Note this is a
	//              pointer-to-a-pointer, because if the buffer needs to be
	//				reallocated, ppszTarget needs to move with it, to point to 
	//				the same relative location in the newly-reallocated buffer
	//nTargetLen = length of string to be replaced
	//pszValue = new string to be inserted at *ppszTarget
	//nValueLen = length of new string

	//if nTargetLen = 0, new string will be inserted at *ppszTarget.

	//if nValueLen = 0, "nTargetLen" characters will be removed at **ppszTarget 

#if defined(TARGET_WIN32)
	//OutputDebugStringA( pszValue );OutputDebugString( L"\n" );
#endif

	bool bReverse = false;

	size_t nShift = nValueLen - nTargetLen;

	size_t dwAdjustedDataSize = g_dwDataSize + nShift;
	
	if ( ((int)nShift) < 0 ) 
	{
		nShift = ~nShift;
		bReverse = true;
	}
	else
	{
		//forward shift.  Is buffer large enough for longer string? 
		if ( g_dwBufSize < dwAdjustedDataSize )
		{
			//first remember old buffer and "target" pointer in it
			char* ptempBuf = g_buffer;
			char* ptempTarget = *ppszTarget;

			//expand buffer size
			g_dwBufSize += 1024;

			//get new, larger buffer
			g_buffer = (char*)malloc( g_dwBufSize );
			if ( NULL == g_buffer) 
			{
				//whoops
				return( false );
				
			}
			//copy the old buffer to the new
			memcpy( g_buffer, ptempBuf, g_dwDataSize );//original un-adjusted data size
			//zero the remaining segment of the new buffer
			memset( g_buffer + g_dwDataSize, 0L, g_dwBufSize - g_dwDataSize );
			
			//calculate new "target" pointer, based on offset of old one
			*ppszTarget = g_buffer + (ptempTarget - ptempBuf);

			//free the old buffer
			free( ptempBuf );
			ptempBuf = NULL;
		}
	}

	if ( nTargetLen != nValueLen )
	{
		//get a pointer to beyond the Target
		char* pszAfter = *ppszTarget + nTargetLen; 

		//and a pointer to where pszAfter has to move, forward or back
		char* pszDest = *ppszTarget + nValueLen; //where pszAfter must move

		//now move pszAfter to where it has to go, making room for new string
		memmove( pszDest, pszAfter, ((g_buffer + g_dwDataSize) - pszAfter) );
	}
	//and put the new string in place
	//strncpy( *ppszTarget, pszValue, nValueLen );
	memcpy( *ppszTarget, pszValue, nValueLen );

	if ( bReverse )
	{
		//pulled string backwards;  clean up leftover characters left beyond 
		//"new" end of string

		//from destination pointer, add length of string to jump to end;
		//from there, back off the number of characters shifted;
		//from there, set characters to NULL, for the number of characters shifted.
		memset( (g_buffer + g_dwDataSize ) - nShift, 0L, nShift );
	}

	//finally, remember the length of the result
	g_dwDataSize = dwAdjustedDataSize;

	return( true );

}

static const wchar_t* GetErrorString(int error)
{
	static	wchar_t	szMessage[128];
	szMessage[0] = L'\0';

#if defined (TARGET_WIN32)
	_wcserror_s(szMessage, _countof(szMessage), error);
#else
	char*	pszError = strerror(error);
	if (NULL != pszError) mbtowc(szMessage, pszError, _countof(szMessage));
#endif

	return szMessage;
}
