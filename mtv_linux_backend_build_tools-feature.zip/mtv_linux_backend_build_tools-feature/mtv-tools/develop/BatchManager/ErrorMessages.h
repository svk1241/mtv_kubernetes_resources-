#ifndef ERRORMESSAGES_H_155336EE_6060_4BBE_B8D7_CB6BABDC9127_INCLUDED_
#define ERRORMESSAGES_H_155336EE_6060_4BBE_B8D7_CB6BABDC9127_INCLUDED_

#ifdef __cplusplus
extern "C" {
#endif

void MVPP_EmitErrorMessage(int errorCode, const char* pszFmt, ...);
void MVPP_EmitAllErrorMessages(GLOBDATA* globdata);

#ifdef __cplusplus
}
#endif

#endif	/* ndef ERRORMESSAGES_H_155336EE_6060_4BBE_B8D7_CB6BABDC9127_INCLUDED_ */
