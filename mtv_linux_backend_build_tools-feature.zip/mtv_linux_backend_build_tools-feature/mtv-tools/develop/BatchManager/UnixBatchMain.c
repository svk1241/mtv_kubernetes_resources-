#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Global communication area */
#define TGT_CLASS
#define TGT_GLOBDATA 
#include <tiabglob.h>

/* Oracle interface functions */
#include "DBMS.h"
/* Our nice error message emitter */
#include "ErrorMessages.h"

/* Module global data */
static	GLOBDATA	g_globdat;
static char szDef[] = "DEFAULT";
static char view[32767];

/* 20080130: UNIX build uses sed to change PROC_STEP to the procedure step name;
 * rely on link errors ('symbol PROC_STEP undefined') to avoid having a load module
 * with no procedure steps.
 */
#if	0
#if !defined(PROC_STEP)
#if defined(_DEBUG)
/* User is doing a test compile? */
/* Ensure main() is not defined such that it will not resolve if pulled from a static library */
#define	main	dummyMain
#else
/* This is a production compilation and we need the name of the procedure step! */
#error "define PROC_STEP prior to compilation.  PROC_STEP should be the PSTEP name."
#endif	/* defined(_DEBUG) */
#endif	/* !defined(PROC_STEP) */
#endif	/* 0 */

/* The procedure step this batch manager fronts */
extern void PROC_STEP(char*, char*, GLOBDATA*, char*, char*);

int main(int argc, char* argv[])
{
	int			returnCode = 0;
	GLOBDATA*	globdata = &g_globdat;
	void*		localSqlca = NULL;
	int			sqlcaLength = MVPP_DBMS_SqlcaLength();

	/* Initialize */
	memset( globdata, 0, sizeof *globdata );
	globdata->psmgr_environment_data.psmgr_pcb_cnt      = 2;
	globdata->psmgr_environment_data.psmgr_pcb_entry[0] = "tty01";
	strcpy( globdata->dialect_name,         szDef );
	strcpy( globdata->message_table_name,   szDef );
	strcpy( globdata->translate_table_name, szDef );
	globdata->psmgr_error_data.error_encountered_sw = ' ';
	globdata->psmgr_error_data.view_overflow_sw     = ' ';
	globdata->psmgr_dasg_data.status_flag[0] = ' ';
	globdata->psmgr_dasg_data.status_flag[1] = ' ';
	globdata->psmgr_dasg_data.status_flag[2] = '\0';

	/* We'll need a spot for action blocks to save their SQLCA */
	globdata->psmgr_dasg_data.save_sqlca = (char*)malloc(sqlcaLength);
	localSqlca = malloc(sqlcaLength);
	if (NULL == globdata->psmgr_dasg_data.save_sqlca || NULL == localSqlca)
	{
		printf("Unable to allocate memory\n");
		return 47;
	}
	memset(globdata->psmgr_dasg_data.save_sqlca, 0, sqlcaLength);

	/* Connect to Oracle */
	if (0 == MVPP_DBMS_Connect(argc, argv, localSqlca) )
	{
		MVPP_EmitErrorMessage(633, "Error connection to database failed");
		MVPP_DBMS_GetErrorMessage("--------------", view, sizeof(view), localSqlca);
		printf("%s\n", view);
		return 47;
	}

	/* 
	 * Use the procedure step.  If the compilation did not define symbol
	 * PROC_STEP, expect a link error (symbol not found).  An example for
	 * compilation would be:
	 *
	 *	cc -DPROC_STEP=HR50N01 -FoHR50X00.o UnixBatchMain.c 
	 *
	 */
	PROC_STEP(NULL, NULL, globdata, view, view);

	/* Scrounge for errors: */
	if ( ' ' != globdata->psmgr_dasg_data.status_flag[0]
		|| ' ' != globdata->psmgr_dasg_data.status_flag[1]
		|| ' ' != globdata->psmgr_error_data.error_encountered_sw
		|| ' ' != globdata->psmgr_error_data.view_overflow_sw)
	{
		/* Something went amiss; let the user know via stdout. */
		MVPP_EmitAllErrorMessages(globdata);

		/* An error means a rollback */
		globdata->psmgr_rollback_rqsted = 'A';
	}

	if ('A' == globdata->psmgr_rollback_rqsted)
	{
		if (0 == MVPP_DBMS_Rollback(localSqlca))
		{
			MVPP_EmitErrorMessage(633, "Error database rollback failed");
			MVPP_DBMS_GetErrorMessage("--------------", view, sizeof(view), localSqlca);
			printf("%s\n", view);
			returnCode = 47;
		}
	}
	else
	{
		if (0 == MVPP_DBMS_Commit(localSqlca))
		{
			MVPP_EmitErrorMessage(633, "Error database commit failed");
			MVPP_DBMS_GetErrorMessage("--------------", view, sizeof(view), localSqlca);
			printf("%s\n", view);
			returnCode = 47;
		}
	}

	if ( 'N' != globdata->psmgr_exit_msgtype)
	{
		int i;

		/* Only print exit state messages that are not "spaces": */
		globdata->psmgr_exit_infomsg[sizeof(globdata->psmgr_exit_infomsg) - 1] = '\0';
		for (i = 0;
			i < sizeof(globdata->psmgr_exit_infomsg) - 1 && '\0' != globdata->psmgr_exit_infomsg[i];
			++i)
		{
			if (' ' != globdata->psmgr_exit_infomsg[i])
			{
				printf("Exit state message: %s\n", globdata->psmgr_exit_infomsg);
				break;
			}
		}
	}

	if (0 == returnCode && 'A' == globdata->psmgr_rollback_rqsted)
	{
		/* Commit or rollback succeeded above but a CAB/ProcStep/Runtime function
		requested and abort. */
		returnCode = 42;
	}

	return returnCode;
}