#ifndef DBMS_H_155336EE_6060_4BBE_B8D7_CB6BABDC9127_INCLUDED_
#define DBMS_H_155336EE_6060_4BBE_B8D7_CB6BABDC9127_INCLUDED_

#ifdef __cplusplus
extern "C" {
#endif

int MVPP_DBMS_Connect(int argc, char* argv[], void* errorSqlca);
int MVPP_DBMS_Disconnect(void* errorSqlca);
int MVPP_DBMS_Commit(void* errorSqlca);
int MVPP_DBMS_Rollback(void* errorSqlca);
int MVPP_DBMS_GetErrorMessage(const char* inMsg, char* outMsg, size_t nOutMsg, void* errorSqlca);
int MVPP_DBMS_SqlcaLength(void);

#ifdef __cplusplus
}
#endif

#endif /* ndef DBMS_H_155336EE_6060_4BBE_B8D7_CB6BABDC9127_INCLUDED_ */
