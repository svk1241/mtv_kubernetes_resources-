#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "DBMS.h"

/* Global communication area */
#define TGT_CLASS
#define TGT_GLOBDATA 
#include <tiabglob.h>

#if !defined(_countof)
#define	_countof(x)	(sizeof(x)/sizeof(x[0]))
#endif

void MVPP_EmitErrorMessage(int errorCode, const char* pszFmt, ...)
{
	va_list args;

	if (-1 != errorCode) printf("TIRM%03dE: ", errorCode);

	va_start(args, pszFmt);
	vprintf(pszFmt, args);
	va_end(args);

	printf("\n");
}

#define EmitErrorMessage MVPP_EmitErrorMessage
void MVPP_EmitAllErrorMessages(GLOBDATA* globdata)
{
	EmitErrorMessage(30, "Application failed - Updates have been backed out");
	EmitErrorMessage(31, "Failing procedure exit data follows:");
	EmitErrorMessage(32, "Last or current action block id    = %s", globdata->psmgr_debug_data.cur_ab_id);
	EmitErrorMessage(33, "Last or current action block name  = %s", globdata->psmgr_debug_data.cur_ab_name);

	if (LOCAL_VIEW_ALLOC_ERROR != globdata->psmgr_error_data.error_encountered_sw)
	{
		EmitErrorMessage(34, "Last or current database statement = %d", globdata->psmgr_dasg_data.action_id);
	}

	EmitErrorMessage(35, "Current statement being processed  = %s", globdata->psmgr_debug_data.last_statement_num);

	if (' ' != globdata->psmgr_error_data.view_overflow_sw)
	{
		EmitErrorMessage(36, "*** Fatal view overflow was encountered ***");
	}

	if (' ' != globdata->psmgr_error_data.error_encountered_sw)
	{
		EmitErrorMessage(37, "** Fatal Error was encountered ***");

		if (0 == memcmp("IE", globdata->psmgr_dasg_data.last_status, 2)
			|| 0 == memcmp("DE", globdata->psmgr_dasg_data.last_status, 2))
		{
			const char* pszMsg = "Unknown error";
			int error = atoi(globdata->psmgr_function_data.psmgr_func_errmsg);

			if (0 == memcmp("IE", globdata->psmgr_dasg_data.last_status, 2))
			{
				EmitErrorMessage(149, "Error occurred in AllFusion(r) Gen supplied function: %s", globdata->psmgr_function_data.psmgr_func_name);
			}
			else
			{
				EmitErrorMessage(146, "Error occurred in AllFusion(r) Gen runtime routine: %s", globdata->psmgr_function_data.psmgr_func_name);
			}

			switch (error)
			{
			case 130: pszMsg = "Internal Error: parameters invalid - Contact support"; break;
			case 131: pszMsg = "Length of input string exceeds 255 characters"; break;
			case 132: pszMsg = "Substring length exceeds length of input string"; break;
			case 133: pszMsg = "Substring starting position exceeds length of input string"; break;
			case 134: pszMsg = "Starting position + length exceeds length of input string"; break;
			case 135: pszMsg = "Concatenation of input strings exceeds 255 characters"; break;
			case 136: pszMsg = "Numeric input parameters must be positive"; break;
			case 137: pszMsg = "Input date was not a valid date"; break;
			case 138: pszMsg = "Format of input date was not valid"; break;
			case 139: pszMsg = "Internal error: date calculated is not valid - Contact support"; break;
			case 140: pszMsg = "Number of days integer exceeds 3,652,059"; break;
			case 141: pszMsg = "Input time was not a valid time"; break;
			case 142: pszMsg = "Format of input time was not valid"; break;
			case 143: pszMsg = "Invalid input string:  cannot convert to numeric"; break;
			case 144: pszMsg = "Internal error: converting string to numeric - Contact support"; break;
			case 145: pszMsg = "Invalid length for string to be converted, 0 < length < 16"; break;
			case 146: pszMsg = "Error occurred in AllFusion(r) Gen runtime routine:: pszMsg = "; break;
			case 147: pszMsg = "Date increment would result in an invalid date range"; break;
			case 148: pszMsg = "Internal error: calculated time is not valid - Contact support"; break;
			case 149: pszMsg = "Error occurred in AllFusion(r) Gen supplied function:: pszMsg = "; break;
			case 150: pszMsg = "Input date duration was not a valid date duration"; break;
			case 151: pszMsg = "Input time duration was not a valid time duration"; break;
			case 152: pszMsg = "Data cannot be deleted because a relationship restricts the deletion"; break;
			case 153: pszMsg = "Memory allocation failed"; break;
			case 154: pszMsg = "Invalid filter or sort argument string"; break;
			case 155: pszMsg = "No arguments in filter or sort string"; break;
			case 156: pszMsg = "Internal error in filter or sort"; break;
			}
			EmitErrorMessage(-1, pszMsg);

			if (LOCAL_VIEW_ALLOC_ERROR == globdata->psmgr_error_data.error_encountered_sw)
			{
				EmitErrorMessage(153, "Memory allocation failed");
			}
		}
	}

	if (0 == memcmp("FE", globdata->psmgr_dasg_data.status_flag, 2))
	{
		EmitErrorMessage(38, "*** Fatal database error was encountered ***");
		EmitErrorMessage(39, "                    DB last status = %s", globdata->psmgr_dasg_data.last_status);
	}

	if (0 == memcmp("DB", globdata->psmgr_dasg_data.status_flag, 2))
	{
		EmitErrorMessage(38, "*** Fatal database error was encountered ***");
		EmitErrorMessage(39, "                    DB last status = %s", globdata->psmgr_dasg_data.last_status);
	}

	if (0 == memcmp("AB", globdata->psmgr_dasg_data.status_flag, 2))
	{
		EmitErrorMessage(162, "Application requested abort. DBMS error message follows:");
		if (0 == strlen(globdata->psmgr_dasg_data.last_status))
		{
			EmitErrorMessage(164, "SQLCODE = 0: No DBMS error has occurred.");
		}
		else
		{
			EmitErrorMessage(39, "                    DB last status = %s", globdata->psmgr_dasg_data.last_status);
		}
	}

	if (0 == memcmp("AM", globdata->psmgr_dasg_data.status_flag, 2))
	{
		EmitErrorMessage(163, "Application requested abort. Error message follows:");
		fwrite(globdata->psmgr_extra_errinfo.errinfo_buf_addr,
			globdata->psmgr_extra_errinfo.errinfo_msg_size,
			1,
			stdout);
		printf("\n");
		EmitErrorMessage(39, "                    DB last status = %s", globdata->psmgr_dasg_data.last_status);
	}

	if (0 == memcmp("RT", globdata->psmgr_dasg_data.status_flag, 2))
	{
		EmitErrorMessage(161, "Maximum number of retries exceeded. Application aborted.");
		EmitErrorMessage(39, "                    DB last status = %s", globdata->psmgr_dasg_data.last_status);
	}

	if (0 == memcmp("BP", globdata->psmgr_dasg_data.status_flag, 2))
	{
		EmitErrorMessage(40, "Permitted values mismatch, field = f%ld", globdata->psmgr_dasg_data.attribute_id);
	}

	if (0 == memcmp("IA", globdata->psmgr_dasg_data.status_flag, 2))
	{
		EmitErrorMessage(41, "Retrieved data mismatch, field = f%ld", globdata->psmgr_dasg_data.attribute_id);
	}

	if (0 == memcmp("BT", globdata->psmgr_dasg_data.status_flag, 2))
	{
		EmitErrorMessage(45, "Data doesnt match type, attribute = a%ld", globdata->psmgr_dasg_data.attribute_id);
	}

	if (0 == memcmp("RE", globdata->psmgr_dasg_data.status_flag, 2))
	{
		EmitErrorMessage(152, "Data cannot be deleted because a relationship restricts the deletion");
	}

	if (0 == memcmp("PO", globdata->psmgr_dasg_data.status_flag, 2))
	{
		EmitErrorMessage(251, "Decimal Precision Overflow");
	}

	if (0 == memcmp("PU", globdata->psmgr_dasg_data.status_flag, 2))
	{
		EmitErrorMessage(252, "Decimal Precision Underflow");
	}

	if (0 == memcmp("PZ", globdata->psmgr_dasg_data.status_flag, 2))
	{
		EmitErrorMessage(253, "Decimal Precision Divide By Zero");
	}

	if (0 == memcmp("PI", globdata->psmgr_dasg_data.status_flag, 2))
	{
		EmitErrorMessage(254, "Decimal Precision Invalid Data");
	}

	if (0 == memcmp("DB", globdata->psmgr_dasg_data.last_status, 2)
		|| 0 == memcmp("AM", globdata->psmgr_dasg_data.last_status, 2)
		|| 0 == memcmp("DT", globdata->psmgr_dasg_data.last_status, 2)
		|| 0 == memcmp("DF", globdata->psmgr_dasg_data.last_status, 2)
		|| 0 == memcmp("NU", globdata->psmgr_dasg_data.last_status, 2)
		|| 0 == memcmp("AB", globdata->psmgr_dasg_data.last_status, 2))
	{
		char	szMsg[512];

		MVPP_DBMS_GetErrorMessage("--------------", szMsg, _countof(szMsg), globdata->psmgr_dasg_data.save_sqlca);
		printf("%s\n", szMsg);
	}

	EmitErrorMessage(46, "*** Processing terminated ***");
}
#undef EmitErrorMessage
