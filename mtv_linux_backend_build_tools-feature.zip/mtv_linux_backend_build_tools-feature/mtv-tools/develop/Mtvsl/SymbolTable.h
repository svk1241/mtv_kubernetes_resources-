// ----------------------------------------------------------------------
// MetaVance
// Copyright (C) 2008-2009, Hewlett-Packard Development Company, LP
// All Rights Reserved.
//
// EDS, an HP company
// 225 Grandview Avenue
// Camp Hill, PA  17011 USA
// http://www.eds.com
//
// This source code is the confidential property of EDS, an HP company.
// All proprietary rights, including but not limited to any trade secret,
// copyright, patent or trademark rights in and to this source code are
// the property of EDS.  This source code is not to be used, disclosed or
// reproduced in any form without the express written consent of EDS.
//
// ----------------------------------------------------------------------
#if	!defined(_mtvsl_symboltable_h_included_)
#define	_mtvsl_symboltable_h_included_

// Needs map, string, and vector

namespace Mtvsl {

// @doc INTERNAL
//
// @class A container to hold zero or more string symbols.  Symbols can be
// duplicated in a <c SymbolTable> instance.  It is up to the client of this
// class to allow or remove duplicates.
class SymbolTable
{
// @access public
public:

	// @doc INTERNAL
	//
	// @mfunc Default constructor
	SymbolTable(void)
	{
	}

	// @doc INTERNAL
	// 
	// @mfunc Create a copy of a <c SymbolTable> instance.
	// 
	// @parm const SymbolTable & | other | <c SymbolTable> instance to copy.
	SymbolTable(const SymbolTable& other)
	{
		operator =(other);
	}

	// @doc INTERNAL
	// 
	// @mfunc Assignment operator.
	// 
	// @parm const SymbolTable & | rhs | <c SymbolTable> instance to copy.
	// 
	// @rdesc SymbolTable& | the current <c SymbolTable> instance. 
	SymbolTable& operator =(const SymbolTable& rhs)
	{
		if (&rhs != this)
		{
			m_table.clear();
			m_table.insert(rhs.m_table.begin(), rhs.m_table.end());
		}
		return *this;
	}

	// @doc INTERNAL
	// 
	// @mfunc Subtractive operator.  Remove the symbols in <p rhs> from
	// this <c SymbolTable> instance.
	// 
	// @parm const SymbolTable & | rhs | <c SymbolTable> instance subtract.
	// 
	// @rdesc SymbolTable& | the current <c SymbolTable> instance. 
	SymbolTable& operator -=(const SymbolTable& rhs)
	{
		if (&rhs == this)
		{
			// The difference of this symbol set with itself is nothing.
			m_table.clear();
		}
		else
		{
			// Remove each matching symbol.
			TableType	difference;
			for (TableType::const_iterator it = m_table.begin();
				it != m_table.end();
				++it)
			{
				unsigned int	hash = it->first;
				if (rhs.m_table.end() == rhs.m_table.find(hash))
				{
					// Transfer all the items which match the has code.
					while (it != m_table.end() && hash == it->first)
					{
						difference.insert(*it);
						++it;
					}

					// The iterator will be incremented above; right now it
					// points to the first item past the matching hash.  Reset
					// it to accomodate the incremment.
					--it;
				}
			}

			// The difference is now the set
			m_table.clear();
			m_table.insert(difference.begin(), difference.end());
		}
		return *this;
	}

	// @doc INTERNAL
	// 
	// @mfunc Operator equals.
	// 
	// @parm const SymbolTable & | rhs | <c SymbolTable> to check for equality.
	// 
	// @rdesc bool | true if the two <c SymbolTable> instances match.
	// @rdesc bool | false if the two <c SymbolTable> instances do not match.
	bool operator ==(const SymbolTable& rhs) const
	{
		bool	isEqual = false;
		if (&rhs == this)
		{
			isEqual = true;
		}
		else
		{
			if (m_table.size() != rhs.m_table.size())
			{
				isEqual = false;;
			}
			else
			{
				isEqual = true;
				for (TableType::const_iterator it = m_table.begin(); isEqual && it != m_table.end(); ++it)
				{
					isEqual = (rhs.m_table.end() != rhs.m_table.find(it->first));
				}
			}
		}
		return isEqual;
	}

	// @doc INTERNAL
	//
	// @mfunc Add a symbol to this <c SymbolTable> instance.  Duplicate symbols
	// are permitted as are empty symbol strings.
	void Add(const std::string& symbol)
	{
		TableType::value_type value(PJWHash(symbol), symbol);
		m_table.insert(value);
	}

	// @doc INTERNAL
	// 
	// @mfunc Does this <c SymbolTable> instance contain the given <p symbol>?
	// 
	// @parm const std::string & | symbol | symbol string to find
	// 
	// @rdesc bool | true if the symbol is contained in this <c SymbolTable> instance.
	// @rdesc bool | false if the symbol is not contained in this <c SymbolTable> instance.
	bool Contains(const std::string& symbol) const
	{
		unsigned int hash = PJWHash(symbol);
		TableType::const_iterator it = m_table.find(hash);
		while (it != m_table.end() && hash == it->first)
		{
			if (0 == it->second.compare(symbol)) return true;
			++it;
		}
		return false;
	}

	// @doc INTERNAL
	// 
	// @mfunc Remove the given <p symbol> from this <c SymbolTable> instance.
	// 
	// @parm const std::string & | symbol | symbol string to remove
	void Remove(const std::string& symbol)
	{
		unsigned int hash = PJWHash(symbol);
		TableType::iterator it = m_table.find(hash);
		while (it != m_table.end() && hash == it->first)
		{
			if (0 == it->second.compare(symbol))
			{
				m_table.erase(it);
			}
			it = m_table.find(hash);
		}
	}

	// @doc INTERNAL
	// 
	// @mfunc Get the number of symbols stored in this <c SymbolTable>.
	//
	// @rdesc size_t | count of stored symbols. 
	size_t Size(void) const
	{
		return m_table.size();
	}

	// @doc INTERNAL
	//
	// @mfunc Transform the contents of this <c SymbolTable> into
	// a vector of strings.
	//
	// @rdesc std::vector<std::string> | all symbols, including any duplicates,
	// in an unordered vector.
	std::vector<std::string> ToArray(void) const
	{
		std::vector<std::string> theArray;
		
		theArray.reserve(m_table.size());
		for (TableType::const_iterator it = m_table.begin(); it != m_table.end(); ++it)
		{
			theArray.push_back(it->second);
		}

		return theArray;
	}

	// @doc INTERNAL
	//
	// @mfunc Destructor.
	~SymbolTable(void)
	{
	}

private:

	// @doc INTERNAL
	// 
	// @mfunc Get a hash value describing the given string.
	// From: http://www.partow.net/programming/hashfunctions/
	// 
	// @parm const std::string & | str | string to hash
	// 
	// @rdesc unsigned int | hash value
	unsigned int PJWHash(const std::string& str) const
	{
	   unsigned int BitsInUnsignedInt = (unsigned int)(sizeof(unsigned int) * 8);
	   unsigned int ThreeQuarters     = (unsigned int)((BitsInUnsignedInt  * 3) / 4);
	   unsigned int OneEighth         = (unsigned int)(BitsInUnsignedInt / 8);
	   unsigned int HighBits          = (unsigned int)(0xFFFFFFFF) << (BitsInUnsignedInt - OneEighth);
	   unsigned int hash              = 0;
	   unsigned int test              = 0;

	   for(std::size_t i = 0; i < str.length(); i++)
	   {
		  hash = (hash << OneEighth) + str[i];

		  if((test = hash & HighBits)  != 0)
		  {
			 hash = (( hash ^ (test >> ThreeQuarters)) & (~HighBits));
		  }
	   }

	   return hash;
	}

	typedef	std::multimap<unsigned int, std::string> TableType;
	TableType m_table;
};

}	// namespace Mtvsl

#endif	// !defined(_mtvsl_symboltable_h_included_)
