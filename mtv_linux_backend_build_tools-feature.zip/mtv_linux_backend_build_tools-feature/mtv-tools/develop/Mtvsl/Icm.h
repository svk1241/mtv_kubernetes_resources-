// ----------------------------------------------------------------------
// MetaVance
// Copyright (C) 2008-2009, Hewlett-Packard Development Company, LP
// All Rights Reserved.
//
// EDS, an HP company
// 225 Grandview Avenue
// Camp Hill, PA  17011 USA
// http://www.eds.com
//
// This source code is the confidential property of EDS, an HP company.
// All proprietary rights, including but not limited to any trade secret,
// copyright, patent or trademark rights in and to this source code are
// the property of EDS.  This source code is not to be used, disclosed or
// reproduced in any form without the express written consent of EDS.
//
// ----------------------------------------------------------------------
#if	!defined(_mtvsl_icm_h_included_)
#define	_mtvsl_icm_h_included_

// Needs cctype, istream, map, stack, string, and vector

#include "LineParser.h"

namespace Mtvsl {

// @doc INTERNAL
//
// @class A CA Gen Installation Control Module (ICM) is a series of sections
// which contain one or more name / value pairs.
class Icm
{
	typedef std::pair<std::string, std::string> NameValuePair;
	typedef std::map<std::string, std::string> NameValuePairs;
	typedef	std::vector<NameValuePairs> Section;
	typedef std::pair<std::string, Section> SectionsItem;
	typedef std::map<SectionsItem::first_type, SectionsItem::second_type> Sections;

public:

	// @doc INTERNAL
	//
	// @mfunc | Default constructor
	Icm(void)
	{
	}

	// @doc INTERNAL
	//
	// @mfunc | Copy constructor
	//
	// @parm const <c Icm>& | other | the <c Icm> instance to copy
	Icm(const Icm& other)
	{
		operator =(other);
	}

	// @doc INTERNAL
	// 
	// @mfunc Get the Dialog Manager module name, the PSTEP
	// module name and then each action block
	// including CASCADE members.
	//
	// @rdesc std::vector<std::string> | a vectory of action block names
	std::vector<std::string> get_ActionBlocks(void) const
	{
		const char*	sectionNames[] = { "execunit", "pstep", "acblk" };

		return GetMemberNames((sizeof(sectionNames)/sizeof(sectionNames[0])),
			sectionNames);
	}

	// @doc INTERNAL
	//
	// @mfunc Get the external action blocks.
	//
	// @rdesc std::vector<std::string> | a vectory of external action block names
	std::vector<std::string> get_Externals(void) const
	{
		const char*	sectionNames[] = { "extern" };

		return GetMemberNames((sizeof(sectionNames)/sizeof(sectionNames[0])),
			sectionNames);
	}

	// @doc INTERNAL
	//
	// @mfunc Is this an <c Icm> describing a CASCADE library?
	//
	// @rdesc bool | true if the <c Icm> describes a CASCADE library
	// @rdesc bool | false if the <c Icm> does not describe a CASCADE library
	bool get_IsCascade(void) const
	{
		// Most ICMs have cascade=CASACDE in the execunit section.
		// However, a CASCADE ICM will have no procedure steps.
		// OPSLIBs will have an lmtype=OPSLIB but no procedure steps.
		Sections::const_iterator	it = m_sections.find("pstep");

		return (m_sections.end() == it)
			&& (true == get_LmType(""))
			&& (0 == get_FromExecunit("cascade").compare("CASCADE"))
			;


	}

	// @doc INTERNAL
	//
	// @mfunc Is this an <c Icm> describing a OPLIB?
	//
	// @rdesc bool | true if the <c Icm> describes an OPLIB
	// @rdesc bool | false if the <c Icm> does not describe an OPLIB
	bool get_IsOpslib(void) const
	{
		return get_LmType("OPLIB");
	}

	// @doc INTERNAL
	//
	// @mfunc Is this an <c Icm> describing an online server?
	//
	// @rdesc bool | true if the <c Icm> describes an online server
	// @rdesc bool | false if the <c Icm> does not describe an online server

	bool get_IsServer(void) const
	{
		return get_LmType("SRVR");
	}

// @access private
private:

	// @doc INTERNAL
	//
	// @mfunc Compare the <c Icm>'s EXECUNIT.LMTYPE to the given string.
	//
	// @parm const char* | str | value to compare
	//
	// @rdesc bool | true if the <c Icm> LMTYPE is <p str>
	// @rdesc bool | false if the <c Icm> is not <p str>
	std::string get_FromExecunit(const char* str) const
	{
		std::string	value;
		if (NULL != str)
		{
			Sections::const_iterator	it = m_sections.find("execunit");
			if (m_sections.end() != it)
			{
				for (Section::const_iterator itS = (*it).second.begin();
					itS != (*it).second.end();
					++itS)
				{
					NameValuePairs::const_iterator itN = (*itS).find(str);
					if (itN != (*itS).end())
					{
						value = itN->second;
					}
				}
			}
		}
		return value;
	}

	// @doc INTERNAL
	//
	// @mfunc Compare the <c Icm>'s EXECUNIT.LMTYPE to the given string.
	//
	// @parm const char* | str | value to compare
	//
	// @rdesc bool | true if the <c Icm> LMTYPE is <p str>
	// @rdesc bool | false if the <c Icm> is not <p str>
	bool get_LmType(const char* str) const
	{
		bool	matches = false;
		if (NULL != str)
		{
			std::string lmtype = get_FromExecunit("lmtype");

			// We have a match if the lmtype equals the given string
			// or the given string is an empty string and so is the
			// value of lmtype.
			matches = (0 == lmtype.compare(str))
				|| (0 == strlen(str) && 0 == lmtype.length());
		}
		return matches;
	}

// @access public
public:

	// @doc INTERNAL
	//
	// @mfunc Get the name of the load module described by this <c Icm>.
	//
	// @rdesc std::string | load module name
	std::string get_LoadModule(void) const
	{
		std::vector<std::string>	names;
		const char*					sectionNames[] = { "execunit" };

		names = GetMemberNames(1, sectionNames);
		if (0 == names.size()) names.push_back("");

		return names.front();
	}

	// @doc INTERNAL
	//
	// @mfunc Get first transaction code of the first procedure
	// step in this <c Icm>.
	//
	// @rdesc std::string | transaction code.  May be empty.
	std::string get_Transaction(void) const
	{
		std::vector<std::string>	tranCodes = get_Transactions();
		if (0 == tranCodes.size()) tranCodes.push_back("");

		return tranCodes.front();
	}

	// @doc INTERNAL
	//
	// @mfunc Get all the transaction codes of all the procedure
	// step in this <c Icm>.
	//
	// @rdesc std::vector<std::string> | transaction codes.  May be empty.
	std::vector<std::string> get_Transactions(void) const
	{
		std::vector<std::string>	tranCodes;
		Sections::const_iterator	it;

		it = m_sections.find("pstep");
		if (m_sections.end() != it)
		{
			for (Section::const_iterator itS = (*it).second.begin();
				itS != (*it).second.end();
				++itS)
			{
				NameValuePairs::const_iterator itN = (*itS).find("dlgtran");
				if (itN != (*itS).end())
				{
					tranCodes.push_back((*itN).second);
				}
			}
		}

		return tranCodes;
	}

	// @doc INTERNAL
	//
	// @mfunc Does this <c Icm> contain a procedure step which defines
	// the transaction code given in <p transaction>?
	//
	// @parm const std::string& | transaction | the transaction code to find.
	//
	// @rdesc bool | true if the <c Icm> defines <p transaction>
	// @rdesc bool | false if the <c Icm> does not define <p transaction>
	bool has_Transaction(const std::string& transaction) const
	{
		bool						hasTransaction = false;
		Sections::const_iterator	it;

		it = m_sections.find("pstep");
		if (m_sections.end() != it)
		{
			for (Section::const_iterator itS = (*it).second.begin();
				itS != (*it).second.end() && false == hasTransaction;
				++itS)
			{
				NameValuePairs::const_iterator itN = (*itS).find("dlgtran");
				if (itN != (*itS).end())
				{
					hasTransaction = (0 == (*itN).second.compare(transaction));
				}
			}
		}

		return hasTransaction;
	}

	// @doc INTERNAL
	//
	// @mfunc Assignment operator
	//
	// @parm const <c Icm>& | rhs | <c Icm> instance
	//
	// @rdesc <c Icm>& | the current <c Icm> instance
	Icm& operator =(const Icm& rhs)
	{
		if (&rhs != this)
		{
			m_sections.clear();
			m_sections.insert(rhs.m_sections.begin(), rhs.m_sections.end());
		}
		return *this;
	}

	// @doc INTERNAL
	//
	// @mfunc Emit a load module, procedure step name, and transaction code tuple
	// to the given output stream.  The items are comma-seperated and terminated
	// with a new line character.
	//
	// @parm std::ostream& | output | output stream
	void emitLoadModulePstepTran(std::ostream& output) const
	{
		Sections::const_iterator		it;
		NameValuePairs::const_iterator	itN;

		it = m_sections.find("pstep");
		if (m_sections.end() != it)
		{
			for (Section::const_iterator itS = (*it).second.begin();
				itS != (*it).second.end();
				++itS)
			{
				output << get_LoadModule()
					<< ',';
				itN = (*itS).find("name");
				if (itN != (*itS).end())
				{
					output << (*itN).second;
				}
				output << ',';
				itN = (*itS).find("dlgtran");
				if (itN != (*itS).end())
				{
					output << (*itN).second;
				}
				output << std::endl;
			}
		}
	}

	/*
	void Dump(void) const
	{
		for (Sections::const_iterator it = m_sections.begin(); it != m_sections.end(); ++it)
		{
			std::cout << ':' << it->first << std::endl;
			for (Section::const_iterator itN = it->second.begin(); itN != it->second.end(); ++itN)
			{
				for (NameValuePairs::const_iterator itV = itN->begin(); itV!= itN->end(); ++itV)
				{
					std::cout << '\t' << itV->first << '=' << itV->second << std::endl;
				}
			}
			std::cout << ":e" << it->first << std::endl;
		}
	}
	*/

// @access private
private:

	// @doc INTERNAL
	//
	// @mfunc Add a new section to this <c Icm>.  If the section, identified by
	// <p name> exists, create a new name / value pair list for that section.
	//
	// @parm const std::string | name | section name
	//
	// @rdesc Section& | new or existing section.
	Section& AddSection(const std::string& name)
	{
		SectionsItem	item;
		item.first = name;

		std::pair<Sections::iterator, bool> insertedAt
			= m_sections.insert(item);

		Section& ret = (*(insertedAt.first)).second;
		ret.push_back(NameValuePairs());

		return ret;
	}

	// @doc INTERNAL
	// 
	// @mfunc | Get the values of all items named "member" from each given section.
	// 
	// @parm | nSectionNames | number of names in <p sectionNames>
	// @parm | sectionNames | section names
	// 
	// @rdesc std::vector<std::string> | a vector of names which may be empty.
	std::vector<std::string> GetMemberNames(size_t nSectionNames, const char* sectionNames[]) const
	{
		Sections::const_iterator it;
		std::vector<std::string> names;

		// Do for each section
		for (size_t i = 0; i < nSectionNames; ++i)
		{
			it = m_sections.find(sectionNames[i]);
			if (m_sections.end() != it)
			{
				// Do for each name / value pair list
				for (Section::const_iterator itS = (*it).second.begin();
					itS != (*it).second.end();
					++itS)
				{
					NameValuePairs::const_iterator itN = (*itS).find("member");
					if (itN != (*itS).end())
					{
						// Found one in the list!
						names.push_back((*itN).second);
					}
				}
			}
		}

		return names;
	}

public:

	// @doc INTERNAL
	//
	// @cmember Parse a textual <c Icm> from the given stream
	static Icm Parse(std::istream& stream);

	// @doc INTERNAL
	//
	// @mfunc Destructor
	~Icm(void)
	{
	}

private:

	Sections m_sections;
};


// @doc INTERNAL
// 
// @mfunc | Parse a textual <c Icm> from the given stream.  Throws std::logic_error
// if the stream is unparsable.
// 
// @parm | stream | text stream
// 
// @rdesc <c Icm> | <c Icm> instance
Icm Icm::Parse(std::istream& stream)
{
	std::string::size_type	index;
	std::string				line;
	LineParser				lineParser;
	NameValuePair			nvp;
	Icm						parsedIcm;
	std::stack<Section*>	section;
	std::stack<std::string>	state;

	line.reserve(1024);
	while (!stream.eof())
	{
		lineParser.GetLine(stream, line);

		// Ignore blank lines
		if (0 == line.length()) continue;

		// Have we entered or exited a section?
		if (':' == line[0])
		{
			line = line.substr(1);

			if ('.' == line[line.length() - 1] || 0 == line.compare("eentity") || 0 == line.compare("erelation"))
			{
				// We're exiting a section
				if ('.' == line[line.length() - 1]) line = line.substr(0, line.length() - 1);
				if (0 != line.compare(state.top()))
				{
					throw std::logic_error("bad ICM state");
				}
				state.pop();
				section.pop();
			}
			else
			{
				// We're entering a section; set the expected end state
				section.push(&(parsedIcm.AddSection(line)));
				line.insert((unsigned long) 0, (unsigned long) 1, (char) 'e');
				state.push(line);
			}
		}
		else
		{
			// A name / value pair must be in a section
			if (0 == section.size()) throw std::logic_error("unknown ICM section");

			// Must be a name / value pair
			index = line.find_first_of('=');
			if (std::string::npos == index)
			{
				throw std::logic_error("unknown ICM line");
			}

			// Add the name / value pair to the current section
			nvp.first = line.substr(0, index);
			nvp.second = line.substr(index + 1);
			if (0 < nvp.second.length())
			{
				if ('.' == nvp.second[nvp.second.length() - 1]) nvp.second = nvp.second.substr(0, nvp.second.length() - 1);
				section.top()->back().insert(nvp);
			}
		}
	}

	// All sections must have been closed before end-of-file.
	if (0 != section.size()) throw std::logic_error("ICM section not closed");

	return parsedIcm;
}

}	// namespace Mtvsl

#endif	// !defined(_mtvsl_icm_h_included_)
