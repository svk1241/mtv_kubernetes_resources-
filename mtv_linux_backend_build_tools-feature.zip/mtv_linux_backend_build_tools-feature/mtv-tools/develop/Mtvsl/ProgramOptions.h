// ----------------------------------------------------------------------
// MetaVance
// Copyright (C) 2008-2009, Hewlett-Packard Development Company, LP
// All Rights Reserved.
//
// EDS, an HP company
// 225 Grandview Avenue
// Camp Hill, PA  17011 USA
// http://www.eds.com
//
// This source code is the confidential property of EDS, an HP company.
// All proprietary rights, including but not limited to any trade secret,
// copyright, patent or trademark rights in and to this source code are
// the property of EDS.  This source code is not to be used, disclosed or
// reproduced in any form without the express written consent of EDS.
//
// ----------------------------------------------------------------------
#if	!defined(_mtvsl_programoptions_h_included_)
#define	_mtvsl_programoptions_h_included_

// Needs string, and vector.

namespace Mtvsl {

// @doc INTERNAL
//
// @class Options used to influence program execution
class ProgramOptions
{
// @access public
public:

	// @doc INTERNAL
	//
	// @mfunc Default constructor
	ProgramOptions(void)
		: m_apiRemainderModuleCount(4)
		, m_apiRemainderModulePrefix("APIR")
		, m_onlineRemainderModuleCount(4)
		, m_onlineRemainderModulePrefix("LMR")
		, m_skipApis(false)
		, m_skipBatch(false)
		, m_skipOnline(false)
                , m_skipBatchSharedLib(false)
	{
		m_includeBatchIcmPatterns.push_back("*.icm");
		m_includePkgPatterns.push_back("*.pkg");
		m_includeServerIcmPatterns.push_back("*.icm");
	}

	// @doc INTERNAL
	// 
	// @mfunc Copy constructor.
	// 
	// @parm const ProgramOptions & | other | <c ProgramOptions> instance to copy.
	ProgramOptions(const ProgramOptions& other)
	{
		operator =(other);
	}

	// @doc INTERNAL
	//
	// @mfunc Get the preferred count of API remainder modules.
	//
	// @rdesc int | preferred count of API remainder modules.
	int get_ApiRemainderModuleCount(void) const
	{
		return m_apiRemainderModuleCount;
	}

	// @doc INTERNAL
	//
	// @mfunc Get file name prefix for API remainder modules
	//
	// @rdesc const std::string& | file name prefix for API remainder modules.
	const std::string& get_ApiRemainderModulePrefix(void) const
	{
		return m_apiRemainderModulePrefix;
	}

	// @doc INTERNAL
	//
	// @mfunc Get API transaction grouping file name.
	//
	// @rdesc const std::string& | API transaction grouping file name
	const std::string& get_ApiTransactionGrouping(void) const
	{
		return m_apiTransactionGrouping;
	}

	// @doc INTERNAL
	//
	// @mfunc Get area concatenation list.
	//
	// @rdesc const std::vector<std::string>& | areas
	const std::vector<std::string>& get_Areas(void) const
	{
		return m_areas;
	}

	// @doc INTERNAL
	//
	// @mfunc Get component area concatenation list.
	//
	// @rdesc const std::vector<std::string>& | component areas
	const std::vector<std::string>& get_ComponentAreas(void) const
	{
		return m_componentAreas;
	}

	// @doc INTERNAL
	//
	// @mfunc Get API ICM file name exclusion patterns.
	//
	// @rdesc const std::vector<std::string>& | API ICM file name patterns.  May be empty.
	const std::vector<std::string>& get_ExcludeApiIcmPatterns(void) const
	{
		return m_excludeApiIcmPatterns;
	}

	// @doc INTERNAL
	//
	// @mfunc Get batch ICM file name exclusion patterns.
	//
	// @rdesc const std::vector<std::string>& | batch file name exclusion patterns.  May be empty.
	const std::vector<std::string> get_ExcludeBatchIcmPatterns(void) const
	{
		return m_excludeBatchIcmPatterns;
	}

	// @doc INTERNAL
	//
	// @mfunc Get PKG file name exclusion patterns.
	//
	// @rdesc const std::vector<std::string>& | PKG file name exclusion patterns.  May be empty.
	const std::vector<std::string> get_ExcludePkgPatterns(void) const
	{
		return m_excludePkgPatterns;
	}

	// @doc INTERNAL
	//
	// @mfunc Get server ICM file name exclusion patterns.
	//
	// @rdesc const std::vector<std::string>& | server file name exclusion patterns.  May be empty.
	const std::vector<std::string> get_ExcludeServerIcmPatterns(void) const
	{
		return m_excludeServerIcmPatterns;
	}

	// @doc INTERNAL
	//
	// @mfunc Get API ICM file name pattern inclusion list.
	//
	// @rdesc const std::vector<std::string>& | API ICM file name inclusion patterns.
	const std::vector<std::string>& get_IncludeApiIcmPatterns(void) const
	{
		return m_includeApiIcmPatterns;
	}

	// @doc INTERNAL
	//
	// @mfunc Get batch ICM file name pattern inclusion list.
	//
	// @rdesc const std::vector<std::string>& | batch program ICM file name inclusion patterns.
	const std::vector<std::string>& get_IncludeBatchIcmPatterns(void) const
	{
		return m_includeBatchIcmPatterns;
	}

	// @doc INTERNAL
	//
	// @mfunc Get PKG file name inclusion patterns.
	//
	// @rdesc const std::vector<std::string>& | PKG file name inclusion patterns.  May be empty.
	const std::vector<std::string> get_IncludePkgPatterns(void) const
	{
		return m_includePkgPatterns;
	}

	// @doc INTERNAL
	//
	// @mfunc Get online inclusion server ICM file name pattern list.
	//
	// @rdesc const std::vector<std::string>& | online server ICM file name patterns.
	const std::vector<std::string>& get_IncludeServerIcmPatterns(void) const
	{
		return m_includeServerIcmPatterns;
	}

	// @doc INTERNAL
	//
	// @mfunc Get the preferred count of remainder modules.
	//
	// @rdesc int | preferred count of remainder modules.
	int get_OnlineRemainderModuleCount(void) const
	{
		return m_onlineRemainderModuleCount;
	}

	// @doc INTERNAL
	//
	// @mfunc Get file name prefix for remainder modules
	//
	// @rdesc const std::string& | file name prefix for remainder modules.
	const std::string& get_OnlineRemainderModulePrefix(void) const
	{
		return m_onlineRemainderModulePrefix;
	}

	// @doc INTERNAL
	//
	// @mfunc Get online transaction grouping file name.
	//
	// @rdesc const std::string& | online transaction grouping file name
	const std::string& get_OnlineTransactionGrouping(void) const
	{
		return m_onlineTransactionGrouping;
	}

	// @doc INTERNAL
	//
	// @mfunc Get output directory.
	//
	// @rdesc const std::string& | output directory
	const std::string& get_OutputDir(void) const
	{
		return m_outputDir;
	}

	// @doc INTERNAL
	//
	// @mfunc Should the program skip processing API transactions?
	//
	// @rdesc bool | true or false
	bool get_SkipApis(void) const
	{
		return m_skipApis;
	}

	// @doc INTERNAL
	//
	// @mfunc Should the program skip processing batch load modules?
	//
	// @rdesc bool | true or false
	bool get_SkipBatch(void) const
	{
		return m_skipBatch;
	}

	// @doc INTERNAL
	//
	// @mfunc Should the program skip processing online transactions?
	//
	// @rdesc bool | true or false
	bool get_SkipOnline(void) const
	{
		return m_skipOnline;
	}

	// @doc INTERNAL
	//
	// @mfunc Set the preferred count of API remainder modules.
	//
	// @rdesc int | preferred count of API remainder modules.
	void set_ApiRemainderModuleCount(int count)
	{
		if (count < REMAINDERCOUNTMIN || count > REMAINDERCOUNTMAX)
		{
			throw std::logic_error("remainder count is out of range");
		}
		m_apiRemainderModuleCount = count;
	}

	// @doc INTERNAL
	//
	// @mfunc Set API remainder module prefix.
	//
	// @parm const std::string& | str | API remainder module file name prefix.
	void set_ApiRemainderModulePrefix(const std::string& str)
	{
		m_apiRemainderModulePrefix = str;
	}

	// @doc INTERNAL
	//
	// @mfunc Set API transaction grouping file name.
	//
	// @parm const std::string& | filePath | API transaction grouping file name
	void set_ApiTransactionGrouping(const std::string& filePath)
	{
		m_apiTransactionGrouping = filePath;
	}

	// @doc INTERNAL
	//
	// @mfunc Set area concatenation list.
	//
	// @parm const std::vector<std::string>& | areas | area concatenation
	void set_Areas(const std::vector<std::string>& areas)
	{
		m_areas.clear();
		m_areas.insert(m_areas.end(), areas.begin(), areas.end());
	}

	// @doc INTERNAL
	//
	// @mfunc Set component area concatenation list.
	//
	// @parm const std::vector<std::string>& | areas | component area concatenation
	void set_ComponentAreas(const std::vector<std::string>& areas)
	{
		m_componentAreas.clear();
		m_componentAreas.insert(m_componentAreas.end(), areas.begin(), areas.end());
	}

	// @doc INTERNAL
	//
	// @mfunc Set API ICM file name exclusion patterns.
	//
	// @parm const std::vector<std::string>& | patterns | API ICM exclusion patterns
	void set_ExcludeApiIcmPatterns(const std::vector<std::string>& patterns)
	{
		m_excludeApiIcmPatterns = patterns;
	}

	// @doc INTERNAL
	//
	// @mfunc Set batch ICM file name exclusion patterns.
	//
	// @parm const std::vector<std::string>& | patterns | batch ICM file name exclusion patterns.
	void set_ExcludeBatchIcmPatterns(const std::vector<std::string>& patterns)
	{
		m_excludeBatchIcmPatterns = patterns;
	}

	// @doc INTERNAL
	//
	// @mfunc Set PKG file name exclusion patterns.
	//
	// @parm const std::vector<std::string>& | patterns | PKG file name exclusion patterns.
	void set_ExcludePkgPatterns(const std::vector<std::string>& patterns)
	{
		m_excludePkgPatterns = patterns;
	}

	// @doc INTERNAL
	//
	// @mfunc Set server ICM file name exclusion patterns.
	//
	// @parm const std::vector<std::string>& | patterns | server ICM file name exclusion patterns.
	void set_ExcludeServerIcmPatterns(const std::vector<std::string>& patterns)
	{
		m_excludeServerIcmPatterns = patterns;
	}

	// @doc INTERNAL
	//
	// @mfunc Get search-for file name patterns for API load modules ICMs.  The
	// full file name pattern is expected--a base name and an extension.  Wildcards,
	// as defined by the operating system, are acceptable.
	//
	// @parm const std::vector<std::string>& | patterns | API ICM inclusion patterns
	void set_IncludeApiIcmPatterns(const std::vector<std::string>& patterns)
	{
		m_includeApiIcmPatterns = patterns;
	}

	// @doc INTERNAL
	//
	// @mfunc Get search-for file name patterns for batch load modules ICMs.  The
	// full file name pattern is expected--a base name and an extension.  Wildcards,
	// as defined by the operating system, are acceptable.
	//
	// @parm const std::vector<std::string>& | batchIcmPatterns | batch ICM inclusion patterns
	void set_IncludeBatchIcmPatterns(const std::vector<std::string>& batchIcmPatterns)
	{
		m_includeBatchIcmPatterns = batchIcmPatterns;
	}

	// @doc INTERNAL
	//
	// @mfunc Set PKG file name inclusion patterns.
	//
	// @parm const std::vector<std::string>& | patterns | PKG file name inclusion patterns.
	void set_IncludePkgPatterns(const std::vector<std::string>& patterns)
	{
		m_includePkgPatterns = patterns;
	}

	// @doc INTERNAL
	//
	// @mfunc Get search-for file name patterns for online server ICMs.  The
	// full file name pattern is expected--a base name and an extension.  Wildcards,
	// as defined by the operating system, are acceptable.
	//
	// @parm const std::vector<std::string>& | serverIcmPatterns | inclusion server ICM patterns
	void set_IncludeServerIcmPatterns(const std::vector<std::string>& serverIcmPatterns)
	{
		m_includeServerIcmPatterns = serverIcmPatterns;
	}

	// @doc INTERNAL
	//
	// @mfunc Set the preferred count of online remainder modules.
	//
	// @rdesc int | preferred count of online remainder modules.
	void set_OnlineRemainderModuleCount(int count)
	{
		if (count < REMAINDERCOUNTMIN || count > REMAINDERCOUNTMAX)
		{
			throw std::logic_error("remainder count is out of range");
		}
		m_onlineRemainderModuleCount = count;
	}

	// @doc INTERNAL
	//
	// @mfunc Set online remainder module prefix.
	//
	// @parm const std::string& | str | online remainder module file name prefix.
	void set_OnlineRemainderModulePrefix(const std::string& str)
	{
		m_onlineRemainderModulePrefix = str;
	}

	// @doc INTERNAL
	//
	// @mfunc Set online transaction grouping file name.
	//
	// @parm const std::string& | filePath | online transaction grouping file name
	void set_OnlineTransactionGrouping(const std::string& filePath)
	{
		m_onlineTransactionGrouping = filePath;
	}

	// @doc INTERNAL
	//
	// @mfunc Set output directory.
	//
	// @parm const std::string& | directory | output directory
	void set_OutputDir(const std::string& directory)
	{
		m_outputDir = directory;
	}

	// @doc INTERNAL
	//
	// @mfunc Should the program skip processing API transactions?
	//
	// @parm bool | flag | true or false
	void set_SkipApis(bool flag)
	{
		m_skipApis = flag;
	}

	// @doc INTERNAL
	//
	// @mfunc Should the program skip processing batch load modules?
	//
	// @parm bool | flag | true or false
	void set_SkipBatch(bool flag)
	{
		m_skipBatch = flag;
	}

	// @doc INTERNAL
	//
	// @mfunc Should the program skip processing online transactions?
	//
	// @parm bool | flag | true or false
	void set_SkipOnline(bool flag)
	{
		m_skipOnline = flag;
	}

        // @doc INTERNAL
        //
        // @mfunc Should the program skip building a batch shared library?
        //
        // @parm bool | flag | true or false
        void set_SkipBatchSharedLib(bool flag)
        {
                m_skipBatchSharedLib = flag;
        }

        // @doc INTERNAL
        //
        // @mfunc Should the program skip building a batch shared library?
        //
        // @parm bool | flag | true or false
        bool get_SkipBatchSharedLib(void) const
        {
              return m_skipBatchSharedLib; 
        }



	// @doc INTERNAL
	// 
	// @mfunc Assignment operator.
	// 
	// @parm const ProgramOptions & | rhs | <c ProgramOptions> instance to copy.
	// 
	// @rdesc ProgramOptions & | current <c ProgramOptions> instance.
	ProgramOptions& operator =(const ProgramOptions& rhs)
	{
		if (&rhs != this)
		{
			m_apiRemainderModuleCount = rhs.m_apiRemainderModuleCount;
			m_apiRemainderModulePrefix = rhs.m_apiRemainderModulePrefix;
			m_apiTransactionGrouping = rhs.m_apiTransactionGrouping;
			m_areas = rhs.m_areas;
			m_componentAreas = rhs.m_componentAreas;
			m_excludeBatchIcmPatterns = rhs.m_excludeBatchIcmPatterns;
			m_excludeApiIcmPatterns = rhs.m_excludeApiIcmPatterns;
			m_excludePkgPatterns = rhs.m_excludePkgPatterns;
			m_excludeServerIcmPatterns = rhs.m_excludeServerIcmPatterns;
			m_includeApiIcmPatterns = rhs.m_includeApiIcmPatterns;
			m_includeBatchIcmPatterns = rhs.m_includeBatchIcmPatterns;
			m_includePkgPatterns = rhs.m_includePkgPatterns;
			m_includeServerIcmPatterns = rhs.m_includeServerIcmPatterns;
			m_onlineRemainderModuleCount = rhs.m_onlineRemainderModuleCount;
			m_onlineRemainderModulePrefix = rhs.m_onlineRemainderModulePrefix;
			m_onlineTransactionGrouping = rhs.m_onlineTransactionGrouping;
			m_outputDir = rhs.m_outputDir;
			m_skipApis = rhs.m_skipApis;
			m_skipBatch = rhs.m_skipBatch;
			m_skipOnline = rhs.m_skipOnline;
                        m_skipBatchSharedLib = rhs.m_skipBatchSharedLib;
		}
		return *this;
	}

	// @doc INTERNAL
	// 
	// @mfunc equality operator.
	// 
	// @parm const ProgramOptions & | rhs | <c ProgramOptions> instance to check for equality.
	// 
	// @rdesc bool | true if <p rhs> is equal to this <c ProgramOptions> instance.
	// @rdesc bool | false if <p rhs> is not equal to this <c ProgramOptions> instance.
	bool operator ==(const ProgramOptions& rhs) const
	{
		bool	isEqual = (&rhs == this);

		if (!isEqual)
		{
			isEqual = (m_apiRemainderModuleCount == rhs.m_apiRemainderModuleCount)
			&& (m_apiRemainderModulePrefix == rhs.m_apiRemainderModulePrefix)
			&& (m_apiTransactionGrouping == rhs.m_apiTransactionGrouping)
			&& (m_areas == rhs.m_areas)
			&& (m_componentAreas == rhs.m_componentAreas)
			&& (m_excludeBatchIcmPatterns == rhs.m_excludeBatchIcmPatterns)
			&& (m_excludeApiIcmPatterns == rhs.m_excludeApiIcmPatterns)
			&& (m_excludePkgPatterns == rhs.m_excludePkgPatterns)
			&& (m_excludeServerIcmPatterns == rhs.m_excludeServerIcmPatterns)
			&& (m_includeApiIcmPatterns == rhs.m_includeApiIcmPatterns)
			&& (m_includeBatchIcmPatterns == rhs.m_includeBatchIcmPatterns)
			&& (m_includePkgPatterns == rhs.m_includePkgPatterns)
			&& (m_includeServerIcmPatterns == rhs.m_includeServerIcmPatterns)
			&& (m_onlineRemainderModuleCount == rhs.m_onlineRemainderModuleCount)
			&& (m_onlineRemainderModulePrefix == rhs.m_onlineRemainderModulePrefix)
			&& (m_onlineTransactionGrouping == rhs.m_onlineTransactionGrouping)
			&& (m_outputDir == rhs.m_outputDir)
			&& (m_skipApis == rhs.m_skipApis)
			&& (m_skipBatch == rhs.m_skipBatch)
			&& (m_skipOnline == rhs.m_skipOnline)
			;
		}
		return isEqual;
	}

	// @doc INTERNAL
	//
	// @mfunc Verify that a set of options are valid.
	//
	// @parm ostream& | stream | stream to which messages are written
	//
	// @rdesc bool | true if the given options are valid.
	// @rdesc bool | false if the given options are not valid.
	bool Verify(std::ostream& stream)
	{
		std::string			msgPrefix("Option error: ");
		std::ostringstream	output;

		// Only validate API options if we're to process API transactions.
		if (false == this->get_SkipApis())
		{
			if (0 == this->get_IncludeApiIcmPatterns().size())
			{
				output << msgPrefix << "no API ICM file name pattern given." << std::endl;
			}
			if (0 == this->get_ApiTransactionGrouping().length())
			{
				output << msgPrefix << "no API transaction grouping file given." << std::endl;
			}
			else if (false == VerifyFileExists(this->get_ApiTransactionGrouping()))
			{
				output << msgPrefix << "cannot find API transaction grouping file \'" << this->get_ApiTransactionGrouping() << "\'." << std::endl;
			}
			if (0 == this->get_ApiRemainderModulePrefix().length()) { output << msgPrefix << "no API remainder module prefix given." << std::endl; }
		}

		// Only validate Batch options if we're to process batch load modules
		if (false == this->get_SkipBatch())
		{
			if (0 == this->get_IncludeBatchIcmPatterns().size())
			{
				output << msgPrefix << "no batch ICM file name pattern given." << std::endl;
			}
		}

		// Only validate API options if we're to process API transactions.
		if (false == this->get_SkipOnline())
		{
			if (0 == this->get_IncludeServerIcmPatterns().size())
			{
				output << msgPrefix << "no online ICM file name pattern given." << std::endl;
			}
			if (0 == this->get_OnlineTransactionGrouping().length())
			{
				output << msgPrefix << "no online transaction grouping file given." << std::endl;
			}
			else if (false == VerifyFileExists(this->get_ApiTransactionGrouping()))
			{
				output << msgPrefix << "cannot find online transaction grouping file \'" << this->get_ApiTransactionGrouping() << "\'." << std::endl;
			}
			if (0 == this->get_OnlineRemainderModulePrefix().length())
			{
				output << msgPrefix << "no online remainder module prefix given." << std::endl;
			}
		}

		// We need the areas if we're to do APIs, online, or batch
		if (false == this->get_SkipApis() || false == this->get_SkipBatch() || false == this->get_SkipOnline())
		{
			if (0 == this->get_Areas().size()) output << msgPrefix << "no build area concatenation given." << std::endl;
			for (std::vector<std::string>::const_iterator it = this->get_Areas().begin();
				it != this->get_Areas().end();
				++it)
			{
				if (false == VerifyIsBuildArea(*it)) output << "does not seem to be a build area: '" << (*it) << "'." << std::endl;
			}
		}

		// It seems we always need the component area:
		if (0 == this->get_ComponentAreas().size())
		{
			output << msgPrefix << "no component area concatenation given." << std::endl;
		}
		for (std::vector<std::string>::const_iterator it = this->get_ComponentAreas().begin();
			it != this->get_ComponentAreas().end();
			++it)
		{
			if (false == VerifyIsBuildArea(*it)) output << "does not seem to be a build area for components: '" << (*it) << "'." << std::endl;
		}

		std::string	errors = output.str();
		if (0 < errors.length()) stream << errors;

		return (0 == errors.length());
	}

// @access private
private:

	// @doc INTERNAL
	//
	// @mfunc Verify a given directory path is a build area--or, at least, contains the subdirectories
	// in which we have an interest.
	//
	// @parm const std::string& | areaDirectory | build area base directory
	//
	// @rdesc bool | true if <p areaDirectory> seems to be a build area
	// @rdesc bool | false if <p areaDirectory> does not seem to be a build area
	bool VerifyIsBuildArea(const std::string& areaDirectory)
	{
		/*static*/ const char*	subDirectories[] =
		{
			"",
			"extrn/src",
			"srvr/icm",
//BB 07/14/09 - Make this conditional because Unix does not have these directories
#if	defined(TARGET_WIN32) && !defined(SJP_SAYS_EMULATE)
			"extrn/rpt",	
			"coop/batch/icm"
#else 
			"icm"
#endif 

		};

		std::string	directory;
		bool		isArea = (0 != areaDirectory.length());
		struct stat	statBuf;

		for (int i = 0; i < _countof(subDirectories) && isArea; ++i)
		{
			directory = areaDirectory;
			if (0 < strlen(subDirectories[i]))
			{
				if (PATHSEP != directory[directory.length() - 1]) directory.append(&PATHSEP, 1);
				directory.append(subDirectories[i]);
#if	defined(TARGET_WIN32)
				std::string::size_type index = directory.find('/');
				while (std::string::npos != index)
				{
					directory[index] = PATHSEP;
					index = directory.find('/');
				}
#endif
			}

			statBuf.st_mode = 0;
			isArea = (0 == stat(directory.c_str(), &statBuf) && S_IFDIR == (S_IFDIR & statBuf.st_mode));
		}

		return isArea;
	}

	// @doc INTERNAL
	//
	// @mfunc Verify that a file exists.
	//
	// @parm const std::string& | filename | file name to verify
	//
	// @rdesc bool | true if file exists
	// @rdesc bool | false if file does not exist
	bool VerifyFileExists(const std::string& filename)
	{
		bool	exists = false;
		struct stat	statBuf;
	
		statBuf.st_mode = 0;
		exists = (0 == stat(filename.c_str(), &statBuf) && S_IFREG == (S_IFREG & statBuf.st_mode));

		return exists;
	}

// @access public
public:

	// @doc INTERNAL
	//
	// @mfunc destructor
	~ProgramOptions(void)
	{
	}

private:

	int							m_apiRemainderModuleCount;
	std::string					m_apiRemainderModulePrefix;
	std::string					m_apiTransactionGrouping;
	std::vector<std::string>	m_areas;
	std::vector<std::string>	m_componentAreas;
	std::vector<std::string>	m_excludeBatchIcmPatterns;
	std::vector<std::string>	m_excludeApiIcmPatterns;
	std::vector<std::string>	m_excludePkgPatterns;
	std::vector<std::string>	m_excludeServerIcmPatterns;
	std::vector<std::string>	m_includeApiIcmPatterns;
	std::vector<std::string>	m_includeBatchIcmPatterns;
	std::vector<std::string>	m_includePkgPatterns;
	std::vector<std::string>	m_includeServerIcmPatterns;
	int							m_onlineRemainderModuleCount;
	std::string					m_onlineRemainderModulePrefix;
	std::string					m_onlineTransactionGrouping;
	std::string					m_outputDir;
	bool						m_skipApis;
	bool						m_skipBatch;
	bool						m_skipOnline;
        bool                                            m_skipBatchSharedLib;

	static const char	PATHSEP;
	static const int	REMAINDERCOUNTMAX;
	static const int	REMAINDERCOUNTMIN;
};

#if	defined(TARGET_WIN32)
const char	ProgramOptions::PATHSEP = '\\';
#else
const char	ProgramOptions::PATHSEP = '/';
#endif
const int	ProgramOptions::REMAINDERCOUNTMAX = 99;
const int	ProgramOptions::REMAINDERCOUNTMIN = 1;

}	// namespace Mtvsl

#endif	// !defined(_mtvsl_programoptions_h_included_)
