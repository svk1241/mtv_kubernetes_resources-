// ----------------------------------------------------------------------
// MetaVance
// Copyright (C) 2008-2009, Hewlett-Packard Development Company, LP
// All Rights Reserved.
//
// EDS, an HP company
// 225 Grandview Avenue
// Camp Hill, PA  17011 USA
// http://www.eds.com
//
// This source code is the confidential property of EDS, an HP company.
// All proprietary rights, including but not limited to any trade secret,
// copyright, patent or trademark rights in and to this source code are
// the property of EDS.  This source code is not to be used, disclosed or
// reproduced in any form without the express written consent of EDS.
//
// ----------------------------------------------------------------------
#if	!defined(_mtvsl_loadmodule_h_included_)
#define	_mtvsl_loadmodule_h_included_

// Needs string

#include "SymbolTable.h"

namespace Mtvsl {

// @doc INTERNAL
//
// @class A CA Gen load module.
class LoadModule
{
// @access public
public:

	// @doc INTERNAL
	//
	// @mfunc Default constructor
	LoadModule(void)
	{
	}

	// @doc INTERNAL
	//
	// @mfunc Construct with a load module name.
	//
	// @parm const std::string& | name | load module name.
	LoadModule(const std::string& name)
		: m_name(name)
	{
	}

	// @doc INTERNAL
	//
	// @mfunc Construct with a load module name.
	//
	// @parm const char* | name | load module name
	LoadModule(const char* name)
		: m_name(name)
	{
	}

	// @doc INTERNAL
	//
	// @mfunc Construct a copy.
	//
	// @parm const <c LoadModule>& | other | <c LoadModule> instance to copy
	LoadModule(const LoadModule& other)
	{
		operator =(other);
	}

	// @doc INTERNAL
	//
	// @mfunc Add an action block to this <c LoadModule>.  This
	// method does not check for duplicate names.
	//
	// @parm const std::string& | actionBlock | action block name
	void add_ActionBlock(const std::string& actionBlock)
	{
		if (0 != actionBlock.length()) m_actionBlocks.Add(actionBlock);
	}

	// @doc INTERNAL
	//
	// @mfunc Add a set of action block names to this <c LoadModule>.
	// This method does not check for duplicate names.
	//
	// @parm const std::vector<std::string>& | actionBlocks | action
	// block names to add.
	void add_ActionBlocks(const std::vector<std::string>& actionBlocks)
	{
		for (std::vector<std::string>::const_iterator it = actionBlocks.begin();
			it != actionBlocks.end();
			++it)
		{
			if (0 != it->length()) m_actionBlocks.Add(*it);
		}
	}

	// @doc INTERNAL
	//
	// @mfunc Add a set of action block names to this <c LoadModule>.  Each
	// given name is checked for duplication such that a name is added 0-to-1
	// times.
	//
	// @parm const std::vector<std::string>& | actionBlocks | action
	// block names to add.
	void add_ActionBlocksUnique(const std::vector<std::string>& actionBlocks)
	{
		for (std::vector<std::string>::const_iterator it = actionBlocks.begin();
			it != actionBlocks.end();
			++it)
		{
			if (0 != it->length() && !m_actionBlocks.Contains(*it)) m_actionBlocks.Add(*it);
		}
	}

	// @doc INTERNAL
	//
	// @mfunc Get the action block names previously added to
	// this <c LoadModule>.
	//
	// @rdesc const SymbolTable | action block names
	const SymbolTable& get_ActionBlocks(void) const
	{
		return m_actionBlocks;
	}

	// @doc INTERNAL
	//
	// @mfunc Get the name of this <c LoadModule>.
	//
	// @rdesc const std::string& | load module name
	const std::string& get_Name(void) const
	{
		return m_name;
	}

	// @doc INTERNAL
	//
	// @mfunc Set the name of this <c LoadModule>.
	//
	// @parm const std::string& | name | load module name
	void set_Name(const std::string& name)
	{
		m_name = name;
	}

	// @doc INTERNAL
	// 
	// @mfunc Assignment operator.
	// 
	// @parm const <c LoadModule> | rhs | <c LoadModule> to copy
	// 
	// @rdesc <c LoadModule> | current <c LoadModule> instance.
	LoadModule& operator =(const LoadModule& rhs)
	{
		if (&rhs != this)
		{
			m_actionBlocks = rhs.m_actionBlocks;
			m_name = rhs.m_name;
		}
		return *this;
	}

	// @doc INTERNAL
	//
	// @mfunc Destructor
	~LoadModule(void)
	{
	}

private:

	SymbolTable	m_actionBlocks;
	std::string	m_name;
};

}	// namespace Mtvsl

#endif	// !defined(_mtvsl_loadmodule_h_included_)
