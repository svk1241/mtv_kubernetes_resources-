// ----------------------------------------------------------------------
// MetaVance
// Copyright (C) 2008-2009, Hewlett-Packard Development Company, LP
// All Rights Reserved.
//
// EDS, an HP company
// 225 Grandview Avenue
// Camp Hill, PA  17011 USA
// http://www.eds.com
//
// This source code is the confidential property of EDS, an HP company.
// All proprietary rights, including but not limited to any trade secret,
// copyright, patent or trademark rights in and to this source code are
// the property of EDS.  This source code is not to be used, disclosed or
// reproduced in any form without the express written consent of EDS.
//
// ----------------------------------------------------------------------
#if	!defined(_mtvsl_tuxedoloadmodule_h_included_)
#define	_mtvsl_tuxedoloadmodule_h_included_

// Needs algorithm, string, and vector.

#include "LoadModule.h"

namespace Mtvsl {

class TuxedoLoadModule;

typedef std::vector<TuxedoLoadModule>	TuxedoLoadModules;

// @doc INTERNAL
//
// @class A <c TuxedoLoadModule> instance is a <c LoadModule> instance plus
// a set of transaction codes.
//
// @base public | <c LoadModule>
class TuxedoLoadModule
	: public LoadModule
{
// @access public
public:

	// @doc INTERNAL
	//
	// @mfunc Default constructor.
	TuxedoLoadModule(void)
	{
	}

	// @doc INTERNAL
	// 
	// @mfunc Copy constructor.
	// 
	// @parm const TuxedoLoadModule & | other | <c TuxedoLoadModule> to copy.
	TuxedoLoadModule(const TuxedoLoadModule& other)
	{
		operator =(other);
	}

	// @doc INTERNAL
	// 
	// @mfunc Add a transaction code to this <c TuxedoLoadModule> instance.  Empty
	// transaction codes and duplicates are ignored.
	// 
	// @parm const std::string & | transaction | transaction code to add.
	void add_Transaction(const std::string& transaction)
	{
		if (0 < transaction.length())
		{
			if (!m_transactions.Contains(transaction)) m_transactions.Add(transaction);
		}
	}

	// @doc INTERNAL
	// 
	// @mfunc Does this <c TuxedoLoadModule> instance define the given
	// transaction code?
	// 
	// @parm const std::string & | transaction | transaction code to find.
	//
	// @rdesc bool | true if <p transaction> exists.
	// @rdesc bool | false if <p transaction> does not exist.
	bool get_HasTransaction(const std::string& transaction)
	{
		return m_transactions.Contains(transaction);
	}

	// @doc INTERNAL
	// 
	// @mfunc Get the transactions serviced by this load module as
	// an array of strings.
	// 
	// 
	// @rdesc std::vector<std::string> | transaction array
	std::vector<std::string> get_Transactions(void) const
	{
		return m_transactions.ToArray();
	}

private:

	//static bool StringLess(const std::string& lhs, const std::string& rhs)
	//{
	//	return (lhs < rhs);
	//}

public:

	// @doc INTERNAL
	//
	// @cmember Parse the given stream into <c TuxedoLoadModule> instances.
	static TuxedoLoadModules Parse(std::istream& stream);

	// @doc INTERNAL
	// 
	// @mfunc Assignment operator.
	// 
	// @parm const TuxedoLoadModule & | rhs | <c TuxedoLoadModule> instance to copy.
	// 
	// @rdesc TuxedoLoadModule& | the current <c TuxedoLoadModule> instance. 
	TuxedoLoadModule& operator =(const TuxedoLoadModule& rhs)
	{
		LoadModule::operator =(rhs);
		if (&rhs != this)
		{
			m_transactions = rhs.m_transactions;
		}

		return *this;
	}

	// @doc INTERNAL
	// 
	// @mfunc Remove the specified transaction from this load module.
	// 
	// @parm const std::string& | transaction | transaction to remove.
	void remove_Transaction(const std::string& transaction)
	{
		m_transactions.Remove(transaction);
	}

	// @doc INTERNAL
	//
	// @mfunc Destructor.
	~TuxedoLoadModule(void)
	{
	}

private:

	SymbolTable	m_transactions;
};

// @doc INTERNAL
//
// @mfunc Parse the given stream into <c TuxedoLoadModule> instances.  Throws
// std::logic_error if the <p stream> is not parsable.
// 
// @parm std::istream & | stream | stream to parse
// 
// @rdesc TuxedoLoadModules | parsed <c TuxedoLoadModule> instances.  The
// collection may be empty.
TuxedoLoadModules TuxedoLoadModule::Parse(std::istream& stream)
{
	typedef std::map<std::string, std::string>		TxnMapType;
	typedef std::map<std::string, TuxedoLoadModule>	ModuleMapType;

	TuxedoLoadModule	dummyTuxedoModule;
	std::string			loadModuleName;
	ModuleMapType		moduleMap;
	std::string			tranCode;
	TxnMapType			txnMap;

	while (!stream.eof())
	{
		// Skip leading whitespace
		std::ws(stream);
		if (stream.eof()) continue;

		// The transaction code is first.
		if (0 == tranCode.length())
		{
			stream >> tranCode;
		}
		else if (0 == loadModuleName.length())
		{
			stream >> loadModuleName;
		}

		// Do we have both?
		if (0 < loadModuleName.length() && 0 < tranCode.length())
		{
			if (txnMap.end() == txnMap.find(tranCode))
			{
				ModuleMapType::value_type	toInsert(loadModuleName, dummyTuxedoModule);

				// Insert or reference a map pair.
				std::pair<ModuleMapType::iterator, bool> foundAt
					= moduleMap.insert(toInsert);

				// If we just inserted a load module, ensure it is named.
				if (foundAt.second) foundAt.first->second.set_Name(loadModuleName);

				// Add the transaction to the current load module.
				foundAt.first->second.add_Transaction(tranCode);

				// Remember this transaction
				TxnMapType::value_type	sawTxn(tranCode, loadModuleName);
				txnMap.insert(sawTxn);

		}	// Start all over.
				loadModuleName.clear();
				tranCode.clear();
			
		}
	}

	// Transform the map into a vector
	TuxedoLoadModules	modules;
	for (ModuleMapType::const_iterator it = moduleMap.begin(); it != moduleMap.end(); ++it)
	{
		modules.push_back(it->second);
	}

	return modules;
}

}	// namespace Mtvsl

#endif	// !defined(_mtvsl_tuxedoloadmodule_h_included_)
