// ----------------------------------------------------------------------
// MetaVance
// Copyright (C) 2008-2009, Hewlett-Packard Development Company, LP
// All Rights Reserved.
//
// EDS, an HP company
// 225 Grandview Avenue
// Camp Hill, PA  17011 USA
// http://www.eds.com
//
// This source code is the confidential property of EDS, an HP company.
// All proprietary rights, including but not limited to any trade secret,
// copyright, patent or trademark rights in and to this source code are
// the property of EDS.  This source code is not to be used, disclosed or
// reproduced in any form without the express written consent of EDS.
//
// ----------------------------------------------------------------------
#if	!defined(_mtvsl_program_h_included_)
#define	_mtvsl_program_h_included_

// Needs climits, fstream, iostream, map, string, and vector

#include "Icm.h"
#include "Pkg.h"
#include "ProgramOptions.h"
#include "SymbolTable.h"
#include "TuxedoLoadModule.h"

namespace Mtvsl {

// @doc INTERNAL
//
// @class The class is the main program for creating UNIX shared library definitions
// from CA Gen Installation Control Modules (ICMs).
//
class Program
{
// @access private
private:

	// No copy construction or assignment
	Program(const Program&);
	Program& operator =(const Program&);

// @access protected
protected:

	class OnFileFoundDelegate
	{
		// No copy construction or assignment
		OnFileFoundDelegate(const OnFileFoundDelegate&);
		OnFileFoundDelegate& operator =(const OnFileFoundDelegate&);
	public:
		OnFileFoundDelegate(void)
		{
		}

		virtual void Invoke(const std::string& fullPath, const char* baseFilename) = 0;

		~OnFileFoundDelegate(void)
		{
		}
	};

	class OnIcmFound
		: public OnFileFoundDelegate
	{
		// No copy construction or assignment
		OnIcmFound(const OnIcmFound&);
		OnIcmFound& operator =(const OnIcmFound&);

		std::map<std::string, Icm>& m_allServers;
		std::map<std::string, Icm>& m_allLibraries;
	public:
		OnIcmFound(std::map<std::string, Icm>& allServers, std::map<std::string, Icm>& allLibraries)
			: m_allLibraries(allLibraries)
			, m_allServers(allServers)
		{
		}

		virtual void Invoke(const std::string& fullPath, const char* baseFileName)
		{
                    try
                    {
			// Reference unused parameters
			((void)baseFileName);

			// Pull the ICM into an object instance
			std::ifstream	stream;
			stream.open(fullPath.c_str());
			Icm	icm = Icm::Parse(stream);
			stream.close();

			// Categorize the appropriately:
			std::map<std::string, Icm>*	mapToSearch = NULL;
			if (icm.get_IsCascade() || icm.get_IsOpslib())
			{
				mapToSearch = &m_allLibraries;
			}
			else /*if (icm.get_IsServer())*/
			{
				// Must be a load module
				mapToSearch = &m_allServers;
			}

			/*if (NULL == mapToSearch)
			{
				// TODO: emit warning message 
			}
			else*/
			{
				// Have we seen this library or server before?
				std::map<std::string, Icm>::iterator haveIt =
					mapToSearch->find(icm.get_LoadModule());
				if (haveIt == mapToSearch->end())
				{
					// We've not yet seen this ICM so retain it:
					std::pair<std::string, Icm> value;
					value.first = icm.get_LoadModule();
					value.second = icm;
					mapToSearch->insert(value);
				}
			}
                    }
                    catch (std::exception& ex)
                    {
                       std::cout << "Exception while processing: " << fullPath << std::endl
                        << ex.what() << std::endl;
                        
                    }

		}
	};

	class OnPkgFound
		: public OnFileFoundDelegate
	{
		// No copy construction or assignment
		OnPkgFound(const OnPkgFound&);
		OnPkgFound& operator =(const OnPkgFound&);

		std::map<std::string, Pkg>& m_all;

	public:
		OnPkgFound(std::map<std::string, Pkg>& all)
			: m_all(all)
		{
		}

		virtual void Invoke(const std::string& fullPath, const char* baseFileName)
		{
			// Pull the component into an object instance
			std::ifstream	stream;
			stream.open(fullPath.c_str());
			Pkg	pkg = Pkg::Parse(stream);
			stream.close();
			pkg.set_LibraryName(baseFileName);

			// Have we already encountered this component library instance?
			std::map<std::string, Pkg>::iterator haveIt =
				m_all.find(pkg.get_LibraryName());
			if (haveIt == m_all.end())
			{
				// This is the first time we've seen this component
				// library.  Keep it around.
				std::pair<std::string, Pkg> value;
				value.first = pkg.get_LibraryName();
				value.second = pkg;
				m_all.insert(value);
			}
		}
	};


// @access public
public:

	// @mfunc | Default constructor 
	Program(void)
#if defined(TARGET_WIN32)
		: m_chSep('\\')
#else
		: m_chSep('/')
#endif
	{
	}

// @access protected
protected:

	// These are protected so our test class can test them . . .
	void DoEmitDependencyList(const std::string& sharedLibraryName, const Mtvsl::SymbolTable& symbols);
	void EmitLoadModuleDependencyList(const LoadModule& loadModule, const SymbolTable& sharedLibrary, const std::string& libraryName);
	void EmitMksrvrMgrList(const TuxedoLoadModule& loadModule, std::map<std::string, Icm>& allIcms);
	Mtvsl::SymbolTable DoFindCommonActionBlocks(std::vector<const LoadModule*>& modules, int referencesNeededForShare);
	void DoRepackage(const std::map<std::string, Icm>& caGenModules,
						  std::vector<TuxedoLoadModule>& modules,
						  const std::string& remainderModulePrefix,
						  int remainderModules);


	void GatherFromFiles(size_t numSubDirectories,
		const char* subDirectories[],
		const std::vector<std::string>& directories,
		const std::vector<std::string>& includePatterns,
		const std::vector<std::string>& excludePatterns,
		OnFileFoundDelegate& delegateObj);

         bool IsModuleInPackageFile(const std::string& moduleName);


// @access public
public:

	// @doc INTERNAL
	//
	// @mfunc | Execute the main line by examining ICMs and suggesting shared library composition.
	//
	// @parm const ProgramOptions& | options | a <c ProgramOptions> instance to control execution
	void Run(const ProgramOptions& options)
	{
		m_outputDir = options.get_OutputDir();


		if (false == options.get_SkipApis()
			|| false == options.get_SkipBatch()
			|| false == options.get_SkipOnline())
		{
			std::cout << "Gathering components (PKG files) . . ." << std::endl;
			{
				const char*	paths[] = { "extrn", "src" };
				OnPkgFound	pkgDelegate(m_allComponents);
                            
				GatherFromFiles(_countof(paths),
					paths,
					options.get_ComponentAreas(),
					options.get_IncludePkgPatterns(),
					options.get_ExcludePkgPatterns(),
					pkgDelegate);
			}
		}

		if (false == options.get_SkipApis())
		{
			std::cout << "Gathering API ICMs. . ." << std::endl;

			const char*	paths[] = { "srvr", "icm" };
			OnIcmFound	icmDelegate(m_allApis, m_allLibraries);
			GatherFromFiles(_countof(paths),
				paths,
				options.get_Areas(),
				options.get_IncludeApiIcmPatterns(),
				options.get_ExcludeApiIcmPatterns(),
				icmDelegate);

			std::cout << "Gathering predefined API Tuxedo load modules. . ." << std::endl;
			{
				std::ifstream theStream;
				theStream.open(options.get_ApiTransactionGrouping().c_str(), std::ios_base::in);

				m_apiLoadModules = TuxedoLoadModule::Parse(theStream);
				theStream.close();
			}

			std::cout << "Repackaging APIs for Tuxedo. . ." << std::endl;
			DoRepackage(m_allApis, m_apiLoadModules, options.get_ApiRemainderModulePrefix(), options.get_ApiRemainderModuleCount());

			std::cout << "Finding action blocks for a shared library for APIs. . ." << std::endl;
			{
				// Data structure for common action block find:
				std::vector<const LoadModule*>	modules;
				modules.reserve(m_apiLoadModules.size());
				for (TuxedoLoadModules::const_iterator it = m_apiLoadModules.begin();
					it != m_apiLoadModules.end();
					++it)
				{
					const LoadModule*	ptr = &(*it);
					modules.push_back(ptr);
				}

				// Create API shared library definition and modify the
				// Tuxedo load module definitions.
				m_apiSharedLibrary = DoFindCommonActionBlocks(modules, 3);
			}
		}

		if (false == options.get_SkipOnline())
		{
			std::cout << "Gathering server ICMs. . ." << std::endl;

			const char*	paths[] = { "srvr", "icm" };
			OnIcmFound	icmDelegate(m_allServers, m_allLibraries);
			GatherFromFiles(_countof(paths),
				paths,
				options.get_Areas(),
				options.get_IncludeServerIcmPatterns(),
				options.get_ExcludeServerIcmPatterns(),
				icmDelegate);

			std::cout << "Gathering predefined online Tuxedo load modules. . ." << std::endl;
			{
				std::ifstream theStream;
				theStream.open(options.get_OnlineTransactionGrouping().c_str(), std::ios_base::in);

				m_onlineLoadModules = TuxedoLoadModule::Parse(theStream);
				theStream.close();
			}

			std::cout << "Repackaging servers for Tuxedo. . ." << std::endl;
			DoRepackage(m_allServers, m_onlineLoadModules, options.get_OnlineRemainderModulePrefix(), options.get_OnlineRemainderModuleCount());

			std::cout << "Finding action blocks for a shared library for servers. . ." << std::endl;
			{
				// Data structure for common action block find:
				std::vector<const LoadModule*>	modules;
				modules.reserve(m_onlineLoadModules.size());
				for (TuxedoLoadModules::const_iterator it = m_onlineLoadModules.begin();
					it != m_onlineLoadModules.end();
					++it)
				{
					const LoadModule*	ptr = &(*it);
					modules.push_back(ptr);
				}

				// Create online shared library definition and modify the
				// Tuxedo load module definitions.
				m_onlineSharedLibrary = DoFindCommonActionBlocks(modules, 3);
			}
		}

		if (false == options.get_SkipBatch())
		{
			std::cout << "Gathering batch ICMs. . ." << std::endl;
			{
//BB 07/14/09 - Unix has a different directory structure
#if defined(TARGET_WIN32) && !defined(SJP_SAYS_EMULATE)
				const char*	paths[] = { "coop", "batch", "icm" };
#else 
				const char*	paths[] = { "icm" };
#endif 
				OnIcmFound	icmDelegate(m_allBatch, m_allLibraries);

				GatherFromFiles(_countof(paths),
					paths,
					options.get_Areas(),
					options.get_IncludeBatchIcmPatterns(),
					options.get_ExcludeBatchIcmPatterns(),
					icmDelegate);


				std::cout << "Finding action blocks for a shared library for batch programs. . ." << std::endl;
				{
					std::vector<LoadModule>	batch;
					batch.reserve(m_allBatch.size());
					for (std::map<std::string, Icm>::const_iterator it = m_allBatch.begin();
						it != m_allBatch.end();
						++it)
					{
						LoadModule	lm;
						lm.set_Name(it->second.get_LoadModule());
						lm.add_ActionBlocks(it->second.get_ActionBlocks());
						lm.add_ActionBlocks(it->second.get_Externals());
						batch.push_back(lm);
					}

					// Data structure for common action block find:
					std::vector<const LoadModule*>	modules;
					modules.reserve(batch.size());
					for (std::vector<LoadModule>::const_iterator it = batch.begin();
						it != batch.end();
						++it)
					{
						const LoadModule*	ptr = &(*it);
						modules.push_back(ptr);
					}

					// Create batch shared library definition and modify the
					// batch load module definitions.
                                         if (false == options.get_SkipBatchSharedLib())
                                         {
					   m_batchSharedLibrary = DoFindCommonActionBlocks(modules, int(modules.size() / 10));
                                         }
				}
			}
		}

		// Create pseudo makefile dependency lists
		if (false == options.get_SkipApis())
		{
			std::cout << "Emitting API dependency lists . . ." << std::endl;
			std::string	libraryName("libMVPPAPI");
			DoEmitDependencyList(libraryName, m_apiSharedLibrary);
			for (std::vector<TuxedoLoadModule>::const_iterator it = m_apiLoadModules.begin();
				it != m_apiLoadModules.end();
				++it)
			{
				EmitLoadModuleDependencyList(*it, m_apiSharedLibrary, libraryName);
				EmitMksrvrMgrList(*it, this->m_allApis);
			}
		}

		if (false == options.get_SkipOnline())
		{
			std::cout << "Emitting online dependency lists . . ." << std::endl;
			std::string	libraryName("libMVPPONLN");
			DoEmitDependencyList(libraryName, m_onlineSharedLibrary);
			for (std::vector<TuxedoLoadModule>::const_iterator it = m_onlineLoadModules.begin();
				it != m_onlineLoadModules.end();
				++it)
			{
				EmitLoadModuleDependencyList(*it, m_onlineSharedLibrary, libraryName);
				EmitMksrvrMgrList(*it, this->m_allServers);
			}
		}

		if (false == options.get_SkipBatch())
		{
			std::cout << "Emitting batch dependency lists . . ." << std::endl;
			std::string	libraryName("libMVPPBTCH");
			DoEmitDependencyList(libraryName, m_batchSharedLibrary);
			for (std::map<std::string, Icm>::const_iterator it = m_allBatch.begin();
				it != m_allBatch.end();
				++it)
			{
				LoadModule	thisLoadModule;
				thisLoadModule.set_Name(it->second.get_LoadModule());
				thisLoadModule.add_ActionBlocksUnique(it->second.get_ActionBlocks());
				EmitLoadModuleDependencyList(thisLoadModule, m_batchSharedLibrary, libraryName);
			}
		}
	}

	// @doc INTERNAL
	//
	// @mfunc | Destructor
	~Program(void)
	{
	}

protected:

	std::map<std::string, Icm>		m_allApis;
	std::map<std::string, Icm>		m_allBatch;
	std::map<std::string, Pkg>		m_allComponents;
	std::map<std::string, Icm>		m_allLibraries;
	std::map<std::string, Icm>		m_allServers;
	std::vector<TuxedoLoadModule>	m_apiLoadModules;
	SymbolTable						m_apiSharedLibrary;
	SymbolTable						m_batchSharedLibrary;
	char							m_chSep;
	std::vector<TuxedoLoadModule>	m_onlineLoadModules;
	SymbolTable						m_onlineSharedLibrary;
	std::string						m_outputDir;
};

// @doc INTERNAL
// 
// @mfunc | Emit a <c SymbolTable> as a pseudo-makefile dependency list.
// 
// @parm | sharedLibraryName | base name of file which will be <sharedLibraryName.dep> 
// @parm | symbols | a <c SymbolTable> to emit
void Program::DoEmitDependencyList(const std::string& sharedLibraryName, const SymbolTable& symbols)
{
	// Order the symbols ascending.
	std::vector<std::string>	sym = symbols.ToArray();
	std::sort(sym.begin(), sym.end());

	// Assume the library name has no extenstion; we're really
	// just emitting a dependency list.
	std::string	dependencyFileName(m_outputDir);
	if (0 < dependencyFileName.length() && m_chSep != dependencyFileName[dependencyFileName.length() - 1])
	{
		dependencyFileName.append(&m_chSep, 1);
	}
	dependencyFileName.append(sharedLibraryName);
	dependencyFileName.append(".dep");
	std::ofstream	fout(dependencyFileName.c_str());

	//BB 08/18/09 - On Unix we just want a simple list of object names in the
	//dependency list
#if	defined(TARGET_WIN32)
	// A pseudo make file: a target followed by dependencies.
	fout << sharedLibraryName << "::";
#endif

	bool firstTime = true;

	for (std::vector<std::string>::const_iterator it = sym.begin(); it != sym.end(); ++it)
	{
                //If this is in a user exit package file we don't want it in one of the shared libs
                if(IsModuleInPackageFile(*it) == false)
                {
		   //BB 08/18/09 - On Unix we just want a simple list of object names in the
		   //dependency list
#if	defined(TARGET_WIN32)
		   // Contine the previous line and emit the symbol name.
		   fout << " \\" << std::endl << (*it);
#else
		   if ( false == firstTime )
		   {
			 // Contine the previous line and emit the symbol name.
			fout <<  std::endl << (*it);
		   }
		   else
		   {
			// Contine the previous line and emit the symbol name.
			fout <<  (*it);
			firstTime = false;
		   }
#endif
              }  //if

	}  //for
	fout << std::endl;
	fout.close();
}

// @doc INTERNAL
// 
// @mfunc | Emit a <c LoadModule> as a pseudo-makefile dependency list.
// 
// @parm | loadModule | the load module to be emitted; the file name wil be loadModule.get_Name() + ".dep"
// @parm | sharedLibrary | a <c SymbolTable> containing shared library names
// @parm | libraryName | the name of the library described by <p sharedLibrary>
void Program::EmitLoadModuleDependencyList(const LoadModule& loadModule, const SymbolTable& sharedLibrary, const std::string& libraryName)
{
	// Create an output stream with loadModule.get_Name() as the base name.  I.e. LM01.dep, or API01.dep,
	// or HR50X00.dep.
	std::string		fileName(m_outputDir);
	if (0 < fileName.length() && m_chSep != fileName[fileName.length() - 1])
	{
		fileName.append(&m_chSep, 1);
	}
	fileName.append(loadModule.get_Name());
	fileName.append(".dep");
	std::ofstream	fout;
	fout.open(fileName.c_str());

//BB 08/18/09 - On Unix we just want a simple list of object names in the
//dependency list
#if	defined(TARGET_WIN32)
	fout << loadModule.get_Name() << "::";
#endif

	// For each symbol in loadModule.get_actionBlocks()
	//	if the current symbol is in the shared library
	//		remember we need to depend on the shared library
	//	else
	//		Put the symbol to the output stream
	//	end if
	// end for-each
	bool						dependsOnSharedLibrary = false;
	std::vector<std::string>	cabs = loadModule.get_ActionBlocks().ToArray();
	bool firstTime = true;

	for (std::vector<std::string>::const_iterator it = cabs.begin(); it != cabs.end(); ++it)
	{
		if (sharedLibrary.Contains(*it) || IsModuleInPackageFile(*it))
		{
			dependsOnSharedLibrary = true;
		}
		else
		{
//BB 08/18/09 - On Unix we just want a simple list of object names in the
//dependency list
#if	defined(TARGET_WIN32)
			// Contine the previous line and emit the symbol name.
			fout << " \\" << std::endl << (*it);
#else
			if ( false == firstTime )	
			{
				// Contine the previous line and emit the symbol name.
				fout << std::endl << (*it);
			}
			else
			{
				// Contine the previous line and emit the symbol name.
				fout <<  (*it);
				firstTime = false;
			}
#endif

		}
	}

	// if this load module depends on the shared library
	//	emit the shared library name as a dependency
	// end if
#if	defined(TARGET_WIN32)
	if (dependsOnSharedLibrary)
	{
		fout << " \\" << std::endl << libraryName;
	}
#endif

	fout << std::endl;
	fout.close();
}

bool Program::IsModuleInPackageFile(const std::string& moduleName)
{

   for (std::map<std::string, Pkg>::const_iterator it = m_allComponents.begin();
        it != m_allComponents.end();
        ++it)
   {
       const SymbolTable& actionBlocks = it->second.get_ActionBlocks();
       if(actionBlocks.Contains(moduleName))
       {
           return true;
       }

       const SymbolTable& externals = it->second.get_Externals();
       if(externals.Contains(moduleName))
       {
           return true;
       }
   }

  return false;
}

// @doc INTERNAL
// 
// @cmember Emit a list of load module names, procedure step names, and transaction codes
// suitable for consumption by MksrvrMgr.
// 
// @parm const TuxedoLoadModule& | loadModule | load module
// @parm std::map<std::string, Icm>& | allIcms | set of <c Icm> instances of which the <p loadModule>
// is a subset.
void Program::EmitMksrvrMgrList(const TuxedoLoadModule& loadModule, std::map<std::string, Icm>& allIcms)
{
	std::string		fileName(m_outputDir);
	if (0 < fileName.length() && m_chSep != fileName[fileName.length() - 1])
	{
		fileName.append(&m_chSep, 1);
	}
	fileName.append(loadModule.get_Name());
	fileName.append(".trans");
	std::ofstream	fout;
	fout.open(fileName.c_str());

	std::vector<std::string>	txns = loadModule.get_Transactions();
	for (std::vector<std::string>::const_iterator it = txns.begin();
		it != txns.end();
		++it)
	{
		for (std::map<std::string, Icm>::const_iterator itI = allIcms.begin();
			itI != allIcms.end();
			++itI)
		{
			if (itI->second.has_Transaction(*it))
			{
				itI->second.emitLoadModulePstepTran(fout);
				break;
			}
		}
	}
}

// @doc INTERNAL
// 
// @mfunc | Given a set of <c LoadModule> objects each containing a set of action blocks in a
// <c SymbolTable>, create a <c SymbolTable> where each symbol (action block) is used by at
// least <p referencesNeededForShare> load modules.
// 
// @parm | modules | a vector of <c LoadModule> objects.
// @parm | referencesNeededForShare | the number of references needed for an action block to
// be considered common between load modules.
// 
// @rdesc a <c SymbolTable> containing common action blocks.  The table may be empty.
SymbolTable Program::DoFindCommonActionBlocks(std::vector<const LoadModule*>& modules, int referencesNeededForShare)
{
	SymbolTable					sharedLibrary;
	std::vector<std::string>	thisLmActionBlocks;

	// Ensure the reference count is positive:
	referencesNeededForShare &= INT_MAX;

	// Determine what the load modules have in common.  Record the results
	// in the shared library.
	for (std::vector<const LoadModule*>::size_type i = 0; i < modules.size(); ++i)
	{
		thisLmActionBlocks = modules[i]->get_ActionBlocks().ToArray();
		for (std::vector<std::string>::size_type j = 0; j < thisLmActionBlocks.size(); ++j)
		{
			// Is this action block in the shared library?
			if (sharedLibrary.Contains(thisLmActionBlocks[j]))
			{
				// Already shared!
				continue;
			}
			else
			{
				// Is this action block used by other load modules?
				int	references = 1;
				for (std::vector<const LoadModule*>::size_type k = 0; k < modules.size(); ++k)
				{
					// Ignore the current load module.
					if (k == i) continue;

					if (modules[k]->get_ActionBlocks().Contains(thisLmActionBlocks[j]))
					{
						++references;
					}
				}

				if (referencesNeededForShare <= references)
				{
					// This action block is to be placed in the shared library
					sharedLibrary.Add(thisLmActionBlocks[j]);
				}
			}
		}
	}

	return sharedLibrary;
}

// @doc INTERNAL
//
// @mfunc | Repackage transactions found in generated CA Gen server ICMs
// into Tuxedo load modules.  A.K.A. make "superservers".
void Program::DoRepackage(const std::map<std::string, Icm>& caGenModules,
						  std::vector<TuxedoLoadModule>& modules,
						  const std::string& remainderModulePrefix,
						  int remainderModuleMax)
{
	// 1) Ensure all transactions within the same ICM are placed
	// in the same Tuxedo load module.
	//
	// 2) If the transactions in the ICM are not packed in a Tuxedo load
	// module, add those transactions to a remainder module.
	TuxedoLoadModules	remainderModules;

	for (int i = 0; i < remainderModuleMax; ++i)
	{
		char	name[32];
		sprintf_s(name, _countof(name), "%s%02d",
			remainderModulePrefix.c_str(),
			i + 1);

		TuxedoLoadModule	module;
		module.set_Name(name);
		remainderModules.push_back(module);
	}

	std::map<std::string, TuxedoLoadModule*>		assignedTxns;
	std::pair<std::string, TuxedoLoadModule*>		assignedTxnValue;
	for (std::vector<TuxedoLoadModule>::iterator itM = modules.begin();
		itM != modules.end();
		++itM)
	{
		std::vector<std::string>	transactions = itM->get_Transactions();
		for (std::vector<std::string>::const_iterator itT = transactions.begin();
			itT != transactions.end();
			++itT)
		{
			assignedTxnValue.first = *itT;
			assignedTxnValue.second = &(*itM);
			assignedTxns.insert(assignedTxnValue);
		}
	}

	TuxedoLoadModules::size_type					currentRemainderModule = 0;
	for (std::map<std::string, Icm>::const_iterator it = caGenModules.begin();
		it != caGenModules.end();
		++it)
	{
		// Are the transactions in this icm already in a Tuxedo load module?
		const Icm&											theIcm = it->second;
		std::vector<std::string>							transactions = theIcm.get_Transactions();
		TuxedoLoadModule*									loadModuleForTxn = NULL;
		std::map<std::string, TuxedoLoadModule*>::iterator	packagedTxn;
		for (std::vector<std::string>::const_iterator itT = transactions.begin();
			itT != transactions.end();
			++itT)
		{
			packagedTxn = assignedTxns.find(*itT);
			if (assignedTxns.end() == packagedTxn)
			{
				// This transaction is not assigned; put it into a remainder module
				loadModuleForTxn = &remainderModules[currentRemainderModule++];
				if (remainderModuleMax <= currentRemainderModule) currentRemainderModule = 0;
			}
			else
			{
				// This transaction is already in a load module:
				loadModuleForTxn = packagedTxn->second;
				// The ICM may contain more than one transaction.  All those transactions
				// must be in the same Tuxedo load module so stop looking . . .
				break;
			}
		}

		// The load module contains all the transactions defined in this ICM:
		for (std::vector<std::string>::const_iterator itT = transactions.begin();
			itT != transactions.end();
			++itT)
		{
			loadModuleForTxn->add_Transaction(*itT);

			// Do we need to reassign the load module?
			packagedTxn = assignedTxns.find(*itT);
			if (assignedTxns.end() != packagedTxn)
			{
				if (packagedTxn->second->get_Name() != loadModuleForTxn->get_Name())
				{
					packagedTxn->second->remove_Transaction(*itT);
				}
			}

			// Remember this transaction is already assigned (this will redo the assignment if necessary):
			std::pair<std::string, TuxedoLoadModule*>	value(*itT, loadModuleForTxn);
			assignedTxns.insert(value);
		}

		// Add the action blocks from this ICM to the Tuxedo load module
		loadModuleForTxn->add_ActionBlocksUnique(theIcm.get_ActionBlocks());
		loadModuleForTxn->add_ActionBlocksUnique(theIcm.get_Externals());
	}
	//	bool						unpackaged = true;
	//	for (TuxedoLoadModules::iterator itTLM = modules.begin(); 
	//		itTLM != modules.end() && unpackaged;
	//		++itTLM)
	//	{
	//		for (std::vector<std::string>::const_iterator itT = transactions.begin();
	//			itT != transactions.end() && unpackaged;
	//			++itT)
	//		{
	//			unpackaged = !itTLM->get_HasTransaction(*itT);
	//		}

	//		if (false == unpackaged)
	//		{
	//			// One (or more) of the transactions defined in this ICM are
	//			// already in this load module.  Ensure all the transactions
	//			// are in the Tuxedo load module--the CA Gen generated dialog manager
	//			// will be confused if the two tranaction's procedure steps
	//			// are in two different load modules.
	//			for (std::vector<std::string>::const_iterator itT = transactions.begin();
	//				itT != transactions.end();
	//				++itT)
	//			{
	//				itTLM->add_Transaction(*itT);
	//			}

	//			// Add the action blocks from this ICM to the Tuxedo load module
	//			itTLM->add_ActionBlocksUnique(theIcm.get_ActionBlocks());
	//			itTLM->add_ActionBlocksUnique(theIcm.get_Externals());

	//			for (TuxedoLoadModules::iterator itOther = modules.begin(); 
	//				itOther != modules.end();
	//				++itOther)
	//			{
	//				if (itOther == itTLM) continue;

	//				for (std::vector<std::string>::const_iterator itT = transactions.begin();
	//					itT != transactions.end();
	//					++itT)
	//				{
	//					itOther->remove_Transaction(*itT);
	//				}
	//			}
	//		}
	//	}

	//	if (unpackaged)
	//	{
	//		// Put the transactions in this ICM into a remainder module.
	//		for (std::vector<std::string>::const_iterator itT = transactions.begin();
	//			itT != transactions.end() && unpackaged;
	//			++itT)
	//		{
	//			remainderModules[currentRemainderModule].add_Transaction(*itT);
	//		}

	//		// Add the action blocks from this ICM to the remainder module
	//		remainderModules[currentRemainderModule].add_ActionBlocksUnique(theIcm.get_ActionBlocks());
	//		remainderModules[currentRemainderModule].add_ActionBlocksUnique(theIcm.get_Externals());

	//		// Round robin to the next remainder module.
	//		++currentRemainderModule;
	//		if (remainderModules.size() <= currentRemainderModule) currentRemainderModule = 0;
	//	}
	//}

	// Don't emit load modules with no transactions.
	for (TuxedoLoadModules::const_iterator it = remainderModules.begin(); it != remainderModules.end(); ++it)
	{
		if (0 < it->get_Transactions().size())
		{
			modules.push_back(*it);
		}
	}
}


// @doc INTERNAL
// 
// @mfunc Find 0-to-N files in a given directory.  Use the a <p directories> as a base directory
// and append each <p subDirectories> item.  Use <p includePatterns> to match found files names
// and use <p excludePatterns> to reject found file names.  When a file is found, pass the full path
// and file name (without extension) to the <p OnFileFound> delegate.
// 
// @parm size_t | numSubDirectories | count of strings in <p subDirectories>
// @parm const char *[] | subDirectories | sub-directories off of the base directory
// @parm const std::vector<std::string> & | directories | bas directories to search
// @parm const std::vector<std::string> & | includePatterns | file name include patterns
// @parm const std::vector<std::string> & | excludePatterns | file name exclude patterns
// @parm void (Program::*)(const std::string &, const char *) | OnFileFound | found file delegate
void Program::GatherFromFiles(size_t numSubDirectories,
	const char* subDirectories[],
	const std::vector<std::string>& directories,
	const std::vector<std::string>& includePatterns,
	const std::vector<std::string>& excludePatterns,
	OnFileFoundDelegate& delegateObj)
{
	std::string		fullDirectory;
	std::string		fullPath;
	bool			isIncluded;
#if	defined(TARGET_WIN32)
	static	char	baseFileName[MAX_PATH];
	std::string		search;
#else
	static	char	baseFileName[PATH_MAX];
#endif

	// For each directory
	for (std::vector<std::string>::const_iterator itD = directories.begin();
		itD != directories.end();
		++itD)
	{
		// Each item in the directories collection refers to the base of a build
		// area.  Append the caller's subdirectory parts to the base directory.
		fullDirectory = (*itD);
                std::cout << "Directory is: " << fullDirectory << std::endl;
		for (size_t	j = 0; j < numSubDirectories; ++j)
		{
			// Ensure the directory ends with a directory part seperator.
			if (0 < fullDirectory.length()
				&& m_chSep != fullDirectory[fullDirectory.length() - 1])
			{
				fullDirectory.append(1, m_chSep);
			}

			// Append a subdirectory part
			fullDirectory.append(subDirectories[j]);
		}

		// Ensure the directory ends with a directory part seperator.
		if (0 < fullDirectory.length()
			&& m_chSep != fullDirectory[fullDirectory.length() - 1])
		{
			fullDirectory.append(1, m_chSep);
		}

#if	defined(TARGET_WIN32)
		// For each include file name mask
		for (std::vector<std::string>::const_iterator itI = includePatterns.begin();
			itI != includePatterns.end();
			++itI)
		{
			// Start with the (hopefully) fully qualified subdirectory
			search = fullDirectory;

			// Add the file name wildcard pattern or file name to the search-for string:
			search.append(*itI);

			// Find each file named in the string:
			WIN32_FIND_DATAA	entry;
			HANDLE				hFile = ::FindFirstFileA(search.c_str(), &entry);
			if (INVALID_HANDLE_VALUE != hFile)
			{
				do
				{
					// Skip directories
					if (!(FILE_ATTRIBUTE_DIRECTORY & entry.dwFileAttributes))
					{
						// Is this file name excluded?
						isIncluded = true;
						for (std::vector<std::string>::const_iterator itE = excludePatterns.begin();
							itE != excludePatterns.end() && isIncluded;
							++itE)
						{
							isIncluded =(::PathMatchSpecA(entry.cFileName, itE->c_str()))
								? false
								: true;
						}

						if (isIncluded)
						{
							// We found a file that is included but not excluded!
							fullPath = fullDirectory;
							fullPath.append(entry.cFileName);
							::PathRemoveExtensionA(entry.cFileName);

							// Use the callback for this file type or collection type.
							delegateObj.Invoke(fullPath, entry.cFileName);
						}
					}
				}
				while (TRUE == ::FindNextFileA(hFile, &entry));
				::FindClose(hFile);
			}
		}
#else
		DIR*			dirp = opendir(fullDirectory.c_str());
		struct dirent*	dp;
		struct stat	statBuf;
	        std::cout << "Inside Gather files " << std::endl;

		while (dp = readdir(dirp))
		{
			// Loop until we exhaust the match list or we have a match
			isIncluded = false;
			for (std::vector<std::string>::const_iterator itI = includePatterns.begin();
				itI != includePatterns.end() && false == isIncluded;
				++itI)
			{
                                //std::cout << "Include pattern is: " << (*itI).c_str() << std::endl;
				isIncluded = (0 == (fnmatch((*itI).c_str(), dp->d_name, 0)))
					? true
					: false;
			}

			// Is this file name excluded?
			for (std::vector<std::string>::const_iterator itE = excludePatterns.begin();
				itE != excludePatterns.end() && isIncluded;
				++itE)
			{
				isIncluded = (0 == (fnmatch((*itE).c_str(), dp->d_name, 0)))
					? false
					: true;
			}

			if (isIncluded)
			{
			fullPath = fullDirectory;
				fullPath.append(dp->d_name);

				// Make sure we're looking at a file and not a directory
				statBuf.st_mode = 0;
				if (0 == stat(fullPath.c_str(), &statBuf) && S_IFREG == (S_IFREG & statBuf.st_mode))
				{
					strcpy(baseFileName, basename(dp->d_name));
					char*	period = strchr(baseFileName, '.');
					if (NULL != period) *period = '\0';
					// Use the callback for this file type or collection type.
					delegateObj.Invoke(fullPath, baseFileName);
				}
			}
		}
#endif
	}
}

}	// namespace Mtvsl

#endif	// !defined(_mtvsl_program_h_included_)
