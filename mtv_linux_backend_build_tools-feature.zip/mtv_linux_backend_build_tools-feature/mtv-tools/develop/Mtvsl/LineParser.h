// ----------------------------------------------------------------------
// MetaVance
// Copyright (C) 2008-2009, Hewlett-Packard Development Company, LP
// All Rights Reserved.
//
// EDS, an HP company
// 225 Grandview Avenue
// Camp Hill, PA  17011 USA
// http://www.eds.com
//
// This source code is the confidential property of EDS, an HP company.
// All proprietary rights, including but not limited to any trade secret,
// copyright, patent or trademark rights in and to this source code are
// the property of EDS.  This source code is not to be used, disclosed or
// reproduced in any form without the express written consent of EDS.
//
// ----------------------------------------------------------------------
#if	!defined(_mtvsl_lineparser_h_included_)
#define	_mtvsl_lineparser_h_included_

// Needs cctype, istream, and string

namespace Mtvsl {

// @doc INTERNAL
//
// @class A line oriented stream parser.  Gets a logical line from
// a given stream ignoring comments.  Counts the lines in a stream
// along the way.
class LineParser
{
// @access public
public:

	// @doc INTERNAL
	//
	// @mfunc Default constructor
	LineParser(void)
		: m_commentToEol(0)
		, m_lineNumber(1)
	{
	}

	// @doc INTERNAL
	// 
	// @mfunc Copy constructor.
	// 
	// @parm const Mtvsl::LineParser & | other | other <c LineParser> instance to copy
	LineParser(const LineParser& other)
	{
		operator =(other);
	}

// Attributes

	// @doc INTERNAL
	//
	// @mfunc Get the comment-to-end-of-line character.
	//
	// @rdesc char | comment-to-end-of-line character
	char get_CommentToEol(void) const
	{
		return m_commentToEol;
	}

	// @doc INTERNAL
	// 
	// @mfunc Get the current line number.
	// 
	// @rdesc size_t | line number
	size_t get_LineNumber(void) const
	{
		return m_lineNumber;
	}

	// @doc INTERNAL
	//
	// @mfunc Set the comment-to-end-of-line character.
	//
	// @parm char | ch | comment-to-end-of-line character
	void set_CommentToEol(char ch)
	{
		m_commentToEol = ch;
	}

	// @doc INTERNAL
	// 
	// @mfunc Set the current line number.  Use this when the stream
	// is read by another parser as well.
	// 
	// @parm size_t | lineNumber | current line number on the stream
	void set_LineNumber(size_t lineNumber)
	{
		m_lineNumber = lineNumber;
	}

	// @doc INTERNAL
	// 
	// @mfunc Assignment operator.
	// 
	// @parm const Mtvsl::LineParser& | rhs | <c LineParser> instance to assign to this <c LineParser> instance.
	// 
	// @rdesc Mtvsl::LineParser & | this <c LineParser> instance.
	LineParser& operator =(const LineParser& rhs)
	{
		m_commentToEol = rhs.m_commentToEol;
		m_lineNumber = rhs.m_lineNumber;
		return *this;
	}

	// @doc INTERNAL
	// 
	// @mfunc Get a data line from the stream.  Skips leading whitespace and trailing whitespace.
	// Reads and discards comments as indicated via the given comment character.
	// 
	// @parm std::istream & | stream | stream to read
	// @parm std::string & | line | ouput data line
	void GetLine(std::istream& stream, std::string& line)
	{
		std::istream::int_type	nextCh;
		std::istream::char_type	ch;

		// No output yet
		line.clear();

		// Skip leading whitespace and count linefeeds
		while (!stream.eof())
		{
			nextCh = stream.peek();
			if ('\n' == nextCh)
			{
				// We're on a new line
				++m_lineNumber;
			}
		
			if (std::isspace(nextCh))
			{
				// Gobble a whitepace character
				stream.read(&ch, 1);
			}
			else
			{
				// Not a whitespace character
				break;
			}
		}

		// Take characters to end of line
		bool	takeChars = true;
		nextCh = stream.peek();
		while (!(std::char_traits<char>::eof() == nextCh || '\n' == nextCh))
		{
			// Fetch the character--it's not past EOF or a line feed
			stream.read(&ch, 1);

			// Are we in the data protion of the line?
			if (takeChars)
			{
				// Have we entered the comment portion of the line?
				takeChars = (0 != m_commentToEol && nextCh == m_commentToEol) ? false : true;
				if (takeChars) line.append(1, ch);
			}
			nextCh = stream.peek();
		}

		// If we've read the last character, read EOF:
		if (std::char_traits<char>::eof() == nextCh) stream.read(&ch, 1);

		// Strip whitespace from the end of the line
		std::string::size_type	length = line.length();
		while (0 < length && std::isspace(static_cast<unsigned char>(line[length -1]))) --length;
		if (length < line.length()) line = line.substr(0, length);
	}

	// @doc INTERNAL
	//
	// @mfunc Destructor.
	~LineParser(void)
	{
	}

private:

	std::istream::int_type	m_commentToEol;	
	size_t					m_lineNumber;
};

}	// namespace Mtvsl {

#endif	// !defined(_mtvsl_lineparser_h_included_)
