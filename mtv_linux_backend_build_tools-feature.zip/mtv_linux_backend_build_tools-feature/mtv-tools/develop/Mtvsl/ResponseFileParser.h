// ----------------------------------------------------------------------
// MetaVance
// Copyright (C) 2008-2009, Hewlett-Packard Development Company, LP
// All Rights Reserved.
//
// EDS, an HP company
// 225 Grandview Avenue
// Camp Hill, PA  17011 USA
// http://www.eds.com
//
// This source code is the confidential property of EDS, an HP company.
// All proprietary rights, including but not limited to any trade secret,
// copyright, patent or trademark rights in and to this source code are
// the property of EDS.  This source code is not to be used, disclosed or
// reproduced in any form without the express written consent of EDS.
//
// ----------------------------------------------------------------------
#if	!defined(_mtvsl_responsefileparser_h_included_)
#define	_mtvsl_responsefileparser_h_included_

// Needs cctype, istream, string, and vector

#include "LineParser.h"
#include "ProgramOptions.h"

namespace Mtvsl {

// @doc INTERNAL
//
// @class Parses a stream into a <c ProgramOptions> instance.
class ResponseFileParser
{
// @access public
public:

	// @doc INTERNAL
	//
	// @mfunc Default constructor
	ResponseFileParser(void)
	{
	}

	// @doc INTERNAL
	//
	// @mfunc Parse program options from the given stream.
	static ProgramOptions Parse(std::istream& stream);

	// @doc INTERNAL
	//
	// @mfunc Write keyword strings and brief help to the given stream.
	static void ShowHelp(std::ostream& stream);

	// @doc INTERNAL
	//
	// @mfunc Destructor.
	~ResponseFileParser(void)
	{
	}

// @access private
private:

	enum Keyword
	{
		Unknown,
		ApiRemainderModuleCount,
		ApiRemainderModulePrefix,
		ApiTransactionGrouping,
		Areas,
		ComponentAreas,
		ExcludeApiIcmPatterns,
		ExcludeBatchIcmPatterns,
		ExcludePkgPatterns,
		ExcludeServerIcmPatterns,
		IncludeApiIcmPatterns,
		IncludeBatchIcmPatterns,
		IncludePkgPatterns,
		IncludeServerIcmPatterns,
		OnlineRemainderModuleCount,
		OnlineRemainderModulePrefix,
		OutputDir,
		OnlineTransactionGrouping,
		SkipApis,
		SkipBatch,
		SkipOnline,
                SkipBatchSharedLib
	};

	typedef	struct	tagKeywordDef
	{
		Keyword		eKeyword;
		const char*	szKeyword;
		const char*	szKeywordHelp;
	} KEYWORDDEF;

	// @doc INTERNAL
	//
	// @cmember Obtain a boolean value from a string.
	static bool BooleanFromString(const std::string& str);

	// @doc INTERNAL
	//
	// @cmember Given a string, see if it matches a keyword.
	static Keyword KeywordFromString(const std::string& word);

	// @doc INTERNAL
	//
	// @mfunc Create a string from a vector of file name patterns
	//
	// @parm const std::vector<std::string>& | vec | file name patterns
	//
	// @rdesc std::string | the values of <p vec> concatenated with a comma
	static std::string PatternsToString(const std::vector<std::string>& vec)
	{
		std::ostringstream	os;
		bool				emitted = false;

		for (std::vector<std::string>::size_type i = 0; i < vec.size(); ++i)
		{
			if (emitted) os << COMMA_DELIM;
			if (0 < vec.at(i).length())
			{
				os << vec.at(i);
				emitted = true;
			}
		}

		return os.str();
	}

	// @doc INTERNAL
	//
	// @cmember Tokenize a string into a vector of substrings.
	static std::vector<std::string> VectorFromString(const char delimiter, const std::string& str);

	static	const char	COMMA_DELIM;
	static	KEYWORDDEF	KEYWORDS[];
public:
	static	const char	CONCAT_DELIM;
};

const char	ResponseFileParser::COMMA_DELIM = ',';
#if	defined(TARGET_WIN32)
const char	ResponseFileParser::CONCAT_DELIM = ';';
#else
const char	ResponseFileParser::CONCAT_DELIM = ':';
#endif

#define	S(k, c)	{ k, # k, c }
ResponseFileParser::KEYWORDDEF ResponseFileParser::KEYWORDS[] =
{
	S(ApiRemainderModuleCount,	"how many load modules to use for unpackaged API transactions"),
	S(ApiRemainderModulePrefix,	"load module prefix for unpackaged API transaction load modules"),
	S(ApiTransactionGrouping,	"an API transction grouping file with transaction / load module pairs"),
	S(Areas,					"build area concatenation"),
	S(ComponentAreas,			"component area concatenation"),
	S(ExcludeApiIcmPatterns,	"file name patterns to ignore during an API load module search"),
	S(ExcludeBatchIcmPatterns,	"file name patterns to ignore during a batch load module search"),
	S(ExcludePkgPatterns,		"file name patterns to ignore during a package file search"),
	S(ExcludeServerIcmPatterns,	"file name patterns to ignore during an online load module search"),
	S(IncludeApiIcmPatterns,	"file name patterns to include during an API load module search"),
	S(IncludeBatchIcmPatterns,	"file name patterns to include during a batch load module search"),
	S(IncludePkgPatterns,		"file name patterns to include during a package file search"),
	S(IncludeServerIcmPatterns, "file name patterns to include during an online load module search"),
	S(OnlineRemainderModuleCount, "how many load modules to use for unpackaged online transactions"),
	S(OnlineRemainderModulePrefix, "load module prefix for unpackaged online transaction load modules"),
	S(OutputDir,				"directory used for output files"),
	S(OnlineTransactionGrouping, "an online transction grouping file with transaction / load module pairs"),
	S(SkipApis,					"do not perform API load module processing"),
	S(SkipBatch,				"do not perform batch load module processing"),
	S(SkipOnline,				"do not perform batch load module processing"),
        S(SkipBatchSharedLib,            "do not build Batch shared library")
};
#undef	S

// @doc INTERNAL
//
// @mfunc Obtain a boolean value from a string.
//
// @parm const std::string& | str | string to tokenize
//
// @rdesc bool | true or false
bool ResponseFileParser::BooleanFromString(const std::string& str)
{
	const char*	value = str.c_str();

	if (0 == _stricmp("true", value)
		|| 0 == _stricmp("T", value)
		|| 0 == strcmp("1", value))
	{
		return true;
	}

	if (0 == _stricmp("false", value)
		|| 0 == _stricmp("F", value)
		|| 0 == strcmp("0", value))
	{
		return false;
	}

	// What might the value be?
	std::ostringstream	os;
	os << "Cannot get boolean value from '"
		<< str
		<< "'"
		;
	throw std::invalid_argument(os.str());
}

// @doc INTERNAL
// 
// @mfunc Given a string, see if it matches a keyword.  The compare
// is case-insensitive.
// 
// @parm const std::string & | word | string to match
// 
// @rdesc ResponseFileParser::Keyword | a <e Keyword> value.
ResponseFileParser::Keyword ResponseFileParser::KeywordFromString(const std::string& word)
{
	Keyword		eKeyword = Unknown;
	const char*	pszKeyword = word.c_str();

	for (int i = 0; i < _countof(KEYWORDS) && Unknown == eKeyword; ++i)
	{
		if (0 == _stricmp(KEYWORDS[i].szKeyword, pszKeyword))
		{
			eKeyword = KEYWORDS[i].eKeyword;
		}
	}

	return eKeyword;
}

// @doc INTERNAL
//
// @mfunc Parse program options from the given stream.
// 
// @parm std::istream & | stream | input stream.
// 
// @rdesc ProgramOptions | options parsed from stream
ProgramOptions ResponseFileParser::Parse(std::istream& stream)
{
	Keyword						eKeyword;
	bool						flag;
	std::string					keyword;
	std::string					line;
	LineParser					lineParser;
	std::string::size_type		index;
	ProgramOptions				options;
	std::string					value;
	std::vector<std::string>	values;
	
	line.reserve(255);
	lineParser.set_CommentToEol('#');
	while (!stream.eof())
	{
		lineParser.GetLine(stream, line);

		// Ignore blank lines
		if (0 == line.length()) continue;

		// Split the line into a keyword / value pair:
		index = line.find_first_of('=');
		if (std::string::npos == index)
		{
			throw std::logic_error("unknown response file line");
		}
		keyword = line.substr(0, index);
		value = line.substr(index + 1);

		// Which keyword is this?
		eKeyword = KeywordFromString(keyword);

		switch (eKeyword)
		{
		case ApiRemainderModuleCount:
		{
			int	count = atoi(value.c_str());
			options.set_ApiRemainderModuleCount(count);
			break;
		}
		case ApiRemainderModulePrefix:
		{
			options.set_ApiRemainderModulePrefix(value);
			break;
		}
		case ApiTransactionGrouping:
		{
			options.set_ApiTransactionGrouping(value);
			break;
		}
		case Areas:
		{
			values = VectorFromString(CONCAT_DELIM, value);
			options.set_Areas(values);
		}
		case ComponentAreas:
		{
			values = VectorFromString(CONCAT_DELIM, value);
			options.set_ComponentAreas(values);
			break;
		}
		case ExcludeApiIcmPatterns:
		{
			values = VectorFromString(COMMA_DELIM, value);
			options.set_ExcludeApiIcmPatterns(values);
			break;
		}
		case ExcludeBatchIcmPatterns:
		{
			values = VectorFromString(COMMA_DELIM, value);
			options.set_ExcludeBatchIcmPatterns(values);
			break;
		}
		case ExcludePkgPatterns:
		{
			values = VectorFromString(COMMA_DELIM, value);
			options.set_ExcludePkgPatterns(values);
			break;
		}
		case ExcludeServerIcmPatterns:
		{
			values = VectorFromString(COMMA_DELIM, value);
			options.set_ExcludeServerIcmPatterns(values);
			break;
		}
		case IncludeApiIcmPatterns:
		{
			values = VectorFromString(COMMA_DELIM, value);
			options.set_IncludeApiIcmPatterns(values);
			break;
		}
		case IncludeBatchIcmPatterns:
		{
			values = VectorFromString(COMMA_DELIM, value);
			options.set_IncludeBatchIcmPatterns(values);
			break;
		}
		case IncludePkgPatterns:
		{
			values = VectorFromString(COMMA_DELIM, value);
			options.set_IncludePkgPatterns(values);
			break;
		}
		case IncludeServerIcmPatterns:
		{
			values = VectorFromString(COMMA_DELIM, value);
			options.set_IncludeServerIcmPatterns(values);
			break;
		}
		case OnlineRemainderModuleCount:
		{
			int	count = atoi(value.c_str());
			options.set_OnlineRemainderModuleCount(count);
			break;
		}
		case OnlineRemainderModulePrefix:
		{
			options.set_OnlineRemainderModulePrefix(value);
			break;
		}
		case OutputDir:
		{
			options.set_OutputDir(value);
			break;
		}
		case OnlineTransactionGrouping:
		{
			options.set_OnlineTransactionGrouping(value);
			break;
		}
		case SkipApis:
		{
			flag = BooleanFromString(value);
			options.set_SkipApis(flag);
			break;
		}
		case SkipBatch:
		{
			flag = BooleanFromString(value);
			options.set_SkipBatch(flag);
			break;
		}
		case SkipOnline:
		{
			flag = BooleanFromString(value);
			options.set_SkipOnline(flag);
			break;
		}
                case SkipBatchSharedLib:
                {
                        flag = BooleanFromString(value);
                        options.set_SkipBatchSharedLib(flag);
                        break;
                }

		} // switch
	}

	return options;
}

// @doc INTERNAL
//
// @mfunc Write keyword strings and brief help to the given stream.
//
// @parm ostream& | stream | output stream
void ResponseFileParser::ShowHelp(std::ostream& stream)
{
	size_t	len;
	size_t	longest = 0;

	// Which is the longest string?
	for (int i = 0; i < _countof(KEYWORDS); ++i)
	{
		len = strlen(KEYWORDS[i].szKeyword);
		longest = (len > longest) ? len : longest;
	}

	// Emit the keyword and help . . .
	for (int i = 0; i < _countof(KEYWORDS); ++i)
	{
		stream << std::left
			<< std::setw(longest)
			<< std::setfill(' ')
			<< KEYWORDS[i].szKeyword
			<< KEYWORDS[i].szKeywordHelp
			<< std::endl
			;
	}

	// And default values:
	std::ios_base::fmtflags	savedFlags = stream.flags();
	std::boolalpha(stream);

	ProgramOptions	defaultOptions;
	stream
		<< std::endl << "Default values:" << std::endl
		<< "ApiRemainderModuleCount="	<< defaultOptions.get_ApiRemainderModuleCount() << std::endl
		<< "ApiRemainderModulePrefix="	<< defaultOptions.get_ApiRemainderModulePrefix() << std::endl
		<< "IncludeBatchIcmPatterns="	<< PatternsToString(defaultOptions.get_IncludeBatchIcmPatterns()) << std::endl
		<< "IncludePkgPatterns="		<< PatternsToString(defaultOptions.get_IncludePkgPatterns()) << std::endl
		<< "IncludeServerIcmPatterns="	<< PatternsToString(defaultOptions.get_IncludeServerIcmPatterns()) << std::endl
		<< "OnlineRemainderModuleCount=" << defaultOptions.get_OnlineRemainderModuleCount() << std::endl
		<< "OnlineRemainderModulePrefix=" << defaultOptions.get_OnlineRemainderModulePrefix() << std::endl
		<< "SkipApis="					<< defaultOptions.get_SkipApis() << std::endl
		<< "SkipBatch="					<< defaultOptions.get_SkipBatch() << std::endl
		<< "SkipOnline="				<< defaultOptions.get_SkipOnline() << std::endl
		;
	stream.flags(savedFlags);
}

// @doc INTERNAL
//
// @mfunc Tokenize a string into a vector of substrings.
//
// @parm const char* | delimiters | delimiter characters used to subdivide the string
// @parm const std::string& | str | string to tokenize
//
// @rdesc std::vector<std::string> | substrings
std::vector<std::string> ResponseFileParser::VectorFromString(const char delimiter, const std::string& str)
{
#if	!defined(TARGET_WIN32)
#define	strtok_s(x, y, z)	strtok(x, y)
#endif

	char*						context = NULL;
	std::string					cow(str);
	char						delimiters[2] = { delimiter, '\0' };
	size_t						len;
	char*						token;
	char*						tokens;
	std::string					value;
	std::vector<std::string>	values;

	tokens = const_cast<char*>(cow.c_str());
	token = strtok_s(tokens, delimiters, &context);
	while (NULL != token)
	{
		// Strip trailing spaces
		len = strlen(token);
		while (0 < len && std::isspace(static_cast<unsigned char>(token[len - 1]))) --len;

		// Only add meaningful tokens
		if (0 != len) values.push_back(std::string(token, len));
		token = strtok_s(NULL, delimiters, &context);
	}

	return values;

#if	!defined(TARGET_WIN32)
#undef	strtok_s
#endif
}

}	// namespace Mtvsl

#endif	// !defined(_mtvsl_responsefileparser_h_included_)
