// ----------------------------------------------------------------------
// MetaVance
// Copyright (C) 2008-2009, Hewlett-Packard Development Company, LP
// All Rights Reserved.
//
// EDS, an HP company
// 225 Grandview Avenue
// Camp Hill, PA  17011 USA
// http://www.eds.com
//
// This source code is the confidential property of EDS, an HP company.
// All proprietary rights, including but not limited to any trade secret,
// copyright, patent or trademark rights in and to this source code are
// the property of EDS.  This source code is not to be used, disclosed or
// reproduced in any form without the express written consent of EDS.
//
// ----------------------------------------------------------------------
#if !defined(_mtvsl_pkg_h_included_)
#define	_mtvsl_pkg_h_included_

// Needs cctype, istream, map, and string

#include "LineParser.h"
#include "SymbolTable.h"

namespace Mtvsl	{

// @doc INTERNAL
//
// @class A <c Pkg> holds the definition of a library which contains CA Gen generated
// action blocks, external action blocks, and referential integrity (RI) triggers.
class Pkg
{
	typedef std::pair<std::string, SymbolTable>	SectionsItem;
	typedef std::map<std::string, SymbolTable>	Sections;

// @access public
public:

	// @doc INTERNAL
	//
	// @mfunc Default constructor.
	Pkg(void)
	{
	}

	// @doc INTERNAL
	// 
	// @mfunc Copy constructor.
	// 
	// @parm const Pkg& | other | <c Pkg> instance to copy.
	Pkg(const Pkg& other)
	{
		operator =(other);
	}

	// @doc INTERNAL
	// 
	// @mfunc Get the action blocks defined in this <c Pkg>.
	// 
	// @rdesc const SymbolTable & | action block table.
	const SymbolTable& get_ActionBlocks(void) const
	{
		return GetNames("[CABs]");
	}

	// @doc INTERNAL
	// 
	// @mfunc Get the external action blocks defined in this <c Pkg>.
	// 
	// @rdesc const SymbolTable & | action block table.
	const SymbolTable& get_Externals(void) const
	{
		return GetNames("[Externals]");
	}

	// @doc INTERNAL
	// 
	// @mfunc Get the library name assigned to this <c Pkg>.
	// 
	// @rdesc const std::string& | library name.
	const std::string& get_LibraryName(void) const
	{
		return m_libraryName;
	}

	// @doc INTERNAL
	// 
	// @mfunc Get the RI triggers defined in this <c Pkg>.
	// 
	// @rdesc const SymbolTable & | RI trigger table.
	const SymbolTable& get_Triggers(void) const
	{
		return GetNames("[Triggers]");
	}

	// @doc INTERNAL
	// 
	// @mfunc Set the library name for this <c Pkg>.
	// 
	// @parm const std::string & | name | library name
	void set_LibraryName(const std::string& name)
	{
		m_libraryName = name;
	}

	// @doc INTERNAL
	// 
	// @mfunc Assignment operator.
	// 
	// @parm const Pkg & | rhs | <c Pkg> instance to copy.
	// 
	// @rdesc Pkg & | this <c Pkg> instance.
	Pkg& operator =(const Pkg& rhs)
	{
		if (&rhs != this)
		{
			m_libraryName = rhs.m_libraryName;
			m_sections.clear();
			m_sections.insert(rhs.m_sections.begin(), rhs.m_sections.end());
		}
		return *this;
	}

// @access private
private:

	// @doc INTERNAL
	// 
	// @mfunc Get symbol table names in the section named by <p name>.
	// 
	// @parm const char * | name | section name
	// 
	// @rdesc const SymbolTable& | names in the given section.  May be empty. 
	const SymbolTable& GetNames(const char* name) const
	{
		Sections::const_iterator	it = m_sections.find(name);

		return (it != m_sections.end())
			? it->second
			: m_emptyTable
			;
	}

public:

	// @doc INTERNAL
	//
	// @cmember Parse a texual <c Pkg> instance from the given stream.
	static Pkg Parse(std::istream& stream);

	// @doc INTERNAL
	//
	// @mfunc Destructor
	~Pkg(void)
	{
	}

private:

	SymbolTable	m_emptyTable;
	std::string	m_libraryName;
	Sections	m_sections;
};

// @doc INTERNAL
// 
// @mfunc Parse a texual <c Pkg> instance from the given <p stream>. Throws
// std::logic_error if the stream is not parsable.
// 
// @parm std::istream & | stream | the stream to parse.
// 
// @rdesc Pkg | <c Pkg> instance as described in the <p stream>.
Pkg Pkg::Parse(std::istream& stream)
{
	SymbolTable*	currentSection = NULL;
	std::string		line;
	LineParser		lineParser;
	Pkg				parsedPkg;
	
	line.reserve(255);
	lineParser.set_CommentToEol('#');
	while (!stream.eof())
	{
		lineParser.GetLine(stream, line);

		// Ignore blank lines
		if (0 == line.length()) continue;

		// Is this a section name?
		if ('[' == line[0])
		{
			SectionsItem	value;
			value.first = line;

			// Add a new section
			std::pair<Sections::iterator, bool> insertedAt =
				parsedPkg.m_sections.insert(value);
			if (false == insertedAt.second) throw std::logic_error("PKG file has duplicate sections");

			currentSection = &((*insertedAt.first).second);
		}
		else
		{
			// Most likely a member name; are we in a section?
			if (NULL == currentSection) throw std::logic_error("Action block name not in a section.");

			// Add the action block to the named section
			currentSection->Add(line);
		}
	}

	return parsedPkg;
}

}	// namespace Mtvsl

#endif	// !defined(_mtvsl_pkg_h_included_)
