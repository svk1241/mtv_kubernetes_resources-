// ----------------------------------------------------------------------
// MetaVance
// Copyright (C) 2008-2009, Hewlett-Packard Development Company, LP
// All Rights Reserved.
//
// EDS, an HP company
// 225 Grandview Avenue
// Camp Hill, PA  17011 USA
// http://www.eds.com
//
// This source code is the confidential property of EDS, an HP company.
// All proprietary rights, including but not limited to any trade secret,
// copyright, patent or trademark rights in and to this source code are
// the property of EDS.  This source code is not to be used, disclosed or
// reproduced in any form without the express written consent of EDS.
//
// ----------------------------------------------------------------------
#if defined(TARGET_WIN32)
#define	WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shlwapi.h>
#else
#if	defined(__INTERIX)
#define	_ALL_SOURCE
#endif
#endif

// For reading directories
#include <sys/types.h>
#include <sys/stat.h>
#if defined(TARGET_WIN32)
#include <io.h>
#else
#include <dirent.h>
#include <fnmatch.h>
#include <libgen.h>
#include <strings.h>
#include <string.h>

// Equivalent functions in HP-UX
#define	_stricmp	strcasecmp
#define	sprintf_s	snprintf
#endif

// Array helper
#if	! defined(_countof)
#define	_countof(x)	(sizeof(x)/sizeof(x[0]))
#endif

// Template library needs
#include <algorithm>
#include <cctype>
#include <climits>
#include <exception>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <istream>
#include <map>
#include <sstream>
#include <stack>
#include <stdexcept>
#include <string>
#include <vector>

#include "Program.h"
#include "ResponseFileParser.h"

//@enum Program exit codes.
enum ProgramReturnCodes { ReturnOkay = 0, ReturnFault };

// @doc INTERNAL
// 
// @mfunc Show program help on the console.  This function does not return.
// 
// @parm bool | showDetailed | if true keyword help will be displayed
// @parm int | exitCode | a <e ProgramReturnCodes> value to use at exit()
static void ShowHelp(bool showDetailed = false, ProgramReturnCodes exitCode = ReturnOkay)
{
    std::cout
        << "Mtvsl @responseFile [-help | --help] [keyword=value] [keyword=value] [...]" << std::endl
        << "Where:" << std::endl
        << "\tresponseFile      contains Mtvsl keywords and values" << std::endl
        << "\tkeyword=value     is one keyword / value pair in addition to" << std::endl
        << "\t                  or overriding the same keyword / value pair" << std::endl
        << "\t                  in the given response file." << std::endl
        << "\t--help            keyword help." << std::endl
        ;

	if (showDetailed)
	{
		std::cout << std::endl << "Keywords:" << std::endl;
		Mtvsl::ResponseFileParser::ShowHelp(std::cout);
	}

	// Do not return from this function
	exit(exitCode);
}

// @doc INTERNAL
// 
// @mfunc Get program options from the command line.
// 
// @parm int | argc | command line argument count
// @parm char *[] | argv | command line arguments
// 
// @rdesc ProgramOptions | a <c ProgramOptions> instance containing
// all the options the user presented.
static Mtvsl::ProgramOptions GetOptions(int argc, char* argv[])
{
	std::ostringstream	allOptions;
	bool				haveResponseFile = false;

	// Did the user ask for help?
	for (int i = 1; i < argc; ++i)
	{
		if ('-' == argv[i][0]
#if	defined(TARGET_WIN32)
		|| '/' == argv[i][0]
#endif
		)
		{
			if (0 == _stricmp("help", &argv[i][1])
				|| 0 == _stricmp("?", &argv[i][1]))
			{
				ShowHelp();
			}
			else if (0 == _stricmp("-help", &argv[i][1]))
			{
				ShowHelp(true);
			}
		}
	}

	// Is there a response file on the command line?
	for (int i = 1; i < argc; ++i)
	{
		if ('@' == argv[i][0])
		{
			if (haveResponseFile) throw std::runtime_error("Multiple response files on the command line.");

			std::ifstream	fin(&argv[i][1], std::ios_base::in | std::ios_base::binary);
			if (!fin.is_open()) throw std::runtime_error("Cannot open response file.");

			// Transfer streams
			char			buffer[128];
			std::streamsize	readCount;
			while (!fin.eof())
			{
				//fin.get(buffer, _countof(buffer));
				//readCount = fin.gcount();
				fin.read(buffer, _countof(buffer));
				readCount = fin.gcount();
				//readCount = fin.readsome(buffer, sizeof(buffer));
				allOptions.write(buffer, readCount);
			}
			fin.close();
			haveResponseFile = true;
		}
	}

	// Do not continue if we've not found a response file:
	if (false == haveResponseFile)
	{
		std::cout << "No reponse file found on the command line." << std::endl;
		ShowHelp(false, ReturnFault);
	}

	// Put all the command line arguments at the end of the response file.  That
	// means that command line options override response file options.
	allOptions << std::endl;
	for (int i = 1; i < argc; ++i)
	{
		if ('@' != argv[i][0])
		{
			allOptions << argv[i] << std::endl;
		}
	}

	// Get the options into an object instance
	std::istringstream		optionsStream(allOptions.str());
	Mtvsl::ProgramOptions	options = Mtvsl::ResponseFileParser::Parse(optionsStream);
        
 
	// Verify given options
	if (false == options.Verify(std::cout)) exit(1);

	return options;
}

// @doc INTERNAL
// 
// @func Executable entry point.
// 
// @parm int | argc | argument count.
// @parm char *[] | argv | argument list
// 
// @rdesc int | 0 on success
// @rdesc int | not 0 on failure
int main(int argc, char* argv[])
{
	int	returnCode = ReturnOkay;

	try
	{
		Mtvsl::ProgramOptions	options = GetOptions(argc, argv);
		Mtvsl::Program			pgm;
		pgm.Run(options);
	}
	catch (std::exception& ex)
	{
		std::cout << "Exception:" << std::endl
			<< ex.what() << std::endl
			;
		returnCode = ReturnFault;
	}

	return returnCode;
}
