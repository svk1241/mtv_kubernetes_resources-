#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#ifndef  TRUE
#define  TRUE  1
#endif

#ifndef  FALSE
#define  FALSE 0
#endif

/* Process return codes */
#define  PROCESS_ERROR  0     /* Process error--could not execute */
#define  PROCESS_CSRVR  1     /* File name describes a cooperative server */
#define  PROCESS_CWIN   2     /* File name describes a cooperative window */
#define  PROCESS_WIN    3     /* File name describes a window-packaged window */
#define  PROCESS_RI     4     /* File name describes a cascade library */
/* OPLIB added 10/05/2001 -CTV */
#define  PROCESS_C_OPLIB 5    /* File name describes an OPLIB (packaged component) */
/* checking PSTEP name with OLE's added 01/24/2002 -CTV */
#define  PROCESS_CWIN_BAD_OLE 6

/* Size of a read buffer */
#define  RDBUFSZ        8192
#define  TXTBUFSZ       32

#define  DIM(m)         ( sizeof(m) / sizeof(m[0]) )

static   char  szSyntax[] = "Syntax error: %s filename\n\n" \
"   Where <filename> is an ICM or RMT file.\n\n" \
"   Return codes:\n" \
"         %d\tgeneral processing error\n" \
"         %d\tindicates input is a cooperative server\n" \
"         %d\tindicates input is a cooperative window\n" \
"         %d\tindicates input is a window packaged window\n" \
"         %d\tindicates input is a cascade descriptor\n" \
"         %d\tindicates input is an OPLIB (packaged component)\n\n";

static   char  szNoMem[]  = "Cannot allocate memory: %s\n";
static   char  szMod[9];

/*TLB - added following two lines */
int fileptr1;
FILE *fpin;

/* TLB
static   int   mainline( FILE* fin );
*/
static   int   mainline( FILE *fpin );

void           getModel( char* pszBuf ); /*CTV get model*/
static   int   getType( char* pszBuf );

/* 
TLB extern   int   main( int argc, char* argv[] )
*/

main( int argc, char* argv[] )
{
   int   rc = PROCESS_ERROR;
   FILE* fin;

/* TLB
   _splitpath( argv[0], NULL, NULL, szMod, NULL );
*/

   if ( argc < 2 )
   {
	   /*OPLIB added 10/05/2001 -CTV */
/* TLB
      printf( szSyntax, szMod, PROCESS_ERROR, PROCESS_CSRVR, PROCESS_CWIN,
*/
      printf( szSyntax, argv[0], PROCESS_ERROR, PROCESS_CSRVR, PROCESS_CWIN,
         PROCESS_WIN, PROCESS_RI, PROCESS_C_OPLIB);
   }
   else
   {
      if ((fpin = fopen( argv[1], "r" )) == NULL)
      {
         printf( "Cannot open \'%s\': %s\n", argv[1], strerror(errno) );
      }
      else
      {
         /* TLB 
          setvbuf( fin, NULL, 32767, _IOFBF );
         */

         rc = mainline( fpin );
         fclose( fpin );
      }
   }
   return( rc );
}

static   int   mainline( FILE* fin )
{
   int      rc = PROCESS_ERROR;
   char*    pszBuf;
   size_t   nRead;
   char*    pszTmp;

   pszBuf = (char*) malloc( RDBUFSZ );
   if ( pszBuf != NULL )
   {
      nRead = fread( pszBuf, 1, RDBUFSZ, fin );

      while ( nRead > 0 )
      {
         pszBuf[nRead] = '\0';
		 pszTmp = strstr( pszBuf, "\r\n:source" );
		 if ( pszTmp != NULL )
		 { 
			 getModel( pszTmp );
		 }

/* TLB
         pszTmp = strstr( pszBuf, "\r\n:execunit" );
*/
         pszTmp = strstr( pszBuf, ":execunit" );

         if ( pszTmp != NULL )
         {
            rc = getType( pszTmp );
            break;
         }

         nRead = fread( pszBuf, 1, RDBUFSZ, fin );
      }

      if ( ferror(fin) )
      {
         printf( "Error reading input: %s\n", strerror(errno) );
         rc = PROCESS_ERROR;
      }
      else if (pszTmp == NULL )
      {
         printf( "File does not appear to be an ICM or RMT\n" );
      }
   }
   else
   {
      printf( szNoMem, strerror(errno) );
   }

   return( rc );
}

void   getModel( char* pszBuf ) 
{
	static   char  szModel[]   = "model=";        
	static char    szModelOut[64] = "\n";
	char* pszModelOut = szModelOut;
	char* pszTmp;
	char* pszEndModel;

	pszTmp = strstr( pszBuf, szModel );          

	if ( pszTmp != NULL) 
	{
		pszTmp += sizeof(szModel);

		
		pszEndModel = strstr( pszTmp, "'" );
		strncpy(szModelOut, pszTmp, pszEndModel - pszTmp);
		printf( "%s;",pszModelOut);               
	} 

	return;
}
static   int   getType( char* pszBuf )
{												   
	static   char  szLmtype[]  = "lmtype=";
	static   char  szCoop[]    = "COOP";
	static   char  szSrvr[]    = "SRVR";
	static   char  szOpLib[]   = "OPLIB"; /*added OPLIB and Type2 10/05/2001 -CTV */
	static   char  szFileType[]= "File is a %s\n";
	static   char  szFileType2[]= "File is an %s\n";
	static   char  szBadPstep[] = "PSTEP name > 31 characters: %s\n";
	static   char  szPname[]   = "pname=";
    static   char  szCRLF[]      ="\r\n";

	
	char* pPname;
	char* pCRLF;

   int   rc = PROCESS_ERROR;
   char* pszTmp;

   /* Cooperative windows and cooperative servers will have an lmtype= defined
   in their :execunit section.
   */
		
   pszTmp = strstr( pszBuf, szLmtype );
   if ( pszTmp != NULL )
   {
      pszTmp += sizeof(szLmtype) - sizeof(char);

/* TLB
      if ( memicmp( pszTmp, szSrvr, sizeof(szSrvr) - sizeof(char) ) == 0 )
*/
      if ( strncmp( pszTmp, szSrvr, sizeof(szSrvr) - sizeof(char) ) == 0 )
      {
         printf( szFileType, szSrvr );
         rc = PROCESS_CSRVR;
      }
      else if ( strncmp( pszTmp, szCoop, sizeof(szCoop) - sizeof(char) ) == 0 )
      {
		  rc = PROCESS_CWIN;   
		  printf( szFileType, szCoop );
	  
		  pPname = strstr( pszBuf, szPname );
	  
		  while ( pPname != NULL )
		  {
			  pPname += strlen( szPname );
			  pCRLF = strstr( pPname, szCRLF );
			  if ( 31 < ( pCRLF - pPname ) )
			  {
				  strncpy( pCRLF, "\0\0", 2 );
				  rc = PROCESS_CWIN_BAD_OLE;
				  printf( szBadPstep, pPname );
				  strncpy( pCRLF, szCRLF, strlen(szCRLF) );

			  }
			  pPname = strstr( pPname, szPname );
		  }

                  
      }
/* check for OPLIB */
	  else if ( strncmp( pszTmp, szOpLib, sizeof(szOpLib) - sizeof(char) ) == 0 )
	  {
		  printf( szFileType2, szOpLib );
		  rc = PROCESS_C_OPLIB;
	  }
/* end OPLIB */
	  else
      {
         printf( "Don\'t know how to categorize \'lmtype=%-4.4s\'\n", pszTmp );
         rc = PROCESS_ERROR;
      }
   }
   else
   {
      /* Window packaged load modules do not have lmtype= in :execunit.  However,
      CASCADE members will also have an :execunit with no lmtype=.  So check to
      see if this is a cascade module before we call it a window packaged window
      manager.
      */
      
      pszTmp = strstr( pszBuf, "isolation=" );
      if ( pszTmp == NULL )
      {
         printf( szFileType, "CASCADE" );
         rc = PROCESS_RI;
      }
      else
      {
         printf( szFileType, "WIN" );
         rc = PROCESS_WIN;
      }
   }

   return( rc );
}


