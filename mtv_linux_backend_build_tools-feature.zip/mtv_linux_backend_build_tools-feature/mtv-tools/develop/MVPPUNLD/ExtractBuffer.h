/*
 **********************************************************************
 *
 * Metavance
 * Copyright (C) 2001-2008, EDS
 * All Rights Reserved.
 *
 * EDS
 * 225 Grandview Avenue
 * Camp Hill, PA  USA
 * http: *www.eds.com
 *
 * This source code is the confidential property of EDS, All
 * proprietary rights, including but not limited to any trade secret,
 * copyright, patent, or trademark rights in and to this source code
 * are the property of EDS.  This source code is not to be used,
 * disclosed or reproduced in any form without the express written
 * consent of EDS.
 *
 **********************************************************************
 */
#ifndef EXTRACTBUFFER_H_F36E32E0B_EB2D_4A81_A55A_C2C704EF00CC_INCLUDED
#define EXTRACTBUFFER_H_F36E32E0B_EB2D_4A81_A55A_C2C704EF00CC_INCLUDED

#ifdef _MSC_VER
#pragma once
#endif

#include "SimpleOciWrapper.h"

class ExtractBuffer
{
// @access Construction
public:
	ExtractBuffer()
	: m_rows(0)
	, m_contention(0)
	{
	}

private:

	// No copy construction
	ExtractBuffer(const ExtractBuffer&);

// @access Attributes
public:

	unsigned int get_Rows(void) const
	{
		return m_rows;
	}

	void set_Rows(unsigned int rows)
	{
		m_rows = rows;
	}

	std::vector<OCI::TextEmitter*>& get_Emitters(void)
	{
		return m_emitters;
	}

// @access Operations
private:
	// No assignment
	ExtractBuffer& operator =(const ExtractBuffer&);

// @access Implementation
public:
	~ExtractBuffer()
	{
	}

private:
	std::vector<OCI::TextEmitter*>	m_emitters;

protected:
	unsigned int m_rows;
	unsigned int m_contention;
};

class ExtractBufferList
{
	// No copy construction
	ExtractBufferList(const ExtractBufferList&);

public:
	ExtractBufferList()
	{
#if defined(TARGET_WIN32)
		InitializeCriticalSection(&m_cs);
		m_hEvt = CreateEvent(NULL, FALSE, FALSE, NULL);
		if (NULL == m_hEvt) ThrowWin32Exception(GetLastError());
#else
		int	rc;

		memcpy(&m_lock, &mutexInitialValue, sizeof(mutexInitialValue));

		rc = pthread_mutex_init(&m_lock, NULL);
		if (0 != rc)
		{
			ThrowRuntimeException(rc, __FILE__, __LINE__);
		}

		rc = sem_init(&m_evt, 0, 1);
		if (0 != rc)
		{
			ThrowRuntimeException(rc, __FILE__, __LINE__);
		}
#endif
	}

// @access Attributes
public:

	ExtractBuffer* getBuffer(void)
	{
		ExtractBuffer*	pBuffer = NULL;
		while (NULL == pBuffer)
		{
			Lock();
			if (!m_queue.empty())
			{
				pBuffer = m_queue.front();
				m_queue.pop_front();
			}
			Unlock();

			if (NULL == pBuffer)
			{
				Wait();
			}
		}

		return pBuffer;
	}
	void putBuffer(ExtractBuffer* pBuffer)
	{
		Lock();
		m_queue.push_back(pBuffer);
		Unlock();
		Signal();
	}

// @access Operations
private:
	// No assignment
	ExtractBufferList& operator =(const ExtractBufferList&);

private:
	void Lock(void)
	{
#if defined(TARGET_WIN32)
		EnterCriticalSection(&m_cs);
#else
		int rc = pthread_mutex_lock(&m_lock);
		if (0 != rc)
		{
			ThrowRuntimeException(rc, __FILE__, __LINE__);
		}
#endif
	}

	void Signal(void)
	{
#if defined(TARGET_WIN32)
		if (FALSE == SetEvent(m_hEvt)) ThrowWin32Exception(GetLastError());
#else
		int	rc;

		rc = sem_post(&m_evt);
		if (0 != rc)
		{
			ThrowRuntimeException(rc, __FILE__, __LINE__);
		}
#endif
	}

	void Unlock(void)
	{
#if defined(TARGET_WIN32)
		LeaveCriticalSection(&m_cs);
#else
		int rc = pthread_mutex_unlock(&m_lock);
		if (0 != rc)
		{
			ThrowRuntimeException(rc, __FILE__, __LINE__);
		}
#endif
	}

	void Wait(void)
	{
#if defined(TARGET_WIN32)
		if (WAIT_OBJECT_0 != WaitForSingleObject(m_hEvt, INFINITE)) ThrowWin32Exception(GetLastError());
#else
		int	rc;

		rc = sem_wait(&m_evt);
		if (0 != rc)
		{
			ThrowRuntimeException(rc, __FILE__, __LINE__);
		}
#endif
	}

#if defined(TARGET_WIN32)

	// Throw a std::exception in response to a WIN32 error code
	void ThrowWin32Exception(DWORD dwError)
	{
		std::string	strErrorMessage;
		PSTR   pszErrorMessage = NULL;

		::FormatMessageA( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
						 NULL,
						 dwError,
						 MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
						 reinterpret_cast<PSTR>( &pszErrorMessage ),
						 0,
						 NULL ); 

		if ( NULL == pszErrorMessage )
		{
			char    message[48];
			sprintf_s( message, "WIN32 error %ld (0x%08X)", dwError, dwError );
			strErrorMessage = message;
		}
		else
		{
			strErrorMessage = pszErrorMessage;
			LocalFree(pszErrorMessage);
		}
		throw std::exception(strErrorMessage.c_str());
	}

#else

	void ThrowRuntimeException(int rc, const char* file, int line)
	{
		std::ostringstream sb;
		sb 
			<< strerror(rc)
			<< " at "
			<< file
			<< '('
			<< line
			<< ')'
		;
		throw std::runtime_error(sb.str());
	}
#endif


	std::deque<ExtractBuffer*> m_queue;
#if defined(TARGET_WIN32)
	CRITICAL_SECTION	m_cs;
	HANDLE				m_hEvt;
#else
	pthread_mutex_t	m_lock;
	sem_t			m_evt;

	static pthread_mutex_t	mutexInitialValue;
#endif
};

#if ! defined(TARGET_WIN32)
pthread_mutex_t	ExtractBufferList::mutexInitialValue = PTHREAD_MUTEX_INITIALIZER;
#endif

#endif	// ndef EXTRACTBUFFER_H_F36E32E0B_EB2D_4A81_A55A_C2C704EF00CC_INCLUDED
