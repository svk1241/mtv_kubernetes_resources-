/*
 **********************************************************************
 *
 * Metavance
 * Copyright (C) 2001-2008, EDS
 * All Rights Reserved.
 *
 * EDS
 * 225 Grandview Avenue
 * Camp Hill, PA  USA
 * http: *www.eds.com
 *
 * This source code is the confidential property of EDS, All
 * proprietary rights, including but not limited to any trade secret,
 * copyright, patent, or trademark rights in and to this source code
 * are the property of EDS.  This source code is not to be used,
 * disclosed or reproduced in any form without the express written
 * consent of EDS.
 *
 **********************************************************************
 */
#if ! defined(SIMPLEOCIWRAPPER_H_F49E2FC5_4D7F_447C_BC67_5C590C6A42BB_INCLUDED)
#define	SIMPLEOCIWRAPPER_H_F49E2FC5_4D7F_447C_BC67_5C590C6A42BB_INCLUDED

#ifdef _MSC_VER
#pragma once
#endif

#include <iomanip>
#include <math.h>
#include <ostream>
#include <sstream>
#include <string>
#include <assert.h>

namespace OCI
{
	// Forward declarations
	class Column;
	class Define;
	class OciException;
	class Session;
	class Statement;

	class OciException
	{
		// @access Construction
	public:
		OciException()
			: m_errorCode(0)
		{
		}

		OciException(const char* pszMessage)
			: m_errorCode(0)
			, m_message(pszMessage)
		{
		}

		OciException(const char* pszMessage, int errorCode)
			: m_errorCode(errorCode)
			, m_message(pszMessage)
		{
		}

		OciException(const std::string& message)
			: m_errorCode(0)
			, m_message(message)
		{
		}

		OciException(const std::string& message, int errorCode)
			: m_errorCode(errorCode)
			, m_message(message)
		{
		}

		OciException(const OciException& other)
		{
			operator =(other);
		}

		OciException(ORACLE_NS::OCIError* pErr)
			: m_errorCode(0)
		{
			CommonConstruct(pErr, OCI_HTYPE_ERROR);
		}

		OciException(ORACLE_NS::OCIEnv* pEnv)
			: m_errorCode(0)
		{
			CommonConstruct(pEnv, OCI_HTYPE_ENV);
		}

		// @access Attributes
	public:
		const std::string& get_Message(void) const
		{
			return m_message;
		}

		int get_ErrorCode(void) const
		{
			return m_errorCode;
		}

		// @access Operations
	public:
		OciException& operator =(const OciException& rhs)
		{
			if (this != &rhs)
			{
				m_message = rhs.m_message;
				m_errorCode = rhs.m_errorCode;
			}
			return *this;
		}

	private:

		void CommonConstruct(void* pHandle, ORACLE_NS::ub4 handleType)
		{
			ORACLE_NS::text		message[OCI_ERROR_MAXMSG_SIZE] = { L'\0' };
			ORACLE_NS::sb4		errorCode = 0;
			ORACLE_NS::ub4		record = 1;
			ORACLE_NS::sword	ret = OCI_SUCCESS;
			std::ostringstream	messages;

			do
			{
				ret = ORACLE_NS::OCIErrorGet(pHandle,
					record,
					0,
					&errorCode,
					reinterpret_cast<ORACLE_NS::OraText*>(message),
					sizeof(message),
					handleType);

				if (OCI_SUCCESS == ret)
				{
					messages << reinterpret_cast<char*>(&message[0]);
					m_errorCode = errorCode;
					++record;
				}
			}
			while (OCI_SUCCESS == ret);
			m_message = messages.str();
		}

		// @access implementation
	public:
		~OciException()
		{
		}

	private:

		std::string	m_message;
		int				m_errorCode;
	};
#define THROW_OCI_ERR(pErr) \
	{ \
	printf("Throwing OciException() from %s(%d)\n", __FILE__, __LINE__); \
	throw OciException(pErr); \
	}

	class Session
	{
		// @access Construction
	public:
		Session()
			: m_pEnv(NULL)
			, m_pSrvr(NULL)
			, m_pSvcCtx(NULL)
			, m_pSess(NULL)
			, m_pErr(NULL)
		{
		}

		Session(const std::string& userName, const std::string& password, const std::string& serviceName)
			: m_pEnv(NULL)
			, m_pSrvr(NULL)
			, m_pSvcCtx(NULL)
			, m_pSess(NULL)
			, m_pErr(NULL)
		{
			CommonConstruct(userName, password, serviceName);
		}

		Session(const std::string& connectString)
			: m_pEnv(NULL)
			, m_pSrvr(NULL)
			, m_pSvcCtx(NULL)
			, m_pSess(NULL)
			, m_pErr(NULL)
		{
			std::string::size_type	pos;
			std::string::size_type	startPos = 0;
			std::string userName;
			std::string password;
			std::string serviceName;

			pos = connectString.find_first_of(L'/', startPos);
			if (std::string::npos != pos)
			{
				userName = connectString.substr(0, pos);
				startPos = pos + 1;

				if (startPos < connectString.length())
				{
					pos = connectString.find_first_of('@', pos);
					if (std::string::npos != pos)
					{
						password = connectString.substr(startPos, pos - startPos); // pragma: allowlist secret
						startPos = pos + 1;
						if (startPos < connectString.length())
						{
							serviceName = connectString.substr(startPos);
						}
					}
					else
					{
						password = connectString.substr(startPos); // pragma: allowlist secret
					}
				}
			}

			CommonConstruct(userName, password, serviceName);
		}

		// Copy construction creates a new session
		Session(const Session& other)
			: m_pEnv(NULL)
			, m_pSrvr(NULL)
			, m_pSvcCtx(NULL)
			, m_pSess(NULL)
			, m_pErr(NULL)
		{
			CommonConstruct(other.m_userName, other.m_password, other.m_serviceName);
		}

		void Release(void)
		{
			if (NULL != m_pSvcCtx && NULL != m_pErr && NULL != m_pSess)
			{
				OCISessionEnd(m_pSvcCtx, m_pErr, m_pSess, OCI_DEFAULT);
			}

			if (m_pSess) OCIHandleFree(m_pSess, OCI_HTYPE_SESSION);
			m_pSess = NULL;
			if (m_pSvcCtx) OCIHandleFree(m_pSvcCtx, OCI_HTYPE_SVCCTX);
			m_pSvcCtx = NULL;

			if (m_pSrvr)
			{
				OCIServerDetach(m_pSrvr, m_pErr, OCI_DEFAULT);
				OCIHandleFree(m_pSrvr, OCI_HTYPE_SERVER);
			}
			m_pSrvr = NULL;

			if (m_pErr) OCIHandleFree(m_pErr, OCI_HTYPE_ERROR);
			m_pErr = NULL;
			if (m_pEnv) OCIHandleFree(m_pEnv, OCI_HTYPE_ENV);
			m_pEnv = NULL;
		}

		// @access Attributes
	public:

		// @access Operations
	private:
		// No assignment
		Session& operator =(const Session& lhs)
		{
			if (this != &lhs)
			{
				Release();

				m_pEnv = lhs.m_pEnv;
				m_pSrvr = lhs.m_pSrvr;
				m_pSvcCtx = lhs.m_pSvcCtx;
				m_pSess = lhs.m_pSess;
				m_pErr = m_pErr;
				m_db_charset = lhs.m_db_charset;
				m_db_ncharset = lhs.m_db_ncharset;

				m_userName = lhs.m_userName;
				m_password = lhs.m_password; // pragma: allowlist secret
				m_serviceName = lhs.m_serviceName;
			}
			return *this;
		}

		void CommonConstruct(const std::string& userName, const std::string& password, const std::string& serviceName)
		{
			try
			{
				ORACLE_NS::sword ret;

				// Let the library know we'll be multithreaded
				ORACLE_NS::OCIThreadProcessInit();

				// create the environment
				//ret = ORACLE_NS::OCIEnvCreate(&m_pEnv, OCI_THREADED, 0, 0, 0, 0, 0, 0);
				//ret = ORACLE_NS::OCIEnvNlsCreate(&m_pEnv, OCI_THREADED, NULL, NULL, NULL, NULL, 0, NULL, OCI_UTF16ID, OCI_UTF16ID);
				ret = ORACLE_NS::OCIEnvNlsCreate(&m_pEnv, OCI_THREADED, NULL, NULL, NULL, NULL, 0, NULL, OCI_DEFAULT, OCI_DEFAULT);
				if (OCI_SUCCESS != ret) throw OciException("Cannot create environment");

				// create the server handle
				ret = ORACLE_NS::OCIHandleAlloc(m_pEnv,
					reinterpret_cast<dvoid**>(&m_pSrvr),
					OCI_HTYPE_SERVER,
					0,
					0);
				if (OCI_SUCCESS != ret) throw OciException("Cannot create server handle");

				// create the error handle
				ret = ORACLE_NS::OCIHandleAlloc(m_pEnv,
					reinterpret_cast<dvoid**>(&m_pErr),
					OCI_HTYPE_ERROR,
					0,
					0);
				if (OCI_SUCCESS != ret) throw OciException("Cannot create error handle");

				// create the server context
				ORACLE_NS::sb4 serviceNameLen = static_cast<ORACLE_NS::sb4>(serviceName.size() * sizeof(char));
				ret = ORACLE_NS::OCIServerAttach(m_pSrvr,
					m_pErr,
					reinterpret_cast<ORACLE_NS::text*>(const_cast<char*>(serviceName.c_str())),
					serviceNameLen,
					OCI_DEFAULT);
				if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_pErr);

				// create service context handle
				ret = ORACLE_NS::OCIHandleAlloc(m_pEnv,
					reinterpret_cast<dvoid**>(&m_pSvcCtx),
					OCI_HTYPE_SVCCTX,
					0,
					0);
				if (OCI_SUCCESS != ret) throw OciException("Cannot create service context");

				// set the server attribute in the context handle
				ret = ORACLE_NS::OCIAttrSet(m_pSvcCtx,
					OCI_HTYPE_SVCCTX,
					m_pSrvr,
					0,
					OCI_ATTR_SERVER,
					m_pErr);
				if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_pErr);

				// allocate user session handle
				ret = ORACLE_NS::OCIHandleAlloc(m_pEnv,
					reinterpret_cast<dvoid**>(&m_pSess),
					OCI_HTYPE_SESSION,
					0,
					0);
				if (OCI_SUCCESS != ret) throw OciException("Cannot allocate user session handle");

				// set username attribute in the user session handle
				ORACLE_NS::sb4 userNameLen = static_cast<ORACLE_NS::sb4>(userName.size() * sizeof(char));
				ret = ORACLE_NS::OCIAttrSet(m_pSess, OCI_HTYPE_SESSION,
					reinterpret_cast<dvoid*>(const_cast<char*>(userName.c_str())),
					userNameLen,
					OCI_ATTR_USERNAME,
					m_pErr);
				if (OCI_SUCCESS != ret)	throw OciException("Cannot set username");

				// set password attribute
				ORACLE_NS::sb4 passwordLen = static_cast<ORACLE_NS::sb4>(password.size() * sizeof(char));
				ret = ORACLE_NS::OCIAttrSet(m_pSess,
					OCI_HTYPE_SESSION,
					reinterpret_cast<dvoid*>(const_cast<char*>(password.c_str())),
					passwordLen,
					OCI_ATTR_PASSWORD,
					m_pErr);
				if (OCI_SUCCESS != ret) throw OciException("Cannot set password");

				// begin the session
				ret = ORACLE_NS::OCISessionBegin(m_pSvcCtx,
					m_pErr,
					m_pSess,
					OCI_CRED_RDBMS,
					OCI_DEFAULT);
				if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_pErr);

				// set the session in the context handle
				ret = ORACLE_NS::OCIAttrSet(m_pSvcCtx,
					OCI_HTYPE_SVCCTX,
					m_pSess,
					0,
					OCI_ATTR_SESSION,
					m_pErr);
				if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_pErr);

				// Get the server characters sets
				ORACLE_NS::ub4	attrLen = sizeof(m_db_charset);
				ret = ORACLE_NS::OCIAttrGet(m_pSrvr,
					OCI_HTYPE_SERVER,
					&m_db_charset,
					&attrLen,
					OCI_ATTR_DB_CHARSET_ID,
					m_pErr);
				if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_pErr);

				attrLen = sizeof(m_db_charset);
				ret = ORACLE_NS::OCIAttrGet(m_pSrvr,
					OCI_HTYPE_SERVER,
					&m_db_ncharset,
					&attrLen,
					OCI_ATTR_DB_NCHARSET_ID,
					m_pErr);
				if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_pErr);

				m_userName = userName;
				m_password = password; // pragma: allowlist secret
				m_serviceName = serviceName;

			}
			catch (OciException&)
			{
				Release();
				throw;
			}
		}

		// @access Implementation
	public:
		~Session()
		{
			Release();
		}

	private:

		ORACLE_NS::OCIEnv*		m_pEnv;
		ORACLE_NS::OCIServer*	m_pSrvr;
		ORACLE_NS::OCISvcCtx*	m_pSvcCtx;
		ORACLE_NS::OCISession*	m_pSess;
		ORACLE_NS::OCIError*	m_pErr;
		ORACLE_NS::ub2			m_db_charset;
		ORACLE_NS::ub2			m_db_ncharset;

		std::string m_userName;
		std::string m_password;
		std::string m_serviceName;

		friend class Column;
		friend class Statement;
		friend class TextEmitter;
	};

	class Column
	{
	// @access Construction
	public:
		Column(ORACLE_NS::OCIParam* parameter, ORACLE_NS::OCIError* pErr, unsigned int position)
		: m_dataSize(0)
		, m_dataType(0)
		, m_precision(0)
		, m_scale(0)
		, m_nullable(0)
		, m_position(position)
		{
			ORACLE_NS::sword	ret;
			ORACLE_NS::ub4		attrLen;

			attrLen = sizeof(m_dataType);
			ret = ORACLE_NS::OCIAttrGet(parameter,
				OCI_DTYPE_PARAM,
				&m_dataType,
				&attrLen,
				OCI_ATTR_DATA_TYPE,
				pErr);
			if (OCI_SUCCESS != ret) THROW_OCI_ERR(pErr);

			char*	pszName = NULL;
			attrLen = sizeof(pszName);
			ret = ORACLE_NS::OCIAttrGet(parameter,
				OCI_DTYPE_PARAM,
				&pszName,
				&attrLen,
				OCI_ATTR_NAME,
				pErr);
			if (OCI_SUCCESS != ret) THROW_OCI_ERR(pErr);
			m_name = std::string(pszName, attrLen);

			ORACLE_NS::ub4 char_semantics = 0;
			attrLen = sizeof(char_semantics);
			ret = ORACLE_NS::OCIAttrGet(parameter,
				OCI_DTYPE_PARAM,
				&char_semantics,
				&attrLen,
				OCI_ATTR_CHAR_USED,
				pErr);
			//if (OCI_SUCCESS != ret) throw OciException(pErr);

			//Retrieve the column width in bytes
			ORACLE_NS::ub4 attribute = OCI_ATTR_DATA_SIZE;
			if (char_semantics)
			{
				// Retrieve the column width in characters 
				attribute = OCI_ATTR_CHAR_SIZE;
			}

			attrLen = sizeof(m_dataSize);
			ret = ORACLE_NS::OCIAttrGet(parameter,
				OCI_DTYPE_PARAM,
				&m_dataSize,
				&attrLen,
				attribute,
				pErr);
			if (OCI_SUCCESS != ret) THROW_OCI_ERR(pErr);

			ORACLE_NS::ub4	char_form = 0;
			ret = ORACLE_NS::OCIAttrGet(parameter,
				OCI_DTYPE_PARAM,
				&char_form,
				&attrLen,
				OCI_ATTR_CHARSET_FORM,
				pErr );
			//if (OCI_SUCCESS != ret) throw OciException(m_pErr);
			if (SQLCS_NCHAR == char_form)
			{
				m_dataSize = m_dataSize * sizeof(char);
			}

			attrLen = sizeof(m_precision);
			ret = ORACLE_NS::OCIAttrGet(parameter,
				OCI_DTYPE_PARAM,
				&m_precision,
				&attrLen,
				OCI_ATTR_PRECISION,
				pErr );
			if (OCI_SUCCESS != ret) THROW_OCI_ERR(pErr);

			attrLen = sizeof(m_scale);
			ret = ORACLE_NS::OCIAttrGet(parameter,
				OCI_DTYPE_PARAM,
				&m_scale,
				&attrLen,
				OCI_ATTR_SCALE,
				pErr );
			if (OCI_SUCCESS != ret) THROW_OCI_ERR(pErr);

			attrLen = sizeof(m_nullable);
			ret = ORACLE_NS::OCIAttrGet(parameter,
				OCI_DTYPE_PARAM,
				&m_nullable,
				&attrLen,
				OCI_ATTR_IS_NULL,
				pErr );
			if (OCI_SUCCESS != ret) THROW_OCI_ERR(pErr);
		}

		Column(const Column& other)
			: m_dataSize(other.m_dataSize)
			, m_dataType(other.m_dataType)
			, m_name(other.m_name)
			, m_precision(other.m_precision)
			, m_scale(other.m_scale)
			, m_nullable(other.m_nullable)
			, m_position(other.m_position)
		{
		}

	// @access Attributes
	public:

		const std::string&	get_Name() const
		{
			return m_name;
		}

		int get_DataSize(void) const
		{
			return static_cast<int>(m_dataSize);
		}

		int get_DataType(void) const
		{
			return static_cast<int>(m_dataType);
		}

		bool get_IsNullable(void) const
		{
			return (0 == m_nullable) ? false : true;
		}

		unsigned int get_Position(void) const
		{
			return m_position;
		}

		int get_Precision(void) const
		{
			return static_cast<int>(m_precision);
		}

		int get_Scale(void) const
		{
			return static_cast<int>(m_scale);
		}

	// @access Operations
	public:

		Column& operator =(const Column& rhs)
		{
			if (this != &rhs)
			{
				m_dataSize = rhs.m_dataSize;
				m_dataType = rhs.m_dataType;
				m_name = rhs.m_name;
				m_precision = rhs.m_precision;
				m_scale = rhs.m_scale;
				m_nullable = rhs.m_nullable;
				m_position = rhs.m_position;
			}
			return *this;
		}

	// @access Implementation
	public:
		~Column()
		{
		}

	protected:
#ifndef TARGET_WIN32
		ORACLE_NS::ub2	m_dataSize;
#else
		ORACLE_NS::ub4	m_dataSize;
#endif
		ORACLE_NS::ub2	m_dataType;
		std::string		m_name;
		ORACLE_NS::sb2	m_precision;
		ORACLE_NS::ub1	m_scale;
		ORACLE_NS::ub1	m_nullable;
		unsigned int	m_position;
	};
	typedef std::vector<Column> ColumnsType;

	class Statement
	{
		// @access Construction
	public:
		Statement(Session& session)
			: m_session(session)
			, m_pStmt(NULL)
			, m_pNullIndicators(NULL)
			, m_pLengths(NULL)
			, m_pRetCodes(NULL)
			, m_pDefineHandles(NULL)
		{
			Alloc();
		}
	private:
		// No copy construction
		Statement(const Statement&);

		// @access Attributes
	public:
		
		const ColumnsType& Columns(void) const
		{
			return m_columns;
		}

		// @access Operations
	private:
		// No assignment
		Statement& operator =(const Statement&);

		void Alloc(void)
		{
			if (OCI_SUCCESS != ORACLE_NS::OCIHandleAlloc(m_session.m_pEnv,
				reinterpret_cast<dvoid**>(&m_pStmt),
				OCI_HTYPE_STMT,
				0,
				0))
			{
				throw OciException("Cannot allocate statement handle");
			}
		}


		void AllocDefineSupport(int maxRows)
		{
			try
			{
				if (NULL == m_pNullIndicators) m_pNullIndicators = reinterpret_cast<ORACLE_NS::OCIInd*>(malloc(m_columnCount * sizeof(ORACLE_NS::OCIInd) * maxRows));
				if (NULL == m_pNullIndicators) throw std::bad_alloc();
				if (NULL == m_pLengths) m_pLengths = reinterpret_cast<ORACLE_NS::ub2*>(malloc(m_columnCount * sizeof(ORACLE_NS::ub2) * maxRows));
				if (NULL == m_pLengths) throw std::bad_alloc();
				if (NULL == m_pRetCodes) m_pRetCodes = reinterpret_cast<ORACLE_NS::ub2*>(malloc(m_columnCount * sizeof(ORACLE_NS::ub2) * maxRows));;
				if (NULL == m_pRetCodes) throw std::bad_alloc();
				if (NULL == m_pDefineHandles)
				{
					m_pDefineHandles = reinterpret_cast<ORACLE_NS::OCIDefine**>(malloc(m_columnCount * sizeof(ORACLE_NS::OCIDefine*)));
					memset(m_pDefineHandles, 0, m_columnCount * sizeof(ORACLE_NS::OCIDefine*));
				}
				if (NULL == m_pDefineHandles) throw std::bad_alloc();
			}
			catch (std::bad_alloc&)
			{
				ReleaseDefineSupport();
				throw;
			}
		}

		void Release(void)
		{
			if (NULL != m_pStmt) ORACLE_NS::OCIHandleFree(m_pStmt, OCI_HTYPE_STMT);
			m_pStmt = NULL;
			m_columns.clear();

			ReleaseDefineSupport();
		}

		void ReleaseDefineSupport(void)
		{
			if (NULL != m_pNullIndicators) free(m_pNullIndicators);
			m_pNullIndicators = NULL;
			if (NULL != m_pLengths) free(m_pLengths);
			m_pLengths = NULL;
			if (NULL != m_pRetCodes) free(m_pRetCodes);
			m_pRetCodes = NULL;
			if (NULL != m_pDefineHandles) free(m_pDefineHandles);
			m_pDefineHandles = NULL;
		}

	public:

		void Describe(const std::string& sql)
		{
			Release();
			Alloc();

			ORACLE_NS::sword ret;

			ORACLE_NS::ub4 sqlLen = static_cast<ORACLE_NS::ub4>(sql.length() * sizeof(char));
			ret = ORACLE_NS::OCIStmtPrepare(m_pStmt,
				m_session.m_pErr,
				reinterpret_cast<ORACLE_NS::OraText*>(const_cast<char*>(sql.c_str())),
				sqlLen,
				OCI_NTV_SYNTAX,
				OCI_DEFAULT);
			if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_session.m_pErr);

			ret = ORACLE_NS::OCIStmtExecute(m_session.m_pSvcCtx,
				m_pStmt,
				m_session.m_pErr,
				0,
				0,
				NULL,
				NULL,
				OCI_DESCRIBE_ONLY);
			if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_session.m_pErr);

			ORACLE_NS::ub4 attrLen = sizeof(m_columnCount);
			ret = ORACLE_NS::OCIAttrGet(m_pStmt,
				OCI_HTYPE_STMT,
				&m_columnCount,
				&attrLen,
				OCI_ATTR_PARAM_COUNT,
				m_session.m_pErr );
			if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_session.m_pErr);

			for (ORACLE_NS::ub4 i = 1; i <= m_columnCount; ++i)
			{
				ORACLE_NS::OCIParam*	parameter;

				ret = ORACLE_NS::OCIParamGet(m_pStmt,
					OCI_HTYPE_STMT,
					m_session.m_pErr, 
					reinterpret_cast<dvoid**>(&parameter),
					i);
				if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_session.m_pErr);

				Column	column(parameter, m_session.m_pErr, i);
				m_columns.push_back(column);
			}
		}

		void Execute(const char* sql)
		{
			Execute(std::string(sql));
		}

		void Execute(const std::string& sql)
		{
			ORACLE_NS::sword ret;

			ORACLE_NS::ub4 sqlLen = static_cast<ORACLE_NS::ub4>(sql.length() * sizeof(char));
			ret = ORACLE_NS::OCIStmtPrepare(m_pStmt,
				m_session.m_pErr,
				reinterpret_cast<ORACLE_NS::OraText*>(const_cast<char*>(sql.c_str())),
				sqlLen,
				OCI_NTV_SYNTAX,
				OCI_DEFAULT);
			if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_session.m_pErr);

			ret = ORACLE_NS::OCIStmtExecute(m_session.m_pSvcCtx,
				m_pStmt,
				m_session.m_pErr,
				0,
				0,
				NULL,
				NULL,
				/*OCI_STMT_SCROLLABLE_READONLY*/ OCI_DEFAULT);
			if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_session.m_pErr);

			m_columnCount = 0;
			m_columns.clear();

			ORACLE_NS::ub4 attrLen = sizeof(m_columnCount);
			ret = ORACLE_NS::OCIAttrGet(m_pStmt,
				OCI_HTYPE_STMT,
				&m_columnCount,
				&attrLen,
				OCI_ATTR_PARAM_COUNT,
				m_session.m_pErr );
			if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_session.m_pErr);

			for (ORACLE_NS::ub4 i = 1; i <= m_columnCount; ++i)
			{
				ORACLE_NS::OCIParam*	parameter;

				ret = ORACLE_NS::OCIParamGet(m_pStmt,
					OCI_HTYPE_STMT,
					m_session.m_pErr, 
					reinterpret_cast<dvoid**>(&parameter),
					i);
				if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_session.m_pErr);

				Column	column(parameter, m_session.m_pErr, i);
				m_columns.push_back(column);
			}
		}

		void ExecuteImmediate(const std::string& sql)
		{
			ORACLE_NS::sword ret;

			ORACLE_NS::ub4 sqlLen = static_cast<ORACLE_NS::ub4>(sql.length() * sizeof(char));
			ret = ORACLE_NS::OCIStmtPrepare(m_pStmt,
				m_session.m_pErr,
				reinterpret_cast<ORACLE_NS::OraText*>(const_cast<char*>(sql.c_str())),
				sqlLen,
				OCI_NTV_SYNTAX,
				OCI_DEFAULT);
			if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_session.m_pErr);

			ret = ORACLE_NS::OCIStmtExecute(m_session.m_pSvcCtx,
				m_pStmt,
				m_session.m_pErr,
				1,
				0,
				NULL,
				NULL,
				OCI_DEFAULT);
			if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_session.m_pErr);

		}
		unsigned int Fetch(unsigned int maxRows)
		{
			ORACLE_NS::sword	ret;
			ORACLE_NS::ub4		rows = static_cast<ORACLE_NS::ub4>(maxRows);
			ORACLE_NS::ub4		rowsFetched = 0;

			ret = ORACLE_NS::OCIStmtFetch2(m_pStmt, m_session.m_pErr, rows, OCI_DEFAULT, 0, OCI_DEFAULT);
			if (!(OCI_NO_DATA == ret || OCI_SUCCESS == ret)) THROW_OCI_ERR(m_session.m_pErr);

			ORACLE_NS::ub4 sizep = sizeof(rowsFetched);
			ret = ORACLE_NS::OCIAttrGet(m_pStmt,
				OCI_HTYPE_STMT,
				reinterpret_cast<dvoid*>(&rowsFetched),
				&sizep,
				OCI_ATTR_ROWS_FETCHED,
				m_session.m_pErr);
			if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_session.m_pErr);

			return static_cast<unsigned int>(rowsFetched);
		}

		unsigned int Fetch(unsigned int maxRows, unsigned int startAt)
		{
			ORACLE_NS::sword	ret;
			ORACLE_NS::ub4		rows = static_cast<ORACLE_NS::ub4>(maxRows);
			ORACLE_NS::ub4		rowsFetched = 0;

			ret = ORACLE_NS::OCIStmtFetch2(m_pStmt, m_session.m_pErr, rows, OCI_FETCH_ABSOLUTE, startAt, OCI_DEFAULT);
			if (!(OCI_NO_DATA == ret || OCI_SUCCESS == ret)) THROW_OCI_ERR(m_session.m_pErr);

			ORACLE_NS::ub4 sizep = sizeof(rowsFetched);
			ret = ORACLE_NS::OCIAttrGet(m_pStmt,
				OCI_HTYPE_STMT,
				reinterpret_cast<dvoid*>(&rowsFetched),
				&sizep,
				OCI_ATTR_ROWS_FETCHED,
				m_session.m_pErr);
			if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_session.m_pErr);

			return static_cast<unsigned int>(rowsFetched);
		}

		// @access Implementation
	public:
		~Statement()
		{
		}

	private:

		Session&				m_session;
		ORACLE_NS::OCIStmt*		m_pStmt;
		ORACLE_NS::ub4			m_columnCount;
		ORACLE_NS::OCIInd*		m_pNullIndicators;
		ORACLE_NS::ub2*			m_pLengths;
		ORACLE_NS::ub2*			m_pRetCodes;
		ORACLE_NS::OCIDefine**	m_pDefineHandles;
		ColumnsType				m_columns;

		friend class Column;
		friend class TextEmitter;
	};

	class TextEmitter
		: public Column
	{
	public:
		TextEmitter(Statement& statement, const Column& other, unsigned int maxRows)
		: Column(other)
		, m_statement(statement)
		, m_maxRows(maxRows)
		, m_pDefine(NULL)
		, m_pNullIndicators(NULL)
		, m_pLengths(NULL)
		, m_pRetCodes(NULL)
		, m_buffer(NULL)
		, m_emitLength(0)
		{
		}

		TextEmitter(const TextEmitter& other)
		: Column(other)
		, m_statement(other.m_statement)
		, m_maxRows(other.m_maxRows)
		, m_pDefine(NULL)
		, m_pNullIndicators(NULL)
		, m_pLengths(NULL)
		, m_pRetCodes(NULL)
		, m_buffer(NULL)
		, m_emitLength(other.m_emitLength)
		{
		}

		unsigned int get_EmitLength(void) const
		{
			return m_emitLength;
		}

		void DefineForFetch(void)
		{
			ORACLE_NS::ub4	ret;

			// Assume we can handle the native Oracle data type
			ORACLE_NS::ub2	typeToDefine = m_dataType;
			ORACLE_NS::ub2	sizeToDefine = m_dataSize;

			// Coerce the native Oracle types we cannot handle to other types
			if (SQLT_TIMESTAMP == m_dataType) sizeToDefine = sizeof(ORACLE_NS::OCIDateTime*);
			if (SQLT_DAT == m_dataType)
			{
#ifdef TARGET_WIN32
				// Use the OciDateTime type for Windows
				typeToDefine = SQLT_ODT;
#else
				// For UNIX let the Oracle client convert
				typeToDefine = SQLT_AFC;
				sizeToDefine = 10;
#endif
			}
			//if (SQLT_NUM == m_dataType) typeToDefine = SQLT_VNU;

			// We'll need a buffer to handle the size of the column for as many rows
			size_t	bufferSize = m_maxRows * sizeToDefine;

			try
			{
				if (NULL == m_pNullIndicators) m_pNullIndicators = reinterpret_cast<ORACLE_NS::OCIInd*>(malloc(m_maxRows * sizeof(ORACLE_NS::OCIInd)));
				if (NULL == m_pNullIndicators) throw std::bad_alloc();
				if (NULL == m_pLengths) m_pLengths = reinterpret_cast<ORACLE_NS::ub2*>(malloc(m_maxRows * sizeof(ORACLE_NS::ub2)));
				if (NULL == m_pLengths) throw std::bad_alloc();
				if (NULL == m_pRetCodes) m_pRetCodes = reinterpret_cast<ORACLE_NS::ub2*>(malloc(m_maxRows * sizeof(ORACLE_NS::ub2)));;
				if (NULL == m_pRetCodes) throw std::bad_alloc();
				if (NULL == m_buffer)
				{
					m_buffer = reinterpret_cast<unsigned char*>(malloc(bufferSize));
					if (NULL == m_buffer) throw std::bad_alloc();

					switch (m_dataType)
					{
					default:
						{
							char	szMsg[48];
							sprintf_s(szMsg, _countof(szMsg), "Unhandled datatype: %d", m_dataType);
							throw std::logic_error(szMsg);
							break;
						}
					case SQLT_DAT:
						{
							m_format = "YYYY-MM-DD";
							m_emitLength = 10;
							break;
						}
					case SQLT_NUM:
						{
							char	szFmt[48];
							int		fmtLen;

							if ( m_scale > 0 )
							{
								fmtLen = sprintf_s( szFmt, _countof(szFmt), "S%0*.*dD%*.*s",
									m_precision - m_scale,
									m_precision - m_scale,
									9,
									m_scale,
									m_scale,
									"99999999999999999999999999999999"
									);
							}
							else
							{
								fmtLen = sprintf_s( szFmt, _countof(szFmt),"S%0*.*d",
									m_precision,
									m_precision,
									9
									);
							}
							m_format = szFmt;
							m_emitLength = fmtLen;
							break;
						}
					case SQLT_TIMESTAMP:
						{
							m_format = "YYYY-MM-DD.HH24.MI.SS.FF6";
							ORACLE_NS::OCIDateTime** p = reinterpret_cast<ORACLE_NS::OCIDateTime**>(m_buffer);
							for (unsigned int n = 0; n < m_maxRows; ++n)
							{
								ret = ORACLE_NS::OCIDescriptorAlloc(m_statement.m_session.m_pEnv,
									reinterpret_cast<dvoid**>(p),
									OCI_DTYPE_TIMESTAMP,
									0,
									NULL);
								if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_statement.m_session.m_pErr);
								++p;
							}
							m_emitLength = 29;
							break;
						}
					case SQLT_CHR:
					case SQLT_AFC:
						{
							m_emitLength = m_dataSize;
							break;
						}
					}
				}
			}
			catch (std::bad_alloc&)
			{
				throw;
			}

			ret = ORACLE_NS::OCIDefineByPos(m_statement.m_pStmt,
				&m_pDefine,
				m_statement.m_session.m_pErr,
				m_position,
				m_buffer,
				sizeToDefine,
				typeToDefine,
				m_pNullIndicators,
				m_pLengths,
				m_pRetCodes,
				OCI_DEFAULT);
			if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_statement.m_session.m_pErr);

			ORACLE_NS::ub4	skip = sizeToDefine/*m_dataSize*/;
			if (SQLT_TIMESTAMP == m_dataType) skip = sizeof(ORACLE_NS::OCIDateTime*);
#ifndef TARGET_WIN32
			if (SQLT_DAT == m_dataType) skip = 10;
#endif

			ret = ORACLE_NS::OCIDefineArrayOfStruct(m_pDefine,
				m_statement.m_session.m_pErr,
				skip,
				sizeof(ORACLE_NS::OCIInd),
				sizeof(ORACLE_NS::ub2),
				sizeof(ORACLE_NS::ub2));
			if (OCI_SUCCESS != ret) THROW_OCI_ERR(m_statement.m_session.m_pErr);
		}


		unsigned int Emit(unsigned int row, unsigned char* buffer, void* pvErr, void* pvEnv) const
		{
			ORACLE_NS::OCIError* pErr = reinterpret_cast<ORACLE_NS::OCIError*>(pvErr);
			ORACLE_NS::OCIEnv* pEnv = reinterpret_cast<ORACLE_NS::OCIEnv*>(pvEnv);

			if (((ORACLE_NS::OCIInd)(-1)) == m_pNullIndicators[row])
			{
				buffer[0] = '~';
				memset(&buffer[1], ' ', m_emitLength - 1);
			}
			else
			{
				ORACLE_NS::ub2	sizeToDefine = m_dataSize;
				unsigned char*	columnData = m_buffer + (row * sizeToDefine);
				ORACLE_NS::ub4	ret;

				switch (m_dataType)
				{
				case SQLT_DAT:
					{
#ifndef TARGET_WIN32
						columnData = m_buffer + (row * 10);
						memcpy(buffer, columnData, 10);
#else
						ret = sprintf_s(reinterpret_cast<char*>(buffer), m_emitLength + 1,
							"%04d-%02d-%02d",
							reinterpret_cast<ORACLE_NS::OCIDate*>(columnData)->OCIDateYYYY,
							reinterpret_cast<ORACLE_NS::OCIDate*>(columnData)->OCIDateMM,
							reinterpret_cast<ORACLE_NS::OCIDate*>(columnData)->OCIDateDD);

						//ORACLE_NS::ub4 bufferSize = static_cast<ORACLE_NS::ub4>(m_format.length());
						//ret = ORACLE_NS::OCIDateToText(pErr,
						//	reinterpret_cast<ORACLE_NS::OCIDate*>(columnData),
						//	reinterpret_cast<const ORACLE_NS::oratext*>(m_format.c_str()),
						//	static_cast<ORACLE_NS::ub1>(m_format.length()),
						//	NULL, 0,
						//	&bufferSize,
						//	buffer);
						//if (OCI_SUCCESS != ret) throw OciException(pErr);
#endif
						break;
					}
				case SQLT_NUM:
					{
						ret = EmitNumber(reinterpret_cast<ORACLE_NS::OCINumber*>(columnData),
							m_pLengths[row],
							buffer);

						/*
						unsigned char	num[OCI_NUMBER_SIZE + 1];
						num[0] = static_cast<ORACLE_NS::ub1>(m_pLengths[row]);
						memcpy(&num[1], columnData, m_pLengths[row]);
						unsigned char numText[64];

						ORACLE_NS::ub4 bufferSize = static_cast<ORACLE_NS::ub4>(m_format.length());
						ORACLE_NS::ub4 rc = ORACLE_NS::OCINumberToText(pErr,
							reinterpret_cast<ORACLE_NS::OCINumber*>(&num[0]),
							reinterpret_cast<const ORACLE_NS::oratext*>(m_format.c_str()),
							static_cast<ORACLE_NS::ub4>(m_format.length()),
							NULL, 0,
							&bufferSize,
							numText);
						if (OCI_SUCCESS != rc) throw OciException(pErr);
						assert(ret == bufferSize);
						assert(0 == memcmp(numText, buffer, bufferSize));
						//*/
						// --------------------------------------------------------------
						// Ensure numbers are extracted as SQLT_VNU for OCINumberToText
						// --------------------------------------------------------------
						//bufferSize = static_cast<ORACLE_NS::ub4>(m_format.length());
						//ret = ORACLE_NS::OCINumberToText(pErr,
						//	reinterpret_cast<ORACLE_NS::OCINumber*>(columnData),
						//	reinterpret_cast<const ORACLE_NS::oratext*>(m_format.c_str()),
						//	static_cast<ORACLE_NS::ub4>(m_format.length()),
						//	NULL, 0,
						//	&bufferSize,
						//	buffer);
						//if (OCI_SUCCESS != ret) throw OciException(pErr);
						break;
					}
				case SQLT_TIMESTAMP:
					{
						columnData = m_buffer + (row * sizeof(ORACLE_NS::OCIDateTime*));

						ORACLE_NS::sb2	year;
						ORACLE_NS::ub1	month;
						ORACLE_NS::ub1	day;
						ORACLE_NS::ub1	hour;
						ORACLE_NS::ub1	minute;
						ORACLE_NS::ub1	second;
						ORACLE_NS::ub4	fsecond;

						ret = ORACLE_NS::OCIDateTimeGetDate(pEnv, pErr,
							*reinterpret_cast<ORACLE_NS::OCIDateTime**>(columnData),
							&year, &month, &day);
						if (OCI_SUCCESS != ret) THROW_OCI_ERR(pErr);

						ret = ORACLE_NS::OCIDateTimeGetTime(pEnv, pErr,
							*reinterpret_cast<ORACLE_NS::OCIDateTime**>(columnData),
							&hour, &minute, &second, &fsecond);
						if (OCI_SUCCESS != ret) THROW_OCI_ERR(pErr);

						// Format as a textual timestamp value
						ret = sprintf_s(reinterpret_cast<char*>(buffer), m_emitLength + 1,
							"%04d-%02d-%02d.%02d.%02d.%02d.%09d",
							year, month, day, hour, minute, second, fsecond);

						// Truncate the fractional seconds
						buffer[26] = ' ';
						buffer[27] = ' ';
						buffer[28] = ' ';

						/*
						bufferSize = 28;
						ret = ORACLE_NS::OCIDateTimeToText(pEnv,
						pErr,
						*reinterpret_cast<ORACLE_NS::OCIDateTime**>(columnData),
						reinterpret_cast<const ORACLE_NS::oratext*>(m_format.c_str()),
						static_cast<ORACLE_NS::ub1>(m_format.length()),
						6,
						NULL, 0,
						&bufferSize,
						buffer);
						if (OCI_SUCCESS != ret) throw OciException(pErr);
						*/
						break;
					}
				case SQLT_CHR:
				case SQLT_AFC:
					{
						//memcpy(buffer, columnData, m_emitLength);
						memcpy(buffer, columnData, m_pLengths[row]);
						memset(&buffer[m_pLengths[row]], ' ', m_emitLength - m_pLengths[row]);
						break;
					}
				default:
					{
						ret = m_emitLength;
						break;
					}
				}

			}

			return m_emitLength;
		}

		unsigned int EmitControlCardStatement(std::ostream& os,
			unsigned int startPosition,
			unsigned int maxColumnName,
			unsigned int maxPositionDigits)
		{
			std::ostringstream pos;
			pos << "POSITION(" << startPosition << ':' << startPosition + m_emitLength - 1 << ")";

			os
				<< "	"
				<< std::left
				<< std::setw(maxColumnName)
				<< m_name
				<< ' '
				<< std::setw(8 + 1 + maxPositionDigits + 1 + maxPositionDigits + 1)
				<< pos.str()
				<< ' '
				;

			switch ( m_dataType )
			{
			case SQLT_NUM:
				{
					os << "DECIMAL EXTERNAL";
					break;
				}

			case SQLT_DAT:
				{
					os << "DATE 'YYYY-MM-DD'";
					break;
				}
			case SQLT_TIMESTAMP:
				{
					os << "TIMESTAMP 'YYYY-MM-DD.HH24.MI.SS.FF6'";
					break;
				}
			case SQLT_CHR:
			case SQLT_AFC:
				{
					os << "CHAR(" << m_emitLength << ')';
					break;
				}
			default:
				{
					break;
				}
			}

			/*
			// WEB
			//	  fprintf(stdout, "column name is %s\t\n",pDescO[idx].colNme);
			//	  fprintf(stdout, "nullok is %d\t\n",pDescO[idx].nullok);
			*/

			if ( m_nullable )
			{
			os
				<< std::endl
				<< "	"
				<< std::left
				<< std::setw(maxColumnName)
				<< " "
				<< ' '
				<< std::setw(8 + 1 + maxPositionDigits + 1 + maxPositionDigits + 1)
				<< " "
				<< " NULLIF ("
				<< startPosition << ':' << startPosition
				<< ") = '~'"
				;
			}

			return m_emitLength;
		}

		unsigned int EmitNumber(const ORACLE_NS::OCINumber* pNumber, ORACLE_NS::ub4 numberLen, unsigned char* buffer) const
		{
#define Get_Sign(on) ((on)->OCINumberPart[0] & 0x80)
#define Get_Exp_Part(on) ((on)->OCINumberPart[0] & 0x7F)
#define Get_Exponent(on) (Get_Sign(on) ? (Get_Exp_Part(on) - 65) : (~(Get_Exp_Part(on)) + 63))
#define Get_Mantissa_At(on, i) (Get_Sign(on) ? ((on)->OCINumberPart[i+1]) - 1 : 101 - ((on)->OCINumberPart[i+1]))

			int exponent;
			int j;

			if (0x80 == pNumber->OCINumberPart[0])
			{
				unsigned int length = 1 + m_precision + ((m_scale > 0) ? 1 : 0);

				// A zero is always positive
				buffer[0] = '+';
				if ( m_scale > 0 )
				{
					/*
					-------------- BACKWARDS COMPATIBILITY -----------------
					The previous version of the unloader used S9D99, for example
					which emits .5 as +.50 rather than +0.50 (e.g. the pattern
					should have been S0D99).  Maintain that distinction here:
					-------------- BACKWARDS COMPATIBILITY -----------------
					*/
					if (1 == (m_precision - m_scale))
					{
						buffer[0] = ' ';
						buffer[1] = Get_Sign(pNumber)
							? '+'
							: '-';
						buffer[2] = '.';

						memset(&buffer[3], '0', m_scale);
					}
					else
					{
						// +00000.00 for example
						memset(buffer + 1, '0', m_precision - m_scale);
						buffer[1 + m_precision - m_scale] = '.';
						memset(buffer + 1 + m_precision - m_scale + 1, '0', m_scale);
					}
				}
				else
				{
					if (0 == m_precision + m_scale)
					{
						buffer[1] = '0';
						length = 2;
					}
					else
					{
						// +000 for example
						memset(buffer + 1, '0', m_precision);
					}
				}

				return length;
			}

			// Do not include the sign/exponent byte in the digits
			unsigned int digitBytes = numberLen - 1;
			if (!Get_Sign(pNumber))
			{
				// Skip the 102 at the end of the negative number
				digitBytes -= 1;
			}

			// Where is the decimal point?
			exponent = Get_Sign(pNumber)
				? (pNumber->OCINumberPart[0] & 0x7F) - 64
				: ((~pNumber->OCINumberPart[0]) & 0x7F) - 64
				;

			//unsigned char	number[40];
			//memset(number, 0, sizeof(number));
			//int idx = 0;
			//{
			//	for (i = 0; i < digitBytes; ++i )
			//	{
			//		if (idx == exponent * 2) number[idx++] = '.';
			//		j = Get_Mantissa_At(pNumber, i);
			//		//if (! (0 == i && 0 == j / 10) )  
			//		{
			//			number[idx++] = j / 10 + '0';
			//			//if (idx == exponent) number[idx++] = '.';
			//		}
			//		number[idx++] = j % 10 + '0';
			//		//if (idx == exponent) number[idx++] = '.';
			//	}
			//}
			//while (idx < exponent * 2)
			//{
			//	number[idx++] = '0';
			//	number[idx++] = '0';
			//}

			// Convert each base-100 byte into an ASCII representation
			// of that number.  Differentiaite between the integral 
			// portion of the number and the fractional portion.
			unsigned char	integer[38] = { 0 };
			//memset(integer, 0, sizeof(integer));
			unsigned int	integerDigits = 0;
			unsigned char	fraction[38] = { 0 };
			//memset(fraction, 0, sizeof(fraction));
			unsigned int	fractionDigits = 0;

			int digits = 0;
			unsigned char*	p = integer;
			unsigned int*	pDigits = &integerDigits;

			if (0 > exponent)
			{
				p = fraction;
				pDigits = &fractionDigits;
				while (digits < (abs(exponent) * 2))
				{
					*p++ = '0';
					*pDigits += 1;
					++digits;
				}
			}

			for (unsigned int i = 0; i < digitBytes; ++i )
			{
				if (digits == exponent * 2)
				{
					p = fraction;
					pDigits = &fractionDigits;
				}
				j = Get_Mantissa_At(pNumber, i);
				*p++ = static_cast<unsigned char>(j / 10) + '0';
				*pDigits += 1;
				++digits;
				*p++ = static_cast<unsigned char>(j % 10) + '0';
				*pDigits += 1;
				++digits;
			}

			while (digits < exponent * 2)
			{
				*p++ = '0';
				*pDigits += 1;
				++digits;
			}

			//unsigned char	result[128];
			//memset(result, 0, sizeof(result));

			// All numbers have a sign (gag! a bad '70s thing)
			buffer[0] = Get_Sign(pNumber)
				? '+'
				: '-';

			// Fill the output pattern
			p = &buffer[1];
			memset(p, '0', m_precision + ((m_scale > 0) ? 1 : 0));
			if (0 < m_scale) p[m_precision - m_scale] = '.';

			if ('0' == integer[0])
			{
				// Ignore leading the zero in the integer portion
				// (we emitted them for the digit count of for the
				// exponent but do not need it now).
				memcpy(p 
						+ m_precision 
						- m_scale 
						- integerDigits + 1,
					&integer[1],
					integerDigits - 1);
			}
			else
			{
				memcpy(p 
						+ m_precision 
						- m_scale
						- integerDigits,
					&integer[0],
					integerDigits);
			}

			/*
			-------------- BACKWARDS COMPATIBILITY -----------------
			The previous version of the unloader used S9D99, for example
			which emits .5 as +.50 rather than +0.50 (e.g. the pattern
			should have been S0D99).  Maintain that distinction here:
			-------------- BACKWARDS COMPATIBILITY -----------------
			*/
			if (0 < fractionDigits)
			{
				if (0 == integerDigits && 1 == (m_precision - m_scale))
				{
					buffer[0] = ' ';
					buffer[1] = Get_Sign(pNumber)
						? '+'
						: '-';
					buffer[2] = '.';

					memset(&buffer[3], '0', m_scale);
					memcpy(&buffer[3], fraction, fractionDigits);
				}
				else
				{
					// Tack on the fraction
					memcpy(p + m_precision - m_scale + 1,
						fraction,
						fractionDigits);
				}
			}

			// We always format the full numeric plus a sign
			// and a decimal point if needed.
			return 1 + m_precision + ((m_scale > 0) ? 1 : 0);

#undef Get_Sign
#undef Get_Exp_Part
#undef Get_Exponent
#undef Get_Mantissa_At
		}

		void ReleaseFromStatement(void)
		{
			if (NULL != m_pNullIndicators) free(m_pNullIndicators);
			m_pNullIndicators = NULL;
			if (NULL != m_pLengths) free(m_pLengths);
			m_pLengths = NULL;
			if (NULL != m_pRetCodes) free(m_pRetCodes);
			m_pRetCodes = NULL;
			if (NULL != m_buffer)
			{
				if (SQLT_TIMESTAMP == m_dataType)
				{
					ORACLE_NS::OCIDateTime** p = reinterpret_cast<ORACLE_NS::OCIDateTime**>(m_buffer);
					for (unsigned int n = 0; n < m_maxRows; ++n)
					{
						ORACLE_NS::OCIDescriptorFree(*p, OCI_DTYPE_TIMESTAMP);
						++p;
					}
				}
			}
			m_buffer = NULL;		

		}

		TextEmitter& operator =(const TextEmitter& rhs)
		{
			if (this != &rhs)
			{
				Column::operator =(rhs);
				ReleaseFromStatement();
				memcpy(&m_statement, &rhs.m_statement, sizeof(m_statement)); // ??? Why this construct in WIN32?
				m_maxRows = rhs.m_maxRows;
				m_emitLength = rhs.m_emitLength;
			}
			return *this;
		}

		~TextEmitter()
		{
			ReleaseFromStatement();
		}
	private:
		Statement&				m_statement;
		unsigned int			m_maxRows;
		ORACLE_NS::OCIDefine*	m_pDefine;
		ORACLE_NS::OCIInd*		m_pNullIndicators;
		ORACLE_NS::ub2*			m_pLengths;
		ORACLE_NS::ub2*			m_pRetCodes;
		unsigned char*			m_buffer;
		std::string				m_format;
		unsigned int			m_emitLength;
	};

	std::string CreateTableOrViewSelect( Session& session,
		const std::string& tableOrViewName,
		ColumnsType& columns)
	{
		std::string	sql("select * from ");
		sql.append(tableOrViewName);

		Statement	stmt(session);

		stmt.Describe(sql);

		std::ostringstream	sqlToChar;
		sqlToChar << "select ";

		ColumnsType::const_iterator it = stmt.Columns().begin();
		ColumnsType::const_iterator itE = stmt.Columns().end();
		for (int i = 1; it != itE; ++it, ++i)
		{
			columns.push_back(*it);

			if (1 != i) sqlToChar << ", ";

			const std::string&	pszColName = (*it).get_Name();

			int	dataType = (*it).get_DataType();
			switch ( dataType )
			{
			case SQLT_NUM:
				{
					int precision = (*it).get_Precision();
					int scale = (*it).get_Scale();

					char	szFmt[48];

					if ( scale > 0 )
					{
						sprintf_s( szFmt, _countof(szFmt), "S%0*.*dD%*.*s",
							precision - scale,
							precision - scale,
							9,
							scale,
							scale,
							"99999999999999999999999999999999"
							);
					}
					else
					{
						sprintf_s( szFmt, _countof(szFmt), "S%0*.*d",
							precision,
							precision,
							9
							);
					}
					sqlToChar << "TO_CHAR(" << pszColName << ", '" << szFmt << "')";
					break;
				}

			case SQLT_INT:
				{
					sqlToChar << "TO_CHAR(" << pszColName << ", 'S000000009')";
					break;
				}

			case SQLT_DAT:
			case SQLT_DATE:
				{
					sqlToChar << "TO_CHAR(" << pszColName << ", 'YYYY-MM-DD')";
					break;
				}

			case SQLT_TIMESTAMP:
			case SQLT_TIMESTAMP_TZ:
			case SQLT_TIMESTAMP_LTZ:
			case SQLT_INTERVAL_YM:
			case SQLT_INTERVAL_DS:
				{
					sqlToChar << "TO_CHAR(" << pszColName << ", 'YYYY-MM-DD.HH24.MI.SS.FF6')";
					break;
				}
			default:
				{
					if (!(SQLT_CHR == dataType
						|| SQLT_VCS == dataType
						|| SQLT_AFC == dataType
						|| SQLT_AVC == dataType))
					{
						std::ostringstream	error;
						error << "Unable to convert datatype "
							<< dataType;
						THROW_OCI_ERR(error.str());
					}

					sqlToChar << pszColName;
					break;
				}
			}
		}
		sqlToChar << " from " << tableOrViewName;

		return std::string(sqlToChar.str());
	}

}

/* http://kr.forums.oracle.com/forums/thread.jspa?messageID=1640249

Subject : Number DataType
-------------------------
This article attempts to explain, with examples, the ORACLE Number
datatype (type 2) as stored internally. Oracle Corporation reserves the
right to change this internal representation at any time without reason
and notice. Numeric data is stored internaly in variable length format,
and consists of two parts
- SIGN/EXPONENT Byte (1st byte)
- DATA Byte(s) (2nd byte onwards)

SIGN/EXPONENT BYTE : The sign/exponent byte is divided into two parts
again 

- Sign bit (high-order bit)
- Exponent bits (lower order 7 bits)

The key to the calculation of a number is the sign bit which can
take values 0 for negative and 1 for positive numbers.

The 7 lower order bits are the exponent, stored in excess 64 notation
i.e. whatever the number you calculate from the 7 bits, you will have to
deduct 64 from it to determine exponent value. 
The Sign/Exponent byte is evaluated as follows -

If the sign bit is set then the number is positive and the exponential
is calculated in the following manner Determine the value of the exponent 
using the lower order 7 bits. As this value is in excess 64 notation,
deduct 64 from this number that was calculated to give the exponent value.

E.g. Assume the SIGN/EXPONENT byte was 223 which in binary is 11011111.
From the binary representation of the example we determine that bit 8 is
set, hence this is a positive number. To determine the exponent, clear
bit 8 and then calculate the resultant which in this case is 95. As 95 is
in excess 64 notation deduct 64 from it to give 31, which is the exponent.

If the sign bit is cleared i.e. 0 (number is negative), a little more 
work goes into calculating the number. 
Perform a 1's complement of the sign/exponent byte (all 8 bits) 
Determine the value of the exponent using the lower order 7 bits. As this
value is in excess 64 notation, deduct 64 from the value that was
calculated to give the exponent value. 
E.g. Assume the SIGN/EXPONENT byte was 100 which in binary is 01100100.
From the binary representation we can determine that the number is
negative as bit 8 is clear. Now take the 1's complement of 01100100 to
give 10011011. Mask of bit 8 (or just set it to 0) so that only bits 1
through 7 are used to calculate the exponent which in our example will be
27. As 27 is in excess 64 notation, deduct 64 from it to give -37. Hence,
exponent is -37.
DATA BYTE(s) : Data is stored in a series of bytes with the
representation being in base 100. To avoid a binary zero a 1 is added to
the number. Hence, each data byte represents digits in base 100 with
values ranging from 1 to 100 representing values 0 to 99.
Negative numbers have a terminator byte with a value of 102.

Let us take some examples and then try to understand the methodology of
the calculation. These examples work off a table with the following 
description. 

SQL> describe num_tab 
Name Null? Type
------------------------------- -------- ----
C1 NUMBER

CASE 1 : insert number 123456. Dump of column c1 gives the following 

DUMP(C1)
------------------------------------------
Typ=2 Len=4: 195,13,35,57 

1st byte = 195 decimal --> 11000011 binary
Number is positive as bit 8 is set. The exponent value is 01000011 
binary which is 67 decimal. As this number is in excess 64 notation 
deduct 64 from 67 giving 3. Exponent is 3 and positive. 

2nd byte = 13 decimal 
As the sign is positive deduct 1 from 13 (as it is stored with one added)
to get 12

3rd byte = 35 decimal

As the sign is positive deduct 1 from 35 to get 34

4th byte = 57 decimal

As the sign is positive, deduct 1 from 57 to get 56

The exponent is 3, the data bytes are in base 100, so the number is 

12 x (100 e 2) + 34 x (100 e 1) + 56 x (100 e 0) = 123456 

CASE 2 : insert number -123456. Dump c1 gives the following 

DUMP(C1)
------------------------------------------ 
Typ=2 Len=5: 60,89,67,45,102 
1st byte = 60 decimal --> 00111100 binary 
Number is negative as bit 8 is not set. Take the 1's complement of 
00111100 which is 11000011. From this the exponent is 67 decimal (take 
the lower order 7 bits to calculate the exponent). As this number is in
excess 64 notation deduct 64 from 67 giving 3. Exponent is positive and
is 3.

2nd byte = 89 decimal

Deduct 1 from this which gives 88. As the sign is negative, you need to
take the 100's complement of this i.e. 100 - 88 to get 12. 

3rd byte = 67 decimal
Deduct 1 from this which gives 66 and take the 100's complement to get
34.
4th byte = 45 decimal

Deduct 1 from this which gives 44 and take the 100's complement to get 
56.

5th byte = 102 decimal
This is the last byte. 

The calculation is

12 x (100 e 2) + 34 x (100 e 1) + 56 x (100 e 0) = 123456 
and as the sign is negative, the answer is -123456. 

CASE 3 : insert number 123456.789. Dump (c1) gives the following 

DUMP(C1)
------------------------------------------ 
Typ=2 Len=6: 195,13,35,57,79,91 
1st byte = 195 --> 11000011 binary 
Number is positive as bit 8 is set. The exponent value is 01000011 binary
which is 67 decimal. As this number is in excess 64 notation deduct 64
from 67 giving 3 which is a positive number. 

2nd byte = 13 decimal 
As the sign is positive, deduct 1 from 13 to get 12. 

3rd byte = 35 decimal 
As the sign is positive, deduct 1 from 35 to get 34. 

4th byte = 57 decimal 
As the sign is positive, deduct 1 from 57 to get 56. 

5th byte = 79 decimal 
As the sign is positive, deduct 1 from 79 to get 78. 

6th byte = 91 decimal 
As the sign is positive, deduct 1 from 91 to get 90. The exponent is 3,
the data bytes are in base 100, so the number is 
12 x (100 e 2) + 34 x (100 e 1) + 56 x (100 e 0) + 78 x (100 e -1) + 
90 x (100 e -2) = 123456.789 
CASE 4 : insert number -123456.789 Dump of c1 gives the following 

DUMP(C1) 
------------------------------------------ 
Typ=2 Len=7: 60,89,67,45,23,11,102 
1st byte = 60 decimal --> 00111100 binary 
Number is negative as bit 8 is not set. Take the 1's complement of 
00111100 which is 11000011. From this the exponent is 67 decimal 
(take the lower order 7 bits to calculate the exponent). As this number is
in excess 64 notation deduct 64 from 67 giving 3. Exponent is positive 
and is 3. 

2nd byte = 89 decimal 
Deduct 1 from this which give 88. As the sign is negative, you need to 
take the 100's complement of this i.e. 100 - 88 to get 12. 

3rd byte = 67 decimal 
Deduct 1 from this which give 66. As the sign is negative, you need to
take the 100's complement of this i.e. 100 - 66 to get 34. 

4th byte = 45 decimal 
Deduct 1 from this which give 44. As the sign is negative, you need to 
take the 100's complement of this i.e. 100 - 44 to get 56. 

5th byte = 23 decimal 
Deduct 1 from this which give 22. As the sign is negative, you need to
take the 100's complement of this i.e. 100 - 22 to get 78. 
6th byte = 11 decimal 
Deduct 1 from this which give 11. As the sign is negative, you need to
take the 100's complement of this i.e. 100 - 11 to get 89. 
7th byte = 102 decimal 
This is the last byte. 
The calculation is 
12 x (100 e 2) + 34 x (100 e 1) + 56 x (100 e 0) + 78 x (100 e -1) + 
90 x (100 e -2) = 123456.789 
and as the sign is negative, the answer is -123456.789 

The above explanation is intended to further the knowledge of ORACLE's 
internal datatype representation only. 

Note : Given below are examples of calculating the 1's and 100's
complement.
1's complement of 10001100 = 01110011 (just 'not' the bits) 100's 
complement of 26 = 100 - 26 = 74 

*/

#endif	// ! defined(SIMPLEOCIWRAPPER_H_F49E2FC5_4D7F_447C_BC67_5C590C6A42BB_INCLUDED)

