/*
 **********************************************************************
 *
 * Metavance
 * Copyright (C) 2001-2008, EDS
 * All Rights Reserved.
 *
 * EDS
 * 225 Grandview Avenue
 * Camp Hill, PA  USA
 * http: *www.eds.com
 *
 * This source code is the confidential property of EDS, All
 * proprietary rights, including but not limited to any trade secret,
 * copyright, patent, or trademark rights in and to this source code
 * are the property of EDS.  This source code is not to be used,
 * disclosed or reproduced in any form without the express written
 * consent of EDS.
 *
 **********************************************************************
 */
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <algorithm>
#include <cctype>
#include <cstdarg>
#include <deque>
#include <fstream>
#include <functional>
#include <iostream>
#include <limits>
#include <locale>
#include <stdexcept>
#include <string>
#include <vector>

#if defined(TARGET_WIN32) || defined(_MSC_VER)
#include <windows.h>
#include <io.h>
#include <share.h>
#else
#include <alloca.h>
#include <libgen.h>
#include <pthread.h>
#include <semaphore.h>
#if defined(__INTERIX) || defined(TARGET_LINUX)
#include <string.h>
#include <strings.h>
#endif
#include <wchar.h>
#include <unistd.h>
#define _fileno		fileno
#define	_strnicmp	strncasecmp
#define _countof(x)	(sizeof(x)/sizeof(x[0]))

int sprintf_s(char* d, size_t, const char* f, ...)
{
	va_list args;
	va_start( args, f );
	int ret = vsprintf(d, f, args);
	va_end(args);
	return ret;
}
#endif

namespace OracleOci
{
#include <oci.h>
}
#define	ORACLE_NS	OracleOci

#include "SimpleOciWrapper.h"
#include "ExtractBuffer.h"
#include "CommandLineParser.h"

#ifdef TARGET_WIN32
#include "Win32SingleThreadedFileWriter.h"
#else
#include "SingleThreadedFileWriter.h"
#endif

static	unsigned int			g_rowsToFetch = 100;
static	std::string				g_selectStatement;

static	FileWriters::FileWriter*	g_pWriter = NULL;
static	unsigned int				g_totalFetched = 0;
static	unsigned int				g_totalEmitted = 0;
#ifdef TARGET_WIN32
static	unsigned int				g_recordLength = 2;
#else
static	unsigned int				g_recordLength = 1;
#endif

static ExtractBufferList	g_freeBuffers;
static ExtractBufferList	g_filledBuffers;

static   void print_ctl( std::ostream& os, const std::vector<OCI::TextEmitter*>& columns, const std::string& tableName )
{
	unsigned int	position = 1;
	unsigned int	maxColumnName = 0;

	// Get the longest column name and the maximum position
	for ( std::vector<OCI::Column>::size_type idx = 0; idx < columns.size(); idx++ )
	{
		if (maxColumnName < columns[idx]->get_Name().length())
		{
			maxColumnName = columns[idx]->get_Name().length();
		}

		position += columns[idx]->get_EmitLength();
	}
	char	szPos[64];
	unsigned int	maxPosStr = sprintf_s(szPos, _countof(szPos), "%u", position);

	os  << "  LOAD DATA PRESERVE BLANKS" << std::endl
		<< "  INTO TABLE " << tableName << std::endl
		<< "  TRUNCATE\n  FIELDS TERMINATED BY \'|\' OPTIONALLY ENCLOSED BY \'^\'"  << std::endl
		<< "  TRAILING NULLCOLS"  << std::endl
		<< "  (" << std::endl
		;

	position = 1;
	for ( std::vector<OCI::Column>::size_type idx = 0; idx < columns.size(); idx++ )
	{
		if (0 != idx) os << ',' << std::endl;

		position += columns[idx]->EmitControlCardStatement(os, position, maxColumnName, maxPosStr);
	}
	os << std::endl << "  )" << std::endl;
}


#ifdef TARGET_WIN32
static DWORD __stdcall ConvertThread(void* pvArg)
#else
static void* ConvertThread(void* pvArg)
#endif
{
	// Reference unused parameters
	pvArg = pvArg;

	// Locals
	unsigned int			thisFetch = 0;
	ORACLE_NS::OCIEnv*		pEnv = NULL;
	ORACLE_NS::OCIError*	pErr = NULL;
	ORACLE_NS::sword		ret = 0;

	try
	{

		// Create an OCI environment and error object for this thread.  Using the
		// main thread's object handles will force synchronization between the threads
		// which is undesireable.
		ret = ORACLE_NS::OCIEnvNlsCreate(&pEnv, OCI_THREADED, NULL, NULL, NULL, NULL, 0, NULL, OCI_DEFAULT, OCI_DEFAULT);
		if (OCI_SUCCESS != ret) throw OCI::OciException("Cannot create environment");
		ret = ORACLE_NS::OCIHandleAlloc(pEnv, reinterpret_cast<void**>(&pErr), OCI_HTYPE_ERROR, 0, 0);
		if (OCI_SUCCESS != ret) throw OCI::OciException("Cannot error handle");

		// Loop forever.  Well, until we're asked to convert a buffer
		// with less than the maximum number of rows
		for (;;)
		{
			// Wait for some work
			ExtractBuffer* pBuffer = g_filledBuffers.getBuffer();

			// How many extracted rows in this buffer?
			thisFetch = pBuffer->get_Rows();

			// Convert each column in each row and emit the converted
			// data item to the output file.
			//unsigned char buffer[512];
			std::vector<OCI::TextEmitter*>& emitters = pBuffer->get_Emitters();
			std::vector<OCI::TextEmitter*>::size_type limit = emitters.size();

			for (unsigned int row = 0; row < thisFetch; ++row)
			{
				for ( std::vector<OCI::TextEmitter*>::size_type idx = 0; idx < limit; idx++ )
				{
					const OCI::TextEmitter* column = emitters[idx];
					unsigned char* buffer = g_pWriter->NextWriteBuffer(column->get_EmitLength());
					unsigned int toWrite = column->Emit(row, buffer, pErr, pEnv);
					//g_pWriter->Write(buffer, toWrite);
				}
#ifdef TARGET_WIN32
				static unsigned char recordTerminator[2] = { '\r', '\n' };
				g_pWriter->Write(&recordTerminator[0], 2);
#else
				static unsigned char recordTerminator[1] = { '\n' };
				g_pWriter->Write(&recordTerminator[0], 1);
#endif
				++g_totalEmitted;
			}

			// The buffer is consumed
			pBuffer->set_Rows(0);

			// Send it back into the wild
			g_freeBuffers.putBuffer(pBuffer);

			// The buffer we just consumed, was it completely full?
			if (g_rowsToFetch == thisFetch)
			{
				// Yes, we must have more work pending.  The next buffer to consume will be
				// the next in queue.
				;
			}
			else
			{
				// Our work here is done.
				break;
			}
		}
	}
	catch (std::bad_alloc&)
	{
		std::cout
			<< "CONVERT: "
			<< "Out of memory" << std::endl;

		// Force the process to end
		exit(1);
	}
	catch (std::exception& e)
	{
		std::cout 
			<< "CONVERT: "
			<< "Exception: " << e.what() << std::endl;

		// Force the process to end
		exit(1);
	}
	catch (OCI::OciException& e)
	{
		std::cout
			<< "CONVERT: " << std::endl
			<< "Oracle error code: " << e.get_ErrorCode() << std::endl
			<< "Message:           " << e.get_Message().c_str() << std::endl
			;

		// Force the process to end
		exit(1);
	}
	catch (FileWriters::FileIoException& e)
	{
		std::cout
			<< "CONVERT: "
			<< "I/O error: " << e.get_Message() << std::endl;

		// Force the process to end
		exit(1);
	}

	return 0;
}

std::string TimeFormat( time_t start, time_t finish )
{
	time_t	elapsed;
	int		hours = 0;
	int		minutes = 0;

	elapsed = finish - start;

	while ( elapsed >= 3600 )
	{
		elapsed -= 3600;
		++hours;
	}

	while ( elapsed >= 60 )
	{
		elapsed -= 60;
		++minutes;
	}

	char	buf[50];
	sprintf_s( buf, _countof(buf), "%02d:%02d:%02d", hours, minutes, elapsed );

	return std::string(buf);
}

static   const char	szSyntax[] = 
": tableName connectStr dataFile [controlFile] [options]\n\n" \
"   Where:  tableName   is the table to unload; can be prefixed with\n" \
"                           schema.  e.g. schema.table\n" \
"           connectStr  is a userid and password as userid/password@service\n" \
"           dataFile    stores the output\n" \
"           controlFile optionally stores control cards\n" \
"    Options:\n" \
/*"           -lrecl:num   optionally specifies dataFile\'s record length; must\n" \
"                             be greater 2.  e.g. /lrecl:80\n" \
"           -owner:id    optionally specifies string which will prefix the \n" \
"                             table name in the control file; may not contain\n" \
"                              more than 32 characters\n" \
"           -coldef:ColumnName=Type optionally indicates that the Column name\n" \
"                              is of data type DATE, TIME, or TIMESTAMP.  You\n" \
"                              can use this option 1 to 10 times\n" */ \
"           -RESTRICT:<where clause> optionally restricts the select to the\n" \
"                              given conditions in the clause\n" \
"\n" \
"The tableName parameter can refer to a response file as in @response.txt\n" \
"In response file, the first non-blank and non-comment line is used as the\n" \
"table name.  The response file can optionally contain the -RESTRICT key-\n" \
"word.  For example:\n" \
"\n" \
"# Comments begin with a hash mark and can be\n" \
"     # preceded by whitespace.  Whitespace prior to the table name is\n" \
"# discarded:\n" \
"        HISTORY_CLAIM parition(42)\n" \
"# Yields \"HISTORY_CLAIM parition(42)\" as the table name parameter.\n" \
"# The file can end after the table name, or contain white space, comments\n" \
"# or a -RESTRICT keyword:\n" \
"/restrict:where (FK_SOMETHING = 'value'\n" \
"  or COLA = 3)\n" \
"  and colb like 'hello?'\n" \
";\n" \
"# The text between the colon and the semicolon is taken literal except CR\n" \
"# and LF which are converted to spaces.  File content after the semicolon \n" \
"# ignored.\n"
;

extern   int   main( int argc, char* argv[] )
{
	int		iRet	= 0;
	time_t  start	= 0;
	time_t	finish	= 0;

	std::string	moduleName;

	try
	{
		// Start the clock
		time(&start);

		// What is the executable name we've been linked under?
#if defined(TARGET_WIN32) || defined(_MSC_VER)
		moduleName.resize(MAX_PATH, '\0');
		char* pszModule = const_cast<char*>(moduleName.data());
		_splitpath_s(argv[0], NULL, 0, NULL, 0, pszModule, MAX_PATH, NULL, 0);
		moduleName.resize(moduleName.find_first_of('\0'));
#else
		moduleName = basename(argv[0]);
#endif

		// Command line arguments
		CommandLineParser options;
		options.Parse(argc, argv);

#ifdef TARGET_WIN32
		FileWriters::Win32SingleThreadedFileWriter writer;
#else
		FileWriters::SingleThreadedFileWriter	writer;
#endif
		writer.Open(options.get_DataFile());

		// Connect to Oracle
		OCI::Session	session(options.get_ConnectString());
		g_pWriter = &writer;

		//-----------------------
		{
			OCI::Statement	stmtSetSession(session);
			stmtSetSession.ExecuteImmediate("alter session set \"_serial_direct_read\"=true");
			stmtSetSession.ExecuteImmediate("alter session set \"db_file_multiblock_read_count\"=128");
			stmtSetSession.ExecuteImmediate("alter session set nls_date_format='YYYY-MM-DD'");
		}

		OCI::Statement	statement(session);
		g_selectStatement = "select * from " + options.get_UnloadObject();
		if (0 != options.get_Restrict().length())
		{
			g_selectStatement += " " + options.get_Restrict();
		}
		
		statement.Execute(g_selectStatement);
		ExtractBuffer*	buffers[3];
		memset(buffers, 0, sizeof(buffers));

		for ( std::vector<OCI::Column>::size_type idx = 0; idx < statement.Columns().size(); idx++ )
		{
			const OCI::Column& column = statement.Columns()[idx];

			OCI::TextEmitter emitter(statement, column, g_rowsToFetch);
			for (int i = 0; i < _countof(buffers); ++i)
			{
				if (NULL == buffers[i])
				{
					buffers[i] = new ExtractBuffer();
					g_freeBuffers.putBuffer(buffers[i]);
				}
				buffers[i]->get_Emitters().push_back(new OCI::TextEmitter(emitter));
			}
		}

		// Start with the first buffer in the circular queue
		ExtractBuffer*	pBuffer = g_freeBuffers.getBuffer();

		// Start the converter thread
#ifdef TARGET_WIN32
		HANDLE hThrd = CreateThread(NULL, 0, ConvertThread, NULL, 0, NULL);
#else
		pthread_t	hThrd;
		iRet = pthread_create(&hThrd, NULL, ConvertThread, NULL);
#endif

		// Get a local copy of the control file name:
		std::string controlFile(options.get_ControlFile());

		// Get arrays of rows
		unsigned int	thisFetch = 0;
		unsigned int	iterations = 0;
		do
		{
			// Define this buffer to the statement
			std::vector<OCI::TextEmitter*>& emitters = pBuffer->get_Emitters();
			std::vector<OCI::TextEmitter*>::size_type limit = emitters.size();
			for ( std::vector<OCI::Define>::size_type idx = 0; idx < limit; idx++ )
			{
				emitters[idx]->DefineForFetch();
				if (0 == iterations)
				{
					g_recordLength += emitters[idx]->get_EmitLength();
				}
			}

			// Once the emitters have been bound to the statement we
			// can produce the control file if one is requested.
			if (0 != controlFile.length())
			{
				std::ofstream	os(options.get_ControlFile().c_str());
				print_ctl(os, pBuffer->get_Emitters(), options.get_UnloadObject());
				os.close();

				// Don't do this again
				controlFile.clear();
			}

			// Get a set of rows
			thisFetch = statement.Fetch(g_rowsToFetch);

			// How many thus far?
			++iterations;
			g_totalFetched += thisFetch;

			// Give it to the converter
			pBuffer->set_Rows(thisFetch);
			g_filledBuffers.putBuffer(pBuffer);

			// Get the next extract buffer
			pBuffer = g_freeBuffers.getBuffer();
		}
		while (thisFetch == g_rowsToFetch);

		// Wait for the conversion thread
#ifdef TARGET_WIN32
		WaitForSingleObject(hThrd, INFINITE);
#else
		pthread_join(hThrd, NULL);
#endif
		//-----------------------

		for (int i = 0; i < _countof(buffers); ++i)
		{
			delete buffers[i];
			buffers[i] = 0;
		}

		// Stop the clock
		time(&finish);
	}
	catch (CommandLineSyntaxException& ex)
	{
		if (NULL != ex.what())
		{
			std::cout << "Syntax error: " << ex.what() << std::endl;
		}
		std::cout << moduleName << szSyntax << std::endl;
		iRet = 1;
	}
	catch (std::bad_alloc&)
	{
		std::cout << "EXTRACT: "
			<< "Out of memory" << std::endl;
		iRet = 1;
	}
	catch (std::exception& e)
	{
		std::cout
			<< "EXTRACT: "
			<< "Exception: " << e.what() << std::endl;
		iRet = 1;
	}
	catch (OCI::OciException& e)
	{
		std::cout
			<< "EXTRACT: " << std::endl
			<< "Oracle error code: " << e.get_ErrorCode() << std::endl
			<< "Message:           " << e.get_Message().c_str() << std::endl
			;
		iRet = 1;
	}
	catch (FileWriters::FileIoException& e)
	{
		std::cout
			<< "EXTRACT: "
			<< "I/O error: " << e.get_Message() << std::endl;
		iRet = 1;
	}

	if (0 == iRet)
	{
		std::cout 
			<< "Record length:     " << g_recordLength << std::endl
			<< "Records extracted: " << g_totalFetched << std::endl
			//<< "Records emitted:   " << g_totalEmitted << std::endl
			<< "Elapsed time:      " << TimeFormat(start, finish).c_str() << std::endl
			;
	}

	return iRet;
}
