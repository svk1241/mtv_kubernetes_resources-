/*
 **********************************************************************
 *
 * Metavance
 * Copyright (C) 2001-2008, EDS
 * All Rights Reserved.
 *
 * EDS
 * 225 Grandview Avenue
 * Camp Hill, PA  USA
 * http: *www.eds.com
 *
 * This source code is the confidential property of EDS, All
 * proprietary rights, including but not limited to any trade secret,
 * copyright, patent, or trademark rights in and to this source code
 * are the property of EDS.  This source code is not to be used,
 * disclosed or reproduced in any form without the express written
 * consent of EDS.
 *
 **********************************************************************
 */
#ifndef COMMANDLINEPARSER_H_F36E32E0B_EB2D_4A81_A55A_C2C704EF00CC_INCLUDED
#define COMMANDLINEPARSER_H_F36E32E0B_EB2D_4A81_A55A_C2C704EF00CC_INCLUDED

#ifdef _MSC_VER
#pragma once
#endif

#include "ResponseFileParser.h"

class CommandLineSyntaxException :
	public std::exception
{
// @access Construction
public:

	CommandLineSyntaxException(void)
	{
	}

	CommandLineSyntaxException(const char *const& what)
		: m_what(what)
	{
	}

	CommandLineSyntaxException(const char *const& what, int code)
		: m_what(what)
	{
	}

	CommandLineSyntaxException(const CommandLineSyntaxException& other)
	{
		operator =(other);
	}

	CommandLineSyntaxException& operator =(const CommandLineSyntaxException& other)
	{
		std::exception::operator =(other);
		if (this != &other)
		{
			m_what = other.m_what;
		}
		return *this;
	}

	virtual const char* what(void) const throw()
	{
		if (0 != m_what.length()) return m_what.c_str();
		return NULL;
	}

private:
	std::string m_what;
};

class CommandLineParser
{
// @access Construction
public:

	CommandLineParser(void)
	{
	}

	CommandLineParser(const CommandLineParser& other)
	{
		operator =(other);
	}

// @access Attributes
public:

	const std::string& get_UnloadObject(void) const
	{
		return m_unloadObject;
	}

	const std::string& get_ConnectString(void) const
	{
		return m_connectString;
	}

	const std::string& get_DataFile(void) const
	{
		return m_dataFile;
	}

	const std::string& get_ControlFile(void) const
	{
		return m_controlFile;
	}

	const std::string&	get_Restrict(void) const
	{
		return m_restrict;
	}

// @access Operations
public:
	CommandLineParser& operator =(const CommandLineParser& other)
	{
		if (this != &other)
		{
			m_unloadObject = other.m_unloadObject;
			m_connectString = other.m_connectString;
			m_dataFile = other.m_dataFile;
			m_controlFile = other.m_controlFile;
			m_restrict = other.m_restrict;
		}
		return *this;
	}

	void Parse(int argc, char* argv[])
	{
		int positionalParameter = 0;
		int responseFiles = 0;

		for (int i = 1; i < argc; ++i)
		{
			if ('@' == argv[i][0])
			{
				if (0 != positionalParameter)
				{
					throw CommandLineSyntaxException("Response file must be first positional parameter.");
				}
				++positionalParameter;

				if (0 != responseFiles)
				{
					throw CommandLineSyntaxException("Use one and only one response file.");
				}
				++responseFiles;

				std::ifstream fin(&argv[i][1]);
				if (!fin.is_open())
				{
					std::ostringstream os;
					os << "Cannot open response file: \"" << &argv[i][1] << '"';
					throw CommandLineSyntaxException(os.str().c_str());
				}

				ResponseFileParser parser;
				parser.Parse(fin);
				m_unloadObject = parser.get_UnloadObject();
				if (0 != m_restrict.length() && 0 != parser.get_Restrict().length())
				{
					throw CommandLineSyntaxException("More than one restrict keyword.");
				}

				m_restrict = parser.get_Restrict();

				continue;
			}

			if ('-' == argv[i][0]
#ifdef TARGET_WIN32
			|| '/' == argv[i][0]
#endif
			)
			{
				if (0 == _strnicmp(&argv[i][1], "restrict:", 9))
				{
					if (0 != m_restrict.length())
					{
						throw CommandLineSyntaxException("More than one restrict keyword.");
					}

					m_restrict = &argv[i][10];
					if (0 == m_restrict.length())
					{
						throw CommandLineSyntaxException("Restrict keyword has no clause.");
					}
				}
				else
				{
					static const char* ignored[] = { "coldef:", "lrecl:", "owner:" };
					int j;
					for (j = 0; j < 3; ++j)
					{
						if (0 == _strnicmp(ignored[j], &argv[i][1], strlen(ignored[j])))
						{
							std::cout << '"' << ignored[j] 
								<< "\" keyword is deprecated and will be ignored."
									<< std::endl << std::endl;
							break;
						}
					}

					if (3 <= j)
					{
						std::ostringstream os;
						os << "Unknown keyword: \"" << argv[i] << '"';
						throw CommandLineSyntaxException(os.str().c_str());
					}
				}
			}
			else
			{
				switch (positionalParameter)
				{
				case 0:
					m_unloadObject = argv[i];
					break;
				case 1:
					m_connectString = argv[i];
					break;
				case 2:
					m_dataFile = argv[i];
					break;
				case 3:
					m_controlFile = argv[i];
					break;
				default:
					throw CommandLineSyntaxException();
				}
				++positionalParameter;
			}
		}

		// These 3 are required:
		if (0 == m_unloadObject.length()
			|| 0 == m_connectString.length()
			|| 0 == m_dataFile.length())
		{
			throw CommandLineSyntaxException();
		}
	}

// @access Implementation
public:

	~CommandLineParser(void)
	{
	}

private:

	std::string	m_unloadObject;
	std::string	m_connectString;
	std::string	m_dataFile;
	std::string m_controlFile;
	std::string	m_restrict;
};

#endif	// ndef RESPONSEFILEPARSER_H_F36E32E0B_EB2D_4A81_A55A_C2C704EF00CC_INCLUDED
