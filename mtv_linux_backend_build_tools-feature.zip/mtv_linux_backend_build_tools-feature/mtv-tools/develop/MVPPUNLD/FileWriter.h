/*
 **********************************************************************
 *
 * Metavance
 * Copyright (C) 2001-2008, EDS
 * All Rights Reserved.
 *
 * EDS
 * 225 Grandview Avenue
 * Camp Hill, PA  USA
 * http: *www.eds.com
 *
 * This source code is the confidential property of EDS, All
 * proprietary rights, including but not limited to any trade secret,
 * copyright, patent, or trademark rights in and to this source code
 * are the property of EDS.  This source code is not to be used,
 * disclosed or reproduced in any form without the express written
 * consent of EDS.
 *
 **********************************************************************
 */
#if !defined(FILEWRITER_H_A03036FB_69F1_40E1_AEE1_8762EF89A1A2_INCLUDED)
#define FILEWRITER_H_A03036FB_69F1_40E1_AEE1_8762EF89A1A2_INCLUDED

#ifdef _MSC_VER
#pragma once
#endif

#include <string>

namespace FileWriters
{
	class FileIoBuffer
	{
	// @access Construction
	public:
		FileIoBuffer(unsigned int bufferSize)
		: m_buffer(NULL)
		, m_bufferLen(0)
		{
			Allocate(bufferSize);
		}
	private:
		// Do not permit copy construction
		FileIoBuffer(const FileIoBuffer&);

	// @access Attributes
	public:
		unsigned char* get_Buffer(void) const
		{
			return const_cast<unsigned char*>(m_buffer);
		}

		unsigned int get_BufferSize(void) const
		{
			return m_bufferLen;
		}

	// @access Operations
	public:

	protected:
		virtual void Allocate(unsigned int bufferSize)
		{
			Free();
			m_buffer = reinterpret_cast<unsigned char*>
				(malloc(bufferSize));
			if (NULL == m_buffer) throw std::bad_alloc();
			m_bufferLen = bufferSize;
		}

		virtual void Free(void)
		{
			if (NULL != m_buffer) free(m_buffer);
			m_buffer = NULL;
			m_bufferLen = 0;
		}

	// @access Implementation
	public:
		~FileIoBuffer()
		{
			Free();
		}
	private:

		unsigned char*	m_buffer;
		unsigned int	m_bufferLen;
	};

	class FileIoException
	{
	// @access Construction
	public:
		FileIoException()
		: m_errorCode(0)
		{
		}

		FileIoException(const std::string& errorMessage, unsigned int errorCode = 0)
		: m_message(errorMessage)
		, m_errorCode(errorCode)
		{
		}

		FileIoException(const char* pszErrorMessage, unsigned int errorCode = 0)
		: m_message(pszErrorMessage)
		, m_errorCode(errorCode)
		{
		}

		FileIoException(const FileIoException& other)
		{
			operator =(other);
		}

	// @access Attributes
	public:
		const std::string& get_Message(void) const
		{
			return m_message;
		}

		unsigned int get_ErrorCode(void) const
		{
			return m_errorCode;
		}

	// @access Operations
	public:
		FileIoException& operator =(const FileIoException& rhs)
		{
			if (this != &rhs)
			{
				m_message = rhs.m_message;
				m_errorCode = rhs.m_errorCode;
			}
			return *this;
		}

	// @access Implementation
	public:
		~FileIoException()
		{
		}

	private:

		std::string	m_message;
		unsigned int	m_errorCode;
	};

	class FileWriter
	{
	// @access Construction
	public:
		FileWriter()
		{
		}
	private:
		// Do not permit copy construction
		FileWriter(const FileWriter&);

	// @access Attributes
	public:
		
	// @access Operations
	private:
		// Do not permit assignment
		FileWriter& operator =(const FileWriter&);
	public:
		// Open a file for writing
		virtual void Open(const std::string& fileName) = 0;
		// Close an open file
		virtual void Close(void) = 0;
		// Write a buffer to the file
		virtual void Write(unsigned char* buffer, unsigned int bufferSize) = 0;

		virtual unsigned char* NextWriteBuffer(unsigned int writeSize) = 0;

	// @access Implementation
	public:
		~FileWriter()
		{
		}
	};
}

#endif // !defined(FILEWRITER_H_A03036FB_69F1_40E1_AEE1_8762EF89A1A2_INCLUDED)
