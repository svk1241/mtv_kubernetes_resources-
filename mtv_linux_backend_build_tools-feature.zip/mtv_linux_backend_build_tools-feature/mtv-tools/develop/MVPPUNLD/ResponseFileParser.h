/*
 **********************************************************************
 *
 * Metavance
 * Copyright (C) 2001-2008, EDS
 * All Rights Reserved.
 *
 * EDS
 * 225 Grandview Avenue
 * Camp Hill, PA  USA
 * http: *www.eds.com
 *
 * This source code is the confidential property of EDS, All
 * proprietary rights, including but not limited to any trade secret,
 * copyright, patent, or trademark rights in and to this source code
 * are the property of EDS.  This source code is not to be used,
 * disclosed or reproduced in any form without the express written
 * consent of EDS.
 *
 **********************************************************************
 */
#ifndef RESPONSEFILEPARSER_H_F36E32E0B_EB2D_4A81_A55A_C2C704EF00CC_INCLUDED
#define RESPONSEFILEPARSER_H_F36E32E0B_EB2D_4A81_A55A_C2C704EF00CC_INCLUDED

#ifdef _MSC_VER
#pragma once
#endif

class ResponseFileParser
{
// @access Construction
public:

	ResponseFileParser(void)
	{
	}

	ResponseFileParser(const ResponseFileParser& other)
	{
		operator =(other);
	}

// @access Attributes
public:

	const std::string& get_Restrict(void) const
	{
		return m_restrict;
	}

	const std::string& get_UnloadObject(void) const
	{
		return m_unloadObject;
	}

// @access Operations
public:

	ResponseFileParser& operator =(const ResponseFileParser& other)
	{
		if (&other != this)
		{
			m_unloadObject = other.m_unloadObject;
		}

		return *this;
	}

	void Parse(std::istream& input)
	{
		// Reset
		m_unloadObject.clear();
		m_restrict.clear();

		// Do nothing if at the end of input
		if (EOF == input.peek()) return;

		// The first non-comment line is the unload object
		SkipWhitespaceAndComments(input);
		if (EOF == input.peek()) return;
		std::getline(input, m_unloadObject);


		// Does the next non-comment line contain "/restrict:"?
		SkipWhitespaceAndComments(input);
		if (EOF == input.peek()) return;

		int ch = input.get();
		if ('-' == ch || '/' == ch)
		{
			static const char	szRestrict[] = "restrict:";
			char	keyword[sizeof(szRestrict)];
			memset(keyword, 0, sizeof(keyword));
			input.read(keyword, static_cast<std::streamsize>(strlen(szRestrict)));

			// HP-UX does not have _memicmp
			for (int i = 0; i < sizeof(keyword); ++i)
			{
				keyword[i] = static_cast<char>(std::tolower(keyword[i]));
			}

			if (0 == memcmp(keyword, szRestrict, sizeof(szRestrict)))
			{
				std::ostringstream os;
				ch = input.peek();
				while (EOF != ch && ';' != ch)
				{
					if ('\r' == ch || '\n' == ch)
					{
						os << ' ';
						input.get();
					}
					else
					{
						os << static_cast<char>(input.get());
					}
					ch = input.peek();
				}
				m_restrict = os.str();
			}
		}
	}

private:

	void SkipWhitespaceAndComments(std::istream& input)
	{
		int ch = '#';
		do
		{
			ch = input.peek();
			if (EOF == ch) return;

			// Skip leading whitespace
			while (std::isspace(ch))
			{
				input.get();
				ch = input.peek();
			}
			if (EOF == ch) return;

			if ('#' == ch)
			{
				std::string line;
				std::getline(input, line);
			}
		}
		while ('#' == ch);
	}

	std::string m_unloadObject;
	std::string m_restrict;
};
#endif	// ndef RESPONSEFILEPARSER_H_F36E32E0B_EB2D_4A81_A55A_C2C704EF00CC_INCLUDED
