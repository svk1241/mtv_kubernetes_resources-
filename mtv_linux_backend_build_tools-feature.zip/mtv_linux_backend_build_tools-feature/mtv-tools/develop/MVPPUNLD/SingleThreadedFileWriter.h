/*
 **********************************************************************
 *
 * Metavance
 * Copyright (C) 2001-2008, EDS
 * All Rights Reserved.
 *
 * EDS
 * 225 Grandview Avenue
 * Camp Hill, PA  USA
 * http: *www.eds.com
 *
 * This source code is the confidential property of EDS, All
 * proprietary rights, including but not limited to any trade secret,
 * copyright, patent, or trademark rights in and to this source code
 * are the property of EDS.  This source code is not to be used,
 * disclosed or reproduced in any form without the express written
 * consent of EDS.
 *
 **********************************************************************
 */
#if !defined(SINGLETHREADEDFILEWRITER_H_0B688E82_6C40_4EA3_95C6_634B17C676E8_INCLUDED)
#define	SINGLETHREADEDFILEWRITER_H_0B688E82_6C40_4EA3_95C6_634B17C676E8_INCLUDED

#ifdef _MSC_VER
#pragma once
#endif

#include "FileWriter.h"

namespace FileWriters
{
	class SingleThreadedFileWriter : public FileWriter
	{
	// @access Construction
	public:
		SingleThreadedFileWriter()
		: m_fh(-1)
		{
		}
	private:
		// Do not permit copy construction
		SingleThreadedFileWriter(const SingleThreadedFileWriter&);

	// @access Attributes
	public:
		
	// @access Operations
	private:
		// Do not permit assignment
		SingleThreadedFileWriter operator =(const SingleThreadedFileWriter&);
	public:
		// Open a file for writing
		virtual void Open(const std::string& fileName)
		{
#ifdef	TARGET_WIN32
			errno_t rc = _sopen_s(&m_fh,
				fileName.c_str(),
				_O_CREAT | _O_TRUNC | _O_BINARY | _O_SEQUENTIAL | _O_WRONLY, _SH_DENYWR, _S_IWRITE);
			if (0 != rc)
			{
				char	message[80] = { '\0' };
				errno_t error = errno;

				rc = strerror_s(message, error);
				throw FileIoException(message, error);
			}
#else
			m_fh = open(fileName.c_str(),
				O_CREAT | O_TRUNC | O_WRONLY
				| /*O_LARGEFILE*/ 04000
				,
				S_IRUSR | S_IWUSR);
			if (-1 == m_fh)
			{
				int	error = errno;
				throw FileIoException(strerror(error), error);
			}
#endif
			size_t	bufferSize = 128 * 1024;
			m_buffer = reinterpret_cast<unsigned char*>(malloc(bufferSize));
			if (NULL == m_buffer) throw std::bad_alloc();
			m_bufferSize = bufferSize;
			m_bufferUsed = 0;
		}

		// Close an open file
		virtual void Close(void)
		{
			if (-1 != m_fh)
			{
				if (0 != m_bufferUsed)
				{
#ifdef	TARGET_WIN32
					if (-1 == _write(m_fh, m_buffer, m_bufferUsed))
					{
						char	message[80] = { '\0' };
						errno_t error = errno;

						strerror_s(message, error);
						throw FileIoException(message, error);
					}
#else
					if (-1 == write(m_fh, m_buffer, m_bufferUsed))
					{
						int	error = errno;
						throw FileIoException(strerror(error), error);
					}
#endif
					m_bufferUsed = 0;
				}

#ifdef	TARGET_WIN32
				_close(m_fh);
#else
				close(m_fh);
#endif
			}
			m_fh = -1;
			if (NULL != m_buffer) free(m_buffer);
			m_buffer = NULL;
		}

		virtual void Write(unsigned char* buffer, unsigned int bufferSize)
		{
			if (bufferSize + m_bufferUsed > m_bufferSize)
			{
#ifdef	TARGET_WIN32
				if (-1 == _write(m_fh, m_buffer, m_bufferUsed))
				{
					char	message[80] = { '\0' };
					errno_t error = errno;

					strerror_s(message, error);
					throw FileIoException(message, error);
				}
#else
				if (-1 == write(m_fh, m_buffer, m_bufferUsed))
				{
					int	error = errno;
					throw FileIoException(strerror(error), error);
				}
#endif
				m_bufferUsed = 0;
			}

			memcpy(m_buffer + m_bufferUsed, buffer, bufferSize);
			m_bufferUsed += bufferSize;
		}

		virtual unsigned char* NextWriteBuffer(unsigned int writeSize)
		{
			// Increase the write size by 1 byte to accomodate any trailing
			// nul character.  That character will not be written and the next
			// write request will overlay the nul character.
			if (writeSize + 1 + m_bufferUsed > m_bufferSize)
			{
#ifdef	TARGET_WIN32
				if (-1 == _write(m_fh, m_buffer, m_bufferUsed))
				{
					char	message[80] = { '\0' };
					errno_t error = errno;

					strerror_s(message, error);
					throw FileIoException(message, error);
				}
#else
				if (-1 == write(m_fh, m_buffer, m_bufferUsed))
				{
					int	error = errno;
					throw FileIoException(strerror(error), error);
				}
#endif
				m_bufferUsed = 0;
			}

			unsigned char* ret = m_buffer + m_bufferUsed;
			m_bufferUsed += writeSize;
			return ret;
		}

	// @access Implementation
	public:
		~SingleThreadedFileWriter()
		{
			Close();
		}

	private:

		int	m_fh;
		unsigned char*	m_buffer;
		size_t		m_bufferSize;
		size_t		m_bufferUsed;
	};
}

#endif
