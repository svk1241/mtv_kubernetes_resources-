////////////////////////////////////////////////////////////////////////
// Metavance
// Copyright (C) 2001-2008, EDS
// All Rights Reserved.
//
// EDS
// 225 Grandview Avenue
// Camp Hill, PA  USA
// http://www.eds.com
//
// This source code is the confidential property of EDS, All proprietary
// rights, including but not limited to any trade secret, copyright,
// patent or trademark rights in and to this source code are the
// property of EDS.  This source code is not to be used, disclosed or
// reproduced in any form without the express written consent of EDS.
//
////////////////////////////////////////////////////////////////////////
#ifdef _MSC_VER
#pragma once
#endif

#ifndef _DESTQUEUE_20080630_INCLUDED_
#define _DESTQUEUE_20080630_INCLUDED_

#include "MTV_cmqc.h"

class DestQueue
{
public:
	DestQueue()
		: m_queueHandle(0)
		, m_queueManagerHandle(0)
	{
	}

	DestQueue(const std::string& manager, const std::string& name)
		: m_queueManager(manager)
		, m_queueName(name)
		, m_queueHandle(0)
		, m_queueManagerHandle(0)
	{
		if (0 == m_queueManager.length()) throw std::invalid_argument("m_queueManager");
		if (0 == m_queueName.length()) throw std::invalid_argument("m_queueName");
	}

	DestQueue(const DestQueue& other)
		: m_queueManager(other.m_queueManager)
		, m_queueName(other.m_queueName)
		, m_queueHandle(0)
		, m_queueManagerHandle(0)
	{
	}

	const std::string& get_Manager(void) const
	{
		return m_queueManager;
	}

	const std::string& get_Name(void) const
	{
		return m_queueName;
	}

	bool IsOpen(void) const
	{
		return (0 != m_queueHandle);
	}

	DestQueue& operator =(const DestQueue& other)
	{
		if (this != &other)
		{
			m_queueManager = other.m_queueManager;
			m_queueName = other.m_queueName;
			if (NULL != other.m_queueHandle)
			{
				Close();
				Open();
			}
		}

		return *this;
	}

	void Close(void)
	{
		if (0 != m_queueManagerHandle)
		{
			MQLONG	compCode;
			MQLONG	reason;

			if (0 != m_queueHandle)
			{
				MQCLOSE(m_queueManagerHandle,
					&m_queueHandle,
					0,
					&compCode,
					&reason);
				// Close errors are ignored
			}
			m_queueHandle = 0;

			MQDISC(&m_queueManagerHandle,
					&compCode,
					&reason);
			// Disconnect errors are ignored
			m_queueManagerHandle = 0;
		}
	}

	void Commit(void)
	{
		MQLONG	compCode;
		MQLONG	reason;

		MQCMIT(m_queueManagerHandle, &compCode, &reason);
		if (MQCC_FAILED == compCode)
		{
			std::ostringstream os;
			os << m_queueName << ": cannot commit; reason code: " << reason;
			os.flush();
			throw std::runtime_error(os.str());
		}
	}

	void Open(void)
	{
		std::ostringstream os;
		MQLONG	compCode;
		MQLONG	reason;

		// Connect to the queue manager
		MQCONN( reinterpret_cast<PMQCHAR>(const_cast<char*>(m_queueManager.c_str())),
			&m_queueManagerHandle,
			&compCode,
			&reason);
		if (MQCC_FAILED == compCode)
		{
			os << m_queueManager << ": cannot connect; reason code: " << reason;
			os.flush();
			throw std::runtime_error(os.str());
		}

		// Open the queue
		MQOD   od = {MQOD_DEFAULT};
#ifdef TARGET_WIN32
		strncpy_s(od.ObjectName, m_queueName.c_str(), (size_t)MQ_Q_NAME_LENGTH);
#else
		strncpy(od.ObjectName, m_queueName.c_str(), (size_t)MQ_Q_NAME_LENGTH);
#endif
		MQOPEN(m_queueManagerHandle,
			&od,
			MQOO_OUTPUT | MQOO_FAIL_IF_QUIESCING,
			&m_queueHandle,
			&compCode,
			&reason);

		if (MQCC_FAILED == compCode)
		{
			os << m_queueName << ": cannot open; reason code: " << reason;
			os.flush();
			throw std::runtime_error(os.str());
		}
	}

	void Write(const char* buffer, int bufferLength)
	{
		if (NULL == buffer) throw std::invalid_argument("buffer");

		MQLONG	compCode;
		MQLONG	reason;
		MQMD   md = {MQMD_DEFAULT};
		MQPMO  pmo = { MQPMO_DEFAULT };

		pmo.Options |= MQPMO_SYNCPOINT;
		MQPUT(m_queueManagerHandle,
			m_queueHandle,
			&md,
			&pmo,
			bufferLength,
			const_cast<char*>(buffer),
			&compCode,
			&reason);
		if (MQCC_FAILED == compCode)
		{
			std::ostringstream os;
			os << m_queueName << ": cannot write; reason code: " << reason;
			os.flush();
			throw std::runtime_error(os.str());
		}
	}

	~DestQueue()
	{
		Close();
	}

private:
	std::string	m_queueManager;
	std::string	m_queueName;
	MQHCONN		m_queueManagerHandle;
	MQHOBJ		m_queueHandle;
};

#endif	//ndef _DESTQUEUE_20080630_INCLUDED_
