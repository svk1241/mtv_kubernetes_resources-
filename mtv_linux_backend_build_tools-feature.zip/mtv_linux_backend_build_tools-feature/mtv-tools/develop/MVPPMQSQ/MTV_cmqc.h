////////////////////////////////////////////////////////////////////////
// Metavance
// Copyright (C) 2001-2008, EDS
// All Rights Reserved.
//
// EDS
// 225 Grandview Avenue
// Camp Hill, PA  USA
// http://www.eds.com
//
// This source code is the confidential property of EDS, All proprietary
// rights, including but not limited to any trade secret, copyright,
// patent or trademark rights in and to this source code are the
// property of EDS.  This source code is not to be used, disclosed or
// reproduced in any form without the express written consent of EDS.
//
////////////////////////////////////////////////////////////////////////
#ifndef MTV_CMQC_INCLUDED
#define MTV_CMQC_INCLUDED

/* Force a rename of the MQSeries API */
#define MQCONN MQCONN_static
#define MQDISC MQDISC_static
#define MQOPEN MQOPEN_static
#define MQCLOSE MQCLOSE_static
#define MQGET MQGET_static
#define MQPUT MQPUT_static
#define MQCMIT MQCMIT_static
#define MQBACK MQBACK_static

/* Include MQSeries API--the API functions will be renamed to <function>_static */
#include <cmqc.h>

/* Restore the function names expected by an application program. */
#undef MQCONN
#undef MQDISC
#undef MQOPEN
#undef MQCLOSE
#undef MQGET
#undef MQPUT
#undef MQCMIT
#undef MQBACK

/* Define function pointers.  The application program will use
the function pointer rather than the library supplied entry point.
The function pointer is resolved in the MapFunction() implementation
below.  A segment fault / access violation on one of the function
pointers indicates either a mis-map or simply that MapFunctions()
was not executed prior to the first MQSeries call. */

/* THESE POINTERS ARE USED BY BOTH WINDOWS AND UNIX; ENSURE PLATFORM
CAPABILITY WHEN CHANGING */

typedef void  (MQENTRY * PMQCONN) (

	      PMQCHAR,   /*pQMgrName,  Name of queue manager */
          PMQHCONN,  /*pHconn,     Connection handle */
          PMQLONG,   /*pCompCode,  Completion code */
          PMQLONG);  /*pReason);   Reason code qualifying CompCode */
            
		static PMQCONN MQCONN = NULL;

typedef void (MQENTRY * PMQDISC) (
		  PMQHCONN,  /*pHconn,     Connection handle */
          PMQLONG,   /*pCompCode,  Completion code */
          PMQLONG);  /*pReason);   Reason code qualifying CompCode */

		static PMQDISC MQDISC = NULL;

typedef void (MQENTRY * PMQOPEN) (
		  MQHCONN,  /*Hconn,     Connection handle */
          PMQVOID,  /*pObjDesc,  Object descriptor */
          MQLONG,   /*Options,   Options that control the action of MQOPEN */
          PMQHOBJ,  /*pHobj,     Object handle */
          PMQLONG,  /*pCompCode, Completion code */
          PMQLONG); /*pReason);  Reason code qualifying CompCode */

		static PMQOPEN MQOPEN = NULL;
		
typedef void (MQENTRY * PMQCLOSE) (
		  MQHCONN,  /*Hconn,     Connection handle */
          PMQHOBJ,  /*pHobj,     Object handle */
          MQLONG,   /*Options,   Options that control the action of MQCLOSE */
          PMQLONG,  /*pCompCode, Completion code */
          PMQLONG); /*pReason);  Reason code qualifying CompCode */

		static PMQCLOSE MQCLOSE = NULL;

typedef void (MQENTRY * PMQGET) (
          MQHCONN,  /*Hconn,          Connection handle */
 	      MQHOBJ,   /*Hobj,           Object handle */
		  PMQVOID,  /*pMsgDesc,       Message descriptor */
		  PMQVOID,  /*pGetMsgOpts,    Options that control the action of MQGET */
		  MQLONG,   /*BufferLength,   Length in bytes of the Buffer area */
		  PMQVOID,  /*pBuffer,        Area to contain the message data */
		  PMQLONG,  /*pDataLength,    Length of the message */
		  PMQLONG,  /*pCompCode,      Completion code */
		  PMQLONG); /*pReason);       Reason code qualifying CompCode */

	
         static PMQGET MQGET = NULL;

typedef void (MQENTRY * PMQPUT) ( 
		  MQHCONN,  /*Hconn,          Connection handle */
          MQHOBJ,   /*Hobj,           Object handle */
          PMQVOID,  /*pMsgDesc,       Message descriptor */
          PMQVOID,  /*pPutMsgOpts,    Options that control the action of MQPUT */
          MQLONG,   /*BufferLength,   Length of the message in Buffer */
          PMQVOID,  /*pBuffer,        Message data */
          PMQLONG,  /*pCompCode,      Completion code */
          PMQLONG); /*pReason);       Reason code qualifying CompCode */

		static PMQPUT MQPUT = NULL;

typedef void (MQENTRY * PMQCMIT) (
          MQHCONN,  /*Hconn,       Connection handle */
          PMQLONG,  /*pCompCode,   Completion code */
          PMQLONG); /*pReason);    Reason code qualifying CompCode */ 

		static PMQCMIT MQCMIT = NULL;

typedef void (MQENTRY * PMQBACK) (
		  MQHCONN,  /*Hconn,       Connection handle */
          PMQLONG,  /*pCompCode,   Completion code */
          PMQLONG); /*pReason);    Reason code qualifying CompCode */
								   
        static PMQBACK MQBACK = NULL;

/*---------------------------------------------------------------------
 *                  W I N D O W S
 *---------------------------------------------------------------------
 */
#if defined(TARGET_WIN32)

/* Need windows.h for LoadLibrary() */
#include "target.h"

/* Load the library once and only once */
static HINSTANCE g_hInstMQIC32 = NULL;

/* Resolve the above defined function pointers */
static int MapFunctions(void)
{
	FARPROC pFunc;

	if (NULL == g_hInstMQIC32)
	{
		DWORD	dwErr;
		UINT UiOldMode;

		UiOldMode = SetErrorMode( SEM_FAILCRITICALERRORS );
		g_hInstMQIC32 = LoadLibrary( "MQIC32.DLL"  );
		dwErr = GetLastError();
		SetErrorMode( UiOldMode );

		if ( g_hInstMQIC32 == NULL ) 
		{
			printf( "Cannot load MQSeries -- system error %d.  Try reinstalling that component. \n", dwErr );
			return( 0 );
		}
	}

	/* Fetch the function address for each MQ function. If any */
	/* fail, return 0.                                         */
	if (NULL == MQCONN)
	{
		pFunc = GetProcAddress( g_hInstMQIC32, "MQCONN" );
		MQCONN = (PMQCONN) pFunc;
		if ( MQCONN == NULL ) 
		{
			return( 0 );
		}
	}

	if (NULL == MQDISC)
	{
		pFunc = GetProcAddress( g_hInstMQIC32, "MQDISC" );
		MQDISC = (PMQDISC) pFunc;
		if ( MQDISC == NULL ) 
		{
			return( 0 );
		}
	}

	if (NULL == MQOPEN)
	{
		pFunc = GetProcAddress( g_hInstMQIC32, "MQOPEN" );
		MQOPEN = (PMQOPEN) pFunc;
		if ( MQOPEN == NULL ) 
		{
			return( 0 );
		}
	}

	if (NULL == MQCLOSE)
	{
		pFunc = GetProcAddress( g_hInstMQIC32, "MQCLOSE" );
		MQCLOSE = (PMQCLOSE) pFunc;
		if ( MQCLOSE == NULL ) 
		{
			return( 0 );
		}
	}

	if (NULL == MQGET)
	{
		pFunc = GetProcAddress( g_hInstMQIC32, "MQGET" );
		MQGET = (PMQGET) pFunc;
		if ( MQGET == NULL ) 
		{
			return( 0 );
		}
	}

	if (NULL == MQPUT)
	{
		pFunc = GetProcAddress( g_hInstMQIC32, "MQPUT" );
		MQPUT = (PMQPUT) pFunc;
		if ( MQPUT == NULL ) 
		{
			return( 0 );
		}
	}

	if (NULL == MQBACK)
	{
		pFunc = GetProcAddress( g_hInstMQIC32, "MQBACK" );
		MQBACK = (PMQBACK) pFunc;
		if ( MQBACK == NULL ) 
		{
			return( 0 );
		}
	}

	if (NULL == MQCMIT)
	{
		pFunc = GetProcAddress( g_hInstMQIC32, "MQCMIT" );
		MQCMIT = (PMQCMIT) pFunc;
		if ( MQCMIT == NULL ) 
		{
			return( 0 );
		}
	}

	/* if we got this far, all functions were found - return success.*/
	return( 1 );
}


/*---------------------------------------------------------------------
 *                  HP - U X
 *---------------------------------------------------------------------
 */
#elif defined(TARGET_HPUX)

/* shl_load() et al. */
#include <dl.h>

/* Load the library once and only once. */
static shl_t	hLibMQIC = NULL;

/* Resolve the above defined function pointers */
static int MapFunctions(void)
{
	int	success = 1;

	if (NULL == hLibMQIC)
	{
           #ifdef TARGET_HPUX_ITAN
                hLibMQIC = shl_load( "libmqic.so", BIND_IMMEDIATE | DYNAMIC_PATH, 0);
           #else
	        hLibMQIC = shl_load( "libmqic.sl", BIND_IMMEDIATE | DYNAMIC_PATH, 0);
           #endif

		if ( NULL == hLibMQIC )
		{
			printf( "Cannot load MQSeries -- system error %d.  Try reinstalling that component. \n", errno );
			return 0;
		}
	}

	if (NULL == MQCONN)
	{
		if ( shl_findsym(&hLibMQIC, "MQCONN", TYPE_PROCEDURE, (void *) &MQCONN) )
		{
			return 0;
	    }
	}

	if (NULL == MQDISC)
	{
		if ( shl_findsym(&hLibMQIC, "MQDISC", TYPE_PROCEDURE, (void *) &MQDISC) )
		{
			return 0;
	    }
	}

	if (NULL == MQOPEN)
	{
		if ( shl_findsym(&hLibMQIC, "MQOPEN", TYPE_PROCEDURE, (void *) &MQOPEN) )
		{
			return 0;
	    }
	}

	if (NULL == MQCLOSE)
	{
		if ( shl_findsym(&hLibMQIC, "MQCLOSE", TYPE_PROCEDURE, (void *) &MQCLOSE) )
		{
			return 0;
	    }
	}

	if (NULL == MQGET)
	{
		if ( shl_findsym(&hLibMQIC, "MQGET", TYPE_PROCEDURE, (void *) &MQGET) )
		{
			return 0;
	    }
	}

	if (NULL == MQPUT)
	{
		if ( shl_findsym(&hLibMQIC, "MQPUT", TYPE_PROCEDURE, (void *) &MQPUT) )
		{
			return 0;
	    }
	}

	if (NULL == MQBACK)
	{
		if ( shl_findsym(&hLibMQIC, "MQBACK", TYPE_PROCEDURE, (void *) &MQBACK) )
		{
			return 0;
	    }
	}

	if (NULL == MQCMIT)
	{
		if ( shl_findsym(&hLibMQIC, "MQCMIT", TYPE_PROCEDURE, (void *) &MQCMIT) )
		{
			return 0;
	    }
	}

	/* A successful load */
	return 1;
}
/*---------------------------------------------------------------------
 *                  Linux
 *---------------------------------------------------------------------
 */
#elif defined(TARGET_LINUX)

/* shl_load() et al. */
#include <dlfcn.h>

/* Load the library once and only once. */
static void *	hLibMQIC = NULL;

/* Resolve the above defined function pointers */
static int MapFunctions(void)
{
	int	success = 1;

	if (NULL == hLibMQIC)
	{
        hLibMQIC = dlopen( "libmqic.so", RTLD_LAZY);

		if ( NULL == hLibMQIC )
		{
			printf( "Cannot load MQSeries -- system error %d.  Try reinstalling that component. \n", errno );
			return 0;
		}
	}

	if (NULL == MQCONN)
	{
		MQCONN = (PMQCONN) dlsym(hLibMQIC, "MQCONN");
		if ( MQCONN == NULL )
		{
			return 0;
	    }
	}

	if (NULL == MQDISC)
	{
		MQDISC = (PMQDISC) dlsym(hLibMQIC, "MQDISC");
		if ( MQDISC == NULL )
		{
			return 0;
	    }
	}

	if (NULL == MQOPEN)
	{
		MQOPEN = (PMQOPEN) dlsym(hLibMQIC, "MQOPEN");
		if ( MQOPEN == NULL )
		{
			return 0;
	    }
	}

	if (NULL == MQCLOSE)
	{
		MQCLOSE = (PMQCLOSE) dlsym(hLibMQIC, "MQCLOSE");
		if ( MQCLOSE == NULL )
		{
			return 0;
	    }
	}

	if (NULL == MQGET)
	{
		MQGET = (PMQGET) dlsym(hLibMQIC, "MQGET");
		if ( MQGET == NULL )
		{
			return 0;
	    }
	}

	if (NULL == MQPUT)
	{
		MQPUT = (PMQPUT) dlsym(hLibMQIC, "MQPUT");
		if ( MQPUT == NULL )
		{
			return 0;
	    }
	}

	if (NULL == MQBACK)
	{
		MQBACK = (PMQBACK) dlsym(hLibMQIC, "MQBACK");
		if ( MQBACK == NULL )
		{
			return 0;
	    }
	}

	if (NULL == MQCMIT)
	{
		MQCMIT = (PMQCMIT) dlsym(hLibMQIC, "MQCMIT");
		if ( MQCMIT == NULL )
		{
			return 0;
	    }
	}

	/* A successful load */
	return 1;
}
#else
#error "Define a MapFunctions() for this target platform"
#endif

#endif /* MTV_CMQC_INCLUDED */
