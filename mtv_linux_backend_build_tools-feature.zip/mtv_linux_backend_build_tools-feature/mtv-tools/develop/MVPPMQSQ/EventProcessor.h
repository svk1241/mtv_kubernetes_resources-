////////////////////////////////////////////////////////////////////////
// Metavance
// Copyright (C) 2001-2008, EDS
// All Rights Reserved.
//
// EDS
// 225 Grandview Avenue
// Camp Hill, PA  USA
// http://www.eds.com
//
// This source code is the confidential property of EDS, All proprietary
// rights, including but not limited to any trade secret, copyright,
// patent or trademark rights in and to this source code are the
// property of EDS.  This source code is not to be used, disclosed or
// reproduced in any form without the express written consent of EDS.
//
// #pragma pack(1)
////////////////////////////////////////////////////////////////////////
#ifdef _MSC_VER
#pragma once
#endif

#ifndef _EVENTPROCESSOR_20080630_INCLUDED_
#define _EVENTPROCESSOR_20080630_INCLUDED_

#include "DestQueues.h"

class EventProcessor
{
protected:


#pragma pack(1)

	struct tagInEventBuffer
	{
		char	someValue[1];
		char	eventName[32];
		char	eventQualifier[32];
		char	keyCount[2];
		char	keys[16][32];
#ifdef TARGET_WIN32
		char	cr[1];
#endif
		char	lf[1];

		int GetKeyCount(void) const
		{
			char	sz[sizeof(keyCount) + 1];
			for (int i = 0; i < sizeof(keyCount); ++i)
			{
				if (!std::isdigit(keyCount[i])) throw std::domain_error("Non-numeric key count");
				sz[i] = keyCount[i];
				sz[i + 1] = '\0';
			}
			int n = atoi(sz);
			if (0 > n || (sizeof(keys)/sizeof(keys[0])) < n)
			{
				std::ostringstream os;
				os << "Record has a key count of " << n << " but the maximum is " << (sizeof(keys)/sizeof(keys[0]));
				throw std::domain_error(os.str());
			}
			return n;
		}

		bool IsFullRecord(void)
		{
			return ('\n' == lf[0])
#ifdef TARGET_WIN32
				&& ('\r' == cr[0])
#endif
				;
		}

		bool Read(std::istream& stream)
		{
			if (stream.eof() || EOF == stream.peek()) return false;

			std::istream::pos_type	currentPos = stream.tellg();

#ifdef	TARGET_WIN32
			cr[0] = '\0';
#endif
			lf[0] = '\0';
			stream.read(&this->someValue[0], sizeof(*this));

			if (!IsFullRecord())
			{
				std::ostringstream sb;
				sb << "Malformed record at file offset: " << currentPos;
				throw std::runtime_error(sb.str());
			}

			// Not EOF
			return true;
		}
	};
	typedef struct tagInEventBuffer INEVENTBUFFER;

	struct tagOutEventBuffer
	{
		char	eventName[32];
		char	filler1;
		char	eventQualifier[32];
		char	filler2;
		char	eventKeys[16][33];

		int Translate(const INEVENTBUFFER& in)
		{
			memcpy(eventName, in.eventName, sizeof(eventName));
			filler1 = '\0';
			memcpy(eventQualifier, in.eventQualifier, sizeof(eventQualifier));
			filler2 = '\0';

			int	keyCount = in.GetKeyCount();
			for (int i = 0; i < keyCount; ++i)
			{
				memcpy(eventKeys[i], in.keys[i], sizeof(eventKeys[i]) - 1);
				eventKeys[i][sizeof(eventKeys[i]) - 1] = '\0';
			}

			return sizeof(eventName)
				+ sizeof(filler1)
				+ sizeof(eventQualifier)
				+ sizeof(filler2)
				+ (sizeof(eventKeys[0]) * keyCount)
				;
		}
	};
	typedef struct tagOutEventBuffer	OUTEVENTBUFFER;

#pragma pack()

public:
	EventProcessor(std::istream& fin, std::vector<DestQueue>& destQueues)
	: m_fin(fin)
	, m_destQueues(destQueues)
	, m_read(0)
	, m_write(0)
	{
	}

	unsigned int get_Reads(void) const
	{
		return m_read;
	}

	unsigned int get_Writes(void) const
	{
		return m_write;
	}

private:
	// No assignment
	EventProcessor& operator =( const EventProcessor& );

public:

	void Process(void)
	{
		m_read = 0;
		m_write = 0;

		while (m_inEventBuffer.Read(m_fin))
		{
			++m_read;

			int	eventLength = m_outEventBuffer.Translate(m_inEventBuffer);

			for (std::vector<DestQueue>::iterator it = m_destQueues.begin();
				it != m_destQueues.end();
				++it)
			{
				(*it).Write(reinterpret_cast<char*>(&m_outEventBuffer), eventLength);
				++m_write;
			}

			if (0 != m_destQueues.size()) m_destQueues[0].Commit();
		}
	}

private:
	std::istream&			m_fin;
	std::vector<DestQueue>& m_destQueues;

	INEVENTBUFFER	m_inEventBuffer;
	OUTEVENTBUFFER	m_outEventBuffer;

	unsigned int	m_read;
	unsigned int	m_write;
};

#endif // ndef _EVENTPROCESSOR_20080630_INCLUDED_
