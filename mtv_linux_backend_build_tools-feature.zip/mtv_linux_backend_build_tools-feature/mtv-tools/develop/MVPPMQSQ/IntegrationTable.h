////////////////////////////////////////////////////////////////////////
// Metavance
// Copyright (C) 2001-2008, EDS
// All Rights Reserved.
//
// EDS
// 225 Grandview Avenue
// Camp Hill, PA  USA
// http://www.eds.com
//
// This source code is the confidential property of EDS, All proprietary
// rights, including but not limited to any trade secret, copyright,
// patent or trademark rights in and to this source code are the
// property of EDS.  This source code is not to be used, disclosed or
// reproduced in any form without the express written consent of EDS.
//
////////////////////////////////////////////////////////////////////////
#ifdef _MSC_VER
#pragma once
#endif

#ifndef _INTEGRATIONTABLE_20080630_INCLUDED_
#define _INTEGRATIONTABLE_20080630_INCLUDED_

// Oracle
#ifdef  _MSC_VER
#define WIN32COMMON
#endif
#include <occi.h>

class IntegrationTable
{
  //select INTERNAL_KWD_DESC into kwdDesc from reference_keyword
  //where KWD_SEQUENCE_ID = 2
  //and FK_CODE_VALUE_ID = 'INTEGRATION'
  //and FK_CODE_CATG_ID = '099'
  //and EXPO_LEVEL_IND = '0'
  //;
public:

	static std::vector<std::string> Get(const char* pszConnectString)
	{
		std::vector<std::string> returnValues;
		std::string	sql("select INTERNAL_KWD_DESC, KWD_SEQUENCE_ID from REFERENCE_KEYWORD " \
			"where FK_CODE_VALUE_ID = 'INTEGRATION' " \
			"  and FK_CODE_CATG_ID = '099' " \
			"  and EXPO_LEVEL_IND = '0' "
			"order by KWD_SEQUENCE_ID");

		oracle::occi::Environment*  pEnv = NULL;
		oracle::occi::Connection*   pConn = NULL;
		oracle::occi::Statement*    pStmt = NULL;
		oracle::occi::ResultSet*	pRs = NULL;

		try
		{
			pEnv = oracle::occi::Environment::createEnvironment( oracle::occi::Environment::OBJECT );
			pConn = Connect(pszConnectString, pEnv);
			pStmt = pConn->createStatement();
			pRs = pStmt->executeQuery(sql);

			// The default Oracle 10.2g OCCI runtime seems to be linked to MSVCR71; the std::string
			// implementation of 7.1 does not seem to play nicely with 8.0
			//
			// Fetch into a buffer rather than using the resultset's getString() method.
			char	kwd[251];
			ub2		kwdLen = 0;
			sb2		kwdNull = 0;
			ub2		kwdRetCode = 0;
			pRs->setDataBuffer(1, kwd, oracle::occi::OCCI_SQLT_AVC, sizeof(kwd), &kwdLen, &kwdNull, &kwdRetCode);

			std::string	kwdDesc;
			std::string	queue;
			int	row = 0;
			while (oracle::occi::ResultSet::END_OF_FETCH != pRs->next())
			{
				kwdDesc.clear();
				if (!kwdNull)
				{
					int		limit = (0 == row) ? 5 : (1 == row ) ? 2 : 0;
					size_t	pos = 0;

					for (int i = 0; i < limit && 0 < kwdLen; ++i)
					{
						// Get the chunk: 48 characters or less
						char*	psz = &kwd[pos];
						size_t	nameLen = 0;
						while (0 < kwdLen /*'\0' != *psz*/ && 48 > nameLen) { ++nameLen; ++psz; --kwdLen; }

						// Ignore trailing spaces
						if (0 != nameLen) --psz;
						while (0 < nameLen && isspace(*psz)) { --nameLen;  --psz; }

						// We have a queue name--it may be empty
						queue.clear();
						queue.append(&kwd[pos], nameLen);

						// We're done with this block, prepare for the
						// next block.
						pos += 48;

						// The first item is the queue manager--always push it
						// even if it is spaces:
						if (0 != queue.length() || (0 == row && 0 == i))
						{
							returnValues.push_back(queue);
						}
					}
				}
				++row;
			}
		}
		catch (...)
		{
			if (NULL != pStmt && NULL != pRs) pStmt->closeResultSet(pRs);
			pRs = NULL;
			if ( NULL != pStmt && NULL != pConn ) pConn->terminateStatement( pStmt );
			pStmt = NULL;
			if ( NULL != pEnv && NULL != pConn ) pEnv->terminateConnection( pConn );
			pConn = NULL;
			if ( NULL != pEnv ) oracle::occi::Environment::terminateEnvironment( pEnv );
			pEnv = NULL;
			throw;
		}

		if (NULL != pStmt && NULL != pRs) pStmt->closeResultSet(pRs);
		pRs = NULL;
		if ( NULL != pStmt && NULL != pConn ) pConn->terminateStatement( pStmt );
		pStmt = NULL;
		if ( NULL != pEnv && NULL != pConn ) pEnv->terminateConnection( pConn );
		pConn = NULL;
		if ( NULL != pEnv ) oracle::occi::Environment::terminateEnvironment( pEnv );
		pEnv = NULL;

		return returnValues;
	}

private:

	static oracle::occi::Connection* Connect(const char* pszConnectString, oracle::occi::Environment* pEnv)
	{
		if (NULL == pszConnectString) return NULL;
		oracle::occi::Connection*   pConn = NULL;

		std::ostringstream bufUID;
		std::ostringstream bufPWD;
		std::ostringstream bufORCL;

		const char* psz = pszConnectString;
		std::ostringstream* p = &bufUID;

		while ( *psz )
		{
			if ( '/' == *psz )
			{
				p = &bufPWD;
			}
			else if ( '@' == *psz )
			{
				p = &bufORCL;
			}
			else
			{
				(*p) << *psz;
			}
			psz++;
		}

		pConn = pEnv->createConnection( bufUID.str(), bufPWD.str(), bufORCL.str() );

		return pConn;
	}
};

#endif	//ndef _INTEGRATIONTABLE_20080630_INCLUDED_
