////////////////////////////////////////////////////////////////////////
// Metavance
// Copyright (C) 2001-2008, EDS
// All Rights Reserved.
//
// EDS
// 225 Grandview Avenue
// Camp Hill, PA  USA
// http://www.eds.com
//
// This source code is the confidential property of EDS, All proprietary
// rights, including but not limited to any trade secret, copyright,
// patent or trademark rights in and to this source code are the
// property of EDS.  This source code is not to be used, disclosed or
// reproduced in any form without the express written consent of EDS.
//
////////////////////////////////////////////////////////////////////////
#ifdef _MSC_VER
#pragma once
#endif

#ifndef _DESTQUEUES_20080630_INCLUDED_
#define _DESTQUEUES_20080630_INCLUDED_

#include <exception>
#include <istream>
#include <vector>

#include "DestQueue.h"

class DestQueues :
	public std::vector<DestQueue>
{
public:

	void GetQueueNames(std::istream& fin)
	{
		this->clear();

		int	lines = 0;
		std::string	manager;
		while (!fin.eof() && 7 > lines)
		{
			// Get one line of text
			std::string	rawLine;
			std::getline(fin, rawLine);

			// Deleting trailing whitespace
			std::vector<char> line(rawLine.begin(), rawLine.end());
			while (!line.empty() && std::isspace(line.back())) line.pop_back();

			// Ignore blank lines
			if (!line.empty())
			{
				// The first non-blank line is the queue manager; subsequent
				// non-blank lines are queue names.
				if (0 == manager.length())
				{
					if (0 != lines) throw std::logic_error("Queue manager name must be the first line");
					manager.assign(line.begin(), line.end());
				}
				else
					this->push_back(DestQueue(manager, std::string(line.begin(), line.end())));
			}
			++lines;
		}
	}
};

#endif	//ndef _DESTQUEUES_20080630_INCLUDED_
