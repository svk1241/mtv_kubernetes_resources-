////////////////////////////////////////////////////////////////////////
// Metavance
// Copyright (C) 2001-2008, EDS
// All Rights Reserved.
//
// EDS
// 225 Grandview Avenue
// Camp Hill, PA  USA
// http://www.eds.com
//
// This source code is the confidential property of EDS, All proprietary
// rights, including but not limited to any trade secret, copyright,
// patent or trademark rights in and to this source code are the
// property of EDS.  This source code is not to be used, disclosed or
// reproduced in any form without the express written consent of EDS.
//
////////////////////////////////////////////////////////////////////////
#include <cctype>
#include <exception>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <string.h>

// HP-UX Itanium unaligned data access signal handler
extern "C" void allow_unaligned_data_access(void);

#include "DestQueues.h"
#include "EventProcessor.h"
#include "IntegrationTable.h"

#define	SYSIN_SYMBOLIC	"SYSIN"
#define IEVENT_SYMBOLIC	"IEVENT"

static std::string g_connectString;

static int MainLine(void)
{
	try
	{
		std::string	sysinFileName;
		std::string eventFileName;

#ifdef TARGET_WIN32
		size_t	cchSymbolic = 0;
		char	symbolic[_MAX_PATH];
#endif

#ifdef TARGET_WIN32
		if (0 == getenv_s(&cchSymbolic, symbolic, SYSIN_SYMBOLIC)
			&& 0 < cchSymbolic)
		{
			sysinFileName = symbolic;
		}
#else
		sysinFileName = getenv(SYSIN_SYMBOLIC);
#endif

		if (0 == sysinFileName.length())
		{
			std::ostringstream sb;
			sb << "No symbolic " << SYSIN_SYMBOLIC << " defined." << std::endl;
			throw std::runtime_error(sb.str());
		}

#ifdef TARGET_WIN32
		if (0 == getenv_s(&cchSymbolic, symbolic, IEVENT_SYMBOLIC)
			&& 0 < cchSymbolic)
		{
			eventFileName = symbolic;
		}
#else
		eventFileName = getenv(IEVENT_SYMBOLIC);
#endif

		if (0 == eventFileName.length())
		{
			std::ostringstream sb;
			sb << "No symbolic " << IEVENT_SYMBOLIC << " defined." << std::endl;
			throw std::runtime_error(sb.str());
		}

		// Obtain queue manager and queue names
		std::ifstream	sysinFile(sysinFileName.c_str());
		DestQueues		queues;
		queues.GetQueueNames(sysinFile);
		sysinFile.close();

		if (0 == queues.size())
		{
			std::cout << "No configured queues in SYSIN=" << sysinFileName << std::endl;
			if (0 != g_connectString.length())
			{
				std::cout << "Using given connect string to read \"INTEGRATION\" table." << std::endl;
				std::vector<std::string> configedQueues =
					IntegrationTable::Get(g_connectString.c_str());

				if (2 <= configedQueues.size())
				{
					for (size_t i = 1; i < configedQueues.size(); ++i)
					{
						DestQueue q(configedQueues[0], configedQueues[i]);
						queues.push_back(q);
					}
				}
			}
			else
			{
				std::cout << "No connect string given; \"INTEGRATION\" table read bypassed." << std::endl;
			}
		}

		if (0 == queues.size())
		{
			std::cout << "No destination queues configured" << std::endl;
			return 0;
		}

		// Name the queues for the user
		std::cout << "Configured queues:" << std::endl;
		int	i = 1;
		for (DestQueues::iterator it = queues.begin(); it != queues.end(); ++it)
		{
			std::cout
				<< i << ": "
				<< (*it).get_Manager() << '/' << (*it).get_Name() << std::endl;
			++i;
		}

		// Attach to MQSeries dynamic link library / shared library
		if (0 == MapFunctions())
		{
			std::cout << std::endl;
			throw std::runtime_error("");
		}

		// Open the queues
		for (DestQueues::iterator it = queues.begin(); it != queues.end(); ++it)
		{
			(*it).Open();
		}

		// Open the event file
		std::ifstream	eventFile(eventFileName.c_str(), std::ios_base::in | std::ios_base::binary);

		// File-to-queue mover
		EventProcessor	events(eventFile, queues);
		events.Process();

		// Close the queues
		for (DestQueues::iterator it = queues.begin(); it != queues.end(); ++it)
		{
			(*it).Close();
		}

		// Statistics
		std::cout 
			<< "Total events read:          " << events.get_Reads() << std::endl
			<< "Total events put on queues: " << events.get_Writes() << std::endl
			<< "Moving events to queues complete" << std::endl
			;

	}
	catch ( oracle::occi::SQLException& e )
	{
		std::cout << "Processing aborted." << std::endl
			<< "Oracle Exception:" << std::endl
			<< "Error code: " << e.getErrorCode() << std::endl
			<< e.getMessage() << std::endl
			;
		std::cout.flush();
		return 1;
	}
	catch (std::exception& ex)
	{
		std::cout << "Processing aborted." << std::endl
			<< ex.what()
			<< std::endl
			;
		return 1;
	}
	catch (...)
	{
		std::cout << "Processing aborted." << std::endl
			<< "An unexpected exception occurred." << std::endl;
		return 1;
	}

	// All went well
	return 0;
}

static void Syntax(void)
{
	std::cout
		<< "Syntax:"	<< std::endl
		<< "MVPPMQSQ [-?] [-db=connectString]"	<< std::endl
		<< std::endl
		<< "Where:"	<< std::endl
		<< "    -?    prints this text"	<< std::endl
		<< "    -db=  specifies the Oracle connect string to use when attempting to"	<< std::endl
		<< "          read MetaVance's \"INTEGRATION\" table."	<< std::endl
		<< std::endl
		<< "Environment variables " << SYSIN_SYMBOLIC << " and " << IEVENT_SYMBOLIC << " must be set."	<< std::endl
		<< std::endl
		<< IEVENT_SYMBOLIC << " specifies the file to read.  All events in the file will"	<< std::endl
		<< "be written to queues."	<< std::endl
		<< std::endl
		<< SYSIN_SYMBOLIC << " specifies which queues should be written and has the following"	<< std::endl
		<< "format:"	<< std::endl
		<< "   Line 1: queue manager name"	<< std::endl
		<< "   Line 2: first queue name"	<< std::endl
		<< "   Line 3: optional second queue name"	<< std::endl
		<< "   Line 4: optional third queue name"	<< std::endl
		<< "   Line 5: optional fourth queue name"	<< std::endl
		<< "   Line 6: optional fifth queue name"	<< std::endl
		<< "   Line 7: optional sixth queue name"	<< std::endl
		<< "   Line 8: line 8 through the end of the file is ignored"	<< std::endl
		<< std::endl
		<< "If the file specified by " << SYSIN_SYMBOLIC << " contains no queue names, an attempt is made" << std::endl
		<< "to read the \"INTEGRATION\" table using the Oracle connect string given via -db=." << std::endl
		<< "If there are no queue names in the table, the program exits with a zero return" << std::endl
		<< "code having taken no action."	<< std::endl
		;
	exit(2);
}

int main(int argc, char* argv[])
{
	allow_unaligned_data_access();

	// Did we get an Oracle connect string on the command line?
	for (int i = 1; i < argc; ++i)
	{
		if ('-' == argv[i][0]
#if defined(TARGET_WIN32)
			|| '/' == argv[i][0]
#endif
			)
		{
			size_t argLen = strlen(argv[i]);

			if (4 <= argLen)
			{
				if ('d' == tolower(argv[i][1])
				&& 'b' == tolower(argv[i][2])
				&& '=' == tolower(argv[i][3]))
				{
					g_connectString = &argv[i][4];
				}
			}
			else if (2 == argLen && '?' == argv[i][1])
			{
				Syntax();
			}
			else
			{
				std::cout << "Syntax error." << std::endl;
				Syntax();
			}
		}
	}
	
	int	returnCode = 0;
	
	if( argc == 1 )
	{
		Syntax();
	}
	else
	{
		returnCode = MainLine();
	}
	return returnCode;
}

#if defined(TARGET_WIN32) || defined(TARGET_LINUX)
void allow_unaligned_data_access(void)
{
	// A symbol to satisify the linker
}
#endif
