/////////////////////////////////////////////////////////////////////////////
//
// Metavance
// Copyright (C) 1998-2000, EDS
// All Rights Reserved.
//
// EDS
// 225 Grandview Avenue
// Camp Hill, PA  USA
// http://www.eds.com
//
// This source code is the confidential property of EDS, All proprietary
// rights, including but not limited to any trade secret, copyright, patent
// or trademark rights in and to this source code are the property of EDS.
// This source code is not to be used, disclosed or reproduced in any form
// without the express written consent of EDS.
//
/////////////////////////////////////////////////////////////////////////////
//
// $NoKeywords: $

// StubTrapper.cpp : Defines the entry point for the console application.
//

#ifdef WIN32
#include "stdafx.h"
#include "StubTrapper.h"
#include <malloc.h>
#else
#include <errno.h>
#include <malloc.h>
#include <stdio.h>
#include <string.h>
#endif

#ifdef _DEBUG
#define STATIC
#else
#define STATIC static
#endif

#ifndef WIN32
#define	__cdecl
#define	_tmain	main
#define	TCHAR	char
#define	_T(x)	x
#define	PCTSTR	const char*
#define PTSTR	char*
#define	_tcscmp	strcmp
#define	_tfopen	fopen
#define	BOOL	int
#define	TRUE	1
#define	FALSE	0
#define _tcsicmp	strcasecmp
#define	_tprintf	printf
#define	LPVOID		void*
#define	ERROR_BAD_FORMAT	45
#define ZeroMemory(p,l)	memset(p, 0, l)
#define	_ftprintf fprintf
#define lstrlenA	strlen
typedef	unsigned int DWORD;
typedef	unsigned int UINT;
#define strnicmp	strncasecmp

class CException
{
public:
	CException()
	{
	}

	BOOL GetErrorMessage(PTSTR pszBuffer, UINT nLen)
	{
		if (0 < nLen)
		{
			strncpy(pszBuffer, "Unknown error", nLen);
			pszBuffer[nLen-1] = '\0';
			return TRUE;
		}
		return FALSE;
	}

	void Delete( void )
	{
	}
};

#endif

/////////////////////////////////////////////////////////////////////////////
// Module data

STATIC  TCHAR szSyntax[] = 
	_T("\nSyntax:") \
	_T("  %s remote-file-name load-module-name \n") \
	_T("\n") \
	_T("Example:") \
	_T("  %s d:\\models\\sc1.ief\\c\\hx01w00w.rmt HX01W00W\n") \
    _T("\n") \
	_T("Return values (ERRORLEVEL) :\n") \
	_T("  1:  syntax error\n") \
	_T("  2:  file error\n") \
	_T("  3:  unknown error\n") \
	_T("  4:  stubbed-out source code found\n\n\n");

#ifdef	WIN32
STATIC  TCHAR*  pszArgv0 = _T("StubTrapper");
#else
STATIC  TCHAR   pszArgv0[] = _T("StubTrapper");
#endif

/////////////////////////////////////////////////////////////////////////////
// Module Prototypes
STATIC  int StubTrapper( PCTSTR pszRmtFile, PCTSTR pszModule, FILE* fileStdout );

/////////////////////////////////////////////////////////////////////////////
// Module Code

#if defined(USE_STUBTRAPPER_MODULE)

extern "C" int StubTrapper( PCTSTR pszRmtFile, PCTSTR pszModule, PCTSTR pszOutFile )
{
    ASSERT( pszRmtFile != 0 );
    ASSERT( AfxIsValidString( pszRmtFile, -1 ) );
    ASSERT( pszModule != 0 );
    ASSERT( AfxIsValidString( pszModule, -1 ) );
 
    FILE*   fileStdout = 0;
    if ( pszOutFile != 0 && AfxIsValidString( pszOutFile, -1 ) )
    {
        // Open message file for append . . .
        fileStdout = _tfopen( pszOutFile, _T("w") );
        if ( 0 == fileStdout )
        {
            // Hmmmm . . . no output file is a syntax error
            return( 1 );
        }
    }

    int iRet = StubTrapper( pszRmtFile, pszModule, fileStdout == 0 ? stdout : fileStdout );
    if ( 0 != fileStdout ) fclose( fileStdout );

    return( iRet );
}

#else

int __cdecl _tmain(int argc, TCHAR* argv[])
{
#if defined(WIN32)
#if ! defined(_AFXDLL)
#error "Program needs MFC in a DLL --OR-- YOU figure out how to attach MFC resource strings to this executable!"
#error "use /MDd /D_DEBUG /D_AFXDLL for a DEBUG build"
#error "use /MD /D_AFXDLL for a RELEASE build"
#endif

	if ( FALSE == AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0 ))
	{
		_tprintf( _T("MFC failed to initialize!  Aborting...") );
		return(3);
	}
#endif

	
#ifdef	WIN32
    pszArgv0 = argv[0];     // process name
#endif

	BOOL    fSyntax=FALSE;
    int     iRet = 0;       // process return code

	if ( argc <= 2 ) //	not enough  arguments
	{
		fSyntax=TRUE;

	}
	else
	{
		if ( (0 == _tcsicmp( _T("-?"), argv[1] ) )|| //syntax query
		     (0 == _tcsicmp( _T("/?"), argv[1] ) )  )
		{
			fSyntax=TRUE;
		}
	}

	if ( fSyntax == TRUE )
	{
		_tprintf(szSyntax, argv[0], argv[0]);
		iRet = 1;
	}
	else
	{
        iRet = StubTrapper( argv[1], argv[2], stdout );
    }

	return( iRet );
}

#endif  // defined(USE_STUBTRAPPER_MODULE)

int StubTrapper( PCTSTR pszRmtFile, PCTSTR _pszModule, FILE* fileStdout )
{
    // Process return code
    int     iRet = 0;

    // The inbound file will most likely be in ANSI characters.  However,
    // we might be compiled as UNICODE.
    FILE*   fin = _tfopen( pszRmtFile, _T("r") );

    char*   pszModule = 0;

	try
	{
        if ( 0 == fin )
        {	
#ifdef	WIN32
            CFileException::ThrowErrno( errno, pszRmtFile );
#else
			throw errno;
#endif
        }

#ifdef	WIN32
#ifdef  _UNICODE
        DWORD   dwLen = ::WideCharToMultiByte( CP_ACP,
                                               0,
                                               _pszModule,
                                               -1,
                                               0,
                                               0,
                                               0,
                                               0 );
        pszModule = reinterpret_cast<char*>( alloca(dwLen + 1) );
        if ( pszModule == 0 ) AfxThrowMemoryException();
        ::WideCharToMultiByte( CP_ACP,
                               0,
                               _pszModule,
                               -1,
                               pszModule,
                               dwLen + 1,
                               0,
                               0 );
#else
        pszModule = (char*) alloca( strlen(_pszModule) + 1 );
        if ( pszModule == 0 ) AfxThrowMemoryException();
        strcpy( pszModule, _pszModule );
#endif
#else
		pszModule = (char*) _pszModule;
#endif

//		CStdioFile stdRmtFile( pszRmtFile,
//                               CStdioFile::modeRead|CStdioFile::shareDenyNone );
		//throw exception if open fails

//		CString szRmtRec;

		BOOL fMoreData=TRUE;
		BOOL fStubbed=FALSE;

		STATIC  char    cSplit[]    = ":split";
		STATIC  char    cEsplit[]   = ":esplit";
		STATIC  char    cMember[]   = "member=";
		STATIC  char    cType[]     = "type=";
		STATIC  char    cLmType[]   = "lmtype=";
		STATIC  char    cStmtProc[] = "PROCEDURE STATEMENTS";
		STATIC  char    cStmtC[]    = "/*     1";
		STATIC  char    cStmtCbl[]  = "     1*";
		STATIC  char    cWinInStmt[]  = "void win_IN_";
		STATIC  char    cWinOutStmt[] = "void win_OUT_";
		STATIC  char    cDlgInStmt[]  = "void dlg_IN_";
		STATIC  char    cDlgOutStmt[] = "void dlg_OUT_";
		STATIC  char    cInOutStmt[]  = "void INOUT_";
		STATIC  char    cOutInStmt[]  = "void OUTIN_";
		STATIC  char    cCpyStmt[]  = "cpy";
		STATIC  char    cEndBracket[] = "}";
		STATIC  char    cSemiColon[]  = ";";
		STATIC  char    cEventStmt[]  = "    WI_BEGIN_EVENT_LIST";
        
		char    szMember[128];
		char*   pRec;
		char*   pTmp;
		char*   pSpace;
        bool    fIsCobol;
		bool    fFoundProc;
		bool    fMemberMatch;
		bool    fFoundOne    = false;
		bool    fMgrOK = true;
		bool    fFoundEvent = false;
		bool    fNtBatch = true;

        char    szRmtRec[1024];
        fgets( szRmtRec, sizeof(szRmtRec), fin );

#ifdef	WIN32
        int iMsk = IS_TEXT_UNICODE_UNICODE_MASK;
        if ( 0 != ::IsTextUnicode( szRmtRec, strlen(szRmtRec), &iMsk ) )
        {
            throw(ERROR_BAD_FORMAT);
        }
#endif

        fMoreData = (feof(fin)) ? FALSE : TRUE;

//		while ( fMoreData )
		while ( ! feof(fin) )
		{
///**/		fMoreData = stdRmtFile.ReadString(szRmtRec); 
			//advance to next ":split"
//			pRec = szRmtRec.GetBufferSetLength(szRmtRec.GetLength());
			pRec = szRmtRec;

            if ( 0 != strstr( pRec, ":remote target=" ) )
            {
                pTmp = strstr( pRec, "type=" );
                if ( 0 != pTmp )
                {
                    pTmp += 5;
                    if ( 0 == strnicmp( pTmp, "CASCADE", 7 ) )
                    {
                        // We don't do RI Triggers
                        break;
                    }
                }
            }

			pTmp = strstr(pRec, cLmType);
			if ( pTmp != NULL )
			{
				//found an "lmtype=" string; this must be 
				//cooperatively packaged (not NT batch)
				fNtBatch= false;
			}

			pTmp = strstr(pRec, cSplit);
			//if ( pTmp == NULL )
			if ( pTmp != pRec )
			{
				//haven't found ":split" yet, return to top of loop
				//OR
				//found ":split", but not at the beginning of a line, 
				// in which case it doesn't count anyway.
                fgets( szRmtRec, sizeof(szRmtRec), fin );
				continue;
			}

			//:split found, find member=
			pTmp = strstr(pRec, cMember );
			if ( pTmp ==  NULL)
			{
				//member= not found
				throw(ERROR_BAD_FORMAT);
			}
			else
			{
				//advance pointer to member value
				pTmp += strlen(cMember);
				pSpace = strchr( pTmp, ' ' ) ;
				if (    (pTmp >= &pRec[strlen(pRec)] )
					 || (pSpace == NULL ) )
				{
					//no value after member=
					throw(ERROR_BAD_FORMAT);
				}
			}

			//if ( 0 == strnicmp(pTmp, pszModule, strlen(pszModule) ) )
			if ( 0 == strnicmp( pTmp, pszModule, pSpace - pTmp ) ) 
			{
				/*//member=module, ignore this one, jump back to top of loop
                fgets( szRmtRec, sizeof(szRmtRec), fin );
				continue;*/
				//actually, no, if member=module, this could be a window 
				//manager, so we can still check to see if it is stubbed out.
				//go on, and any member=module that is not type=C will be thrown
				//out later.
				fMemberMatch = true;
			}
			else
			{
				fMemberMatch = false;
			}

            char    szViewDef41a[16];
            ::ZeroMemory( szViewDef41a, sizeof(szViewDef41a) );
            strncpy( szViewDef41a, pszModule, sizeof(szViewDef41a) - 1 );
            szViewDef41a[strlen(szViewDef41a)-1] = 'V';
    		if ( 0 == strnicmp(pTmp, szViewDef41a, strlen(szViewDef41a) ) )
	    	{
		    	//member=module, ignore this one, jump back to top of loop
                fgets( szRmtRec, sizeof(szRmtRec), fin );
				continue;
    		}

            ::ZeroMemory( szMember, sizeof(szMember) );

			char* pSpace = strstr(pTmp, " " );
			if ( pSpace == NULL )
			{
				throw(ERROR_BAD_FORMAT);
			}
			else
            {
				strncpy(szMember,pTmp, (pSpace - pTmp)  );
			}

			//find "type=", advance pointer to type value
			pTmp = strstr(pRec, cType);
			if ( pTmp ==  NULL)
			{
				//type= not found
				throw(ERROR_BAD_FORMAT);
			}
			else
			{
				//advance pointer to type value
				pTmp += strlen(cType);
				if ( pTmp >= &pRec[strlen(pRec)] )
				{
					//no value after member=
					throw(ERROR_BAD_FORMAT);
				}
			}

			//if type is "C" or "sqc", choose "C" indicator and keep going.
			//3/13/03 "Create Remote Files..." produces "type=C." w/ period.  
			if ( ( 0 == strnicmp(pTmp, "C ",  2))  ||
				 ( 0 == strnicmp(pTmp, "C.",  2))  ||  //3/13/03
			     ( 0 == strnicmp(pTmp, "sqc", 3))    )
			{ 
				fIsCobol = false;
			}
			else
			{
				//if type is "CBL", choose "COBOL" indicator and keep going
				if ( 0 == strnicmp(pTmp, "CBL", 3) )
				{
    				fIsCobol = true;
				}
				else
				{
					//neither "C" nor "SQC" nor "COBOL" - return to top of loop
    				fIsCobol = false;
                    fgets( szRmtRec, sizeof(szRmtRec), fin );
					continue;
				} //end-if "CBL"
			} //end-if "C" or "SQC

			//at this point, type must be "C" or "sqc" or "CBL"
			//read next line from rmt and search for pattern or :esplit
            fgets( szRmtRec, sizeof(szRmtRec), fin );
            fMoreData = (feof(fin)) ? FALSE : TRUE;
			fFoundProc = false;
///**/		fMoreData = stdRmtFile.ReadString(szRmtRec);
//			while ( fMoreData )
			if ( true == fMemberMatch )
			{
				while ( ! feof(fin) )
				{
					//must be a dialog manager
					if ( false == fIsCobol )
					{
						pTmp = strstr( szRmtRec, cEsplit );
						if ( pTmp != NULL )
						{
							if ( ! fMgrOK )
							{
								fMemberMatch = false;
								_ftprintf( fileStdout, _T("Source member %hs is \"stubbed out\".\n"), szMember);
								fStubbed = TRUE;
							}
							break;
						}

						if ( true == fFoundOne )
						{
							//we've found one of the six paragraphs 
							//we're looking for, but haven't found 
							//a "}" yet
							pTmp = strstr( szRmtRec, cCpyStmt );
							if (    ( pTmp != NULL )
								 || ( true == fFoundEvent ) )
							{
								//found a "cpy" before "}", or found 
								//an event table, so Mgr is not stubbed.
								fMgrOK = true;
								fMemberMatch = false;
								//advance to :esplit
								while ( ! feof(fin) )
								{
									fgets( szRmtRec, sizeof(szRmtRec), fin);
									pTmp = strstr( szRmtRec, cEsplit );
									if ( pTmp != NULL )
									{
										fgets( szRmtRec, sizeof(szRmtRec), fin);
										break;
									}
								}
								break;
							}
							else 
							{
								//didn't find a "cpy" yet - is there a bracket? 
								pTmp = strstr( szRmtRec, cEndBracket );
								if ( pTmp != NULL )
								{
									//uh oh.  this gv1_hole paragraph is empty.
									fFoundOne = false;

								}//endif findstr "}"
							}//end-if findstr "cpy"
						}
						else //haven't found one of the six yet
						{
							//don't bother if it's NT batch.
							if ( ! ( fNtBatch ) )
							{
								pTmp = strstr( szRmtRec, cEventStmt );
								if ( pTmp != NULL )
								{
									fFoundEvent = true;
								}
								else
								{
									//continue with checking the other statements
									pTmp = strstr( szRmtRec, cWinInStmt );
								}
								if ( pTmp == NULL ) pTmp = strstr( szRmtRec, cWinOutStmt );
								if ( pTmp == NULL ) pTmp = strstr( szRmtRec, cDlgInStmt );
								if ( pTmp == NULL ) pTmp = strstr( szRmtRec, cDlgOutStmt );
								if ( pTmp == NULL ) pTmp = strstr( szRmtRec, cInOutStmt );
								if ( pTmp == NULL ) pTmp = strstr( szRmtRec, cOutInStmt );

								//now if any of those returned a result...
								if ( pTmp != NULL) 
								{
									//get the next line and see if it is ";"
									fgets( szRmtRec, sizeof(szRmtRec), fin);
									pTmp = strstr( szRmtRec, cSemiColon );
									if ( pTmp != NULL && lstrlenA(szRmtRec) == 2)
									{
										//never mind, this is the function definition
									}
									else
									{
										//we found one, so wait and see if mgr is stubbed out
										fMgrOK = false;
										fFoundOne = true;
									}

								}
							}
						}
						fgets( szRmtRec, sizeof(szRmtRec), fin );
						continue;					
					}
				}
			}
			else
			{
				while( ! feof (fin) )
				{

					if ( true == fFoundProc )
					{
						if ( true == fIsCobol )
						{
							pTmp = strstr( szRmtRec, cStmtCbl );
							if ( pTmp != &szRmtRec[0] )
							{
								//string not found at beginning of line - ignore it.
								pTmp = NULL;
							}
						}
						else 
						{
							pTmp = strstr( szRmtRec, cStmtC );
							if ( pTmp != &szRmtRec[0] )
							{
								//string not found at beginning of line - ignore it.  
								pTmp = NULL;
							}
						}
					}
					else //haven't found "PROCEDURE STATEMENTS" yet
					{
						pTmp = strstr( szRmtRec, cStmtProc );
						if ( pTmp != NULL )
						{
							//found "PROCEDURE STATEMENTS", continue search looking for 1st 
							//Coolgen statement.
							fFoundProc = true;
							pTmp = NULL;
						}
					}


					if ( pTmp != NULL)
					{
						//this member is not stubbed out.
						//stop scanning this member.
						break;
					}
					else
					{
						//check to see if we've come to the end of this member
						pTmp = strstr(szRmtRec, cEsplit);
						if (pTmp != NULL)
						{
							_ftprintf( fileStdout, _T("Source member %hs is \"stubbed out\".\n"), szMember);
							fStubbed = TRUE;
							break;
						}
						else
						{
							//not the end of the member yet, keep reading.
	///**/					fMoreData = stdRmtFile.ReadString(szRmtRec);
							fgets( szRmtRec, sizeof(szRmtRec), fin );
							fMoreData = (feof(fin)) ? FALSE : TRUE;
						}
					}/* end-if */
				}/* end-while (while not membermatch) */

				//whether this member stubbed or not, 
				//return to top of loop and find next :split
				fgets( szRmtRec, sizeof(szRmtRec), fin );
			
			}
		}/* end-while */ 
			
		if ( fStubbed == TRUE) 
		{
			TCHAR msg[] = 
			   _T("\n\n") \
			   _T("Due to the above error(s), your build has not been \n")    \
			   _T("submitted to the Build Tool Proxy for processing.\n")      \
			   _T("\n")                                                       \
			   _T("To correct this error:\n")                                 \
			   _T("  -delete the identified source member(s) from ")          \
			   _T("your source code folder.\n")                                     \
			   _T("  -go back to COOL:Gen's generation window.\n")            \
			   _T("  -perform the \"Install\" step for this load module again.") \
			   _T("\n\n")                                                     \
			   _T("Then try your build again.\n");
			_ftprintf( fileStdout, _T("%s"), msg );
			_ftprintf( fileStdout, _T("*** Build for Load Module %s Failed. ***\n"), _pszModule); 
			iRet = 4;
		}
		else
		{
			iRet = 0;
		}
	}/* end-try */

#ifdef	WIN32
	catch( CFileException* e )
	{
		TCHAR	szMsg[256] = { _T('\0') };
		e->GetErrorMessage( szMsg, sizeof(szMsg) );
		_ftprintf( fileStdout, _T("File exception:  %s\n"), szMsg);
        e->Delete();
		iRet = 2;
	}
#endif
	
	catch( CException* e )
	{
		TCHAR	szMsg[256] = { _T('\0') };
		e->GetErrorMessage( szMsg, sizeof(szMsg) );
		_ftprintf( fileStdout, _T("Unknown error occurred: %s\n"), szMsg);
        e->Delete();
		iRet = 3;
	}

	catch( long e )
	{
		//oops...?
		LPVOID lpMsgBuf;
		DWORD  dwErr;

#ifdef	WIN32
		if ( e == 0 )
		{
			dwErr = GetLastError();
		}
		else
		{
			dwErr = DWORD(e);
		}

		FormatMessage( 
			FORMAT_MESSAGE_ALLOCATE_BUFFER | 
			FORMAT_MESSAGE_FROM_SYSTEM | 
			FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL,
			dwErr,
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
			(LPTSTR) &lpMsgBuf,
			0,
			NULL 
			);
#else
		dwErr = e;
		lpMsgBuf = NULL;
#endif

//		_tprintf( _T("%s:\n"), argv[0] );
//		_tprintf( _T("  %s:\n"), argv[1]);

		_ftprintf( fileStdout, _T("%s:\n  %s:\n"),
            pszArgv0,
            pszRmtFile );


		if ( ( dwErr >= 2) &&
			 ( dwErr <= 5)    ) //file error, which I've defined as RC=2
		{
//			_tprintf( _T("    %s"), argv[2] );
			_ftprintf( fileStdout, _T("    %s\n"), pszModule );
    		iRet = 2;
		}
		else
		{
			_ftprintf( fileStdout, _T("    An unexpected error has occurred.  The file might ") );
			_ftprintf( fileStdout, _T("not be a valid .RMT file.") );
			if ( dwErr > 0 && NULL != lpMsgBuf)
			{
				_ftprintf(fileStdout, _T("      System message: %s\n"), lpMsgBuf);
			}

    		iRet = 3;
		}
	}

    if ( 0 != fin ) fclose(fin);

    return( iRet );
}

