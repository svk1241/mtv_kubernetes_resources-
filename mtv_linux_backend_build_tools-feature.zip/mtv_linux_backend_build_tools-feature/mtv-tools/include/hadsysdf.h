/* Common Operating System Dependent Global includes for C version */

/* (c) Copyright 2017 nThrive, Inc. */

/* hadsysdf.h */

/* This is the only section that needs alteration for different
 * target machines.
 * Add overrides below in '#if defined()' blocks, and send back to IRP
 * so we can incorporate in next release.
 */

/* available system defines:
 *  MSDOSBORLC  - MS-DOS Borland C++
 *  IBMAS400    - IBM AS/400 C - original EPM model
             *  IBMAS400ILE - IBM AS/400 ILE C - will also define IBMAS400
 *  HPMPEIXC    - HP3000 MPEIXC C
 *  IBMRS6000   - IBM RS/6000 c
 *  PCWIN       - Windows 16 bit DLL (Borland compiler)
 *  PCWIN32     - Windows NT/95 32 bit DLL (Borland compiler)
 *  IBMRS6000SH - IBM RS/6000 Shared Memory (replaced by
 *                    IBMRS6000
 *  UNIX        - Generic UNIX (with STATIC32TBL)
 - works with UNIXWare
 *  UNIXUTS     - Amdahl UTS System V
 *  SCOUNIX     - Generic UNIX (with FILETBLREAD)
             *  DECOSFU     - DEC OSF Unix C Compiler
                                (with STATIC32TBL, and pragmas to handle
                                 proper alignment of certain internal
                                 structure arrays.  This allows the static
                                 data tables to work (because we compile
                                 with nomember_alignment)).
             *  DECOVMS     - DEC Open VMS (Alpha) C Compiler
                              uses STATIC32TBL, but r,w for READ_, WRITE_TEXT
 *  PCOS2DLL    - OS/2 DLL
 *  PCOS2       - OS/2 exe OBJ
 */

/*  change log:
 *    07/13/96 szh initial creation from existing components
 *    07/19/96 szh moved as/400 trigraph define to a separate header,
 *                     hadsysa4.h
 *    07/26/96 szh added define for "far" to nothing for non-DOS, non-PCWIN
 *    09/15/96 szh added unlink/remove for AS/400
 *                 added DIRDELIMIT for AS/400 for library/file separator
 *    09/20/96 szh added redefine for ftell for UNIXUTS
 *    09/22/96 szh added define for SCOUNIX - needs bin tables
 *    09/30/96 szh added PCWIN32 define for win nt/95
 *    11/14/96 szh added IRPEXTENT IRPEXTCALL variables to model
 *                       entry point and function headers more easily.
 *                       also added HADSYSDF_INCLUDED flag, test.
 *    11/19/96 szh added IRPEXTERNC for C++ compiles
 *    04/08/98 szh added DECOSFU define and special #pragmas around
 *                       certain structures that need to have members
 *                       properly aligned for Alpha UNIX machine
 *                       otherwise get Unaligned access errors when
 *                       getting from or storing to non-aligned int or
 *                       pointer fields within the structure.
 *    06/18/98 szh changed READ_BIN, WRITE_BIN for OS/2 to rb, wb instead
 *                       of r,w;  default was to process text mode if b
 *                       not specified; caused early EOF on binary files.
 *                       also changed READ_TEXT and WRITE_TEXT to rt,wt.
 *                 made the same change for UNIX, RS6000, and HP
 *    08/18/98 szh added DECOVMS define
 *                 NOTE:  DIRDELIMIT probably doesnt work for VMS and needs
 *                        actual code changes!!
 *                 unlink is remove for DECOVMS
 *    09/23/98 szh UNIXUTS needs READ_TEXT, WRITE_TEXT r,w not rt,wt
 *                 same for READ_BIN, WRITE_BIN = r,w not rb, wb
 *    01/18/99 szh added defines needed by CodeBase for various platforms
 *                 - need to be completed.
 *    03/24/99 szh added Y2KPIVOTYR here - this is used by various IRP
 *                 programs internally to decide on cc=20 if yy<Y2KPIVOTYR
 *    05/19/99 szh added IBMAS400ILE define
 *    06/23/99 twf added PATHDELIMIT definition
 *    08/18/99 twf add conditional and #define access
 *    07/14/00 twf add EBCDICPLATFORM
 *    07/24/00 twf add LITTLE_ENDIAN_PLATFORM
 *    08/25/00 twf remove EBCDICPLATFORM and LITTLE_ENDIAN_PLATFORM
 *                 LITTLE_ENDIAN_PLATFORM not used and EBCDICPLATFORM
 *                 determined at runtime in haaf1ac1:hpgsstartup
 *    08/29/00 twf added IBMRS6000A identical to IBMRS6000 for
 *                 AIX Version 3.2 which cannot handle large table
 *                 so haaf1ac1.c can use FILEREADTBL for 3.2
 *    09/01/00 twf likewise UNIXWARE because unixware cannot compile
 *                 large table = this may be temporary
 *    09/01/00 twf likewise DECOVMSA because decvms cannot compile
 *                 large table = this may be temporary
 *    09/27/00 twf likewise NCRUNIX because ncr cannot compile
 *                 large table = this may be temporary
 *    10/17/01 twf add defines for haint64, haint32, haint16, haint8 for win32
 *    04/19/02 twf add IBMCOMPILEONPC definition;used with ibmcmpile.ide
 *                 project which puts output in win32dll\ibmdummy
 *    08/08/02 twf add MS6COMPILER conditional so that the code will compile
 *                 with microsoft v6.0 compiler, it seems _export is no longer
 *                 valid, must be __declspec( dllexport ); if this is not
 *                 found then the linker will not generate a .lib for the .dll
 *    11/22/02 twf using the __declspec(dllexport) generates c calling
 *                 convention
 *                 and calling program clears the stack and exported name is
 *                 _name.  There is a compiler command line option /Gz which
 *                 will generate __stdcall call convention with called program
 *                 clearing the stack and exported name is
 *                 _name@<size of arguments in bytes>
 *    12/04/02 szh shortened lines for as400
 *    09/11/03 twf add __cdecl cast for all Microsoft run time functions
 *                 since everything is compiled with stdcal
 *    10/15/03 twf irp - change copyright notice
 *    10/20/03 twf irp move string_compare_md and string_compare_rg and
 *                 string_compare_dr to hadsysdf.h since they are used by
 *                 all fed groupers and use MS6COMPILER conditional
 *    07/28/04 twf add: #if defined(MPEUNIX)
 *    01/14/06 twf add edit_rtn_sz for new APC sizes
 *    01/14/06 twf add v7_flag_sz for status, payindicator,pay adjust
 *    03/24/06 twf add IRPUNEXPAND dependency
 *    06/19/06 twf comment out IRPUNEXPAND dependency, now defaults to
 *                  EXPANDED
 *    12/27/06 twf set APG_MAX_SG to 100
 *    08/03/07 ejf Changed copyright notice
 *    12/29/07 dme Added definitons for Microsoft Visual Studio 2005
 *    08/13/08 djc Removed include of hadsysa4.h for AS400 after verifying
 *                 that it is no longer needed
 *
 */

#ifndef HADSYSDF_INCLUDED
#define HADSYSDF_INCLUDED

#define SYSTEM_X
#define UNIX

                           /* Y2KPIVOTYR;  used in various IRP programs
                            * if yy<Y2KPIVOTYR, century=20
                            * else              century=19
                            */
#define Y2KPIVOTYR 36

/* conditional debug logic - comment out for production */

/* #define IRPDBUG
 */

/* if no valid system is defined, default
 * to MSDOSBORLC
 */

#ifdef _MSC_VER /* predefined by Microsoft Compiler */
#include <io.h>
#define access _access
#endif  /* _MSC_VER */

#if defined(MS6COMPILER)
#define DllImport   __declspec( dllimport )
#define DllExport   __declspec( dllexport )
#endif

#if defined(MSDOSBORLC)
#define FILEREADTBL
#define SYSDEF
#endif
#if defined(IBMAS400)
#define STATIC32TBL
#define SYSDEF
#endif
#if defined(IBMAS400ILE)
#ifndef IBMAS400
#define IBMAS400
#endif
#define STATIC32TBL
#define SYSDEF
#endif
#if defined(HPMPEIXC)
#define STATIC32TBL
#define UNIX
#define SYSDEF
#endif
#if defined(DECOSFU)
#define STATIC32TBL
#define UNIX
#define SYSDEF
#define haint64 double
#define haint32 int
#define haint16 short int
#define haint08 unsigned char
#endif
#if defined(DECOVMS)
#define STATIC32TBL
#define SYSDEF
#endif
#if defined(DECOVMSA)
#define DECOVMS
#define STATIC32TBL
#define SYSDEF
#endif
#if defined(IBMRS6000)
#define STATIC32TBL
#define UNIX
#define SYSDEF
#endif
#if defined(IBMRS6000A)
#define IBMRS6000
#define UNIX
#define STATIC32TBL
#define SYSDEF
#endif
#if defined(NCRUNIX)
#define UNIX
#define STATIC32TBL
#define SYSDEF
#endif
#if defined(UNIXWARE)
#define UNIX
#define STATIC32TBL
#define SYSDEF
#endif
#if defined(MPEUNIX)
#define UNIX
#define STATIC32TBL
#define SYSDEF
#endif
#if defined(UNIX64)
#define UNIX
#define STATIC32TBL
#define SYSDEF
#define haint64 long
#define haint32 int
#define haint16 short int
#define haint08 unsigned char
#endif
#if defined(AIX64)
#define SYSDEF
#define haint64 long
#define haint32 int
#define haint16 short int
#define haint08 unsigned char
#endif
#if defined(IBMRS6000SH)
#define IBMRS6000
#define UNIX
#define FILEREADTBL
#define SYSDEF
#endif
#if defined(UNIXUTS)
#define UNIX
#define FILEREADTBL
#define SYSDEF
#endif
#if defined(SCOUNIX)
#define UNIX
#define FILEREADTBL
#define SYSDEF
#endif
#if defined(PCWIN)
#define MSDOSBORLC
#define DLLRESTBL
#define SYSDEF
#endif
#if defined(PCWIN32)
#define STATIC32TBL
#define SYSDEF
#define haint64 double
#define haint32 long
#define haint16 short int
#define haint08 unsigned char
#endif
#if defined(PCOS2DLL)
#define PCOS2
#endif
#if defined(PCOS2)
#define STATIC32TBL
#define SYSDEF
#endif
#if defined(IBMZOS)
#define STATIC32TBL
#define SYSDEF
#endif

/* defaults for UNIX
 * if no specific one selected above
 */
#if defined(UNIX)
#ifndef SYSDEF
#define STATIC32TBL
#define SYSDEF
#endif
#endif


#if defined(SYSDEF)
  /* do nothing */
#else
#define MSDOSBORLC
#define FILEREADTBL
#define SYSDEF
#endif

/* default for table model */
#ifndef STATIC32TBL
#ifndef FILEREADTBL
#ifndef DLLRESTBL
#define FILEREADTBL
#endif
#endif
#endif

/* default values for int sizes */
#ifndef haint64
#define haint64 double
#endif
#ifndef haint32
#define haint32 long
#endif
#ifndef haint16
#define haint16 short int
#endif
#ifndef haint08
#define haint08 unsigned int
#endif


/* For PC, DLL versions we define the call structure here
 * through a preprocessor variable set - default to blanks,
 * set as needed
 */

#define IRPEXTENT
#define IRPEXTCALL


#ifdef _cplusplus
#define IRPEXTERNC extern "C"
#else
#define IRPEXTERNC extern
#endif

#if defined(IBMZOS)
#undef  IRPEXTERNC
#define IRPEXTERNC extern
#endif


#if defined(MSDOSBORLC)

/* Target system dependencies
 * These are for MS-DOS on a PC (Intel 8x86 chip set)
 * - Borland C++ compiler (using only basic C conventions)
 * Duplicate and modify these in the next section as needed for each
 * target machine architecture and OS
 */

#define READ_BIN        "rb"
#define READ_TEXT       "rt"
#define WRITE_BIN       "wb"
#define WRITE_TEXT      "wt"
#define FARMALLOC       farmalloc
#define FARFREE         farfree
#ifndef HUGE
#define HUGE            huge /* far huge */
#endif
#ifndef FAR
#define FAR             far
#endif
#define XOR ^

/* CodeBase defines */
#define S4STATIC
#define S4DOS

#endif


#if defined(PCWIN32)

#define READ_BIN        "rb"
#define READ_TEXT       "rt"
#define WRITE_BIN       "wb"
#define WRITE_TEXT      "wt"
#define FARMALLOC       malloc
#define FARFREE         free
#define HUGE
#ifndef FAR
#define FAR
#endif
#define far
#define farfree         free
#define farmalloc       malloc
#define XOR ^

#undef  IRPEXTENT
#undef  IRPEXTCALL

#if defined(MS6COMPILER)
#define IRPEXTENT   __declspec( dllexport )
#define IRPEXTCALL  __declspec( dllimport )
#else
#define IRPEXTENT       __stdcall _export
#define IRPEXTCALL      __stdcall
#endif

/* CodeBase defines */
#define S4DLL
#define S4WIN32


#endif

#ifdef IBMAS400
/* for the AS/400, read_bin, _text, Write_
 * are for character stream, not record i/o
 * functions. */

#define READ_BIN        "rb"
#define READ_TEXT       "r"
#define WRITE_BIN       "wb"
#define WRITE_TEXT      "w"
#define FARMALLOC       malloc
#define FARFREE         free
#define FAR
#define HUGE
#define far
#define DIRDELIMIT      "/"
#define PATHDELIMIT     ":"

/* the AS/400 remove function is same as
 * C unlink
 */

#define unlink          remove

#endif


#if defined(PCOS2) || defined(PCOS2DLL)
                               /* 06-18-98 changed from r,w to rt,rb,wb,wt */
#define READ_TEXT       "rt"
#define READ_BIN        "rb"
#define WRITE_BIN       "wb"
#define WRITE_TEXT      "wt"
#define FARMALLOC       malloc
#define FARFREE         free
#define FAR
#define HUGE
#define far

#undef  IRPEXTENT
#undef  IRPEXTCALL
#define IRPEXTENT       _export __syscall
#define IRPEXTCALL      __syscall

/* CodeBase defines */
#define S4DLL
#define S4OS2



#endif

#if defined(IBMZOS)

#define READ_TEXT       "r"
#define READ_BIN        "rb"
#define WRITE_BIN       "wb"
#define WRITE_TEXT      "w"
#define FARMALLOC       malloc
#define FARFREE         free
#define FAR
#define HUGE
#define far

#undef  IRPEXTENT
#undef  IRPEXTCALL

#define IRPEXTENT
#define IRPEXTCALL

#endif

#if defined(DECOVMS)
                               /* 08-18-98 added */

#define READ_TEXT       "r"
#define READ_BIN        "rb"
#define WRITE_BIN       "wb"
#define WRITE_TEXT      "w"
#define FARMALLOC       malloc
#define FARFREE         free
#define FAR
#define HUGE
#define far
#define DIRDELIMIT      "/"
#define PATHDELIMIT     ":"

/* the DECOVMS C remove function is same as
 * unlink
 */

#define unlink          remove

#endif


#if defined(UNIX) || defined(IBMRS6000) || defined(HPMPEIXC)
                               /* 06-18-98 changed from r,w to rt,rb,wb,wt */

#define READ_TEXT       "rt"
#define READ_BIN        "rb"
#define WRITE_BIN       "wb"
#define WRITE_TEXT      "wt"
#define FARMALLOC       malloc
#define FARFREE         free
#define FAR
#define HUGE
#define far
#define DIRDELIMIT      "/"
#define PATHDELIMIT     ":"

/* CodeBase defines */
#define S4STATIC
#define S4UNIX




#endif


#if defined(UNIXUTS)

                              /* rt, wt not valid un UNIXUTS */
#undef READ_TEXT
#define READ_TEXT       "r"
#undef WRITE_TEXT
#define WRITE_TEXT      "w"
#undef READ_BIN
#define READ_BIN        "r"
#undef WRITE_BIN
#define WRITE_BIN       "w"

/* for some reason, the std headers in UTS are
 * redefining ftell to ftell_long, which is not
 * defined in UTS.  This redef will occur after
 * the stdio.h, etc includes and will set ftell
 * back to ftell.
 */
#define ftell ftell


/* CodeBase defines */
#define S4STATIC
#define S4UNIX




#endif



/* If all defines not set in
 * above, default individual ones
 * to MSDOSBORLC settings.
 */

#ifndef READ_BIN
#define READ_BIN        "rb"
#endif
#ifndef READ_TEXT
#define READ_TEXT       "rt"
#endif
#ifndef WRITE_BIN
#define WRITE_BIN       "wb"
#endif
#ifndef WRITE_TEXT
#define WRITE_TEXT      "wt"
#endif
#ifndef FARMALLOC
#define FARMALLOC       farmalloc
#endif
#ifndef FARFREE
#define FARFREE         farfree
#endif
#ifndef HUGE
#define HUGE            huge /* far huge */
#endif
#ifndef FAR
#define FAR             far /* far huge */
#endif
#ifndef XOR
#define XOR ^
#endif
#ifndef DIRDELIMIT
#define DIRDELIMIT      "\\"
#endif
#ifndef PATHDELIMIT
#define PATHDELIMIT    ";"
#endif

/* #if defined(IBMAS400) || defined(PCOS2) || defined(DECOVMS) */
#if defined(IBMAS400) || defined(DECOVMS)
#define access  IRPACCESS
#endif

/* force far versions of routines for win16 */
#ifdef PCWIN
#define MEMCPY          _fmemcpy
#define MEMSET          _fmemset
#define MEMCMP          _fmemcmp
#define MEMCCPY         _fmemccpy
#define MEMCHR          _fmemchr
#define MEMICMP         _fmemicmp

#define STRLEN          _fstrlen
#define STRSPN          _fstrspn

/* CodeBase defines - might have defined for MSDOSBORLC above,
   so clear out here  */
#ifdef  S4STATIC
#undef  S4STATIC
#endif
#define S4DLL
#ifdef  S4DOS
#undef  S4DOS
#endif
#define S4WIN16




#else

#define MEMCPY          memcpy
#define MEMSET          memset
#define MEMCMP          memcmp
#define MEMCCPY         memccpy
#define MEMCHR          memchr
#define MEMICMP         memicmp

#define STRLEN          strlen
#define STRSPN          strspn


#endif  /* if PCWIN else ...  */

#ifdef IBMCOMPILEONPC
/* the following is an attempt to compile on a pc with
 * ibm constants defined
 * e.g. IBMAS400
 * the XOR is not defined, so add IBMCOMPILEONPC define in project
 * ..\win32dll\ibmcmpile.ide
 *
 * trying to eliminate errors before the source is moved to the as400 platform
 *
 */
#define XOR ^
#endif

#if defined(MS6COMPILER)
int __cdecl string_compare_md( char *arg1, char **arg2 );
int __cdecl string_compare_dr( char *arg1, char **arg2 );
int __cdecl string_compare_rg( char *arg1, char **arg2 );
#else
int string_compare_md( char *arg1, char **arg2 );
int string_compare_dr( char *arg1, char **arg2 );
int string_compare_rg( char *arg1, char **arg2 );
#endif

#define edit_rtn_sz 3      /* 2 for APC versions < 7b; 3 after */
#define v7_flag_sz  2      /* 1 for APC versions < 7b; 2 after */
#define sz_expand   1      /* 0 for APC versions < 7b; 1 after */

#ifdef _MSC_VER /* predefined by Microsoft Compiler */
# ifdef FAR
#  undef FAR
# endif
# define FAR
# ifdef far
#  undef far
# endif
# define far
# ifdef _export
#  undef _export
# endif
# define _export
# ifdef unlink
#  undef _unlink
# endif
# define unlink _unlink
#endif  /* _MSC_VER */
#endif    /* HADSYSDF_INCLUDED */
