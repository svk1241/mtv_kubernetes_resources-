
/*  
  CA1100.H - Procedure Level Integration Record

  Product:  ClaimCheck R10.0
  Platform: UNIXes, ALPHA, PC
  Author:   TDN
  Date:     04/22/2003
  Modified: 12/20/2010
  
    R10.0 Changes:
    *<>*  COPYBOOK CAC1100                                 
    *<>*  TITLE:   PROCEDURE LEVEL DATA (LENGTH: 46500)    
    *<>*           EACH OCCURRENCE = 372 * [125] = 46500                  
    *<>*                                                   
    SUPPORT 100 MAXIMUM INPUT PX LINES, 125 OUTPUT LINES
    HIPAA CHANGES - EXPAND PROVIDER, SPECIALTY,   
    12 CLAIM-LEVEL DIAGNOSIS
    4 PX-LEVEL, ALLOW SEX='U'     
    ALL DATE FIELDS ARE IN CCYYMMDD FORMAT
    **************************************************
*/

#ifndef CA1100_H
#define CA1100_H

#define CA1100_SCE_ASURG_SOMETIMES     'S'

#define CA1100_PAY_AGE_REPLACE         'A'
#define CA1100_PAY_MUTEXCLU            'M'
#define CA1100_PAY_INCIDENTAL          'I'
#define CA1100_PAY_NONCOVERED          'N'
#define CA1100_PAY_REPLACED            'R'
#define CA1100_PAY_SEX_REPLACE         'S'
#define CA1100_PAY_VISIT_CODE          'V'
#define CA1100_PAY_ASURG_DENIED        'D'
#define CA1100_PAY_ASURG_AS_DENIED     'E'
#define CA1100_PAY_PRE_OP              'P'
#define CA1100_PAY_POST_OP             'O'
#define CA1100_PAY_DUPLICATE           'U'
#define CA1100_PAY_UM_REPLACE          'G'
#define CA1100_PAY_UM_DENY             'H'
#define CA1100_PAY_HIST_DENIED         'J'
#define CA1100_PAY_IOS                 'T'
#define CA1100_PAY_DXPX                'X'
#define CA1100_PAY_NVF                 'F'
#define CA1100_PAY_SS_DENY             'Z'
#define CA1100_PAY_GOOD                '0'
#define CA1100_PAY_1ST_LEVEL           '1'
#define CA1100_PAY_2ND_LEVEL           '2'
#define CA1100_PAY_3RD_LEVEL           '3'
#define CA1100_PAY_4TH_LEVEL           '4'
#define CA1100_PAY_OTHER               '5'
#define CA1100_PAY_INVALID             '9'
#define CA1100_PAY_PXDX                'W'      /* cc10 PxDx */
#define CA1100_PAY_MUE                 'Y'      /* cc10 MUE */

/* ----- ca1100_code_origination values */
#define CA1100_ORIGINAL_CODE           '0'
#define CA1100_RULES_CODE              '1'
#define CA1100_SEX_SUBSTITUTE          '2'
#define CA1100_AGE_SUBSTITUTE          '3'
#define CA1100_UM_CODE                 '4'
#define CA1100_IOS_SUBSTITUTE          '6'
#define CA1100_NVF_SUBSTITUTE          '7'

/*----- ca1100_cpt_module_id values */
#define CA1100_SURGERY                 'S'
#define CA1100_RADIOLOGY               'R'
#define CA1100_LAB                     'L'
#define CA1100_MEDICINE                'M'
#define CA1100_EVAL_MAN                'E'
#define CA1100_ANESTHESIA              'A'
#define CA1100_USER_DEFINED            'U'


/*----- ca1100_policy_ind values */
#define CA1100_INC_POLICY              'A'
#define CA1100_ME_POLICY               'B'
#define CA1100_INC_ME_POLICY           'C'
#define CA1100_MCR_POLICY              'D'
#define CA1100_MCR_INC_POLICY          'E'
#define CA1100_MCR_ME_POLICY           'F'
#define CA1100_MCR_ME_INC_POLICY       'G'

/*----- ca1100_code_status values */
#define CA1100_BOTH_AVAIL              '0'
#define CA1100_UANDC_UNAVAIL           '1'
#define CA1100_CHARGE_UNAVAIL          '2'
#define CA1100_BOTH_UNAVAIL            '3'

/*----- ca1100_duplicate_flag values */
#define CA1100_DUP_NO                  '0'
#define CA1100_DUP_YES                 '1'
#define CA1100_DUP_YES_SUPPRESS        '2'

/*----- ca1100_entry_mode values */
#define CA1100_ETC_MODE                'E'
#define CA1100_CTE_MODE                'C'

/*----- ca1100_mod_warn_ind values */
#define CA1100_MOD_WARN_VISIT          'V'
#define CA1100_MOD_WARN_POST           'O'
#define CA1100_MOD_WARN_INC            'I'
#define CA1100_MOD_WARN_ME             'M'
#define CA1100_MOD_WARN_REB            'R'

/*----- ca1100_reb_code_add_sw values */
#define CA1100_REB_CODE_ADDED          'Y'
#define CA1100_REB_CODE_NOT_ADDED      'N'

/*----- ca1100_um_curr_preauth_ind values */
#define CA1100_UM_CURR_PREAUTH_YES     'Y'
#define CA1100_UM_CURR_PREAUTH_NO      'N'

/*----- ca1100_pay_pct_lvl values */
#define CA1100_PAY_PCT_LVL_CODE        'C'
#define CA1100_PAY_PCT_LVL_RANGE       'R'
#define CA1100_PAY_PCT_LVL_SECT        'S'

/*----- ca1100_history_ind values */
#define CA1100_CURRENT_PX              '0'
#define CA1100_HISTORY_PAID            '1'
#define CA1100_HISTORY_PAID_WARN       '2'
#define CA1100_HISTORY_DENIED_WARN     '3'
#define CA1100_HISTORY_DENIED          '4'

/*----- ca1100_mod_include_um values */
#define CA1100_MOD_INCLUDE_UM_YES      'Y'
#define CA1100_MOD_INCLUDE_UM_NO       'N'

/*----- ca1100_hist_warn_pre_post values */
#define CA1100_HIST_WARN_PRE_OP        '1'
#define CA1100_HIST_WARN_POST_OP       '2'


/*----- ca1100_tpldx_sce_stat values */
#define CA1100_TPLDX_NOT_PROCESSED     "  "
#define CA1100_TPLDX_WC_SUSPEND        "WS"
#define CA1100_TPLDX_WC_MONITOR        "WM"
#define CA1100_TPLDX_DENTAL_SUSPEND    "DS"
#define CA1100_TPLDX_DENTAL_MONITOR    "DM"

/*----- ca1100_tplpx_sce_stat values */
#define CA1100_TPLPX_NOT_PROCESSED     "  "
#define CA1100_TPLPX_WC_SUSPEND        "WS"
#define CA1100_TPLPX_WC_MONITOR        "WM"
#define CA1100_TPLPX_DENTAL_SUSPEND    "DS"
#define CA1100_TPLPX_DENTAL_MONITOR    "DM"
#define CA1100_TPLPX_BOTH_SUSPEND      "BS"
#define CA1100_TPLPX_BOTH_MONITOR      "BM"

/*----- ca1100_mcbdcb_process_stat values */
#define CA1100_MCBDCB_NOT_PROCESSED    "  "
#define CA1100_DCB_SUSPEND             "DS"
#define CA1100_DCB_MONITOR             "DM"
#define CA1100_MCB_SUSPEND             "MS"
#define CA1100_MCB_MONITOR             "MM"

/*----- ca1100_ios_processing_stat values */
#define CA1100_IOS_NOT_PROC            ' '
#define CA1100_IOS_REPLACE             'R'
#define CA1100_IOS_SUSPEND             'S'
#define CA1100_IOS_MONITOR             'M'

/*----- ca1100_idxpx_process_stat values */
#define CA1100_DXPX_NOT_PROCESSED      ' '
#define CA1100_DXPX_EXPECTED           'E'
#define CA1100_DXPX_DENIED             'D'
#define CA1100_DXPX_SUSPEND            'S'
#define CA1100_DXPX_MONITOR            'M'

/*----- ca1100_pay_pct_sw values */
#define CA1100_PAY_PCT_ON              'Y'



struct ca_diagnosis_cd_grp
{
    char ca1100_dx_code[7];
    char ca1100_dx_coding_system;
};

struct ca_message_entry                         /*015 */
{
    char message_code[7];
    char ca_message_modifier[4] [2];       
};


struct  ca1100                                  /*372 rec len*/
{
    char    ca1100_medical_code[7];               /*007*/
    char    ca1100_medical_code_modifier[4][2];   /*008 80,81,82*/
    struct ca_date  ca1100_date_of_service;       /*008 ceyymmdd*/
    struct ca_age  ca1100_dos_age;                /*004*/
    
    struct ca_diagnosis_cd_grp ca1100_dx_tbl[4];  /*028*/
    
    char    ca1100_sce_error1[2];                 /*002*/
    char    ca1100_sce_error2[2];                 /*002*/
    char    ca1100_sce_age_status[2];             /*002*/
    char    ca1100_sce_asst_surg_status;          /*001 S=sometimes*/
    char    ca1100_sce_exp_status;                /*001*/
    char    ca1100_sce_obs_status;                /*001*/
    char    ca1100_sce_rvu_status;                /*001*/
    char    ca1100_payment_status;                /*001 A,M,I,N,R,S,V,...*/
    char    ca1100_code_origination;              /*001 0..7*/
    char    ca1100_uandc_value[11];               /*009 cc10 11*/
    char    ca1100_cpt_module_id;                 /*001 S,R,...*/
    char    ca1100_short_description[28];         /*028*/
    char    ca1100_policy_ind;                    /*001 A=incPolicy*/
    char    ca1100_code_order[3];                 /*003*/
    char    ca1100_pay_percent[3];                /*003*/
    char    ca1100_charge[11];                    /*009 cc10 11*/
    char    ca1100_redis_charge[11];              /*009 cc10 11*/
    char    ca1100_allowed_amount[11];            /*009 cc10 11*/
    char    ca1100_code_status;                   /*001 0..3*/
    char    ca1100_user_area[10];                 /*010*/
    char    ca1100_duplicate_flag;                /*001 0..2*/
    char    ca1100_rvu[5];                        /*005 9(3)v99*/
    char    ca1100_dropped_day_range[3];          /*003*/
    struct ca_message_entry 
        ca1100_message_entry[4];             /*060 4x15=60*/
    char    ca1100_mod_warn_ind[2][1];            /*002 V,O,I,M=ME,R=Reb*/
    char    ca1100_duplicate_msg_type[2];         /*002*/
    char    ca1100_max_times_dup[2];              /*002*/
    
    char    ca1100_reb_code_add_sw;               /*001 Y=added;N=NotAdded*/
    char    ca1100_ss_orig_position[3];           /*003*/
    char    ca1100_pay_pct_lvl;                   /*001 C=code;R=range;S=sect*/
    char    ca1100_history_ind;                   /*001 0..4*/
    char    ca1100_provider[16];                  /*016*/
    char    ca1100_specialty[10];                 /*010 */
    char    ca1100_tpldx_sce_stat[4][2];          /*008 (DX)*/
    char    ca1100_tplpx_sce_stat[2];             /*002 (PX) WS;WM,...*/
    char    ca1100_mcbdcb_process_stat[2];        /*002*/
    char    ca1100_ios_processing_stat;           /*001 space,R,S,M*/
    char    ca1100_idxpx_process_stat;            /*001 space,E,D,S,M*/
    char    ca1100_ipxdx_process_stat;            /*001 space P,D,S,M  cc10 */
    char    ca1100_pay_pct_sub_range[2];          /*002*/
    char    ca1100_pay_pct_sw;                    /*001 Y=on*/
    char    ca1100_pay_pct_value[5][3];           /*015*/
    char    ca1100_px_pos[3];                     /*003*/
    char    ca1100_px_claim_number[30];           /*030*/
    
    char    ca1100_asst_at_surg_status;           /*001*/
    char    ca1100_original_order[5];             /*005*/
    char    ca1100_split_mod_indicator;           /*001*/

    char    ca1100_orig_nvf_visit_code[7];        /*007 cc10*/
    char    ca1100_msr_exempt_ind;                /*001 cc10 */
    char    ca1100_mue_orig_line[3];              /*003 cc10 */

    char    filler[19];                           /*019 cc10 */
};



#endif
