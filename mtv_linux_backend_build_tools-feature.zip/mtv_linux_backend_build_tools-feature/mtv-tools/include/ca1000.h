/*  
  CA1000.H - Claim Level Integration Record

  Company:  McKesson
  Product:  ClaimCheck R 10.0
  Platform: UNIXes, PC
  Author:   TDN
  Date:     04/22/2003
  Modified: 12/20/2010
  
    TN.01.11.2011 - CAC1000 rec-len=1250
*/


#ifndef CA1000_H
#define CA1000_H


struct ca_gmis_claim            /* 26 bytes */
{
    char claim_julian_n [7];
    char claim_time     [8];
    char claim_proc_cnt [3];    /* 100 lines input, 125 output */
    char claim_seq_n    [8];
};


struct ca_date                  /* 8 bytes; ceyymmdd */
{
    char ce[2];
    char yy[2];
    char mm[2];
    char dd[2];
};

struct ca_age
{
    char age_num[3];
    char infant_indicator;
};


struct ca_claim_diag_info                   /*43 x [12] */
{
    char clm_diag_code            [7]; 
    char clm_diag_coding_system;            /*01*/
    char clm_diag_idx_val         [5];      /*05*/
    char clm_diag_desc            [28];     /*28*/
    char clm_diag_tpl_flag;                 /*01*/
    char clm_diag_tpl_sce_stat    [2];      /*02*/
};                                  


struct ca_ss_match                      /*29 = Bytes total*/
{
    char ss_category_1      [2];        /*02*/
    char ss_category_2      [2];        /*02*/
    char ss_category_3      [2];        /*02*/
    char ss_cat1_level;                 /*01*/
    char ss_cat1_occur      [3];        /*03*/
    char ss_cat1_mod_occur;             /*01*/
    char ss_cat2_level;                 /*01*/
    char ss_cat2_occur      [3];        /*03*/
    char ss_cat2_mod_occur;             /*01*/
    char ss_cat3_level;                 /*01*/
    char ss_cat3_occur      [3];        /*03*/
    char ss_cat3_mod_occur;             /*01*/
    char ss_status;                     /*01*/
    char ss_message_no      [4];        /*04*/
    char ss_display_option;             /*01*/
    char ss_occurences      [2];        /*02*/
};


struct  ca1000                                /* 1250 bytes */
{
    struct ca_gmis_claim ca1000_gmis_claim;     /*026*/
    char    ca1000_claim_num[30];               /*030*/
    char    ca1000_user_id[8];                  /*008*/
    char    ca1000_cap_status;                  /*001*/
    char    ca1000_return_program[8];           /*008 CA1100,CCB0100...*/
    char    ca1000_summ_scr_option;             /*001 D,A=action,N=never*/
    char    ca1000_entry_from;                  /*001 I,0..6*/
    struct ca_date  ca1000_date_of_service;      /*008 ceyymmdd*/
    struct ca_date  ca1000_date_of_birth;        /*008 ceyymmdd*/
    /* struct ca_age  ca1000_age; */                 /*004*/
    char    ca1000_sex;                         /*001 F,M,Unknown*/
    struct ca_claim_diag_info 
        ca1000_claim_diag_info[12];              /*43 x 12*/
    char    ca1000_provider[16];                /*016*/
    char    ca1000_specialty[10];               /*010*/
    char    ca1000_optional_data[14];           /*014*/
    char    ca1000_procedure_count[3];          /*003*/
    char    ca1000_source_pgm;                  /*001*/
    char    ca1000_claim_savings[13];            /*009 --> 013*/
    char    ca1000_error_line [5][8];           /*040 --> 8 x [5] lines*/
    char    ca1000_sort_field[14];              /*014*/
    char    ca1000_account_id[14];              /*014*/
    char    ca1000_override_file_sw;            /*001*/
    char    ca1000_shared_cust_acct[14];        /*014*/
    char    ca1000_pay_percent_sw;              /*001*/
    
    char    ca1000_asst_surg_as_pay_sw;           /*001 chg for 8.5 CA1000-ASST-SURG-AS-PAY-SW */
    char    ca1000_claim_pass_switch;           /*001*/
    char    ca1000_rule_error_name[10];         /*010*/
    char    ca1000_ss_clm_status;               /*001 0,1*/
    struct ca_ss_match ca1000_ss_match[10];     /*290 29x10=280*/
    char    ca1000_ss_more_matches_sw;          /*001 Y,N*/
    char    ca1000_current_ymd[8];              /*008*/
    char    ca1000_cp_gcprof_flag;              /*001 Y,N*/
    char    ca1000_cg_gcprof_flag;              /*001 Y,N*/
    char    ca1000_pi_gcprof_flag;              /*001 Y,N*/
    char    ca1000_claim_taskn[8];              /*008 s9(7)*/
    char    ca1000_claim_action;                /*001 0=init,1=processing*/
    
    char    ca1000_orig_time_key[7];            /*007*/
    char    ca1000_exit_f1;                     /*001 M=menu,C=cics*/
    char    ca1000_mode_flag;                   /*001 T=test,P=Prod*/
    char    ca1000_status_reason[5];            /*005 s9(4)*/
    char    ca1000_sce_sex_edit_sw;             /*001 0=Yes,1=No*/
    char    ca1000_sce_age_edit_sw;             /*001 0=Yes,1=No*/
    char    ca1000_sce_exp_edit_sw;             /*001 Y=Yes,N=No*/
    char    ca1000_sce_obs_edit_sw;             /*001 Y,N*/
    char    ca1000_asst_surg_80_pay_sw;         /*001 1=Yes,0=No*/
    
    char    ca1000_temp_storage_queue_id[8];    /*008 (new)*/
    char    ca1000_as_apply_audit_sw;           /*001 Y,N*/
    
    char    ca1000_asst_surgeon_sw;             /*001 Y,N*/
    char    ca1000_pay_pct_cust_sw;             /*001 Y,N*/
    char    ca1000_modifier_support_sw;         /*001 N=0,Y=1,2,3,4*/
    char    ca1000_num_dx_per_px_line;          /*001 N=0; Y=1,2,3,4 (new)*/
    char    ca1000_transfer_type;               /*001 0=xctld,1=client-linked*/
    char    ca1000_log_type;                    /*001*/
    char    ca1000_record_type;                 /*001*/
    char    ca1000_aid_key[2];                  /*002*/
    char    ca1000_commarea_sw;                 /*001 W=wrkFile;A=aux;M=mainQ*/
    char    ca1000_ts_queue_sw;                 /*001 A=aux;M=main*/
    char    ca1000_return_message_code[2];      /*002*/
    char    ca1000_pfkey_ind;                   /*001 B=backward,F,A=audit*/
    char    ca1000_screen_ind[2];               /*002 1..4th;5th=5..13*/
    char    ca1000_integrated_len[6];           /*006 val=+14078 s9(5)*/
    char    ca1000_ss_results_len[6];           /*006 val=+14351 s9(5)*/
    char    ca1000_shared_clmrvw_cust_acct[14]; /*014*/
    char    ca1000_claimrvw_ovrd_file_sw;       /*001*/
    char    ca1000_record_type_seq_num[3];      /*003*/
    char    ca1000_expand_err_process_sw;       /*001 Y,N*/
    char    ca1000_record_type_tot_num[3];      /*003*/
    char    ca1000_conflict_error_sw;           /*001 Y=found,N=notFound*/
    char    ca1000_error_level;                 /*001 S,C,P=px,B=claimPx*/
    char    ca1000_syntax_error_cnt[8];         /*008 s9(7)*/
    char    ca1000_rule_edits_cnt[8];           /*008 s9(7)*/
    char    ca1000_note_edits_cnt[8];           /*008 s9(7)*/
    char    ca1000_default_member_number[30];   /*030*/
    char    ca1000_default_pos[3];              /*003*/
    char    ca1000_ss_shared_cust_acct[14];     /*014*/
    char    ca1000_asst_surg_81_pay_sw;         /*001*/
    char    ca1000_asst_surg_82_pay_sw;         /*001*/

    char    ca1000_filler_1[12];                /*012*/
    
};



#endif