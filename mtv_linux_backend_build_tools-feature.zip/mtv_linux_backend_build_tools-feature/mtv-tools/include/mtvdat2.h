/***********************************************************************************/
/*                                                                                 */
/*   MTVDAT2.h                                                                     */
/*                                                                                 */
/*   This .h file is forced into all source code by a new source-code editor       */
/*   widget, which replaces calls to CA's TIRDAT2() function with calls to our     */
/*   MTVDAT2() function instead.  Ours always calls CA's;  then, if and only if    */
/*   the function was called in "get system timestamp" mode, ours adds some        */
/*   manufactured microseconds to the timestamp that was returned to CA's function */
/*   by the OS.                                                                    */
/*                                                                                 */
/*   Chad Varner       4/13/2009    Created                                        */
/*                                                                                 */
/***********************************************************************************/

#ifndef _MTVDAT2_H
#define _MTVDAT2_H

#ifdef __cplusplus
extern "C" {
#endif

extern void MTVDAT2( void*, void*, void*);

#ifdef __cplusplus
}
#endif





#endif
