/*  This header is to be included in the calling                                
    C program that uses any nThrive grouper.                                  
    (c) Copyright 2017 nThrive, Inc.                                                
    HADGRPCP.H                                                                  
                                                                                
 */                                                                             
                                                                                
                                                                                
/* This header contains the structures and prototypes required                  
   to call either the IRP common grouper interface program, HADGRP,             
   or the individual groupers at the lowest levels.                             
                                                                                
   The most common method is to use the HADGRP higher-level interface           
   because it provides numerous extension functions not available at            
   the individual grouper level, and can automatically select and               
   load the proper grouper based on discharge date or input specifications.     
                                                                                
   However, the HADGRP interface may not be ideal in high performance,          
   high volume grouping applications.  The "dynamic" loading of                 
   individual grouper modules may be significantly slower (up to 100 times      
   slower) in some computer / operating system models.  In such cases           
   a direct link to a statically bound grouper object module may be             
   preferable, but less flexible.  Also, field sizes of arguments and           
   lists may differ from one version of a grouper to another.  These need       
   to be handled correctly at the individual grouper call level.  The           
   HADGRP interface normalizes many of these fields.                            
                                                                                
   Lower level prototypes are provided in the second part of this header        
   to accomplish this direct linkage.                                           
                                                                                
  >>>  Note: This header is also included in the grouper compile,               
             but certain sections are bypassed to avoid conflicts.              
                                                                                
 */                                                                             
                                                                                
/* NOTE::  EACH different called IRP grouper may allocate a significant         
 *         amount of memory (100-150K) automatically upon first invocation.     
 *         This storage IS NOT AUTOMATICALLY RELEASED.                          
 *         This technique is used to significantly improve                      
 *         response time for groupings, both interactive and                    
 *         batch.                                                               
 *                                                                              
 *         THE CALLING APPLICATION should perform a 'dummy'                     
 *         termination call to the grouper to release this                      
 *         storage after all grouping is logically complete.                    
 *                                                                              
 *         If multiple groupers are to be used in a session, and                
 *         your application knows it is finished with a particular              
 *         grouper, the FN_FREE (DRG_FREE) function can be used with that       
 *         particular gouper to free just that grouper's storage.               
 *         The storage for other groupers remains unaffected.                   
 *                                                                              
 *         Since the groupers automatically allocate storage when               
 *         needed, extra calls with FN_FREE (DRG_FREE) won't                    
 *         affect grouping, just response time.                                 
 *                                                                              
 *         Memory and table handling differ significantly among the             
 *         various computer / operating systems versions, and the               
 *         FN_FREE (DRG_FREE) call may not result in any reduction in           
 *         memory utilization for a particular version, but it                  
 *         will never cause an error or problem, so it's best to                
 *         structure your code to make these calls in all implementations.      
 *                                                                              
 *  Change log:                                                                 
 *                                                                              
 *   07/06/95 szh irp - updated to combine windows, shared memory model         
 *   08/10/95 szh irp - added FAR to all Dxxxx arguments;                       
 *                    - added APG Grouper prototypes & external pointers        
 *   09/16/95 szh irp - added HCFA grouper 13 DRG                               
 *   04/15/96 szh irp - added OS/2 option                                       
 *   04/24/96 szh irp - changed calling convention to __syscall for             
 *                      OS/2                                                    
 *   07/06/96 szh irp - updated all grouper calls for OS/2                      
 *   07/13/96 szh irp - dropped all anchor pointers                             
 *                      dropped superfluous defines for far routines            
 *   06/96    ljh irp - modified for HADGRP IRP standard grouper interface      
 *   06/14/96 ljh irp - added to external interface include file                
 *   07/06/96 szh irp - added OS/2 __syscall calling convention for ext int     
 *                      low level grouper - needs verification.                 
 *   07/24/96 szh irp - merged the HADGRPC1.H (test HADGRP version)             
 *                      into HADGRPCP.H                                         
 *                    - added #define for far (lower case) to nothing           
 *                      for non-DOS/WIN16 models                                
 *   08/26/96 szh irp - added 50 char array for valid pr flags; kept GRP1       
 *                      sver.  Added 500 byte filler at end;                    
 *                      added GRPGEN preprocessor tests                         
 *                      added single structure entry points for groupers        
 *   08/28/96 szh irp - incorporated hadrmp.h in-line here for convenience.     
 *   09/11/96 szh pjo - added APG single structure entries                      
 *   09/14/96 szh irp - added prototype for HCFA DRG v 14                       
 *   09/25/96 pjo irp - changed OS/2 entry point from hajf01cw to hajf01c1      
 *   11/11/96 szh irp - changed PCWIN32 entry to regular C                      
 *                      linkage convention.                                     
 *   11/14/96 szh irp - changed to use IRPEXTCALL and added _INCLUDED           
 *                    - removed _export from all entries - should not           
 *                      be needed on prototype entries that model CALL's        
 *   11/19/96 szh irp - added IRPEXTERNC for c++ compiles                       
 *   01/31/97 bas irp - added prototype hajf21.. cloned from hajf01..           
 *   02/26/97 szh irp - moved hajf21 entry point definitions around;            
 *                      renamed APG grouper entry points for consistency        
 *                      this affected the version 1.0 apg calls.                
 *   02/28/97 szh irp - added apg_vers [20] to apg structure.                   
 *                    - reduced fields apg_pt_visit_type & apg_status           
 *                      from 3 char to 1 char; 3 was incorrect.                 
 *   03/08/97 szh irp - made APG Grouper MVS entry point prototypes match       
 *                      actual calling parameter list                           
 *   06/10/97 dcr irp - cloned grouper 6 prototypes from grouper 7;             
 *                      removed majop3 parameter                                
 *   07/20/97 szh irp - added explicit prototypes for HADGRP01 and HAJGRP01     
 *                      entry points in HADGRP                                  
 *   09/07/97 szh irp - adjusted errors for AP-DRG groupers                     
 *   09/13/97 szh irp - added entries for F15                                   
 *   05/11/98 szh irp - added entry for irp severity grouper hads10c1           
 *   05/27/98 szh irp - added entries for irp refined grouper hadr06c1          
 *                      IRP refined grouper based on Yale 2.2 model which       
 *                      has 8 more arguments than HCFA Ver 6.0 base;            
 *                      actually used HCFA 10.0 base argument set so that       
 *                      we had all arguments needed for subsequent versions     
 *                      of refined grouper as well.                             
 *                    - 2 Refined output fields (RRT and MDX) will be           
 *                      merged into existing grouper fields (RTC and CCDX)      
 *                      since their interpretation is similar.                  
 *                    - added additional fields in former filler areas to       
 *                      HADGRP01 data structure for new refined grouper         
 *                      fields                                                  
 *                      THIS DID NOT CHANGE RELATIVE BYTE OFFSETS OF            
 *                      EXISTING FIELDS                                         
 *                    - moved endifs for GRPGEN and HADGRPCP_INCLUDED to        
 *                      physical end of this file, where they belong.           
 *   05/28/98 szh irp - Regrouping for Refined Grouper will produce RGN in      
 *                      regrouping arrays - using filler byte following DRG     
 *                      field for refinement class.                             
 *                    - Total of 6 addl fields needed for refined grouper       
 *                    - 2 addl ref grp input fields (LOS and BWT) were already  
 *                      in the HADGRP interface area;                           
 *                    - 4 new Ref Grp output fields                             
 *                      were put into 30 byte filler in output area.  Total of  
 *                      12 chars used from filler, leaving 18 bytes in this     
 *                      area.                                                   
 *   05/31/98 szh irp - updated notes on IRP Severity DRG Grouper.              
 *                    - For Severity Grouper, drg field in c1 interface is      
 *                      the actual severity DRG;  However, in CS interface,     
 *                      drg is the original HCFA drg, and the Severity DRG      
 *                      is placed in the first 3 positions of rgn; the          
 *                      4th position of rgn is filled with the severity level   
 *                      represented by the SRDRG 3 digit number.  This makes    
 *                      the severity DRG grouper interface more similar to      
 *                      the refined DRG interface.                              
 *   06/01/98 szh irp - added r16 grouper definition for future use             
 *   09/11/98 szh irp - added F16 grouper definition                            
 *   04/05/99 szh irp - added N41 (AP-DRG 14.1) definition                      
 *   07/16/99 twf irp - add externals for hadcom1 entry points                  
 *   08/18/99 twf irp - remove #define access IRPaccess                         
 *   08/19/99 twf irp - add #define pathlength 255 for use by locinifile and    
 *                          all buffers passed to locinifile                    
 *   09/13/99 twf irp - added F17 grouper definition                            
 *   10/28/99 twf irp - haa structures, codes and entries added                 
 *   02/17/00 szh irp - added R17                                               
 *   02/22/00 szh irp - shortened lines to 80 chars for as/400                  
 *   05/19/00 twf irp - initial change for oce data structures                  
 *   06/04/00 szh irp - shortened lines to 80 chars for as/400                  
 *   08/24/00 szh irp - chg APC error defines to coordinate all                 
 *                      platforms and match haagrp.c and haaf1ac1.c             
 *                    - moved APC error defines from haagrp.h to here           
 *   08/30/00 szh irp - added HACMAPDBASEERR define for starting ##             
 *                      on HACMAPD errors (add return to this ## to             
 *                      get .ini error ##                                       
 *                      same for HADRMP                                         
 *   09/13/00 twf irp - F18 changes                                             
 *   09/14/00 twf irp - R18 changes                                             
 *   10/16/00 twf irp - APC f1b changes                                         
 *   11/08/00 twf irp - add OCE_CC21_ERROR20                                    
 *   12/11/00 twf irp - added N18 (AP-DRG 18.0) definition                      
 *   12/12/00 twf irp - added lvmalrg pointer for 18.0                          
 *   12/12/00 twf irp - added drg_malfrm_indicator for AP-DRG 18.0 to           
 *                        hadgrp_data overflow area                             
 *   12/26/00 twf irp - add APC_Version_Extend_Date constant                    
 *   12/26/00 twf irp - use #define drg_malfrm_indicator drg_fill_end_1[0]      
 *                      to take one byte out of hadgrp_data filler field        
 *                      for AP-DRG                                              
 *   01/02/01 twf irp - APC f2a changes                                         
 *   03/13/01 twf irp - haaf2ac2 prototype added                                
 *   03/24/01 twf irp - APC f2b changes                                         
 *   03/27/01 twf irp - add pstat, opps to haagrp_data                          
 *   03/27/01 twf irp - add pstatptr,oppsptr to haaf2ac2,haaf2bc2 entries       
 *   04/05/01 twf irp - add claim_vers field in Haagrp_Data structure           
 *   04/09/01 twf irp - drg_func_opt_grp_admit 'A' group by drg_admit_date      
 *   06/14/01 twf irp - APC f2c changes                                         
 *   06/15/01 twf irp - add OCE_PBT_ERROR22                                     
 *   08/20/01 twf irp - F19 changes                                             
 *   08/27/01 twf irp - Ed Rado at Anthem trying to build a c++ executable on   
 *                      aix could not link our components: hadgrp01 not resolved
 *                      I tried it on win32 and got unresolved hadgrp01. When I 
 *                      defined _cplusplus I got another error - bad            
 *                      terminationd character on IRPEXTERNC statement. Needed  
 *                      to modify short IRPEXTERNC IRPEXTCALL HAAF2ACS to       
 *                      IRPEXTERNC short IRPEXTCALL HAAF2ACS                    
 *                      I surrounded this change with an ifdef _cplusplus       
 *   08/28/01 twf irp - add _cplusplus dependency for unix hadgrp01 prototype   
 *   09/13/01 szh irp - shortened long lines for AS/400                         
 *   09/20/01 twf irp - APC f2d changes                                         
 *   10/10/01 szh irp - added R19                                               
 *   10/29/01 twf irp - added #ifndef edit_rtn                                  
 *   10/31/01 twf irp - pricer information added at end of file                 
 *   11/02/01 ejf irp - added APDRG 19 from APDRG 18                            
 *   11/14/01 twf irp - add typedef OPSCALRtnStrucIF for opscal call            
 *   11/15/01 twf irp - add APC_TO_GROUPER date format(ccyymmdd)                
 *                      used by haagpc.c                                        
 *   12/26/01 szh irp - shortened lines for as/400                              
 *   03/11/02 twf irp - add APC_NAME                                            
 *   03/18/02 ejf irp - Added APC f3b                                           
 *   04/08/02 twf irp - add champus entry HADC19CS                              
 *   04/17/02 twf irp - add champus hadc19c1 entry                              
 *   06/10/02 ejf irp - Added APC f3c                                           
 *   07/22/02 ejf irp - Added Long-Term L19 from DRG F19                        
 *   08/09/02 twf irp - add MS6COMPILER dependency                              
 *   09/05/02 ejf irp - Added APC f3d                                           
 *   09/05/02 ejf irp - Added DRG F20, R20, L20, C20                            
 *   12/17/02 ejf irp - Added APC f4a                                           
 *   12/27/02 twf irp - add apc_admit_dx, apc_admit_dx_edit to Haagrp_Data      
 *   01/02/03 szh irp - shorten long line for as400                             
 *   02/12/03 ejf irp - Regenerated L20 from F20                                
 *   03/23/03 ejf irp - Added APC f4b                                           
 *   06/19/03 ejf irp - Added APC f4C                                           
 *   08/07/03 twf irp - change #define oryx_data drg_fill_end[4] to             
                               #define oryx_data drg_fill_end_1[4]              
 *   08/18/03 ejf irp - Added DRG F21, R21, L21, C21                            
 *   08/26/03 ejf irp - Added APC F4D                                           
 *   10/15/03 twf irp - change copyright notice                                 
 *   12/11/03 twf irp - add apdrg 21, remove apdrg 19                           
 *   12/30/03 ejf irp - Added APC F5A                                           
 *   01/06/04 twf irp - remove occurrence count from Haagrp_Data                
 *   01/07/04 twf irp - add occptr,noccptr to APCRtn450IF structure; is used    
 *                      only in haagpc.c - a test program that calls the        
 *                      grouper and haopscal.dll                                
 *   03/22/04 ejf irp - Added APC F5B                                           
 *   05/18/04 twf irp - in Hadgrp_Data, document apdrg birth wt options         
 *   06/24/04 ejf irp - Added APC F5C                                           
 *   07/22/04 ejf irp - Added DRG F22                                           
 *   09/07/04 ejf irp - Added APC F5D                                           
 *   12/08/04 ejf irp - Added APC F6A                                           
 *   02/03/05 twf irp - added X_APX_.. and X_OCE_..  error codes to report      
 *                      3 character errors as 1 character in the cms interface  
 *                      which are in addition to codes reported by cms          
 *   03/11/05 ejf irp - Added APC F6B                                           
 *   06/16/05 twf irp - Added APC F6C                                           
 *   09/21/05 twf irp - Added APC F6D                                           
 *   10/04/05 twf irp - added rdrg r23                                          
 *   10/26/05 twf irp - add haaf6e for the transition from old apc 6d           
 *                      to new apc 7a, 6e is new version of 6d                  
 *   12/20/05 twf irp - create apc 7a entries                                   
 *   01/14/06 twf add edit_rtn_sz for new APC sizes                             
 *   01/14/06 twf add v7_flag_sz for status, payindicator,pay adjust            
 *   03/16/06 ejf irp - Added APC F7B                                           
 *   03/13/06 twf irp - add HADN23CS                                            
 *   05/30/06 jsc irp - Added APC F7C                                           
 *   06/14/06 twf irp - re do the HADN23 additions, only one complaint          
 *                      so far, the v23 grouper was not generated               
 *                      I don't understand why no more complaints               
 *   08/15/06 jsc irp - Added APC F7D                                           
 *   08/16/06 twf irp - add drg 24                                              
 *   10/17/06 twf irp - added rdrg r24                                          
 *   11/28/06 dme irp - model N24 additions on N23 changes                      
 *   12/15/06 jsc irp - Added APC F8A                                           
 *   12/27/06 twf irp - add APG_MAX_SG dependency to Hajgrp_Data typedef        
 *   06/12/07 ejf irp - Added APC F8C                                           
 *   08/21/07 ejf irp - Added APC F8D                                           
 *   11/12/07 djc irp - Added APC F9A                                           
 *   12/18/07 djc irp - Added AP DRG N25                                        
 *   02/19/08 djc irp - Added OCECLAIM_C2 as the 450 line interface             
 *   02/29/08 djc irp - Added DRG 52 (25.1)                                     
 *   03/03/08 djc irp - Added AP DRG 52 (25.1)                                  
 *   03/24/08 djc irp - Added APC F9B                                           
 *   05/27/08 djc irp - Added new DRG grouper structure Hadgrp2_Data            
 *   05/27/08 djc irp - Added temporary MS DRG 99 (25.1 using Hadgrp2_Data)     
 *   09/08/08 djc irp - Changes made for MS DRG V26                             
 *                      Replace F99 with F26                                    
 *                      Added defines for new RTC values (POA errors)           
 *                      Updated I/F changes made between CMS V25 and V26        
 *   09/08/08 djc irp - Added APC F9D                                           
 *   11/24/08 djc irp - Added AP DRG N26                                        
 *   12/17/08 djc irp - Updated comments for outpatient groupers                
 *                                                                              
 */                                                                             
                                                                                
#ifndef HADGRPCP_INCLUDED                                                       
#define HADGRPCP_INCLUDED                                                       
                                                                                
#ifndef HADSYSDF_INCLUDED                                                       
   #error  hadsysdf.h must be included before this header file                  
#endif                                                                          
                                                                                
#if ! defined(GRPGEN)                                                           
                                                                                
#if defined(MSDOSBORLC) || defined(PCWIN)                                       
#if ! defined(HUGE)                                                             
#define HUGE            huge /* far huge */                                     
#endif                                                                          
#if ! defined(FAR)                                                              
#define FAR             far  /* far huge */                                     
#endif                                                                          
#if ! defined(PASCAL)                                                           
#define PASCAL          pascal                                                  
#endif                                                                          
#else                                                                           
#ifdef HUGE                                                                     
#undef HUGE                                                                     
#endif                                                                          
#ifdef far                                                                      
#undef far                                                                      
#endif                                                                          
#ifdef FAR                                                                      
#undef FAR                                                                      
#endif                                                                          
#define HUGE                                                                    
#define far                                                                     
#define FAR                                                                     
#endif                                                                          
                                                                                
#endif                                                                          
               /* endif for ! defined(GRPGEN) */                                
                                                                                
                                /* 08-30-00 add these numbers to                
                                   return codes from the respective             
                                   modules to get .ini 3 digit                  
                                   return code message                          
                                */                                              
#define HADRMPBASEERR  820                                                      
#define HACMAPDBASEERR 830                                                      
                                                                                
/* ************************************************************** */            
/* this is the start of the HADGRP IRP DRG grouper call structure */            
                                                                                
/* all fields are character displayable.  all conversions to                    
 * numeric will be done in the calling and called programs                      
 */                                                                             
                                                                                
 /* The following data types are declared to remove any uncertainty             
 * about parameter passing and to ensure that the data areas passed             
 * are sized correctly                                                          
 */                                                                             
                                                                                
struct Drg_Grcctab                                                              
{                                                                               
   char chars[50];               /* Flags of diagnoses                          
                                    that are valid CCs for                      
                                    this principal DX */                        
};                                                                              
typedef struct Drg_Grcctab Drg_Grcctab;                                         
                                                                                
                                                                                
struct Drg_Grvsn                                                                
{                                                                               
   char chars[11];               /* Low-level returned grouper version */       
};                                                                              
typedef struct Drg_Grvsn Drg_Grvsn;                                             
                                                                                
                                                                                
typedef char Drg_Grret;          /* Low-level return code one char */           
                                                                                
                                                                                
struct Drg_Dstat                                                                
{                                                                               
   char chars[2];                /* Two digits UB-04 form         */            
};                                                                              
typedef struct Drg_Dstat Drg_Dstat;                                             
                                                                                
                                                                                
struct Drg_Age                                                                  
{                                                                               
   char chars[3];                /* Three digits, right justified */            
};                                                                              
typedef struct Drg_Age Drg_Age;                                                 
                                                                                
                                                                                
struct Dxsg8_Code                                                               
{                                                                               
   char chars[8];                /* Codes returned formatted      */            
};                                                                              
typedef struct Dxsg8_Code Dxsg8_Code;                                           
                                                                                
typedef struct pr_modifiers   /* up to 4 2-character modifiers/cpt */           
{                             /* first modif is appended to the cpt code */     
   char m1[2];                                                                  
   char m2[2];                                                                  
   char m3[2];                                                                  
}pr_modifiers;                                                                  
                                                                                
struct Sg_Code                                                                  
{                                                                               
   char chars[7];                /* Procedure code, low-level  */               
};                                                                              
typedef struct Sg_Code Sg_Code;                                                 
                                                                                
struct Dx_Code                                                                  
{                                                                               
   char chars[6];                /* Diagnosis code, low-level  */               
};                                                                              
typedef struct Dx_Code Dx_Code;                                                 
                                                                                
typedef struct date_field       /* 5/19/00 twf */                               
{                                                                               
   char df[10];                                                                 
}date_field;                                                                    
                                                                                
typedef struct condition_code   /* 5/19/00 twf */                               
{                                                                               
   char cc[2];                                                                  
}condition_code;                                                                
                                                                                
typedef struct revenue_code     /* 5/19/00 twf */                               
{                                                                               
   char rc[4];                                                                  
}revenue_code;                                                                  
                                                                                
typedef struct service_unit     /* 5/19/00 twf */                               
{                                                                               
   char su[3];                                                                  
}service_unit;                                                                  
                                                                                
#ifndef edit_rtn_defined                                                        
#define edit_rtn_defined                                                        
typedef struct edit_rtn         /* 5/19/00 twf */                               
{                                                                               
   char  edc[edit_rtn_sz];       /* 2-3 character edit return code */           
}edit_rtn;                                                                      
#endif                                                                          
                                                                                
struct Drg_Regroup                                                              
{                                                                               
   char drg[3];                                                                 
                     /* For HCFA, SeverityDRG ,APDRG this is the drg.     */    
                     /* For Refined DRG, this is the first 3 bytes of rgn */    
  /*  char fill[1];   05-28-98 szh this is filler for HCFA DRG, AP-DRG,         
                               IRP Sev DRG */                                   
   char RefClass[1];  /* 05-28-98 szh filler is Refinement Class for Refined    
                               DRG grouper (4th byte of RGN) */                 
                      /* For Severity DRG, this is the severity level */        
   char rtc[1];                                                                 
   char mdc[2];                                                                 
};                                                                              
typedef struct Drg_Regroup Drg_Regroup, *Drg_Regroup_Ptr;                       
                                                                                
struct Drg_Regroup2                                                             
{                                                                               
   char drg[4];                                                                 
   char rtc[2];                                                                 
   char mdc[2];                                                                 
};                                                                              
typedef struct Drg_Regroup2 Drg_Regroup2, *Drg_Regroup2_Ptr;                    
                                                                                
/* Structure for Grouper Interface.                                             
 * Some fields are not returned in version DRG_VERSION_1                        
 *                                                                              
 * Fill DRG_INIT in drg_function to clear out all fields.                       
 * Pass this structure to HADGRP01 after filling in:                            
 * Discharge Date                                                               
 * Discharge Status                                                             
 * Date of Birth or Age                                                         
 * Significant Procedures                                                       
 * Significant Diagnoses                                                        
 * Patient Gender (M, 1, F, 2)                                                  
 *                                                                              
 * Returned fields include:                                                     
 *    drg_drg                                                                   
 *    drg_mdc                                                                   
 *    drg_rtc                                                                   
 *    drg_significant_npr[0]                                                    
 *    drg_significant_npr[1]                                                    
 *    drg_significant_pr[0]                                                     
 *    drg_significant_pr[1]                                                     
 *    drg_significant_pr[2]                                                     
 *    drg_significant_dx[0]                                                     
 *    drg_significant_dx[1]                                                     
 *    drg_dxcctab                                                               
 *    drg_vers                                                                  
 *                                                                              
 */                                                                             
                                                                                
struct Hadgrp_Data                                                              
{                                                                               
/****** GENERAL GROUPER INPUTS ******************************************/      
        char drg_sver[4];               /* Structure version                    
                                         * Must be "GRP1"                       
                                         */                                     
        char drg_function;              /* I=init Hadgrp_Data data              
                                         *   to all blanks,                     
                                         *   except preserve values of          
                                         *   drg_sver and drg_function          
                                         * G=group                              
                                         * F=free grouper storage               
                                         */                                     
        char drg_func_opt_remap;        /* Y=remap new codes to old codes       
                                         *   and vice versa                     
                                         */                                     
        char drg_func_opt_regroup;      /* Y=regroup using all 2ndary DX        
                                         *   as PDX                             
                                         */                                     
        char drg_func_opt_mce_edit;     /* Not used by the grouper      */      
        char drg_func_opt_price;        /* Not used by the grouper      */      
        char drg_func_opt_pr_codes;     /* Not used by the grouper      */      
        char drg_func_opt_date_format;  /* auto detect overrides all options    
                                         * auto detect based on delimiter       
                                         *   YYYY.MM.DD                         
                                         *   MM/DD/YYYY                         
                                         *   DD-MM-YYYY                         
                                         * 1= MMDDYYYY                          
                                         * 2= DDMMYYYY                          
                                         * 3= YYYYMMDD                          
                                         * 4= YYYYDDD                           
                                         * blank= same as option 1              
                                         */                                     
                                                                                
/****** AP DRG ONLY INPUTS **********************************************/      
        char drg_func_opt_bw;           /* Birth weight option          */      
/* birth weight options:                                                        
    1      use the entered weight                                               
                                                                                
    2      ignore entered wt, use wt implicit in ICD-9-CM code                  
           if invalid, flag wt as invalid                                       
                                                                                
    3      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, flag wt as invalid                                  
                                                                                
    4      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag weight as invalid                                
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, flag wt as invalid                   
                                                                                
    5      ignore entered wt, use wt implicit in ICD-9-CM code                  
           if invalid, default to normal wt                                     
                                                                                
    6      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, default to normal wt                                
                                                                                
    7      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag wt as invalid                                    
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, default to normal                    
                                                                                
    notes  1. Normal birth weight range is 100 - 9000 g.                        
           2. If option entry is invalid or missing, it defaults to 1.          
           3. For a crosscheck, a comparison is made between the entered        
              birth weight and the implicit birth weight.                       
           4. If the birth weight is required, the system returns DRG 470.      
           5. The normal weight default assumes birth weight is set             
              to >= 2499 g.                                                     
*/                                                                              
        char drg_func_opt_trauma;       /* Trauma processing option             
                                         * 1=grouper and trauma                 
                                         * 2=trauma only                        
                                         */                                     
                                                                                
/****** GENERAL GROUPER INPUTS ******************************************/      
        char drg_func_opt_title;        /* Not used by the grouper      */      
        char drg_func_opt_grp_admit;    /* A = group by drg_admit_date  */      
        char drg_func_opt_11;           /* Not used by the grouper      */      
        char drg_func_opt_12;           /* Not used by the grouper      */      
        char drg_func_opt_13;           /* Not used by the grouper      */      
        char drg_func_opt_14;           /* Not used by the grouper      */      
        char drg_func_opt_15;           /* Not used by the grouper      */      
        char drg_ovr_grouper[10];       /* Select grouper module:               
                                         * FED or blank:                        
                                         *   auto select Federal DRG grouper    
                                         *   by discharge date                  
                                         * F06 - Fnn:                           
                                         *   select specific version of         
                                         *   Federal DRG grouper                
                                         * APDRG:       -                       
                                         *   auto select All Patient(AP) DRG    
                                         *   grouper by discharge date          
                                         * A08 - Ann:                           
                                         *   select specific version of         
                                         *   All Patient(AP) DRG grouper        
                                         */                                     
        char drg_ovr_pricer[10];        /* Not used by the grouper      */      
        char drg_ovr_module2[10];       /* Not used by the grouper      */      
        char drg_ovr_module3[10];       /* Not used by the grouper      */      
        char drg_ovr_module4[10];       /* Not used by the grouper      */      
                                                                                
/****** GENERAL GROUPER OUTPUTS *****************************************/      
        char drg_return_code[3];        /* 000-999; Zero on no error.   */      
        char drg_return_code_ext[3];    /* Not used by the grouper      */      
        char drg_return_code_module[10];/* Module called by interface.  */      
        char drg_return_code_parag[10]; /* Not used by the grouper      */      
        char drg_return_code_msg[60];   /* Text correspond to ret code  */      
                                                                                
/****** GENERAL GROUPER INPUTS ******************************************/      
        Drg_Age drg_pt_age_yrs;         /* Age in years 000-124         */      
                                        /* Not needed if admit/birth    */      
                                        /* date supplied                */      
        char drg_pt_sex;                /* M,1 or F,2                   */      
        char drg_discharge_status[2];   /* UB-04 discharge status       */      
        Dxsg8_Code drg_dx [50];         /* Diagnoses w/ or w/o                  
                                         * decimal points.                      
                                         * left justified, blank padded         
                                         */                                     
        Dxsg8_Code drg_pr [50];         /* Procedure codes w/ or w/o            
                                         * decimal points                       
                                         * left justified, blank padded         
                                         */                                     
        char drg_admit_date[10];        /* General date format field    */      
        char drg_discharge_date[10];    /* General date format field    */      
        char drg_birth_date[10];        /* General date format field    */      
                                                                                
/****** AP DRG ONLY INPUTS **********************************************/      
        char drg_birth_weight[4];       /* birth weight in grams.               
                                         * right justified, zero padded         
                                         */                                     
                                                                                
/****** REFINED DRG ONLY INPUTS *****************************************/      
        char drg_transfer;              /* Not used by the grouper      */      
        char drg_los[3];                /* Length of stay in days               
                                         * 000-nnn                              
                                         * only required for discharge          
                                         * status 20 or neonate discharge       
                                         * status 02                            
                                         */                                     
        char drg_charges[12];           /* Not used by the grouper      */      
        char drg_alc[3];                /* Not used by the grouper      */      
                                                                                
/****** RESERVED FOR FUTURE USE *****************************************/      
        char drg_outfill1;                                                      
                                                                                
/****** GENERAL GROUPER OUTPUTS *****************************************/      
        char drg_drg[3];                /* assigned DRG 001-999         */      
        char drg_mdc[2];                /* assigned MDC 00-99           */      
        char drg_rtc[2];                /* Return code from grouper             
                                         * left justified, blank padded         
                                         */                                     
        char drg_vers[20];              /* Version string from grouper          
                                         * For MS DRG: "HAFvv-mm/yy"            
                                         * For AP DRG: "HADNvvmm/yy"            
                                         */                                     
        char drg_significant_dx [5] [8];  /* 2ndary diagnoses affecting         
                                           * the DRG                            
                                           */                                   
        char drg_significant_pr [5] [8];  /* OR procedures affecting            
                                           * the DRG                            
                                           */                                   
        char drg_significant_npr [5] [8]; /* Non-OR procedures affecting        
                                           * the DRG                            
                                           */                                   
        char drg_cc_dx [8];             /* First CC Diagnosis           */      
                                                                                
/****** AP DRG ONLY OUTPUTS *********************************************/      
        char drg_trauma_indicator;      /* trauma registry indicator            
                                         *   0 = record not to be sent to       
                                         *       trauma registry                
                                         *   1 = record to be sent to           
                                         *       trauma registry                
                                         *   2 = record contains an             
                                         *       invalid age, trauma            
                                         *       cannot be calculated           
                                         */                                     
        char drg_majorcc_indicator;     /* major CC indicator                   
                                         *   0 = drg_cc_dx is a CC              
                                         *   1 = drg_cc_dx is a MCC1            
                                         *   2 = drg_cc_dx, paired with         
                                         *       drg_significant_npr[0],        
                                         *       is a MCC2                      
                                         *   3 = drg_cc_dx is a MCC3            
                                         *   4 = drg_cc_dx, paired with         
                                         *       drg_significant_npr[0],        
                                         *       is a MCC4                      
                                         */                                     
                                                                                
/****** REFINED DRG ONLY OUTPUTS ****************************************/      
        char drg_rdrg_rgn[4];           /* Refinement Group - 4 bytes   */      
        char drg_rdrg_adg[3];           /* Refinement Adjacent DRG      */      
        char drg_rdrg_mrg[4];           /* Refinement Medical Group             
                                         *  = RGN if no procedures used         
                                         */                                     
        char drg_rdrg_ped[1];           /* Refinement Pediatric                 
                                         * indicator                            
                                         *  = P if pt age <18                   
                                         */                                     
                                                                                
/****** RESERVED FOR FUTURE USE *****************************************/      
        char drg_outfill2[18];          /* Reserved                     */      
                                        /* 05-28-98 outfill2 was [30],  */      
                                        /* now, with refined grouper    */      
                                        /* added fields, is 18          */      
                                                                                
/****** GENERAL GROUPER OUTPUTS *****************************************/      
        Drg_Grcctab drg_dxcctab;        /* CC, MCC flags                        
                                         * For MS DRG:                          
                                         *   0 = DX is not a CC or MCC          
                                         *   1 = DX is an MCC                   
                                         *   2 = DX is a CC                     
                                         *   blank = Principal DX or            
                                         *           Invalid DX                 
                                         * For AP DRG:                          
                                         *   Y = DX is a CC                     
                                         *   blank = Principal DX or            
                                         *           DX is not a CC             
                                         */                                     
        char drg_dx_edit_tab[50];       /* blank = valid diagnosis code */      
                                        /* I = invalid diagnosis code   */      
                                                                                
        Drg_Regroup drg_regroup[49];    /* Regrouper output             */      
                                        /* For MS DRG and AP DRG        */      
                                        /* 49 x DRG[3],                 */      
                                        /*      RefClass[1] - not used  */      
                                        /*      RTC[1]                  */      
                                        /*      MDC[2]                  */      
                                        /* For Refined DRG              */      
                                        /* 49 x DRG[3],                 */      
                                        /*      RefClass[1]             */      
                                        /*      RTC[1]                  */      
                                        /*      MDC[2]                  */      
                                        /* where DRG and RefClass       */      
                                        /*   together define the        */      
                                        /*   Refinement Group           */      
                                                                                
        char drg_drg_title[80];         /* DRG Title from grouper       */      
        char drg_mdc_title[80];         /* MDC Title from grouper       */      
        char drg_pr_edit_tab[50];       /* blank = valid procedure code */      
                                        /* 0 = valid non-OR code        */      
                                        /* 1 = valid OR code            */      
                                        /* I = invalid code             */      
                                                                                
/****** RESERVED FOR FUTURE USE *****************************************/      
        char drg_fill_end_1[500];                                               
        /* take bytes out of filler by using a define statement so that         
         * existing groupers not using this field will still clear all          
         * 500 bytes of the filler                                              
         */                                                                     
   #define drg_malfrm_indicator drg_fill_end_1[0]                               
                                  /* congenital malformation indic */           
                                  /* 1 byte                        */           
                                  /* input for AP DRG only         */           
                                  /*   0 = record not to be sent to             
                                   *       CM registry                          
                                   *   1 = codes on record require              
                                   *       a malformation narrative             
                                   *   2 = codes on record don't req.           
                                   *       a malformation narrative             
                                   *   3 = some codes on record req.            
                                   *       a malformation narrative             
                                   *   4 = record contains an                   
                                   *       invalid age, CM cannot be            
                                   *       determined                           
                                   */                                           
   #define drg_pt_age_days drg_fill_end_1[1]                                    
                                  /* 3 bytes                       */           
                                  /* Not used by the grouper       */           
   #define oryx_data drg_fill_end_1[4]                                          
                                  /* 1 byte                        */           
                                  /* Not used by the grouper       */           
 };                                                                             
                                                                                
 typedef struct Hadgrp_Data Hadgrp_Data, far *HadgrpDataPtr;                    
                                                                                
                                                                                
struct Hadgrp2_Data                                                             
{                                                                               
/****** GENERAL GROUPER INPUTS ******************************************/      
                                                                                
        char drg_sver[4];               /* Structure version                    
                                         * Must be "GRP2"                       
                                         */                                     
        char drg_function;              /* I=init Hadgrp2_Data data             
                                         *   to all blanks,                     
                                         *   except preserve values of          
                                         *   drg_sver and drg_function          
                                         * G=group                              
                                         * F=free grouper storage               
                                         */                                     
        char drg_func_opt_remap;        /* Y=remap new codes to old codes       
                                         *   and vice versa                     
                                         */                                     
        char drg_func_opt_regroup;      /* Y=regroup using all 2ndary DX        
                                         *   as PDX                             
                                         */                                     
        char drg_func_opt_date_format;  /* auto detect overrides all options    
                                         * auto detect based on delimiter       
                                         *   YYYY.MM.DD                         
                                         *   MM/DD/YYYY                         
                                         *   DD-MM-YYYY                         
                                         * 1= MMDDYYYY                          
                                         * 2= DDMMYYYY                          
                                         * 3= YYYYMMDD                          
                                         * 4= YYYYDDD                           
                                         * blank= same as option 1              
                                         */                                     
        char drg_ovr_grouper[10];       /* Select grouper module:               
                                         * FED or blank:                        
                                         *   auto select Federal DRG grouper    
                                         *   by discharge date                  
                                         * F06 - Fnn:                           
                                         *   select specific version of         
                                         *   Federal DRG grouper                
                                         * APDRG:       -                       
                                         *   auto select All Patient(AP) DRG    
                                         *   grouper by discharge date          
                                         * A08 - Ann:                           
                                         *   select specific version of         
                                         *   All Patient(AP) DRG grouper        
                                         */                                     
        char drg_func_opt_grp_admit;    /* A = group by drg_admit_date  */      
                                                                                
                                                                                
/****** GENERAL CLAIM INPUTS ********************************************/      
                                                                                
        Drg_Age drg_pt_age_yrs;         /* Age in years 000-124         */      
                                        /* Not needed if admit/birth    */      
                                        /* date supplied                */      
        char drg_pt_sex;                /* M,1 or F,2                   */      
        char drg_discharge_status[2];   /* UB-04 discharge status       */      
        char drg_admit_date[10];        /* General date format field    */      
        char drg_discharge_date[10];    /* General date format field    */      
        char drg_birth_date[10];        /* General date format field    */      
        Dxsg8_Code drg_dx [50];         /* Diagnoses w/ or w/o                  
                                         * decimal points.                      
                                         * left justified, blank padded         
                                         * For MS DRG rightmost char is         
                                         * the POA indicator                    
                                         */                                     
        Dxsg8_Code drg_pr [50];         /* Procedure codes w/ or w/o            
                                         * decimal points                       
                                         * left justified, blank padded         
                                         */                                     
                                                                                
                                                                                
                                                                                
/****** MS DRG ONLY INPUTS **********************************************/      
                                                                                
        char drg_poa_logic;             /* X=No POA processing                  
                                         * Z=POA processing                     
                                         */                                     
        char drg_pr_date[50][10];       /* procedure dates              */      
                                                                                
                                                                                
/****** AP DRG ONLY INPUTS **********************************************/      
                                                                                
        char drg_func_opt_trauma;       /* Trauma processing option             
                                         * 1=grouper and trauma                 
                                         * 2=trauma only                        
                                         */                                     
        char drg_func_opt_bw;           /* Birth weight option          */      
/* birth weight options:                                                        
    1      use the entered weight                                               
                                                                                
    2      ignore entered wt, use wt implicit in ICD-9-CM code                  
           if invalid, flag wt as invalid                                       
                                                                                
    3      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, flag wt as invalid                                  
                                                                                
    4      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag weight as invalid                                
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, flag wt as invalid                   
                                                                                
    5      ignore entered wt, use wt implicit in ICD-9-CM code                  
           if invalid, default to normal wt                                     
                                                                                
    6      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, default to normal wt                                
                                                                                
    7      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag wt as invalid                                    
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, default to normal                    
                                                                                
    notes  1. Normal birth weight range is 100 - 9000 g.                        
           2. If option entry is invalid or missing, it defaults to 1.          
           3. For a crosscheck, a comparison is made between the entered        
              birth weight and the implicit birth weight.                       
           4. If the birth weight is required, the system returns DRG 470.      
           5. The normal weight default assumes birth weight is set             
              to >= 2499 g.                                                     
*/                                                                              
        char drg_birth_weight[4];       /* birth weight in grams.               
                                         * right justified, zero padded         
                                         */                                     
/****** APR DRG INPUTS **************************************************/      
                                                                                
/* some inputs designated as MS DRG ONLY are also used by APR DRG               
        char drg_pr_date[50][10];        * procedure dates              */      
                                                                                
/* some inputs designated as AP DRG ONLY are also used by APR DRG               
        char drg_func_opt_bw;            * Birth weight option                  
        char drg_birth_weight[4];        * birth weight in grams.       */      
                                                                                
                                                                                
/****** GENERAL GROUPER OUTPUTS *****************************************/      
                                                                                
        char drg_return_code[3];        /* 000-999; Zero on no error.   */      
        char drg_return_code_module[10];/* Module called by interface.  */      
        char drg_return_code_msg[60];   /* Text correspond to ret code  */      
                                                                                
        char drg_drg[4];                /* assigned DRG 0001-0999       */      
        char drg_mdc[2];                /* assigned MDC 00-99           */      
        char drg_rtc[2];                /* Return code from grouper             
                                         * right justified, zero padded         
                                         */                                     
        char drg_vers[20];              /* Version string from grouper          
                                         * For MS DRG: "HAFvv-mm/yy"            
                                         * For AP DRG: "HADNvvmm/yy"            
                                         */                                     
        char drg_significant_dx [5] [8];  /* 2ndary diagnoses affecting         
                                           * the DRG                            
                                           */                                   
        char drg_significant_pr [5] [8];  /* OR procedures affecting            
                                           * the DRG                            
                                           */                                   
        char drg_significant_npr [5] [8]; /* Non-OR procedures affecting        
                                           * the DRG                            
                                           */                                   
        char drg_cc_dx [8];             /* First CC Diagnosis           */      
                                                                                
        Drg_Grcctab drg_dxcctab;        /* CC, MCC flags                        
                                         * For MS DRG:                          
                                         *   0 = DX is not a CC or MCC          
                                         *   1 = DX is an MCC                   
                                         *   2 = DX is a CC                     
                                         *   blank = Principal DX or            
                                         *           Invalid DX                 
                                         * For AP DRG:                          
                                         *   Y = DX is a CC                     
                                         *   blank = Principal DX or            
                                         *           DX is not a CC             
                                         */                                     
        char drg_dx_edit_tab[50];       /* blank = valid diagnosis code */      
                                        /* I = invalid diagnosis code   */      
                                        /* P = invalid HAC POA indic    */      
        char drg_pr_edit_tab[50];       /* blank = valid procedure code */      
                                        /* 0 = valid non-OR code        */      
                                        /* 1 = valid OR code            */      
                                        /* I = invalid code             */      
                                                                                
        Drg_Regroup2 drg_regroup[49];   /* Regrouper output             */      
                                        /* 49 x DRG[4],                 */      
                                        /*      RTC[2]                  */      
                                        /*      MDC[2]                  */      
                                                                                
        char drg_drg_title[80];         /* DRG Title from grouper       */      
        char drg_mdc_title[80];         /* MDC Title from grouper       */      
                                                                                
                                                                                
/****** MS DRG ONLY OUTPUTS *********************************************/      
                                                                                
        char drg_cc_flag;               /* 0=DRG based on no CC or MCC          
                                         * 1=DRG based on MCC                   
                                         * 2=DRG based on CC                    
                                         */                                     
        char drg_med_surg_drg;          /* 0=RTC is non-zero                    
                                         * 1=Medical Final DRG                  
                                         * 2=Surgical Final DRG                 
                                         */                                     
        char drg_poa_error[50];         /* HAC Status (MS DRG V27+)             
                                         *   0=HAC not applicable               
                                         *   1=HAC criteria met                 
                                         *   2=HAC criteria not met
                                         *   3=HAC crit. not met, CC Excl.
                                         *     (MS DRG V31+)                    
                                         *                                      
                                         * POA Status (MS DRG V26 only)         
                                         * 0=POA processing selected and        
                                         *   not a HAC                          
                                         *   or                                 
                                         *   POA processing selected and        
                                         *   a HAC with a valid POA indic.      
                                         * 1=POA processing selected and        
                                         *   a HAC with invalid POA indic.      
                                         *   or                                 
                                         *   POA processing not selected        
                                         */                                     
        char drg_dx_affected_drg[50];   /* 0=DX did not affect the DRG          
                                         * 1=DX affected initial DRG only       
                                         * 2=DX affected final DRG only         
                                         * 3=DX affected both initial           
                                         *   and final DRG                      
                                         */                                     
        char drg_pr_affected_drg[50];   /* 0=proc did not affect the DRG        
                                         * 1=proc affected initial DRG only     
                                         * 2=proc affected final DRG only       
                                         * 3=proc affected both initial         
                                         *   and final DRG                      
                                         */                                     
        char drg_pr_or_flag[50];        /* 0=not an OR procedure                
                                         * 1=operating room (OR) procedure      
                                         */                                     
                                        /* Initial DRG outputs          */      
        char drg_drg_init[4];           /* Initial DRG 0001-0999        */      
        Drg_Grcctab drg_dxcctab_init_drg; /* CC/MCC flags for init. DRG         
                                           * For MS DRG:                        
                                           *   0 = DX is not a CC or MCC        
                                           *   1 = DX is an MCC                 
                                           *   2 = DX is a CC                   
                                           *   blank = Principal DX or          
                                           *           Invalid DX               
                                           * For AP DRG:                        
                                           *   Y = DX is a CC                   
                                           *   blank = Principal DX or          
                                           *           DX is not a CC           
                                           */                                   
        char drg_med_surg_drg_init;     /* 0=RTC is non-zero                    
                                         * 1=Medical Initial DRG                
                                         * 2=Surgical Initial DRG               
                                         */                                     
        char drg_sig_dx_init_drg [5] [8];  /* 2ndary diagnoses affecting        
                                            * the initial DRG                   
                                            */                                  
        char drg_sig_pr_init_drg [5] [8];  /* OR procedures affecting           
                                            * the initial DRG                   
                                            */                                  
        char drg_sig_npr_init_drg [5] [8]; /* Non-OR procedures affecting       
                                            * the initial DRG                   
                                            */                                  
                                                                                
                                                                                
/****** AP DRG ONLY OUTPUTS *********************************************/      
                                                                                
        char drg_trauma_indicator;      /* trauma registry indicator            
                                         *   0 = record not to be sent to       
                                         *       trauma registry                
                                         *   1 = record to be sent to           
                                         *       trauma registry                
                                         *   2 = record contains an             
                                         *       invalid age, trauma            
                                         *       cannot be calculated           
                                         */                                     
        char drg_majorcc_indicator;     /* major CC indicator                   
                                         *   0 = drg_cc_dx is a CC              
                                         *   1 = drg_cc_dx is a MCC1            
                                         *   2 = drg_cc_dx, paired with         
                                         *       drg_significant_npr[0],        
                                         *       is a MCC2                      
                                         *   3 = drg_cc_dx is a MCC3            
                                         *   4 = drg_cc_dx, paired with         
                                         *       drg_significant_npr[0],        
                                         *       is a MCC4                      
                                         */                                     
        char drg_malform_indicator;     /* congenital malformation ind.         
                                         *   0 = record not to be sent to       
                                         *       CM registry                    
                                         *   1 = codes on record require        
                                         *       a malformation narrative       
                                         *   2 = codes on record don't req.     
                                         *       a malformation narrative       
                                         *   3 = some codes on record req.      
                                         *       a malformation narrative       
                                         *   4 = record contains an             
                                         *       invalid age, CM cannot be      
                                         *       determined                     
                                         */                                     
/****** APR DRG OUTPUTS *************************************************/      
                                                                                
/* some outputs designated as MS DRG ONLY are also used by APR DRG              
        char drg_med_surg_drg;           * 0=RTC is non-zero                    
                                         * 1=Medical  Discharge DRG             
                                         * 2=Surgical Discharge DRG             
        char drg_dx_affected_drg[50];    * 0=DX did not affect the DRG          
                                         * 1=DX affected Discharge DRG only     
                                         * 2=DX affected Admit DRG only         
                                         * 3=DX affected both Admit             
                                         *   and Discharge DRG                  
        char drg_pr_affected_drg[50];    * 0=proc did not affect the DRG        
                                         * 1=proc affected Discharge DRG only   
                                         * 2=proc affected Admit DRG only       
                                         * 3=proc affected both Admit           
                                         *   and Discharge DRG                  
        char drg_pr_or_flag[50];         * 0=not an OR procedure                
                                         * 1=operating room (OR) procedure      
        char drg_drg_init[4];            * Admit DRG 0001-0999                  
        char drg_med_surg_drg_init;      * 0=RTC is non-zero                    
                                         * 1=Medical  Admit DRG                 
                                         * 2=Surgical Admit DRG         */      
                                                                                
                                                                                
/****** RESERVED FOR FUTURE USE *****************************************/      
                                                                                
        char drg_fill_end_1[500];                                               
                                                                                
                                                                                
/****** Additional MS DRG ONLY OUTPUTS *********************************/       
                                                                                
/* HAC condition satisfied flags 12 chars 1 if true, otherwise false */         
#define drg_hac_cond_met               drg_fill_end_1[0]                        
                                                                                
                                                                                
/****** Additional APR DRG ONLY INPUTS **********************************/      
                                                                                
/* days on mechanical ventilator 3 chars 000-999 */                             
#define drg_mech_vent_days               drg_fill_end_1[0]                      
                                                                                
/* days after admission when placed on mech. ventilator         */              
/* 3 chars -99-999 left justified, blank padded. FOR FUTURE USE */              
#define drg_mech_vent_days_after_admit   drg_fill_end_1[3]                      
                                                                                
/****** Additional APR DRG ONLY OUTPUTS *********************************/      
                                                                                
/* discharge severity of illness 1 char 0-4 */                                  
#define drg_soi                          drg_fill_end_1[6]                      
                                                                                
/* discharge risk of mortality 1 char 0-4 */                                    
#define drg_rom                          drg_fill_end_1[7]                      
                                                                                
/* admission return code 2 chars 00-12  */                                      
#define drg_rtc_admit                    drg_fill_end_1[8]                      
                                                                                
/* admission MDC 2 chars 00-25          */                                      
#define drg_mdc_admit                    drg_fill_end_1[10]                     
                                                                                
/* admission severity of illness 1 char 0-4 */                                  
#define drg_soi_admit                    drg_fill_end_1[12]                     
                                                                                
/* admission risk of mortality 1 char 0-4 */                                    
#define drg_rom_admit                    drg_fill_end_1[13]                     
                                                                                
/* diagnosis affected severity of illness 1 char 0-3 */                         
#define drg_dx_affected_soi              drg_fill_end_1[14]                     
                                                                                
/* diagnosis affected risk of mortality 1 char 0-3 */                           
#define drg_dx_affected_rom              drg_fill_end_1[64]                     
                                                                                
/* diagnosis discharge SOI level 1 char P,X,0-4 */                              
#define drg_dx_aff_soi_level             drg_fill_end_1[114]                    
                                                                                
/* diagnosis discharge ROM level 1 char P,X,0-4 */                              
#define drg_dx_aff_rom_level             drg_fill_end_1[164]                    
                                                                                
/* diagnosis admission SOI level 1 char P,X,0-4 */                              
#define drg_dx_aff_soi_level_admit       drg_fill_end_1[214]                    
                                                                                
/* diagnosis admission ROM level 1 char P,X,0-4 */                              
#define drg_dx_aff_rom_level_admit       drg_fill_end_1[264]                    
                                                                                
/* procedure affected severity of illness 1 char 0-3 */                         
#define drg_pr_affected_soi              drg_fill_end_1[314]                    
                                                                                
/* procedure affected risk of mortality 1 char 0-3 */                           
#define drg_pr_affected_rom              drg_fill_end_1[364]                    
                                                                                
                                                                                
/****** Additional GENERAL CLAIM INPUTS *********************************/      
                                                                                
/* version of ICD codes being used - 2 char 9 or 10, 
 *              blank implies code set required by for selected grouper */         
#define drg_icd_version                  drg_fill_end_1[414]                    
                                                                                
/* source of admission - 1 char 1-9,A-F */                                      
#define drg_admit_source                 drg_fill_end_1[416]                    
                                                                                
                                                                                
/****** Additional APR DRG ONLY INPUTS **********************************/      
                                                                                                                   
/* discharge DRG option - 1 char,                                               
 *                        0 or space will compute the Discharge DRG             
 *                          using HAC logic.                                    
 *                        1 will compute the Discharge DRG excluding            
 *                          all complication of care codes.                     
 *                          No Admit DRG will be returned.                      
 */                                                                             
#define drg_disch_DRG_opt                drg_fill_end_1[417]                    
                                                                                
/* agency indicator used by HAC logic - 1 char, 1=Medicare,2=Medicaid */        
#define drg_agency_indic                 drg_fill_end_1[418]                    

/* HAC version - 3 chars, e.g. 290 */                                           
#define drg_hac_version                  drg_fill_end_1[419]                    

/* agency indicator used by HAC logic - 2 char, 11=CA Medicaid */               
#define drg_agency_indic2                drg_fill_end_1[422]                    
                                                                                
                                                                                
/****** Additional APR DRG ONLY OUTPUTS *********************************/      
                                                                                
/* HAC category condition satisfied 20 chars 1 if true, otherwise false */      
#define apr_hac_cond_met                 drg_fill_end_1[424]                    
                                                                                

/****** Additional GENERAL CLAIM INPUTS *********************************/      

/* condition codes - 7 allowed, 2 chars each */
#define drg_cond_codes                   drg_fill_end_1[444]

/* grouper add on processing - 1 char, 1=New York Medicaid */
#define drg_grouper_add_on               drg_fill_end_1[458]


/****** NEW YORK MEDICAID ONLY INPUTS ***********************************/ 

/* hospital type - 1 char, 1=Psych exempt, 0=Not Psych exempt */
#define drg_hosp_type                    drg_fill_end_1[459]

/* payer flag - 1 char, 1=Medicaid, 2=Medicaid Managed Care */     
#define drg_payer_flag                   drg_fill_end_1[460]
                                                                                

/****** NEW YORK MEDICAID ONLY OUTPUTS **********************************/ 

/* payment action - 1 char, 0=N/A, 1=Pay in full, 2=Reduced Pay, 3=Deny */
#define drg_pay_action                   drg_fill_end_1[461]

/* psych payment flag - 1 char, 1=Qualifies for Psych Exempt payment */
#define drg_psych_pay_flag               drg_fill_end_1[462]

/* mental retardation flag - 1 char, 1=mental retardation code present */
#define drg_mental_retard                drg_fill_end_1[463]

/* comorbity categories - 20 categories allowed, 1 char each, 1=present */
#define drg_comorb_cat                   drg_fill_end_1[464]
                                                                                
};                                                                              
                                                                                
typedef struct Hadgrp2_Data Hadgrp2_Data, far *Hadgrp2DataPtr;                  
                                                                                
/*********************************************************************/         
/*                                                                   */         
/*               HADGRP IRP APC Grouper Call Structures              */         
/*               --------------------------------------              */         
/*********************************************************************/         
                                                                                
/* This is the start of the HADGRP IRP APC grouper call structure    */         
/* all fields are character displayable.  All conversions to         */         
/* numeric will be done in the calling and called programs           */         
                                                                                
/* The following data types are declared to remove any uncertainty   */         
/* about parameter passing and to ensure that the data areas passed  */         
/* are sized correctly.                                              */         
                                                                                
#define APC_Version_Extend_Date 45   /* extend end date of latest    */         
                                 /* entry in the versionrange table  */         
struct Apc_Grvsn                                                                
/*     ---------                                                     */         
 {                                                                              
  char chars [11];              /* Low-level returned grouper version*/         
 };                                                                             
typedef struct Apc_Grvsn Apc_Grvsn;                                             
                                                                                
                                                                                
typedef char Apc_Grret;         /* Low-level return code one char    */         
                                                                                
                                                                                
struct Apc_Dstat                                                                
 {                                                                              
  char chars [2];               /* Two digits UB-04 form             */         
 };                                                                             
typedef struct Apc_Dstat Apc_Dstat;                                             
                                                                                
                                                                                
struct Apc_Age                                                                  
/*     -------                                                       */         
 {                                                                              
  char chars [3];               /* Three digits, right justified     */         
 };                                                                             
typedef struct Apc_Age Apc_Age;                                                 
                                                                                
                                                                                
struct Apc_Regroup                                                              
/*     -----------                                                   */         
 {                                                                              
  char mapc      [5];                    /* twf 10-28-99 */                     
  char mapc_type [2];                                                           
 };                                                                             
typedef struct Apc_Regroup Apc_Regroup, *Apc_Regroup_Ptr;                       
                                                                                
typedef struct ValueCodes
{
  char value[2];             /* QN - QW                              */
  char amount[9];            /* implied decimal nnnnnnn.nn           */
} ValueCodes;

struct Apc_Assigned                                                             
/*     ------------                                                  */         
 {                                                                              
  char papc[5];             /* APC used to determine payment                 */ 
  char papc_status[2];      /* status indicator                              */ 
                            /*    right-justified, blank-filled              */ 
                            /*  A Services not paid under OPPS               */ 
                            /*  B Non-allowed item or service for OPPS       */ 
                            /*  C Inpatient procedure                        */ 
                            /*  E Non-allowed item or service                */ 
                            /*  F Corneal tissue acquisition; certain CRNA   */ 
                            /*    services and hepatitis B vaccines          */ 
                            /*  G Drug/biological pass-through               */ 
                            /*  H Pass-through device categories and         */ 
                            /*    radiopharmaceutical agents                 */ 
                            /*  J New drug or new biological pass-through    */ 
                            /* J1 Outpatient department services paid        */
                            /*    through  a comprehensive APC               */
                            /* J2 Hospital Part B services that may be paid  */
                            /*    through a comprehensive APC                */
                            /*  K Non-pass-through drugs and biologicals     */ 
                            /*  L Flu/PPV vaccines                           */ 
                            /*  M Service not billable to the FI/MAC         */ 
                            /*  N Items and Services packaged into APC rates */ 
                            /*  P Partial hospitalization service            */ 
                            /* Q1 STVX-packaged codes                        */ 
                            /* Q2 T-packaged codes                           */ 
                            /* Q3 Codes paid through a composite APC         */ 
                            /* Q4 Conditionally packaged laboratory services */ 
                            /*  R Blood and blood products                   */ 
                            /*  S Significant proceudre not subject to       */ 
                            /*    multiple procedure discounting             */ 
                            /*  T Significant proceudre subject to           */ 
                            /*    multiple procedure discounting             */ 
                            /*  U Brachytherapy sources                      */ 
                            /*  V Clinic or emergency department visit       */ 
                            /*  W Invalid HCPCS or invalid revenue code with */ 
                            /*    blank HCPCS                                */ 
                            /*  X Ancillary service                          */ 
                            /*  Y Non-implantable DME                        */ 
                            /*  Z Valid revenue code with blank HCPCS and no */ 
                            /*    other SI assigned                          */ 
  char papc_error[edit_rtn_sz];                                                 
                             /* blank = no error on line item                */ 
                             /* non-blank = error on line item               */ 
                             /*     see haagrp.ini for possible              */ 
                             /*     edit codes and corresponding             */ 
                             /*     messages                                 */ 
  char papc_pay_flag[v7_flag_sz];                                               
                             /* payment indicator                            */ 
                             /*     right-justified, blank-filled            */ 
                             /* 1 Paid standard hospital OPPS amount         */ 
                             /*   (status indicators J1,J2,K,R,S,T,U,V)      */ 
                             /* 2 Service not paid under OPPS                */ 
                             /*   (status indicator A)                       */ 
                             /* 3 Not paid                                   */ 
                             /*   (status indicators E,M,Q,Q1,Q2,Q3,Q4,W,Y)  */ 
                             /*   or not paid under OPPS                     */ 
                             /*   (status indicators B, C, Z)                */ 
                             /* 4 Paid at reasonable cost                    */ 
                             /*   (status indicators F, L)                   */ 
                             /* 5 Paid standard amount for pass-through drug */ 
                             /*   or biological                              */ 
                             /*   (status indicator G)                       */ 
                             /* 6 Payment based on charge adjusted to cost   */ 
                             /*   (status indicators H, U)                   */ 
                             /* 7 Additional payment for new drug or new     */ 
                             /*   biological                                 */ 
                             /* 8 Paid partial hospitalization per diem      */ 
                             /*   (status indicator P)                       */ 
                             /* 9 No additional payment;                     */ 
                             /*   Payment included in line items with APCs   */ 
                             /*   (status indicator N;                       */ 
                             /*   or no HCPCS code and certaiin revenue      */ 
                             /*   codes or HCPCS codes G0176, G0129 or G0177)*/
                             /* 10 Paid FQHC encounter payment               */
                             /* 11 Not paid or not included under FQHC       */
                             /*    encounter payment                         */
                             /* 12 No additional payment, included in        */
                             /*    payment for FQHC encounter                */
                             /* 13 Paid FQHC encounter payment for New       */
                             /*    patient or IPPE/AWV                       */
                             /* 14 Grandfathered tribal FQHC payment         */
  char papc_discount_formula;/* discount formula number                      */ 
                             /* 1  1.0                                       */ 
                             /* 2  (1.0 + D(U-1))/U                          */ 
                             /* 3  T/U                                       */ 
                             /* 4  (1 + D)/U                                 */ 
                             /* 5  D                                         */ 
                             /* 6  TD/U                                      */ 
                             /* 7  D(1 + D)/U                                */ 
                             /* 8  2.0                                       */ 
                             /* 9  2D/U                                      */ 
                             /* where D = discounting fraction               */ 
                             /*       U = number of units                    */ 
                             /*       T = terminated procedure discount      */ 
  char papc_denial_flag;     /* line item denial or rejection flag           */ 
                             /* 0 Line item is not denied or rejected.       */ 
                             /* 1 Line item is denied or rejected.           */ 
                             /* 2 Line item is not denied or rejected but    */ 
                             /*   occurs on a day that has been denied or    */ 
                             /*   rejected.                                  */ 
  char papc_packaging_flag;  /* packaging flag                               */ 
                             /* 0 Not packaged                               */ 
                             /* 1 Packaged service                           */ 
                             /* 2 Packaged as part of partial hospitalization*/ 
                             /*   per diem or daily mental health service    */ 
                             /*   per diem                                   */ 
                             /* 3 Artificial charges for surgical procedures */ 
                             /* 4 Packaged as part of drug administrations   */ 
                             /*   APC payment                                */ 
                             /* 5 Packaged as part of FQHC encounter payment */
                             /* 6 Packaged preventive service as part of FQHC*/
                             /*   encounter payment not subject to           */
                             /*   coinsurance payment                        */
  char papc_pay_adjust[v7_flag_sz]; /* payment adjustment flag               */ 
                             /*    right-jusified, blank-filled              */ 
                             /*  0 No payment adjustment                     */ 
                             /*  1 Paid standard amount for pass-through drug*/ 
                             /*    or biological (status indicator G)        */ 
                             /*  2 Payment based on charge adjusted to cost  */ 
                             /*    (status indicators H, U)                  */ 
                             /*  3 Additional payment for new drug or new    */ 
                             /*    biological applies to APC                 */ 
                             /*    (status indicator J)                      */ 
                             /*  4 Deductible not applicable                 */ 
                             /*    (specific list of HCPCS codes)            */ 
                             /*  5 Blood/blood product used in blood         */ 
                             /*    deductible calculation                    */ 
                             /*  6 Blood processing/storage not subject to   */ 
                             /*    blood deductible                          */ 
                             /*  7 Item provided without cost to provider    */ 
                             /*  8 Item provided with partial credit to      */ 
                             /*    provider                                  */ 
                             /*  9 Deductible/co-insurance not applicable    */
                             /* 10 Co-insurance not applicable               */
                             /* 11 Multiple service units reduced to one by  */
                             /*    IOCE processing; payment based on single  */
                             /*    payment rate                              */
                             /* 12 Offset for first  device pass-through     */
                             /* 13 Offset for second device pass-through     */
                             /* 14 PAMA Section 218 reduction on CT scan     */
                             /* 15 Placeholder - Reserved for Future Use     */
                             /* 16 Terminated procedure with pass-thru device*/
                             /* 17 Condition for device credit present       */
                             /* 18 Offset for 1st pass-thru drug/biological  */
                             /* 19 Offset for 2nd pass-thru drug/biological  */
                             /* 20 Offset for 3rd pass-thru drug/biological  */
  char papc_bill_inclusion;  /* payment method flag                          */ 
                             /* 0 fOPPS pricer determines payment for service*/ 
                             /* 1 Based on OPPS, Coverage of Billing rules,  */ 
                             /*   the service is not paid                    */ 
                             /* 2 Service is not subject to OPPS             */ 
                             /* 3 Service is not subject to OPPS and has a   */ 
                             /*   line item denial or rejection              */ 
                             /* 4 Line item is denied or rejected by FI/MAC; */ 
                             /*   OPPS is not applied to line item           */ 
                             /* 5 Payment for service determined under FQHC  */
                             /*   PPS                                        */
};                                                                              
typedef struct Apc_Assigned Apc_Assigned, *Apc_Assigned_Ptr;                    
                                                                                
typedef struct claim_return                                                     
{                                                                               
  char  ovclmdisp;           /* overall claim disposition: */                   
                             /* 0 no edits present on claim */                  
                             /* 1 only edits present are for line item */       
                             /*   denial or rejection */                        
                             /* 2 multiple-day claim with one or more days */   
                             /*   denied or rejected */                         
                             /* 3 claim denied, rejected, suspended or */       
                             /*   returned to provider, or single day */        
                             /*   claim with all line items denied or */        
                             /*   rejected, with only post-payment edits */     
                             /* 4 claim denied, rejected, suspended or */       
                             /*   returned to provider, or single day */        
                             /*   claim with all line items denied or */        
                             /*   rejected, with only pre-payment edits */      
                             /* 5 claim denied, rejected, suspended or */       
                             /*   returned to provider, or single day */        
                             /*   claim with all line items denied or */        
                             /*   rejected, with both post-payment and */       
                             /*   pre-payment edits */                          
  char  rejdisp;             /* 0 claim not rejected */                         
                             /* 1 there are one or more edits present that */   
                             /*   cause the claim to be rejected */             
                             /* 2 there are one or more edits present that */   
                             /*   cause one or more days of a multiple-day */   
                             /*   claim to be rejected */                       
  char  dendisp;             /* 0 claim not denied */                           
                             /* 1 there are one or more edits present that */   
                             /*   cause the claim to be denied */               
                             /* 2 there are one or more edits present that */   
                             /*   cause one or more days of a multiple-day */   
                             /*   claim to be denied */                         
  char  retdisp;             /* 0 claim not returned to provider */             
                             /* 1 one or more edits that caused the claim */    
                             /*   to be returned */                             
  char  susdisp;             /* 0 claim not suspended */                        
                             /* 1 one or more edits that caused the claim */    
                             /*   to be suspended */                            
  char  lrejdisp;            /* 0 line item not rejected */                     
                             /* 1 one or more edits that caused the line */     
                             /*   item to be rejected */                        
  char  ldendisp;            /* 0 no line item denials */                       
                             /* 1 one or more edits that caused one or */       
                             /*   more line items to be denied */               
  edit_rtn clmrej[4];        /* edits that caused the claim to be rejected*/    
  edit_rtn clmden[8];        /* edits that caused the claim to be denied */     
  edit_rtn clmreturn[30];    /* edits that caused the claim to be returned*/    
  edit_rtn clmsuspend[16];   /* edits that caused the claim to be suspended */  
  edit_rtn linerej[12];      /* edits that caused the line items to be */       
                             /* rejected */                                     
  edit_rtn lineden[6];       /* edits that caused the line items to be */       
                             /* denied  */                                      
}claim_return;                                                                  
                                                                                
                                                                                
                                                                                
/*---------------------------------------------------------*/                   
/* Structure for Grouper Interface.                        */                   
/*---------------------------------------------------------*/                   
                                                                                
/* Some fields are not returned in version APC_VERSION_1   */                   
/*                                                         */                   
/* Fill APC_INIT in apc_function to clear out all fields.  */                   
/*                                                         */                   
/* Pass this structure to HAAGRP01 after filling in:       */                   
/*   Service Date                                          */                   
/*   Discharge Status                                      */                   
/*   Date of Birth                                         */                   
/*   Age                                                   */                   
/*   Significant Procedures                                */                   
/*   Significant Diagnoses                                 */                   
/*   Patient Gender (M, 1, F, 2)                           */                   
/*                                                         */                   
/* Returned fields include:                                */                   
/*   apc_apc                                               */                   
/*   apc_rtc                                               */                   
/*   apc_patient_type                                      */                   
/*   apc_status                                            */                   
/*   apc_error                                             */                   
/*   mapc_ssf                                              */                   
/*   papc                                                  */                   
/*   papc_type                                             */                   
/*   papc_error                                            */                   
/*   apc_consolidation                                     */                   
/*   apc_ancillary                                         */                   
/*                                                         */                   
                                                                                
struct Haagrp_Data                                                              
/*     -----------                                                   */         
 {                                                                              
                             /* ==================================== */         
                             /* IRP Universal Grouper Call Struct    */         
                             /* ==================================== */         
                             /*                                      */         
                             /* ------------------------------------ */         
                             /* Identification Area                  */         
                             /* ------------------------------------ */         
 char apc_sver[4];           /*   Structure version id               */         
                             /*     Set to "APC3"                    */         
                             /* ------------------------------------ */         
                             /* Function Request Indicators          */         
                             /* ------------------------------------ */         
 char apc_function;          /*   Function request                   */         
                             /*     I  Init Haagrp_Data data to all  */         
                             /*        blanks, except preserve       */         
                             /*        apc_sver and apc_function     */         
                             /*     G  Group                         */         
                             /*     F  Free grouper storage          */         
                             /* ------------------------------------ */         
                             /* Processing Options/Modules           */         
                             /* ------------------------------------ */         
 char apc_func_opt_remap;    /*   reserved for future use            */         
 char apc_func_opt_regroup;  /*   reserved for future use            */         
 char apc_func_opt_mce_edit; /*   reserved for future use            */         
 char apc_func_opt_price;    /*   Calculate Reimbursement            */         
                             /*     reserved for future use          */         
 char apc_func_opt_pr_codes; /*   9 = ICD-9-CM, C = CPT-4            */         
                             /*     reserved for future use          */         
 char apc_func_opt_date_format; /* Date Format Indicator             */         
                             /*   auto detect overrides all options  */         
                             /*     auto detect based on delimiter   */         
                             /*        YYYY.MM.DD                    */         
                             /*        MM/DD/YYYY                    */         
                             /*        DD-MM-YYYY                    */         
                             /*     1= MMDDYYYY                      */         
                             /*     2= DDMMYYYY                      */         
                             /*     3= YYYYMMDD                      */         
                             /*     4= YYYYDDD                       */         
                             /*     blank= same as option 1          */         
                             /*     for HAAFxxCS entry point         */         
                             /*        must use MM/DD/YYYY format    */         
 char apc_func_opt_7;        /*   reserved for future use            */         
 char apc_func_opt_8;        /*   reserved for future use            */         
 char apc_func_opt_9;        /*   reserved for future use            */         
 char apc_func_opt_10;       /*   reserved for future use            */         
 char apc_func_opt_11;       /*   reserved for future use            */         
 char apc_func_opt_12;       /*   reserved for future use            */         
 char apc_func_opt_13;       /*   reserved for future use            */         
 char apc_func_opt_14;       /*   reserved for future use            */         
 char apc_func_opt_15;       /*   reserved for future use            */         
                             /* ------------------------------------ */         
                             /* Processing Overrides                 */         
                             /* ------------------------------------ */         
                             /*                                      */         
 char apc_ovr_grouper[10];   /*   Select grouper module:             */         
                             /*     HCFA Federal Medicare            */         
                             /*     ---------------------            */         
                             /*     "   " or                         */         
                             /*     "FED" or                         */         
                             /*     "APC" = Auto-Select by Discharge */         
                             /*             Date                     */         
                             /*     "F10A" = 2009 Q1 grouper         */         
 char apc_ovr_pricer[10];    /*   Pricer module                      */         
                             /*     reserved for future use          */         
 char apc_ovr_module2[10];   /*   reserved for future use            */         
 char apc_ovr_module3[10];   /*   reserved for future use            */         
 char apc_ovr_module4[10];   /*   reserved for future use            */         
 char apc_ovr_pkg_tbl[2];    /*   Internal Packaging Table ##        */         
                             /*     reserved for future use          */         
 char apc_ovr_cons_tbl[2];   /*   Internal Consolidation Tbl ##      */         
                             /*     reserved for future use          */         
                             /* ------------------------------------ */         
                             /* MAIN RETURN DATA                     */         
                             /* ------------------------------------ */         
 char apc_return_code[3];    /*   Return Code 000-999  000=OK        */         
                             /*     see haagrp.ini for possible      */         
                             /*     return codes and corresponding   */         
                             /*     messages                         */         
 char apc_return_code_ext[3];/*   reserved for future use            */         
 char apc_return_code_module[10];/* module used to perform grouping  */         
                             /*     blank for HAAFxxCS entry point   */         
 char apc_return_code_parag[10];/* reserved for future use           */         
 char apc_return_code_msg[60];/*  Return Code Text                   */         
                             /*     see haagrp.ini for possible      */         
                             /*     return codes and corresponding   */         
                             /*     messages                         */         
                             /* ------------------------------------ */         
                             /* PATIENT/CASE Input Data              */         
                             /* ------------------------------------ */         
                             /*                                      */         
                             /*       Data Required for Grouping     */         
                             /*       --------------------------     */         
                             /*                                      */         
 Apc_Age apc_pt_age_yrs;     /*   Age years 000-124                  */         
                             /*     Not Needed, if From Date and     */         
                             /*     Birth Date are supplied          */         
 char apc_pt_sex;            /*   Sex  1,M = Male  2,F=Female        */         
                             /*          0 = Unknown                 */         
 char apc_discharge_status[2];/*  UB-04 Discharge Status             */         
 Dxsg8_Code apc_dx[50];      /*   Array of 50  ICD-9/10 Diagnoses    */         
                             /*     8 characters each                */         
                             /*     left or right-justified          */         
                             /*     blank-filled                     */         
                             /*     decimal points are optional      */         
                             /*     for HAAFxxCS entry point codes   */         
                             /*     must be left-justified, blank-   */         
                             /*     filled with no decimal points    */         
 Dxsg8_Code apc_pr[100];     /*   Array of 100 CPT-4 Procedures      */         
                             /*     with or without one 2 character  */         
                             /*     modifier per code                */         
                             /*     e.g. 30000 or 30000-25           */         
                             /*     up to 3 additional modifiers are */         
                             /*     in apc_modifiers below           */         
                             /*     8 characters each                */         
                             /*     left-justified                   */         
                             /*     blank-filled, if no modifier     */         
 date_field apc_service_dates[100];/* 100 10 byte service dates      */         
                             /*     in format specified by           */         
                             /*        apc_func_opt_date_format      */         
                             /*     for HAAFxxCS entry point must    */         
                             /*        use MM/DD/YYYY format         */         
 revenue_code apc_revenue_codes[100]; /* 100 4 byte revenue codes    */         
 service_unit apc_service_units[100]; /* 100 3 byte service units    */         
                             /*     right-justified, zero-filled     */         
 date_field apc_from_date;   /*   from date                          */         
                             /*     in format specified by           */         
                             /*        apc_func_opt_date_format      */         
                             /*     for HAAFxxCS entry point must    */         
                             /*        use MM/DD/YYYY format         */         
 date_field apc_through_date;/*   through date                       */         
                             /*     in format specified by           */         
                             /*        apc_func_opt_date_format      */         
                             /*     for HAAFxxCS entry point must    */         
                             /*        use MM/DD/YYYY format         */         
 condition_code apc_condition_codes[7]; /* 7 2 byte condition codes  */         
 char apc_bill_type[3];      /*   bill type                          */         
 char apc_npi[13];           /*   national provider id               */         
 char apc_oscar[6];          /*   OSCAR Medicare value               */         
 char apc_birth_date[10];    /*   birth date                         */         
                             /*     in format specified by           */         
                             /*        apc_func_opt_date_format      */         
                             /*     for HAAFxxCS entry point must    */         
                             /*        use MM/DD/YYYY format         */         
 char apc_birth_weight[4];   /*   reserved for future use            */         
 char apc_charges[12];       /*   Total Actual Charges               */         
                             /*     Explicit Decimal Used            */         
                             /*     not used by the grouper          */         
 pr_modifiers apc_modifiers[100]; /* up to 3 additional modifiers    */         
                             /*      each for 100 cpts               */         
                             /*     each modifier is 2 bytes         */         
                             /*     the first modifier is appended   */         
                             /*     to the cpt (e.g 30000-25) in     */         
                             /*     apc_pr above                     */         
                             /* ------------------------------------ */         
                             /* BASIC OUTPUT FROM GROUPER            */         
                             /* ------------------------------------ */         
                             /*                                      */         
 char apc_outfill1;          /*   reserved for future use            */         
 char apc_rtc;               /*   not used by grouper                */         
 char apc_vers[20];          /*   grouper version                    */         
                             /*     e.g. HAA10A-0109 10.0.0          */         
#define claim_vers apc_vers + 12 /* 8 chars from version field in    */         
                             /* oce_claim_return structure           */         
                             /*                                      */         
 char apc_pt_visit_type[1];  /*   reserved for future use            */         
 char apc_status [1];        /*   APC status code 0 = no errors      */         
                             /*     0 Claim processed                */         
                             /*     1 Claim not processed; invalid   */         
                             /*        date; inappropriate bill      */         
                             /*        type/condition code           */         
                             /*        combination; or invalid bill  */         
                             /*        type                          */         
                             /*     2 Claim not processed; no line   */         
                             /*       items present                  */         
                             /*     3 Claim not processed; condition */         
                             /*       code 21 present                */         
                             /*     9 A fatal error has been         */         
                             /*       detected during initializaton  */         
 char apc_mapc[5];           /*   not used by grouper                */         
 char apc_mapc_type[2];      /*   not used by grouper                */         
 char apc_mapc_cat[2];       /*   not used by grouper                */         
 char apc_mapc_ssf[8];       /*   not used by grouper                */         
 Apc_Assigned apc_assigned[100];/* APC return buffer                 */         
                             /*   see Apc_Assigned above             */         
 claim_return papc_claim_return;/* claim return buffer               */         
                             /*   see claim_return above             */         
 edit_rtn apc_dx_edit_tab[50];/*  Diagnosis Code Edits               */         
                             /*     50 3 byte edit codes             */         
                             /*     blank = valid code               */         
                             /*     non-blank = invalid Code         */         
                             /*     see haagrp.ini for possible      */         
                             /*     edit codes and corresponding     */         
                             /*     messages                         */         
 char filler1[2000];                                                            
#define unused filler1       /* 2 bytes, unused                      */         
#define opps filler1 + 2     /* 1 byte opps/non-opps flag            */         
                             /*   1 = OPPS, 2 - Non-OPPS             */         
#define claim_processed filler1[3] /* 1 byte                         */         
                             /* 0  claim processed                   */         
                             /* 1  claim not processed: invalid date */         
                             /*     (edit 23 or 24) or inappropriate */         
                             /*     bill type/condition code         */         
                             /*     combination (edit 45)            */         
                             /* 2  claim not processed: no line items*/         
                             /*     present                          */         
                             /* 3  claim not processed: condition    */         
                             /*     code 21 present (edit 10)        */         
                             /* 9  a fatal error has been detected   */         
                             /*     during initialization. see page  */         
                             /*     3.13 for a list of reasons for a */         
                             /*     fatal error. This error must be  */         
                             /*     tested for in your user          */         
                             /*     interface and processing should  */         
                             /*     be terminated immediately        */         
#define apc_admit_dx filler1[4]/* reason for visit diagnosis         */         
                             /* 8 bytes, may be left blank           */         
                             /*   left or right-justified            */         
                             /*   blank-filled                       */         
                             /*   Decimal Points are Optional        */         
                             /*   for HAAFxxCS entry point must be   */         
                             /*   left-justified, blank-filled       */         
                             /*   with no decimal points             */         
#define apc_admit_dx_edit filler1[12]   /*  2 bytes */                          
#define apc_occur_codes filler1[14]/* 20 bytes; occurrence codes     */         
                             /*  up to 10 2 byte occurrence codes    */         
                             /*  left-justified, blank-filled        */         
#define nopps_bill_flag filler1[34]/* 1 byte; Non-OPPS bill type flag*/         
                             /* 0 N/A                                */         
                             /* 1 Bill type should be 83x            */         
                             /* 2 Bill type should not be 83x        */         
#define compadjflag filler1[35]/* 200 bytes; composite adjustmen flag*/         
                             /* 2 bytes per line item                */         
                             /* 00 no composite group assigned       */         
                             /* 01 first composite group on claim    */         
                             /* 02 second composite group on claim   */         
                             /* ...                                  */         
                             /* nn nth composite group on claim      */         
                             /* For FQHC PPS claims (bill type 77x)  */
                             /* only, the following values are       */
                             /* defined for composite adjustment flag*/
                             /* 01 FQHC medical clinic visit         */
                             /* 02 FQHC mental health clinic visit   */
                             /* 03 Subsequent FQHC clinic visit,     */
                             /*    medical or mental health (modifier*/
                             /*    59 reported)                      */
#define code_type_indic filler1[235]/* ICD code type, 1 byte         */         
                             /* 0 ICD-10 diagnosis codes             */         
                             /* 9 ICD-9  diagnosis codes             */         
                             /* else code type based on from date    */         
#define condition_codes_11 filler1[236]/* up to 11 condition codes   */         
                             /* 22 bytes                             */         
                             /* for 7 or less condition codes use    */
                             /* either field apc_condition_codes     */
                             /* or condition_codes_11                */
                             /* for 8 to 11 condition codes use      */
                             /* field condition_codes_11             */
                                                                                
                             /* Reason for Visit Diagnoses (RVDXs)   */         
                             /* 8 bytes, may be left blank           */         
                             /*   left or right-justified            */         
                             /*   blank-filled                       */         
                             /*   Decimal Points are Optional        */         
                             /*   for HAAFxxCS entry point must be   */         
                             /*   left-justified, blank-filled       */         
                             /*   with no decimal points             */         
                             /* for 1 RVDX use either field          */         
                             /*   apc_admit_dx or rvdx1              */         
                             /* for 2 or 3 RVDXs use RVDX fields     */         
#define rvdx1 filler1[258]   /* first  reason for visit diagnosis    */         
#define rvdx2 filler1[266]   /* second reason for visit diagnosis    */         
#define rvdx3 filler1[274]   /* third  reason for visit diagnosis    */         
                                                                                
                             /* RVDX edits, 2 bytes                  */         
#define rvdx1_edit filler1[282]/* edit for RVDX1                     */         
#define rvdx2_edit filler1[284]/* edit for RVDX2                     */         
#define rvdx3_edit filler1[286]/* edit for RVDX3                     */
#define value_codes filler1[288] /* 110 bytes (ValueCodes[10])       */
                                 /* 2 char value code (QN - QW)      */
                                 /* 9 char amount nnnnnnn.nn         */
                                 /*   (assumed decimal place)        */
};                                                                              
 typedef struct Haagrp_Data Haagrp_Data, far *HaagrpDataPtr;                    
                                                                                
                                                                                
/*                                                                              
   The following are some of the error codes that can be returned by            
   the HADGRP01 entry point.  The ASCII character form of this return           
   value is placed in drg_return_code (3 chars).  These are provided            
   here as #defines for convenience only.  This is not a complete list.         
   Text for any return error is found in drg_return_code_msg and a              
   complete table of messages is in hadgrp.ini                                  
*/                                                                              
                                                                                
#define DRG_ERR_REQ_FUNCTION   999  /* Invalid function request         */      
#define DRG_ERR_DATE_INVALID   998  /* Date format not recognized       */      
#define DRG_ERR_NO_GROUPER     997  /* No Grouper for these dates       */      
#define DRG_ERR_NO_NUMBER      996  /* No numeric data found            */      
#define DRG_ERR_MISSING_DATE   995  /* Required date not present        */      
#define DRG_ERR_NO_DATA        994  /* Input data not found             */      
#define DRG_ERR_DATA           993  /* Data could not be interpreted    */      
#define DRG_ERR_NOT_NUM        992  /* Edit field not numeric value     */      
#define DRG_ERR_GROUPER_FIND   991  /* Named Grouper not found          */      
#define DRG_ERR_GROUPER_LOAD   990  /* Named Grouper not loaded         */      
#define DRG_ERR_DX_REQ         989  /* Diagnosis code required          */      
#define DRG_ERR_SG_REQ         988  /* Procedure code required          */      
#define DRG_MEM_ALLOC          987  /* Alloc for wk structures failed   */      
                                    /* Following codes are also         */      
                                    /* represented by values in      */         
                                    /* drg_rtc after grouper calls:     */      
#define DRG_ERR_DX_24            1  /* '1' =  INVALID PRINCIPAL DX      */      
                                    /* IF MDC 24, PRINCIPAL DX IS       */      
                                    /* A VALID ICD9-CM-CODE             */      
#define DRG_ERR_DX_0             1  /* IF MDC 0, PRINCIPAL DX IS NOT    */      
                                    /* A VALID PRINCIPAL DX ('ENNN')    */      
                                    /* BUT IS VALID ICD9-CM-CODE        */      
#define DRG_ERR_DX_MDC           1                                              
#define DRG_ERR_DX_PRIN          2  /* '2' =  RECORD DOES NOT MEET      */      
                                    /*        CRITERIA FOR ANY DRG      */      
                                    /*  IN MDC AS INDICATED             */      
                                    /*        BY PRINCIPAL DX           */      
#define DRG_ERR_AGE              3  /* '3' = AGE (NOT 001-124)          */      
                                    /*       ONLY CHECKED IF DRG        */      
                                    /*    NEEDS AGE      */                     
#define DRG_ERR_AAGE            42  /* APDRG age at admit */                    
#define DRG_ERR_DAGE            43  /* APDRG age at discharge */                
#define DRG_ERR_SEX              4  /* '4' = SEX (NOT 1 OR 2)           */      
                                    /*       ONLY CHECKED IF DRG        */      
                                    /* NEEDS SEX TO GROUP               */      
#define DRG_ERR_DSTAT            5  /* '5' = INVALID DISCHARGE STAT     */      
                                    /*       ONLY CHECKED IF NEEDED     */      
                                    /* FOR GROUPING                     */      
#define DRG_ERR_DX               6  /* '6' = NO DIAGNOSIS PASSED        */      
                                    /*                                  */      
#define DRG_ERR_PRIN_DX          7  /* '7' = INVALID PRIN. DIAGNOSIS    */      
                                    /*                                  */      
#define DRG_ERR_UNUSED_8         8  /* '8' UNUSED BY THIS GROUPER       */      
                                    /*                                  */      
#define DRG_ERR_UNUSED_9         9  /* '9' UNUSED BY THIS GROUPER       */      
                                                                                
/* MS DRG POA logic indicator or POA indicator errors */                        
#define DRG_ERR_INV_POA_09       9  /* MS DRG versions 26 & 27          */      
                                    /* POA processing but HAC codes     */      
                                    /* have missing or invalid POA      */      
                                    /* indicators                       */      
                                    /* MS DRG versions 28+              */      
                                    /* POA processing but HAC codes     */      
                                    /* have missing, invalid or '1'     */      
                                    /* POA indicators                   */      
#define DRG_ERR_INV_POA_10      10  /* MS DRG versions 26+              */      
                                    /* Invalid POA logic indicator with */      
                                    /* HAC codes having only POA        */      
                                    /* indicators of N and/or U         */      
#define DRG_ERR_INV_POA_11      11  /* MS DRG versions 26 & 27          */      
                                    /* Invalid POA logic indicator with */      
                                    /* HAC codes having only missing or */      
                                    /* invalid POA indicators           */      
                                    /* MS DRG versions 28+              */      
                                    /* Invalid POA logic indicator with */      
                                    /* HAC codes having only missing,   */      
                                    /* invalid or '1' POA indicators    */      
#define DRG_ERR_INV_POA_12      12  /* MS DRG versions 26 & 27          */      
                                    /* POA processing but HAC codes     */      
                                    /* have POA indicators of 1         */      
#define DRG_ERR_INV_POA_13      13  /* MS DRG versions 26 & 27          */      
                                    /* Invalid POA logic indicator with */      
                                    /* HAC codes having POA indicators  */      
                                    /* of 1                             */      
#define DRG_ERR_INV_POA_14      14  /* MS DRG versions 26 & 27          */      
                                    /* POA processing but HAC codes     */      
                                    /* have mixture of missing or       */      
                                    /* invalid POA indicators and POA   */      
                                    /* indicators of 1                  */      
#define DRG_ERR_INV_POA_15      15  /* MS DRG versions 26 & 27          */      
                                    /* Invalid POA logic indicator with */      
                                    /* HAC codes having a mixture of    */      
                                    /* missing or invalid POA           */      
                                    /* indicators and POA indicators of */      
                                    /* 1, N and/or U                    */      
                                    /* MS DRG versions 28+              */      
                                    /* Invalid POA logic indicator with */      
                                    /* HAC codes having a mixture of    */      
                                    /* missing, invalid or '1' POA      */      
                                    /* indicators and POA indicators of */      
                                    /* N and/or U                       */      
#define DRG_ICD_MISMATCH        16  /* Cannot group an ICD-9 claim with */      
                                    /* an ICD-10 grouper                */      
#define DRG_ICD10DX_CW_FAILED   17  /* ICD-10 diagnoses crosswalked     */      
                                    /* to >50 ICD-9 DXs                 */      
#define DRG_ICD10PR_CW_FAILED   18  /* ICD-10 procedures crosswalked    */      
                                    /* to >50 ICD-9 procedures          */
#define DRG_APR_INV_HAC_VERS    19  /* HAC Version invalid (needed for  */
                                    /* HAC processing)                  */
#define DRG_APR_INV_AGENCY      20  /* Agency Indicator invalid (needed */
                                    /* for HAC processing)              */
#define DRG_APR_INV_DISCH_OPT   21  /* Discharge DRG option invalid     */
#define DRG_APR_HAC_INCONSIST   22  /* Inconsistency with Disch Date,   */
                                    /* HAC Vers, Agency Indicator       */
#define DRG_ICD10_PDX_NO_REMAP  23  /* No ICD-9 Mapping exists for this */ 
                                    /* ICD-10 Principal Diagnosis       */ 
                                                                                
                                    /*                                  */      
#define DRG_ERR_BW              44  /* APDRG Birth Weight Error */              
#define DRG_ERR_GEST_AGE_BW     46  /* APRDRG Gestational Age/Birth     */      
                                    /* Weight Conflict                  */      
#define DRG_ERR_GRP_X          976  /* 'X' = IRRECOVERABLE GROUPER      */      
                                    /* ERROR                            */      
                                    /*       GENERALLY - NOT ENOUGH     */      
                                    /*       MEMORY TO LOAD TABLES.     */      
                                                                                
#define DRG_ERR_TSW             41  /*  APDRG: 'A' =  BAD TSW APDRG*/           
#define DRG_ERR_GRP_A           41  /*  APDRG: Duplicate for compat */          
#define DRG_ERR_GRP_Z          975  /*  'Z' =  LICENSE AGREEMENT        */      
                                    /*  EXPIRED                         */      
#define DRG_ERR_RTC            974  /*  UNKNOWN RTC FROM GROUPER        */      
#define DRG_ERR_ID_VERSION     973  /*  sver must be 'GRP1'             */      
#define DRG_APR_INV_JRE        972  /* Incompatible JRE being used      */
#define DRG_ERR_REMAP_FILE     822  /* Remap file error                 */
#define DRG_ERR_NONE           000  /* NORMAL EXECUTION                 */      
                                                                                
                                    /* 05-28-98 Refined Grouper         */      
#define DRG_SRDRG_ERR_ADRGTBL  171  /* Internal DRG->ADRG table error   */      
#define DRG_SRDRG_ERR_LOS       10  /* Invalid LOS                      */      
#define DRG_SRDRG_ERR_BW        44  /* Use APDRG 044 err for birth weight*/     
                                                                                
#define DRG_VERSION_1 "GRP1"        /* for drg_sver initialization */           
#define DRG_VERSION_2 "GRP2"        /* for drg_sver initialization */           
#define DRG_VERSION_3 "GRP3"        /* for drg_sver initialization */           
                                                                                
enum                                                                            
{                                      /* drg_function                  */      
   DRG_FREE  = 'F',                    /* Free all allocated memory     */      
   DRG_GROUP = 'G',                    /* Perform automatic grouping    */      
   DRG_GROUPA = 'H',      /* Perform automatic grouping based on admit_date */  
   DRG_INIT  = 'I',                 /* Initialize parameter areas    */         
   DRG_NAME  = 'N'                     /* Return name of grouper to call   */   
};                                                                              
                                                                                
enum                                                                            
{                                      /* drg_func_opt_date_format      */      
   DRG_MMDDYY = '1',                   /* Date based on MD(C)Y order    */      
   DRG_DDMMYY = '2',                   /* Date based on DM(C)Y order    */      
   DRG_YYMMDD = '3',                   /* Date based on (C)YMD order    */      
   DRG_YYDDD = '4',                    /* Date based on (C)YYDDD        */      
   DRG_HISTORICAL = 'H',               /* Historical remap functions    */      
   DRG_LOGICAL = 'L',                  /* Logical remap functions       */      
   DRG_MIXED = 'M',                    /* Mixed                         */      
   DRG_NO  = 'N',                      /* No                            */      
   DRG_NONE  = ' ',                    /* Space can also mean "No"      */      
   DRG_YES  = 'Y'                      /* Yes                           */      
};                                                                              
                                                                                
enum                                                                            
{                             /* for drg_pt_sex */                              
   DRG_MALE_OTHER = '1',                                                        
   DRG_FEMALE_OTHER = '2',                                                      
   DRG_FEMALE = 'F',                                                            
   DRG_MALE = 'M'                                                               
};                                                                              
                                                                                
/*                                                                              
   The following are some of the error codes that can be returned by            
   the HADGRP01 entry point.  The ASCII character form of this return           
   value is placed in drg_return_code (3 chars).  These are provided            
   here as #defines for convenience only.  This is not a complete list.         
   Text for any return error is found in drg_return_code_msg and a              
   complete table of messages is in hadgrp.ini                                  
*/                                                                              
                                                                                
/*                            twf 10-28-99                                      
   The following are some of the error codes that can be returned by            
   the HAAGRP01 entry point.  The ASCII character form of this return           
   value is placed in drg_return_code (3 chars).  These are provided            
   here as #defines for convenience only.  This is not a complete list.         
   Text for any return error is found in drg_return_code_msg and a              
   complete table of messages is in hadgrp.ini                                  
*/                                                                              
                                                                                
#define APC_ERR_REQ_FUNCTION   999  /* Invalid function request         */      
#define APC_ERR_DATE_INVALID   998  /* Date format not recognized       */      
#define APC_ERR_NO_GROUPER     997  /* No Grouper for these dates       */      
#define APC_ERR_NO_NUMBER      996  /* No numeric data found            */      
#define APC_ERR_MISSING_DATE   995  /* Required date not present        */      
#define APC_ERR_NO_DATA        994  /* Input data not found             */      
#define APC_ERR_DATA           993  /* Data could not be interpreted    */      
#define APC_ERR_NOT_NUM        992  /* Edit field not numeric value     */      
#define APC_ERR_GROUPER_FIND   991  /* Named Grouper not found          */      
#define APC_ERR_GROUPER_LOAD   990  /* Named Grouper not loaded         */      
#define APC_ERR_DX_REQ         989  /* Diagnosis code required          */      
#define APC_ERR_SG_REQ         988  /* Procedure code required          */      
#define APC_MEM_ALLOC          987  /* Alloc for wk structures failed   */      
#define APC_ERR_GRP_X          976  /* 'X' = IRRECOVERABLE GROUPER      */      
                                    /* ERROR                            */      
                                    /*       GENERALLY - NOT ENOUGH     */      
                                    /*       MEMORY TO LOAD TABLES.     */      
                                                                                
#define APC_ERR_GRP_Z          975  /*  'Z' =  LICENSE AGREEMENT        */      
                                    /*  EXPIRED                         */      
#define APC_ERR_RTC            974  /*  UNKNOWN RTC FROM GROUPER        */      
#define APC_ERR_ID_VERSION     973  /*  sver must be 'APC3'             */      
                                                                                
                                                                                
#define APC_OCEPOOL_ERROR      901  /* Allocated oce pool not large enough */   
#define APC_C1_T1_NF           910  /* Table t1 not found */ 

/* the following are no longer used with haaf17bc1 effective 04/01/16   */
#define X_APC_MEM_ALLOC        'A'  /* Alloc for wk structures failed   */      
#define X_APC_OCEPOOL_ERROR    'B'  /* Allocated oce pool not large enough */   
#define X_APC_ERR_GRP_X        'C'  /* 'X' = IRRECOVERABLE GROUPER      */      
#define X_APC_C1_T1_NF         'D'  /* Table t1 not found */                    
#define X_APC_ERR_NO_DATA      'P'  /* Input data not found             */      
#define X_APC_ERR_SG_REQ       'Q'  /* Procedure code required */               
#define X_APC_ERR_REQ_FUNCTION 'R'  /* Invalid function request */              
#define X_APC_SEVERE_ERROR     'Z'  /* error above this may stop run  */        
                                                                                
                                                                                
                                    /* Following codes are compatibility*/      
                                   /* items from DRG and APC      */            
#define APC_ERR_DX_24            1  /*  =  INVALID PRINCIPAL DX      */         
                                    /*  DRG code; conform to OCE01   */         
                                    /* A VALID ICD9-CM-CODE             */      
#define APC_ERR_DX_0             1  /* IF MDC 0, PRINCIPAL DX IS NOT    */      
                                    /* DRG Code, conform to OCE01       */      
                                    /* BUT IS VALID ICD9-CM-CODE        */      
#define APC_ERR_DX_MDC           1  /* DRG code, conform to OCE01 */            
#define APC_ERR_DX_PRIN          2  /* '2' =  RECORD DOES NOT MEET      */      
                                    /*        CRITERIA FOR ANY APC      */      
                                    /*  IN MDC AS INDICATED             */      
                                    /*        BY PRINCIPAL DX           */      
#define APC_ERR_AGE              25 /*  = AGE NOT 001-124)           */         
                                    /*       Match OCE25          */            
                                    /*    NEEDS AGE      */                     
#define APC_ERR_SEX              26 /*  = SEX (NOT 1 OR 2)           */         
                                    /*       Match OCE26          */            
                                    /* NEEDS SEX TO GROUP               */      
#define APC_ERR_DSTAT            0  /* was 5 = INVALID DISCHARGE STAT   */      
                                    /*       Not needed for OCE         */      
                                    /* FOR GROUPING                     */      
#define APC_ERR_DX               1  /*  = NO DIAGNOSIS PASSED        */         
                                    /* DRG Code, conform to OCE01       */      
#define APC_ERR_PRIN_DX          1  /*  Err IN. DIAGNOSIS   */                  
                                    /* DRG Code, conform to OCE01       */      
#define APC_ERR_UNUSED_8         8  /* '8' UNUSED BY THIS GROUPER       */      
                                    /*                                  */      
#define APC_ERR_UNUSED_9         9  /* '9' UNUSED BY THIS GROUPER       */      
                                                                                
#define APC_ERR_NONE           000  /* NORMAL EXECUTION                 */      
                                                                                
                                                                                
/*  Some OCE/APC edit codes - moved here from haagrp.h 08-24-00 */              
                                                                                
#define APC_EDIT_INVALID_DG  01                                                 
#define APC_EDIT_DG_AGE_CONFLICT 02                                             
#define APC_EDIT_DG_SEX_CONFLICT 03                                             
#define APC_EDIT_ECODE_AS_REASON 05                                             
#define APC_EDIT_INVALID_SG 06                                                  
#define APC_EDIT_SG_AGE_CONFLICY 07                                             
#define APC_EDIT_SG_SEX_CONFLICT 08                                             
#define APC_EDIT_NON_COVERED 09                                                 
#define APC_EDIT_NON_COVERED_21 10                                              
#define APC_EDIT_NON_COVERED_20 11                                              
#define APC_EDIT_NON_COVERED_QUESTIONABLE 12                                    
#define APC_EDIT_SNP 13               /* Service Not Paid */                    
#define APC_EDIT_SNP_OPPS 14                                                    
#define APC_EDIT_SU_OUT_OF_RANGE 15   /* Service Unit */                        
                                                                                
                                                                                
/* the following are reported by HPCSEXIT calls in bal code */                  
/* these codes are mapped upwards from BAL series by adding xxx */              
                                                                                
#define OCE_DATE_ERROR13        233 /* invalid from date, this is reported*/    
                                    /* as 23 in claimretbuf->clmreturn */       
#define OCE_DATE_ERROR14        234 /* invalid to date, this is reported*/      
                                    /* as 23 in claimretbuf->clmreturn */       
#define OCE_DATE_ERROR15        235 /* from date > through date this is */      
                                    /* reported as 23 in */                     
                                    /* claimretbuf->clmreturn */                
#define OCE_DATE_ERROR16        236 /* line item date not in from,to range */   
                                    /* this is reported as 23 in */             
                                    /* claimretbuf->clmreturn */                
#define OCE_DATE_ERROR17        237 /* date out of OCE version range, */        
                                    /* this is reported as 23 in */             
                                    /* claimretbuf->clmreturn */                
#define OCE_PBT_ERROR18         238 /* invalid bill type */                     
                                    /* comes from pbtcontrol processing */      
#define OCE_CC21_ERROR20        240 /* claim includes condition code 21 */      
#define OCE_PBT_ERROR22         242 /* invalid bill type */                     
                                                                                
#define X_OCE_DATE_ERROR13      'E' /* invalid from date, this is reported*/    
                                    /* as 23 in claimretbuf->clmreturn */       
#define X_OCE_DATE_ERROR14      'F' /* invalid to date, this is reported*/      
                                    /* as 23 in claimretbuf->clmreturn */       
#define X_OCE_DATE_ERROR15      'G' /* from date > through date this is */      
                                    /* reported as 23 in */                     
                                    /* claimretbuf->clmreturn */                
#define X_OCE_DATE_ERROR16      'H' /* line item date not in from,to range */   
                                    /* this is reported as 23 in */             
                                    /* claimretbuf->clmreturn */                
#define X_OCE_DATE_ERROR17      'I' /* date out of OCE version range, */        
                                    /* this is reported as 23 in */             
                                    /* claimretbuf->clmreturn */                
#define X_OCE_PBT_ERROR18       'J' /* invalid bill type */                     
                                    /* comes from pbtcontrol processing */      
#define X_OCE_CC21_ERROR20      'L' /* claim includes condition code 21 */      
#define X_OCE_PBT_ERROR22       'N' /* invalid bill type */                     
                                    /*                                  */      
                                                                                
#define APC_SEVERE_ERROR 499        /* error above this may stop run  */        
                                                                                
                                                                                
#define APC_VERSION_1 "APC3"        /* for apc_sver initialization */           
                                                                                
enum                                                                            
{                                      /* drg_function                  */      
   APC_FREE  = 'F',                    /* Free all allocated memory     */      
   APC_GROUP = 'G',                    /* Perform automatic grouping    */      
   APC_INIT  = 'I',                    /* Initialize parameter areas    */      
   APC_NAME  = 'N'                     /* Return name of grouper to call   */   
};                                                                              
                                                                                
enum                                                                            
{                                      /* drg_func_opt_date_format      */      
   APC_MMDDYY = '1',                   /* Date based on MD(C)Y order    */      
   APC_DDMMYY = '2',                   /* Date based on DM(C)Y order    */      
   APC_YYMMDD = '3',                   /* Date based on (C)YMD order    */      
   APC_YYDDD = '4',                     /* Date based on (C)YYDDD       */      
   APC_TO_GROUPER = '5',   /* used by haagpc.c, looks like ccyymmdd */          
   APC_HISTORICAL = 'H',               /* Historical remap functions    */      
   APC_LOGICAL = 'L',                  /* Logical remap functions       */      
   APC_MIXED = 'M',                    /* Mixed                         */      
   APC_NO  = 'N',                      /* No                            */      
   APC_NONE  = ' ',                    /* Space can also mean "No"      */      
   APC_YES  = 'Y'                      /* Yes                           */      
};                                                                              
                                                                                
enum                                                                            
{                             /* for apc_pt_sex */                              
   APC_MALE_OTHER = '1',                                                        
   APC_FEMALE_OTHER = '2',                                                      
   APC_FEMALE = 'F',                                                            
   APC_MALE = 'M'                                                               
};                                                                              
                                                                                
/* hadrmp.h
 *                                                                              
 *  This defines the calling structure and entry point for the                  
 *  IRP re-mapping routine.                                                     
 *                                                                              
 *  ---->  This is duplicated in hadgrpcp.h    to reduce the number             
 *                                             of included headers              
 *                                                                              
 */                                                                             
                                                                                
                                                                                
struct hadrmp_struct                                                            
{                                                                               
   char op; /* 'R' : remap, 'S' : statistical remap, 'F' : free tables */       
   char codetype; /* 'D', 'P', 'C', etc. */                                     
   char code[8]; /* code to remap */                                            
   char originperiod[10]; /* not used */                                        
   char grouper[8]; /* name of grouper to remap to */                           
   char remappedcode[8]; /* will hold remapped code on return */                
   char retmsg[79]; /* will hold a return message on return */                  
};                                                                              
                                                                                
IRPEXTERNC int HADRMP(struct hadrmp_struct *args);                              
IRPEXTERNC int HADRMP10(struct hadrmp_struct *args);                              
IRPEXTERNC short mapdx10to9(char *dx10, char *remap_version, int *n,            
                            char *dx9_1, char *dx9_2, char *dx9_3,              
                            char *dx9_4, char *dx9_5, char *dx9_6);             
IRPEXTERNC void mappr10to9(char *pr10, char *remap_version, int *n,             
                           char *pr9_1, char *pr9_2, char *pr9_3,               
                           char *pr9_4, char *pr9_5, char *pr9_6);              
                                                                                
IRPEXTERNC int IRPstrcmpi(const char *string1, const char *string2); /* twf */  
IRPEXTERNC int num2string(int num, char *string, int length);                   
IRPEXTERNC char *IRPstrupr(char *string);                                       
IRPEXTERNC int string2num(char *string);                                        
IRPEXTERNC int IRPstrspn(const char *string1, const char *string2);             
IRPEXTERNC int locinifile(char *inifilename, char *inifilepath);                
IRPEXTERNC void cobmove(char *dest,int dleft,int dright,                        
                        char *src,int sleft,int sright);                        
IRPEXTERNC void cvt_long_char(long in_val, char FAR * out_char, short out_len); 
#if defined(IBMAS400) || defined(DECOVMS)                                       
IRPEXTERNC int IRPACCESS(char *fname, int fmode);                               
#endif                                                                          
                                                                                
                                                                                
#if ! defined(GRPGEN)                                                           
                                                                                
/* ********************************************************************         
 *  The rest of this .h member is not needed when compiling the                 
 *  actual grouper haxxxxc1.c modules because it consists of the                
 *  definitions of all the entry points for all the groupers.                   
 *                                                                              
 *  This is needed by programs that CALL any grouper.                           
 * ********************************************************************         
 */                                                                             
                                                                                
                                                                                
/* **********************************************************************       
                                                                                
       input functions and prototypes for low-level grouper calls               
                                                                                
 * ********************************************************************* */     
                                                                                
#define FN_GROUP        0                                                       
#define FN_FREE         1                                                       
#define FN_FREE_ALL     1  /* no longer used - was 2 */                         
                                                                                
                                                                                
/*  These are generic forms for the external grouper call using a               
 *  procedure pointer - verify that argument field sizes are proper             
 *  for the grouper being used!!                                                
 */                                                                             
                                                                                
#if defined(PCWIN)                                                              
 typedef    short PASCAL FAR (PASCAL FAR *GroupRtn)                             
#elif defined(PCOS2DLL) || defined(PCOS2)                                       
 /* extern ? */                                                                 
 typedef    short __syscall (__syscall *GroupRtn)                               
#elif defined (PCWIN32)                                                         
 typedef    short (__stdcall *GroupRtn)                                         
#else                                                                           
 typedef    short (*GroupRtn)                                                   
#endif                                                                          
               /* Note that "far" is used below because "FAR"                   
                * generated near pointers to the parameters,                    
                * while "far" generate far pointers as was                      
                * necessary. (Borland compiler oddity?)                         
                */                                                              
(                                                                               
   short       grpfunc,                                                         
   short       vndx,             /* number dx (diagnoses)          */           
   short       vnsg,             /* number sg (procedures)         */           
   Dx_Code     far *dx_ptr,      /* array of 50 DX x 6 bytes ea    */           
   Sg_Code     far *sg_ptr,      /* array of 50 SG x 7 bytes ea    */           
   Drg_Age     far *vage,        /* age - 3 char                   */           
   char        far *vsex,        /* sex - 1 char                   */           
   Drg_Dstat   far *vdstat,      /* Numeric Discharge Status UB-04 */           
   Sg_Code     far *vdrg,        /* Returned DRG                   */           
   Dx_Code     far *vmdc,        /* Returned MDC                   */           
   Drg_Grret   far *vrtc,        /* Return code from grouper code  */           
   Sg_Code     far *vmajop,      /* First Operative Proc used      */           
   Dx_Code     far *vadx,        /* "Any Diagnosis" used           */           
   Dx_Code     far *vsdx,        /* "Secondary DX" used            */           
   Drg_Grvsn   far *vers,        /* Grouper Version ID             */           
   Sg_Code     far *vmajop2,     /* Second Operative Proc used     */           
   Sg_Code     far *vminop,      /* First Non-Operative Proc used  */           
   Sg_Code     far *vminop2,     /* Second Non-Operative Proc used */           
   Dx_Code     far *vdxcc,       /* First Valid CC Diagnosis       */           
   Sg_Code     far *vmajop3,     /* Third Operative Proc used      */           
   Drg_Grcctab far *vdxcctab     /* Flag Array of All Valid CCDX   */           
);                                                                              
                                                                                
                                                                                
#if defined(PCWIN)                                                              
 typedef    short PASCAL FAR (PASCAL FAR *GroupRtnStrucIF)                      
#elif defined(PCOS2DLL) || defined(PCOS2)                                       
 /* extern ? */                                                                 
 typedef    short __syscall (__syscall *GroupRtnStrucIF)                        
#elif defined (PCWIN32)                                                         
#if defined(MS6COMPILER)                                                        
/* typedef   short  (__declspec( dllimport ) *GroupRtnStrucIF) (I cannot get    
   this to work, although it should) */                                         
/* typedef   short  (__stdcall *GroupRtnStrucIF) (this will compile             
               and link and then blow up at run time */                         
 typedef   short  (*GroupRtnStrucIF) /* according to the documentation for      
                                      * declspec( dllimport ), this             
                                      * will generate inefficient call          
                                      * to dll, but it works                    
                                      */                                        
#else                                                                           
 typedef   short  (IRPEXTCALL *GroupRtnStrucIF)                                 
#endif                                                                          
#else                                                                           
 typedef    short (*GroupRtnStrucIF)                                            
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
                                                                                
#if defined(PCWIN)                                                              
 typedef    short PASCAL FAR (PASCAL FAR *GroupRtnStruc2IF)                     
#elif defined(PCOS2DLL) || defined(PCOS2)                                       
 /* extern ? */                                                                 
 typedef    short __syscall (__syscall *GroupRtnStruc2IF)                       
#elif defined (PCWIN32)                                                         
#if defined(MS6COMPILER)                                                        
/* typedef   short  (__declspec( dllimport ) *GroupRtnStrucIF) (I cannot get    
   this to work, although it should) */                                         
/* typedef   short  (__stdcall *GroupRtnStrucIF) (this will compile             
               and link and then blow up at run time */                         
 typedef   short  (*GroupRtnStruc2IF) /* according to the documentation for     
                                      * declspec( dllimport ), this             
                                      * will generate inefficient call          
                                      * to dll, but it works                    
                                      */                                        
#else                                                                           
 typedef   short  (IRPEXTCALL *GroupRtnStruc2IF)                                
#endif                                                                          
#else                                                                           
 typedef    short (*GroupRtnStruc2IF)                                           
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp2_Data *hgp);                                                    
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADGRP01                                            
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
IRPEXTERNC short IRPEXTCALL HADGRP01                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADGRP01                                            
#else                                                                           
#ifdef _cplusplus                                                               
extern "C" short HADGRP01                                                       
#else                                                                           
short IRPEXTCALL HADGRP01                                                       
#endif                                                                          
#endif                                                                          
     (Hadgrp_Data *hgp);                                                        
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADGRP02                                            
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
IRPEXTERNC short IRPEXTCALL HADGRP02                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADGRP02                                            
#else                                                                           
#ifdef _cplusplus                                                               
extern "C" short HADGRP02                                                       
#else                                                                           
short IRPEXTCALL HADGRP02                                                       
#endif                                                                          
#endif                                                                          
     (Hadgrp2_Data *hgp);                                                       
                                                                                
                                                                                
#if defined(PCWIN)                                                              
typedef short FAR PASCAL (*Grouper_Routine)                                     
#elif defined(PCOS2DLL) || defined(PCOS2)                                       
 /* extern ? */                                                                 
typedef short __syscall  (*Grouper_Routine)                                     
#elif defined(PCWIN32)                                                          
#if defined(MS6COMPILER)                                                        
typedef short (*Grouper_Routine)                                                
#else                                                                           
typedef short (__stdcall *Grouper_Routine)                                      
#endif                                                                          
#else                                                                           
typedef short  (*Grouper_Routine)                                               
#endif                                                                          
   (                             /* ------Federal Grouper  x.0---- */           
                                 /* -------- input arguments ----- */           
      short grpfunc,             /* grouper function:                           
                                  *   0 = group,                                
                                  *   1 = free this groupers storage            
                                  *   2 = free all groupers storage             
                                  */                                            
      short vndx,                /* number dx (diagnoses)  50 MAX  */           
      short vnsg,                /* number sg (procedures) 50 MAX  */           
      char  far *vdx_ptr,        /* to array of 50 DX x 5 bytes ea */           
      char  far *vsg_ptr,        /* to array of 50 SG x 4 bytes ea */           
      char  far *vage,           /* age - 3 char                   */           
      char  far *vsex,           /* sex - 1 char 1,m or 2,f        */           
      char  far *vdstat,         /* UB92 discharge stat 2 char     */           
                                 /* ------  output arguments ----- */           
      char  far *vdrg,           /* assigned DRG 3 char            */           
      char  far *vmdc,           /* assigned MDC 2 char            */           
      char  far *vrtc,           /* return code  1 char            */           
      char  far *vmajop,         /* 1st significant SG  4 bytes    */           
      char  far *vadx,           /* 1st significant DX  5 bytes    */           
      char  far *vsdx,           /* 2nd significant DX  5 bytes    */           
      char  far *vers,           /* grouper version 11 bytes       */           
      char  far *vmajop2,        /* 2nd significant SG  4 bytes    */           
      char  far *vminop,         /* 1st minor sign. SG  4 bytes    */           
      char  far *vminop2,        /* 2nd minor sign. SG  4 bytes    */           
      char  far *vdxcc,          /* CC DX               5 bytes    */           
      char  far *vmajop3,        /* 3rd significant SG  4 bytes    */           
      char  far *vdxcctab        /* array of 50 char - one for each             
                                  * input DX.  set to 'Y' (upper                
                                  * case Y) if corresponding DX is              
                                  * a valid CC for this Prinicipal              
                                  * DX.                                         
                                  */                                            
   );                                                                           
                                                                                
                                                                                
/* This function prototype is for version 6 which does not have a               
   'majop3' argument */                                                         
                                                                                
#if defined(PCWIN)                                                              
typedef short FAR PASCAL (*Grouper6_Routine)                                    
#elif defined(PCOS2DLL) || defined(PCOS2)                                       
 /* extern ? */                                                                 
typedef short __syscall  (*Grouper6_Routine)                                    
#elif defined(PCWIN32)                                                          
#if defined(MS6COMPILER)                                                        
typedef short (*Grouper6_Routine)                                               
#else                                                                           
typedef short (__stdcall *Grouper6_Routine)                                     
#endif                                                                          
#else                                                                           
typedef short  (*Grouper6_Routine)                                              
#endif                                                                          
   (                             /* ------Federal Grouper  6.0---- */           
                                 /* -------- input arguments ----- */           
      short grpfunc,             /* grouper function:                           
                                  *   0 = group,                                
                                  *   1 = free this groupers storage            
                                  *   2 = free all groupers storage             
                                  */                                            
      short vndx,                /* number dx (diagnoses)  50 MAX  */           
      short vnsg,                /* number sg (procedures) 50 MAX  */           
      char  far *vdx_ptr,        /* to array of 50 DX x 5 bytes ea */           
      char  far *vsg_ptr,        /* to array of 50 SG x 4 bytes ea */           
      char  far *vage,           /* age - 3 char                   */           
      char  far *vsex,           /* sex - 1 char 1,m or 2,f        */           
      char  far *vdstat,         /* UB92 discharge stat 2 char     */           
                                 /* ------  output arguments ----- */           
      char  far *vdrg,           /* assigned DRG 3 char            */           
      char  far *vmdc,           /* assigned MDC 2 char            */           
      char  far *vrtc,           /* return code  1 char            */           
      char  far *vmajop,         /* 1st significant SG  4 bytes    */           
      char  far *vadx,           /* 1st significant DX  5 bytes    */           
      char  far *vsdx,           /* 2nd significant DX  5 bytes    */           
      char  far *vers,           /* grouper version 11 bytes       */           
      char  far *vmajop2,        /* 2nd significant SG  4 bytes    */           
      char  far *vminop,         /* 1st minor sign. SG  4 bytes    */           
      char  far *vminop2,        /* 2nd minor sign. SG  4 bytes    */           
      char  far *vdxcc,          /* CC DX               5 bytes    */           
/*    char  far *vmajop3,*/        /* 3rd significant SG  4 bytes    */         
      char  far *vdxcctab        /* array of 50 char - one for each             
                                  * input DX.  set to 'Y' (upper                
                                  * case Y) if corresponding DX is              
                                  * a valid CC for this Prinicipal              
                                  * DX.                                         
                                  */                                            
   );                                                                           
                                                                                
#if defined(PCWIN)                                                              
typedef void FAR PASCAL  (*Grouper_Routine_MVS)                                 
#elif defined(PCOS2DLL) || defined(PCOS2)                                       
 /* extern ? */                                                                 
typedef void __syscall  (*Grouper_Routine_MVS)                                  
#elif defined (PCWIN32)                                                         
typedef void (__stdcall *Grouper_Routine_MVS)                                   
#else                                                                           
typedef void (*Grouper_Routine_MVS)                                             
#endif                                                                          
   (                              /* ------Federal Grouper  x.0---- */          
                                  /* -------- input arguments ----- */          
                                  /* ---HCFA MVS COMPATIBLE ENTRY-- */          
                                  /* ------------------------------ */          
      char far *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */          
      int  far *vndx,             /* number dx (diagnoses)  50 MAX  */          
      char far *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */          
      int  far *vnsg,             /* number sg (procedures) 50 MAX  */          
      char far *vage,             /* age - 3 char                   */          
      char far *vsex,             /* sex - 1 char 1,m or 2,f        */          
      char far *vdstat,           /* UB92 discharge stat 2 char     */          
                                  /* ------  output arguments ----- */          
      char far *vdrg,             /* assigned DRG 3 char            */          
      char far *vmdc,             /* assigned MDC 2 char            */          
      char far *vrtc,             /* return code  1 char            */          
      char far *vmajop,           /* 1st significant SG  4 bytes    */          
      char far *vadx,             /* 1st significant DX  5 bytes    */          
      char far *vsdx,             /* 2nd significant DX  5 bytes    */          
      char far *vers,             /* grouper version 11 bytes       */          
      char far *vmajop2,          /* 2nd significant SG  4 bytes    */          
      char far *vminop,           /* 1st minor sign. SG  4 bytes    */          
      char far *vminop2,          /* 2nd minor sign. SG  4 bytes    */          
      char far *vdxcc,            /* CC DX               5 bytes    */          
      char far *vmajop3           /* 3rd significant SG  4 bytes    */          
   );                                                                           
                                                                                
                                                                                
                                                                                
/*  Generic Refined DRG Grouper Calls       */                                  
                                                                                
                                                                                
#if defined(PCWIN)                                                              
typedef short FAR PASCAL (*Ref_Grouper_Routine)                                 
#elif defined(PCOS2DLL) || defined(PCOS2)                                       
 /* extern ? */                                                                 
typedef short __syscall  (*Ref_Grouper_Routine)                                 
#elif defined(PCWIN32)                                                          
#if defined(MS6COMPILER)                                                        
typedef short  (*Ref_Grouper_Routine)                                           
#else                                                                           
typedef short (__stdcall *Ref_Grouper_Routine)                                  
#endif                                                                          
#else                                                                           
typedef short  (*Ref_Grouper_Routine)                                           
#endif                                                                          
   (                             /* ------IRP Refined Grouper  x.0---- */       
                                 /* -------- input arguments ----- */           
      short grpfunc,             /* grouper function:                           
                                  *   0 = group,                                
                                  *   1 = free this groupers storage            
                                  *   2 = free all groupers storage             
                                  */                                            
      short vndx,                /* number dx (diagnoses)  50 MAX  */           
      short vnsg,                /* number sg (procedures) 50 MAX  */           
      char  far *vdx_ptr,        /* to array of 50 DX x 5 bytes ea */           
      char  far *vsg_ptr,        /* to array of 50 SG x 4 bytes ea */           
      char  far *vage,           /* age - 3 char                   */           
      char  far *vsex,           /* sex - 1 char 1,m or 2,f        */           
      char  far *vdstat,         /* UB92 discharge stat 2 char     */           
                              /* --addl RefGrp input arguments ----- */         
      char  far *vbwght,         /* Birth Weight grams, 4 char     */           
      char  far *vlos,           /* Length of Stay, days, 3 char   */           
                                 /* ------  output arguments ----- */           
      char  far *vdrg,           /* assigned HCFA DRG 3 char       */           
      char  far *vmdc,           /* assigned HCFA MDC 2 char       */           
      char  far *vrtc,           /* HCFA return code  1 char       */           
                                 /* will also contain refinement   */           
                                 /* error codes                    */           
      char  far *vmajop,         /* 1st significant SG  4 bytes    */           
      char  far *vadx,           /* 1st significant DX  5 bytes    */           
      char  far *vsdx,           /* 2nd significant DX  5 bytes    */           
      char  far *vers,           /* grouper version 11 bytes       */           
      char  far *vmajop2,        /* 2nd significant SG  4 bytes    */           
      char  far *vminop,         /* 1st minor sign. SG  4 bytes    */           
      char  far *vminop2,        /* 2nd minor sign. SG  4 bytes    */           
      char  far *vdxcc,          /* CC DX               5 bytes    */           
                                 /* Refinement MDX                 */           
      char  far *vmajop3,        /* 3rd significant SG  4 bytes    */           
                              /* --addl RefGrp output arguments ----- */        
      char  far *vrgn,           /* assigned Refined Group 4 char  */           
      char  far *vadg,           /* assigned Adjacent DRG  3 char  */           
      char  far *vmrg,           /* assigned Medical Refined Group 4 char  */   
      char  far *vped,           /* Refinement 'P' for age <18     */           
                              /* ----IRP added output grp arguments ----- */    
      char  far *vdxcctab        /* array of 50 char - one for each             
                                  * input DX.  set to 0,1,2,3                   
                                  * for corresponding DX refined class          
                                  * a valid CC for this Prinicipal              
                                  * DX.  Blank if not a valid Ref CC.           
                                  */                                            
   );                                                                           
                                                                                
#if defined(PCWIN)                                                              
typedef void FAR PASCAL  (*Ref_Grouper_Routine_MVS)                             
#elif defined(PCOS2DLL) || defined(PCOS2)                                       
 /* extern ? */                                                                 
typedef void __syscall  (*Ref_Grouper_Routine_MVS)                              
#elif defined (PCWIN32)                                                         
typedef void (__stdcall *Ref_Grouper_Routine_MVS)                               
#else                                                                           
typedef void (*Ref_Grouper_Routine_MVS)                                         
#endif                                                                          
   (                              /* ------IRP Refined Grouper  x.0---- */      
                                  /* -------- input arguments ----- */          
                                  /* ---HCFA MVS COMPATIBLE ENTRY-- */          
                                  /* ------------------------------ */          
      char far *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */          
      int  far *vndx,             /* number dx (diagnoses)  50 MAX  */          
      char far *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */          
      int  far *vnsg,             /* number sg (procedures) 50 MAX  */          
      char far *vage,             /* age - 3 char                   */          
      char far *vsex,             /* sex - 1 char 1,m or 2,f        */          
      char far *vdstat,           /* UB92 discharge stat 2 char     */          
                              /* --addl RefGrp input arguments ----- */         
      char  far *vbwght,         /* Birth Weight grams, 4 char     */           
      char  far *vlos,           /* Length of Stay, days, 3 char   */           
                                  /* ------  output arguments ----- */          
      char far *vdrg,             /* assigned DRG 3 char            */          
      char far *vmdc,             /* assigned MDC 2 char            */          
      char far *vrtc,             /* return code  1 char            */          
                                  /* will also contain refinement   */          
                                  /* error codes                    */          
      char far *vmajop,           /* 1st significant SG  4 bytes    */          
      char far *vadx,             /* 1st significant DX  5 bytes    */          
      char far *vsdx,             /* 2nd significant DX  5 bytes    */          
      char far *vers,             /* grouper version 11 bytes       */          
      char far *vmajop2,          /* 2nd significant SG  4 bytes    */          
      char far *vminop,           /* 1st minor sign. SG  4 bytes    */          
      char far *vminop2,          /* 2nd minor sign. SG  4 bytes    */          
      char far *vdxcc,            /* CC DX               5 bytes    */          
                                  /* Refinement MDX                 */          
      char far *vmajop3,          /* 3rd significant SG  4 bytes    */          
                              /* --addl RefGrp output arguments ----- */        
      char  far *vrgn,           /* assigned Refined Group 4 char  */           
      char  far *vadg,           /* assigned Adjacent DRG  3 char  */           
      char  far *vmrg,           /* assigned Medical Refined Group 4 char  */   
      char  far *vped            /* Refinement 'P' for age <18     */           
   );                                                                           
                                                                                
                                                                                
                                                                                
                                                                                
/*  Generic APC Grouper Calls       */                                          
                                                                                
#if defined(PCWIN)                                                              
 typedef    short PASCAL FAR (PASCAL FAR *APCRtn450IF)                          
#elif defined(PCOS2DLL) || defined(PCOS2)                                       
 /* extern ? */                                                                 
 typedef    short __syscall (__syscall *APCRtn450IF)                            
#elif defined (PCWIN32)                                                         
typedef short (__stdcall *APCRtn450IF)                                          
#else                                                                           
 typedef    short (*APCRtn450IF)                                                
#endif                                                                          
                               /* 450 line item entry point */                  
 (char  FAR *lvdx_ptr,    /* 02 */ /* to array of 15 DX x 6 bytes ea */         
  char  FAR *lvndx,       /* 03 */ /* act nbr dx (diagnoses) 15 MAX  */         
  char  FAR *lineitems,   /* 05 */ /* line items                     */         
  char  FAR *vlineitems,           /* act nbr line items 450 MAX     */         
  char  FAR *laction,              /* line item action flags         */         
  char  FAR *age,                  /* age in years                   */         
  char  FAR *sex,                                                               
  char  FAR *fromtodates,          /* from - to dates                */         
  char  FAR *ccodes,               /* condition codes                */         
  char  FAR *vccodes,              /* number of conditon codes       */         
  char  FAR *billtype,                                                          
  char  FAR *npinumber,                                                         
  char  FAR *oscar,                                                             
  char  FAR *pstatptr,                                                          
  char  FAR *oppsptr,                                                           
  char  FAR *occptr,               /* [5a] 2 byte occurrence code    */         
  char  FAR *noccptr,              /* [5a] max # of occurrence codes */         
  char  FAR *dxeditbuf,            /* dx edit return buffer          */         
  char  FAR *sgeditbuf,            /* sg edit return buffer          */         
  char  FAR *modeditbuf,           /* modifier edit return buffer    */         
  char  FAR *dteditbuf,            /* date edit return buffer        */         
  char  FAR *reveditbuf,           /* revenue edit return buffer     */         
  char  FAR *apceditbuf,           /* apc edit return buffer         */         
  char  FAR *clmeditbuf,           /* claim edit return buffer       */         
  char  FAR *workbuf,              /* work area                      */         
  char  FAR *workbufsize           /* work area size                 */         
 );                                                                             
                                                                                
#if defined(PCWIN)                                                              
 typedef    short PASCAL FAR (PASCAL FAR *OPSCALRtnStrucIF)                     
#elif defined(PCOS2DLL) || defined(PCOS2)                                       
 /* extern ? */                                                                 
 typedef    short __syscall (__syscall *OPSCALRtnStrucIF)                       
#elif defined (PCWIN32)                                                         
typedef short (__stdcall *OPSCALRtnStrucIF)                                     
#else                                                                           
 typedef    short (*OPSCALRtnStrucIF)                                           
#endif                                                                          
        (char *count,         /* line items */                                  
         char *data,          /* APC_return structure */                        
         char *additional,    /* A_ADDITIONAL_VARIABLES */                      
         char *spec_area,     /* L_PROV_SPEC_AREA */                            
         char *from_dt,       /* ccyymmdd */                                    
         char *deduct,        /* PIC 9(03)V9(02) */                             
         char *in_date        /* OCE_IN_DATE */                                 
        );                                                                      
                                                                                
                                                                                
#if defined(PCWIN)                                                              
 typedef    short PASCAL FAR (PASCAL FAR *APCRtnStrucIF)                        
#elif defined(PCOS2DLL) || defined(PCOS2)                                       
 /* extern ? */                                                                 
 typedef    short __syscall (__syscall *APCRtnStrucIF)                          
#elif defined (PCWIN32)                                                         
#if defined(MS6COMPILER)                                                        
typedef short (*APCRtnStrucIF)                                                  
#else                                                                           
typedef short (__stdcall *APCRtnStrucIF)                                        
#endif                                                                          
#else                                                                           
 typedef    short (*APCRtnStrucIF)                                              
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Haagrp_Data *hagp);                                                    
                                                                                
                                                                                
                    /* Same as above, but use entry point name */               
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HAAGRP01                                            
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
IRPEXTERNC short IRPEXTCALL HAAGRP01                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HAAGRP01                                            
#else                                                                           
short IRPEXTCALL HAAGRP01                                                       
#endif                                                                          
     (Haagrp_Data *hagp);                                                       
                                                                                
                                                                                
/*                                                                              
  Entry for 450 line item claims with all parameters passed by                  
  reference. This entry is identical to haaf..c2 but the name does              
  not have to change for each release                                           
*/                                                                              
short  IRPEXTENT OCECLAIM_GRP(
/*------------------------------*/                                              
/*      INPUT ARGUMENTS         */                                              
/*------------------------------*/                                              
  char  FAR *lvdx_ptr,             /* array of DXs, 8 chars each            */  
                /* left-justified, blank-filled                             */  
                /* first  DX is first  reason for visit, may be blank       */  
                /* second DX is second reason for visit, may be blank       */  
                /* third  DX is third  reason for visit, may be blank       */  
                /* fourth DX is principal DX, may not be blank              */  
                /* additional DXs are secondary DXs                         */  
  char  FAR *lvndx,                /* number of DXs in lvdx_ptr, 99 max     */  
                /* count is 8 chars (e.g. 00000016)                         */  
                /* right-justified, zero or blank-filled                    */  
  char  FAR *lineitems,            /* array of line items, 44 chars each    */  
                /*  5 chars HCPCS Code, left-justified, blank-filled        */  
                /* 10 chars HCPCS Modifiers, up to 5 2-char modififiers,    */  
                /*          blank-filled                                    */  
                /*  8 chars Service Date, yyyymmdd                          */  
                /*  4 chars Revenue Code                                    */  
                /*  9 chars Service Units, right-justified, zero-filled     */
                /* 10 chars Charge, in cents e.g. 0000000101 = $1.01        */  
                /*          right-justified, zero-filled                    */  
  char  FAR *vlineitems,           /* number of line items, 450 max         */  
                /* count is 8 chars (e.g. 00000450)                         */  
                /* right-justified, zero or blank-filled                    */  
  char  FAR *laction,              /* array of line item action flags,      */  
                /* 1 char each                                              */  
                /* 0 Line item denial or rejection is not ignored           */  
                /* 1 Line item denial or rejection is ignored               */  
                /* 2 External line item denial                              */  
                /* 3 External line item rejection                           */  
                /* 4 External line item adjustment                          */  
                /* 5 Non-covered service excluded from payment under FQHC   */
                /*   PPS                                                    */
  char  FAR *age,                  /* age in years, 3 chars, 000-124        */  
                /* right-justified, zero or blank-filled                    */  
  char  FAR *sex,                  /* 0 unknown, 1 male, 2 female           */  
  char  FAR *fromtodates,          /* from - to dates, 16 chars             */  
                /* yyyymmddyyyymmdd                                         */  
  char  FAR *ccodes,               /* array of condition codes,2 chars each */  
  char  FAR *vccodes,              /* number of condition codes, 11 max     */  
                /* count is 8 chars (e.g. 00000007)                         */  
                /* right-justified, zero or blank-filled                    */  
  char  FAR *billtype,             /* 3 byte bill type                      */  
  char  FAR *npinumber,            /* 13 byte national provider ID          */  
  char  FAR *oscar,                /* 6 byte OSCAR Medicare value           */  
  char  FAR *pstatptr,             /* 2 byte patient status                 */  
  char  FAR *oppsptr,              /* 1 OPPS, 2 Non-OPPS                    */  
  char  FAR *occptr,               /* array of occurence codes,2 chars each */  
  char  FAR *noccptr,              /* number of occurrence codes, 10 max    */  
                /* count is 8 chars (e.g. 00000010)                         */  
                /* right-justified, zero or blank-filled                    */  
  char  FAR *codetype,             /* ICD code type indicator, 1 char       */  
                /* 0 ICD-10 diagnosis codes                                 */  
                /* 9 ICD-9  diagnosis codes                                 */  
                /* otherwise the code type is based on the from date        */  
/*------------------------------*/                                              
/*      OUTPUT ARGUMENTS        */                                              
/*------------------------------*/                                              
  char  FAR *dxeditbuf,            /* array of dx edit return buffers       */  
                /* 24 chars ( 8 edits x 3 digit edit code) for each DX      */  
  char  FAR *sgeditbuf,            /* array of sg edit return buffers       */  
                /* 90 chars (30 edits x 3 digit edit code) per line item    */  
  char  FAR *modeditbuf,           /* array of modifier edit return buffers */  
                /* 60 chars per line item                                   */  
                /* (4 edits x 3 digit edit code x 5 modifiers) per line item*/  
  char  FAR *dteditbuf,            /* array of date edit return buffers     */  
                /* 12 chars ( 4 edits x 3 digit edit code) per line item    */  
  char  FAR *reveditbuf,           /* array of revenue edit return buffers  */  
                /* 15 chars ( 5 edits x 3 digit edit code) per line item    */  
  char  FAR *apceditbuf,           /* apc edit return buffer, 45 chars      */  
                /*  5 chars HCPCS Code from input                           */  
                /*  5 chars Payment APC (used to determine payment)         */  
                /*  5 chars HCPCS APC (APC assigned to HCPCS code)          */  
                /*  2 chars Status Indicator, right-justified, blank-filled */  
                /*           A Services not paid under OPPS                 */  
                /*           B Non-allowed item or service for OPPS         */  
                /*           C Inpatient procedure                          */  
                /*           E Non-allowed item or service                  */  
                /*           F Corneal tissue acquisition; certain CRNA     */  
                /*             services and hepatitis B vaccines            */  
                /*           G Drug/biological pass-through                 */  
                /*           H Pass-through device categories and           */  
                /*             radiopharmaceutical agents                   */  
                /*           J New drug or new biological pass-through      */  
                /*          J1 Outpatient department services paid          */
                /*             through  a comprehensive APC                 */
                /*          J2 Hospital Part B services that may be paid    */
                /*             through a comprehensive APC                  */
                /*           K Non-pass-through drugs and biologicals       */  
                /*           L Flu/PPV vaccines                             */  
                /*           M Service not billable to the FI/MAC           */  
                /*           N Items and Services packaged into APC rates   */  
                /*           P Partial hospitalization service              */  
                /*          Q1 STVX-packaged codes                          */  
                /*          Q2 T-packaged codes                             */  
                /*          Q3 Codes paid through a composite APC           */  
                /*          Q4 Conditionally packaged laboratory services   */ 
                /*           R Blood and blood products                     */  
                /*           S Significant proceudre not subject to         */  
                /*             multiple procedure discounting               */  
                /*           T Significant proceudre subject to             */  
                /*             multiple procedure discounting               */  
                /*           U Brachytherapy sources                        */  
                /*           V Clinic or emergency department visit         */  
                /*           W Invalid HCPCS or invalid revenue code with   */  
                /*             blank HCPCS                                  */  
                /*           X Ancillary service                            */  
                /*           Y Non-implantable DME                          */  
                /*           Z Valid revenue code with blank HCPCS and no   */  
                /*             other SI assigned                            */  
                /*  2 chars Payment Indicator, right-justified, blank-filled*/  
                /*           1 Paid standard hospital OPPS amount           */  
                /*             (status indicators J1,J2,K,R,S,T,U,V)        */  
                /*           2 Service not paid under OPPS                  */  
                /*             (status indicator A)                         */  
                /*           3 Not paid                                     */  
                /*             (status indicators E,M,Q,Q1,Q2,Q3,Q4,W,Y)    */  
                /*             or not paid under OPPS                       */  
                /*             (status indicators B, C, Z)                  */  
                /*           4 Paid at reasonable cost                      */  
                /*             (status indicators F, L)                     */  
                /*           5 Paid standard amount for pass-through drug   */  
                /*             or biological                                */  
                /*             (status indicator G)                         */  
                /*           6 Payment based on charge adjusted to cost     */  
                /*             (status indicators H, U)                     */  
                /*           7 Additional payment for new drug or new       */  
                /*             biological                                   */  
                /*           8 Paid partial hospitalization per diem        */  
                /*             (status indicator P)                         */  
                /*           9 No additional payment;                       */  
                /*             Payment included in line items with APCs     */  
                /*             (status indicator N;                         */  
                /*             or no HCPCS code and certaiin revenue codes; */  
                /*             or HCPCS codes G0176, G0129 or G0177)        */  
                /*          10 Paid FQHC encounter payment                  */
                /*          11 Not paid or not included under FQHC          */
                /*             encounter payment                            */
                /*          12 No additional payment, included in payment   */
                /*             for FQHC encounter                           */
                /*          13 Paid FQHC encounter payment for New patient  */
                /*             or IPPE/AWV                                  */
                /*          14 Grandfathered tribal FQHC encounter payment  */
                /*  1 char  Discount Formula Number                         */  
                /*          1 1.0                                           */  
                /*          2 (1.0 + D(U-1))/U                              */  
                /*          3 T/U                                           */  
                /*          4 (1 + D)/U                                     */  
                /*          5 D                                             */  
                /*          6 TD/U                                          */  
                /*          7 D(1 + D)/U                                    */  
                /*          8 2.0                                           */  
                /*          9 2D/U                                          */  
                /*            D = discounting fraction                      */  
                /*            U = number of units                           */  
                /*            T = terminated procedure discount             */  
                /*  1 char  Line Item Denial or Rejection Flag              */  
                /*          0 Line item is not denied or rejected.          */  
                /*          1 Line item is denied or rejected.              */  
                /*          2 Line item is not denied or rejected but       */  
                /*            occurs on a day that has been denied or       */  
                /*            rejected.                                     */  
                /*  1 char  Packaging Flag                                  */  
                /*          0 Not packaged                                  */  
                /*          1 Packaged service                              */  
                /*          2 Packaged as part of partial hospitalization   */  
                /*            per diem or daily mental health service per   */  
                /*            diem                                          */  
                /*          3 Artificial charges for surgical procedures    */  
                /*          4 Packaged as part of drug administrations APC  */  
                /*            payment                                       */  
                /*          5 Packaged as part of FQHC encounter payment    */
                /*          6 Packaged preventive service as part of FQHC   */
                /*            encounter payment not subject to coinsurance  */
                /*            payment                                       */
                /*  2 chars Payment Adjustment Flag                         */  
                /*          right-jusified, blank-filled                    */  
                /*           0 No payment adjustment                        */  
                /*           1 Paid standard amount for pass-through drug   */  
                /*             or biological (status indicator G)           */  
                /*           2 Payment based on charge adjusted to cost     */  
                /*             (status indicators H, U)                     */  
                /*           3 Additional payment for new drug or new       */  
                /*             biological applies to APC                    */  
                /*             (status indicator J)                         */  
                /*           4 Deductible not applicable                    */  
                /*             (specific list of HCPCS codes)               */  
                /*           5 Blood/blood product used in blood deductible */  
                /*             calculation                                  */  
                /*           6 Blood processing/storage not subject to      */  
                /*             blood deductible                             */  
                /*           7 Item provided without cost to provider       */  
                /*           8 Item provided with partial credit to provider*/  
                /*           9 Deductible/co-insurance not applicable       */
                /*          10 Co-insurance not applicable                  */
                /*          11 Multiple service units reduced to one by     */
                /*             IOCE processing; payment based on single     */
                /*             payment rate                                 */
                /*          12 Offset for first  device pass-through        */
                /*          13 Offset for second device pass-through        */
                /*          14 PAMA Section 218 reduction on CT scan        */
                /*          15 Placeholder - Reserved for Future Use        */
                /*          16 Terminated procedure with pass-thru device   */
                /*          17 Condition for device credit present          */
                /*          18 Offset for 1st pass-thru drug or biological  */
                /*          19 Offset for 2nd pass-thru drug or biological  */
                /*          20 Offset for 3rd pass-thru drug or biological  */
                /*  1 char  Payment Method Flag                             */  
                /*          0 OPPS pricer determines payment for service    */  
                /*          1 Based on OPPS, Coverage of Billing rules,     */  
                /*            the service is not paid                       */  
                /*          2 Service is not subject to OPPS                */  
                /*          3 Service is not subject to OPPS and has a line */  
                /*            item denial or rejection                      */  
                /*          4 Line item is denied or rejected by FI/MAC;    */  
                /*            OPPS is not applied to line item              */  
                /*          5 Payment for service determined under FQHC PPS */
                /*  9 chars Service Units, right-justified, zero-filled     */
                /*          transferred from input                          */  
                /* 10 chars Charge, in cents e.g. 0000000101 = $1.01        */  
                /*          right-justif., zero-filled                      */  
                /*          transferred from input                          */  
                /*  1 char  Line Item Action Flag                           */  
                /*          0 Line item denial or rejection is not ignored  */  
                /*          1 Line item denial or rejection is ignored      */  
                /*          2 External line item denial                     */  
                /*          3 External line item rejection.                 */  
                /*          4 External line item adjustment.                */  
                /*          5 Non-covered service excluded from payment     */
                /*            under FQHC PPS                                */
                /*  2 chars Composite Adjustment Flag                       */  
                /*          right-justified, zero-filled                    */  
                /*          00 No composite group assigned                  */  
                /*          01 First composite group on claim               */  
                /*          02 Second composite group on claim              */  
                /*          ...                                             */  
                /*          nn nth composite group on claim                 */  
                /*          For FQHC PPS claims (bill type 77x) only, the   */
                /*          following values are defined for composite      */
                /*          adjustment flag:                                */
                /*          01 FQHC medical clinic visit                    */
                /*          02 FQHC mental health clinic visit              */
                /*          03 Subsequent FQHC clinic visit, medical or     */
                /*             mental health (modifier 59 reported)         */
  char  FAR *clmeditbuf,           /* claim edit return buffer, 270 chars   */  
                /*  1 char  Claim Processed Flag                            */  
                /*          0 Claim processed                               */  
                /*          1 Claim not processed; invalid date;            */  
                /*            inappropriate bill type/condition code        */  
                /*            combination; or invalid bill type             */  
                /*          2 Claim not processed; no line items present    */  
                /*          3 Claim not processed; condition code 21 present*/  
                /*          9 A fatal error has been detected during        */  
                /*            initializaton                                 */  
                /*  3 chars Number of Line Items                            */  
                /*          transferrred from input                         */  
                /* 13 chars National Provider Identifier,                   */  
                /*          transferrred from input, for pricer             */  
                /*  6 chars OSCAR Medicare Provider Number                  */  
                /*          transferrred from input, for pricer             */  
                /*  1 char  Overall Claim Disposition                       */  
                /*          0 No edits present on claim                     */  
                /*          1 The only edits present are for line item      */  
                /*            denial or rejection                           */  
                /*          2 Multiple-day claim with one or more days      */  
                /*            denied or rejected                            */  
                /*          3 Claim is denied, rejected, suspended or       */  
                /*            returned to provider, or single day claim     */  
                /*            with all line items denied or rejected,       */  
                /*            with only post-payment edits                  */  
                /*          4 Claim is denied, rejected, suspended or       */  
                /*            returned to provider, or single day claim     */  
                /*            with all line items denied or rejected,       */  
                /*            with only pre-payment edits                   */  
                /*          5 Claim is denied, rejected, suspended or       */  
                /*            returned to provider, or single day claim     */  
                /*            with all line items denied or rejected,       */  
                /*            with both pre- and post-payment edits         */  
                /*  1 char  Claim Rejection Disposition                     */  
                /*          0 Claim not rejected                            */  
                /*          1 One or more edits are present that cause      */  
                /*            the claim to be rejected                      */  
                /*          2 One or more edits are present that cause      */  
                /*            one or more days of a mulitple-day claim      */  
                /*            to be rejected                                */  
                /*  1 char  Claim Denial Disposition                        */  
                /*          0 Claim not denied                              */  
                /*          1 One or more edits are present that cause      */  
                /*            the claim to be denied                        */  
                /*          2 One or more edits are present that cause      */  
                /*            one or more days of a mulitple-day claim      */  
                /*            to be denied, or single day claim with all    */  
                /*            lines denied                                  */  
                /*  1 char  Claim Returned to Provider Disposition          */  
                /*          0 Claim is not returned to provider             */  
                /*          1 One or more edits are present that cause      */  
                /*            the claim to be returned to provider          */  
                /*  1 char  Claim Suspension Disposition                    */  
                /*          0 Claim is not suspended                        */  
                /*          1 One or more edits are present that cause      */  
                /*            the claim to be suspended                     */  
                /*  1 char  Line Item Rejection Disposition                 */  
                /*          0 No line items are rejected                    */  
                /*          1 One or more edits are present that cause      */  
                /*            one or more line items to be rejected         */  
                /*  1 char  Line Item Denial Disposition                    */  
                /*          0 No line items are denied                      */  
                /*          1 One or more edits are present that cause      */  
                /*            one or more line items to be denied           */  
                /* 12 chars Claim Rejection Reasons                         */  
                /*          Up to 4 three-digit codes specifying the edits  */  
                /*          that caused the claim to be rejected            */  
                /* 24 chars Claim Denial Reasons                            */  
                /*          Up to 8 three-digit codes specifying the edits  */  
                /*          that caused the claim to be denied              */  
                /* 90 chars Claim Returned to Provider Reasons              */  
                /*          Up to 30 three-digit codes specifying the edits */  
                /*          that could cause the claim to be returned to    */  
                /*          the provider                                    */  
                /* 48 chars Claim Suspension Reasons                        */  
                /*          Up to 16 three-digit codes specifying the edits */  
                /*          that caused the claim to be suspended           */  
                /* 36 chars Line Item Rejection Reasons                     */  
                /*          Up to 12 three-digit codes specifying the edits */  
                /*          that caused the line item to be rejected        */  
                /* 18 chars Line Item Denied Reasons                        */
                /*          Up to 6 three-digit codes specifying the edits  */  
                /*          that caused the line item to be denied          */  
                /*  1 char  APC/ASC Return Buffer Flag                      */  
                /*          0 APC/ASC return buffer filled in with default  */  
                /*            values; no services paid under OPPS           */  
                /*          1 APC/ASC return buffer filled in; one or more  */  
                /*            services paid under OPPS                      */  
                /*  8 chars Version Used                                    */  
                /*          ID of the program version used to process the   */  
                /*          claim in yy.vv.rr format                        */  
                /*  2 chars Patient Status                                  */  
                /*          transferred from input                          */  
                /*  1 char  OPPS Flag                                       */
                /*          transferred from input                          */
                /*  1 char  Non-OPPS Bill Type Flag                         */  
                /*          0 N/A                                           */  
                /*          1 Bill type should be 83x                       */  
                /*          2 Bill type should not be 83x                   */
                /* 110 chars Payer Value Codes (10 code/amount pairs        */
                /*          2 char value code (QN - QW)                     */
                /*          9 char amount nnnnnnn.nn (assumed decimal place)*/
  char  FAR *workbuf,              /* work area - set to NULL               */
  char  FAR *workbufsize           /* work area size - set to "00000000"    */  
 );
                                                                                
#if defined(PCWIN)                                                              
typedef short FAR PASCAL (*APC_v1_Grouper_Routine)                              
#elif defined(PCOS2DLL) || defined(PCOS2)                                       
typedef short __syscall  (*APC_v1_Grouper_Routine)                              
#elif defined (PCWIN32)                                                         
typedef short (__stdcall *APC_v1_Grouper_Routine)                               
#else                                                                           
typedef short           (*APC_v1_Grouper_Routine)                               
#endif                                                                          
  (                                                                             
                             /* ==================================== */         
                             /*    v1.0 c Style Interface            */         
                             /* ==================================== */         
                             /*                                      */         
                             /*       Note:  This I/F area is very   */         
                             /*        much like the OS/MVS version, */         
                             /*        except FN_GROUP field has     */         
                             /*        been added, and the function  */         
                             /*        returns an error code.        */         
                             /*      Plus additional args            */         
                             /*                                      */         
                             /* Parm  ------- IRP I/P Argument ----- */         
                             /*                                      */         
  short      grpfunc,        /*  01   IRP grouper function:          */         
                             /*         0 = group,                   */         
                             /*         1 = free this groupers storag*/         
                             /*         2 = free all groupers storage*/         
                             /*                                      */         
                             /*       ------- 370 I/P Arguments ---- */         
                             /*                                      */         
  char  FAR *vdx_ptr,        /*  02   to array of 50 DX x 6 bytes ea */         
  short      vndx,           /*  03   act nbr dx (diagnoses)  50 MAX */         
  short      vndxmax,        /*  04   max nbr dx (diagnoses)  50 MAX */         
  char  FAR *vsg_ptr,        /*  05   to array of 50 SG x 9 bytes ea */         
  short      vnsg,           /*  06   act nbr sg (cpt4 procs) 50 MAX */         
  short      vnsgmax,        /*  07   max nbr sg (cpt4 procs) 50 MAX */         
                             /*                                      */         
                             /*       ----- 370 Output Arguments --- */         
                             /*                                      */         
  char  FAR *vpatvist,       /*  08   Visit Type Code       (1 char) */         
                             /*         0 - Undetermined             */         
                             /*         1 - Significant Procedure    */         
                             /*         2 - Ancillary Procedure ONLY */         
                             /*         3 - Medical Visit            */         
  char  FAR *vapcstat,       /*  09  APC Status Code -     (1 char) */          
                             /*         0 - No errors found          */         
                             /*         1 - Procedure APC PAPC errs  */         
                             /*         2 - Medical APC MAPC errs    */         
                             /*         3 - Both PAPC & MAPC errors  */         
  char  FAR *vmapc,          /*  10   unused                         */         
  char  FAR *vpapc,          /*  11   50x5 PAPC assigned    (5 char) */         
  char  FAR *vpapcstat,      /*  12   50x2 PAPC Status      (2 char) */         
                                 /*  A1 - Non-paid                 */           
                                 /*  C  - Bill as Inpatient        */           
                                 /*  A2 - DMEPOS Fee Schedule      */           
                                 /*  E  - Non-Paid                 */           
                                 /*  A3 - Rehab Fee Schedule       */           
                                 /*  A4 - Ambulance Fee Schedule   */           
                                 /*  A5 - National Rate            */           
                                 /*  A6 - Lab Fee Schedule         */           
                                 /*  A7 - Bill to Carrier          */           
                               /*  A8 - Lower of Charge or National Rate */     
                               /*  N  - Packaged; No Addl payment allowed */    
                               /*  P  - Paid per diem            */             
                               /*  S  - Paid under hosp outpt PPS(APC Rate) */  
                               /*  T  - Paid under hosp outpt PPS(APC Rate) */  
                               /*  V  - Paid under hosp outpt PPS(APC Rate) */  
                               /*  X  - Paid under hosp outpt PPS(APC Rate) */  
  char  FAR *vpapcerr,       /*  13   50x2 PAPC Error       (2 char) */         
  char  FAR *vancpk,         /*  14   50x1 PAPC ancillary pkg fl 0/1 */         
                             /*                                      */         
                             /*       -----  IRP O/P Arguments ----- */         
                             /*                                      */         
  char  FAR *vers            /*  15   grouper version      (11 char) */         
);                                                                              
                                                                                
                                                                                
#if defined(PCWIN)                                                              
typedef void far pascal (*APC_v2_Grouper_Routine_MVS)                           
#elif defined(PCOS2DLL) || defined(PCOS2)                                       
 /* extern ? */                                                                 
typedef void __syscall (*APC_v2_Grouper_Routine_MVS)                            
#elif defined(PCWIN32)                                                          
typedef void (__stdcall *APC_v2_Grouper_Routine_MVS)                            
#else                                                                           
typedef void (*APC_v2_Grouper_Routine_MVS)                                      
#endif                                                                          
   (                                                                            
                             /* ==================================== */         
                             /*    v2.0 MVS 370 Style Interface      */         
                             /* ==================================== */         
                             /*                                      */         
                             /*       Note:  This I/F mirrors the    */         
                             /*        MVS Assembler version         */         
                             /*        of the APC v2.0 Grouper       */         
                             /*                                      */         
                             /* Parm  ------- I/P Argument -----     */         
                             /*                                      */         
  char  FAR *vdx_ptr,        /*  01   to array of 50 DX x 6 bytes ea */         
  char  FAR *vcndx,          /*  02   act nbr dx (diagnoses)  50 MAX */         
                             /*                 9(3) display decimal */         
  char  FAR *vcndxmax,       /*  03   max nbr dx (diagnoses)  50 MAX */         
                             /*                 9(3) display decimal */         
  char  FAR *vsg_ptr,        /*  04   to array of 50 SG x 9 bytes ea */         
  char  FAR *vcnsg,          /*  05   act nbr sg (cpt4 procs) 50 MAX */         
                             /*                 9(3) display decimal */         
  char  FAR *vcnsgmax,       /*  06   max nbr sg (cpt4 procs) 50 MAX */         
                             /*                 9(3) display decimal */         
                             /*                                      */         
                             /*       ----- 370 Output Arguments --- */         
                             /*                                      */         
  char  FAR *vpatvist,       /*  07   Visit Type Code       (1 char) */         
                             /*         0 - Undetermined             */         
                             /*         1 - Significant Procedure    */         
                             /*         2 - Ancillary Procedure ONLY */         
                             /*         3 - Medical Visit            */         
  char  FAR *vapcstat,       /*  08  APC Status Code -     (1 char) */          
                             /*         0 - No errors found          */         
                             /*         1 - Procedure APC PAPC errs  */         
                             /*         2 - Medical APC MAPC errs    */         
                             /*         3 - Both PAPC & MAPC errors  */         
  char  FAR *vmapc,          /*  09   Medical APC assigned  (3 char) */         
  char  FAR *vmapctyp,       /*  10   MAPC  Type Code       (2 char) */         
                             /*        07 - Medical Visit            */         
                             /*        08 - Error APC                */         
  char  FAR *vmapccat,       /*  11   MAPC Category         (2 char) */         
  char  FAR *vmapcssf,       /*  12   1st encountered SSF (MAPC=611) */         
                             /*                             (6 char) */         
  char  FAR *vpapc,          /*  13   50x3 PAPC assigned    (3 char) */         
  char  FAR *vpapctype,      /*  14   50x2 PAPC Type code - (2 char) */         
                             /*        01 - Significant Procedure    */         
                             /*        02 - Ancillary   Procedure    */         
                             /*        03 - Incidental  Procedure    */         
                             /*        04 - Medical Visit Indicator  */         
                             /*        05 - Mental Illness/Substance */         
                             /*               Abuse Therapy          */         
                             /*        06 - Mental Illness/Substance */         
                             /*               Abuse Counseling       */         
                             /*        08 - Alpha HCPCS w/ no PAPC   */         
                             /*        09 - Error APC                */         
  char  FAR *vpapccat,       /*  15   50x2 PAPC Category    (2 char) */         
  char  FAR *vancpk          /*  16   50x1 PAPC ancillary pkg fl 0/1 */         
);                                                                              
                                                                                
/* AP-DRG NY 8.0 */                                                             
                                                                                
#if defined(PCWIN)                                                              
typedef short FAR PASCAL (*APDRG_Grouper_Routine)                               
#elif defined(PCOS2DLL) || defined(PCOS2)                                       
 /* extern ? */                                                                 
typedef short __syscall  (*APDRG_Grouper_Routine)                               
#elif defined(PCWIN32)                                                          
#if defined(MS6COMPILER)                                                        
typedef short  (*APDRG_Grouper_Routine)                                         
#else                                                                           
typedef short (__stdcall *APDRG_Grouper_Routine)                                
#endif                                                                          
#else                                                                           
typedef short  (*APDRG_Grouper_Routine)                                         
#endif                                                                          
  (                                                                             
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free this groupers storage               
                               *   2 = free all groupers storage                
                               */                                               
    short  lvndx,             /* number dx (diagnoses)          */              
    short  lvnsg,             /* number sg (procedures)         */              
    char  far *lvdx_ptr,      /* to array of 50 DX x 5 bytes ea */              
    char  far *lvsg_ptr,      /* to array of 50 SG x 4 bytes ea */              
    char  far *lvsex,         /*                                */              
    char  far *lvdstat,       /*                                */              
    char  far *lvbdate,       /*                                */              
    char  far *lvadate,       /*                                */              
    char  far *lvddate,       /*                                */              
    char  far *lvcind,        /*                                */              
    char  far *lvbwght,       /*                                */              
    char  far *lvbwtopt,      /*                                */              
    char  far *lvdrg,         /*                                */              
    char  far *lvmdc,         /*                                */              
    char  far *lvrtc,         /*                                */              
    char  far *lvmajop1,      /*                                */              
    char  far *lvmajop2,      /*                                */              
    char  far *lvmajop3,      /*                                */              
    char  far *lvminop1,      /*                                */              
    char  far *lvminop2,      /*                                */              
    char  far *lvdrgdx1,      /*                                */              
    char  far *lvdrgdx2,      /*                                */              
    char  far *lvdrgdx3,      /*                                */              
    char  far *lvdrgcc,       /*                                */              
    char  far *lvmajcci,      /*                                */              
    char  far *lvers,         /*                                */              
    char  far *lvdxcctab      /*                                */              
                                                                                
   );                                                                           
                                                                                
                                                                                
/* AP-DRG NY 10.0 */                                                            
                                                                                
#if defined(PCWIN)                                                              
typedef short FAR PASCAL (*APDRG10_Grouper_Routine)                             
#elif defined(PCOS2DLL) || defined(PCOS2)                                       
 /* extern ? */                                                                 
typedef short __syscall  (*APDRG10_Grouper_Routine)                             
#elif defined(PCWIN32)                                                          
#if defined(MS6COMPILER)                                                        
typedef short  (*APDRG10_Grouper_Routine)                                       
#else                                                                           
typedef short (__stdcall *APDRG10_Grouper_Routine)                              
#endif                                                                          
#else                                                                           
typedef short  (*APDRG10_Grouper_Routine)                                       
#endif                                                                          
  (                                                                             
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free this groupers storage               
                               *   2 = free all groupers storage                
                               */                                               
    short  lvndx,             /* number dx (diagnoses)          */              
    short  lvnsg,             /* number sg (procedures)         */              
    char  far *lvdx_ptr,      /* to array of 50 DX x 5 bytes ea */              
    char  far *lvsg_ptr,      /* to array of 50 SG x 4 bytes ea */              
    char  far *lvsex,         /*                                */              
    char  far *lvdstat,       /*                                */              
    char  far *lvbdate,       /*                                */              
    char  far *lvadate,       /*                                */              
    char  far *lvddate,       /*                                */              
    char  far *lvcind,        /*                                */              
    char  far *lvbwght,       /*                                */              
    char  far *lvbwtopt,      /*                                */              
    char  far *lvdrg,         /*                                */              
    char  far *lvmdc,         /*                                */              
    char  far *lvrtc,         /*                                */              
    char  far *lvmajop1,      /*                                */              
    char  far *lvmajop2,      /*                                */              
    char  far *lvmajop3,      /*                                */              
    char  far *lvminop1,      /*                                */              
    char  far *lvminop2,      /*                                */              
    char  far *lvdrgdx1,      /*                                */              
    char  far *lvdrgdx2,      /*                                */              
    char  far *lvdrgdx3,      /*                                */              
    char  far *lvdrgcc,       /*                                */              
    char  far *lvmajcci,      /*                                */              
    char  far *lvtraum,       /*                                */              
    char  far *lvers,         /*                                */              
    char  far *lvdxcctab      /*                                */              
                                                                                
   );                                                                           
                                                                                
                                                                                
/* AP-DRG NY 11.0 */                                                            
                                                                                
#if defined(PCWIN)                                                              
typedef short FAR PASCAL (*APDRG11_Grouper_Routine)                             
#elif defined(PCOS2DLL) || defined(PCOS2)                                       
 /* extern ? */                                                                 
typedef short __syscall  (*APDRG11_Grouper_Routine)                             
#elif defined(PCWIN32)                                                          
#if defined(MS6COMPILER)                                                        
typedef short  (*APDRG11_Grouper_Routine)                                       
#else                                                                           
typedef short (__stdcall *APDRG11_Grouper_Routine)                              
#endif                                                                          
#else                                                                           
typedef short  (*APDRG11_Grouper_Routine)                                       
#endif                                                                          
  (                                                                             
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free this groupers storage               
                               *   2 = free all groupers storage                
                               */                                               
    char  far *lvtsw,         /*                                */              
    short  lvndx,             /* number dx (diagnoses)          */              
    short  lvnsg,             /* number sg (procedures)         */              
    char  far *lvdx_ptr,      /* to array of 50 DX x 5 bytes ea */              
    char  far *lvsg_ptr,      /* to array of 50 SG x 4 bytes ea */              
    char  far *lvage,         /*                                */              
    char  far *lvsex,         /*                                */              
    char  far *lvdstat,       /*                                */              
    char  far *lvbdate,       /*                                */              
    char  far *lvadate,       /*                                */              
    char  far *lvddate,       /*                                */              
    char  far *lvcind,        /*                                */              
    char  far *lvbwght,       /*                                */              
    char  far *lvbwtopt,      /*                                */              
    char  far *lvdrg,         /*                                */              
    char  far *lvmdc,         /*                                */              
    char  far *lvrtc,         /*                                */              
    char  far *lvmajop1,      /*                                */              
    char  far *lvmajop2,      /*                                */              
    char  far *lvmajop3,      /*                                */              
    char  far *lvminop1,      /*                                */              
    char  far *lvminop2,      /*                                */              
    char  far *lvdrgdx1,      /*                                */              
    char  far *lvdrgdx2,      /*                                */              
    char  far *lvdrgdx3,      /*                                */              
    char  far *lvdrgcc,       /*                                */              
    char  far *lvmajcci,      /*                                */              
    char  far *lvtraum,       /*                                */              
    char  far *lvers,         /*                                */              
    char  far *lvdxcctab      /*                                */              
                                                                                
   );                                                                           
                                                                                
/* AP-DRG NY 14.0 */                                                            
                                                                                
#if defined(PCWIN)                                                              
typedef short FAR PASCAL (*APDRG14_Grouper_Routine)                             
#elif defined(PCOS2DLL) || defined(PCOS2)                                       
 /* extern ? */                                                                 
typedef short __syscall  (*APDRG14_Grouper_Routine)                             
#elif defined(PCWIN32)                                                          
#if defined(MS6COMPILER)                                                        
typedef short  (*APDRG14_Grouper_Routine)                                       
#else                                                                           
typedef short (__stdcall *APDRG14_Grouper_Routine)                              
#endif                                                                          
#else                                                                           
typedef short  (*APDRG14_Grouper_Routine)                                       
#endif                                                                          
  (                                                                             
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free this groupers storage               
                               *   2 = free all groupers storage                
                               */                                               
    char  far *lvtsw,         /*                                */              
    short  lvndx,             /* number dx (diagnoses)          */              
    short  lvnsg,             /* number sg (procedures)         */              
    char  far *lvdx_ptr,      /* to array of 50 DX x 5 bytes ea */              
    char  far *lvsg_ptr,      /* to array of 50 SG x 4 bytes ea */              
    char  far *lvage,         /*                                */              
    char  far *lvsex,         /*                                */              
    char  far *lvdstat,       /*                                */              
    char  far *lvbdate,       /*                                */              
    char  far *lvadate,       /*                                */              
    char  far *lvddate,       /*                                */              
    char  far *lvbwght,       /*                                */              
    char  far *lvbwtopt,      /*                                */              
    char  far *lvdrg,         /*                                */              
    char  far *lvmdc,         /*                                */              
    char  far *lvrtc,         /*                                */              
    char  far *lvmajop1,      /*                                */              
    char  far *lvmajop2,      /*                                */              
    char  far *lvmajop3,      /*                                */              
    char  far *lvminop1,      /*                                */              
    char  far *lvminop2,      /*                                */              
    char  far *lvdrgdx1,      /*                                */              
    char  far *lvdrgdx2,      /*                                */              
    char  far *lvdrgdx3,      /*                                */              
    char  far *lvdrgcc,       /*                                */              
    char  far *lvmajcci,      /*                                */              
    char  far *lvtraum,       /*                                */              
    char  far *lvers,         /*                                */              
    char  far *lvdxcctab      /*                                */              
                                                                                
   );                                                                           
                                                                                
/* AP-DRG NY 18.0 */                                                            
                                                                                
#if defined(PCWIN)                                                              
typedef short FAR PASCAL (*APDRG18_Grouper_Routine)                             
#elif defined(PCOS2DLL) || defined(PCOS2)                                       
 /* extern ? */                                                                 
typedef short __syscall  (*APDRG18_Grouper_Routine)                             
#elif defined(PCWIN32)                                                          
#if defined(MS6COMPILER)                                                        
typedef short  (*APDRG18_Grouper_Routine)                                       
#else                                                                           
typedef short (__stdcall *APDRG18_Grouper_Routine)                              
#endif                                                                          
#else                                                                           
typedef short  (*APDRG18_Grouper_Routine)                                       
#endif                                                                          
  (                                                                             
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free this groupers storage               
                               *   2 = free all groupers storage                
                               */                                               
    char  far *lvtsw,         /*                                */              
    short  lvndx,             /* number dx (diagnoses)          */              
    short  lvnsg,             /* number sg (procedures)         */              
    char  far *lvdx_ptr,      /* to array of 50 DX x 5 bytes ea */              
    char  far *lvsg_ptr,      /* to array of 50 SG x 4 bytes ea */              
    char  far *lvage,         /*                                */              
    char  far *lvsex,         /*                                */              
    char  far *lvdstat,       /*                                */              
    char  far *lvbdate,       /*                                */              
    char  far *lvadate,       /*                                */              
    char  far *lvddate,       /*                                */              
    char  far *lvbwght,       /*                                */              
    char  far *lvbwtopt,      /*                                */              
    char  far *lvdrg,         /*                                */              
    char  far *lvmdc,         /*                                */              
    char  far *lvrtc,         /*                                */              
    char  far *lvmajop1,      /*                                */              
    char  far *lvmajop2,      /*                                */              
    char  far *lvmajop3,      /*                                */              
    char  far *lvminop1,      /*                                */              
    char  far *lvminop2,      /*                                */              
    char  far *lvdrgdx1,      /*                                */              
    char  far *lvdrgdx2,      /*                                */              
    char  far *lvdrgdx3,      /*                                */              
    char  far *lvdrgcc,       /*                                */              
    char  far *lvmajcci,      /*                                */              
    char  far *lvtraum,       /*                                */              
    char  far *lvmalrg,       /* added for 18.0                 */              
    char  far *lvers,         /*                                */              
    char  far *lvdxcctab      /*                                */              
                                                                                
   );                                                                           
                                                                                
/* These are the individual grouper prototypes */                               
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf06cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf06c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf06c1                                            
#else                                                                           
short IRPEXTCALL hadf06c1                                                       
#endif                                                                          
                                                                                
      (                      /* ------Federal Grouper  6.0---- */               
                 /* -------- input arguments ----- */                           
       short grpfunc,          /* grouper function:                             
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
      short  vndx,            /* number dx (diagnoses)  50 MAX  */              
       short  vnsg,            /* number sg (procedures) 50 MAX  */             
     char  FAR *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */          
       char  FAR *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
     char  FAR *vmdc,             /* assigned MDC 2 char            */          
     char  FAR *vrtc,             /* return code  1 char            */          
     char  FAR *vmajop,           /* 1st significant SG  4 bytes    */          
     char  FAR *vadx,             /* 1st significant DX  5 bytes    */          
       char  FAR *vsdx,             /* 2nd significant DX  5 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  4 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  4 bytes    */        
     char  FAR *vminop2,          /* 2nd minor sign. SG  4 bytes    */          
       char  FAR *vdxcc,            /* CC DX               5 bytes    */        
/*       char  FAR *vmajop3,*/          /* 3rd significant SG  4 bytes    */    
     char  FAR *vdxcctab          /* array of 50 char - one for each            
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D60CTL                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D60CTL                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D60CTL                                               
#else                                                                           
 void IRPEXTCALL  D60CTL                                                        
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper  6.0---- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
    char FAR *vmajop,           /* 1st significant SG  4 bytes    */            
    char FAR *vadx,             /* 1st significant DX  5 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  5 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  4 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  4 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  4 bytes    */            
    char FAR *vdxcc/*,*/            /* CC DX               5 bytes    */        
/*  char FAR *vmajop3*/           /* 3rd significant SG  4 bytes    */          
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF06CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL  HADF06CS                                           
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL  HADF06CS                                           
#else                                                                           
short IRPEXTCALL HADF06CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf07cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf07c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf07c1                                            
#else                                                                           
short IRPEXTCALL hadf07c1                                                       
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper  7.0---- */            
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  4 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  5 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  5 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  4 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  4 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  4 bytes    */        
       char  FAR *vdxcc,            /* CC DX               5 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  4 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D70CTL                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D70CTL                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D70CTL                                               
#else                                                                           
 void IRPEXTCALL  D70CTL                                                        
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper  7.0---- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
    char FAR *vmajop,           /* 1st significant SG  4 bytes    */            
    char FAR *vadx,             /* 1st significant DX  5 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  5 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  4 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  4 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  4 bytes    */            
    char FAR *vdxcc,            /* CC DX               5 bytes    */            
    char FAR *vmajop3           /* 3rd significant SG  4 bytes    */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF07CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL  HADF07CS                                           
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL  HADF07CS                                           
#else                                                                           
short IRPEXTCALL HADF07CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf08cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf08c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf08c1                                            
#else                                                                           
short IRPEXTCALL hadf08c1                                                       
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper  8.0---- */            
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  4 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  5 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  5 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  4 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  4 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  4 bytes    */        
       char  FAR *vdxcc,            /* CC DX               5 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  4 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D80CTL                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D80CTL                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D80CTL                                               
#else                                                                           
 void  IRPEXTCALL D80CTL                                                        
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper  8.0---- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
    char FAR *vmajop,           /* 1st significant SG  4 bytes    */            
    char FAR *vadx,             /* 1st significant DX  5 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  5 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  4 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  4 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  4 bytes    */            
    char FAR *vdxcc,            /* CC DX               5 bytes    */            
    char FAR *vmajop3           /* 3rd significant SG  4 bytes    */            
          );                                                                    
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF08CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF08CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF08CS                                            
#else                                                                           
short IRPEXTCALL HADF08CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf09cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf09c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf09c1                                            
#else                                                                           
short IRPEXTCALL hadf09c1                                                       
#endif                                                                          
                                                                                
          (                     /* ------Federal Grouper  9.0---- */            
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  4 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  5 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  5 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  4 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  4 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  4 bytes    */        
       char  FAR *vdxcc,            /* CC DX               5 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  4 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D90CTL                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D90CTL                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D90CTL                                               
#else                                                                           
 void  IRPEXTCALL D90CTL                                                        
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper  9.0---- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
    char FAR *vmajop,           /* 1st significant SG  4 bytes    */            
    char FAR *vadx,             /* 1st significant DX  5 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  5 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  4 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  4 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  4 bytes    */            
    char FAR *vdxcc,            /* CC DX               5 bytes    */            
    char FAR *vmajop3           /* 3rd significant SG  4 bytes    */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF09CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF09CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF09CS                                            
#else                                                                           
short IRPEXTCALL HADF09CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf10cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf10c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf10c1                                            
#else                                                                           
short IRPEXTCALL hadf10c1                                                       
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper 10.0---- */            
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  4 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  5 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  5 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  4 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  4 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  4 bytes    */        
       char  FAR *vdxcc,            /* CC DX               5 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  4 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
                                                                                
       );                                                                       
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D100CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D100CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D100CN                                               
#else                                                                           
 void  IRPEXTCALL D100CN                                                        
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper 10.0---- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
    char FAR *vmajop,           /* 1st significant SG  4 bytes    */            
    char FAR *vadx,             /* 1st significant DX  5 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  5 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  4 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  4 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  4 bytes    */            
    char FAR *vdxcc,            /* CC DX               5 bytes    */            
    char FAR *vmajop3           /* 3rd significant SG  4 bytes    */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF10CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF10CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF10CS                                            
#else                                                                           
short IRPEXTCALL HADF10CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf11cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf11c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf11c1                                            
#else                                                                           
short IRPEXTCALL hadf11c1                                                       
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper 11.0---- */            
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  7 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  6 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  6 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  7 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  7 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */        
       char  FAR *vdxcc,            /* CC DX               6 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  7 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D110CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D110CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D110CN                                               
#else                                                                           
 void  IRPEXTCALL D110CN                                                        
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper 11.0---- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
    char FAR *vmajop,           /* 1st significant SG  7 bytes    */            
    char FAR *vadx,             /* 1st significant DX  6 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  6 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  7 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  7 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */            
    char FAR *vdxcc,            /* CC DX               6 bytes    */            
    char FAR *vmajop3           /* 3rd significant SG  7 bytes    */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF11CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF11CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF11CS                                            
#else                                                                           
short IRPEXTCALL HADF11CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf12cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf12c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf12c1                                            
#else                                                                           
short IRPEXTCALL hadf12c1                                                       
#endif                                                                          
                (     /* ------Federal Grouper 12.0---- */                      
                                                                                
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  7 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  6 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  6 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  7 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  7 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */        
       char  FAR *vdxcc,            /* CC DX               6 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  7 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D120CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D120CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D120CN                                               
#else                                                                           
 void  IRPEXTCALL D120CN                                                        
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper 12.0---- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
    char FAR *vmajop,           /* 1st significant SG  7 bytes    */            
    char FAR *vadx,             /* 1st significant DX  6 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  6 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  7 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  7 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */            
    char FAR *vdxcc,            /* CC DX               6 bytes    */            
    char FAR *vmajop3           /* 3rd significant SG  7 bytes    */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF12CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF12CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF12CS                                            
#else                                                                           
short IRPEXTCALL HADF12CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf13cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf13c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf13c1                                            
#else                                                                           
short IRPEXTCALL hadf13c1                                                       
#endif                                                                          
                (     /* ------Federal Grouper 13.0---- */                      
                                                                                
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  7 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  6 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  6 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  7 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  7 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */        
       char  FAR *vdxcc,            /* CC DX               6 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  7 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D130CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D130CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D130CN                                               
#else                                                                           
 void  IRPEXTCALL D130CN                                                        
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper 12.0---- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
    char FAR *vmajop,           /* 1st significant SG  7 bytes    */            
    char FAR *vadx,             /* 1st significant DX  6 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  6 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  7 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  7 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */            
    char FAR *vdxcc,            /* CC DX               6 bytes    */            
    char FAR *vmajop3           /* 3rd significant SG  7 bytes    */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF13CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF13CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF13CS                                            
#else                                                                           
short IRPEXTCALL HADF13CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf14cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf14c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf14c1                                            
#else                                                                           
short IRPEXTCALL hadf14c1                                                       
#endif                                                                          
                (     /* ------Federal Grouper 14.0---- */                      
                                                                                
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  7 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  6 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  6 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  7 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  7 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */        
       char  FAR *vdxcc,            /* CC DX               6 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  7 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D140CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D140CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D140CN                                               
#else                                                                           
 void  IRPEXTCALL D140CN                                                        
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper 12.0---- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
    char FAR *vmajop,           /* 1st significant SG  7 bytes    */            
    char FAR *vadx,             /* 1st significant DX  6 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  6 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  7 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  7 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */            
    char FAR *vdxcc,            /* CC DX               6 bytes    */            
    char FAR *vmajop3           /* 3rd significant SG  7 bytes    */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF14CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF14CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF14CS                                            
#else                                                                           
short IRPEXTCALL HADF14CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf15cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf15c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf15c1                                            
#else                                                                           
short IRPEXTCALL hadf15c1                                                       
#endif                                                                          
                (     /* ------Federal Grouper 15.0---- */                      
                                                                                
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  7 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  6 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  6 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  7 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  7 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */        
       char  FAR *vdxcc,            /* CC DX               6 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  7 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D150CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D150CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D150CN                                               
#else                                                                           
 void  IRPEXTCALL D150CN                                                        
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper 12.0---- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
    char FAR *vmajop,           /* 1st significant SG  7 bytes    */            
    char FAR *vadx,             /* 1st significant DX  6 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  6 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  7 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  7 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */            
    char FAR *vdxcc,            /* CC DX               6 bytes    */            
    char FAR *vmajop3           /* 3rd significant SG  7 bytes    */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF15CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF15CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF15CS                                            
#else                                                                           
short IRPEXTCALL HADF15CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf16cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf16c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf16c1                                            
#else                                                                           
short IRPEXTCALL hadf16c1                                                       
#endif                                                                          
                (     /* ------Federal Grouper 16.0---- */                      
                                                                                
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  7 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  6 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  6 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  7 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  7 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */        
       char  FAR *vdxcc,            /* CC DX               6 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  7 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D160CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D160CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D160CN                                               
#else                                                                           
 void  IRPEXTCALL D160CN                                                        
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper 12.0---- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
    char FAR *vmajop,           /* 1st significant SG  7 bytes    */            
    char FAR *vadx,             /* 1st significant DX  6 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  6 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  7 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  7 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */            
    char FAR *vdxcc,            /* CC DX               6 bytes    */            
    char FAR *vmajop3           /* 3rd significant SG  7 bytes    */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF16CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF16CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF16CS                                            
#else                                                                           
short IRPEXTCALL HADF16CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf17cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf17c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf17c1                                            
#else                                                                           
short IRPEXTCALL hadf17c1                                                       
#endif                                                                          
                (     /* ------Federal Grouper 16.0---- */                      
                                                                                
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  7 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  6 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  6 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  7 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  7 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */        
       char  FAR *vdxcc,            /* CC DX               6 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  7 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D170CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D170CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D170CN                                               
#else                                                                           
 void  IRPEXTCALL D170CN                                                        
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper 12.0---- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
    char FAR *vmajop,           /* 1st significant SG  7 bytes    */            
    char FAR *vadx,             /* 1st significant DX  6 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  6 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  7 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  7 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */            
    char FAR *vdxcc,            /* CC DX               6 bytes    */            
    char FAR *vmajop3           /* 3rd significant SG  7 bytes    */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF17CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF17CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF17CS                                            
#else                                                                           
short IRPEXTCALL HADF17CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf18cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf18c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf18c1                                            
#else                                                                           
short IRPEXTCALL hadf18c1                                                       
#endif                                                                          
                (     /* ------Federal Grouper 16.0---- */                      
                                                                                
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  7 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  6 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  6 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  7 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  7 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */        
       char  FAR *vdxcc,            /* CC DX               6 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  7 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D180CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D180CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D180CN                                               
#else                                                                           
 void  IRPEXTCALL D180CN                                                        
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper 12.0---- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
    char FAR *vmajop,           /* 1st significant SG  7 bytes    */            
    char FAR *vadx,             /* 1st significant DX  6 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  6 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  7 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  7 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */            
    char FAR *vdxcc,            /* CC DX               6 bytes    */            
    char FAR *vmajop3           /* 3rd significant SG  7 bytes    */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF18CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF18CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF18CS                                            
#else                                                                           
short IRPEXTCALL HADF18CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf19cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf19c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf19c1                                            
#else                                                                           
short IRPEXTCALL hadf19c1                                                       
#endif                                                                          
                (     /* ------Federal Grouper 16.0---- */                      
                                                                                
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  7 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  6 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  6 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  7 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  7 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */        
       char  FAR *vdxcc,            /* CC DX               6 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  7 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D190CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D190CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D190CN                                               
#else                                                                           
 void  IRPEXTCALL D190CN                                                        
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper 12.0---- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
    char FAR *vmajop,           /* 1st significant SG  7 bytes    */            
    char FAR *vadx,             /* 1st significant DX  6 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  6 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  7 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  7 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */            
    char FAR *vdxcc,            /* CC DX               6 bytes    */            
    char FAR *vmajop3           /* 3rd significant SG  7 bytes    */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF19CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF19CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF19CS                                            
#else                                                                           
short IRPEXTCALL HADF19CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf20cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf20c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf20c1                                            
#else                                                                           
short IRPEXTCALL hadf20c1                                                       
#endif                                                                          
                (     /* ------Federal Grouper 16.0---- */                      
                                                                                
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  7 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  6 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  6 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  7 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  7 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */        
       char  FAR *vdxcc,            /* CC DX               6 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  7 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D200CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D200CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D200CN                                               
#else                                                                           
 void  IRPEXTCALL D200CN                                                        
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper 12.0---- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
    char FAR *vmajop,           /* 1st significant SG  7 bytes    */            
    char FAR *vadx,             /* 1st significant DX  6 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  6 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  7 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  7 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */            
    char FAR *vdxcc,            /* CC DX               6 bytes    */            
    char FAR *vmajop3           /* 3rd significant SG  7 bytes    */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF20CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF20CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF20CS                                            
#else                                                                           
short IRPEXTCALL HADF20CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf21cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf21c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf21c1                                            
#else                                                                           
short IRPEXTCALL hadf21c1                                                       
#endif                                                                          
                (     /* ------Federal Grouper 16.0---- */                      
                                                                                
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  7 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  6 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  6 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  7 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  7 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */        
       char  FAR *vdxcc,            /* CC DX               6 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  7 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D210CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D210CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D210CN                                               
#else                                                                           
 void  IRPEXTCALL D210CN                                                        
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper 12.0---- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
    char FAR *vmajop,           /* 1st significant SG  7 bytes    */            
    char FAR *vadx,             /* 1st significant DX  6 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  6 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  7 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  7 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */            
    char FAR *vdxcc,            /* CC DX               6 bytes    */            
    char FAR *vmajop3           /* 3rd significant SG  7 bytes    */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF21CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF21CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF21CS                                            
#else                                                                           
short IRPEXTCALL HADF21CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf22cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf22c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf22c1                                            
#else                                                                           
short IRPEXTCALL hadf22c1                                                       
#endif                                                                          
                (     /* ------Federal Grouper 16.0---- */                      
                                                                                
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  7 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  6 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  6 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  7 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  7 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */        
       char  FAR *vdxcc,            /* CC DX               6 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  7 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D220CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D220CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D220CN                                               
#else                                                                           
 void  IRPEXTCALL D220CN                                                        
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper 12.0---- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
    char FAR *vmajop,           /* 1st significant SG  7 bytes    */            
    char FAR *vadx,             /* 1st significant DX  6 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  6 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  7 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  7 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */            
    char FAR *vdxcc,            /* CC DX               6 bytes    */            
    char FAR *vmajop3           /* 3rd significant SG  7 bytes    */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF22CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF22CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF22CS                                            
#else                                                                           
short IRPEXTCALL HADF22CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf23cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf23c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf23c1                                            
#else                                                                           
short IRPEXTCALL hadf23c1                                                       
#endif                                                                          
                (     /* ------Federal Grouper 16.0---- */                      
                                                                                
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  7 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  6 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  6 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  7 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  7 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */        
       char  FAR *vdxcc,            /* CC DX               6 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  7 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D230CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D230CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D230CN                                               
#else                                                                           
 void  IRPEXTCALL D230CN                                                        
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper 12.0---- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
    char FAR *vmajop,           /* 1st significant SG  7 bytes    */            
    char FAR *vadx,             /* 1st significant DX  6 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  6 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  7 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  7 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */            
    char FAR *vdxcc,            /* CC DX               6 bytes    */            
    char FAR *vmajop3           /* 3rd significant SG  7 bytes    */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF23CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF23CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF23CS                                            
#else                                                                           
short IRPEXTCALL HADF23CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf24cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf24c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf24c1                                            
#else                                                                           
short IRPEXTCALL hadf24c1                                                       
#endif                                                                          
                (     /* ------Federal Grouper 16.0---- */                      
                                                                                
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  7 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  6 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  6 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  7 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  7 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */        
       char  FAR *vdxcc,            /* CC DX               6 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  7 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D240CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D240CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D240CN                                               
#else                                                                           
 void  IRPEXTCALL D240CN                                                        
#endif                                                                          
                                                                                
         (                      /* ------Federal Grouper 12.0---- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
    char FAR *vmajop,           /* 1st significant SG  7 bytes    */            
    char FAR *vadx,             /* 1st significant DX  6 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  6 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  7 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  7 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */            
    char FAR *vdxcc,            /* CC DX               6 bytes    */            
    char FAR *vmajop3           /* 3rd significant SG  7 bytes    */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF24CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF24CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF24CS                                            
#else                                                                           
short IRPEXTCALL HADF24CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf25cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf25c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf25c1                                            
#else                                                                           
short IRPEXTCALL hadf25c1                                                       
#endif                                                                          
                (     /* ------Federal Grouper 25.0---- */                      
                                                                                
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  7 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  6 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  6 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  7 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  7 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */        
       char  FAR *vdxcc,            /* CC DX               6 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  7 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D250CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D250CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D250CN                                               
#else                                                                           
 void  IRPEXTCALL D250CN                                                        
#endif                                                                          
                                                                                
         (       /* ------Federal Grouper 25.0---- */                           
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
   char FAR * xvdx_ptr,         /* to array of 50 DX x 8 bytes ea */            
   int  FAR * xvndx,            /* number dx (diagnoses)          */            
   char FAR * xvsg_ptr,         /* to array of 50 SG x 7 bytes ea */            
   int  FAR * xvnsg,            /* number sg (procedures)         */            
   char FAR * xvage,            /* age - 3 char                   */            
   char FAR * xvsex,            /* sex - 1 char                   */            
   char FAR * xvdstat,          /* discharge status - 2 char      */            
   char FAR * xvpoalog,         /* POA logic indicator - 1 char   */            
   char FAR * xvadate,          /* admission date YYYYMMDD        */            
   char FAR * xvddate,          /* discharge date YYYYMMDD        */            
   char FAR * xvpdate,          /* procedure dates - max 50       */            
                 /* ------  output arguments ----- */                           
   char FAR * xvrtc,            /* RTC - 2 char                   */            
   char FAR * xvmdc,            /* MDC - 2 char                   */            
   char FAR * xvdrg,            /* DRG - 4 char                   */            
   char FAR * xvgprflgs,        /* grouper flags - 5 char         */            
   char FAR * xvdxflags,        /* diag flags - 50*6 = 300 char   */            
   char FAR * xvsgflags,        /* proc flags - 50*7 = 350 char   */            
   char FAR * xvbuff            /* additional info - 24 char      */            
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF25CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF25CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF25CS                                            
#else                                                                           
short IRPEXTCALL HADF25CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf52cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf52c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf52c1                                            
#else                                                                           
short IRPEXTCALL hadf52c1                                                       
#endif                                                                          
                (     /* ------Federal Grouper 25.1---- */                      
                                                                                
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 6 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 7 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
       char  FAR *vmajop,           /* 1st significant SG  7 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  6 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  6 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  7 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  7 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  7 bytes    */        
       char  FAR *vdxcc,            /* CC DX               6 bytes    */        
       char  FAR *vmajop3,          /* 3rd significant SG  7 bytes    */        
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL D251CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC void IRPEXTCALL D251CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL D251CN                                               
#else                                                                           
 void  IRPEXTCALL D251CN                                                        
#endif                                                                          
                                                                                
         (       /* ------Federal Grouper 25.1---- */                           
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
   char FAR * xvdx_ptr,         /* to array of 50 DX x 8 bytes ea */            
   int  FAR * xvndx,            /* number dx (diagnoses)          */            
   char FAR * xvsg_ptr,         /* to array of 50 SG x 7 bytes ea */            
   int  FAR * xvnsg,            /* number sg (procedures)         */            
   char FAR * xvage,            /* age - 3 char                   */            
   char FAR * xvsex,            /* sex - 1 char                   */            
   char FAR * xvdstat,          /* discharge status - 2 char      */            
   char FAR * xvpoalog,         /* POA logic indicator - 1 char   */            
   char FAR * xvadate,          /* admission date YYYYMMDD        */            
   char FAR * xvddate,          /* discharge date YYYYMMDD        */            
   char FAR * xvpdate,          /* procedure dates - max 50       */            
                 /* ------  output arguments ----- */                           
   char FAR * xvrtc,            /* RTC - 2 char                   */            
   char FAR * xvmdc,            /* MDC - 2 char                   */            
   char FAR * xvdrg,            /* DRG - 4 char                   */            
   char FAR * xvgprflgs,        /* grouper flags - 5 char         */            
   char FAR * xvdxflags,        /* diag flags - 50*6 = 300 char   */            
   char FAR * xvsgflags,        /* proc flags - 50*7 = 350 char   */            
   char FAR * xvbuff            /* additional info - 24 char      */            
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF52CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF52CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF52CS                                            
#else                                                                           
short IRPEXTCALL HADF52CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf26cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf26c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf26c1                                            
#else                                                                           
short IRPEXTCALL hadf26c1                                                       
#endif                                                                          
(     /* ------Federal Grouper 26---- */                                        
                                                                                
                 /* -------- input arguments ----- */                           
       short grpfunc,               /* grouper function:                        
                                     *   0 = group,                             
                                     *   1 = free grouper storage               
                                     */                                         
       short vndx,                  /* number diagnoses  50 MAX      */         
       short vnsg,                  /* number procedures 50 MAX      */         
       char  FAR *vdx_ptr,          /* array of 50 DX x 8 chars each            
                                     * left justified, blank padded             
                                     * rightmost char is POA indicator          
                                     */                                         
       char  FAR *vsg_ptr,          /* array of 50 SG x 7 chars each            
                                     * left justified, blank padded             
                                     */                                         
       char  FAR *vage,             /* age - 3 chars 000-124          */        
       char  FAR *vsex,             /* sex - 1 char 1,m,M or 2,f,F    */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 chars    */        
       char  FAR *vpoa_logic,       /* 1 char                                   
                                     * X=No POA processing                      
                                     * Z=POA processing                         
                                     */                                         
       char  FAR *vadmit_date,      /* admit date 8 chars YYYYMMDD     */       
       char  FAR *vdisch_date,      /* discharge date 8 chars YYYYMMDD */       
       char  FAR *vsg_dates,        /* array of 50 procedure dates              
                                     * 8 chars each YYYYMMDD                    
                                     */                                         
                                                                                
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 4 chars 0001-0999 */        
       char  FAR *vmdc,             /* assigned MDC 2 chars 00-25     */        
       char  FAR *vrtc,             /* return code  2 chars 00-15     */        
       char  FAR *vmajop,           /* 1st significant OR SG  7 chars */        
       char  FAR *vadx,             /* 1st significant DX  8 chars    */        
       char  FAR *vsdx,             /* 2nd significant DX  8 chars    */        
       char  FAR *vers,             /* grouper version 11 chars                 
                                     * HAFvv-mm/yy                              
                                     */                                         
       char  FAR *vmajop2,          /* 2nd significant OR SG  7 chars */        
       char  FAR *vminop,           /* 1st signif. Non-OR SG  7 chars */        
       char  FAR *vminop2,          /* 2nd signif. Non-OR SG  7 chars */        
       char  FAR *vdxcc,            /* CC DX 8 chars                  */        
       char  FAR *vmajop3,          /* 3rd significant OR SG  7 chars */        
       char  FAR *vdxcctab,         /* array of 50 chars                        
                                     * one for each input DX                    
                                     * 0 = DX is not a CC or MCC                
                                     * 1 = DX is an MCC                         
                                     * 2 = DX is a CC                           
                                     * blank = Principal DX or                  
                                     *         Invalid DX                       
                                     */                                         
       char  FAR * vdrg_initial,    /* initial DRG 4 chars 0001-0999 */         
       char  FAR * vdrg_cc_flag,    /* 1 char                                   
                                     * 0=DRG based on no CC or MCC              
                                     * 1=DRG based on MCC                       
                                     * 2=DRG based on CC                        
                                     */                                         
       char  FAR * vdx_flags,       /* Diagnosis Flags Table                    
                                     * array of 50 DX x 6 chars each            
                                     * [n][0] Diagnosis Validity                
                                     *   0=diagnosis is invalid                 
                                     *   1=diagnosis is valid                   
                                     * [n][1] Diagnosis Affects DRG             
                                     *   0=DX did not affect the DRG            
                                     *   1=DX affected initial DRG only         
                                     *   2=DX affected final DRG only           
                                     *   3=DX affected both initial             
                                     *     and final DRG                        
                                     * [n][2] CC/MCC Categorization             
                                     *   0 = DX is not a CC or MCC              
                                     *       for initial or final DRG           
                                     *   1 = DX is an MCC                       
                                     *       for both initial and final DRG     
                                     *   2 = DX is a CC                         
                                     *       for both initial and final DRG     
                                     *   3 = DX is an MCC for inital DRG        
                                     *       DX is not a CC/MCC for final DRG   
                                     *   4 = DX is a CC for initial DRG         
                                     *       DX is not a CC/MCC for init. DRG   
                                     * [n][3] For future use                    
                                     * [n][4] For future use                    
                                     * [n][5] HAC/POA Status                    
                                     *   0=POA processing selected and          
                                     *     not a HAC                            
                                     *     or                                   
                                     *     POA processing selected and          
                                     *     a HAC with a valid POA indic.        
                                     *   1=POA processing selected and          
                                     *     a HAC with invalid POA indic.        
                                     *     or                                   
                                     *     POA processing not selected          
                                     */                                         
       char  FAR * vsg_flags,       /* Procedure Flags Table                    
                                     * array of 50 SG x 7 chars each            
                                     * [n][0] Procedure Validity                
                                     *   0=procedure is invalid                 
                                     *   1=procedure is valid                   
                                     * [n][1] Procedure Affects DRG             
                                     *   0=proc did not affect the DRG          
                                     *   1=proc affected initial DRG only       
                                     *   2=proc affected final DRG only         
                                     *   3=proc affected both initial           
                                     *     and final DRG                        
                                     * [n][2] OR/Non-OR Procedure               
                                     *   0=not an OR procedure                  
                                     *   1=operating room (OR) procedure        
                                     * [n][3] For future use                    
                                     * [n][4] For future use                    
                                     * [n][5] For future use                    
                                     * [n][6] For future use                    
                                     */                                         
       char  FAR * vmed_surg_ind_init,  /* Initial DRG Medical/Surgical         
                                         * Indicator 1 char                     
                                         * 0=RTC is non-zero                    
                                         * 1=Medical Initial DRG                
                                         * 2=Surgical Initial DRG               
                                         */                                     
       char  FAR * vmed_surg_ind_final  /* Final DRG Medical/Surgical           
                                         * Indicator 1 char                     
                                         * 0=RTC is non-zero                    
                                         * 1=Medical Final DRG                  
                                         * 2=Surgical Final DRG                 
                                         */                                     
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF26CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF26CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF26CS                                            
#else                                                                           
short IRPEXTCALL HADF26CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp2_Data *hgp);                                                    
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf27cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf27c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf27c1                                            
#else                                                                           
short IRPEXTCALL hadf27c1                                                       
#endif                                                                          
(     /* ------Federal Grouper 27---- */                                        
                                                                                
                 /* -------- input arguments ----- */                           
       short grpfunc,               /* grouper function:                        
                                     *   0 = group,                             
                                     *   1 = free grouper storage               
                                     */                                         
       short vndx,                  /* number diagnoses  50 MAX      */         
       short vnsg,                  /* number procedures 50 MAX      */         
       char  FAR *vdx_ptr,          /* array of 50 DX x 8 chars each            
                                     * left justified, blank padded             
                                     * rightmost char is POA indicator          
                                     */                                         
       char  FAR *vsg_ptr,          /* array of 50 SG x 7 chars each            
                                     * left justified, blank padded             
                                     */                                         
       char  FAR *vage,             /* age - 3 chars 000-124          */        
       char  FAR *vsex,             /* sex - 1 char 1,m,M or 2,f,F    */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 chars    */        
       char  FAR *vpoa_logic,       /* 1 char                                   
                                     * X=No POA processing                      
                                     * Z=POA processing                         
                                     */                                         
       char  FAR *vadmit_date,      /* admit date 8 chars YYYYMMDD     */       
       char  FAR *vdisch_date,      /* discharge date 8 chars YYYYMMDD */       
       char  FAR *vsg_dates,        /* array of 50 procedure dates              
                                     * 8 chars each YYYYMMDD                    
                                     */                                         
                                                                                
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 4 chars 0001-0999 */        
       char  FAR *vmdc,             /* assigned MDC 2 chars 00-25     */        
       char  FAR *vrtc,             /* return code  2 chars 00-15     */        
       char  FAR *vmajop,           /* 1st significant OR SG  7 chars */        
       char  FAR *vadx,             /* 1st significant DX  8 chars    */        
       char  FAR *vsdx,             /* 2nd significant DX  8 chars    */        
       char  FAR *vers,             /* grouper version 11 chars                 
                                     * HAFvv-mm/yy                              
                                     */                                         
       char  FAR *vmajop2,          /* 2nd significant OR SG  7 chars */        
       char  FAR *vminop,           /* 1st signif. Non-OR SG  7 chars */        
       char  FAR *vminop2,          /* 2nd signif. Non-OR SG  7 chars */        
       char  FAR *vdxcc,            /* CC DX 8 chars                  */        
       char  FAR *vmajop3,          /* 3rd significant OR SG  7 chars */        
       char  FAR *vdxcctab,         /* array of 50 chars                        
                                     * one for each input DX                    
                                     * 0 = DX is not a CC or MCC                
                                     * 1 = DX is an MCC                         
                                     * 2 = DX is a CC                           
                                     * blank = Principal DX or                  
                                     *         Invalid DX                       
                                     */                                         
       char  FAR * vdrg_initial,    /* initial DRG 4 chars 0001-0999 */         
       char  FAR * vdrg_cc_flag,    /* 1 char                                   
                                     * 0=DRG based on no CC or MCC              
                                     * 1=DRG based on MCC                       
                                     * 2=DRG based on CC                        
                                     */                                         
       char  FAR * vdx_flags,       /* Diagnosis Flags Table                    
                                     * array of 50 DX x 6 chars each            
                                     * [n][0] Diagnosis Validity                
                                     *   0=diagnosis is invalid                 
                                     *   1=diagnosis is valid                   
                                     * [n][1] Diagnosis Affects DRG             
                                     *   0=DX did not affect the DRG            
                                     *   1=DX affected initial DRG only         
                                     *   2=DX affected final DRG only           
                                     *   3=DX affected both initial             
                                     *     and final DRG                        
                                     * [n][2] CC/MCC Categorization             
                                     *   0 = DX is not a CC or MCC              
                                     *       for initial or final DRG           
                                     *   1 = DX is an MCC                       
                                     *       for both initial and final DRG     
                                     *   2 = DX is a CC                         
                                     *       for both initial and final DRG     
                                     *   3 = DX is an MCC for inital DRG        
                                     *       DX is not a CC/MCC for final DRG   
                                     *   4 = DX is a CC for initial DRG         
                                     *       DX is not a CC/MCC for init. DRG   
                                     * [n][3] For future use                    
                                     * [n][4] For future use                    
                                     * [n][5] HAC Status                        
                                     *   0=HAC not applicable                   
                                     *   1=HAC criteria met                     
                                     *   2=HAC criteria not met                 
                                     */                                         
       char  FAR * vsg_flags,       /* Procedure Flags Table                    
                                     * array of 50 SG x 7 chars each            
                                     * [n][0] Procedure Validity                
                                     *   0=procedure is invalid                 
                                     *   1=procedure is valid                   
                                     * [n][1] Procedure Affects DRG             
                                     *   0=proc did not affect the DRG          
                                     *   1=proc affected initial DRG only       
                                     *   2=proc affected final DRG only         
                                     *   3=proc affected both initial           
                                     *     and final DRG                        
                                     * [n][2] OR/Non-OR Procedure               
                                     *   0=not an OR procedure                  
                                     *   1=operating room (OR) procedure        
                                     * [n][3] For future use                    
                                     * [n][4] For future use                    
                                     * [n][5] For future use                    
                                     * [n][6] For future use                    
                                     */                                         
       char  FAR * vmed_surg_ind_init,  /* Initial DRG Medical/Surgical         
                                         * Indicator 1 char                     
                                         * 0=RTC is non-zero                    
                                         * 1=Medical Initial DRG                
                                         * 2=Surgical Initial DRG               
                                         */                                     
       char  FAR * vmed_surg_ind_final  /* Final DRG Medical/Surgical           
                                         * Indicator 1 char                     
                                         * 0=RTC is non-zero                    
                                         * 1=Medical Final DRG                  
                                         * 2=Surgical Final DRG                 
                                         */                                     
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF27CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF27CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF27CS                                            
#else                                                                           
short IRPEXTCALL HADF27CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp2_Data *hgp);                                                    
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf28cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf28c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf28c1                                            
#else                                                                           
short IRPEXTCALL hadf28c1                                                       
#endif                                                                          
(     /* ------Federal Grouper 28---- */                                        
                                                                                
                 /* -------- input arguments ----- */                           
       short grpfunc,               /* grouper function:                        
                                     *   0 = group,                             
                                     *   1 = free grouper storage               
                                     */                                         
       short vndx,                  /* number diagnoses  50 MAX      */         
       short vnsg,                  /* number procedures 50 MAX      */         
       char  FAR *vdx_ptr,          /* array of 50 DX x 8 chars each            
                                     * left justified, blank padded             
                                     * rightmost char is POA indicator          
                                     */                                         
       char  FAR *vsg_ptr,          /* array of 50 SG x 7 chars each            
                                     * left justified, blank padded             
                                     */                                         
       char  FAR *vage,             /* age - 3 chars 000-124          */        
       char  FAR *vsex,             /* sex - 1 char 1,m,M or 2,f,F    */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 chars    */        
       char  FAR *vpoa_logic,       /* 1 char                                   
                                     * X=No POA processing                      
                                     * Z=POA processing                         
                                     */                                         
       char  FAR *vadmit_date,      /* admit date 8 chars YYYYMMDD     */       
       char  FAR *vdisch_date,      /* discharge date 8 chars YYYYMMDD */       
       char  FAR *vsg_dates,        /* array of 50 procedure dates              
                                     * 8 chars each YYYYMMDD                    
                                     */                                         
                                                                                
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 4 chars 0001-0999 */        
       char  FAR *vmdc,             /* assigned MDC 2 chars 00-25     */        
       char  FAR *vrtc,             /* return code  2 chars 00-15     */        
       char  FAR *vmajop,           /* 1st significant OR SG  7 chars */        
       char  FAR *vadx,             /* 1st significant DX  8 chars    */        
       char  FAR *vsdx,             /* 2nd significant DX  8 chars    */        
       char  FAR *vers,             /* grouper version 11 chars                 
                                     * HAFvv-mm/yy                              
                                     */                                         
       char  FAR *vmajop2,          /* 2nd significant OR SG  7 chars */        
       char  FAR *vminop,           /* 1st signif. Non-OR SG  7 chars */        
       char  FAR *vminop2,          /* 2nd signif. Non-OR SG  7 chars */        
       char  FAR *vdxcc,            /* CC DX 8 chars                  */        
       char  FAR *vmajop3,          /* 3rd significant OR SG  7 chars */        
       char  FAR *vdxcctab,         /* array of 50 chars                        
                                     * one for each input DX                    
                                     * 0 = DX is not a CC or MCC                
                                     * 1 = DX is an MCC                         
                                     * 2 = DX is a CC                           
                                     * blank = Principal DX or                  
                                     *         Invalid DX                       
                                     */                                         
       char  FAR * vdrg_initial,    /* initial DRG 4 chars 0001-0999 */         
       char  FAR * vdrg_cc_flag,    /* 1 char                                   
                                     * 0=DRG based on no CC or MCC              
                                     * 1=DRG based on MCC                       
                                     * 2=DRG based on CC                        
                                     */                                         
       char  FAR * vdx_flags,       /* Diagnosis Flags Table                    
                                     * array of 50 DX x 6 chars each            
                                     * [n][0] Diagnosis Validity                
                                     *   0=diagnosis is invalid                 
                                     *   1=diagnosis is valid                   
                                     * [n][1] Diagnosis Affects DRG             
                                     *   0=DX did not affect the DRG            
                                     *   1=DX affected initial DRG only         
                                     *   2=DX affected final DRG only           
                                     *   3=DX affected both initial             
                                     *     and final DRG                        
                                     * [n][2] CC/MCC Categorization             
                                     *   0 = DX is not a CC or MCC              
                                     *       for initial or final DRG           
                                     *   1 = DX is an MCC                       
                                     *       for both initial and final DRG     
                                     *   2 = DX is a CC                         
                                     *       for both initial and final DRG     
                                     *   3 = DX is an MCC for inital DRG        
                                     *       DX is not a CC/MCC for final DRG   
                                     *   4 = DX is a CC for initial DRG         
                                     *       DX is not a CC/MCC for init. DRG   
                                     * [n][3] For future use                    
                                     * [n][4] For future use                    
                                     * [n][5] HAC Status                        
                                     *   0=HAC not applicable                   
                                     *   1=HAC criteria met                     
                                     *   2=HAC criteria not met                 
                                     */                                         
       char  FAR * vsg_flags,       /* Procedure Flags Table                    
                                     * array of 50 SG x 7 chars each            
                                     * [n][0] Procedure Validity                
                                     *   0=procedure is invalid                 
                                     *   1=procedure is valid                   
                                     * [n][1] Procedure Affects DRG             
                                     *   0=proc did not affect the DRG          
                                     *   1=proc affected initial DRG only       
                                     *   2=proc affected final DRG only         
                                     *   3=proc affected both initial           
                                     *     and final DRG                        
                                     * [n][2] OR/Non-OR Procedure               
                                     *   0=not an OR procedure                  
                                     *   1=operating room (OR) procedure        
                                     * [n][3] For future use                    
                                     * [n][4] For future use                    
                                     * [n][5] For future use                    
                                     * [n][6] For future use                    
                                     */                                         
       char  FAR * vmed_surg_ind_init,  /* Initial DRG Medical/Surgical         
                                         * Indicator 1 char                     
                                         * 0=RTC is non-zero                    
                                         * 1=Medical Initial DRG                
                                         * 2=Surgical Initial DRG               
                                         */                                     
       char  FAR * vmed_surg_ind_final  /* Final DRG Medical/Surgical           
                                         * Indicator 1 char                     
                                         * 0=RTC is non-zero                    
                                         * 1=Medical Final DRG                  
                                         * 2=Surgical Final DRG                 
                                         */                                     
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF28CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF28CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF28CS                                            
#else                                                                           
short IRPEXTCALL HADF28CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp2_Data *hgp);                                                    
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf29cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf29c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf29c1                                            
#else                                                                           
short IRPEXTCALL hadf29c1                                                       
#endif                                                                          
(     /* ------Federal Grouper 29---- */                                        
                                                                                
                 /* -------- input arguments ----- */                           
       short grpfunc,               /* grouper function:                        
                                     *   0 = group,                             
                                     *   1 = free grouper storage               
                                     */                                         
       short vndx,                  /* number diagnoses  50 MAX      */         
       short vnsg,                  /* number procedures 50 MAX      */         
       char  FAR *vdx_ptr,          /* array of 50 DX x 8 chars each            
                                     * left justified, blank padded             
                                     * rightmost char is POA indicator          
                                     */                                         
       char  FAR *vsg_ptr,          /* array of 50 SG x 7 chars each            
                                     * left justified, blank padded             
                                     */                                         
       char  FAR *vage,             /* age - 3 chars 000-124          */        
       char  FAR *vsex,             /* sex - 1 char 1,m,M or 2,f,F    */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 chars    */        
       char  FAR *vpoa_logic,       /* 1 char                                   
                                     * X=No POA processing                      
                                     * Z=POA processing                         
                                     */                                         
       char  FAR *vadmit_date,      /* admit date 8 chars YYYYMMDD     */       
       char  FAR *vdisch_date,      /* discharge date 8 chars YYYYMMDD */       
       char  FAR *vsg_dates,        /* array of 50 procedure dates              
                                     * 8 chars each YYYYMMDD                    
                                     */                                         
                                                                                
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 4 chars 0001-0999 */        
       char  FAR *vmdc,             /* assigned MDC 2 chars 00-25     */        
       char  FAR *vrtc,             /* return code  2 chars 00-15     */        
       char  FAR *vmajop,           /* 1st significant OR SG  7 chars */        
       char  FAR *vadx,             /* 1st significant DX  8 chars    */        
       char  FAR *vsdx,             /* 2nd significant DX  8 chars    */        
       char  FAR *vers,             /* grouper version 11 chars                 
                                     * HAFvv-mm/yy                              
                                     */                                         
       char  FAR *vmajop2,          /* 2nd significant OR SG  7 chars */        
       char  FAR *vminop,           /* 1st signif. Non-OR SG  7 chars */        
       char  FAR *vminop2,          /* 2nd signif. Non-OR SG  7 chars */        
       char  FAR *vdxcc,            /* CC DX 8 chars                  */        
       char  FAR *vmajop3,          /* 3rd significant OR SG  7 chars */        
       char  FAR *vdxcctab,         /* array of 50 chars                        
                                     * one for each input DX                    
                                     * 0 = DX is not a CC or MCC                
                                     * 1 = DX is an MCC                         
                                     * 2 = DX is a CC                           
                                     * blank = Principal DX or                  
                                     *         Invalid DX                       
                                     */                                         
       char  FAR * vdrg_initial,    /* initial DRG 4 chars 0001-0999 */         
       char  FAR * vdrg_cc_flag,    /* 1 char                                   
                                     * 0=DRG based on no CC or MCC              
                                     * 1=DRG based on MCC                       
                                     * 2=DRG based on CC                        
                                     */                                         
       char  FAR * vdx_flags,       /* Diagnosis Flags Table                    
                                     * array of 50 DX x 6 chars each            
                                     * [n][0] Diagnosis Validity                
                                     *   0=diagnosis is invalid                 
                                     *   1=diagnosis is valid                   
                                     * [n][1] Diagnosis Affects DRG             
                                     *   0=DX did not affect the DRG            
                                     *   1=DX affected initial DRG only         
                                     *   2=DX affected final DRG only           
                                     *   3=DX affected both initial             
                                     *     and final DRG                        
                                     * [n][2] CC/MCC Categorization             
                                     *   0 = DX is not a CC or MCC              
                                     *       for initial or final DRG           
                                     *   1 = DX is an MCC                       
                                     *       for both initial and final DRG     
                                     *   2 = DX is a CC                         
                                     *       for both initial and final DRG     
                                     *   3 = DX is an MCC for inital DRG        
                                     *       DX is not a CC/MCC for final DRG   
                                     *   4 = DX is a CC for initial DRG         
                                     *       DX is not a CC/MCC for init. DRG   
                                     * [n][3] For future use                    
                                     * [n][4] For future use                    
                                     * [n][5] HAC Status                        
                                     *   0=HAC not applicable                   
                                     *   1=HAC criteria met                     
                                     *   2=HAC criteria not met                 
                                     */                                         
       char  FAR * vsg_flags,       /* Procedure Flags Table                    
                                     * array of 50 SG x 7 chars each            
                                     * [n][0] Procedure Validity                
                                     *   0=procedure is invalid                 
                                     *   1=procedure is valid                   
                                     * [n][1] Procedure Affects DRG             
                                     *   0=proc did not affect the DRG          
                                     *   1=proc affected initial DRG only       
                                     *   2=proc affected final DRG only         
                                     *   3=proc affected both initial           
                                     *     and final DRG                        
                                     * [n][2] OR/Non-OR Procedure               
                                     *   0=not an OR procedure                  
                                     *   1=operating room (OR) procedure        
                                     * [n][3] For future use                    
                                     * [n][4] For future use                    
                                     * [n][5] For future use                    
                                     * [n][6] For future use                    
                                     */                                         
       char  FAR * vmed_surg_ind_init,  /* Initial DRG Medical/Surgical         
                                         * Indicator 1 char                     
                                         * 0=RTC is non-zero                    
                                         * 1=Medical Initial DRG                
                                         * 2=Surgical Initial DRG               
                                         */                                     
       char  FAR * vmed_surg_ind_final  /* Final DRG Medical/Surgical           
                                         * Indicator 1 char                     
                                         * 0=RTC is non-zero                    
                                         * 1=Medical Final DRG                  
                                         * 2=Surgical Final DRG                 
                                         */                                     
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF29CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF29CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF29CS                                            
#else                                                                           
short IRPEXTCALL HADF29CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp2_Data *hgp);                                                    
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf30cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf30c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf30c1                                            
#else                                                                           
short IRPEXTCALL hadf30c1                                                       
#endif                                                                          
(     /* ------Federal Grouper 30---- */                                        
                                                                                
                 /* -------- input arguments ----- */                           
       short grpfunc,               /* grouper function:                        
                                     *   0 = group,                             
                                     *   1 = free grouper storage               
                                     */                                         
       short vndx,                  /* number diagnoses  50 MAX      */         
       short vnsg,                  /* number procedures 50 MAX      */         
       char  FAR *vdx_ptr,          /* array of 50 DX x 8 chars each            
                                     * left justified, blank padded             
                                     * rightmost char is POA indicator          
                                     */                                         
       char  FAR *vsg_ptr,          /* array of 50 SG x 7 chars each            
                                     * left justified, blank padded             
                                     */                                         
       char  FAR *vage,             /* age - 3 chars 000-124          */        
       char  FAR *vsex,             /* sex - 1 char 1,m,M or 2,f,F    */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 chars    */        
       char  FAR *vpoa_logic,       /* 1 char                                   
                                     * X=No POA processing                      
                                     * Z=POA processing                         
                                     */                                         
       char  FAR *vadmit_date,      /* admit date 8 chars YYYYMMDD     */       
       char  FAR *vdisch_date,      /* discharge date 8 chars YYYYMMDD */       
       char  FAR *vsg_dates,        /* array of 50 procedure dates              
                                     * 8 chars each YYYYMMDD                    
                                     */                                         
                                                                                
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 4 chars 0001-0999 */        
       char  FAR *vmdc,             /* assigned MDC 2 chars 00-25     */        
       char  FAR *vrtc,             /* return code  2 chars 00-15     */        
       char  FAR *vmajop,           /* 1st significant OR SG  7 chars */        
       char  FAR *vadx,             /* 1st significant DX  8 chars    */        
       char  FAR *vsdx,             /* 2nd significant DX  8 chars    */        
       char  FAR *vers,             /* grouper version 11 chars                 
                                     * HAFvv-mm/yy                              
                                     */                                         
       char  FAR *vmajop2,          /* 2nd significant OR SG  7 chars */        
       char  FAR *vminop,           /* 1st signif. Non-OR SG  7 chars */        
       char  FAR *vminop2,          /* 2nd signif. Non-OR SG  7 chars */        
       char  FAR *vdxcc,            /* CC DX 8 chars                  */        
       char  FAR *vmajop3,          /* 3rd significant OR SG  7 chars */        
       char  FAR *vdxcctab,         /* array of 50 chars                        
                                     * one for each input DX                    
                                     * 0 = DX is not a CC or MCC                
                                     * 1 = DX is an MCC                         
                                     * 2 = DX is a CC                           
                                     * blank = Principal DX or                  
                                     *         Invalid DX                       
                                     */                                         
       char  FAR * vdrg_initial,    /* initial DRG 4 chars 0001-0999 */         
       char  FAR * vdrg_cc_flag,    /* 1 char                                   
                                     * 0=DRG based on no CC or MCC              
                                     * 1=DRG based on MCC                       
                                     * 2=DRG based on CC                        
                                     */                                         
       char  FAR * vdx_flags,       /* Diagnosis Flags Table                    
                                     * array of 50 DX x 6 chars each            
                                     * [n][0] Diagnosis Validity                
                                     *   0=diagnosis is invalid                 
                                     *   1=diagnosis is valid                   
                                     * [n][1] Diagnosis Affects DRG             
                                     *   0=DX did not affect the DRG            
                                     *   1=DX affected initial DRG only         
                                     *   2=DX affected final DRG only           
                                     *   3=DX affected both initial             
                                     *     and final DRG                        
                                     * [n][2] CC/MCC Categorization             
                                     *   0 = DX is not a CC or MCC              
                                     *       for initial or final DRG           
                                     *   1 = DX is an MCC                       
                                     *       for both initial and final DRG     
                                     *   2 = DX is a CC                         
                                     *       for both initial and final DRG     
                                     *   3 = DX is an MCC for inital DRG        
                                     *       DX is not a CC/MCC for final DRG   
                                     *   4 = DX is a CC for initial DRG         
                                     *       DX is not a CC/MCC for init. DRG   
                                     * [n][3] For future use                    
                                     * [n][4] For future use                    
                                     * [n][5] HAC Status                        
                                     *   0=HAC not applicable                   
                                     *   1=HAC criteria met                     
                                     *   2=HAC criteria not met                 
                                     */                                         
       char  FAR * vsg_flags,       /* Procedure Flags Table                    
                                     * array of 50 SG x 7 chars each            
                                     * [n][0] Procedure Validity                
                                     *   0=procedure is invalid                 
                                     *   1=procedure is valid                   
                                     * [n][1] Procedure Affects DRG             
                                     *   0=proc did not affect the DRG          
                                     *   1=proc affected initial DRG only       
                                     *   2=proc affected final DRG only         
                                     *   3=proc affected both initial           
                                     *     and final DRG                        
                                     * [n][2] OR/Non-OR Procedure               
                                     *   0=not an OR procedure                  
                                     *   1=operating room (OR) procedure        
                                     * [n][3] For future use                    
                                     * [n][4] For future use                    
                                     * [n][5] For future use                    
                                     * [n][6] For future use                    
                                     */                                         
       char  FAR * vmed_surg_ind_init,  /* Initial DRG Medical/Surgical         
                                         * Indicator 1 char                     
                                         * 0=RTC is non-zero                    
                                         * 1=Medical Initial DRG                
                                         * 2=Surgical Initial DRG               
                                         */                                     
       char  FAR * vmed_surg_ind_final  /* Final DRG Medical/Surgical           
                                         * Indicator 1 char                     
                                         * 0=RTC is non-zero                    
                                         * 1=Medical Final DRG                  
                                         * 2=Surgical Final DRG                 
                                         */                                     
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF30CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF30CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF30CS                                            
#else                                                                           
short IRPEXTCALL HADF30CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp2_Data *hgp);                                                    
                                                                                

#if defined(PCWIN)
IRPEXTERNC short FAR PASCAL hadf31cw
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)
IRPEXTERNC short IRPEXTCALL hadf31c1
#elif defined(PCWIN32)
IRPEXTERNC short IRPEXTCALL hadf31c1
#else
short IRPEXTCALL hadf31c1
#endif
(     /* ------Federal Grouper 31---- */
                                                                                
                 /* -------- input arguments ----- */                           
       short grpfunc,               /* grouper function:                        
                                     *   0 = group,                             
                                     *   1 = free grouper storage               
                                     */                                         
       short vndx,                  /* number diagnoses  50 MAX      */         
       short vnsg,                  /* number procedures 50 MAX      */         
       char  FAR *vdx_ptr,          /* array of 50 DX x 8 chars each            
                                     * left justified, blank padded             
                                     * rightmost char is POA indicator          
                                     */                                         
       char  FAR *vsg_ptr,          /* array of 50 SG x 7 chars each            
                                     * left justified, blank padded             
                                     */                                         
       char  FAR *vage,             /* age - 3 chars 000-124          */        
       char  FAR *vsex,             /* sex - 1 char 1,m,M or 2,f,F    */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 chars    */        
       char  FAR *vpoa_logic,       /* 1 char                                   
                                     * X=No POA processing                      
                                     * Z=POA processing                         
                                     */                                         
       char  FAR *vadmit_date,      /* admit date 8 chars YYYYMMDD     */       
       char  FAR *vdisch_date,      /* discharge date 8 chars YYYYMMDD */       
       char  FAR *vsg_dates,        /* array of 50 procedure dates              
                                     * 8 chars each YYYYMMDD                    
                                     */                                         
                                                                                
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 4 chars 0001-0999 */        
       char  FAR *vmdc,             /* assigned MDC 2 chars 00-25     */        
       char  FAR *vrtc,             /* return code  2 chars 00-15     */        
       char  FAR *vmajop,           /* 1st significant OR SG  7 chars */        
       char  FAR *vadx,             /* 1st significant DX  8 chars    */        
       char  FAR *vsdx,             /* 2nd significant DX  8 chars    */        
       char  FAR *vers,             /* grouper version 11 chars                 
                                     * HAFvv-mm/yy                              
                                     */                                         
       char  FAR *vmajop2,          /* 2nd significant OR SG  7 chars */        
       char  FAR *vminop,           /* 1st signif. Non-OR SG  7 chars */        
       char  FAR *vminop2,          /* 2nd signif. Non-OR SG  7 chars */        
       char  FAR *vdxcc,            /* CC DX 8 chars                  */        
       char  FAR *vmajop3,          /* 3rd significant OR SG  7 chars */        
       char  FAR *vdxcctab,         /* array of 50 chars                        
                                     * one for each input DX                    
                                     * 0 = DX is not a CC or MCC                
                                     * 1 = DX is an MCC                         
                                     * 2 = DX is a CC                           
                                     * blank = Principal DX or                  
                                     *         Invalid DX                       
                                     */                                         
       char  FAR * vdrg_initial,    /* initial DRG 4 chars 0001-0999 */         
       char  FAR * vdrg_cc_flag,    /* 1 char                                   
                                     * 0=DRG based on no CC or MCC              
                                     * 1=DRG based on MCC                       
                                     * 2=DRG based on CC                        
                                     */                                         
       char  FAR * vdx_flags,       /* Diagnosis Flags Table                    
                                     * array of 50 DX x 6 chars each            
                                     * [n][0] Diagnosis Validity                
                                     *   0=diagnosis is invalid                 
                                     *   1=diagnosis is valid                   
                                     * [n][1] Diagnosis Affects DRG             
                                     *   0=DX did not affect the DRG            
                                     *   1=DX affected initial DRG only         
                                     *   2=DX affected final DRG only           
                                     *   3=DX affected both initial             
                                     *     and final DRG                        
                                     * [n][2] CC/MCC Categorization             
                                     *   0 = DX is not a CC or MCC              
                                     *       for initial or final DRG           
                                     *   1 = DX is an MCC                       
                                     *       for both initial and final DRG     
                                     *   2 = DX is a CC                         
                                     *       for both initial and final DRG     
                                     *   3 = DX is an MCC for inital DRG        
                                     *       DX is not a CC/MCC for final DRG   
                                     *   4 = DX is a CC for initial DRG         
                                     *       DX is not a CC/MCC for init. DRG   
                                     * [n][3] For future use                    
                                     * [n][4] For future use                    
                                     * [n][5] HAC Status                        
                                     *   0=HAC not applicable                   
                                     *   1=HAC criteria met                     
                                     *   2=HAC criteria not met
                                     *   3=HAC crit. not met, CC Excl.          
                                     */                                         
       char  FAR * vsg_flags,       /* Procedure Flags Table                    
                                     * array of 50 SG x 7 chars each            
                                     * [n][0] Procedure Validity                
                                     *   0=procedure is invalid                 
                                     *   1=procedure is valid                   
                                     * [n][1] Procedure Affects DRG             
                                     *   0=proc did not affect the DRG          
                                     *   1=proc affected initial DRG only       
                                     *   2=proc affected final DRG only         
                                     *   3=proc affected both initial           
                                     *     and final DRG                        
                                     * [n][2] OR/Non-OR Procedure               
                                     *   0=not an OR procedure                  
                                     *   1=operating room (OR) procedure        
                                     * [n][3] For future use                    
                                     * [n][4] For future use                    
                                     * [n][5] For future use                    
                                     * [n][6] For future use                    
                                     */                                         
       char  FAR * vmed_surg_ind_init,  /* Initial DRG Medical/Surgical         
                                         * Indicator 1 char                     
                                         * 0=RTC is non-zero                    
                                         * 1=Medical Initial DRG                
                                         * 2=Surgical Initial DRG               
                                         */                                     
       char  FAR * vmed_surg_ind_final  /* Final DRG Medical/Surgical           
                                         * Indicator 1 char                     
                                         * 0=RTC is non-zero                    
                                         * 1=Medical Final DRG                  
                                         * 2=Surgical Final DRG                 
                                         */                                     
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF31CS
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)
IRPEXTERNC short IRPEXTCALL HADF31CS
#elif defined(PCWIN32)
IRPEXTERNC short IRPEXTCALL HADF31CS
#else
short IRPEXTCALL HADF31CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp2_Data *hgp);                                                    
                                                                                
#if defined(PCWIN)
IRPEXTERNC short FAR PASCAL hadf32cw
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)
IRPEXTERNC short IRPEXTCALL hadf32c1
#elif defined(PCWIN32)
IRPEXTERNC short IRPEXTCALL hadf32c1
#else
short IRPEXTCALL hadf32c1
#endif
(     /* ------Federal Grouper 32---- */
                                                                                
                 /* -------- input arguments ----- */                           
       short grpfunc,               /* grouper function:                        
                                     *   0 = group,                             
                                     *   1 = free grouper storage               
                                     */                                         
       short vndx,                  /* number diagnoses  50 MAX      */         
       short vnsg,                  /* number procedures 50 MAX      */         
       char  FAR *vdx_ptr,          /* array of 50 DX x 8 chars each            
                                     * left justified, blank padded             
                                     * rightmost char is POA indicator          
                                     */                                         
       char  FAR *vsg_ptr,          /* array of 50 SG x 7 chars each            
                                     * left justified, blank padded             
                                     */                                         
       char  FAR *vage,             /* age - 3 chars 000-124          */        
       char  FAR *vsex,             /* sex - 1 char 1,m,M or 2,f,F    */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 chars    */        
       char  FAR *vpoa_logic,       /* 1 char                                   
                                     * X=No POA processing                      
                                     * Z=POA processing                         
                                     */                                         
       char  FAR *vadmit_date,      /* admit date 8 chars YYYYMMDD     */       
       char  FAR *vdisch_date,      /* discharge date 8 chars YYYYMMDD */       
       char  FAR *vsg_dates,        /* array of 50 procedure dates              
                                     * 8 chars each YYYYMMDD                    
                                     */                                         
                                                                                
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 4 chars 0001-0999 */        
       char  FAR *vmdc,             /* assigned MDC 2 chars 00-25     */        
       char  FAR *vrtc,             /* return code  2 chars 00-15     */        
       char  FAR *vmajop,           /* 1st significant OR SG  7 chars */        
       char  FAR *vadx,             /* 1st significant DX  8 chars    */        
       char  FAR *vsdx,             /* 2nd significant DX  8 chars    */        
       char  FAR *vers,             /* grouper version 11 chars                 
                                     * HAFvv-mm/yy                              
                                     */                                         
       char  FAR *vmajop2,          /* 2nd significant OR SG  7 chars */        
       char  FAR *vminop,           /* 1st signif. Non-OR SG  7 chars */        
       char  FAR *vminop2,          /* 2nd signif. Non-OR SG  7 chars */        
       char  FAR *vdxcc,            /* CC DX 8 chars                  */        
       char  FAR *vmajop3,          /* 3rd significant OR SG  7 chars */        
       char  FAR *vdxcctab,         /* array of 50 chars                        
                                     * one for each input DX                    
                                     * 0 = DX is not a CC or MCC                
                                     * 1 = DX is an MCC                         
                                     * 2 = DX is a CC                           
                                     * blank = Principal DX or                  
                                     *         Invalid DX                       
                                     */                                         
       char  FAR * vdrg_initial,    /* initial DRG 4 chars 0001-0999 */         
       char  FAR * vdrg_cc_flag,    /* 1 char                                   
                                     * 0=DRG based on no CC or MCC              
                                     * 1=DRG based on MCC                       
                                     * 2=DRG based on CC                        
                                     */                                         
       char  FAR * vdx_flags,       /* Diagnosis Flags Table                    
                                     * array of 50 DX x 6 chars each            
                                     * [n][0] Diagnosis Validity                
                                     *   0=diagnosis is invalid                 
                                     *   1=diagnosis is valid                   
                                     * [n][1] Diagnosis Affects DRG             
                                     *   0=DX did not affect the DRG            
                                     *   1=DX affected initial DRG only         
                                     *   2=DX affected final DRG only           
                                     *   3=DX affected both initial             
                                     *     and final DRG                        
                                     * [n][2] CC/MCC Categorization             
                                     *   0 = DX is not a CC or MCC              
                                     *       for initial or final DRG           
                                     *   1 = DX is an MCC                       
                                     *       for both initial and final DRG     
                                     *   2 = DX is a CC                         
                                     *       for both initial and final DRG     
                                     *   3 = DX is an MCC for inital DRG        
                                     *       DX is not a CC/MCC for final DRG   
                                     *   4 = DX is a CC for initial DRG         
                                     *       DX is not a CC/MCC for init. DRG   
                                     * [n][3] For future use                    
                                     * [n][4] For future use                    
                                     * [n][5] HAC Status                        
                                     *   0=HAC not applicable                   
                                     *   1=HAC criteria met                     
                                     *   2=HAC criteria not met
                                     *   3=HAC crit. not met, CC Excl.          
                                     */                                         
       char  FAR * vsg_flags,       /* Procedure Flags Table                    
                                     * array of 50 SG x 7 chars each            
                                     * [n][0] Procedure Validity                
                                     *   0=procedure is invalid                 
                                     *   1=procedure is valid                   
                                     * [n][1] Procedure Affects DRG             
                                     *   0=proc did not affect the DRG          
                                     *   1=proc affected initial DRG only       
                                     *   2=proc affected final DRG only         
                                     *   3=proc affected both initial           
                                     *     and final DRG                        
                                     * [n][2] OR/Non-OR Procedure               
                                     *   0=not an OR procedure                  
                                     *   1=operating room (OR) procedure        
                                     * [n][3] For future use                    
                                     * [n][4] For future use                    
                                     * [n][5] For future use                    
                                     * [n][6] For future use                    
                                     */                                         
       char  FAR * vmed_surg_ind_init,  /* Initial DRG Medical/Surgical         
                                         * Indicator 1 char                     
                                         * 0=RTC is non-zero                    
                                         * 1=Medical Initial DRG                
                                         * 2=Surgical Initial DRG               
                                         */                                     
       char  FAR * vmed_surg_ind_final  /* Final DRG Medical/Surgical           
                                         * Indicator 1 char                     
                                         * 0=RTC is non-zero                    
                                         * 1=Medical Final DRG                  
                                         * 2=Surgical Final DRG                 
                                         */                                     
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF32CS
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)
IRPEXTERNC short IRPEXTCALL HADF32CS
#elif defined(PCWIN32)
IRPEXTERNC short IRPEXTCALL HADF32CS
#else
short IRPEXTCALL HADF32CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp2_Data *hgp);                                                    
                                                                                

/*                                                                              
 ************************************                                           
 ****** ICD-10 MS DRG Groupers ******                                           
 ************************************                                           
*/                                                                              
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf33cw
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf33c1
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf33c1
#else                                                                           
short IRPEXTCALL hadf33c1
#endif                                                                          
(     /* ------Federal Grouper 33---- */
                                                                                
                 /* -------- input arguments ----- */                           
       short grpfunc,               /* grouper function:                        
                                     *   0 = group,                             
                                     *   1 = free grouper storage               
                                     */                                         
       short vndx,                  /* number diagnoses  50 MAX      */         
       short vnsg,                  /* number procedures 50 MAX      */         
       char  FAR *vdx_ptr,          /* array of 50 DX x 8 chars each            
                                     * left justified, blank padded             
                                     * rightmost char is POA indicator          
                                     */                                         
       char  FAR *vsg_ptr,          /* array of 50 SG x 7 chars each            
                                     * left justified, blank padded             
                                     */                                         
       char  FAR *vage,             /* age - 3 chars 000-124          */        
       char  FAR *vsex,             /* sex - 1 char 1,m,M or 2,f,F    */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 chars    */        
       char  FAR *vpoa_logic,       /* 1 char                                   
                                     * X=No POA processing                      
                                     * Z=POA processing                         
                                     */                                         
       char  FAR *vadmit_date,      /* admit date 8 chars YYYYMMDD     */       
       char  FAR *vdisch_date,      /* discharge date 8 chars YYYYMMDD */       
       char  FAR *vsg_dates,        /* array of 50 procedure dates              
                                     * 8 chars each YYYYMMDD                    
                                     */                                         
                                                                                
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 4 chars 0001-0999 */        
       char  FAR *vmdc,             /* assigned MDC 2 chars 00-25     */        
       char  FAR *vrtc,             /* return code  2 chars 00-15     */        
       char  FAR *vmajop,           /* 1st significant OR SG  7 chars */        
       char  FAR *vadx,             /* 1st significant DX  8 chars    */        
       char  FAR *vsdx,             /* 2nd significant DX  8 chars    */        
       char  FAR *vers,             /* grouper version 11 chars                 
                                     * HAFvv-mm/yy                              
                                     */                                         
       char  FAR *vmajop2,          /* 2nd significant OR SG  7 chars */        
       char  FAR *vminop,           /* 1st signif. Non-OR SG  7 chars */        
       char  FAR *vminop2,          /* 2nd signif. Non-OR SG  7 chars */        
       char  FAR *vdxcc,            /* CC DX 8 chars                  */        
       char  FAR *vmajop3,          /* 3rd significant OR SG  7 chars */        
       char  FAR *vdxcctab,         /* array of 50 chars                        
                                     * one for each input DX                    
                                     * 0 = DX is not a CC or MCC                
                                     * 1 = DX is an MCC                         
                                     * 2 = DX is a CC                           
                                     * blank = Principal DX or                  
                                     *         Invalid DX                       
                                     */                                         
       char  FAR * vdrg_initial,    /* initial DRG 4 chars 0001-0999 */         
       char  FAR * vdrg_cc_flag,    /* 1 char                                   
                                     * 0=DRG based on no CC or MCC              
                                     * 1=DRG based on MCC                       
                                     * 2=DRG based on CC                        
                                     */                                         
       char  FAR * vdx_flags,       /* Diagnosis Flags Table                    
                                     * array of 50 DX x 6 chars each            
                                     * [n][0] Diagnosis Validity                
                                     *   0=diagnosis is invalid                 
                                     *   1=diagnosis is valid                   
                                     * [n][1] Diagnosis Affects DRG             
                                     *   0=DX did not affect the DRG            
                                     *   1=DX affected initial DRG only
                                     *   2=DX affected final DRG only           
                                     *   3=DX affected both initial             
                                     *     and final DRG                        
                                     * [n][2] CC/MCC Categorization             
                                     *   0 = DX is not a CC or MCC              
                                     *       for initial or final DRG
                                     *   1 = DX is an MCC                       
                                     *       for both initial and final DRG
                                     *   2 = DX is a CC                         
                                     *       for both initial and final DRG     
                                     *   3 = DX is an MCC for inital DRG        
                                     *       DX is not a CC/MCC for final DRG   
                                     *   4 = DX is a CC for initial DRG
                                     *       DX is not a CC/MCC for init. DRG
                                     *   5 = DX is a MCC but not considered
                                     *       due to PDX/SDX exclusion
                                     *   6 = DX is a CC but not considered
                                     *       due to PDX/SDX exclusion
                                     *   7 = DX as PDX is considered its own MCC
                                     *   8 = DX as PDX is considered its own CC
                                     * [n][3] For future use                    
                                     * [n][4] For future use
                                     * [n][5] HAC/POA Status                    
                                     *   0=POA processing selected and          
                                     *     not a HAC                            
                                     *     or                                   
                                     *     POA processing selected and          
                                     *     a HAC with a valid POA indic.        
                                     *   1=POA processing selected and          
                                     *     a HAC with invalid POA indic.        
                                     *     or                                   
                                     *     POA processing not selected          
                                     */                                         
       char  FAR * vsg_flags,       /* Procedure Flags Table                    
                                     * array of 50 SG x 7 chars each            
                                     * [n][0] Procedure Validity                
                                     *   0=procedure is invalid                 
                                     *   1=procedure is valid                   
                                     * [n][1] Procedure Affects DRG             
                                     *   0=proc did not affect the DRG          
                                     *   1=proc affected initial DRG only       
                                     *   2=proc affected final DRG only         
                                     *   3=proc affected both initial           
                                     *     and final DRG                        
                                     * [n][2] OR/Non-OR Procedure               
                                     *   0=not an OR procedure                  
                                     *   1=operating room (OR) procedure        
                                     * [n][3] For future use                    
                                     * [n][4] For future use                    
                                     * [n][5] For future use                    
                                     * [n][6] For future use                    
                                     */                                         
       char  FAR * vmed_surg_ind_init,  /* Initial DRG Medical/Surgical         
                                         * Indicator 1 char                     
                                         * 0=RTC is non-zero                    
                                         * 1=Medical Initial DRG                
                                         * 2=Surgical Initial DRG               
                                         */                                     
       char  FAR * vmed_surg_ind_final  /* Final DRG Medical/Surgical           
                                         * Indicator 1 char                     
                                         * 0=RTC is non-zero                    
                                         * 1=Medical Final DRG                  
                                         * 2=Surgical Final DRG                 
                                         */                                     
       );                                                                                                                                                                                                                   

#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF33CS
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF33CS
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF33CS
#else                                                                           
short IRPEXTCALL HADF33CS
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp2_Data *hgp);
                                                                                

#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadf34cw
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL hadf34c1
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadf34c1
#else                                                                           
short IRPEXTCALL hadf34c1
#endif                                                                          
(     /* ------Federal Grouper 34---- */
                                                                                
                 /* -------- input arguments ----- */                           
       short grpfunc,               /* grouper function:                        
                                     *   0 = group,                             
                                     *   1 = free grouper storage               
                                     */                                         
       short vndx,                  /* number diagnoses  50 MAX      */         
       short vnsg,                  /* number procedures 50 MAX      */         
       char  FAR *vdx_ptr,          /* array of 50 DX x 8 chars each            
                                     * left justified, blank padded             
                                     * rightmost char is POA indicator          
                                     */                                         
       char  FAR *vsg_ptr,          /* array of 50 SG x 7 chars each            
                                     * left justified, blank padded             
                                     */                                         
       char  FAR *vage,             /* age - 3 chars 000-124          */        
       char  FAR *vsex,             /* sex - 1 char 1,m,M or 2,f,F    */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 chars    */        
       char  FAR *vpoa_logic,       /* 1 char                                   
                                     * X=No POA processing                      
                                     * Z=POA processing                         
                                     */                                         
       char  FAR *vadmit_date,      /* admit date 8 chars YYYYMMDD     */       
       char  FAR *vdisch_date,      /* discharge date 8 chars YYYYMMDD */       
       char  FAR *vsg_dates,        /* array of 50 procedure dates              
                                     * 8 chars each YYYYMMDD                    
                                     */                                         
                                                                                
                 /* ------  output arguments ----- */                           
       char  FAR *vdrg,             /* assigned DRG 4 chars 0001-0999 */        
       char  FAR *vmdc,             /* assigned MDC 2 chars 00-25     */        
       char  FAR *vrtc,             /* return code  2 chars 00-15     */        
       char  FAR *vmajop,           /* 1st significant OR SG  7 chars */        
       char  FAR *vadx,             /* 1st significant DX  8 chars    */        
       char  FAR *vsdx,             /* 2nd significant DX  8 chars    */        
       char  FAR *vers,             /* grouper version 11 chars                 
                                     * HAFvv-mm/yy                              
                                     */                                         
       char  FAR *vmajop2,          /* 2nd significant OR SG  7 chars */        
       char  FAR *vminop,           /* 1st signif. Non-OR SG  7 chars */        
       char  FAR *vminop2,          /* 2nd signif. Non-OR SG  7 chars */        
       char  FAR *vdxcc,            /* CC DX 8 chars                  */        
       char  FAR *vmajop3,          /* 3rd significant OR SG  7 chars */        
       char  FAR *vdxcctab,         /* array of 50 chars                        
                                     * one for each input DX                    
                                     * 0 = DX is not a CC or MCC                
                                     * 1 = DX is an MCC                         
                                     * 2 = DX is a CC                           
                                     * blank = Principal DX or                  
                                     *         Invalid DX                       
                                     */                                         
       char  FAR * vdrg_initial,    /* initial DRG 4 chars 0001-0999 */         
       char  FAR * vdrg_cc_flag,    /* 1 char                                   
                                     * 0=DRG based on no CC or MCC              
                                     * 1=DRG based on MCC                       
                                     * 2=DRG based on CC                        
                                     */                                         
       char  FAR * vdx_flags,       /* Diagnosis Flags Table                    
                                     * array of 50 DX x 6 chars each            
                                     * [n][0] Diagnosis Validity                
                                     *   0=diagnosis is invalid                 
                                     *   1=diagnosis is valid                   
                                     * [n][1] Diagnosis Affects DRG             
                                     *   0=DX did not affect the DRG            
                                     *   1=DX affected initial DRG only
                                     *   2=DX affected final DRG only           
                                     *   3=DX affected both initial             
                                     *     and final DRG                        
                                     * [n][2] CC/MCC Categorization             
                                     *   0 = DX is not a CC or MCC              
                                     *       for initial or final DRG
                                     *   1 = DX is an MCC                       
                                     *       for both initial and final DRG
                                     *   2 = DX is a CC                         
                                     *       for both initial and final DRG     
                                     *   3 = DX is an MCC for inital DRG        
                                     *       DX is not a CC/MCC for final DRG   
                                     *   4 = DX is a CC for initial DRG
                                     *       DX is not a CC/MCC for init. DRG
                                     *   5 = DX is a MCC but not considered
                                     *       due to PDX/SDX exclusion
                                     *   6 = DX is a CC but not considered
                                     *       due to PDX/SDX exclusion
                                     *   7 = DX as PDX is considered its own MCC
                                     *   8 = DX as PDX is considered its own CC
                                     * [n][3] For future use                    
                                     * [n][4] For future use
                                     * [n][5] HAC/POA Status                    
                                     *   0=POA processing selected and          
                                     *     not a HAC                            
                                     *     or                                   
                                     *     POA processing selected and          
                                     *     a HAC with a valid POA indic.        
                                     *   1=POA processing selected and          
                                     *     a HAC with invalid POA indic.        
                                     *     or                                   
                                     *     POA processing not selected          
                                     */                                         
       char  FAR * vsg_flags,       /* Procedure Flags Table                    
                                     * array of 50 SG x 7 chars each            
                                     * [n][0] Procedure Validity                
                                     *   0=procedure is invalid                 
                                     *   1=procedure is valid                   
                                     * [n][1] Procedure Affects DRG             
                                     *   0=proc did not affect the DRG          
                                     *   1=proc affected initial DRG only       
                                     *   2=proc affected final DRG only         
                                     *   3=proc affected both initial           
                                     *     and final DRG                        
                                     * [n][2] OR/Non-OR Procedure               
                                     *   0=not an OR procedure                  
                                     *   1=operating room (OR) procedure        
                                     * [n][3] For future use                    
                                     * [n][4] For future use                    
                                     * [n][5] For future use                    
                                     * [n][6] For future use                    
                                     */                                         
       char  FAR * vmed_surg_ind_init,  /* Initial DRG Medical/Surgical         
                                         * Indicator 1 char                     
                                         * 0=RTC is non-zero                    
                                         * 1=Medical Initial DRG                
                                         * 2=Surgical Initial DRG               
                                         */                                     
       char  FAR * vmed_surg_ind_final  /* Final DRG Medical/Surgical           
                                         * Indicator 1 char                     
                                         * 0=RTC is non-zero                    
                                         * 1=Medical Final DRG                  
                                         * 2=Surgical Final DRG                 
                                         */                                     
       );                                                                                                                                                                                                                   

#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADF34CS
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADF34CS
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADF34CS
#else                                                                           
short IRPEXTCALL HADF34CS
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp2_Data *hgp);
                                                                                

/*
 ************************************                                           
 ********* APR DRG groupers *********                                           
 ************************************                                           
*/                                                                              
#if (defined(PCWIN32) && defined(MS6COMPILER)) || \
     defined(AIX64)|| defined(AIX32) || defined(UNIX64) || \
     defined(HPUX)
                                                                                
IRPEXTERNC short IRPEXTCALL hads26c1(                                           
                 /* -------- input arguments ----- */                           
     short grpfunc,               /* grouper function:                          
                                   *   0 = group,                               
                                   *   1 = free grouper storage                 
                                   */                                           
     short lvndx,                 /* number diagnoses  50 MAX      */           
     short lvnsg,                 /* number procedures 50 MAX      */           
     char  FAR *lvdx_ptr,         /* array of 50 DX x 8 chars each              
                                   * left justified, blank padded               
                                   * rightmost char is POA indicator            
                                   */                                           
     char  FAR *lvsg_ptr,         /* array of 50 SG x 7 chars each              
                                   * left justified, blank padded               
                                   */                                           
     char  FAR *lvsex,            /* sex - 1 char 1,m,M or 2,f,F     */         
     char  FAR *lvdstat,          /* UB82 discharge stat 2 chars     */         
     char  FAR *lvbirth_date,     /* birth date 8 chars MMDDYYYY     */         
     char  FAR *lvadmit_date,     /* admit date 8 chars MMDDYYYY     */         
     char  FAR *lvdisch_date,     /* discharge date 8 chars MMDDYYYY */         
     char  FAR *lvsg_dates,       /* array of 50 procedure dates                
                                   * 8 chars each MMDDYYYY                      
                                   */                                           
     char  *lvbwght,              /* birth weight in grams 0200-7000*/          
     char  *lvbwtopt,             /* birth weight option 1-7        */          
/* birth weight options:                                                        
    1      use the entered weight                                               
                                                                                
    2      ignore entered wt, use wt implicit in ICD-9-CM code                  
                                                                                
    3      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, flag wt as invalid                                  
                                                                                
    4      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag weight as invalid                                
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, flag wt as invalid                   
                                                                                
    5      ignore entered wt, use wt implicit in ICD-9-CM code                  
           if invalid, default to normal wt                                     
                                                                                
    6      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, default to normal wt                                
                                                                                
    7      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag wt as invalid                                    
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, default to normal                    
                                                                                
    notes  1. Normal birth weight range is 200 - 7000 g.                        
           2. If option entry is invalid or missing, it defaults to 7.          
           3. For a crosscheck, a comparison is made between the entered        
              birth weight and the implicit birth weight.                       
           4. If the birth weight is required, the system returns DRG 956.      
           5. The normal weight default assumes birth weight is set             
              to >= 2499 g.                                                     
           6. Logic is only performed if age on admit <= 14 days.               
*/                                                                              
     char  FAR *lvdmv,            /* days on mech. vent. 3 chars 000-999 */     
     char  FAR *lvdmva,           /* days after admission when placed on        
                                     mech. ventilator 3 chars -99-999           
                                     left justified, blank padded               
									 FOR FUTURE USE                      */                       
     char  FAR *lvremap,          /* 1 char 0-2, 0 = no remapping               
                                     1 = historical remapping                   
									 2 = logical/clinical remapping                               
									 other = no remapping                                         
								   */                                                           
     char  FAR *lvdischDRGopt,    /* 1 char
								     0 or space will compute Discharge DRG  
									   using HAC processing.
								     1 will compute Discharge DRG excluding
									   all complication of care
									   codes. No Admit DRG will be returned.
								   */
     char  FAR *lvagency,         /* 1 char - needed by HAC logic        
								     1 Medicare HAC logic
								     2 Medicaid HAC logic
								   */
     char  FAR *lvHACvers,        /* 3 char - e.g. 290 */        



                 /* ------  output arguments ----- */
     char  FAR *lvers,            /* grouper version 11 chars
                                   * HASvv-mm/dd
                                   */
     char  FAR *lvrtc,            /* dicharge return code 2 chars 00-12    */
     char  FAR *lvmdc,            /* discharge MDC 2 chars 00-25           */
     char  FAR *lvdrg,            /* discharge DRG 3 chars 001-999         */
     char  FAR *lvsoi,            /* disch. severity of illness 1 char 0-4 */
     char  FAR *lvrom,            /* disch. risk of mortality   1 char 0-4 */
     char  FAR *lvmed_surg_ind,   /* discharge DRG Medical/Surgical
                                   * Indicator 1 char
                                   * 0=Discharge RTC is non-zero
                                   * 1=Medical  Discharge DRG
                                   * 2=Surgical Discharge DRG
                                   */
     char  FAR *lvrtc_admit,      /* admission return code 2 chars 00-12  */
     char  FAR *lvmdc_admit,      /* admission MDC 2 chars 00-25          */
     char  FAR *lvdrg_admit,      /* admission DRG 3 chars 001-999        */
     char  FAR *lvsoi_admit,      /* admit severity of illness 1 char 0-4 */
     char  FAR *lvrom_admit,      /* admit risk of mortality   1 char 0-4 */
     char  FAR *lvmed_surg_ind_admit, /* Admission DRG Medical/Surgical
                                   * Indicator 1 char
                                   * 0=Admission RTC is non-zero
                                   * 1=Medical  Admission DRG
                                   * 2=Surgical Admission DRG
                                   */
     char  FAR *lvdx_flags,       /* Diagnosis Flags Table
                                   * array of 50 x 10 chars each
                                   * [n][0] Diagnosis Validity
                                   *   0=diagnosis is invalid
                                   *   1=diagnosis is valid
                                   * [n][1] Diagnosis Affects DRG
                                   *   0=diag did not affect the DRG
                                   *   1=diag affected disch DRG only
                                   *   2=diag affected admit DRG only
                                   *   3=diag affected both disch
                                   *     and admit DRG
                                   *   4=diag affected HAC DRG only
                                   *   5=diag aff disch & HAC DRG
                                   *   6=diag aff admit & HAC DRG
                                   *   7=diag aff admit, dish & 
                                   *     HAC DRG
                                   * [n][2] Diagnosis Affects SOI
                                   *   0=diag did not affect the SOI
                                   *   1=diag affected disch SOI only
                                   *   2=diag affected admit SOI only
                                   *   3=diag affected both disch
                                   *     and admit SOI
                                   *   4=diag affected HAC SOI only
                                   *   5=diag aff disch & HAC SOI
                                   *   6=diag aff admit & HAC SOI
                                   *   7=diag aff admit, dish &
                                   *     HAC SOI
                                   * [n][3] Diagnosis Affects ROM
                                   *   0=diag did not affect the ROM
                                   *   1=diag affected disch ROM only
                                   *   2=diag affected admit ROM only
                                   *   3=diag affected both disch
                                   *     and admit ROM
                                   *   4=diag affected HAC ROM only
                                   *   5=diag aff disch & HAC ROM
                                   *   6=diag aff admit & HAC ROM
                                   *   7=diag aff admit, dish &
                                   *     HAC ROM
                                   * [n][4] Diagnosis Discharge SOI Level
                                   *   C=Excluded Complication of Care
                                   *   D=Duplicate Secondary DX
                                   *   P=Indicates Principal DX
                                   *   X=Excluded
                                   *   0=Non-groupable claim
                                   *   1=Minor
                                   *   2=Moderate
                                   *   3=Major
                                   *   4=Extreme
                                   *   blank=DX not recognized or excluded HAC
                                   * [n][5] Diagnosis Discharge ROM Level
								   *    same values as DX Discharge SOI Level
                                   * [n][6] Diagnosis Admission SOI Level
								   *    same values as DX Discharge SOI Level
                                   * [n][7] Diagnosis Admission ROM Level
								   *    same values as DX Discharge SOI Level
                                   * [n][8] Diagnosis HAC SOI Level
								   *    same values as DX Discharge SOI Level
                                   * [n][9] Diagnosis HAC ROM Level
								   *    same values as DX Discharge SOI Level
								   */
     char  FAR * lvsg_flags,      /* Procedure Flags Table
                                   * array of 50 x 5 chars each
                                   * [n][0] Procedure Validity
                                   *   0=procedure is invalid
                                   *   1=procedure is valid
                                   * [n][1] Procedure Affects DRG
                                   *   0=proc did not affect the DRG
                                   *   1=proc affected disch DRG only
                                   *   2=proc affected admit DRG only
                                   *   3=proc affected both disch
                                   *     and admit DRG
                                   *   4=proc affected HAC DRG only
                                   *   5=proc aff disch & HAC DRG
                                   *   6=proc aff admit & HAC DRG
                                   *   7=proc aff admit, disch &
                                   *     HAC DRG
                                   * [n][2] Procedure Affects SOI
                                   *   0=proc did not affect the SOI
                                   *   1=proc affected disch SOI only
                                   *   2=proc affected admit SOI only
                                   *   3=proc affected both disch
                                   *     and admit SOI
                                   *   4=proc affected HAC SOI only
                                   *   5=proc aff disch & HAC SOI
                                   *   6=proc aff admit & HAC SOI
                                   *   7=proc aff admit, disch &
                                   *     HAC SOI
                                   * [n][3] Procedure Affects ROM
                                   *   0=proc did not affect the ROM
                                   *   1=proc affected disch ROM only
                                   *   2=proc affected admit ROM only
                                   *   3=proc affected both disch
                                   *     and admit ROM
                                   *   4=proc affected HAC ROM only
                                   *   5=proc aff disch & HAC ROM
                                   *   6=proc aff admit & HAC ROM
                                   *   7=proc aff admit, disch &
                                   *     HAC ROM
                                   * [n][4] OR/Non-OR Procedure
                                   *   0=not an OR procedure
                                   *   1=operating room (OR) procedure
                                   */
     char  FAR *lvrtc_hac,        /* HAC return code 2 chars 00-12  */
     char  FAR *lvmdc_hac,        /* HAC MDC 2 chars 00-25          */
     char  FAR *lvdrg_hac,        /* HAC DRG 3 chars 001-999        */
     char  FAR *lvsoi_hac,        /* HAC severity of illness 1 char 0-4 */
     char  FAR *lvrom_hac,        /* HAC risk of mortality   1 char 0-4 */
     char  FAR *lvmed_surg_ind_hac /* HAC DRG Medical/Surgical
                                   * Indicator 1 char
                                   * 0=HAC RTC is non-zero
                                   * 1=Medical  HAC DRG
                                   * 2=Surgical HAC DRG
                                   */
     );                                                                         
                                                                                
                                                                                
IRPEXTERNC short IRPEXTCALL HADS26CS                                            
  (Hadgrp2_Data * hgp);                                                         
                                                                                
IRPEXTERNC short IRPEXTCALL hads27c1(                                           
                 /* -------- input arguments ----- */                           
     short grpfunc,               /* grouper function:                          
                                   *   0 = group,                               
                                   *   1 = free grouper storage                 
                                   */                                           
     short lvndx,                 /* number diagnoses  50 MAX      */           
     short lvnsg,                 /* number procedures 50 MAX      */           
     char  FAR *lvdx_ptr,         /* array of 50 DX x 8 chars each              
                                   * left justified, blank padded               
                                   * rightmost char is POA indicator            
                                   */                                           
     char  FAR *lvsg_ptr,         /* array of 50 SG x 7 chars each              
                                   * left justified, blank padded               
                                   */                                           
     char  FAR *lvsex,            /* sex - 1 char 1,m,M or 2,f,F     */         
     char  FAR *lvdstat,          /* UB82 discharge stat 2 chars     */         
     char  FAR *lvbirth_date,     /* birth date 8 chars MMDDYYYY     */         
     char  FAR *lvadmit_date,     /* admit date 8 chars MMDDYYYY     */         
     char  FAR *lvdisch_date,     /* discharge date 8 chars MMDDYYYY */         
     char  FAR *lvsg_dates,       /* array of 50 procedure dates                
                                   * 8 chars each MMDDYYYY                      
                                   */                                           
     char  *lvbwght,              /* birth weight in grams 0200-7000*/          
     char  *lvbwtopt,             /* birth weight option 1-7        */          
/* birth weight options:                                                        
    1      use the entered weight                                               
                                                                                
    2      ignore entered wt, use wt implicit in ICD-9-CM code                  
                                                                                
    3      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, flag wt as invalid                                  
                                                                                
    4      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag weight as invalid                                
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, flag wt as invalid                   
                                                                                
    5      ignore entered wt, use wt implicit in ICD-9-CM code                  
           if invalid, default to normal wt                                     
                                                                                
    6      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, default to normal wt                                
                                                                                
    7      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag wt as invalid                                    
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, default to normal                    
                                                                                
    notes  1. Normal birth weight range is 200 - 7000 g.                        
           2. If option entry is invalid or missing, it defaults to 7.          
           3. For a crosscheck, a comparison is made between the entered        
              birth weight and the implicit birth weight.                       
           4. If the birth weight is required, the system returns DRG 956.      
           5. The normal weight default assumes birth weight is set             
              to >= 2499 g.                                                     
           6. Logic is only performed if age on admit <= 14 days.               
*/                                                                              
     char  FAR *lvdmv,            /* days on mech. vent. 3 chars 000-999 */     
     char  FAR *lvdmva,           /* days after admission when placed on        
                                     mech. ventilator 3 chars -99-999           
                                     left justified, blank padded               
									 FOR FUTURE USE                      */                       
     char  FAR *lvremap,          /* 1 char 0-2, 0 = no remapping               
                                     1 = historical remapping                   
									 2 = logical/clinical remapping                               
									 other = no remapping                                         
								   */                                                           
     char  FAR *lvdischDRGopt,    /* 1 char
								     0 or space will compute Discharge DRG  
									   using HAC processing.
								     1 will compute Discharge DRG excluding
									   all complication of care
									   codes. No Admit DRG will be returned.
								   */
     char  FAR *lvagency,         /* 1 char - needed by HAC logic        
								     1 Medicare HAC logic
								     2 Medicaid HAC logic
								   */
     char  FAR *lvHACvers,        /* 3 char - e.g. 290 */        



                 /* ------  output arguments ----- */
     char  FAR *lvers,            /* grouper version 11 chars
                                   * HASvv-mm/dd
                                   */
     char  FAR *lvrtc,            /* dicharge return code 2 chars 00-12    */
     char  FAR *lvmdc,            /* discharge MDC 2 chars 00-25           */
     char  FAR *lvdrg,            /* discharge DRG 3 chars 001-999         */
     char  FAR *lvsoi,            /* disch. severity of illness 1 char 0-4 */
     char  FAR *lvrom,            /* disch. risk of mortality   1 char 0-4 */
     char  FAR *lvmed_surg_ind,   /* discharge DRG Medical/Surgical
                                   * Indicator 1 char
                                   * 0=Discharge RTC is non-zero
                                   * 1=Medical  Discharge DRG
                                   * 2=Surgical Discharge DRG
                                   */
     char  FAR *lvrtc_admit,      /* admission return code 2 chars 00-12  */
     char  FAR *lvmdc_admit,      /* admission MDC 2 chars 00-25          */
     char  FAR *lvdrg_admit,      /* admission DRG 3 chars 001-999        */
     char  FAR *lvsoi_admit,      /* admit severity of illness 1 char 0-4 */
     char  FAR *lvrom_admit,      /* admit risk of mortality   1 char 0-4 */
     char  FAR *lvmed_surg_ind_admit, /* Admission DRG Medical/Surgical
                                   * Indicator 1 char
                                   * 0=Admission RTC is non-zero
                                   * 1=Medical  Admission DRG
                                   * 2=Surgical Admission DRG
                                   */
     char  FAR *lvdx_flags,       /* Diagnosis Flags Table
                                   * array of 50 x 10 chars each
                                   * [n][0] Diagnosis Validity
                                   *   0=diagnosis is invalid
                                   *   1=diagnosis is valid
                                   * [n][1] Diagnosis Affects DRG
                                   *   0=diag did not affect the DRG
                                   *   1=diag affected disch DRG only
                                   *   2=diag affected admit DRG only
                                   *   3=diag affected both disch
                                   *     and admit DRG
                                   *   4=diag affected HAC DRG only
                                   *   5=diag aff disch & HAC DRG
                                   *   6=diag aff admit & HAC DRG
                                   *   7=diag aff admit, dish & 
                                   *     HAC DRG
                                   * [n][2] Diagnosis Affects SOI
                                   *   0=diag did not affect the SOI
                                   *   1=diag affected disch SOI only
                                   *   2=diag affected admit SOI only
                                   *   3=diag affected both disch
                                   *     and admit SOI
                                   *   4=diag affected HAC SOI only
                                   *   5=diag aff disch & HAC SOI
                                   *   6=diag aff admit & HAC SOI
                                   *   7=diag aff admit, dish &
                                   *     HAC SOI
                                   * [n][3] Diagnosis Affects ROM
                                   *   0=diag did not affect the ROM
                                   *   1=diag affected disch ROM only
                                   *   2=diag affected admit ROM only
                                   *   3=diag affected both disch
                                   *     and admit ROM
                                   *   4=diag affected HAC ROM only
                                   *   5=diag aff disch & HAC ROM
                                   *   6=diag aff admit & HAC ROM
                                   *   7=diag aff admit, dish &
                                   *     HAC ROM
                                   * [n][4] Diagnosis Discharge SOI Level
                                   *   C=Excluded Complication of Care
                                   *   D=Duplicate Secondary DX
                                   *   P=Indicates Principal DX
                                   *   X=Excluded
                                   *   0=Non-groupable claim
                                   *   1=Minor
                                   *   2=Moderate
                                   *   3=Major
                                   *   4=Extreme
                                   *   blank=DX not recognized or excluded HAC
                                   * [n][5] Diagnosis Discharge ROM Level
								   *    same values as DX Discharge SOI Level
                                   * [n][6] Diagnosis Admission SOI Level
								   *    same values as DX Discharge SOI Level
                                   * [n][7] Diagnosis Admission ROM Level
								   *    same values as DX Discharge SOI Level
                                   * [n][8] Diagnosis HAC SOI Level
								   *    same values as DX Discharge SOI Level
                                   * [n][9] Diagnosis HAC ROM Level
								   *    same values as DX Discharge SOI Level
								   */
     char  FAR * lvsg_flags,      /* Procedure Flags Table
                                   * array of 50 x 5 chars each
                                   * [n][0] Procedure Validity
                                   *   0=procedure is invalid
                                   *   1=procedure is valid
                                   * [n][1] Procedure Affects DRG
                                   *   0=proc did not affect the DRG
                                   *   1=proc affected disch DRG only
                                   *   2=proc affected admit DRG only
                                   *   3=proc affected both disch
                                   *     and admit DRG
                                   *   4=proc affected HAC DRG only
                                   *   5=proc aff disch & HAC DRG
                                   *   6=proc aff admit & HAC DRG
                                   *   7=proc aff admit, disch &
                                   *     HAC DRG
                                   * [n][2] Procedure Affects SOI
                                   *   0=proc did not affect the SOI
                                   *   1=proc affected disch SOI only
                                   *   2=proc affected admit SOI only
                                   *   3=proc affected both disch
                                   *     and admit SOI
                                   *   4=proc affected HAC SOI only
                                   *   5=proc aff disch & HAC SOI
                                   *   6=proc aff admit & HAC SOI
                                   *   7=proc aff admit, disch &
                                   *     HAC SOI
                                   * [n][3] Procedure Affects ROM
                                   *   0=proc did not affect the ROM
                                   *   1=proc affected disch ROM only
                                   *   2=proc affected admit ROM only
                                   *   3=proc affected both disch
                                   *     and admit ROM
                                   *   4=proc affected HAC ROM only
                                   *   5=proc aff disch & HAC ROM
                                   *   6=proc aff admit & HAC ROM
                                   *   7=proc aff admit, disch &
                                   *     HAC ROM
                                   * [n][4] OR/Non-OR Procedure
                                   *   0=not an OR procedure
                                   *   1=operating room (OR) procedure
                                   */
     char  FAR *lvrtc_hac,        /* HAC return code 2 chars 00-12  */
     char  FAR *lvmdc_hac,        /* HAC MDC 2 chars 00-25          */
     char  FAR *lvdrg_hac,        /* HAC DRG 3 chars 001-999        */
     char  FAR *lvsoi_hac,        /* HAC severity of illness 1 char 0-4 */
     char  FAR *lvrom_hac,        /* HAC risk of mortality   1 char 0-4 */
     char  FAR *lvmed_surg_ind_hac /* HAC DRG Medical/Surgical
                                   * Indicator 1 char
                                   * 0=HAC RTC is non-zero
                                   * 1=Medical  HAC DRG
                                   * 2=Surgical HAC DRG
                                   */
     );                                                                         
                                                                                
                                                                                
IRPEXTERNC short IRPEXTCALL HADS27CS                                            
  (Hadgrp2_Data * hgp);                                                         
                                                                                
IRPEXTERNC short IRPEXTCALL hads28c1(                                           
                 /* -------- input arguments ----- */                           
     short grpfunc,               /* grouper function:                          
                                   *   0 = group,                               
                                   *   1 = free grouper storage                 
                                   */                                           
     short lvndx,                 /* number diagnoses  50 MAX      */           
     short lvnsg,                 /* number procedures 50 MAX      */           
     char  FAR *lvdx_ptr,         /* array of 50 DX x 8 chars each              
                                   * left justified, blank padded               
                                   * rightmost char is POA indicator            
                                   */                                           
     char  FAR *lvsg_ptr,         /* array of 50 SG x 7 chars each              
                                   * left justified, blank padded               
                                   */                                           
     char  FAR *lvsex,            /* sex - 1 char 1,m,M or 2,f,F     */         
     char  FAR *lvdstat,          /* UB82 discharge stat 2 chars     */         
     char  FAR *lvbirth_date,     /* birth date 8 chars MMDDYYYY     */         
     char  FAR *lvadmit_date,     /* admit date 8 chars MMDDYYYY     */         
     char  FAR *lvdisch_date,     /* discharge date 8 chars MMDDYYYY */         
     char  FAR *lvsg_dates,       /* array of 50 procedure dates                
                                   * 8 chars each MMDDYYYY                      
                                   */                                           
     char  *lvbwght,              /* birth weight in grams 0200-7000*/          
     char  *lvbwtopt,             /* birth weight option 1-7        */          
/* birth weight options:                                                        
    1      use the entered weight                                               
                                                                                
    2      ignore entered wt, use wt implicit in ICD-9-CM code                  
                                                                                
    3      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, flag wt as invalid                                  
                                                                                
    4      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag weight as invalid                                
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, flag wt as invalid                   
                                                                                
    5      ignore entered wt, use wt implicit in ICD-9-CM code                  
           if invalid, default to normal wt                                     
                                                                                
    6      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, default to normal wt                                
                                                                                
    7      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag wt as invalid                                    
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, default to normal                    
                                                                                
    notes  1. Normal birth weight range is 200 - 7000 g.                        
           2. If option entry is invalid or missing, it defaults to 7.          
           3. For a crosscheck, a comparison is made between the entered        
              birth weight and the implicit birth weight.                       
           4. If the birth weight is required, the system returns DRG 956.      
           5. The normal weight default assumes birth weight is set             
              to >= 2499 g.                                                     
           6. Logic is only performed if age on admit <= 14 days.               
*/                                                                              
     char  FAR *lvdmv,            /* days on mech. vent. 3 chars 000-999 */     
     char  FAR *lvdmva,           /* days after admission when placed on        
                                     mech. ventilator 3 chars -99-999           
                                     left justified, blank padded               
									 FOR FUTURE USE                      */                       
     char  FAR *lvremap,          /* 1 char 0-2, 0 = no remapping               
                                     1 = historical remapping                   
									 2 = logical/clinical remapping                               
									 other = no remapping                                         
								   */                                                           
                                                                                
     char  FAR *lvdischDRGopt,    /* 1 char
								     0 or space will compute Discharge DRG  
									   using HAC processing.
								     1 will compute Discharge DRG excluding
									   all complication of care
									   codes. No Admit DRG will be returned.
								   */
     char  FAR *lvagency,         /* 1 char - needed by HAC logic        
								     1 Medicare HAC logic
								     2 Medicaid HAC logic
								   */
     char  FAR *lvHACvers,        /* 3 char - e.g. 290 */        



                 /* ------  output arguments ----- */
     char  FAR *lvers,            /* grouper version 11 chars
                                   * HASvv-mm/dd
                                   */
     char  FAR *lvrtc,            /* dicharge return code 2 chars 00-12    */
     char  FAR *lvmdc,            /* discharge MDC 2 chars 00-25           */
     char  FAR *lvdrg,            /* discharge DRG 3 chars 001-999         */
     char  FAR *lvsoi,            /* disch. severity of illness 1 char 0-4 */
     char  FAR *lvrom,            /* disch. risk of mortality   1 char 0-4 */
     char  FAR *lvmed_surg_ind,   /* discharge DRG Medical/Surgical
                                   * Indicator 1 char
                                   * 0=Discharge RTC is non-zero
                                   * 1=Medical  Discharge DRG
                                   * 2=Surgical Discharge DRG
                                   */
     char  FAR *lvrtc_admit,      /* admission return code 2 chars 00-12  */
     char  FAR *lvmdc_admit,      /* admission MDC 2 chars 00-25          */
     char  FAR *lvdrg_admit,      /* admission DRG 3 chars 001-999        */
     char  FAR *lvsoi_admit,      /* admit severity of illness 1 char 0-4 */
     char  FAR *lvrom_admit,      /* admit risk of mortality   1 char 0-4 */
     char  FAR *lvmed_surg_ind_admit, /* Admission DRG Medical/Surgical
                                   * Indicator 1 char
                                   * 0=Admission RTC is non-zero
                                   * 1=Medical  Admission DRG
                                   * 2=Surgical Admission DRG
                                   */
     char  FAR *lvdx_flags,       /* Diagnosis Flags Table
                                   * array of 50 x 10 chars each
                                   * [n][0] Diagnosis Validity
                                   *   0=diagnosis is invalid
                                   *   1=diagnosis is valid
                                   * [n][1] Diagnosis Affects DRG
                                   *   0=diag did not affect the DRG
                                   *   1=diag affected disch DRG only
                                   *   2=diag affected admit DRG only
                                   *   3=diag affected both disch
                                   *     and admit DRG
                                   *   4=diag affected HAC DRG only
                                   *   5=diag aff disch & HAC DRG
                                   *   6=diag aff admit & HAC DRG
                                   *   7=diag aff admit, dish & 
                                   *     HAC DRG
                                   * [n][2] Diagnosis Affects SOI
                                   *   0=diag did not affect the SOI
                                   *   1=diag affected disch SOI only
                                   *   2=diag affected admit SOI only
                                   *   3=diag affected both disch
                                   *     and admit SOI
                                   *   4=diag affected HAC SOI only
                                   *   5=diag aff disch & HAC SOI
                                   *   6=diag aff admit & HAC SOI
                                   *   7=diag aff admit, dish &
                                   *     HAC SOI
                                   * [n][3] Diagnosis Affects ROM
                                   *   0=diag did not affect the ROM
                                   *   1=diag affected disch ROM only
                                   *   2=diag affected admit ROM only
                                   *   3=diag affected both disch
                                   *     and admit ROM
                                   *   4=diag affected HAC ROM only
                                   *   5=diag aff disch & HAC ROM
                                   *   6=diag aff admit & HAC ROM
                                   *   7=diag aff admit, dish &
                                   *     HAC ROM
                                   * [n][4] Diagnosis Discharge SOI Level
                                   *   C=Excluded Complication of Care
                                   *   D=Duplicate Secondary DX
                                   *   P=Indicates Principal DX
                                   *   X=Excluded
                                   *   0=Non-groupable claim
                                   *   1=Minor
                                   *   2=Moderate
                                   *   3=Major
                                   *   4=Extreme
                                   *   blank=DX not recognized or excluded HAC
                                   * [n][5] Diagnosis Discharge ROM Level
								   *    same values as DX Discharge SOI Level
                                   * [n][6] Diagnosis Admission SOI Level
								   *    same values as DX Discharge SOI Level
                                   * [n][7] Diagnosis Admission ROM Level
								   *    same values as DX Discharge SOI Level
                                   * [n][8] Diagnosis HAC SOI Level
								   *    same values as DX Discharge SOI Level
                                   * [n][9] Diagnosis HAC ROM Level
								   *    same values as DX Discharge SOI Level
								   */
     char  FAR * lvsg_flags,      /* Procedure Flags Table
                                   * array of 50 x 5 chars each
                                   * [n][0] Procedure Validity
                                   *   0=procedure is invalid
                                   *   1=procedure is valid
                                   * [n][1] Procedure Affects DRG
                                   *   0=proc did not affect the DRG
                                   *   1=proc affected disch DRG only
                                   *   2=proc affected admit DRG only
                                   *   3=proc affected both disch
                                   *     and admit DRG
                                   *   4=proc affected HAC DRG only
                                   *   5=proc aff disch & HAC DRG
                                   *   6=proc aff admit & HAC DRG
                                   *   7=proc aff admit, disch &
                                   *     HAC DRG
                                   * [n][2] Procedure Affects SOI
                                   *   0=proc did not affect the SOI
                                   *   1=proc affected disch SOI only
                                   *   2=proc affected admit SOI only
                                   *   3=proc affected both disch
                                   *     and admit SOI
                                   *   4=proc affected HAC SOI only
                                   *   5=proc aff disch & HAC SOI
                                   *   6=proc aff admit & HAC SOI
                                   *   7=proc aff admit, disch &
                                   *     HAC SOI
                                   * [n][3] Procedure Affects ROM
                                   *   0=proc did not affect the ROM
                                   *   1=proc affected disch ROM only
                                   *   2=proc affected admit ROM only
                                   *   3=proc affected both disch
                                   *     and admit ROM
                                   *   4=proc affected HAC ROM only
                                   *   5=proc aff disch & HAC ROM
                                   *   6=proc aff admit & HAC ROM
                                   *   7=proc aff admit, disch &
                                   *     HAC ROM
                                   * [n][4] OR/Non-OR Procedure
                                   *   0=not an OR procedure
                                   *   1=operating room (OR) procedure
                                   */
     char  FAR *lvrtc_hac,        /* HAC return code 2 chars 00-12  */
     char  FAR *lvmdc_hac,        /* HAC MDC 2 chars 00-25          */
     char  FAR *lvdrg_hac,        /* HAC DRG 3 chars 001-999        */
     char  FAR *lvsoi_hac,        /* HAC severity of illness 1 char 0-4 */
     char  FAR *lvrom_hac,        /* HAC risk of mortality   1 char 0-4 */
     char  FAR *lvmed_surg_ind_hac /* HAC DRG Medical/Surgical
                                   * Indicator 1 char
                                   * 0=HAC RTC is non-zero
                                   * 1=Medical  HAC DRG
                                   * 2=Surgical HAC DRG
                                   */
     );                                                                         
                                                                                
                                                                                
IRPEXTERNC short IRPEXTCALL HADS28CS                                            
  (Hadgrp2_Data * hgp);                                                         
                                                                                
IRPEXTERNC short IRPEXTCALL hads29c1(                                           
                 /* -------- input arguments ----- */                           
     short grpfunc,               /* grouper function:                          
                                   *   0 = group,                               
                                   *   1 = free grouper storage                 
                                   */                                           
     short lvndx,                 /* number diagnoses  50 MAX      */           
     short lvnsg,                 /* number procedures 50 MAX      */           
     char  FAR *lvdx_ptr,         /* array of 50 DX x 8 chars each              
                                   * left justified, blank padded               
                                   * rightmost char is POA indicator            
                                   */                                           
     char  FAR *lvsg_ptr,         /* array of 50 SG x 7 chars each              
                                   * left justified, blank padded               
                                   */                                           
     char  FAR *lvsex,            /* sex - 1 char 1,m,M or 2,f,F     */         
     char  FAR *lvdstat,          /* UB82 discharge stat 2 chars     */         
     char  FAR *lvbirth_date,     /* birth date 8 chars MMDDYYYY     */         
     char  FAR *lvadmit_date,     /* admit date 8 chars MMDDYYYY     */         
     char  FAR *lvdisch_date,     /* discharge date 8 chars MMDDYYYY */         
     char  FAR *lvsg_dates,       /* array of 50 procedure dates                
                                   * 8 chars each MMDDYYYY                      
                                   */                                           
     char  *lvbwght,              /* birth weight in grams 0200-7000*/          
     char  *lvbwtopt,             /* birth weight option 1-7        */          
/* birth weight options:                                                        
    1      use the entered weight                                               
                                                                                
    2      ignore entered wt, use wt implicit in ICD-9-CM code                  
                                                                                
    3      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, flag wt as invalid                                  
                                                                                
    4      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag weight as invalid                                
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, flag wt as invalid                   
                                                                                
    5      ignore entered wt, use wt implicit in ICD-9-CM code                  
           if invalid, default to normal wt                                     
                                                                                
    6      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, default to normal wt                                
                                                                                
    7      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag wt as invalid                                    
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, default to normal                    
                                                                                
    notes  1. Normal birth weight range is 200 - 7000 g.                        
           2. If option entry is invalid or missing, it defaults to 7.          
           3. For a crosscheck, a comparison is made between the entered        
              birth weight and the implicit birth weight.                       
           4. If the birth weight is required, the system returns DRG 956.      
           5. The normal weight default assumes birth weight is set             
              to >= 2499 g.                                                     
           6. Logic is only performed if age on admit <= 14 days.               
*/                                                                              
     char  FAR *lvdmv,            /* days on mech. vent. 3 chars 000-999 */     
     char  FAR *lvdmva,           /* days after admission when placed on        
                                     mech. ventilator 3 chars -99-999           
                                     left justified, blank padded               
									 FOR FUTURE USE                      */                       
     char  FAR *lvremap,          /* 1 char 0-2, 0 = no remapping               
                                     1 = historical remapping                   
									 2 = logical/clinical remapping                               
									 other = no remapping                                         
								   */                                                           
     char  FAR *lvdischDRGopt,    /* 1 char
								     0 or space will compute Discharge DRG  
									   using HAC processing.
								     1 will compute Discharge DRG excluding
									   all complication of care
									   codes. No Admit DRG will be returned.
								   */
     char  FAR *lvagency,         /* 1 char - needed by HAC logic        
								     1 Medicare HAC logic
								     2 Medicaid HAC logic
								   */
     char  FAR *lvHACvers,        /* 3 char - e.g. 300 */        

                                                                                
                 /* ------  output arguments ----- */                           
     char  FAR *lvers,            /* grouper version 11 chars                   
                                   * HASvv-mm/dd                                
                                   */                                           
     char  FAR *lvrtc,            /* dicharge return code 2 chars 00-12    */   
     char  FAR *lvmdc,            /* discharge MDC 2 chars 00-25           */   
     char  FAR *lvdrg,            /* discharge DRG 3 chars 001-999         */   
     char  FAR *lvsoi,            /* disch. severity of illness 1 char 0-4 */   
     char  FAR *lvrom,            /* disch. risk of mortality   1 char 0-4 */   
     char  FAR *lvmed_surg_ind,   /* discharge DRG Medical/Surgical             
                                   * Indicator 1 char                           
                                   * 0=Discharge RTC is non-zero                
                                   * 1=Medical  Discharge DRG                   
                                   * 2=Surgical Discharge DRG                   
                                   */                                           
     char  FAR *lvrtc_admit,      /* admission return code 2 chars 00-12  */    
     char  FAR *lvmdc_admit,      /* admission MDC 2 chars 00-25          */    
     char  FAR *lvdrg_admit,      /* admission DRG 3 chars 001-999        */    
     char  FAR *lvsoi_admit,      /* admit severity of illness 1 char 0-4 */    
     char  FAR *lvrom_admit,      /* admit risk of mortality   1 char 0-4 */    
     char  FAR *lvmed_surg_ind_admit, /* Admission DRG Medical/Surgical         
                                   * Indicator 1 char                           
                                   * 0=Admission RTC is non-zero                
                                   * 1=Medical  Admission DRG                   
                                   * 2=Surgical Admission DRG                   
                                   */                                           
     char  FAR *lvdx_flags,       /* Diagnosis Flags Table                      
                                   * array of 50 x 10 chars each                
                                   * [n][0] Diagnosis Validity                  
                                   *   0=diagnosis is invalid                   
                                   *   1=diagnosis is valid                     
                                   * [n][1] Diagnosis Affects DRG               
                                   *   0=diag did not affect the DRG            
                                   *   1=diag affected disch DRG only           
                                   *   2=diag affected admit DRG only           
                                   *   3=diag affected both disch               
                                   *     and admit DRG                          
                                   *   4=diag affected HAC DRG only             
                                   *   5=diag aff disch & HAC DRG               
                                   *   6=diag aff admit & HAC DRG               
                                   *   7=diag aff admit, dish &                 
                                   *     HAC DRG                                
                                   * [n][2] Diagnosis Affects SOI               
                                   *   0=diag did not affect the SOI            
                                   *   1=diag affected disch SOI only           
                                   *   2=diag affected admit SOI only           
                                   *   3=diag affected both disch               
                                   *     and admit SOI                          
                                   *   4=diag affected HAC SOI only             
                                   *   5=diag aff disch & HAC SOI               
                                   *   6=diag aff admit & HAC SOI               
                                   *   7=diag aff admit, dish &                 
                                   *     HAC SOI                                
                                   * [n][3] Diagnosis Affects ROM               
                                   *   0=diag did not affect the ROM            
                                   *   1=diag affected disch ROM only           
                                   *   2=diag affected admit ROM only           
                                   *   3=diag affected both disch               
                                   *     and admit ROM                          
                                   *   4=diag affected HAC ROM only             
                                   *   5=diag aff disch & HAC ROM               
                                   *   6=diag aff admit & HAC ROM               
                                   *   7=diag aff admit, dish &                 
                                   *     HAC ROM                                
                                   * [n][4] Diagnosis Discharge SOI Level       
                                   *   C=Excluded Complication of Care          
                                   *   D=Duplicate Secondary DX                 
                                   *   P=Indicates Principal DX                 
                                   *   X=Excluded                               
                                   *   0=Non-groupable claim                    
                                   *   1=Minor                                  
                                   *   2=Moderate                               
                                   *   3=Major                                  
                                   *   4=Extreme                                
                                   *   blank=DX not recognized or excluded HAC  
                                   * [n][5] Diagnosis Discharge ROM Level       
								   *    same values as DX Discharge SOI Level                   
                                   * [n][6] Diagnosis Admission SOI Level       
								   *    same values as DX Discharge SOI Level                   
                                   * [n][7] Diagnosis Admission ROM Level       
								   *    same values as DX Discharge SOI Level                   
                                   * [n][8] Diagnosis HAC SOI Level             
								   *    same values as DX Discharge SOI Level                   
                                   * [n][9] Diagnosis HAC ROM Level             
								   *    same values as DX Discharge SOI Level                   
								   */                                                           
     char  FAR * lvsg_flags       /* Procedure Flags Table                      
                                   * array of 50 x 5 chars each                 
                                   * [n][0] Procedure Validity                  
                                   *   0=procedure is invalid                   
                                   *   1=procedure is valid                     
                                   * [n][1] Procedure Affects DRG               
                                   *   0=proc did not affect the DRG            
                                   *   1=proc affected disch DRG only           
                                   *   2=proc affected admit DRG only           
                                   *   3=proc affected both disch               
                                   *     and admit DRG                          
                                   *   4=proc affected HAC DRG only             
                                   *   5=proc aff disch & HAC DRG               
                                   *   6=proc aff admit & HAC DRG               
                                   *   7=proc aff admit, disch &                
                                   *     HAC DRG                                
                                   * [n][2] Procedure Affects SOI               
                                   *   0=proc did not affect the SOI            
                                   *   1=proc affected disch SOI only           
                                   *   2=proc affected admit SOI only           
                                   *   3=proc affected both disch               
                                   *     and admit SOI                          
                                   *   4=proc affected HAC SOI only             
                                   *   5=proc aff disch & HAC SOI               
                                   *   6=proc aff admit & HAC SOI               
                                   *   7=proc aff admit, disch &                
                                   *     HAC SOI                                
                                   * [n][3] Procedure Affects ROM               
                                   *   0=proc did not affect the ROM            
                                   *   1=proc affected disch ROM only           
                                   *   2=proc affected admit ROM only           
                                   *   3=proc affected both disch               
                                   *     and admit ROM                          
                                   *   4=proc affected HAC ROM only             
                                   *   5=proc aff disch & HAC ROM               
                                   *   6=proc aff admit & HAC ROM               
                                   *   7=proc aff admit, disch &                
                                   *     HAC ROM                                
                                   * [n][4] OR/Non-OR Procedure                 
                                   *   0=not an OR procedure                    
                                   *   1=operating room (OR) procedure          
                                   */                                           
     );                                                                         
                                                                                
                                                                                
IRPEXTERNC short IRPEXTCALL HADS29CS                                            
  (Hadgrp2_Data * hgp);                                                         
                                                                                
IRPEXTERNC short IRPEXTCALL hads30c1(                                           
                 /* -------- input arguments ----- */                           
     short grpfunc,               /* grouper function:                          
                                   *   0 = group,                               
                                   *   1 = free grouper storage                 
                                   */                                           
     short lvndx,                 /* number diagnoses  50 MAX      */           
     short lvnsg,                 /* number procedures 50 MAX      */           
     char  FAR *lvdx_ptr,         /* array of 50 DX x 8 chars each              
                                   * left justified, blank padded               
                                   * rightmost char is POA indicator            
                                   */                                           
     char  FAR *lvsg_ptr,         /* array of 50 SG x 7 chars each              
                                   * left justified, blank padded               
                                   */                                           
     char  FAR *lvsex,            /* sex - 1 char 1,m,M or 2,f,F     */         
     char  FAR *lvdstat,          /* UB82 discharge stat 2 chars     */         
     char  FAR *lvbirth_date,     /* birth date 8 chars MMDDYYYY     */         
     char  FAR *lvadmit_date,     /* admit date 8 chars MMDDYYYY     */         
     char  FAR *lvdisch_date,     /* discharge date 8 chars MMDDYYYY */         
     char  FAR *lvsg_dates,       /* array of 50 procedure dates                
                                   * 8 chars each MMDDYYYY                      
                                   */                                           
     char  *lvbwght,              /* birth weight in grams 0200-7000*/          
     char  *lvbwtopt,             /* birth weight option 1-7        */          
/* birth weight options:                                                        
    1      use the entered weight                                               
                                                                                
    2      ignore entered wt, use wt implicit in ICD-9-CM code                  
                                                                                
    3      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, flag wt as invalid                                  
                                                                                
    4      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag weight as invalid                                
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, flag wt as invalid                   
                                                                                
    5      ignore entered wt, use wt implicit in ICD-9-CM code                  
           if invalid, default to normal wt                                     
                                                                                
    6      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, default to normal wt                                
                                                                                
    7      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag wt as invalid                                    
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, default to normal                    
                                                                                
    notes  1. Normal birth weight range is 200 - 7000 g.                        
           2. If option entry is invalid or missing, it defaults to 7.          
           3. For a crosscheck, a comparison is made between the entered        
              birth weight and the implicit birth weight.                       
           4. If the birth weight is required, the system returns DRG 956.      
           5. The normal weight default assumes birth weight is set             
              to >= 2499 g.                                                     
           6. Logic is only performed if age on admit <= 14 days.               
*/                                                                              
     char  FAR *lvdmv,            /* days on mech. vent. 3 chars 000-999 */     
     char  FAR *lvdmva,           /* days after admission when placed on        
                                     mech. ventilator 3 chars -99-999           
                                     left justified, blank padded               
									 FOR FUTURE USE                      */                       
     char  FAR *lvremap,          /* 1 char 0-2, 0 = no remapping               
                                     1 = historical remapping                   
									 2 = logical/clinical remapping                               
									 other = no remapping                                         
								   */                                                           
     char  FAR *lvdischDRGopt,    /* 1 char
								     0 or space will compute Discharge DRG  
									   using HAC processing.
								     1 will compute Discharge DRG excluding
									   all complication of care
									   codes. No Admit DRG will be returned.
								   */
     char  FAR *lvagency,         /* 1 char - needed by HAC logic        
								     1 Medicare HAC logic
								     2 Medicaid HAC logic
								   */
     char  FAR *lvHACvers,        /* 3 char - e.g. 300 */        

                                                                                
                 /* ------  output arguments ----- */                           
     char  FAR *lvers,            /* grouper version 11 chars                   
                                   * HASvv-mm/dd                                
                                   */                                           
     char  FAR *lvrtc,            /* dicharge return code 2 chars 00-12    */   
     char  FAR *lvmdc,            /* discharge MDC 2 chars 00-25           */   
     char  FAR *lvdrg,            /* discharge DRG 3 chars 001-999         */   
     char  FAR *lvsoi,            /* disch. severity of illness 1 char 0-4 */   
     char  FAR *lvrom,            /* disch. risk of mortality   1 char 0-4 */   
     char  FAR *lvmed_surg_ind,   /* discharge DRG Medical/Surgical             
                                   * Indicator 1 char                           
                                   * 0=Discharge RTC is non-zero                
                                   * 1=Medical  Discharge DRG                   
                                   * 2=Surgical Discharge DRG                   
                                   */                                           
     char  FAR *lvrtc_admit,      /* admission return code 2 chars 00-12  */    
     char  FAR *lvmdc_admit,      /* admission MDC 2 chars 00-25          */    
     char  FAR *lvdrg_admit,      /* admission DRG 3 chars 001-999        */    
     char  FAR *lvsoi_admit,      /* admit severity of illness 1 char 0-4 */    
     char  FAR *lvrom_admit,      /* admit risk of mortality   1 char 0-4 */    
     char  FAR *lvmed_surg_ind_admit, /* Admission DRG Medical/Surgical         
                                   * Indicator 1 char                           
                                   * 0=Admission RTC is non-zero                
                                   * 1=Medical  Admission DRG                   
                                   * 2=Surgical Admission DRG                   
                                   */                                           
     char  FAR *lvdx_flags,       /* Diagnosis Flags Table                      
                                   * array of 50 x 10 chars each                
                                   * [n][0] Diagnosis Validity                  
                                   *   0=diagnosis is invalid                   
                                   *   1=diagnosis is valid                     
                                   * [n][1] Diagnosis Affects DRG               
                                   *   0=diag did not affect the DRG            
                                   *   1=diag affected disch DRG only           
                                   *   2=diag affected admit DRG only           
                                   *   3=diag affected both disch               
                                   *     and admit DRG                          
                                   *   4=diag affected HAC DRG only             
                                   *   5=diag aff disch & HAC DRG               
                                   *   6=diag aff admit & HAC DRG               
                                   *   7=diag aff admit, dish &                 
                                   *     HAC DRG                                
                                   * [n][2] Diagnosis Affects SOI               
                                   *   0=diag did not affect the SOI            
                                   *   1=diag affected disch SOI only           
                                   *   2=diag affected admit SOI only           
                                   *   3=diag affected both disch               
                                   *     and admit SOI                          
                                   *   4=diag affected HAC SOI only             
                                   *   5=diag aff disch & HAC SOI               
                                   *   6=diag aff admit & HAC SOI               
                                   *   7=diag aff admit, dish &                 
                                   *     HAC SOI                                
                                   * [n][3] Diagnosis Affects ROM               
                                   *   0=diag did not affect the ROM            
                                   *   1=diag affected disch ROM only           
                                   *   2=diag affected admit ROM only           
                                   *   3=diag affected both disch               
                                   *     and admit ROM                          
                                   *   4=diag affected HAC ROM only             
                                   *   5=diag aff disch & HAC ROM               
                                   *   6=diag aff admit & HAC ROM               
                                   *   7=diag aff admit, dish &                 
                                   *     HAC ROM                                
                                   * [n][4] Diagnosis Discharge SOI Level       
                                   *   C=Excluded Complication of Care          
                                   *   D=Duplicate Secondary DX                 
                                   *   P=Indicates Principal DX                 
                                   *   X=Excluded                               
                                   *   0=Non-groupable claim                    
                                   *   1=Minor                                  
                                   *   2=Moderate                               
                                   *   3=Major                                  
                                   *   4=Extreme                                
                                   *   blank=DX not recognized or excluded HAC  
                                   * [n][5] Diagnosis Discharge ROM Level       
								   *    same values as DX Discharge SOI Level                   
                                   * [n][6] Diagnosis Admission SOI Level       
								   *    same values as DX Discharge SOI Level                   
                                   * [n][7] Diagnosis Admission ROM Level       
								   *    same values as DX Discharge SOI Level                   
                                   * [n][8] Diagnosis HAC SOI Level             
								   *    same values as DX Discharge SOI Level                   
                                   * [n][9] Diagnosis HAC ROM Level             
								   *    same values as DX Discharge SOI Level                   
								   */                                                           
     char  FAR * lvsg_flags       /* Procedure Flags Table                      
                                   * array of 50 x 5 chars each                 
                                   * [n][0] Procedure Validity                  
                                   *   0=procedure is invalid                   
                                   *   1=procedure is valid                     
                                   * [n][1] Procedure Affects DRG               
                                   *   0=proc did not affect the DRG            
                                   *   1=proc affected disch DRG only           
                                   *   2=proc affected admit DRG only           
                                   *   3=proc affected both disch               
                                   *     and admit DRG                          
                                   *   4=proc affected HAC DRG only             
                                   *   5=proc aff disch & HAC DRG               
                                   *   6=proc aff admit & HAC DRG               
                                   *   7=proc aff admit, disch &                
                                   *     HAC DRG                                
                                   * [n][2] Procedure Affects SOI               
                                   *   0=proc did not affect the SOI            
                                   *   1=proc affected disch SOI only           
                                   *   2=proc affected admit SOI only           
                                   *   3=proc affected both disch               
                                   *     and admit SOI                          
                                   *   4=proc affected HAC SOI only             
                                   *   5=proc aff disch & HAC SOI               
                                   *   6=proc aff admit & HAC SOI               
                                   *   7=proc aff admit, disch &                
                                   *     HAC SOI                                
                                   * [n][3] Procedure Affects ROM               
                                   *   0=proc did not affect the ROM            
                                   *   1=proc affected disch ROM only           
                                   *   2=proc affected admit ROM only           
                                   *   3=proc affected both disch               
                                   *     and admit ROM                          
                                   *   4=proc affected HAC ROM only             
                                   *   5=proc aff disch & HAC ROM               
                                   *   6=proc aff admit & HAC ROM               
                                   *   7=proc aff admit, disch &                
                                   *     HAC ROM                                
                                   * [n][4] OR/Non-OR Procedure                 
                                   *   0=not an OR procedure                    
                                   *   1=operating room (OR) procedure          
                                   */                                           
     );                                                                         
                                                                                
                                                                                
IRPEXTERNC short IRPEXTCALL HADS30CS                                            
  (Hadgrp2_Data * hgp);                                                         
                                                                                

IRPEXTERNC short IRPEXTCALL hads31c1(                                           
                 /* -------- input arguments ----- */                           
     short grpfunc,               /* grouper function:                          
                                   *   0 = group,                               
                                   *   1 = free grouper storage                 
                                   */                                           
     short lvndx,                 /* number diagnoses  50 MAX      */           
     short lvnsg,                 /* number procedures 50 MAX      */           
     char  FAR *lvdx_ptr,         /* array of 50 DX x 8 chars each              
                                   * left justified, blank padded               
                                   * rightmost char is POA indicator            
                                   */                                           
     char  FAR *lvsg_ptr,         /* array of 50 SG x 7 chars each              
                                   * left justified, blank padded               
                                   */                                           
     char  FAR *lvsex,            /* sex - 1 char 1,m,M or 2,f,F     */         
     char  FAR *lvdstat,          /* UB82 discharge stat 2 chars     */         
     char  FAR *lvbirth_date,     /* birth date 8 chars MMDDYYYY     */         
     char  FAR *lvadmit_date,     /* admit date 8 chars MMDDYYYY     */         
     char  FAR *lvdisch_date,     /* discharge date 8 chars MMDDYYYY */         
     char  FAR *lvsg_dates,       /* array of 50 procedure dates                
                                   * 8 chars each MMDDYYYY                      
                                   */                                           
     char  *lvbwght,              /* birth weight in grams 0200-7000*/          
     char  *lvbwtopt,             /* birth weight option 1-7        */          
/* birth weight options:                                                        
    1      use the entered weight                                               
                                                                                
    2      ignore entered wt, use wt implicit in ICD-9-CM code                  
                                                                                
    3      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, flag wt as invalid                                  
                                                                                
    4      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag weight as invalid                                
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, flag wt as invalid                   
                                                                                
    5      ignore entered wt, use wt implicit in ICD-9-CM code                  
           if invalid, default to normal wt                                     
                                                                                
    6      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, default to normal wt                                
                                                                                
    7      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag wt as invalid                                    
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, default to normal                    
                                                                                
    notes  1. Normal birth weight range is 200 - 7000 g.                        
           2. If option entry is invalid or missing, it defaults to 7.          
           3. For a crosscheck, a comparison is made between the entered        
              birth weight and the implicit birth weight.                       
           4. If the birth weight is required, the system returns DRG 956.      
           5. The normal weight default assumes birth weight is set             
              to >= 2499 g.                                                     
           6. Logic is only performed if age on admit <= 14 days.               
*/                                                                              
     char  FAR *lvdmv,            /* days on mech. vent. 3 chars 000-999 */     
     char  FAR *lvdmva,           /* days after admission when placed on        
                                     mech. ventilator 3 chars -99-999           
                                     left justified, blank padded               
									 FOR FUTURE USE                      */                       
     char  FAR *lvremap,          /* 1 char 0-2, 0 = no remapping               
                                     1 = historical remapping                   
									 2 = logical/clinical remapping                               
									 other = no remapping                                         
								   */                                                           
     char  FAR *lvdischDRGopt,    /* 1 char
								     0 or space will compute Discharge DRG  
									   using HAC processing.
								     1 will compute Discharge DRG excluding
									   all complication of care
									   codes. No Admit DRG will be returned.
								   */
     char  FAR *lvagency,         /* 2 char - needed by HAC logic        
								     1  Medicare HAC logic
								     2  Medicaid HAC logic
								     10 CA Medicaid HAC logic
								   */
     char  FAR *lvHACvers,        /* 3 char - e.g. 300 */        

                                                                                
                 /* ------  output arguments ----- */                           
     char  FAR *lvers,            /* grouper version 11 chars                   
                                   * HASvv-mm/dd                                
                                   */                                           
     char  FAR *lvrtc,            /* dicharge return code 2 chars 00-12    */   
     char  FAR *lvmdc,            /* discharge MDC 2 chars 00-25           */   
     char  FAR *lvdrg,            /* discharge DRG 3 chars 001-999         */   
     char  FAR *lvsoi,            /* disch. severity of illness 1 char 0-4 */   
     char  FAR *lvrom,            /* disch. risk of mortality   1 char 0-4 */   
     char  FAR *lvmed_surg_ind,   /* discharge DRG Medical/Surgical             
                                   * Indicator 1 char                           
                                   * 0=Discharge RTC is non-zero                
                                   * 1=Medical  Discharge DRG                   
                                   * 2=Surgical Discharge DRG                   
                                   */                                           
     char  FAR *lvrtc_admit,      /* admission return code 2 chars 00-12  */    
     char  FAR *lvmdc_admit,      /* admission MDC 2 chars 00-25          */    
     char  FAR *lvdrg_admit,      /* admission DRG 3 chars 001-999        */    
     char  FAR *lvsoi_admit,      /* admit severity of illness 1 char 0-4 */    
     char  FAR *lvrom_admit,      /* admit risk of mortality   1 char 0-4 */    
     char  FAR *lvmed_surg_ind_admit, /* Admission DRG Medical/Surgical         
                                   * Indicator 1 char                           
                                   * 0=Admission RTC is non-zero                
                                   * 1=Medical  Admission DRG                   
                                   * 2=Surgical Admission DRG                   
                                   */                                           
     char  FAR *lvdx_flags,       /* Diagnosis Flags Table                      
                                   * array of 50 x 10 chars each                
                                   * [n][0] Diagnosis Validity                  
                                   *   0=diagnosis is invalid                   
                                   *   1=diagnosis is valid                     
                                   * [n][1] Diagnosis Affects DRG               
                                   *   0=diag did not affect the DRG            
                                   *   1=diag affected disch DRG only           
                                   *   2=diag affected admit DRG only           
                                   *   3=diag affected both disch               
                                   *     and admit DRG                          
                                   *   4=diag affected HAC DRG only             
                                   *   5=diag aff disch & HAC DRG               
                                   *   6=diag aff admit & HAC DRG               
                                   *   7=diag aff admit, dish &                 
                                   *     HAC DRG                                
                                   * [n][2] Diagnosis Affects SOI               
                                   *   0=diag did not affect the SOI            
                                   *   1=diag affected disch SOI only           
                                   *   2=diag affected admit SOI only           
                                   *   3=diag affected both disch               
                                   *     and admit SOI                          
                                   *   4=diag affected HAC SOI only             
                                   *   5=diag aff disch & HAC SOI               
                                   *   6=diag aff admit & HAC SOI               
                                   *   7=diag aff admit, dish &                 
                                   *     HAC SOI                                
                                   * [n][3] Diagnosis Affects ROM               
                                   *   0=diag did not affect the ROM            
                                   *   1=diag affected disch ROM only           
                                   *   2=diag affected admit ROM only           
                                   *   3=diag affected both disch               
                                   *     and admit ROM                          
                                   *   4=diag affected HAC ROM only             
                                   *   5=diag aff disch & HAC ROM               
                                   *   6=diag aff admit & HAC ROM               
                                   *   7=diag aff admit, dish &                 
                                   *     HAC ROM                                
                                   * [n][4] Diagnosis Discharge SOI Level       
                                   *   C=Excluded Complication of Care          
                                   *   D=Duplicate Secondary DX                 
                                   *   P=Indicates Principal DX                 
                                   *   X=Excluded                               
                                   *   0=Non-groupable claim                    
                                   *   1=Minor                                  
                                   *   2=Moderate                               
                                   *   3=Major                                  
                                   *   4=Extreme                                
                                   *   blank=DX not recognized or excluded HAC  
                                   * [n][5] Diagnosis Discharge ROM Level       
								   *    same values as DX Discharge SOI Level                   
                                   * [n][6] Diagnosis Admission SOI Level       
								   *    same values as DX Discharge SOI Level                   
                                   * [n][7] Diagnosis Admission ROM Level       
								   *    same values as DX Discharge SOI Level                   
                                   * [n][8] Diagnosis HAC SOI Level             
								   *    same values as DX Discharge SOI Level                   
                                   * [n][9] Diagnosis HAC ROM Level             
								   *    same values as DX Discharge SOI Level                   
								   */                                                           
     char  FAR * lvsg_flags       /* Procedure Flags Table                      
                                   * array of 50 x 5 chars each                 
                                   * [n][0] Procedure Validity                  
                                   *   0=procedure is invalid                   
                                   *   1=procedure is valid                     
                                   * [n][1] Procedure Affects DRG               
                                   *   0=proc did not affect the DRG            
                                   *   1=proc affected disch DRG only           
                                   *   2=proc affected admit DRG only           
                                   *   3=proc affected both disch               
                                   *     and admit DRG                          
                                   *   4=proc affected HAC DRG only             
                                   *   5=proc aff disch & HAC DRG               
                                   *   6=proc aff admit & HAC DRG               
                                   *   7=proc aff admit, disch &                
                                   *     HAC DRG                                
                                   * [n][2] Procedure Affects SOI               
                                   *   0=proc did not affect the SOI            
                                   *   1=proc affected disch SOI only           
                                   *   2=proc affected admit SOI only           
                                   *   3=proc affected both disch               
                                   *     and admit SOI                          
                                   *   4=proc affected HAC SOI only             
                                   *   5=proc aff disch & HAC SOI               
                                   *   6=proc aff admit & HAC SOI               
                                   *   7=proc aff admit, disch &                
                                   *     HAC SOI                                
                                   * [n][3] Procedure Affects ROM               
                                   *   0=proc did not affect the ROM            
                                   *   1=proc affected disch ROM only           
                                   *   2=proc affected admit ROM only           
                                   *   3=proc affected both disch               
                                   *     and admit ROM                          
                                   *   4=proc affected HAC ROM only             
                                   *   5=proc aff disch & HAC ROM               
                                   *   6=proc aff admit & HAC ROM               
                                   *   7=proc aff admit, disch &                
                                   *     HAC ROM                                
                                   * [n][4] OR/Non-OR Procedure                 
                                   *   0=not an OR procedure                    
                                   *   1=operating room (OR) procedure          
                                   */                                           
     );                                                                         
                                                                                
                                                                                
IRPEXTERNC short IRPEXTCALL HADS31CS                                            
  (Hadgrp2_Data * hgp);                                                         
                                                                                
IRPEXTERNC short IRPEXTCALL hads32c1(                                           
                 /* -------- input arguments ----- */                           
     short grpfunc,               /* grouper function:                          
                                   *   0 = group,                               
                                   *   1 = free grouper storage                 
                                   */                                           
     short lvndx,                 /* number diagnoses  50 MAX      */           
     short lvnsg,                 /* number procedures 50 MAX      */           
     char  FAR *lvdx_ptr,         /* array of 50 DX x 8 chars each              
                                   * left justified, blank padded               
                                   * rightmost char is POA indicator            
                                   */                                           
     char  FAR *lvsg_ptr,         /* array of 50 SG x 7 chars each              
                                   * left justified, blank padded               
                                   */                                           
     char  FAR *lvsex,            /* sex - 1 char 1,m,M or 2,f,F     */         
     char  FAR *lvdstat,          /* UB82 discharge stat 2 chars     */         
     char  FAR *lvbirth_date,     /* birth date 8 chars MMDDYYYY     */         
     char  FAR *lvadmit_date,     /* admit date 8 chars MMDDYYYY     */         
     char  FAR *lvdisch_date,     /* discharge date 8 chars MMDDYYYY */         
     char  FAR *lvsg_dates,       /* array of 50 procedure dates                
                                   * 8 chars each MMDDYYYY                      
                                   */                                           
     char  *lvbwght,              /* birth weight in grams 0200-7000*/          
     char  *lvbwtopt,             /* birth weight option 1-7        */          
/* birth weight options:                                                        
    1      use the entered weight                                               
                                                                                
    2      ignore entered wt, use wt implicit in ICD-9-CM code                  
                                                                                
    3      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, flag wt as invalid                                  
                                                                                
    4      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag weight as invalid                                
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, flag wt as invalid                   
                                                                                
    5      ignore entered wt, use wt implicit in ICD-9-CM code                  
           if invalid, default to normal wt                                     
                                                                                
    6      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, default to normal wt                                
                                                                                
    7      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag wt as invalid                                    
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, default to normal                    
                                                                                
    notes  1. Normal birth weight range is 200 - 7000 g.                        
           2. If option entry is invalid or missing, it defaults to 7.          
           3. For a crosscheck, a comparison is made between the entered        
              birth weight and the implicit birth weight.                       
           4. If the birth weight is required, the system returns DRG 956.      
           5. The normal weight default assumes birth weight is set             
              to >= 2499 g.                                                     
           6. Logic is only performed if age on admit <= 14 days.               
*/                                                                              
     char  FAR *lvdmv,            /* days on mech. vent. 3 chars 000-999 */     
     char  FAR *lvdmva,           /* days after admission when placed on        
                                     mech. ventilator 3 chars -99-999           
                                     left justified, blank padded               
									 FOR FUTURE USE                      */                       
     char  FAR *lvremap,          /* 1 char 0-2, 0 = no remapping               
                                     1 = historical remapping                   
									 2 = logical/clinical remapping                               
									 other = no remapping                                         
								   */                                                           
     char  FAR *lvdischDRGopt,    /* 1 char
								     0 or space will compute Discharge DRG  
									   using HAC processing.
								     1 will compute Discharge DRG excluding
									   all complication of care
									   codes. No Admit DRG will be returned.
								   */
     char  FAR *lvagency,         /* 2 char - needed by HAC logic        
								     1  Medicare HAC logic
								     2  Medicaid HAC logic
								     10 CA Medicaid HAC logic
								   */
     char  FAR *lvHACvers,        /* 3 char - e.g. 300 */        

                                                                                
                 /* ------  output arguments ----- */                           
     char  FAR *lvers,            /* grouper version 11 chars                   
                                   * HASvv-mm/dd                                
                                   */                                           
     char  FAR *lvrtc,            /* dicharge return code 2 chars 00-12    */   
     char  FAR *lvmdc,            /* discharge MDC 2 chars 00-25           */   
     char  FAR *lvdrg,            /* discharge DRG 3 chars 001-999         */   
     char  FAR *lvsoi,            /* disch. severity of illness 1 char 0-4 */   
     char  FAR *lvrom,            /* disch. risk of mortality   1 char 0-4 */   
     char  FAR *lvmed_surg_ind,   /* discharge DRG Medical/Surgical             
                                   * Indicator 1 char                           
                                   * 0=Discharge RTC is non-zero                
                                   * 1=Medical  Discharge DRG                   
                                   * 2=Surgical Discharge DRG                   
                                   */                                           
     char  FAR *lvrtc_admit,      /* admission return code 2 chars 00-12  */    
     char  FAR *lvmdc_admit,      /* admission MDC 2 chars 00-25          */    
     char  FAR *lvdrg_admit,      /* admission DRG 3 chars 001-999        */    
     char  FAR *lvsoi_admit,      /* admit severity of illness 1 char 0-4 */    
     char  FAR *lvrom_admit,      /* admit risk of mortality   1 char 0-4 */    
     char  FAR *lvmed_surg_ind_admit, /* Admission DRG Medical/Surgical         
                                   * Indicator 1 char                           
                                   * 0=Admission RTC is non-zero                
                                   * 1=Medical  Admission DRG                   
                                   * 2=Surgical Admission DRG                   
                                   */                                           
     char  FAR *lvdx_flags,       /* Diagnosis Flags Table                      
                                   * array of 50 x 10 chars each                
                                   * [n][0] Diagnosis Validity                  
                                   *   0=diagnosis is invalid                   
                                   *   1=diagnosis is valid                     
                                   * [n][1] Diagnosis Affects DRG               
                                   *   0=diag did not affect the DRG            
                                   *   1=diag affected disch DRG only           
                                   *   2=diag affected admit DRG only           
                                   *   3=diag affected both disch               
                                   *     and admit DRG                          
                                   *   4=diag affected HAC DRG only             
                                   *   5=diag aff disch & HAC DRG               
                                   *   6=diag aff admit & HAC DRG               
                                   *   7=diag aff admit, dish &                 
                                   *     HAC DRG                                
                                   * [n][2] Diagnosis Affects SOI               
                                   *   0=diag did not affect the SOI            
                                   *   1=diag affected disch SOI only           
                                   *   2=diag affected admit SOI only           
                                   *   3=diag affected both disch               
                                   *     and admit SOI                          
                                   *   4=diag affected HAC SOI only             
                                   *   5=diag aff disch & HAC SOI               
                                   *   6=diag aff admit & HAC SOI               
                                   *   7=diag aff admit, dish &                 
                                   *     HAC SOI                                
                                   * [n][3] Diagnosis Affects ROM               
                                   *   0=diag did not affect the ROM            
                                   *   1=diag affected disch ROM only           
                                   *   2=diag affected admit ROM only           
                                   *   3=diag affected both disch               
                                   *     and admit ROM                          
                                   *   4=diag affected HAC ROM only             
                                   *   5=diag aff disch & HAC ROM               
                                   *   6=diag aff admit & HAC ROM               
                                   *   7=diag aff admit, dish &                 
                                   *     HAC ROM                                
                                   * [n][4] Diagnosis Discharge SOI Level       
                                   *   C=Excluded Complication of Care          
                                   *   D=Duplicate Secondary DX                 
                                   *   P=Indicates Principal DX                 
                                   *   X=Excluded                               
                                   *   0=Non-groupable claim                    
                                   *   1=Minor                                  
                                   *   2=Moderate                               
                                   *   3=Major                                  
                                   *   4=Extreme                                
                                   *   blank=DX not recognized or excluded HAC  
                                   * [n][5] Diagnosis Discharge ROM Level       
								   *    same values as DX Discharge SOI Level                   
                                   * [n][6] Diagnosis Admission SOI Level       
								   *    same values as DX Discharge SOI Level                   
                                   * [n][7] Diagnosis Admission ROM Level       
								   *    same values as DX Discharge SOI Level                   
                                   * [n][8] Diagnosis HAC SOI Level             
								   *    same values as DX Discharge SOI Level                   
                                   * [n][9] Diagnosis HAC ROM Level             
								   *    same values as DX Discharge SOI Level                   
								   */                                                           
     char  FAR * lvsg_flags       /* Procedure Flags Table                      
                                   * array of 50 x 5 chars each                 
                                   * [n][0] Procedure Validity                  
                                   *   0=procedure is invalid                   
                                   *   1=procedure is valid                     
                                   * [n][1] Procedure Affects DRG               
                                   *   0=proc did not affect the DRG            
                                   *   1=proc affected disch DRG only           
                                   *   2=proc affected admit DRG only           
                                   *   3=proc affected both disch               
                                   *     and admit DRG                          
                                   *   4=proc affected HAC DRG only             
                                   *   5=proc aff disch & HAC DRG               
                                   *   6=proc aff admit & HAC DRG               
                                   *   7=proc aff admit, disch &                
                                   *     HAC DRG                                
                                   * [n][2] Procedure Affects SOI               
                                   *   0=proc did not affect the SOI            
                                   *   1=proc affected disch SOI only           
                                   *   2=proc affected admit SOI only           
                                   *   3=proc affected both disch               
                                   *     and admit SOI                          
                                   *   4=proc affected HAC SOI only             
                                   *   5=proc aff disch & HAC SOI               
                                   *   6=proc aff admit & HAC SOI               
                                   *   7=proc aff admit, disch &                
                                   *     HAC SOI                                
                                   * [n][3] Procedure Affects ROM               
                                   *   0=proc did not affect the ROM            
                                   *   1=proc affected disch ROM only           
                                   *   2=proc affected admit ROM only           
                                   *   3=proc affected both disch               
                                   *     and admit ROM                          
                                   *   4=proc affected HAC ROM only             
                                   *   5=proc aff disch & HAC ROM               
                                   *   6=proc aff admit & HAC ROM               
                                   *   7=proc aff admit, disch &                
                                   *     HAC ROM                                
                                   * [n][4] OR/Non-OR Procedure                 
                                   *   0=not an OR procedure                    
                                   *   1=operating room (OR) procedure          
                                   */                                           
     );                                                                         
                                                                                
                                                                                
IRPEXTERNC short IRPEXTCALL HADS32CS
  (Hadgrp2_Data * hgp);                                                         
                                                                                
IRPEXTERNC short IRPEXTCALL hads33c1(
                 /* -------- input arguments ----- */                           
     short grpfunc,               /* grouper function:                          
                                   *   0 = group,                               
                                   *   1 = free grouper storage                 
                                   */                                           
     short lvndx,                 /* number diagnoses  50 MAX      */           
     short lvnsg,                 /* number procedures 50 MAX      */           
     char  FAR *lvdx_ptr,         /* array of 50 DX x 8 chars each              
                                   * left justified, blank padded               
                                   * rightmost char is POA indicator            
                                   */                                           
     char  FAR *lvsg_ptr,         /* array of 50 SG x 7 chars each              
                                   * left justified, blank padded               
                                   */                                           
     char  FAR *lvsex,            /* sex - 1 char 1,m,M or 2,f,F     */         
     char  FAR *lvdstat,          /* UB82 discharge stat 2 chars     */         
     char  FAR *lvbirth_date,     /* birth date 8 chars MMDDYYYY     */         
     char  FAR *lvadmit_date,     /* admit date 8 chars MMDDYYYY     */         
     char  FAR *lvdisch_date,     /* discharge date 8 chars MMDDYYYY */         
     char  FAR *lvsg_dates,       /* array of 50 procedure dates                
                                   * 8 chars each MMDDYYYY                      
                                   */                                           
     char  *lvbwght,              /* birth weight in grams 0200-7000*/          
     char  *lvbwtopt,             /* birth weight option 1-7        */          
/* birth weight options:                                                        
    1      use the entered weight                                               
                                                                                
    2      ignore entered wt, use wt implicit in ICD-9-CM code                  
                                                                                
    3      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, flag wt as invalid                                  
                                                                                
    4      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag weight as invalid                                
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, flag wt as invalid                   
                                                                                
    5      ignore entered wt, use wt implicit in ICD-9-CM code                  
           if invalid, default to normal wt                                     
                                                                                
    6      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, default to normal wt                                
                                                                                
    7      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag wt as invalid                                    
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, default to normal                    
                                                                                
    notes  1. Normal birth weight range is 200 - 7000 g.                        
           2. If option entry is invalid or missing, it defaults to 7.          
           3. For a crosscheck, a comparison is made between the entered        
              birth weight and the implicit birth weight.                       
           4. If the birth weight is required, the system returns DRG 956.      
           5. The normal weight default assumes birth weight is set             
              to >= 2499 g.                                                     
           6. Logic is only performed if age on admit <= 14 days.               
*/                                                                              
     char  FAR *lvdmv,            /* days on mech. vent. 3 chars 000-999 */     
     char  FAR *lvdmva,           /* days after admission when placed on        
                                     mech. ventilator 3 chars -99-999           
                                     left justified, blank padded               
									 FOR FUTURE USE                      */                       
     char  FAR *lvremap,          /* 1 char 0-2, 0 = no remapping               
                                     1 = historical remapping                   
									 2 = logical/clinical remapping                               
									 other = no remapping                                         
								   */                                                           
     char  FAR *lvdischDRGopt,    /* 1 char
								     0 or space will compute Discharge DRG  
									   using HAC processing.
								     1 will compute Discharge DRG excluding
									   all complication of care
									   codes. No Admit DRG will be returned.
								   */
     char  FAR *lvagency,         /* 2 char - needed by HAC logic        
								     1  Medicare HAC logic
								     2  Medicaid HAC logic
								     10 CA Medicaid HAC logic
								   */
     char  FAR *lvHACvers,        /* 3 char - e.g. 300 */        

                                                                                
                 /* ------  output arguments ----- */                           
     char  FAR *lvers,            /* grouper version 11 chars                   
                                   * HASvv-mm/dd                                
                                   */                                           
     char  FAR *lvrtc,            /* dicharge return code 2 chars 00-12    */   
     char  FAR *lvmdc,            /* discharge MDC 2 chars 00-25           */   
     char  FAR *lvdrg,            /* discharge DRG 3 chars 001-999         */   
     char  FAR *lvsoi,            /* disch. severity of illness 1 char 0-4 */   
     char  FAR *lvrom,            /* disch. risk of mortality   1 char 0-4 */   
     char  FAR *lvmed_surg_ind,   /* discharge DRG Medical/Surgical             
                                   * Indicator 1 char                           
                                   * 0=Discharge RTC is non-zero                
                                   * 1=Medical  Discharge DRG                   
                                   * 2=Surgical Discharge DRG                   
                                   */                                           
     char  FAR *lvrtc_admit,      /* admission return code 2 chars 00-12  */    
     char  FAR *lvmdc_admit,      /* admission MDC 2 chars 00-25          */    
     char  FAR *lvdrg_admit,      /* admission DRG 3 chars 001-999        */    
     char  FAR *lvsoi_admit,      /* admit severity of illness 1 char 0-4 */    
     char  FAR *lvrom_admit,      /* admit risk of mortality   1 char 0-4 */    
     char  FAR *lvmed_surg_ind_admit, /* Admission DRG Medical/Surgical         
                                   * Indicator 1 char                           
                                   * 0=Admission RTC is non-zero                
                                   * 1=Medical  Admission DRG                   
                                   * 2=Surgical Admission DRG                   
                                   */                                           
     char  FAR *lvdx_flags,       /* Diagnosis Flags Table                      
                                   * array of 50 x 10 chars each                
                                   * [n][0] Diagnosis Validity                  
                                   *   0=diagnosis is invalid                   
                                   *   1=diagnosis is valid                     
                                   * [n][1] Diagnosis Affects DRG               
                                   *   0=diag did not affect the DRG            
                                   *   1=diag affected disch DRG only           
                                   *   2=diag affected admit DRG only           
                                   *   3=diag affected both disch               
                                   *     and admit DRG                          
                                   *   4=diag affected HAC DRG only             
                                   *   5=diag aff disch & HAC DRG               
                                   *   6=diag aff admit & HAC DRG               
                                   *   7=diag aff admit, dish &                 
                                   *     HAC DRG                                
                                   * [n][2] Diagnosis Affects SOI               
                                   *   0=diag did not affect the SOI            
                                   *   1=diag affected disch SOI only           
                                   *   2=diag affected admit SOI only           
                                   *   3=diag affected both disch               
                                   *     and admit SOI                          
                                   *   4=diag affected HAC SOI only             
                                   *   5=diag aff disch & HAC SOI               
                                   *   6=diag aff admit & HAC SOI               
                                   *   7=diag aff admit, dish &                 
                                   *     HAC SOI                                
                                   * [n][3] Diagnosis Affects ROM               
                                   *   0=diag did not affect the ROM            
                                   *   1=diag affected disch ROM only           
                                   *   2=diag affected admit ROM only           
                                   *   3=diag affected both disch               
                                   *     and admit ROM                          
                                   *   4=diag affected HAC ROM only             
                                   *   5=diag aff disch & HAC ROM               
                                   *   6=diag aff admit & HAC ROM               
                                   *   7=diag aff admit, dish &                 
                                   *     HAC ROM                                
                                   * [n][4] Diagnosis Discharge SOI Level       
                                   *   C=Excluded Complication of Care          
                                   *   D=Duplicate Secondary DX                 
                                   *   P=Indicates Principal DX                 
                                   *   X=Excluded                               
                                   *   0=Non-groupable claim                    
                                   *   1=Minor                                  
                                   *   2=Moderate                               
                                   *   3=Major                                  
                                   *   4=Extreme                                
                                   *   blank=DX not recognized or excluded HAC  
                                   * [n][5] Diagnosis Discharge ROM Level       
								   *    same values as DX Discharge SOI Level                   
                                   * [n][6] Diagnosis Admission SOI Level       
								   *    same values as DX Discharge SOI Level                   
                                   * [n][7] Diagnosis Admission ROM Level       
								   *    same values as DX Discharge SOI Level                   
                                   * [n][8] Diagnosis HAC SOI Level             
								   *    same values as DX Discharge SOI Level                   
                                   * [n][9] Diagnosis HAC ROM Level             
								   *    same values as DX Discharge SOI Level                   
								   */                                                           
     char  FAR * lvsg_flags       /* Procedure Flags Table                      
                                   * array of 50 x 5 chars each                 
                                   * [n][0] Procedure Validity                  
                                   *   0=procedure is invalid                   
                                   *   1=procedure is valid                     
                                   * [n][1] Procedure Affects DRG               
                                   *   0=proc did not affect the DRG            
                                   *   1=proc affected disch DRG only           
                                   *   2=proc affected admit DRG only           
                                   *   3=proc affected both disch               
                                   *     and admit DRG                          
                                   *   4=proc affected HAC DRG only             
                                   *   5=proc aff disch & HAC DRG               
                                   *   6=proc aff admit & HAC DRG               
                                   *   7=proc aff admit, disch &                
                                   *     HAC DRG                                
                                   * [n][2] Procedure Affects SOI               
                                   *   0=proc did not affect the SOI            
                                   *   1=proc affected disch SOI only           
                                   *   2=proc affected admit SOI only           
                                   *   3=proc affected both disch               
                                   *     and admit SOI                          
                                   *   4=proc affected HAC SOI only             
                                   *   5=proc aff disch & HAC SOI               
                                   *   6=proc aff admit & HAC SOI               
                                   *   7=proc aff admit, disch &                
                                   *     HAC SOI                                
                                   * [n][3] Procedure Affects ROM               
                                   *   0=proc did not affect the ROM            
                                   *   1=proc affected disch ROM only           
                                   *   2=proc affected admit ROM only           
                                   *   3=proc affected both disch               
                                   *     and admit ROM                          
                                   *   4=proc affected HAC ROM only             
                                   *   5=proc aff disch & HAC ROM               
                                   *   6=proc aff admit & HAC ROM               
                                   *   7=proc aff admit, disch &                
                                   *     HAC ROM                                
                                   * [n][4] OR/Non-OR Procedure                 
                                   *   0=not an OR procedure                    
                                   *   1=operating room (OR) procedure          
                                   */                                           
     );                                                                         
                                                                                
                                                                                
IRPEXTERNC short IRPEXTCALL HADS33CS
  (Hadgrp2_Data * hgp);                                                         
                                                                                
IRPEXTERNC short IRPEXTCALL hads34c1(
                 /* -------- input arguments ----- */                           
     short grpfunc,               /* grouper function:                          
                                   *   0 = group,                               
                                   *   1 = free grouper storage                 
                                   */                                           
     short lvndx,                 /* number diagnoses  50 MAX      */           
     short lvnsg,                 /* number procedures 50 MAX      */           
     char  FAR *lvdx_ptr,         /* array of 50 DX x 8 chars each              
                                   * left justified, blank padded               
                                   * rightmost char is POA indicator            
                                   */                                           
     char  FAR *lvsg_ptr,         /* array of 50 SG x 7 chars each              
                                   * left justified, blank padded               
                                   */                                           
     char  FAR *lvsex,            /* sex - 1 char 1,m,M or 2,f,F     */         
     char  FAR *lvdstat,          /* UB82 discharge stat 2 chars     */         
     char  FAR *lvbirth_date,     /* birth date 8 chars MMDDYYYY     */         
     char  FAR *lvadmit_date,     /* admit date 8 chars MMDDYYYY     */         
     char  FAR *lvdisch_date,     /* discharge date 8 chars MMDDYYYY */         
     char  FAR *lvsg_dates,       /* array of 50 procedure dates                
                                   * 8 chars each MMDDYYYY                      
                                   */                                           
     char  *lvbwght,              /* birth weight in grams 0200-7000*/          
     char  *lvbwtopt,             /* birth weight option 1-7        */          
/* birth weight options:                                                        
    1      use the entered weight                                               
                                                                                
    2      ignore entered wt, use wt implicit in ICD-9-CM code                  
                                                                                
    3      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, flag wt as invalid                                  
                                                                                
    4      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag weight as invalid                                
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, flag wt as invalid                   
                                                                                
    5      ignore entered wt, use wt implicit in ICD-9-CM code                  
           if invalid, default to normal wt                                     
                                                                                
    6      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, default to normal wt                                
                                                                                
    7      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag wt as invalid                                    
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, default to normal                    
                                                                                
    notes  1. Normal birth weight range is 200 - 7000 g.                        
           2. If option entry is invalid or missing, it defaults to 7.          
           3. For a crosscheck, a comparison is made between the entered        
              birth weight and the implicit birth weight.                       
           4. If the birth weight is required, the system returns DRG 956.      
           5. The normal weight default assumes birth weight is set             
              to >= 2499 g.                                                     
           6. Logic is only performed if age on admit <= 14 days.               
*/                                                                              
     char  FAR *lvdmv,            /* days on mech. vent. 3 chars 000-999 */     
     char  FAR *lvdmva,           /* days after admission when placed on        
                                     mech. ventilator 3 chars -99-999           
                                     left justified, blank padded               
									 FOR FUTURE USE                      */                       
     char  FAR *lvremap,          /* 1 char 0-2, 0 = no remapping               
                                     1 = historical remapping                   
									 2 = logical/clinical remapping                               
									 other = no remapping                                         
								   */                                                           
     char  FAR *lvdischDRGopt,    /* 1 char
								     0 or space will compute Discharge DRG  
									   using HAC processing.
								     1 will compute Discharge DRG excluding
									   all complication of care
									   codes. No Admit DRG will be returned.
								   */
     char  FAR *lvagency,         /* 2 char - needed by HAC logic        
								     1  Medicare HAC logic
								     2  Medicaid HAC logic
								     10 CA Medicaid HAC logic
								   */
     char  FAR *lvHACvers,        /* 3 char - e.g. 300 */        

                                                                                
                 /* ------  output arguments ----- */                           
     char  FAR *lvers,            /* grouper version 11 chars                   
                                   * HASvv-mm/dd                                
                                   */                                           
     char  FAR *lvrtc,            /* dicharge return code 2 chars 00-12    */   
     char  FAR *lvmdc,            /* discharge MDC 2 chars 00-25           */   
     char  FAR *lvdrg,            /* discharge DRG 3 chars 001-999         */   
     char  FAR *lvsoi,            /* disch. severity of illness 1 char 0-4 */   
     char  FAR *lvrom,            /* disch. risk of mortality   1 char 0-4 */   
     char  FAR *lvmed_surg_ind,   /* discharge DRG Medical/Surgical             
                                   * Indicator 1 char                           
                                   * 0=Discharge RTC is non-zero                
                                   * 1=Medical  Discharge DRG                   
                                   * 2=Surgical Discharge DRG                   
                                   */                                           
     char  FAR *lvrtc_admit,      /* admission return code 2 chars 00-12  */    
     char  FAR *lvmdc_admit,      /* admission MDC 2 chars 00-25          */    
     char  FAR *lvdrg_admit,      /* admission DRG 3 chars 001-999        */    
     char  FAR *lvsoi_admit,      /* admit severity of illness 1 char 0-4 */    
     char  FAR *lvrom_admit,      /* admit risk of mortality   1 char 0-4 */    
     char  FAR *lvmed_surg_ind_admit, /* Admission DRG Medical/Surgical         
                                   * Indicator 1 char                           
                                   * 0=Admission RTC is non-zero                
                                   * 1=Medical  Admission DRG                   
                                   * 2=Surgical Admission DRG                   
                                   */                                           
     char  FAR *lvdx_flags,       /* Diagnosis Flags Table                      
                                   * array of 50 x 10 chars each                
                                   * [n][0] Diagnosis Validity                  
                                   *   0=diagnosis is invalid                   
                                   *   1=diagnosis is valid                     
                                   * [n][1] Diagnosis Affects DRG               
                                   *   0=diag did not affect the DRG            
                                   *   1=diag affected disch DRG only           
                                   *   2=diag affected admit DRG only           
                                   *   3=diag affected both disch               
                                   *     and admit DRG                          
                                   *   4=diag affected HAC DRG only             
                                   *   5=diag aff disch & HAC DRG               
                                   *   6=diag aff admit & HAC DRG               
                                   *   7=diag aff admit, dish &                 
                                   *     HAC DRG                                
                                   * [n][2] Diagnosis Affects SOI               
                                   *   0=diag did not affect the SOI            
                                   *   1=diag affected disch SOI only           
                                   *   2=diag affected admit SOI only           
                                   *   3=diag affected both disch               
                                   *     and admit SOI                          
                                   *   4=diag affected HAC SOI only             
                                   *   5=diag aff disch & HAC SOI               
                                   *   6=diag aff admit & HAC SOI               
                                   *   7=diag aff admit, dish &                 
                                   *     HAC SOI                                
                                   * [n][3] Diagnosis Affects ROM               
                                   *   0=diag did not affect the ROM            
                                   *   1=diag affected disch ROM only           
                                   *   2=diag affected admit ROM only           
                                   *   3=diag affected both disch               
                                   *     and admit ROM                          
                                   *   4=diag affected HAC ROM only             
                                   *   5=diag aff disch & HAC ROM               
                                   *   6=diag aff admit & HAC ROM               
                                   *   7=diag aff admit, dish &                 
                                   *     HAC ROM                                
                                   * [n][4] Diagnosis Discharge SOI Level       
                                   *   C=Excluded Complication of Care          
                                   *   D=Duplicate Secondary DX                 
                                   *   P=Indicates Principal DX                 
                                   *   X=Excluded                               
                                   *   0=Non-groupable claim                    
                                   *   1=Minor                                  
                                   *   2=Moderate                               
                                   *   3=Major                                  
                                   *   4=Extreme                                
                                   *   blank=DX not recognized or excluded HAC  
                                   * [n][5] Diagnosis Discharge ROM Level       
								   *    same values as DX Discharge SOI Level                   
                                   * [n][6] Diagnosis Admission SOI Level       
								   *    same values as DX Discharge SOI Level                   
                                   * [n][7] Diagnosis Admission ROM Level       
								   *    same values as DX Discharge SOI Level                   
                                   * [n][8] Diagnosis HAC SOI Level             
								   *    same values as DX Discharge SOI Level                   
                                   * [n][9] Diagnosis HAC ROM Level             
								   *    same values as DX Discharge SOI Level                   
								   */                                                           
     char  FAR * lvsg_flags       /* Procedure Flags Table                      
                                   * array of 50 x 5 chars each                 
                                   * [n][0] Procedure Validity                  
                                   *   0=procedure is invalid                   
                                   *   1=procedure is valid                     
                                   * [n][1] Procedure Affects DRG               
                                   *   0=proc did not affect the DRG            
                                   *   1=proc affected disch DRG only           
                                   *   2=proc affected admit DRG only           
                                   *   3=proc affected both disch               
                                   *     and admit DRG                          
                                   *   4=proc affected HAC DRG only             
                                   *   5=proc aff disch & HAC DRG               
                                   *   6=proc aff admit & HAC DRG               
                                   *   7=proc aff admit, disch &                
                                   *     HAC DRG                                
                                   * [n][2] Procedure Affects SOI               
                                   *   0=proc did not affect the SOI            
                                   *   1=proc affected disch SOI only           
                                   *   2=proc affected admit SOI only           
                                   *   3=proc affected both disch               
                                   *     and admit SOI                          
                                   *   4=proc affected HAC SOI only             
                                   *   5=proc aff disch & HAC SOI               
                                   *   6=proc aff admit & HAC SOI               
                                   *   7=proc aff admit, disch &                
                                   *     HAC SOI                                
                                   * [n][3] Procedure Affects ROM               
                                   *   0=proc did not affect the ROM            
                                   *   1=proc affected disch ROM only           
                                   *   2=proc affected admit ROM only           
                                   *   3=proc affected both disch               
                                   *     and admit ROM                          
                                   *   4=proc affected HAC ROM only             
                                   *   5=proc aff disch & HAC ROM               
                                   *   6=proc aff admit & HAC ROM               
                                   *   7=proc aff admit, disch &                
                                   *     HAC ROM                                
                                   * [n][4] OR/Non-OR Procedure                 
                                   *   0=not an OR procedure                    
                                   *   1=operating room (OR) procedure          
                                   */                                           
     );                                                                         
                                                                                
                                                                                
IRPEXTERNC short IRPEXTCALL HADS34CS
  (Hadgrp2_Data * hgp);                                                         
                                                                                
#endif
                                                                                
                                                                                
/*                                                                              
 *************************************                                          
 ********* wisconsin groupers ********                                          
 *************************************                                          
*/                                                                              
                                                                                
/*===================================================================*/         
/* Wisconsin MA DRG 33.0 function prototypes                          */        
/*===================================================================*/         
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADW33CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADW33CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADW33CS                                            
#else                                                                           
short IRPEXTCALL HADW33CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp2_Data *hgp);                                                    
                                                                                
/*===================================================================*/         
/* Wisconsin MA DRG 31.0 function prototypes                          */        
/*===================================================================*/         
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADW31CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADW31CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADW31CS                                            
#else                                                                           
short IRPEXTCALL HADW31CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp2_Data *hgp);                                                    
                                                                                
/*===================================================================*/         
/* Wisconsin MA DRG 30.0 function prototypes                          */        
/*===================================================================*/         
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADW30CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADW30CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADW30CS                                            
#else                                                                           
short IRPEXTCALL HADW30CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp2_Data *hgp);                                                    
                                                                                
/*===================================================================*/         
/* Wisconsin MA DRG 28.0 function prototypes                          */        
/*===================================================================*/         
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADW28CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2) || defined(IBMZOS)                    
IRPEXTERNC short IRPEXTCALL HADW28CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADW28CS                                            
#else                                                                           
short IRPEXTCALL HADW28CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp2_Data *hgp);                                                    
                                                                                

/* ***************************************************************** */         
/*                    RTC     (VRTC)   - 1 BYTE RETURN CODE:         */         
/*                            '0' =  O.K.                            */         
/*                            '1' =  INVALID PRINCIPAL DX            */         
/*                                   IF MDC 24, PRINCIPAL DX IS NOT  */         
/*                                      A VALID ICD9-CM-CODE         */         
/*                                   IF MDC 0,  PRINCIPAL DX IS NOT  */         
/*                                      A VALID PRINCIPAL DX ('ENNN')*/         
/*                                      BUT IS VALID ICD9-CM-CODE    */         
/*                            '2' =  RECORD DOES NOT MEET CRITERIA   */         
/*                                   FOR ANY DRG IN MDC AS INDICATED */         
/*                                   BY PRINCIPAL DX                 */         
/*                            '3' =  INVALID AGE (NOT 001-124)       */         
/*                                   ONLY CHECKED IF DRG NEEDS AGE   */         
/*                            '4' =  INVALID SEX (NOT 1 OR 2) ONLY   */         
/*                                   CHECKED IF DRG NEEDS SEX TO GRP */         
/*                            '5' =  INVALID DISCHARGE STATUS        */         
/*                                   ONLY CHECKED IF NEEDED TO GRP.  */         
/*                            '6' =  NO DIAGNOSIS PASSED             */         
/*                                                                   */         
/*                            '7' =  INVALID PRINCIPAL DIAGNOSIS     */         
/*                                                                   */         
/*                            '8' - '9'  UNUSED BY THIS GROUPER      */         
/*                                                                   */         
/*                            'X' =  IRRECOVERABLE GROUPER ERROR     */         
/*                                   GENERALLY - NOT ENOUGH MEMORY   */         
/*                                   TO LOAD TABLES.                 */         
/*                                                                   */         
/*                            'Z' =  LICENSE AGREEMENT EXPIRED       */         
/*                                                                   */         
/*                                                                   */         
/* ***************************************************************** */         
                                                                                
/*==============================================*/                              
/* HAAFnxCS, HAAFnnxCS - APC Grouper Prototypes */                              
/*==============================================*/                              
                                                                                                                    
/* HAAF###CS signature declaration */                                           
#if defined(PCWIN)                                                              
# define HAAF_SIGNATURE   short IRPEXTERNC FAR PASCAL                           
#elif defined(PCOS2DLL) || defined(PCOS2)  ||  defined(IBMZOS)                  
# define HAAF_SIGNATURE   short IRPEXTERNC IRPEXTCALL                           
#elif defined(PCWIN32)                                                          
#  ifdef _cplusplus                                                             
#   define HAAF_SIGNATURE IRPEXTERNC short IRPEXTCALL                           
#  else                                                                         
#   define HAAF_SIGNATURE short IRPEXTERNC IRPEXTCALL                           
#  endif                                                                        
#else                                                                           
# define HAAF_SIGNATURE   short  IRPEXTCALL                                     
#endif                                                                          

/* KEEP ONLY MOST RECENT 4 GROUPERS */
                                                                                
/* Single Structure Entry Point */
HAAF_SIGNATURE HAAF18ACS(Haagrp_Data *hagp);

/* Single Structure Entry Point */
HAAF_SIGNATURE HAAF17BCS(Haagrp_Data *hagp);

/* Single Structure Entry Point */
HAAF_SIGNATURE HAAF17CCS(Haagrp_Data *hagp);

/* Single Structure Entry Point */
HAAF_SIGNATURE HAAF17DCS(Haagrp_Data *hagp);


/*==================================*/                                          
/* Latest IOCE grouper entry points */                                          
/*==================================*/                                          
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export haaf18acw
#elif defined(PCOS2DLL)  ||  defined(IBMZOS)
short IRPEXTENT haaf18ac1
#elif defined(PCWIN32)
short IRPEXTENT haaf18ac1
#else
short IRPEXTENT haaf18ac1
#endif                                                                          
  (                                                                             
/*------------------------------*/                                              
/*      INPUT ARGUMENTS         */                                              
/*------------------------------*/                                              
  char  FAR *lvdx_ptr,             /* array of DXs, 8 chars each            */  
                /* left-justified, blank-filled                             */  
                /* first  DX is first  reason for visit, may be blank       */  
                /* second DX is second reason for visit, may be blank       */  
                /* third  DX is third  reason for visit, may be blank       */  
                /* fourth DX is principal DX, may not be blank              */  
                /* additional DXs are secondary DXs                         */  
  char  FAR *lvndx,                /* number of DXs in lvdx_ptr, 99 max     */  
                /* count is 2 chars (e.g. 16)                               */  
                /* right-justified, zero or blank-filled                    */  
  char  FAR *lineitems,            /* array of line items, 46 chars each    */  
                /*  5 chars HCPCS Code, left-justified, blank-filled        */  
                /* 10 chars HCPCS Modifiers, up to 5 2-char modififiers,    */  
                /*          blank-filled                                    */  
                /*  8 chars Service Date, yyyymmdd                          */  
                /*  4 chars Revenue Code                                    */  
                /*  9 chars Service Units, right-justified, zero-filled     */  
                /* 10 chars Charge, in cents e.g. 0000000101 = $1.01        */  
                /*          right-justified, zero-filled                    */  
  char  FAR *vlineitems,           /* number of line items, 450 max         */  
                /* count is 4 chars (e.g. 0450)                             */  
                /* right-justified, zero or blank-filled                    */  
  char  FAR *laction,              /* array of line item action flags,      */  
                /* 1 char each                                              */  
                /* 0 Line item denial or rejection is not ignored           */  
                /* 1 Line item denial or rejection is ignored               */  
                /* 2 External line item denial                              */  
                /* 3 External line item rejection                           */  
                /* 4 External line item adjustment                          */  
                /* 5 Non-covered service excluded from payment under FQHC   */
                /*   PPS                                                    */
  char  FAR *age,                  /* age in years, 3 chars, 000-124        */  
                /* right-justified, zero or blank-filled                    */  
  char  FAR *sex,                  /* 0 unknown, 1 male, 2 female           */  
  char  FAR *fromtodates,          /* from - to dates, 16 chars             */  
                /* yyyymmddyyyymmdd                                         */  
  char  FAR *ccodes,               /* array of condition codes,2 chars each */  
  short FAR  vccodes,              /* number of condition codes, 11 max     */  
  char  FAR *billtype,             /* 3 byte bill type                      */  
  char  FAR *npinumber,            /* 13 byte national provider ID          */  
  char  FAR *oscar,                /* 6 byte OSCAR Medicare value           */  
  char  FAR *pstatptr,             /* 2 byte patient status                 */  
  char  FAR *oppsptr,              /* 1 OPPS, 2 Non-OPPS                    */  
  char  FAR *occptr,               /* array of occurence codes,2 chars each */  
  char  FAR *noccptr,              /* number of occurrence codes, 10 max    */  
                /* count is 2 chars (e.g. 01)                               */  
                /* right-justified, zero or blank-filled                    */  
  char  FAR *codetype,             /* ICD code type indicator, 1 char       */  
                /* 0 ICD-10 diagnosis codes                                 */  
                /* 9 ICD-10 diagnosis codes                                 */  
                /* otherwise the code type is based on the from date        */  
/*------------------------------*/                                              
/*      OUTPUT ARGUMENTS        */                                              
/*------------------------------*/                                              
  char  FAR *dxeditbuf,            /* array of dx edit return buffers       */  
                /* 24 chars ( 8 edits x 3 digit edit code) for each DX      */  
  char  FAR *sgeditbuf,            /* array of sg edit return buffers       */  
                /* 90 chars (30 edits x 3 digit edit code) per line item    */  
  char  FAR *modeditbuf,           /* array of modifier edit return buffers */  
                /* 60 chars per line item                                   */  
                /* (4 edits x 3 digit edit code x 5 modifiers) per line item*/  
  char  FAR *dteditbuf,            /* array of date edit return buffers     */  
                /* 12 chars ( 4 edits x 3 digit edit code) per line item    */  
  char  FAR *reveditbuf,           /* array of revenue edit return buffers  */  
                /* 15 chars ( 5 edits x 3 digit edit code) per line item    */  
  char  FAR *apceditbuf,           /* apc edit return buffer, 47 chars      */  
                /*  5 chars HCPCS Code from input                           */  
                /*  5 chars Payment APC (used to determine payment)         */  
                /*  5 chars HCPCS APC (APC assigned to HCPCS code)          */  
                /*  2 chars Status Indicator, right-justified, blank-filled */  
                /*           A Services not paid under OPPS                 */  
                /*           B Non-allowed item or service for OPPS         */  
                /*           C Inpatient procedure                          */  
                /*           E Non-allowed item or service                  */  
                /*           F Corneal tissue acquisition; certain CRNA     */  
                /*             services and hepatitis B vaccines            */  
                /*           G Drug/biological pass-through                 */  
                /*           H Pass-through device categories and           */  
                /*             radiopharmaceutical agents                   */  
                /*           J New drug or new biological pass-through      */  
                /*          J1 Outpatient department services paid          */
                /*             through  a comprehensive APC                 */
                /*          J2 Hospital Part B services that may be paid    */
                /*             through a comprehensive APC                  */
                /*           K Non-pass-through drugs and biologicals       */  
                /*           L Flu/PPV vaccines                             */  
                /*           M Service not billable to the FI/MAC           */  
                /*           N Items and Services packaged into APC rates   */  
                /*           P Partial hospitalization service              */  
                /*          Q1 STVX-packaged codes                          */  
                /*          Q2 T-packaged codes                             */  
                /*          Q3 Codes paid through a composite APC           */  
                /*          Q4 Conditionally packaged laboratory services   */ 
                /*           R Blood and blood products                     */  
                /*           S Significant proceudre not subject to         */  
                /*             multiple procedure discounting               */  
                /*           T Significant proceudre subject to             */  
                /*             multiple procedure discounting               */  
                /*           U Brachytherapy sources                        */  
                /*           V Clinic or emergency department visit         */  
                /*           W Invalid HCPCS or invalid revenue code with   */  
                /*             blank HCPCS                                  */  
                /*           X Ancillary service                            */  
                /*           Y Non-implantable DME                          */  
                /*           Z Valid revenue code with blank HCPCS and no   */  
                /*             other SI assigned                            */  
                /*  2 chars Payment Indicator                               */  
                /*           1 Paid standard hospital OPPS amount           */  
                /*             (status indicators J1,J2,K,R,S,T,U,V)        */  
                /*           2 Service not paid under OPPS                  */  
                /*             (status indicator A)                         */  
                /*           3 Not paid                                     */  
                /*             (status indicators E,M,Q,Q1,Q2,Q3,Q4,W,Y)    */  
                /*             or not paid under OPPS                       */  
                /*             (status indicators B, C, Z)                  */  
                /*           4 Paid at reasonable cost                      */  
                /*             (status indicators F, L)                     */  
                /*           5 Paid standard amount for pass-through drug   */  
                /*             or biological                                */  
                /*             (status indicator G)                         */  
                /*           6 Payment based on charge adjusted to cost     */  
                /*             (status indicators H, U)                     */  
                /*           7 Additional payment for new drug or new       */  
                /*             biological                                   */  
                /*           8 Paid partial hospitalization per diem        */  
                /*             (status indicator P)                         */  
                /*           9 No additional payment;                       */  
                /*             Payment included in line items with APCs     */  
                /*             (status indicator N;                         */  
                /*             or no HCPCS code and certaiin revenue codes; */  
                /*             or HCPCS codes G0176, G0129 or G0177)        */  
                /*          10 Paid FQHC encounter payment                  */
                /*          11 Not paid or not included under FQHC          */
                /*             encounter payment                            */
                /*          12 No additional payment, included in payment   */
                /*             for FQHC encounter                           */
                /*          13 Paid FQHC encounter payment for New patient  */
                /*             or IPPE/AWV                                  */
                /*          14 Grandfathered tribal FQHC encounter payment  */
                /*  1 char  Discount Formula Number                         */  
                /*          1 1.0                                           */  
                /*          2 (1.0 + D(U-1))/U                              */  
                /*          3 T/U                                           */  
                /*          4 (1 + D)/U                                     */  
                /*          5 D                                             */  
                /*          6 TD/U                                          */  
                /*          7 D(1 + D)/U                                    */  
                /*          8 2.0                                           */  
                /*          9 2D/U                                          */  
                /*            D = discounting fraction                      */  
                /*            U = number of units                           */  
                /*            T = terminated procedure discount             */  
                /*  1 char  Line Item Denial or Rejection Flag              */  
                /*          0 Line item is not denied or rejected.          */  
                /*          1 Line item is denied or rejected.              */  
                /*          2 Line item is not denied or rejected but       */  
                /*            occurs on a day that has been denied or       */  
                /*            rejected.                                     */  
                /*  1 char  Packaging Flag                                  */  
                /*          0 Not packaged                                  */  
                /*          1 Packaged service                              */  
                /*          2 Packaged as part of partial hospitalization   */  
                /*            per diem or daily mental health service per   */  
                /*            diem                                          */  
                /*          3 Artificial charges for surgical procedures    */  
                /*          4 Packaged as part of drug administrations APC  */  
                /*            payment                                       */  
                /*          5 Packaged as part of FQHC encounter payment    */
                /*          6 Packaged preventive service as part of FQHC   */
                /*            encounter payment not subject to coinsurance  */
                /*            payment                                       */
                /*  2 chars Payment Adjustment Flag                         */  
                /*          right-jusified, blank-filled                    */  
                /*           0 No payment adjustment                        */  
                /*           1 Paid standard amount for pass-through drug   */  
                /*             or biological (status indicator G)           */  
                /*           2 Payment based on charge adjusted to cost     */  
                /*             (status indicators H, U)                     */  
                /*           3 Additional payment for new drug or new       */  
                /*             biological applies to APC                    */  
                /*             (status indicator J)                         */  
                /*           4 Deductible not applicable                    */  
                /*             (specific list of HCPCS codes)               */  
                /*           5 Blood/blood product used in blood deductible */  
                /*             calculation                                  */  
                /*           6 Blood processing/storage not subject to      */  
                /*             blood deductible                             */  
                /*           7 Item provided without cost to provider       */  
                /*           8 Item provided with partial credit to provider*/  
                /*           9 Deductible/co-insurance not applicable       */
                /*          10 Co-insurance not applicable                  */
                /*          11 Multiple service units reduced to one by     */
                /*             IOCE processing; payment based on single     */
                /*             payment rate                                 */
                /*          12 Offset for first  device pass-through        */
                /*          13 Offset for second device pass-through        */
                /*          14 PAMA Section 218 reduction on CT scan        */
                /*          15 Placeholder - Reserved for Future Use        */
                /*          16 Terminated procedure with pass-thru device   */
                /*          17 Condition for device credit present          */
                /*          18 Offset for 1st pass-thru drug or biological  */
                /*          19 Offset for 2nd pass-thru drug or biological  */
                /*          20 Offset for 3rd pass-thru drug or biological  */
                /*  1 char  Payment Method Flag                             */  
                /*          0 OPPS pricer determines payment for service    */  
                /*          1 Based on OPPS, Coverage of Billing rules,     */  
                /*            the service is not paid                       */  
                /*          2 Service is not subject to OPPS                */  
                /*          3 Service is not subject to OPPS and has a line */  
                /*            item denial or rejection                      */  
                /*          4 Line item is denied or rejected by FI/MAC;    */  
                /*            OPPS is not applied to line item              */  
                /*          5 Payment for service determined under FQHC PPS */
                /*  9 chars Service Units, right-justified, zero-filled     */  
                /*          transferred from input                          */  
                /* 10 chars Charge, in cents e.g. 0000000101 = $1.01        */  
                /*          right-justif., zero-filled                      */  
                /*          transferred from input                          */  
                /*  1 char  Line Item Action Flag                           */  
                /*          0 Line item denial or rejection is not ignored  */  
                /*          1 Line item denial or rejection is ignored      */  
                /*          2 External line item denial                     */  
                /*          3 External line item rejection.                 */  
                /*          4 External line item adjustment.                */  
                /*          5 Non-covered service excluded from payment     */
                /*            under FQHC PPS                                */
                /*  2 chars Composite Adjustment Flag                       */  
                /*          right-justified, zero-filled                    */  
                /*          00 No composite group assigned                  */  
                /*          01 First composite group on claim               */  
                /*          02 Second composite group on claim              */  
                /*          ...                                             */  
                /*          nn nth composite group on claim                 */  
                /*          For FQHC PPS claims (bill type 77x) only, the   */
                /*          following values are defined for composite      */
                /*          adjustment flag:                                */
                /*          01 FQHC medical clinic visit                    */
                /*          02 FQHC mental health clinic visit              */
                /*          03 Subsequent FQHC clinic visit, medical or     */
                /*             mental health (modifier 59 reported)         */ 
  char  FAR *clmeditbuf,           /* claim edit return buffer, 271 chars   */  
                /*  1 char  Claim Processed Flag                            */  
                /*          0 Claim processed                               */  
                /*          1 Claim not processed; invalid date;            */  
                /*            inappropriate bill type/condition code        */  
                /*            combination; or invalid bill type             */  
                /*          2 Claim not processed; no line items present    */  
                /*          3 Claim not processed; condition code 21 present*/  
                /*          9 A fatal error has been detected during        */  
                /*            initializaton                                 */  
                /*  3 chars Number of Line Items                            */  
                /*          transferrred from input                         */  
                /* 13 chars National Provider Identifier,                   */  
                /*          transferrred from input, for pricer             */  
                /*  6 chars OSCAR Medicare Provider Number                  */  
                /*          transferrred from input, for pricer             */  
                /*  1 char  Overall Claim Disposition                       */  
                /*          0 No edits present on claim                     */  
                /*          1 The only edits present are for line item      */  
                /*            denial or rejection                           */  
                /*          2 Multiple-day claim with one or more days      */  
                /*            denied or rejected                            */  
                /*          3 Claim is denied, rejected, suspended or       */  
                /*            returned to provider, or single day claim     */  
                /*            with all line items denied or rejected,       */  
                /*            with only post-payment edits                  */  
                /*          4 Claim is denied, rejected, suspended or       */  
                /*            returned to provider, or single day claim     */  
                /*            with all line items denied or rejected,       */  
                /*            with only pre-payment edits                   */  
                /*          5 Claim is denied, rejected, suspended or       */  
                /*            returned to provider, or single day claim     */  
                /*            with all line items denied or rejected,       */  
                /*            with both pre- and post-payment edits         */  
                /*  1 char  Claim Rejection Disposition                     */  
                /*          0 Claim not rejected                            */  
                /*          1 One or more edits are present that cause      */  
                /*            the claim to be rejected                      */  
                /*          2 One or more edits are present that cause      */  
                /*            one or more days of a mulitple-day claim      */  
                /*            to be rejected                                */  
                /*  1 char  Claim Denial Disposition                        */  
                /*          0 Claim not denied                              */  
                /*          1 One or more edits are present that cause      */  
                /*            the claim to be denied                        */  
                /*          2 One or more edits are present that cause      */  
                /*            one or more days of a mulitple-day claim      */  
                /*            to be denied, or single day claim with all    */  
                /*            lines denied                                  */  
                /*  1 char  Claim Returned to Provider Disposition          */  
                /*          0 Claim is not returned to provider             */  
                /*          1 One or more edits are present that cause      */  
                /*            the claim to be returned to provider          */  
                /*  1 char  Claim Suspension Disposition                    */  
                /*          0 Claim is not suspended                        */  
                /*          1 One or more edits are present that cause      */  
                /*            the claim to be suspended                     */  
                /*  1 char  Line Item Rejection Disposition                 */  
                /*          0 No line items are rejected                    */  
                /*          1 One or more edits are present that cause      */  
                /*            one or more line items to be rejected         */  
                /*  1 char  Line Item Denial Disposition                    */  
                /*          0 No line items are denied                      */  
                /*          1 One or more edits are present that cause      */  
                /*            one or more line items to be denied           */  
                /* 12 chars Claim Rejection Reasons                         */  
                /*          Up to 4 three-digit codes specifying the edits  */  
                /*          that caused the claim to be rejected            */  
                /* 24 chars Claim Denial Reasons                            */  
                /*          Up to 8 three-digit codes specifying the edits  */  
                /*          that caused the claim to be denied              */  
                /* 90 chars Claim Returned to Provider Reasons              */  
                /*          Up to 30 three-digit codes specifying the edits */  
                /*          that could cause the claim to be returned to    */  
                /*          the provider                                    */  
                /* 48 chars Claim Suspension Reasons                        */  
                /*          Up to 16 three-digit codes specifying the edits */  
                /*          that caused the claim to be suspended           */  
                /* 36 chars Line Item Rejection Reasons                     */  
                /*          Up to 12 three-digit codes specifying the edits */  
                /*          that caused the line item to be rejected        */  
                /* 18 chars Line Item Deined Reasons                        */  
                /*          Up to 6 three-digit codes specifying the edits  */  
                /*          that caused the line item to be denied          */  
                /*  1 char  APC/ASC Return Buffer Flag                      */  
                /*          0 APC/ASC return buffer filled in with default  */  
                /*            values; no services paid under OPPS           */  
                /*          1 APC/ASC return buffer filled in; one or more  */  
                /*            services paid under OPPS                      */  
                /*  8 chars Version Used                                    */  
                /*          ID of the program version used to process the   */  
                /*          claim in yy.vv.rr format                        */  
                /*  2 chars Patient Status                                  */  
                /*          transferred from input                          */  
                /*  1 char  OPPS Flag                                       */
                /*          transferred from input                          */
                /*  1 char  Non-OPPS Bill Type Flag                         */
                /*          0 N/A                                           */  
                /*          1 Bill type should be 83x                       */  
                /*          2 Bill type should not be 83x                   */  
                /* 110 chars Payer Value Codes (10 code/amount pairs        */
                /*          2 char value code (QN - QW)                     */
                /*          9 char amount nnnnnnn.nn (assumed decimal place)*/
  char  FAR *workbuf,              /* work area - set to NULL               */  
  long  FAR  workbufsize           /* work area size - set to 0             */  
);                                                                              
                                                                                                                                                                

/*===================================================================*/         
/* AP-DRG NY 8.0 function prototypes                                 */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export hadn08cw                                               
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
short IRPEXTENT hadn08c1                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT hadn08c1                                                        
#else                                                                           
short IRPEXTENT hadn08c1                                                        
#endif                                                                          
                                                                                
      (                                                                         
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free this groupers storage               
                               *   2 = free all groupers storage                
                               */                                               
    short  lvndx,             /* number dx (diagnoses)          */              
    short  lvnsg,             /* number sg (procedures)         */              
    char   *lvdx_ptr,         /* to array of 50 DX x 5 bytes ea */              
    char   *lvsg_ptr,         /* to array of 50 SG x 4 bytes ea */              
    char   *lvsex,            /*                                */              
    char   *lvdstat,          /*                                */              
    char   *lvbdate,          /*                                */              
    char   *lvadate,          /*                                */              
    char   *lvddate,          /*                                */              
    char   *lvcind,           /*                                */              
    char   *lvbwght,          /*                                */              
    char   *lvbwtopt,         /*                                */              
    char   *lvdrg,            /*                                */              
    char   *lvmdc,            /*                                */              
    char   *lvrtc,            /*                                */              
    char   *lvmajop1,         /*                                */              
    char   *lvmajop2,         /*                                */              
    char   *lvmajop3,         /*                                */              
    char   *lvminop1,         /*                                */              
    char   *lvminop2,         /*                                */              
    char   *lvdrgdx1,         /*                                */              
    char   *lvdrgdx2,         /*                                */              
    char   *lvdrgdx3,         /*                                */              
    char   *lvdrgcc,          /*                                */              
    char   *lvmajcci,         /*                                */              
    char   *lvers,            /*                                */              
    char   *lvdxcctab         /*                                */              
                                                                                
   );                                                                           
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export HADN08CS                                               
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
short IRPEXTENT HADN08CS                                                        
#elif defined(IBMAS400)                                                         
short IRPEXTENT HADN08CS                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT HADN08CS                                                        
#else                                                                           
short IRPEXTENT HADN08CS                                                        
#endif                                                                          
      (HadgrpDataPtr hgp);                                                      
                                                                                
                                                                                
                                                                                
/*===================================================================*/         
/* AP-DRG NJ 8.1 function prototypes                                 */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export hadn81cw                                               
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
short IRPEXTENT hadn81c1                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT hadn81c1                                                        
#else                                                                           
short IRPEXTENT hadn81c1                                                        
#endif                                                                          
                                                                                
      (                                                                         
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free this groupers storage               
                               *   2 = free all groupers storage                
                               */                                               
    short  lvndx,             /* number dx (diagnoses)          */              
    short  lvnsg,             /* number sg (procedures)         */              
    char   *lvdx_ptr,         /* to array of 50 DX x 5 bytes ea */              
    char   *lvsg_ptr,         /* to array of 50 SG x 4 bytes ea */              
    char   *lvsex,            /*                                */              
    char   *lvdstat,          /*                                */              
    char   *lvbdate,          /*                                */              
    char   *lvadate,          /*                                */              
    char   *lvddate,          /*                                */              
    char   *lvcind,           /*                                */              
    char   *lvbwght,          /*                                */              
    char   *lvbwtopt,         /*                                */              
    char   *lvdrg,            /*                                */              
    char   *lvmdc,            /*                                */              
    char   *lvrtc,            /*                                */              
    char   *lvmajop1,         /*                                */              
    char   *lvmajop2,         /*                                */              
    char   *lvmajop3,         /*                                */              
    char   *lvminop1,         /*                                */              
    char   *lvminop2,         /*                                */              
    char   *lvdrgdx1,         /*                                */              
    char   *lvdrgdx2,         /*                                */              
    char   *lvdrgdx3,         /*                                */              
    char   *lvdrgcc,          /*                                */              
    char   *lvmajcci,         /*                                */              
    char   *lvers,            /*                                */              
    char   *lvdxcctab         /*                                */              
                                                                                
   );                                                                           
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export HADN81CS                                               
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
short IRPEXTENT HADN81CS                                                        
#elif defined(IBMAS400)                                                         
short IRPEXTENT HADN81CS                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT HADN81CS                                                        
#else                                                                           
short IRPEXTENT HADN81CS                                                        
#endif                                                                          
      (HadgrpDataPtr hgp);                                                      
                                                                                
                                                                                
                                                                                
/*===================================================================*/         
/* AP-DRG NY 9.0 function prototypes                                 */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export hadn09cw                                               
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
short IRPEXTENT hadn09c1                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT hadn09c1                                                        
#else                                                                           
short IRPEXTENT hadn09c1                                                        
#endif                                                                          
                                                                                
      (                                                                         
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free this groupers storage               
                               *   2 = free all groupers storage                
                               */                                               
    short  lvndx,             /* number dx (diagnoses)          */              
    short  lvnsg,             /* number sg (procedures)         */              
    char   *lvdx_ptr,         /* to array of 50 DX x 5 bytes ea */              
    char   *lvsg_ptr,         /* to array of 50 SG x 4 bytes ea */              
    char   *lvsex,            /*                                */              
    char   *lvdstat,          /*                                */              
    char   *lvbdate,          /*                                */              
    char   *lvadate,          /*                                */              
    char   *lvddate,          /*                                */              
    char   *lvcind,           /*                                */              
    char   *lvbwght,          /*                                */              
    char   *lvbwtopt,         /*                                */              
    char   *lvdrg,            /*                                */              
    char   *lvmdc,            /*                                */              
    char   *lvrtc,            /*                                */              
    char   *lvmajop1,         /*                                */              
    char   *lvmajop2,         /*                                */              
    char   *lvmajop3,         /*                                */              
    char   *lvminop1,         /*                                */              
    char   *lvminop2,         /*                                */              
    char   *lvdrgdx1,         /*                                */              
    char   *lvdrgdx2,         /*                                */              
    char   *lvdrgdx3,         /*                                */              
    char   *lvdrgcc,          /*                                */              
    char   *lvmajcci,         /*                                */              
    char   *lvers,            /*                                */              
    char   *lvdxcctab         /*                                */              
                                                                                
   );                                                                           
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export HADN09CS                                               
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
short IRPEXTENT HADN09CS                                                        
#elif defined(IBMAS400)                                                         
short IRPEXTENT HADN09CS                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT HADN09CS                                                        
#else                                                                           
short IRPEXTENT HADN09CS                                                        
#endif                                                                          
      (HadgrpDataPtr hgp);                                                      
                                                                                
                                                                                
/*===================================================================*/         
/* AP-DRG NY 10.0 function prototypes                                */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export hadn10cw                                               
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
short IRPEXTENT hadn10c1                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT hadn10c1                                                        
#else                                                                           
short IRPEXTENT hadn10c1                                                        
#endif                                                                          
                                                                                
      (                                                                         
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free this groupers storage               
                               *   2 = free all groupers storage                
                               */                                               
    short  lvndx,             /* number dx (diagnoses)          */              
    short  lvnsg,             /* number sg (procedures)         */              
    char   *lvdx_ptr,         /* to array of 50 DX x 5 bytes ea */              
    char   *lvsg_ptr,         /* to array of 50 SG x 4 bytes ea */              
    char   *lvsex,            /*                                */              
    char   *lvdstat,          /*                                */              
    char   *lvbdate,          /*                                */              
    char   *lvadate,          /*                                */              
    char   *lvddate,          /*                                */              
    char   *lvcind,           /*                                */              
    char   *lvbwght,          /*                                */              
    char   *lvbwtopt,         /*                                */              
    char   *lvdrg,            /*                                */              
    char   *lvmdc,            /*                                */              
    char   *lvrtc,            /*                                */              
    char   *lvmajop1,         /*                                */              
    char   *lvmajop2,         /*                                */              
    char   *lvmajop3,         /*                                */              
    char   *lvminop1,         /*                                */              
    char   *lvminop2,         /*                                */              
    char   *lvdrgdx1,         /*                                */              
    char   *lvdrgdx2,         /*                                */              
    char   *lvdrgdx3,         /*                                */              
    char   *lvdrgcc,          /*                                */              
    char   *lvmajcci,         /*                                */              
    char   *lvtraum,          /*                                */              
    char   *lvers,            /*                                */              
    char   *lvdxcctab         /*                                */              
                                                                                
   );                                                                           
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export HADN10CS                                               
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
short IRPEXTENT HADN10CS                                                        
#elif defined(IBMAS400)                                                         
short IRPEXTENT HADN10CS                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT HADN10CS                                                        
#else                                                                           
short IRPEXTENT HADN10CS                                                        
#endif                                                                          
      (HadgrpDataPtr hgp);                                                      
                                                                                
                                                                                
/*===================================================================*/         
/* AP-DRG NY 11.0 function prototypes                                */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export hadn11cw                                               
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
short IRPEXTENT hadn11c1                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT hadn11c1                                                        
#else                                                                           
short IRPEXTENT hadn11c1                                                        
#endif                                                                          
                                                                                
      (                                                                         
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free this groupers storage               
                               *   2 = free all groupers storage                
                               */                                               
    char   *lvtsw,                                                              
    short  lvndx,             /* number dx (diagnoses)          */              
    short  lvnsg,             /* number sg (procedures)         */              
    char   *lvdx_ptr,         /* to array of 50 DX x 5 bytes ea */              
    char   *lvsg_ptr,         /* to array of 50 SG x 4 bytes ea */              
    char   *lvage,            /*                                */              
    char   *lvsex,            /*                                */              
    char   *lvdstat,          /*                                */              
    char   *lvbdate,          /*                                */              
    char   *lvadate,          /*                                */              
    char   *lvddate,          /*                                */              
    char   *lvcind,           /*                                */              
    char   *lvbwght,          /*                                */              
    char   *lvbwtopt,         /*                                */              
    char   *lvdrg,            /*                                */              
    char   *lvmdc,            /*                                */              
    char   *lvrtc,            /*                                */              
    char   *lvmajop1,         /*                                */              
    char   *lvmajop2,         /*                                */              
    char   *lvmajop3,         /*                                */              
    char   *lvminop1,         /*                                */              
    char   *lvminop2,         /*                                */              
    char   *lvdrgdx1,         /*                                */              
    char   *lvdrgdx2,         /*                                */              
    char   *lvdrgdx3,         /*                                */              
    char   *lvdrgcc,          /*                                */              
    char   *lvmajcci,         /*                                */              
    char   *lvtraum,          /*                                */              
    char   *lvers,            /*                                */              
    char   *lvdxcctab         /*                                */              
                                                                                
   );                                                                           
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export HADN11CS                                               
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
short IRPEXTENT HADN11CS                                                        
#elif defined(IBMAS400)                                                         
short IRPEXTENT HADN11CS                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT HADN11CS                                                        
#else                                                                           
short IRPEXTENT HADN11CS                                                        
#endif                                                                          
      (HadgrpDataPtr hgp);                                                      
                                                                                
                                                                                
/*===================================================================*/         
/* AP-DRG NY 12.0 function prototypes                                */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export hadn12cw                                               
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
short IRPEXTENT hadn12c1                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT hadn12c1                                                        
#else                                                                           
short IRPEXTENT hadn12c1                                                        
#endif                                                                          
                                                                                
      (                                                                         
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free this groupers storage               
                               *   2 = free all groupers storage                
                               */                                               
    char   *lvtsw,                                                              
    short  lvndx,             /* number dx (diagnoses)          */              
    short  lvnsg,             /* number sg (procedures)         */              
    char   *lvdx_ptr,         /* to array of 50 DX x 5 bytes ea */              
    char   *lvsg_ptr,         /* to array of 50 SG x 4 bytes ea */              
    char   *lvage,            /*                                */              
    char   *lvsex,            /*                                */              
    char   *lvdstat,          /*                                */              
    char   *lvbdate,          /*                                */              
    char   *lvadate,          /*                                */              
    char   *lvddate,          /*                                */              
    char   *lvcind,           /*                                */              
    char   *lvbwght,          /*                                */              
    char   *lvbwtopt,         /*                                */              
    char   *lvdrg,            /*                                */              
    char   *lvmdc,            /*                                */              
    char   *lvrtc,            /*                                */              
    char   *lvmajop1,         /*                                */              
    char   *lvmajop2,         /*                                */              
    char   *lvmajop3,         /*                                */              
    char   *lvminop1,         /*                                */              
    char   *lvminop2,         /*                                */              
    char   *lvdrgdx1,         /*                                */              
    char   *lvdrgdx2,         /*                                */              
    char   *lvdrgdx3,         /*                                */              
    char   *lvdrgcc,          /*                                */              
    char   *lvmajcci,         /*                                */              
    char   *lvtraum,          /*                                */              
    char   *lvers,            /*                                */              
    char   *lvdxcctab         /*                                */              
                                                                                
   );                                                                           
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export HADN12CS                                               
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
short IRPEXTENT HADN12CS                                                        
#elif defined(IBMAS400)                                                         
short IRPEXTENT HADN12CS                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT HADN12CS                                                        
#else                                                                           
short IRPEXTENT HADN12CS                                                        
#endif                                                                          
      (HadgrpDataPtr hgp);                                                      
                                                                                
                                                                                
/*===================================================================*/         
/* AP-DRG NY 14.0 function prototypes                                */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export hadn14cw                                               
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
short IRPEXTENT hadn14c1                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT hadn14c1                                                        
#else                                                                           
short IRPEXTENT hadn14c1                                                        
#endif                                                                          
                                                                                
      (                                                                         
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free this groupers storage               
                               *   2 = free all groupers storage                
                               */                                               
    char   *lvtsw,                                                              
    short  lvndx,             /* number dx (diagnoses)          */              
    short  lvnsg,             /* number sg (procedures)         */              
    char   *lvdx_ptr,         /* to array of 50 DX x 5 bytes ea */              
    char   *lvsg_ptr,         /* to array of 50 SG x 4 bytes ea */              
    char   *lvage,            /*                                */              
    char   *lvsex,            /*                                */              
    char   *lvdstat,          /*                                */              
    char   *lvbdate,          /*                                */              
    char   *lvadate,          /*                                */              
    char   *lvddate,          /*                                */              
/*    char   *lvcind, 14.0 */ /*                                */              
    char   *lvbwght,          /*                                */              
    char   *lvbwtopt,         /*                                */              
    char   *lvdrg,            /*                                */              
    char   *lvmdc,            /*                                */              
    char   *lvrtc,            /*                                */              
    char   *lvmajop1,         /*                                */              
    char   *lvmajop2,         /*                                */              
    char   *lvmajop3,         /*                                */              
    char   *lvminop1,         /*                                */              
    char   *lvminop2,         /*                                */              
    char   *lvdrgdx1,         /*                                */              
    char   *lvdrgdx2,         /*                                */              
    char   *lvdrgdx3,         /*                                */              
    char   *lvdrgcc,          /*                                */              
    char   *lvmajcci,         /*                                */              
    char   *lvtraum,          /*                                */              
    char   *lvers,            /*                                */              
    char   *lvdxcctab         /*                                */              
                                                                                
   );                                                                           
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export HADN14CS                                               
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
short IRPEXTENT HADN14CS                                                        
#elif defined(IBMAS400)                                                         
short IRPEXTENT HADN14CS                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT HADN14CS                                                        
#else                                                                           
short IRPEXTENT HADN14CS                                                        
#endif                                                                          
      (HadgrpDataPtr hgp);                                                      
                                                                                
                                                                                
/*===================================================================*/         
/* AP-DRG NY 14.1 function prototypes                                */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export hadn41cw                                               
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
short IRPEXTENT hadn41c1                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT hadn41c1                                                        
#else                                                                           
short IRPEXTENT hadn41c1                                                        
#endif                                                                          
                                                                                
      (                                                                         
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free this groupers storage               
                               *   2 = free all groupers storage                
                               */                                               
    char   *lvtsw,                                                              
    short  lvndx,             /* number dx (diagnoses)          */              
    short  lvnsg,             /* number sg (procedures)         */              
    char   *lvdx_ptr,         /* to array of 50 DX x 5 bytes ea */              
    char   *lvsg_ptr,         /* to array of 50 SG x 4 bytes ea */              
    char   *lvage,            /*                                */              
    char   *lvsex,            /*                                */              
    char   *lvdstat,          /*                                */              
    char   *lvbdate,          /*                                */              
    char   *lvadate,          /*                                */              
    char   *lvddate,          /*                                */              
/*    char   *lvcind, 14.0 */ /*                                */              
    char   *lvbwght,          /*                                */              
    char   *lvbwtopt,         /*                                */              
    char   *lvdrg,            /*                                */              
    char   *lvmdc,            /*                                */              
    char   *lvrtc,            /*                                */              
    char   *lvmajop1,         /*                                */              
    char   *lvmajop2,         /*                                */              
    char   *lvmajop3,         /*                                */              
    char   *lvminop1,         /*                                */              
    char   *lvminop2,         /*                                */              
    char   *lvdrgdx1,         /*                                */              
    char   *lvdrgdx2,         /*                                */              
    char   *lvdrgdx3,         /*                                */              
    char   *lvdrgcc,          /*                                */              
    char   *lvmajcci,         /*                                */              
    char   *lvtraum,          /*                                */              
    char   *lvers,            /*                                */              
    char   *lvdxcctab         /*                                */              
                                                                                
   );                                                                           
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export HADN41CS                                               
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
short IRPEXTENT HADN41CS                                                        
#elif defined(IBMAS400)                                                         
short IRPEXTENT HADN41CS                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT HADN41CS                                                        
#else                                                                           
short IRPEXTENT HADN41CS                                                        
#endif                                                                          
      (HadgrpDataPtr hgp);                                                      
                                                                                
/*===================================================================*/         
/* AP-DRG NY 18.0 function prototypes                                */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export hadn18cw                                               
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
short IRPEXTENT hadn18c1                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT hadn18c1                                                        
#else                                                                           
short IRPEXTENT hadn18c1                                                        
#endif                                                                          
                                                                                
      (                                                                         
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free this groupers storage               
                               *   2 = free all groupers storage                
                               */                                               
    char   *lvtsw,                                                              
    short  lvndx,             /* number dx (diagnoses)          */              
    short  lvnsg,             /* number sg (procedures)         */              
    char   *lvdx_ptr,         /* to array of 50 DX x 5 bytes ea */              
    char   *lvsg_ptr,         /* to array of 50 SG x 4 bytes ea */              
    char   *lvage,            /*                                */              
    char   *lvsex,            /*                                */              
    char   *lvdstat,          /*                                */              
    char   *lvbdate,          /*                                */              
    char   *lvadate,          /*                                */              
    char   *lvddate,          /*                                */              
/*    char   *lvcind, 18.0 */ /*                                */              
    char   *lvbwght,          /*                                */              
    char   *lvbwtopt,         /*                                */              
    char   *lvdrg,            /*                                */              
    char   *lvmdc,            /*                                */              
    char   *lvrtc,            /*                                */              
    char   *lvmajop1,         /*                                */              
    char   *lvmajop2,         /*                                */              
    char   *lvmajop3,         /*                                */              
    char   *lvminop1,         /*                                */              
    char   *lvminop2,         /*                                */              
    char   *lvdrgdx1,         /*                                */              
    char   *lvdrgdx2,         /*                                */              
    char   *lvdrgdx3,         /*                                */              
    char   *lvdrgcc,          /*                                */              
    char   *lvmajcci,         /*                                */              
    char   *lvtraum,          /*                                */              
    char   *lvmalrg,          /* added for 18.0                 */              
    char   *lvers,            /*                                */              
    char   *lvdxcctab         /*                                */              
                                                                                
   );                                                                           
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export HADN18CS                                               
#elif defined(PCOS2DLL) || defined(IBMZOS)                                      
short IRPEXTENT HADN18CS                                                        
#elif defined(IBMAS400)                                                         
short IRPEXTENT HADN18CS                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT HADN18CS                                                        
#else                                                                           
short IRPEXTENT HADN18CS                                                        
#endif                                                                          
      (HadgrpDataPtr hgp);                                                      
                                                                                
/*===================================================================*/         
/* AP-DRG NY 21.0 function prototypes                                */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export hadn21cw                                               
#elif defined(PCOS2DLL)  || defined(IBMZOS)                                     
short IRPEXTENT hadn21c1                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT hadn21c1                                                        
#else                                                                           
short IRPEXTENT hadn21c1                                                        
#endif                                                                          
                                                                                
      (                                                                         
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free this groupers storage               
                               *   2 = free all groupers storage                
                               */                                               
    char   *lvtsw,                                                              
    short  lvndx,             /* number dx (diagnoses)          */              
    short  lvnsg,             /* number sg (procedures)         */              
    char   *lvdx_ptr,         /* to array of 50 DX x 5 bytes ea */              
    char   *lvsg_ptr,         /* to array of 50 SG x 4 bytes ea */              
    char   *lvage,            /*                                */              
    char   *lvsex,            /*                                */              
    char   *lvdstat,          /*                                */              
    char   *lvbdate,          /*                                */              
    char   *lvadate,          /*                                */              
    char   *lvddate,          /*                                */              
/*    char   *lvcind, 18.0 */ /*                                */              
    char   *lvbwght,          /*                                */              
    char   *lvbwtopt,         /*                                */              
    char   *lvdrg,            /*                                */              
    char   *lvmdc,            /*                                */              
    char   *lvrtc,            /*                                */              
    char   *lvmajop1,         /*                                */              
    char   *lvmajop2,         /*                                */              
    char   *lvmajop3,         /*                                */              
    char   *lvminop1,         /*                                */              
    char   *lvminop2,         /*                                */              
    char   *lvdrgdx1,         /*                                */              
    char   *lvdrgdx2,         /*                                */              
    char   *lvdrgdx3,         /*                                */              
    char   *lvdrgcc,          /*                                */              
    char   *lvmajcci,         /*                                */              
    char   *lvtraum,          /*                                */              
    char   *lvmalrg,          /* added for 18.0                 */              
    char   *lvers,            /*                                */              
    char   *lvdxcctab         /*                                */              
                                                                                
   );                                                                           
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export HADN21CS                                               
#elif defined(PCOS2DLL)  || defined(IBMZOS)                                     
short IRPEXTENT HADN21CS                                                        
#elif defined(IBMAS400)                                                         
short IRPEXTENT HADN21CS                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT HADN21CS                                                        
#else                                                                           
short IRPEXTENT HADN21CS                                                        
#endif                                                                          
      (HadgrpDataPtr hgp);                                                      
                                                                                
/*===================================================================*/         
/* AP-DRG NY 23.0 function prototypes                                */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export hadn23cw                                               
#elif defined(PCOS2DLL)  || defined(IBMZOS)                                     
short IRPEXTENT hadn23c1                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT hadn23c1                                                        
#else                                                                           
short IRPEXTENT hadn23c1                                                        
#endif                                                                          
                                                                                
      (                                                                         
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free this groupers storage               
                               *   2 = free all groupers storage                
                               */                                               
    char   *lvtsw,                                                              
    short  lvndx,             /* number dx (diagnoses)          */              
    short  lvnsg,             /* number sg (procedures)         */              
    char   *lvdx_ptr,         /* to array of 50 DX x 5 bytes ea */              
    char   *lvsg_ptr,         /* to array of 50 SG x 4 bytes ea */              
    char   *lvage,            /*                                */              
    char   *lvsex,            /*                                */              
    char   *lvdstat,          /*                                */              
    char   *lvbdate,          /*                                */              
    char   *lvadate,          /*                                */              
    char   *lvddate,          /*                                */              
/*    char   *lvcind, 18.0 */ /*                                */              
    char   *lvbwght,          /*                                */              
    char   *lvbwtopt,         /*                                */              
    char   *lvdrg,            /*                                */              
    char   *lvmdc,            /*                                */              
    char   *lvrtc,            /*                                */              
    char   *lvmajop1,         /*                                */              
    char   *lvmajop2,         /*                                */              
    char   *lvmajop3,         /*                                */              
    char   *lvminop1,         /*                                */              
    char   *lvminop2,         /*                                */              
    char   *lvdrgdx1,         /*                                */              
    char   *lvdrgdx2,         /*                                */              
    char   *lvdrgdx3,         /*                                */              
    char   *lvdrgcc,          /*                                */              
    char   *lvmajcci,         /*                                */              
    char   *lvtraum,          /*                                */              
    char   *lvmalrg,          /* added for 18.0                 */              
    char   *lvers,            /*                                */              
    char   *lvdxcctab         /*                                */              
                                                                                
   );                                                                           
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export HADN23CS                                               
#elif defined(PCOS2DLL)  || defined(IBMZOS)                                     
short IRPEXTENT HADN23CS                                                        
#elif defined(IBMAS400)                                                         
short IRPEXTENT HADN23CS                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT HADN23CS                                                        
#else                                                                           
short IRPEXTENT HADN23CS                                                        
#endif                                                                          
      (HadgrpDataPtr hgp);                                                      
                                                                                
/*===================================================================*/         
/* AP-DRG NY 24.0 function prototypes                                */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export hadn24cw                                               
#elif defined(PCOS2DLL)  || defined(IBMZOS)                                     
short IRPEXTENT hadn24c1                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT hadn24c1                                                        
#else                                                                           
short IRPEXTENT hadn24c1                                                        
#endif                                                                          
                                                                                
      (                                                                         
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free this groupers storage               
                               *   2 = free all groupers storage                
                               */                                               
    char   *lvtsw,                                                              
    short  lvndx,             /* number dx (diagnoses)          */              
    short  lvnsg,             /* number sg (procedures)         */              
    char   *lvdx_ptr,         /* to array of 50 DX x 5 bytes ea */              
    char   *lvsg_ptr,         /* to array of 50 SG x 4 bytes ea */              
    char   *lvage,            /*                                */              
    char   *lvsex,            /*                                */              
    char   *lvdstat,          /*                                */              
    char   *lvbdate,          /*                                */              
    char   *lvadate,          /*                                */              
    char   *lvddate,          /*                                */              
/*    char   *lvcind, 18.0 */ /*                                */              
    char   *lvbwght,          /*                                */              
    char   *lvbwtopt,         /*                                */              
    char   *lvdrg,            /*                                */              
    char   *lvmdc,            /*                                */              
    char   *lvrtc,            /*                                */              
    char   *lvmajop1,         /*                                */              
    char   *lvmajop2,         /*                                */              
    char   *lvmajop3,         /*                                */              
    char   *lvminop1,         /*                                */              
    char   *lvminop2,         /*                                */              
    char   *lvdrgdx1,         /*                                */              
    char   *lvdrgdx2,         /*                                */              
    char   *lvdrgdx3,         /*                                */              
    char   *lvdrgcc,          /*                                */              
    char   *lvmajcci,         /*                                */              
    char   *lvtraum,          /*                                */              
    char   *lvmalrg,          /* added for 18.0                 */              
    char   *lvers,            /*                                */              
    char   *lvdxcctab         /*                                */              
                                                                                
   );                                                                           
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export HADN24CS                                               
#elif defined(PCOS2DLL)  || defined(IBMZOS)                                     
short IRPEXTENT HADN24CS                                                        
#elif defined(IBMAS400)                                                         
short IRPEXTENT HADN24CS                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT HADN24CS                                                        
#else                                                                           
short IRPEXTENT HADN24CS                                                        
#endif                                                                          
      (HadgrpDataPtr hgp);                                                      
                                                                                
/*===================================================================*/         
/* AP-DRG NY 25.0 function prototypes                                */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export hadn25cw                                               
#elif defined(PCOS2DLL)  || defined(IBMZOS)                                     
short IRPEXTENT hadn25c1                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT hadn25c1                                                        
#else                                                                           
short IRPEXTENT hadn25c1                                                        
#endif                                                                          
                                                                                
      (                                                                         
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free this groupers storage               
                               *   2 = free all groupers storage                
                               */                                               
    char   *lvtsw,                                                              
    short  lvndx,             /* number dx (diagnoses)          */              
    short  lvnsg,             /* number sg (procedures)         */              
    char   *lvdx_ptr,         /* to array of 50 DX x 5 bytes ea */              
    char   *lvsg_ptr,         /* to array of 50 SG x 4 bytes ea */              
    char   *lvage,            /*                                */              
    char   *lvsex,            /*                                */              
    char   *lvdstat,          /*                                */              
    char   *lvbdate,          /*                                */              
    char   *lvadate,          /*                                */              
    char   *lvddate,          /*                                */              
/*    char   *lvcind, 18.0 */ /*                                */              
    char   *lvbwght,          /*                                */              
    char   *lvbwtopt,         /*                                */              
    char   *lvdrg,            /*                                */              
    char   *lvmdc,            /*                                */              
    char   *lvrtc,            /*                                */              
    char   *lvmajop1,         /*                                */              
    char   *lvmajop2,         /*                                */              
    char   *lvmajop3,         /*                                */              
    char   *lvminop1,         /*                                */              
    char   *lvminop2,         /*                                */              
    char   *lvdrgdx1,         /*                                */              
    char   *lvdrgdx2,         /*                                */              
    char   *lvdrgdx3,         /*                                */              
    char   *lvdrgcc,          /*                                */              
    char   *lvmajcci,         /*                                */              
    char   *lvtraum,          /*                                */              
    char   *lvmalrg,          /* added for 18.0                 */              
    char   *lvers,            /*                                */              
    char   *lvdxcctab         /*                                */              
                                                                                
   );                                                                           
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export HADN25CS                                               
#elif defined(PCOS2DLL)  || defined(IBMZOS)                                     
short IRPEXTENT HADN25CS                                                        
#elif defined(IBMAS400)                                                         
short IRPEXTENT HADN25CS                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT HADN25CS                                                        
#else                                                                           
short IRPEXTENT HADN25CS                                                        
#endif                                                                          
      (HadgrpDataPtr hgp);                                                      
                                                                                
/*===================================================================*/         
/* AP-DRG NY 25.1 function prototypes                                */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export hadn52cw                                               
#elif defined(PCOS2DLL)  || defined(IBMZOS)                                     
short IRPEXTENT hadn52c1                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT hadn52c1                                                        
#else                                                                           
short IRPEXTENT hadn52c1                                                        
#endif                                                                          
                                                                                
      (                                                                         
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free this groupers storage               
                               *   2 = free all groupers storage                
                               */                                               
    char   *lvtsw,                                                              
    short  lvndx,             /* number dx (diagnoses)          */              
    short  lvnsg,             /* number sg (procedures)         */              
    char   *lvdx_ptr,         /* to array of 50 DX x 5 bytes ea */              
    char   *lvsg_ptr,         /* to array of 50 SG x 4 bytes ea */              
    char   *lvage,            /*                                */              
    char   *lvsex,            /*                                */              
    char   *lvdstat,          /*                                */              
    char   *lvbdate,          /*                                */              
    char   *lvadate,          /*                                */              
    char   *lvddate,          /*                                */              
/*    char   *lvcind, 18.0 */ /*                                */              
    char   *lvbwght,          /*                                */              
    char   *lvbwtopt,         /*                                */              
    char   *lvdrg,            /*                                */              
    char   *lvmdc,            /*                                */              
    char   *lvrtc,            /*                                */              
    char   *lvmajop1,         /*                                */              
    char   *lvmajop2,         /*                                */              
    char   *lvmajop3,         /*                                */              
    char   *lvminop1,         /*                                */              
    char   *lvminop2,         /*                                */              
    char   *lvdrgdx1,         /*                                */              
    char   *lvdrgdx2,         /*                                */              
    char   *lvdrgdx3,         /*                                */              
    char   *lvdrgcc,          /*                                */              
    char   *lvmajcci,         /*                                */              
    char   *lvtraum,          /*                                */              
    char   *lvmalrg,          /* added for 18.0                 */              
    char   *lvers,            /*                                */              
    char   *lvdxcctab         /*                                */              
                                                                                
   );                                                                           
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export HADN52CS                                               
#elif defined(PCOS2DLL)  || defined(IBMZOS)                                     
short IRPEXTENT HADN52CS                                                        
#elif defined(IBMAS400)                                                         
short IRPEXTENT HADN52CS                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT HADN52CS                                                        
#else                                                                           
short IRPEXTENT HADN52CS                                                        
#endif                                                                          
      (HadgrpDataPtr hgp);                                                      
                                                                                
/*===================================================================*/         
/* AP-DRG NY 26 function prototypes                                  */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export hadn26cw                                               
#elif defined(PCOS2DLL)  || defined(IBMZOS)                                     
short IRPEXTENT hadn26c1                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT hadn26c1                                                        
#else                                                                           
short IRPEXTENT hadn26c1                                                        
#endif                                                                          
      (                                                                         
                 /* -------- input arguments ----- */                           
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free grouper storage                     
                               */                                               
    char   *lvtsw,            /* trauma switch 1 char set to '1'*/              
    short  lvndx,             /* number diagnoses  50 MAX       */              
    short  lvnsg,             /* number procedures 50 MAX       */              
    char   *lvdx_ptr,         /* array of 50 DX x 6 chars each                  
                               * left justified, blank padded                   
                               */                                               
    char   *lvsg_ptr,         /* array of 50 SG x 7 chars each                  
                               * left justified, blank padded                   
                               */                                               
    char   *lvage,            /* age - 3 chars 000-124          */              
    char   *lvsex,            /* sex - 1 char 1,m,M or 2,f,F    */              
    char   *lvdstat,          /* UB92 discharge stat 2 chars    */              
    char   *lvbdate,          /* birth date 10 chars MM/DD/YYYY */              
    char   *lvadate,          /* admit date 10 chars MM/DD/YYYY */              
    char   *lvddate,          /* disch date 10 chars MM/DD/YYYY */              
    char   *lvbwght,          /* birth weight in grams 0100-9000*/              
    char   *lvbwtopt,         /* birth weight option 1-7        */              
/* birth weight options:                                                        
    1      use the entered weight                                               
                                                                                
    2      ignore entered wt, use wt implicit in ICD-9-CM code                  
           if invalid, flag wt as invalid                                       
                                                                                
    3      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, flag wt as invalid                                  
                                                                                
    4      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag weight as invalid                                
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, flag wt as invalid                   
                                                                                
    5      ignore entered wt, use wt implicit in ICD-9-CM code                  
           if invalid, default to normal wt                                     
                                                                                
    6      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, default to normal wt                                
                                                                                
    7      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag wt as invalid                                    
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, default to normal                    
                                                                                
    notes  1. Normal birth weight range is 100 - 9000 g.                        
           2. If option entry is invalid or missing, it defaults to 1.          
           3. For a crosscheck, a comparison is made between the entered        
              birth weight and the implicit birth weight.                       
           4. If the birth weight is required, the system returns DRG 470.      
           5. The normal weight default assumes birth weight is set             
              to >= 2499 g.                                                     
*/                                                                              
                                                                                
                 /* ------  output arguments ----- */                           
    char   *lvdrg,            /* assigned DRG 3 chars 001-901   */              
    char   *lvmdc,            /* assigned MDC 2 chars 00-25     */              
    char   *lvrtc,            /* return code 1 char 0-8         */              
    char   *lvmajop1,         /* 1st significant OR SG  7 chars */              
    char   *lvmajop2,         /* 2nd significant OR SG  7 char  */              
    char   *lvmajop3,         /* 3rd significant OR SG  7 chars */              
    char   *lvminop1,         /* 1st signif. Non-OR SG  7 chars */              
    char   *lvminop2,         /* 2nd signif. Non-OR SG  7 chars */              
    char   *lvdrgdx1,         /* 1st significant DX 6 chars     */              
    char   *lvdrgdx2,         /* 2nd significant DX 6 chars     */              
    char   *lvdrgdx3,         /* 3rd significant DX 6 chars     */              
    char   *lvdrgcc,          /* CC DX 6 chars                  */              
    char   *lvmajcci,         /* major CC indicator                             
                               *   0 = lvdrgcc is a CC                          
                               *   1 = lvdrgcc is a MCC1                        
                               *   2 = lvdrgcc, paired with                     
                               *       lvminop1, is a MCC2                      
                               *   3 = lvdrgcc is a MCC3                        
                               *   4 = lvdrgcc, paired with                     
                               *       lvminop1, is a MCC4                      
                               */                                               
    char   *lvtraum,          /* trauma registry indicator                      
                               *   0 = record not to be sent to                 
                               *       trauma registry                          
                               *   1 = record to be sent to                     
                               *       trauma registry                          
                               *   2 = record contains an                       
                               *       invalid age, trauma                      
                               *       cannot be calculated                     
                               */                                               
    char   *lvmalrg,          /* congenital malformation                        
                               * registry indicator                             
                               *   0 = record not to be sent to                 
                               *       CM registry                              
                               *   1 = codes on record require                  
                               *       a malformation narrative                 
                               *   2 = codes on record don't req.               
                               *       a malformation narrative                 
                               *   3 = some codes on record req.                
                               *       a malformation narrative                 
                               *   4 = record contains an                       
                               *       invalid age, CM cannot be                
                               *       determined                               
                               */                                               
    char   *lvers,            /* grouper version 11 chars                       
                               * HADNvvmm/yy                                    
                               */                                               
    char   *lvdxcctab         /* array of 50 chars                              
                               * one for each input DX                          
                               * Y = DX is a CC                                 
                               * blank = Principal DX or                        
                               *         Invalid DX                             
                               */                                               
   );                                                                           
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export HADN26CS                                               
#elif defined(PCOS2DLL)  || defined(IBMZOS)                                     
short IRPEXTENT HADN26CS                                                        
#elif defined(IBMAS400)                                                         
short IRPEXTENT HADN26CS                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT HADN26CS                                                        
#else                                                                           
short IRPEXTENT HADN26CS                                                        
#endif                                                                          
      (HadgrpDataPtr hgp);                                                      
                                                                                
                                                                                
/*===================================================================*/         
/* AP-DRG NY 27 function prototypes                                  */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export hadn27cw                                               
#elif defined(PCOS2DLL)  || defined(IBMZOS)                                     
short IRPEXTENT hadn27c1                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT hadn27c1                                                        
#else                                                                           
short IRPEXTENT hadn27c1                                                        
#endif                                                                          
      (                                                                         
                 /* -------- input arguments ----- */                           
    short grpfunc,            /* grouper function:                              
                               *   0 = group,                                   
                               *   1 = free grouper storage                     
                               */                                               
    char   *lvtsw,            /* trauma switch 1 char set to '1'*/              
    short  lvndx,             /* number diagnoses  50 MAX       */              
    short  lvnsg,             /* number procedures 50 MAX       */              
    char   *lvdx_ptr,         /* array of 50 DX x 6 chars each                  
                               * left justified, blank padded                   
                               */                                               
    char   *lvsg_ptr,         /* array of 50 SG x 7 chars each                  
                               * left justified, blank padded                   
                               */                                               
    char   *lvage,            /* age - 3 chars 000-124          */              
    char   *lvsex,            /* sex - 1 char 1,m,M or 2,f,F    */              
    char   *lvdstat,          /* UB92 discharge stat 2 chars    */              
    char   *lvbdate,          /* birth date 10 chars MM/DD/YYYY */              
    char   *lvadate,          /* admit date 10 chars MM/DD/YYYY */              
    char   *lvddate,          /* disch date 10 chars MM/DD/YYYY */              
    char   *lvbwght,          /* birth weight in grams 0100-9000*/              
    char   *lvbwtopt,         /* birth weight option 1-7        */              
/* birth weight options:                                                        
    1      use the entered weight                                               
                                                                                
    2      ignore entered wt, use wt implicit in ICD-9-CM code                  
           if invalid, flag wt as invalid                                       
                                                                                
    3      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, flag wt as invalid                                  
                                                                                
    4      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag weight as invalid                                
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, flag wt as invalid                   
                                                                                
    5      ignore entered wt, use wt implicit in ICD-9-CM code                  
           if invalid, default to normal wt                                     
                                                                                
    6      Either the entered wt or implicit may be used                        
           if entered wt present and valid use it                               
             else use implicit wt if valid                                      
           if both invalid, default to normal wt                                
                                                                                
    7      Either the entered wt or implicit may be used and cross checked      
           if both present and valid                                            
             if conflict, flag wt as invalid                                    
           else use entered wt                                                  
           if one present and valid, use it                                     
           if both invalid or not present, default to normal                    
                                                                                
    notes  1. Normal birth weight range is 100 - 9000 g.                        
           2. If option entry is invalid or missing, it defaults to 1.          
           3. For a crosscheck, a comparison is made between the entered        
              birth weight and the implicit birth weight.                       
           4. If the birth weight is required, the system returns DRG 470.      
           5. The normal weight default assumes birth weight is set             
              to >= 2499 g.                                                     
*/                                                                              
                                                                                
                 /* ------  output arguments ----- */                           
    char   *lvdrg,            /* assigned DRG 3 chars 001-901   */              
    char   *lvmdc,            /* assigned MDC 2 chars 00-25     */              
    char   *lvrtc,            /* return code 1 char 0-8         */              
    char   *lvmajop1,         /* 1st significant OR SG  7 chars */              
    char   *lvmajop2,         /* 2nd significant OR SG  7 char  */              
    char   *lvmajop3,         /* 3rd significant OR SG  7 chars */              
    char   *lvminop1,         /* 1st signif. Non-OR SG  7 chars */              
    char   *lvminop2,         /* 2nd signif. Non-OR SG  7 chars */              
    char   *lvdrgdx1,         /* 1st significant DX 6 chars     */              
    char   *lvdrgdx2,         /* 2nd significant DX 6 chars     */              
    char   *lvdrgdx3,         /* 3rd significant DX 6 chars     */              
    char   *lvdrgcc,          /* CC DX 6 chars                  */              
    char   *lvmajcci,         /* major CC indicator                             
                               *   0 = lvdrgcc is a CC                          
                               *   1 = lvdrgcc is a MCC1                        
                               *   2 = lvdrgcc, paired with                     
                               *       lvminop1, is a MCC2                      
                               *   3 = lvdrgcc is a MCC3                        
                               *   4 = lvdrgcc, paired with                     
                               *       lvminop1, is a MCC4                      
                               */                                               
    char   *lvtraum,          /* trauma registry indicator                      
                               *   0 = record not to be sent to                 
                               *       trauma registry                          
                               *   1 = record to be sent to                     
                               *       trauma registry                          
                               *   2 = record contains an                       
                               *       invalid age, trauma                      
                               *       cannot be calculated                     
                               */                                               
    char   *lvmalrg,          /* congenital malformation                        
                               * registry indicator                             
                               *   0 = record not to be sent to                 
                               *       CM registry                              
                               *   1 = codes on record require                  
                               *       a malformation narrative                 
                               *   2 = codes on record don't req.               
                               *       a malformation narrative                 
                               *   3 = some codes on record req.                
                               *       a malformation narrative                 
                               *   4 = record contains an                       
                               *       invalid age, CM cannot be                
                               *       determined                               
                               */                                               
    char   *lvers,            /* grouper version 11 chars                       
                               * HADNvvmm/yy                                    
                               */                                               
    char   *lvdxcctab         /* array of 50 chars                              
                               * one for each input DX                          
                               * Y = DX is a CC                                 
                               * blank = Principal DX or                        
                               *         Invalid DX                             
                               */                                               
   );                                                                           
                                                                                
#if defined(PCWIN)                                                              
short FAR PASCAL _export HADN27CS                                               
#elif defined(PCOS2DLL)  || defined(IBMZOS)                                     
short IRPEXTENT HADN27CS                                                        
#elif defined(IBMAS400)                                                         
short IRPEXTENT HADN27CS                                                        
#elif defined(PCWIN32)                                                          
short IRPEXTENT HADN27CS                                                        
#else                                                                           
short IRPEXTENT HADN27CS                                                        
#endif                                                                          
      (HadgrpDataPtr hgp);                                                      
                                                                                
                                                                                
/* ***************************************************************** */         
/*                                                                   */         
/*        IRP Refined DRG Grouper Calls                              */         
/*                                                                   */         
/* ***************************************************************** */         
                                                                                
                                                                                
                                                                                
/*===================================================================*/         
/* IRP Refined DRG 21.0 function prototypes                          */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadr21cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2)  || defined(IBMZOS)                   
IRPEXTERNC short IRPEXTCALL hadr21c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadr21c1                                            
#else                                                                           
short IRPEXTCALL hadr21c1                                                       
#endif                                                                          
                                                                                
         (                      /* -----IRP Refined Grouper 20.0- */            
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                              /* --addl RefGrp input arguments ----- */         
       char  FAR *vbwght,         /* Birth Weight grams, 4 char     */          
       char  FAR *vlos,           /* Length of Stay, days, 3 char   */          
                              /* ------  output arguments ----- */              
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
                                    /* will also contain refinement   */        
                                    /* error codes                    */        
       char  FAR *vmajop,           /* 1st significant SG  4 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  5 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  5 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  4 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  4 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  4 bytes    */        
       char  FAR *vdxcc,            /* CC DX               5 bytes    */        
                                    /* Refinement MDX                 */        
       char  FAR *vmajop3,          /* 3rd significant SG  4 bytes    */        
                              /* --addl RefGrp output arguments ----- */        
       char  FAR *vrgn,           /* assigned Refined Group 4 char  */          
       char  FAR *vadg,           /* assigned Adjacent DRG  3 char  */          
       char  FAR *vmrg,           /* assigned Medical Refined Group 4 char  */  
       char  FAR *vped,           /* Refinement 'P' for age <18     */          
                              /* ----IRP added output grp arguments ----- */    
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
                                                                                
       );                                                                       
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL R210CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2)  || defined(IBMZOS)                   
IRPEXTERNC void IRPEXTCALL R210CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL R210CN                                               
#else                                                                           
 void  IRPEXTCALL R210CN                                                        
#endif                                                                          
                                                                                
         (                      /* ----IRP Refined Grouper 20.0-- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                              /* --addl RefGrp input arguments ----- */         
    char FAR *vbwght,         /* Birth Weight grams, 4 char     */              
    char FAR *vlos,           /* Length of Stay, days, 3 char   */              
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
                               /* will also contain refinement   */             
                               /* error codes                    */             
    char FAR *vmajop,           /* 1st significant SG  4 bytes    */            
    char FAR *vadx,             /* 1st significant DX  5 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  5 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  4 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  4 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  4 bytes    */            
    char FAR *vdxcc,            /* CC DX               5 bytes    */            
                               /* Refinement MDX                 */             
    char FAR *vmajop3,          /* 3rd significant SG  4 bytes    */            
                                /* --addl RefGrp output arguments ----- */      
    char FAR *vrgn,             /* assigned Refined Group 4 char  */            
    char FAR *vadg,             /* assigned Adjacent DRG  3 char  */            
    char FAR *vmrg,             /* assigned Medical Refined Group 4 char  */    
    char FAR *vped              /* Refinement 'P' for age <18     */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADR21CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2)  || defined(IBMZOS)                   
IRPEXTERNC short IRPEXTCALL HADR21CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADR21CS                                            
#else                                                                           
short IRPEXTCALL HADR21CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
                                                                                
/*===================================================================*/         
/* IRP Refined DRG 22.0 function prototypes                          */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadr22cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2)  || defined(IBMZOS)                   
IRPEXTERNC short IRPEXTCALL hadr22c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadr22c1                                            
#else                                                                           
short IRPEXTCALL hadr22c1                                                       
#endif                                                                          
                                                                                
         (                      /* -----IRP Refined Grouper 20.0- */            
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                              /* --addl RefGrp input arguments ----- */         
       char  FAR *vbwght,         /* Birth Weight grams, 4 char     */          
       char  FAR *vlos,           /* Length of Stay, days, 3 char   */          
                              /* ------  output arguments ----- */              
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
                                  /* will also contain refinement   */          
                                  /* error codes                    */          
       char  FAR *vmajop,           /* 1st significant SG  4 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  5 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  5 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  4 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  4 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  4 bytes    */        
       char  FAR *vdxcc,            /* CC DX               5 bytes    */        
                                  /* Refinement MDX                 */          
       char  FAR *vmajop3,          /* 3rd significant SG  4 bytes    */        
                              /* --addl RefGrp output arguments ----- */        
       char  FAR *vrgn,           /* assigned Refined Group 4 char  */          
       char  FAR *vadg,           /* assigned Adjacent DRG  3 char  */          
       char  FAR *vmrg,           /* assigned Medical Refined Group 4 char  */  
       char  FAR *vped,           /* Refinement 'P' for age <18     */          
                              /* ----IRP added output grp arguments ----- */    
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
                                                                                
       );                                                                       
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL R220CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2)  || defined(IBMZOS)                   
IRPEXTERNC void IRPEXTCALL R220CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL R220CN                                               
#else                                                                           
 void  IRPEXTCALL R220CN                                                        
#endif                                                                          
                                                                                
         (                      /* ----IRP Refined Grouper 20.0-- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                              /* --addl RefGrp input arguments ----- */         
    char FAR *vbwght,         /* Birth Weight grams, 4 char     */              
    char FAR *vlos,           /* Length of Stay, days, 3 char   */              
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
                               /* will also contain refinement   */             
                               /* error codes                    */             
    char FAR *vmajop,           /* 1st significant SG  4 bytes    */            
    char FAR *vadx,             /* 1st significant DX  5 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  5 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  4 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  4 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  4 bytes    */            
    char FAR *vdxcc,            /* CC DX               5 bytes    */            
                               /* Refinement MDX                 */             
    char FAR *vmajop3,          /* 3rd significant SG  4 bytes    */            
                                /* --addl RefGrp output arguments ----- */      
    char FAR *vrgn,             /* assigned Refined Group 4 char  */            
    char FAR *vadg,             /* assigned Adjacent DRG  3 char  */            
    char FAR *vmrg,             /* assigned Medical Refined Group 4 char  */    
    char FAR *vped              /* Refinement 'P' for age <18     */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADR22CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2)  || defined(IBMZOS)                   
IRPEXTERNC short IRPEXTCALL HADR22CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADR22CS                                            
#else                                                                           
short IRPEXTCALL HADR22CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
 /* ****************************************************************** */       
/*===================================================================*/         
/* IRP Refined DRG 23.0 function prototypes                          */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadr23cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2)  || defined(IBMZOS)                   
IRPEXTERNC short IRPEXTCALL hadr23c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadr23c1                                            
#else                                                                           
short IRPEXTCALL hadr23c1                                                       
#endif                                                                          
                                                                                
         (                      /* -----IRP Refined Grouper 20.0- */            
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                              /* --addl RefGrp input arguments ----- */         
       char  FAR *vbwght,         /* Birth Weight grams, 4 char     */          
       char  FAR *vlos,           /* Length of Stay, days, 3 char   */          
                              /* ------  output arguments ----- */              
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
                                  /* will also contain refinement   */          
                                  /* error codes                    */          
       char  FAR *vmajop,           /* 1st significant SG  4 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  5 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  5 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  4 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  4 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  4 bytes    */        
       char  FAR *vdxcc,            /* CC DX               5 bytes    */        
                                  /* Refinement MDX                 */          
       char  FAR *vmajop3,          /* 3rd significant SG  4 bytes    */        
                              /* --addl RefGrp output arguments ----- */        
       char  FAR *vrgn,           /* assigned Refined Group 4 char  */          
       char  FAR *vadg,           /* assigned Adjacent DRG  3 char  */          
       char  FAR *vmrg,           /* assigned Medical Refined Group 4 char  */  
       char  FAR *vped,           /* Refinement 'P' for age <18     */          
                              /* ----IRP added output grp arguments ----- */    
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
                                                                                
       );                                                                       
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL R230CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2)  || defined(IBMZOS)                   
IRPEXTERNC void IRPEXTCALL R230CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL R230CN                                               
#else                                                                           
 void  IRPEXTCALL R230CN                                                        
#endif                                                                          
                                                                                
         (                      /* ----IRP Refined Grouper 20.0-- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                              /* --addl RefGrp input arguments ----- */         
    char FAR *vbwght,         /* Birth Weight grams, 4 char     */              
    char FAR *vlos,           /* Length of Stay, days, 3 char   */              
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
                               /* will also contain refinement   */             
                               /* error codes                    */             
    char FAR *vmajop,           /* 1st significant SG  4 bytes    */            
    char FAR *vadx,             /* 1st significant DX  5 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  5 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  4 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  4 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  4 bytes    */            
    char FAR *vdxcc,            /* CC DX               5 bytes    */            
                               /* Refinement MDX                 */             
    char FAR *vmajop3,          /* 3rd significant SG  4 bytes    */            
                                /* --addl RefGrp output arguments ----- */      
    char FAR *vrgn,             /* assigned Refined Group 4 char  */            
    char FAR *vadg,             /* assigned Adjacent DRG  3 char  */            
    char FAR *vmrg,             /* assigned Medical Refined Group 4 char  */    
    char FAR *vped              /* Refinement 'P' for age <18     */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADR23CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2)  || defined(IBMZOS)                   
IRPEXTERNC short IRPEXTCALL HADR23CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADR23CS                                            
#else                                                                           
short IRPEXTCALL HADR23CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
 /* ****************************************************************** */       
/*===================================================================*/         
/* IRP Refined DRG 24.0 function prototypes                          */         
/*===================================================================*/         
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL hadr24cw                                            
#elif defined(PCOS2DLL) || defined(PCOS2)  || defined(IBMZOS)                   
IRPEXTERNC short IRPEXTCALL hadr24c1                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL hadr24c1                                            
#else                                                                           
short IRPEXTCALL hadr24c1                                                       
#endif                                                                          
                                                                                
         (                      /* -----IRP Refined Grouper 20.0- */            
                 /* -------- input arguments ----- */                           
        short grpfunc,          /* grouper function:                            
                  *   0 = group,                                                
                  *   1 = free this groupers storage                            
                  *   2 = free all groupers storage                             
                  */                                                            
        short  vndx,            /* number dx (diagnoses)  50 MAX  */            
        short  vnsg,            /* number sg (procedures) 50 MAX  */            
       char  FAR *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */        
       char  FAR *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */        
       char  FAR *vage,             /* age - 3 char                   */        
       char  FAR *vsex,             /* sex - 1 char 1,m or 2,f        */        
       char  FAR *vdstat,           /* UB92 discharge stat 2 char     */        
                              /* --addl RefGrp input arguments ----- */         
       char  FAR *vbwght,         /* Birth Weight grams, 4 char     */          
       char  FAR *vlos,           /* Length of Stay, days, 3 char   */          
                              /* ------  output arguments ----- */              
       char  FAR *vdrg,             /* assigned DRG 3 char            */        
       char  FAR *vmdc,             /* assigned MDC 2 char            */        
       char  FAR *vrtc,             /* return code  1 char            */        
                                  /* will also contain refinement   */          
                                  /* error codes                    */          
       char  FAR *vmajop,           /* 1st significant SG  4 bytes    */        
       char  FAR *vadx,             /* 1st significant DX  5 bytes    */        
       char  FAR *vsdx,             /* 2nd significant DX  5 bytes    */        
       char  FAR *vers,             /* grouper version 11 bytes       */        
       char  FAR *vmajop2,          /* 2nd significant SG  4 bytes    */        
       char  FAR *vminop,           /* 1st minor sign. SG  4 bytes    */        
       char  FAR *vminop2,          /* 2nd minor sign. SG  4 bytes    */        
       char  FAR *vdxcc,            /* CC DX               5 bytes    */        
                                  /* Refinement MDX                 */          
       char  FAR *vmajop3,          /* 3rd significant SG  4 bytes    */        
                              /* --addl RefGrp output arguments ----- */        
       char  FAR *vrgn,           /* assigned Refined Group 4 char  */          
       char  FAR *vadg,           /* assigned Adjacent DRG  3 char  */          
       char  FAR *vmrg,           /* assigned Medical Refined Group 4 char  */  
       char  FAR *vped,           /* Refinement 'P' for age <18     */          
                              /* ----IRP added output grp arguments ----- */    
       char  FAR *vdxcctab          /* array of 50 char - one for each          
                  * input DX.  set to 'Y' (upper                                
                  * case Y) if corresponding DX is                              
                  * a valid CC for this Prinicipal                              
                  * DX.                                                         
                  */                                                            
                                                                                
       );                                                                       
                                                                                
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC void FAR PASCAL R240CN                                               
#elif defined(PCOS2DLL) || defined(PCOS2)  || defined(IBMZOS)                   
IRPEXTERNC void IRPEXTCALL R240CN                                               
#elif defined(PCWIN32)                                                          
IRPEXTERNC void IRPEXTCALL R240CN                                               
#else                                                                           
 void  IRPEXTCALL R240CN                                                        
#endif                                                                          
                                                                                
         (                      /* ----IRP Refined Grouper 20.0-- */            
                 /* -------- input arguments ----- */                           
                 /* ---HCFA MVS COMPATIBLE ENTRY-- */                           
                 /* ------------------------------ */                           
    char FAR *vdx_ptr,          /* to array of 50 DX x 5 bytes ea */            
    int  FAR *vndx,             /* number dx (diagnoses)  50 MAX  */            
    char FAR *vsg_ptr,          /* to array of 50 SG x 4 bytes ea */            
    int  FAR *vnsg,             /* number sg (procedures) 50 MAX  */            
    char FAR *vage,             /* age - 3 char                   */            
    char FAR *vsex,             /* sex - 1 char 1,m or 2,f        */            
    char FAR *vdstat,           /* UB92 discharge stat 2 char     */            
                              /* --addl RefGrp input arguments ----- */         
    char FAR *vbwght,         /* Birth Weight grams, 4 char     */              
    char FAR *vlos,           /* Length of Stay, days, 3 char   */              
                 /* ------  output arguments ----- */                           
    char FAR *vdrg,             /* assigned DRG 3 char            */            
    char FAR *vmdc,             /* assigned MDC 2 char            */            
    char FAR *vrtc,             /* return code  1 char            */            
                               /* will also contain refinement   */             
                               /* error codes                    */             
    char FAR *vmajop,           /* 1st significant SG  4 bytes    */            
    char FAR *vadx,             /* 1st significant DX  5 bytes    */            
    char FAR *vsdx,             /* 2nd significant DX  5 bytes    */            
    char FAR *vers,             /* grouper version 11 bytes       */            
    char FAR *vmajop2,          /* 2nd significant SG  4 bytes    */            
    char FAR *vminop,           /* 1st minor sign. SG  4 bytes    */            
    char FAR *vminop2,          /* 2nd minor sign. SG  4 bytes    */            
    char FAR *vdxcc,            /* CC DX               5 bytes    */            
                               /* Refinement MDX                 */             
    char FAR *vmajop3,          /* 3rd significant SG  4 bytes    */            
                                /* --addl RefGrp output arguments ----- */      
    char FAR *vrgn,             /* assigned Refined Group 4 char  */            
    char FAR *vadg,             /* assigned Adjacent DRG  3 char  */            
    char FAR *vmrg,             /* assigned Medical Refined Group 4 char  */    
    char FAR *vped              /* Refinement 'P' for age <18     */            
                                                                                
       );                                                                       
                                                                                
#if defined(PCWIN)                                                              
IRPEXTERNC short FAR PASCAL HADR24CS                                            
#elif defined(PCOS2DLL) || defined(PCOS2)  || defined(IBMZOS)                   
IRPEXTERNC short IRPEXTCALL HADR24CS                                            
#elif defined(PCWIN32)                                                          
IRPEXTERNC short IRPEXTCALL HADR24CS                                            
#else                                                                           
short IRPEXTCALL HADR24CS                                                       
#endif                                                                          
                               /* Single Structure Entry Point */               
        (Hadgrp_Data *hgp);                                                     
                                                                                
 /* ****************************************************************** */       
                                                                                
#if defined(IBMZOS)
IRPEXTERNC void IRPEXTCALL NewYorkMedicaid
#elif defined(PCWIN32)
IRPEXTERNC void IRPEXTCALL NewYorkMedicaid
#else                                                                           
void IRPEXTCALL NewYorkMedicaid
#endif
     (Hadgrp2_Data *hgp);

#endif                                                                          
               /* endif for ! defined(GRPGEN) */                                
                                                                                
#ifndef PATHLENGTH                                                              
#define PATHLENGTH 260                         /* twf */                        
#endif                                                                          
                                                                                
#endif        /* HADGRPCP_INCLUDED */                                           
                                                                                
         /* end of hadgrpcp.h */                                                
                                                                                     
