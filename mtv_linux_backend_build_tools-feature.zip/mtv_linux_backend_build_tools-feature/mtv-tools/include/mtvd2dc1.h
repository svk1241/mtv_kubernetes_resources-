/***********************************************************************************/
/*                                                                                 */
/*   mtvd2dc1.h                                                                    */
/*                                                                                 */
/*   This .h file is forced into all source code by a new source-code editor       */
/*   widget, which replaces calls to CA's tird2dc1() function with calls to our    */
/*   mtvd2dc1() function instead; ours guarantees rounding is used whenever we     */
/*   set a "double" with > 0 decimals and/or > 15 digits.  Our mtvd2dc1() examines */
/*   the parameters and calls CA's tird2dc1(), perhaps with the original           */
/*   or perhaps forcing rounding.                                                  */
/*                                                                                 */
/*   Chad Varner       3/24/2009    Created                                        */
/*                                                                                 */
/***********************************************************************************/

#ifndef _MTVD2DC1_H
#define _MTVD2DC1_H
extern double mtvd2dc1( double, int, int, int );
#endif
