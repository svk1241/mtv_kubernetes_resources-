/***********************************************************************************/
/*                                                                                 */
/*   mtvgetst.h                                                                    */
/*                                                                                 */
/*   This .h file defines MTV_GetSystemTimeAsFileTime, which is called from        */
/*   MTVDAT2(), and from the gettimeofday() function which is implemented in       */
/*   MVPPMKSI and called from both MVPPMKSI and EABCLABY.  It fetches the system   */
/*   time as a FILETIME structure, using shared memory and QueryPerformanceCounter */
/*   to develop a timestamp with nearly-correct microseconds.                      */
/*                                                                                 */
/*   Chad Varner       4/17/2009    Created                                        */
/*                                                                                 */
/***********************************************************************************/

#ifndef _MTVFILET_H
#define _MTVFILET_H

#ifdef TARGET_WIN32

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

extern long MTV_GetSystemTimeAsFileTime( FILETIME* );

#ifdef __cplusplus
}
#endif

#endif /*TARGET_WIN32*/



#endif
