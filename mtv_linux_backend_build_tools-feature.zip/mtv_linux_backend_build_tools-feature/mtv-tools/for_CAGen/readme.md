copy this files to the CA Gen runtime folder: /opt/CA/CAGen/runtime

#steps for build /opt/CA/CAGen/lib/libae_userexits_c.so:

cp src/* /opt/CA/CAGen/runtime/src
cp include/* /opt/CA/CAGen/runtime/include

cd /opt/CA/CAGen/runtime/src
make #will build libae_userexits_c.so in /opt/CA/CAGen/lib/