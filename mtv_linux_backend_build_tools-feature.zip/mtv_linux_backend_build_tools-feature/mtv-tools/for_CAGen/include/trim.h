#ifndef  __INCL_TRIM

#define  __INCL_TRIM

extern   char* rTrim( char* pszStr );
extern   char* lTrim( char* pszStr );

#define  Trim(s)  ( rTrim(lTrim(s)) )

#endif
