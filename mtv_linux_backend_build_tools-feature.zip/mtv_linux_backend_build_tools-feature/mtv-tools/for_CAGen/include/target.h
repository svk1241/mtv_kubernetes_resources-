/*!
 ****************************************************************************
 *                                                                          *
 * Module:           TARGET.H                                               *
 *                                                                          *
 * Description:      Checks for pre-defined OS targets when generating ext- *
 *                   ernal action blocks for IEF generated applications.    *
 *                                                                          *
 * Functions:        None                                                   *
 *                                                                          *
 * Library:          none                                                   *
 *                                                                          *
 *                                                                          *
 ****************************************************************************
!*/

#if !defined(__INCL_TARGET)
#define __INCL_TARGET

#undef  __HAVE_TARGET

#if defined(TARGET_OS2)
#define __HAVE_TARGET
#elif defined(TARGET_WIN31)
#define __HAVE_TARGET
#elif defined(TARGET_WIN32)
#define __HAVE_TARGET
#elif defined(TARGET_HPUX)
#define __HAVE_TARGET
#elif defined(TARGET_SOL)
#define __HAVE_TARGET
#elif defined(TARGET_AIX)
#define __HAVE_TARGET
#elif defined(TARGET_SCOUX)
#define __HAVE_TARGET
#elif defined(TARGET_LINUX)
#define __HAVE_TARGET
#endif

/* If we've not been aimed at a specific operating system, 
   generate a compiler error */

#ifndef __HAVE_TARGET
#error "Unknown target operating system"
#else
#undef __HAVE_TARGET

#ifdef   TARGET_OS2
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <io.h>
#include <limits.h>
#include <share.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>

#define  _GETENV(var)      getenv( var )
#define  _CREAT(f)         _open( f, O_BINARY | O_RDWR | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE )
#define  _OPEN(f)          _open( f, O_BINARY | O_RDWR | O_CREAT, S_IREAD | S_IWRITE )
#define  _OPEN_RD(f)       _open( f, O_BINARY | O_RDONLY, S_IREAD )
#define  _READ(fd,buf,sz)  _read( fd, buf, sz )
#define  _WRITE(fd,buf,sz) _write( fd, buf, sz )
#define  _CLOSE(fd)        _close(fd)
#define  _SEEK(fd,len,pos) _lseek( fd, len, pos )
#define  HFILE             int
#define  HFILE_ERROR       (-1)

#define  _STRCAT(d,s)      ( strcat(d,s) )
#define  _STRCPY(d,s)      ( strcpy(d,s) )
#define  _STRLEN(s)        ( strlen(s)   )
#define  _STRCMP(s,d)      ( strcmp(s,d)   )

#define  _MEMCPY(d,s,n)    ( memcpy( d, s, n ) )
#define  _MEMCMP(d,s,n)    ( memcmp( d, s, n ) )
#define  _MEMICMP(d,s,n)   ( memicmp( d, s, n ) )
#define  _MEMSET(d,v,n)    ( memset( d, v, n ) )

#else
#ifdef  TARGET_WIN31

#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <io.h>
#include <limits.h>
#include <share.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>

#include <windows.h>

#include "getenv.h"

#define  _GETENV(var)      __GetEnv( var )
#define  _CREAT(f)         _lcreat( f, 0 )
#define  _OPEN(f)          _lopen( f, READ_WRITE | OF_SHARE_DENY_NONE )
#define  _OPEN_RD(f)       _lopen( f, READ | OF_SHARE_DENY_NONE )
#define  _READ(fd,buf,sz)  _lread( fd, buf, sz )
#define  _WRITE(fd,buf,sz) _lwrite( fd, buf, sz )
#define  _CLOSE(fd)        _lclose(fd)
#define  _SEEK(fd,len,pos) _llseek( fd, len, pos )

#define  _STRCAT(d,s)      ( lstrcat(d,s) )
#define  _STRCPY(d,s)      ( lstrcpy(d,s) )
#define  _STRLEN(s)        ( lstrlen(s)   )
#define  _STRCMP(s,d)      ( lstrcmp(s,d)   )

#define  _MEMCPY(d,s,n)    ( _fmemmove( d, s, n ) )
#define  _MEMCMP(d,s,n)    ( _fmemcmp( d, s, n ) )
#define  _MEMICMP(d,s,n)   ( _fmemicmp( d, s, n ) )
#define  _MEMSET(d,v,n)    ( _fmemset( d, v, n ) )

#else
#ifdef   TARGET_WIN32

#define  WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <io.h>
#include <limits.h>
#include <share.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>

#define  _GETENV(var)      getenv( var )
#define  _CREAT(f)         _lcreat( f, 0 )
#define  _OPEN(f)          _lopen( f, OF_READWRITE | OF_SHARE_DENY_NONE )
#define  _OPEN_RD(f)       _lopen( f, OF_READ | OF_SHARE_DENY_NONE )
#define  _READ(fd,buf,sz)  _lread( fd, buf, sz )
#define  _WRITE(fd,buf,sz) _lwrite( fd, buf, sz )
#define  _CLOSE(fd)        _lclose(fd)
#define  _SEEK(fd,len,pos) _llseek( fd, len, pos )

#define  _STRCAT(d,s)      ( lstrcat(d,s) )
#define  _STRCPY(d,s)      ( lstrcpy(d,s) )
#define  _STRLEN(s)        ( lstrlen(s)   )
#define  _STRCMP(s,d)      ( lstrcmp(s,d)   )
#define  _STRICMP(s,d)     ( _stricmp(s,d) )

#define  _MEMCPY(d,s,n)    ( memcpy( d, s, n ) )
#define  _MEMCMP(d,s,n)    ( memcmp( d, s, n ) )
#define  _MEMICMP(d,s,n)   ( _memicmp( d, s, n ) )
#define  _MEMSET(d,v,n)    ( memset( d, v, n ) )

#else
#if defined(TARGET_HPUX) | defined(TARGET_SCOUX) | defined(TARGET_SOL)
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>

#define USE_VIRT32
typedef int BOOL;
typedef unsigned long DWORD;

#define  _GETENV(var)      getenv( var )
#define  _CREAT(f)         creat( f, S_IRWXU | S_IRWXG | S_IRWXO )
#define  _OPEN(f)          open( f, O_RDWR | O_CREAT , 0 )
#define  _OPEN_RD(f)       open( f, O_RDONLY , 0 )
#define  _READ(fd,buf,sz)  read( fd, buf, sz )
#define  _WRITE(fd,buf,sz) write( fd, buf, sz )
#define  _CLOSE(fd)        close(fd)
#define  _SEEK(fd,len,pos) lseek( fd, len, pos )

/* TLB - These are the old definitions of previous 7 definitions
#define  _CREAT(f)         _creat( f, S_IREAD | S_IWRITE )
#define  _OPEN(f)          _open( f, O_BINARY | O_RDWR | O_CREAT, S_IREAD | S_IWRITE )
#define  _OPEN_RD(f)       _open( f, O_BINARY | O_RDONLY, S_IREAD )
#define  _READ(fd,buf,sz)  _read( fd, buf, sz )
#define  _WRITE(fd,buf,sz) _write( fd, buf, sz )
#define  _CLOSE(fd)        _close(fd)
#define  _SEEK(fd,len,pos) _lseek( fd, len, pos )
*/

#define  HFILE             int
#define  HFILE_ERROR       (-1)

#define  _STRCAT(d,s)      ( strcat(d,s) )
#define  _STRCPY(d,s)      ( strcpy(d,s) )
#define  _STRLEN(s)        ( strlen(s)   )
#define  _STRCMP(s,d)      ( strcmp(s,d)   )
#define  _STRICMP(s,d)     ( strcasecmp(s,d)   )

#define  _MEMCPY(d,s,n)    ( memcpy( d, s, n ) )
#define  _MEMCMP(d,s,n)    ( memcmp( d, s, n ) )
#define  _MEMICMP(d,s,n)   ( memcmp( d, s, n ) )

/* TLB - This is the old definition of previous  definition
#define  _MEMICMP(d,s,n)   ( memicmp( d, s, n ) )
*/

#define  _MEMSET(d,v,n)    ( memset( d, v, n ) )

#endif
#endif
#endif
#endif

#ifndef  TRUE
#define  TRUE  ( 1 )
#endif

#ifndef  FALSE
#define  FALSE ( 0 )
#endif

/* Set non-machine specific includes */
#include "trim.h"

#endif

#endif /* __INCL_TARGET */
