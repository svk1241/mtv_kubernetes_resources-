/*!
 ***********************************************************************
 *
 * EDS MetaVance
 * Copyright (C) 1999-2003, EDS
 * All Rights Reserved.
 *
 * EDS
 * 225 Grandview Avenue
 * Camp Hill, PA  USA
 * http://www.eds.com
 *
 * This source code is the confidential property of EDS, All proprietary
 * rights, including but not limited to any trade secret, copyright,
 * patent or trademark rights in and to this source code are the
 * property of EDS.  This source code is not to be used, disclosed or
 * reproduced in any form without the express written consent of EDS.
 *
 ***********************************************************************
 *
 * $NoKeywords: $
 * @doc INTERNAL
!*/
#ifndef MTVBF__INCLUDED
#define MTVBF__INCLUDED

#ifdef  TARGET_MVS
#undef  EXCLUDE_METAVANCE
#define EXCLUDE_BF_CREATE
#define METAVANCE_HELPERS
#endif

#ifdef  TARGET_HPUX
#undef  EXCLUDE_METAVANCE
#define EXCLUDE_BF_CREATE
#define METAVANCE_HELPERS
#endif

#ifdef  TARGET_WIN32
#undef  EXCLUDE_METAVANCE
#define EXCLUDE_BF_CREATE
#define METAVANCE_HELPERS
#endif

#ifdef  __cplusplus
extern "C" {
#endif

#ifndef MTVBF_INTERNAL_INCLUDE
typedef const void*   MTVBF;
#endif

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           MtvBF_Create()
 *
 *  DESCRIPTION:        Create a set of p-boxes and s-boxes for the
 *                      given key.  The key may be from 0 to 56 bytes
 *                      (0 to 448 bits).  Return a pointer to the
 *                      caller which opaquely describes the p-boxes
 *                      and s-boxes.
 *
 *  INPUT PARAMETERS:   pucKey: private key
 *                      nKey:   private key length
 *                      ppBF:   output pointer to initalized p-boxes and
 *                              s-boxes
 *
 *  RETURN VALUE:       MTVBF_OKAY       if all went well
 *                      MTVBF_INVALIDARG an invalid argument
 *                      MTVBF_NOMEMORY   if no memory available for
 *                                       initialization
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
#define MtvBF_Create    MTVBFCRE
extern int MtvBF_Create( const unsigned char* pucKey,
                         size_t nKey,
                         MTVBF** ppBF );

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           MtvBF_Encipher()
 *
 *  DESCRIPTION:        Encrypt a block of data using the pre-created
 *                      P-boxes and S-boxes.  The data buffer must
 *                      be a multiple of 8 bytes (64-bits) in length.
 *
 *  INPUT PARAMETERS:   pBF:    initialized p-boxes and s-boxes
 *                      pucIn:  input buffer -- length is nBuf
 *                      pucOut: output buffer -- length is nBuf
 *                      nBuf:   buffer length
 *                      iMode:  encryption mode
 *
 *  RETURN VALUE:       MTVBF_OKAY       if all went well
 *                      MTVBF_INVALIDARG an invalid argument
 *                      MTVBF_BAD_BUFFER_SIZE buffer is not a multiple
 *                      of 8 bytes
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
#define MtvBF_Encipher  MTVBFENC
extern int MtvBF_Encipher( MTVBF* pBF,
						   unsigned char aucChain[8],
                           const unsigned char* pucIn,
                           unsigned char* pucOut,
                           size_t nBuf,
                           int iMode );

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           MtvBF_Decipher()
 *
 *  DESCRIPTION:        Decrypt a block of data using the pre-created
 *                      P-boxes and S-boxes.  The data buffer must
 *                      be a multiple of 8 bytes (64-bits) in length.
 *
 *  INPUT PARAMETERS:   pBF:    initialized p-boxes and s-boxes
 *                      pucIn:  input buffer -- length is nBuf
 *                      pucOut: output buffer -- length is nBuf
 *                      nBuf:   buffer length
 *                      iMode:  encryption mode
 *
 *  RETURN VALUE:       MTVBF_OKAY       if all went well
 *                      MTVBF_INVALIDARG an invalid argument
 *                      MTVBF_BAD_BUFFER_SIZE buffer is not a multiple
 *                      of 8 bytes
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
#define MtvBF_Decipher  MTVBFDEC
extern int MtvBF_Decipher( MTVBF* pBF,
						   unsigned char aucChain[8],
                           const unsigned char* pucIn,
                           unsigned char* pucOut,
                           size_t nBuf,
                           int iMode );

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           MtvBF_Destroy()
 *
 *  DESCRIPTION:        Deallocate a previously allocated set of P-boxes
 *                      S-boxes.
 *
 *  INPUT PARAMETERS:   pBF:    initialized p-boxes and s-boxes
 *
 *  RETURN VALUE:       MTVBF_OKAY       if all went well
 *                      MTVBF_INVALIDARG an invalid argument
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
#define MtvBF_Destroy   MTVBFDES
extern int MtvBF_Destroy( MTVBF** ppBF );

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           MtvBF_GetChain()
 *
 *  DESCRIPTION:        Obtain current 64-bit chain value.
 *
 *  INPUT PARAMETERS:   pBF:        initialized p-boxes and s-boxes
 *                      aucChain:   output chain value
 *
 *  RETURN VALUE:       MTVBF_OKAY       if all went well
 *                      MTVBF_INVALIDARG an invalid argument
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
/*
#define MtvBF_GetChain  MTVBFGET
extern int MtvBF_GetChain( MTVBF* pBF, unsigned char aucChain[8] );
*/

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           MtvBF_SetChain()
 *
 *  DESCRIPTION:        Set current 64-bit chain value.
 *
 *  INPUT PARAMETERS:   pBF:        initialized p-boxes and s-boxes
 *                      aucChain:   input chain value
 *
 *  RETURN VALUE:       MTVBF_OKAY       if all went well
 *                      MTVBF_INVALIDARG an invalid argument
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
/*
#define MtvBF_SetChain  MTVBFSET
extern int MtvBF_SetChain( MTVBF* pBF, unsigned char aucChain[8] );
*/

/*
 ***********************************************************************
 *                   Return Codes
 ***********************************************************************
 */
#define MTVBF_OKAY              0
#define MTVBF_INVALIDARG        1
#define MTVBF_NOMEMORY          2
#define MTVBF_BAD_BUFFER_SIZE   3
#define MTVBF_CANNOT_INIT       4

/*
 ***********************************************************************
 *                   Encipher / Decipher modes
 ***********************************************************************
 */
#define MTVBF_MODE_ECB      0
#define MTVBF_MODE_CBC      1
#define MTVBF_MODE_CFB      2

/*
 ***********************************************************************
 *
 * ECB: Electronic Code Book
 * CBC: Cipher Block Chaining
 * CFB: Cipher Feed Back
 *
 *
 * In ECB mode, chaining is not used.  If the same block is encrypted
 * twice with the same key, the resulting cipher text blocks are the
 * same.
 *
 * In CBC mode a cipher text block is obtained by first XOR-ing the
 * plain text block with the previous cipher text block, and encrypting
 * the resulting value.
 *
 * In CFB mode a cipher text block is obtained by encrypting the 
 * previous cipher text block and XOR-ing the resulting value with the
 * plain text.
 *
 * The operation mode is specified in the iMode parameter on the
 * Encipher() and Decipher() functions.
 *
 ***********************************************************************
 */

#ifdef  METAVANCE_HELPERS

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           MTVBFCGE()
 *
 *  DESCRIPTION:        Encrypt a buffer in place.
 *
 *  INPUT PARAMETERS:   pucMsgIn: data buffer
 *                      pnLen:    data length (in / out)
 *                      nMax:     buffer capacity
 *
 *  RETURN VALUE:       0       if all went well
 *                      -1      if encryption failed for any reason
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
#ifdef  TARGET_MVS
/*#pragma linkage(MTVBFCGE, COBOL)*/
#endif
extern int MTVBFCGE( unsigned char* pucMsgIn,
                     size_t* pnLen,
                     size_t nMax );

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           MTVBFCGD()
 *
 *  DESCRIPTION:        Decrypt a buffer in place.
 *
 *  INPUT PARAMETERS:   pucMsgIn: data buffer
 *                      pnLen:    data length (in / out)
 *                      nMax:     buffer capacity
 *
 *  RETURN VALUE:       0       if all went well
 *                      -1      if encryption failed for any reason
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
#ifdef  TARGET_MVS
/*#pragma linkage(MTVBFCGD, COBOL)*/
#endif
extern int MTVBFCGD( unsigned char* pucMsgIn,
                     size_t nLen );

#ifndef TARGET_MVS

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           IsEncryptOff()
 *
 *  DESCRIPTION:        Check if environment variable MTV_ENCRYPTION_OFF
 *                      is set to true
 *
 *  INPUT PARAMETERS:   none
 *
 *  RETURN VALUE:       0       encryption is on
 *                      1       encryption is off
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/

extern "C" int IsEncryptOff();

/* MetaVance's 448-bit key available via object module */
extern const unsigned char  aucMtvKey448[56];

/* MetaVance's 40-bit key available via object module */
extern  const unsigned char aucMtvKey40[8];

#endif  /* ndef TARGET_MVS */

#endif  /* def METAVANCE_HELPERS */

#ifdef  __cplusplus
}
#endif

#endif	/* MTVBF_INCLUDED */
