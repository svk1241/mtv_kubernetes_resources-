/*!
 ***********************************************************************
 *
 * EDS MetaVance
 * Copyright (C) 1999-2003, EDS
 * All Rights Reserved.
 *
 * EDS
 * 225 Grandview Avenue
 * Camp Hill, PA  USA
 * http://www.eds.com
 *
 * This source code is the confidential property of EDS, All proprietary
 * rights, including but not limited to any trade secret, copyright,
 * patent or trademark rights in and to this source code are the
 * property of EDS.  This source code is not to be used, disclosed or
 * reproduced in any form without the express written consent of EDS.
 *
 ***********************************************************************
 *
 * $NoKeywords: $
 * @doc INTERNAL
!*/

/*
 ***********************************************************************
 *
 * Implements Blowfish encryption algorithm as described in:
 *
 *  Schneier, B., "Fast Software Encryption", Cambridge Security
 *  Workshop Proceedings (December 1993), Springer-Verlag, 1994,
 *  pp. 191-204.
 *
 * also at: http://www.counterpane.com/bfsverlag.html
 *
 * Blowfish is a variable-length key block cipher consisting of two
 * parts: A) key expansion and B) data encryption.
 *
 * Key expansion converts a key of at most 448 bits into several subkey
 * arrays totaling 4168 bytes.
 *
 * Data encryption occurs via a 16-round Feistel network. Each round
 * consists of a key-dependent permutation, and a key- and data-
 * dependent substitution.
 *
 * Generating the Subkeys:
 *
 * The subkeys are calculated using the Blowfish algorithm. The exact
 * method is as follows:
 *
 * 1. Initialize the P-box and then the four S-boxes, in order, with a
 * fixed string. This string consists of the hexadecimal digits of pi
 * (less the initial 3).
 *
 * 2. XOR P1 with the first 32 bits of the key, XOR P2 with the second
 * 32-bits of the key, and so on for all bits of the key (possibly up
 * to P14). Repeatedly cycle through the key bits until the entire
 * P-box has been XORed with key bits.
 *
 * 3. Encrypt an all-zero string with the Blowfish algorithm, using the
 * subkeys described in steps (1) and (2).
 *
 * 4. Replace P1 and P2 with the output of step (3).
 *
 * 5. Encrypt the output of step (3) using the Blowfish algorithm with
 * the modified subkeys.
 *
 * 6. Replace P3 and P4 with the output of step (5).
 *
 * 7. Continue the process, replacing all entries of the P-boxes, and
 * then all four S-boxes in order, with the output of the continuously
 * changing Blowfish algorithm.
 *
 * In total, 521 iterations are required to generate all required
 * subkeys.
 *
 * Blowfish algorithm:
 *
 * Implement Feistel network consisting of 16 rounds. The input is a
 * 64-bit data element, X.
 *
 * Divide x into two 32-bit halves: xL, xR
 * For i = 1 to 16:
 *  xL = xL XOR Pi
 *  xR = F(xL) XOR xR
 *  Swap xL and xR
 * End-For
 * Swap xL and xR (Undo the last swap.)
 * xR = xR XOR P17
 * xL = xL XOR P18
 * Recombine xL and xR
 *
 * Function F:
 *  Divide xL into four eight-bit quarters: a, b, c, and d
 *   F(xL) = ((S1,a + S2,b mod (2^32)) XOR S3,c) + S4,d mod (2^32)
 *
 * (*) p-boxes = permutation boxes
 * (*) s-boxes = substitution boxes
 *
 ***********************************************************************
 * <html><head><title>Feistel network definition</title></head>
 * <body>
 * <p>A Feistel network can be described by the following 
 * algorithm (taken from
 * <a href="http://www.counterpane.com/applied.html">
 * Applied Cryptography</a>):</p>
 * <blockquote>
 *   <p style="font-family: Arial Unicode MS;">
 *   <small>Divide a block of length n into two parts, 
 *   L and R, of length n/2<br>
 *   L<sub>i</sub> = R<sub>i-1</sub><br>
 *   R<sub>i</sub> = L<sub>i-1</sub>
 *   XOR f(R<sub>i-1</sub>,K<sub>i</sub>)</small></p>
 * </blockquote>
 * </body>
 * </html>
 ***********************************************************************
 */

#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <utility>

#if defined(TARGET_WIN32)
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif

#if defined(TARGET_HPUX)
#include <pthread.h>
#endif

/*
 ***********************************************************************
 *                  Defines, Macros, and Structures                    *
 ***********************************************************************
 */
typedef unsigned char uchar;

#if (INT_MAX==0x7fff)

/* 16-bit machines */
typedef unsigned long uint32;

#elif (INT_MAX==0x7fffffff)

/* 32/64-bit machines */
typedef unsigned int uint32;

#else

/* What type of machine do we have here? */
#error unsupported integer size

#endif

/* Default to big-endian */
#define BIG_ENDIAN

/* Is this a little-endian machine? */
#ifdef _MSC_VER
#ifdef _M_IX86

/* We're on an INTEL machine */
#undef BIG_ENDIAN

#endif
#endif

#ifdef TARGET_LINUX
#undef BIG_ENDIAN
#endif

/* Clients get an opaque handle to this structure after a Create()
call.  The handle must be presented on each and every Encrypt()
or Decrypt() call.  Destroy() releases the allocation. */

struct MtvBF
{
    uint32  m_uiDogTagS;
    uint32  m_auiP[18];
    uint32  m_auiS[4][256];
    uint32  m_auiChain[2];
    uint32  m_uiDogTagE;
};
typedef struct MtvBF    MTVBF;

#define BF_DOGTAG_S 0x42460033  /* 'B', 'F', 0, '3' */
#define BF_DOGTAG_E 0x42460133  /* 'B', 'F', 1, '3' */

#define MTVBF_INTERNAL_INCLUDE
#include "mtvbf.h"

#ifndef _countof
#define _countof(x) ( sizeof(x) / sizeof(x[0]) )
#endif

#ifdef  METAVANCE_USES_448
#define METAVANCE_KEY   aucMtvKey448
#else
	#ifdef  METAVANCE_USES_128
	#define METAVANCE_KEY aucMtvKey128
	#else
	#define METAVANCE_KEY   aucMtvKey40
	#endif
#endif

/*
 ***********************************************************************
 * Static Data                                                         *
 ***********************************************************************
 */

#ifndef EXCLUDE_METAVANCE

#include "mtvk448.h"    /* MetaVance 448-bit pre-calculated subkeys */
#include "mtvk40.h"     /* MetaVance 40-bit pre-calculated subkeys */
#include "mtvk128.h"    /* MetaVance 40-bit pre-calculated subkeys */

#endif  /* ndef EXCLUDE_METAVANCE */

#ifndef EXCLUDE_BF_CREATE

#include "mtvbfk.h"     /* Initial Blowfish P- and S-boxes */

#endif  /* ndef EXCLUDE_BF_CREATE */

/*
 ***********************************************************************
 *                         MetaVance Key holder                        *
 ***********************************************************************
 */
std::pair<const unsigned char*, int> GetMTVKey();

#if !defined(TARGET_MVS)
class CKeyHolder
{
public:
	CKeyHolder()
		: pMtv40(NULL)
		, pMtv448(NULL)
		, pMtv128(NULL)
	{
#if defined(TARGET_WIN32)
		InitializeCriticalSection(&cs);
#endif
	}

	const MTVBF* get_Key(void)
	{
		const MTVBF*	ret = NULL;
        auto MTVKey = GetMTVKey();
		if (MTVKey.second == 40)
		{
			ret = get_MTV40();
		}
		else if (MTVKey.second == 448)
		{
			ret = get_MTV448();
		}
		else if (MTVKey.second == 128)
		{
			ret = get_MTV128();
		}


		return ret;
	}

	const MTVBF* get_MTV40(void)
	{
		if (NULL == pMtv40)
		{
			Lock();
			if (NULL == pMtv40)
			{
				MtvBF_Create(aucMtvKey40, _countof(aucMtvKey40), &pMtv40);
			}
			Unlock();
		}

		return pMtv40;
	}

	const MTVBF* get_MTV128(void)
	{
		if (NULL == pMtv128)
		{
			Lock();
			if (NULL == pMtv128)
			{
				MtvBF_Create(aucMtvKey128, _countof(aucMtvKey128), &pMtv128);
			}
			Unlock();
		}

		return pMtv128;
	}

	const MTVBF* get_MTV448(void)
	{
		if (NULL == pMtv448)
		{
			Lock();
			if (NULL == pMtv448)
			{
				MtvBF_Create(aucMtvKey448, _countof(aucMtvKey448), &pMtv448);
			}
			Unlock();
		}

		return pMtv40;
	}

	~CKeyHolder()
	{
		MtvBF_Destroy(&pMtv40);
		MtvBF_Destroy(&pMtv448);
		MtvBF_Destroy(&pMtv128);

#if defined(TARGET_WIN32)
		DeleteCriticalSection(&cs);
#endif
	}

private:
	// No copy construction or assignment
	CKeyHolder(const CKeyHolder&);
	CKeyHolder& operator =(const CKeyHolder&);

	void Lock(void)
	{
#if defined(TARGET_WIN32)
		EnterCriticalSection(&cs);
#endif
#if defined(TARGET_HPUX)
		pthread_mutex_lock( &cs );
#endif
	}

	void Unlock(void)
	{
#if defined(TARGET_WIN32)
		LeaveCriticalSection(&cs);
#endif
#if defined(TARGET_HPUX)
		pthread_mutex_unlock( &cs );
#endif
	}

	MTVBF*	pMtv40;
	MTVBF*	pMtv448;
	MTVBF*	pMtv128;

#if defined(TARGET_WIN32)
	CRITICAL_SECTION	cs;
#endif
#if defined(TARGET_HPUX)
	static pthread_mutex_t cs;
#endif
};

#if defined(TARGET_HPUX)
pthread_mutex_t CKeyHolder::cs = PTHREAD_MUTEX_INITIALIZER;
#endif

static CKeyHolder	g_keyHolder;

#endif /* !defined(TARGET_MVS) */

/*
 ***********************************************************************
 *                         Internal Prototypes                         *
 ***********************************************************************
 */
static void Encrypt( const MTVBF* pBF, uint32 auiData[2] );
static void Decrypt( const MTVBF* pBF, uint32 auiData[2] );
static void get64( const unsigned char* pucData, uint32 puiData[2] );
static void put64( unsigned char* pucData, const uint32 puiData[2] );

#ifndef EXCLUDE_BF_CREATE
#undef  MAKE_KEY
#else
#ifdef  WIN32
#ifdef  _DEBUG
#define MAKE_KEY
#endif  /* def WIN32 */
#endif  /* def _DEBUG */
#endif  /* ndef EXCLUDE_BF_CREATE */

#ifdef  MAKE_KEY
static void MakeKey( MTVBF* pBF, const uchar* pucKey, size_t nKey );
#endif  /* def MAKE_KEY */

/*
 ***********************************************************************
 *                            Module Code                              *
 ***********************************************************************
 */

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           MtvBF_Create()
 *
 *  DESCRIPTION:        Create a set of p-boxes and s-boxes for the
 *                      given key.  The key may be from 0 to 56 bytes
 *                      (0 to 448 bits).  Return a pointer to the
 *                      caller which opaquely describes the p-boxes
 *                      and s-boxes.
 *
 *  INPUT PARAMETERS:   pucKey: private key
 *                      nKey:   private key length
 *                      ppBF:   output pointer to initalized p-boxes and
 *                              s-boxes
 *
 *  RETURN VALUE:       MTVBF_OKAY       if all went well
 *                      MTVBF_INVALIDARG an invalid argument
 *                      MTVBF_NOMEMORY   if no memory available for
 *                                       initialization
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
extern int MtvBF_Create( const unsigned char* pucKey,
                         size_t nKey,
                         MTVBF** ppBF )
{
    int iRet = MTVBF_OKAY;

    if ( 0 == ppBF )
    {
        iRet = MTVBF_INVALIDARG;
    }
    else
    {
        MTVBF*  pBF = (MTVBF*) malloc( sizeof(MTVBF) );
        if ( 0 == pBF )
        {
            iRet = MTVBF_NOMEMORY;
        }
        else
        {
            pBF->m_uiDogTagS = BF_DOGTAG_S;
            pBF->m_uiDogTagE = BF_DOGTAG_E;
            pBF->m_auiChain[0] = 0;
            pBF->m_auiChain[1] = 0;

#ifndef EXCLUDE_METAVANCE
            if ( nKey == _countof(aucMtvKey448)
                 && 0 == memcmp( pucKey, aucMtvKey448, nKey ) )
            {
                memcpy( pBF->m_auiP,
                        auiInitP_Mtv448,
                        sizeof(auiInitP_Mtv448) );
                memcpy( pBF->m_auiS,
                        auiInitS_Mtv448,
                        sizeof(auiInitS_Mtv448) );
            }
            else if ( nKey == _countof(aucMtvKey40)
                      && 0 == memcmp( pucKey, aucMtvKey40, nKey ) )
            {
                memcpy( pBF->m_auiP,
                        auiInitP_Mtv40,
                        sizeof(auiInitP_Mtv40) );
                memcpy( pBF->m_auiS,
                        auiInitS_Mtv40,
                        sizeof(auiInitS_Mtv40) );
            }
			else if ( nKey == _countof(aucMtvKey128)
                      && 0 == memcmp( pucKey, aucMtvKey128, nKey ) )
            {
                memcpy( pBF->m_auiP,
                        auiInitP_Mtv128,
                        sizeof(auiInitP_Mtv128) );
                memcpy( pBF->m_auiS,
                        auiInitS_Mtv128,
                        sizeof(auiInitS_Mtv128) );
            }
            else
#ifdef EXCLUDE_BF_CREATE
            {
                iRet = MTVBF_CANNOT_INIT;
                free( pBF );
                pBF = 0;
            }
#endif  /* def EXCLUDE_BF_CREATE */
#endif  /* ndef EXCLUDE_METAVANCE */

#ifndef EXCLUDE_BF_CREATE
            {
                memcpy( pBF->m_auiP, auiInitP, sizeof(auiInitP) );
                memcpy( pBF->m_auiS, auiInitS, sizeof(auiInitS) );

                MakeKey( pBF, pucKey, nKey );
            }
#endif  /* ndef EXCLUDE_BF_CREATE */

#ifdef  EXCLUDE_METAVANCE
#ifdef  EXCLUDE_BF_CREATE

            iRet = MTVBF_CANNOT_INIT;
            free( pBF );
            pBF = 0;

#endif  /* def EXCLUDE_METAVANCE */
#endif  /* def EXCLUDE_BF_CREATE */

            /* The caller needs the initialized P-boxes and
            S-boxes to call Encipher() and Decipher() */
            *ppBF = pBF;
        }
    }

    return iRet;
}

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           MtvBF_Encipher()
 *
 *  DESCRIPTION:        Encrypt a block of data using the pre-created
 *                      P-boxes and S-boxes.  The data buffer must
 *                      be a multiple of 8 bytes (64-bits) in length.
 *
 *  INPUT PARAMETERS:   pBF:    initialized p-boxes and s-boxes
 *                      pucIn:  input buffer -- length is nBuf
 *                      pucOut: output buffer -- length is nBuf
 *                      nBuf:   buffer length
 *                      iMode:  encryption mode
 *
 *  RETURN VALUE:       MTVBF_OKAY       if all went well
 *                      MTVBF_INVALIDARG an invalid argument
 *                      MTVBF_BAD_BUFFER_SIZE buffer is not a multiple
 *                      of 8 bytes
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
extern int MtvBF_Encipher( const MTVBF* pBF,
						   unsigned char aucChain[8],
                           const unsigned char* pucIn,
                           unsigned char* pucOut,
                           size_t nBuf,
                           int iMode )
{
    int     iRet    = MTVBF_OKAY;
    uint32  auiData[2];
	uint32	auiChain[2];

    if ( 0 == pBF
        || ( BF_DOGTAG_S != pBF->m_uiDogTagS )
        || ( BF_DOGTAG_E != pBF->m_uiDogTagE )
        || ! (MTVBF_MODE_ECB == iMode
             || MTVBF_MODE_CBC == iMode
             || MTVBF_MODE_CFB == iMode ) )
    {
        iRet = MTVBF_INVALIDARG;
    }
    else if ( 0 != (nBuf % 8) )
    {
        iRet = MTVBF_BAD_BUFFER_SIZE;
    }
    else
    {
		memcpy(auiChain, aucChain, sizeof(auiChain));

        if ( MTVBF_MODE_CBC == iMode )
        {
            /* In CBC mode a cipher text block is obtained by first
               XOR-ing the plain text block with the previous
               cipher text block and encrypting the resulting value.
            */

            for ( ; nBuf >= 8; nBuf -= 8 )
            {
                get64( pucIn, auiData );
                pucIn += sizeof(uint32) + sizeof(uint32);

                auiData[0] ^= auiChain[0];
                auiData[1] ^= auiChain[1];

                Encrypt( pBF, auiData );

                put64( pucOut, auiData );
                pucOut += sizeof(uint32) + sizeof(uint32);

                auiChain[0] = auiData[0];
                auiChain[1] = auiData[1];
            }
        }
        else if ( MTVBF_MODE_CFB == iMode )
        {
            /* In CFB mode a cipher text block is obtained by 
               encrypting the previous cipher text block and XOR-ing
               the resulting value with the plain text.
            */
            for ( ; nBuf >= 8; nBuf -= 8 )
            {
                Encrypt( pBF, auiChain );

                get64( pucIn, auiData );
                pucIn += sizeof(uint32) + sizeof(uint32);

                auiChain[0] ^= auiData[0];
                auiChain[1] ^= auiData[1];

                put64( pucOut, auiChain );
                pucOut += sizeof(uint32) + sizeof(uint32);
            }
        }
        else
        {
            /* ECB mode -- no chaining */
            for ( ; nBuf >= 8; nBuf -= 8 )
            {
                get64( pucIn, auiData );
                pucIn += sizeof(uint32) + sizeof(uint32);

                Encrypt( pBF, auiData );

                put64( pucOut, auiData );
                pucOut += sizeof(uint32) + sizeof(uint32);
            }
        }
		memcpy(aucChain, auiChain, sizeof(auiChain));
    }

    return iRet;
}

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           MtvBF_Decipher()
 *
 *  DESCRIPTION:        Decrypt a block of data using the pre-created
 *                      P-boxes and S-boxes.  The data buffer must
 *                      be a multiple of 8 bytes (64-bits) in length.
 *
 *  INPUT PARAMETERS:   pBF:    initialized p-boxes and s-boxes
 *                      pucIn:  input buffer -- length is nBuf
 *                      pucOut: output buffer -- length is nBuf
 *                      nBuf:   buffer length
 *                      iMode:  encryption mode
 *
 *  RETURN VALUE:       MTVBF_OKAY       if all went well
 *                      MTVBF_INVALIDARG an invalid argument
 *                      MTVBF_BAD_BUFFER_SIZE buffer is not a multiple
 *                      of 8 bytes
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
extern int MtvBF_Decipher( const MTVBF* pBF,
						   unsigned char aucChain[8],
                           const unsigned char* pucIn,
                           unsigned char* pucOut,
                           size_t nBuf,
                           int iMode )
{
    int     iRet = MTVBF_OKAY;
    uint32  auiData[2];
    uint32  auiNextChain[2];
	uint32	auiChain[2];

    if ( 0 == pBF
        || ( BF_DOGTAG_S != pBF->m_uiDogTagS )
        || ( BF_DOGTAG_E != pBF->m_uiDogTagE )
        || ! (MTVBF_MODE_ECB == iMode
              || MTVBF_MODE_CBC == iMode
              || MTVBF_MODE_CFB == iMode ) )
    {
        iRet = MTVBF_INVALIDARG;
    }
    else if ( 0 != (nBuf % 8) )
    {
        iRet = MTVBF_BAD_BUFFER_SIZE;
    }
    else
    {
		memcpy(auiChain, aucChain, sizeof(auiChain));

        if ( MTVBF_MODE_CBC == iMode )
        {
            /* In CBC mode a plain text block is obtained by first
               decrypting the cipher text and then XOR-ing the
               decrypted block with the previous cipher text block.
            */

            for ( ; nBuf >= 8; nBuf -= 8 )
            {
                get64( pucIn, auiData );
                pucIn += sizeof(uint32) + sizeof(uint32);

                /* We'll need this as is for the next cycle */
                auiNextChain[0] = auiData[0];
                auiNextChain[1] = auiData[1];

                Decrypt( pBF, auiData );

                auiData[0] ^= auiChain[0];
                auiData[1] ^= auiChain[1];

                put64( pucOut, auiData );
                pucOut += sizeof(uint32) + sizeof(uint32);

                auiChain[0] = auiNextChain[0];
                auiChain[1] = auiNextChain[1];
            }
        }
        else if ( MTVBF_MODE_CFB == iMode )
        {
            /* In CFB mode a plain text block is obtained by 
               encrypting the previous cipher text block and XOR-ing
               the resulting value with the current cipher block.
            */
            for ( ; nBuf >= 8; nBuf -= 8 )
            {
                get64( pucIn, auiData );
                pucIn += sizeof(uint32) + sizeof(uint32);

                auiNextChain[0] = auiData[0];
                auiNextChain[1] = auiData[1];

                Encrypt( pBF, auiChain );
                auiChain[0] ^= auiData[0];
                auiChain[1] ^= auiData[1];

                put64( pucOut, auiChain );
                pucOut += sizeof(uint32) + sizeof(uint32);

                auiChain[0] = auiNextChain[0];
                auiChain[1] = auiNextChain[1];
            }
        }
        else
        {
            /* ECB mode does not use chaining */
            for ( ; nBuf >= 8; nBuf -= 8 )
            {
                get64( pucIn, auiData );
                pucIn += sizeof(uint32) + sizeof(uint32);

                Decrypt( pBF, auiData );

                put64( pucOut, auiData );
                pucOut += sizeof(uint32) + sizeof(uint32);
            }
        }
		memcpy(aucChain, auiChain, sizeof(aucChain));
    }

    return iRet;
}

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           MtvBF_Destroy()
 *
 *  DESCRIPTION:        Deallocate a previously allocated set of P-boxes
 *                      S-boxes.
 *
 *  INPUT PARAMETERS:   pBF:    initialized p-boxes and s-boxes
 *
 *  RETURN VALUE:       MTVBF_OKAY       if all went well
 *                      MTVBF_INVALIDARG an invalid argument
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
extern int MtvBF_Destroy( MTVBF** ppBF )
{
    int iRet = MTVBF_OKAY;

    if ( 0 == ppBF
        || 0 == *ppBF
        || ( BF_DOGTAG_S != (*ppBF)->m_uiDogTagS )
        || ( BF_DOGTAG_E != (*ppBF)->m_uiDogTagE ) )
    {
        iRet = MTVBF_INVALIDARG;
    }
    else
    {
        free( *ppBF );
        *ppBF = 0;
    }

    return iRet;
}

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           MtvBF_GetChain()
 *
 *  DESCRIPTION:        Obtain current 64-bit chain value.
 *
 *  INPUT PARAMETERS:   pBF:        initialized p-boxes and s-boxes
 *                      aucChain:   output chain value
 *
 *  RETURN VALUE:       MTVBF_OKAY       if all went well
 *                      MTVBF_INVALIDARG an invalid argument
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
/*
extern int MtvBF_GetChain( MTVBF* pBF, unsigned char aucChain[8] )
{
    int iRet = MTVBF_OKAY;

    if ( 0 == pBF
        || 0 == aucChain
        || ( BF_DOGTAG_S != pBF->m_uiDogTagS )
        || ( BF_DOGTAG_E != pBF->m_uiDogTagE ) )
    {
        iRet = MTVBF_INVALIDARG;
    }
    else
    {
        put64( aucChain, pBF->m_auiChain );
    }

    return iRet;
}
*/

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           MtvBF_SetChain()
 *
 *  DESCRIPTION:        Set current 64-bit chain value.
 *
 *  INPUT PARAMETERS:   pBF:        initialized p-boxes and s-boxes
 *                      aucChain:   input chain value
 *
 *  RETURN VALUE:       MTVBF_OKAY       if all went well
 *                      MTVBF_INVALIDARG an invalid argument
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
/*
extern int MtvBF_SetChain( MTVBF* pBF, unsigned char aucChain[8] )
{
    int iRet = MTVBF_OKAY;

    if ( 0 == pBF
        || 0 == aucChain
        || ( BF_DOGTAG_S != pBF->m_uiDogTagS )
        || ( BF_DOGTAG_E != pBF->m_uiDogTagE ) )
    {
        iRet = MTVBF_INVALIDARG;
    }
    else
    {
        get64( aucChain, pBF->m_auiChain );
    }

    return iRet;
}
*/

/*
 ***********************************************************************
 *                          Local Functions                            *
 ***********************************************************************
 */

/* Split a 32-bit value into 4 8-bit parts */
#define a(xL)   ( ( xL >> 24 ) & 0xFF )
#define b(xL)   ( ( xL >> 16 ) & 0xFF )
#define c(xL)   ( ( xL >>  8 ) & 0xFF )
#define d(xL)   ( ( xL       ) & 0xFF )

/* Function F() -- note is differs from the description in the Blowfish
publication as the "mod (2^32)" portions have been omitted as platforms
thus far tested use a 32-bit unsigned integer rather than a 64-bit
unsigned integer. 2^32 = 0x100000000 */
#define F(xL) \
((((S1[a(xL)]) + S2[b(xL)]) ^ S3[c(xL)]) + S4[d(xL)])

/* Define one of the 16 rounds for encryption or decryption */
#define ROUND(n, xL, xR) \
    xL = xL ^ P[n]; \
    xR = F(xL) ^ xR

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           Encrypt()
 *
 *  DESCRIPTION:        Given a set of P-boxes and S-boxes, encrypt 64
 *                      bits of data.
 *
 *  INPUT PARAMETERS:   pBF:        initialized p-boxes and s-boxes
 *                      auiData:    data to encrypt
 *
 *  RETURN VALUE:       none
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
static void Encrypt( const MTVBF* pBF, uint32 auiData[2] )
{
#define uiLeft  auiData[0]
#define uiRight auiData[1]

    const uint32* P       = pBF->m_auiP;
    const uint32* S1      = pBF->m_auiS[0];
    const uint32* S2      = pBF->m_auiS[1];
    const uint32* S3      = pBF->m_auiS[2];
    const uint32* S4      = pBF->m_auiS[3];
    uint32  uiSwap;

    ROUND(  0, uiLeft, uiRight );
    ROUND(  1, uiRight, uiLeft );
    ROUND(  2, uiLeft, uiRight );
    ROUND(  3, uiRight, uiLeft );
    ROUND(  4, uiLeft, uiRight );
    ROUND(  5, uiRight, uiLeft );
    ROUND(  6, uiLeft, uiRight );
    ROUND(  7, uiRight, uiLeft );
    ROUND(  8, uiLeft, uiRight );
    ROUND(  9, uiRight, uiLeft );
    ROUND( 10, uiLeft, uiRight );
    ROUND( 11, uiRight, uiLeft );
    ROUND( 12, uiLeft, uiRight );
    ROUND( 13, uiRight, uiLeft );
    ROUND( 14, uiLeft, uiRight );
    ROUND( 15, uiRight, uiLeft );

    uiSwap = uiLeft;
    uiLeft = uiRight;
    uiRight = uiSwap;

    uiRight ^= P[16];
    uiLeft  ^= P[17];

#undef uiLeft
#undef uiRight
}

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           Decrypt()
 *
 *  DESCRIPTION:        Given a set of P-boxes and S-boxes, decrypt 64
 *                      bits of data.
 *
 *  INPUT PARAMETERS:   pBF:        initialized p-boxes and s-boxes
 *                      auiData:    data to encrypt
 *
 *  RETURN VALUE:       none
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
static void Decrypt( const MTVBF* pBF, uint32 auiData[2] )
{
#define uiLeft  auiData[0]
#define uiRight auiData[1]

    const uint32* P       = pBF->m_auiP;
    const uint32* S1      = pBF->m_auiS[0];
    const uint32* S2      = pBF->m_auiS[1];
    const uint32* S3      = pBF->m_auiS[2];
    const uint32* S4      = pBF->m_auiS[3];
    uint32  uiSwap;

    ROUND( 17, uiLeft, uiRight );
    ROUND( 16, uiRight, uiLeft );
    ROUND( 15, uiLeft, uiRight );
    ROUND( 14, uiRight, uiLeft );
    ROUND( 13, uiLeft, uiRight );
    ROUND( 12, uiRight, uiLeft );
    ROUND( 11, uiLeft, uiRight );
    ROUND( 10, uiRight, uiLeft );
    ROUND(  9, uiLeft, uiRight );
    ROUND(  8, uiRight, uiLeft );
    ROUND(  7, uiLeft, uiRight );
    ROUND(  6, uiRight, uiLeft );
    ROUND(  5, uiLeft, uiRight );
    ROUND(  4, uiRight, uiLeft );
    ROUND(  3, uiLeft, uiRight );
    ROUND(  2, uiRight, uiLeft );

    uiSwap = uiLeft;
    uiLeft = uiRight;
    uiRight = uiSwap;

    uiRight ^= P[1];
    uiLeft  ^= P[0];

#undef uiLeft
#undef uiRight
}

#undef a
#undef b
#undef c
#undef d
#undef F
#undef ROUND

#define GET32(p) \
    ( ((uchar*)p)[0] << 24 ) | \
    ( ((uchar*)p)[1] << 16 ) | \
    ( ((uchar*)p)[2] <<  8 ) | \
    ( ((uchar*)p)[3] )

#define PUT32(p, v) \
    ( ((uchar*)p)[0] = (uchar)( ( v >> 24 ) & 0x0FF ) ); \
    ( ((uchar*)p)[1] = (uchar)( ( v >> 16 ) & 0x0FF ) ); \
    ( ((uchar*)p)[2] = (uchar)( ( v >>  8 ) & 0x0FF ) ); \
    ( ((uchar*)p)[3] = (uchar)( ( v       ) & 0x0FF ) );

#ifdef  BIG_ENDIAN
/* BB 05-05-09 modified to work with HP_UX Itanium */
/* #ifndef HP9000 */
#if !defined(HP9000) && !defined(HPia64) && !defined(HPIA64)


/* On MVS use word moves */
#undef GET32
#undef PUT32

#define GET32(p) \
    *((uint32*)(p))
#define PUT32(p, v) \
    *((uint32*)(p)) = v

#endif  /* def HP9000 && HPia64 && HPIA64 */
#endif  /* def BIG_ENDIAN */

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           get64()
 *
 *  DESCRIPTION:        Get 64 bits of data from a buffer into two machine
 *                      words.  Data is loaded in byte order.
 *
 *  INPUT PARAMETERS:   pucData:    data buffer
 *                      puiData:    32-bit machine representative data
 *                                  words.
 *
 *  RETURN VALUE:       none
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
static void get64( const unsigned char* pucData, uint32 puiData[2] )
{
#ifdef  _MSC_VER
#if defined(_M_IX86)

    /* Intel is little-endian.  Load in byte order */
    __asm
    {
        mov edi, puiData
        xor eax,eax
        mov ebx, pucData
        mov ah, byte ptr [ebx+0]
        mov al, byte ptr [ebx+1]
        shl eax, 16
        mov ah, byte ptr [ebx+2]
        mov al, byte ptr [ebx+3]
        stosd
        xor eax,eax
        mov ah, byte ptr [ebx+4]
        mov al, byte ptr [ebx+5]
        shl eax, 16
        mov ah, byte ptr [ebx+6]
        mov al, byte ptr [ebx+7]
        stosd
    }
#else   /* defined(_M_IX86) */

    puiData[0] = GET32( pucData + 0 );
    puiData[1] = GET32( pucData + 4 );

#endif  /* defined(_M_IX86) */

#else   /* def _MSC_VER */

    puiData[0] = GET32( pucData + 0 );
    puiData[1] = GET32( pucData + 4 );

#endif  /* def _MSC_VER */
}

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           put64()
 *
 *  DESCRIPTION:        Save 64 bits of data into a buffer from two machine
 *                      words.  Data is saved in byte order.
 *
 *  INPUT PARAMETERS:   pucData:    data buffer
 *                      puiData:    32-bit machine representative data
 *                                  words.
 *
 *  RETURN VALUE:       none
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
static void put64( unsigned char* pucData, const uint32 puiData[2] )
{
#ifdef  _MSC_VER
#if defined(_M_IX86)

    /* Intel is little-endian.  Save in byte order */
    __asm
    {
        mov ebx, pucData
        mov esi, puiData
        lodsd
        mov ecx,eax
        shr eax, 16
        mov byte ptr [ebx+0], ah
        mov byte ptr [ebx+1], al
        mov eax, ecx
        mov byte ptr [ebx+2], ah
        mov byte ptr [ebx+3], al
        lodsd
        mov ecx,eax
        shr eax, 16
        mov byte ptr [ebx+4], ah
        mov byte ptr [ebx+5], al
        mov eax, ecx
        mov byte ptr [ebx+6], ah
        mov byte ptr [ebx+7], al
    }

#else   /* defined(_M_IX86) */

    PUT32( pucData + 0, puiData[0] );
    PUT32( pucData + 4, puiData[1] );

#endif  /* defined(_M_IX86) */

#else   /* def _MSC_VER */

    PUT32( pucData + 0, puiData[0] );
    PUT32( pucData + 4, puiData[1] );

#endif  /* def _MSC_VER */
}

#ifdef  MAKE_KEY

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           MakeKey()
 *
 *  DESCRIPTION:        Given a set of p- and s-boxes with an initial
 *                      set of random data, encrypt the p- and s-boxes
 *                      with the given key to create an application
 *                      level key.
 *
 *  INPUT PARAMETERS:   pBF:    pointer to initialized p- and s-boxes
 *                      pucKey: user key
 *                      nKey:   length of user key
 *
 *  RETURN VALUE:       none
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
#include "mtvbfk.h"
extern "C" void TestMakeKey(void)
{
	MTVBF	bf;
	memcpy(bf.m_auiP, auiInitP, sizeof(auiInitP));
	memcpy(bf.m_auiS[0], auiInitS[0], sizeof(auiInitS[0]));
	memcpy(bf.m_auiS[1], auiInitS[1], sizeof(auiInitS[1]));
	memcpy(bf.m_auiS[2], auiInitS[2], sizeof(auiInitS[2]));
	memcpy(bf.m_auiS[3], auiInitS[3], sizeof(auiInitS[3]));

	MakeKey(&bf, aucMtvKey40, _countof(aucMtvKey40));
}

static void MakeKey( MTVBF* pBF, const uchar* pucKey, size_t nKey )
{
    int             i;
    size_t          j;
    int             k;
    unsigned int    x;
    uint32          auiNullString[2];

    /* User keys of more than 448 bits are fruitless */
    if ( nKey > 56 )
    {
        nKey = 56;
    }

    /* Repeatedly cycle through the key bits until all the
    P-boxes have been XORed with key bits */
    j = 0;
    for ( i = 0; i < _countof(pBF->m_auiP); i++ )
    {
        x = 0;

        /* Collect 32 bits from the key */
        for ( k = sizeof(uint32); k--; )
        {
            x = ( x << 8) | pucKey[j];
            j++;
            if ( j >= nKey )
            {
                /* All bytes used, so restart at the
                beginning */
                j = 0;
            }
        }

        /* Permute this p-box */
        pBF->m_auiP[i] = pBF->m_auiP[i] ^ x;
    }

    /* Encrypt a null string with the P-boxes and
    S-boxes as they stand now.  Replace P[0] and
    P[1] with the encrypted result.  Continue
    through the entire set of P-boxes. */
    auiNullString[0] = 0;
    auiNullString[1] = 0;

    for ( i = 0; i < _countof(pBF->m_auiP); )
    {
        Encrypt( pBF, auiNullString );

        pBF->m_auiP[i++] = auiNullString[0];
        pBF->m_auiP[i++] = auiNullString[1];
    }

    /* Encrypt the last 64-bits of the P-boxes.  Use that
    value to replace the first two S-boxes.  Re-encrypt the
    value and use it to replace the next two S-boxes.  Continue
    through the entire set of S-boxes */
    for ( j = 0; j < _countof(pBF->m_auiS); j++)
    {
        for ( k = 0; k < _countof(pBF->m_auiS[j]); )
        {
            Encrypt( pBF, auiNullString );
            pBF->m_auiS[j][k++] = auiNullString[0];
            pBF->m_auiS[j][k++] = auiNullString[1];
        }
    }
}

#endif /* def MAKE_KEY */

#ifdef  METAVANCE_HELPERS

/*
 ***********************************************************************
 * Static Data                                                         *
 ***********************************************************************
 */

/*
 ***********************************************************************
 *                            Module Code                              *
 ***********************************************************************
 */

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           MTVBFCGE()
 *
 *  DESCRIPTION:        Encrypt a buffer in place.
 *
 *  INPUT PARAMETERS:   pucMsgIn: data buffer
 *                      pnLen:    data length (in / out)
 *                      nMax:     buffer capacity
 *
 *  RETURN VALUE:       0       if all went well
 *                      -1      if encryption failed for any reason
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
extern int MTVBFCGE( unsigned char* pucMsgIn,
                     size_t* pnLen,
                     size_t nMax )
{
    int             iRet = 0;
    size_t          nBuffer;
    unsigned char   aucChain[8];
    const MTVBF*    pBF_Key = 0;

    /* Buffer size must be a multiple of 8 */
    nBuffer = (*pnLen + 7) & ~7;
    if ( nBuffer <= nMax )
    {
		/* Get the MetaVance key */
#if defined(TARGET_MVS)
		iRet = MtvBF_Create( METAVANCE_KEY,
			                 _countof(METAVANCE_KEY),
				             &pBF_Key );
#else
		pBF_Key = g_keyHolder.get_Key();
		iRet = (NULL != pBF_Key) ? 0 : -1;
#endif

        if ( 0 == iRet )
        {
            memset( aucChain, 0, sizeof(aucChain) );

            iRet = MtvBF_Encipher( pBF_Key,
								   aucChain,
                                   pucMsgIn,
                                   pucMsgIn,
                                   nBuffer,
                                   MTVBF_MODE_CBC );
            if ( MTVBF_OKAY == iRet )
            {
                iRet = 0;
                *pnLen = nBuffer;
            }
            else
            {
                iRet = -1;
            }
        }
    }
    else
    {
        /* Cannot encrypt this buffer . . . to small! */
        iRet = -1;
    }

#ifdef  TARGET_MVS
    if ( 0 != pBF_Key )
    {
        MtvBF_Destroy( &pBF_Key );
    }
#endif

    return iRet;
}

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           MTVBFCGD()
 *
 *  DESCRIPTION:        Decrypt a buffer in place.
 *
 *  INPUT PARAMETERS:   pucMsgIn: data buffer
 *                      pnLen:    data length (in / out)
 *                      nMax:     buffer capacity
 *
 *  RETURN VALUE:       0       if all went well
 *                      -1      if encryption failed for any reason
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/
extern int MTVBFCGD( unsigned char* pucMsgIn, size_t nLen )
{
    int             iRet = 0;
    unsigned char   aucChain[8];
    const MTVBF*    pBF_Key = 0;

	/* Get the MetaVance key */
#if defined(TARGET_MVS)
	iRet = MtvBF_Create( METAVANCE_KEY,
		                 _countof(METAVANCE_KEY),
			             &pBF_Key );
#else
	pBF_Key = g_keyHolder.get_Key();
	iRet = (NULL != pBF_Key) ? 0 : -1;
#endif

    if ( 0 == iRet )
    {
        memset( aucChain, 0, sizeof(aucChain) );

        iRet = MtvBF_Decipher( pBF_Key,
			                   aucChain,
                               pucMsgIn,
                               pucMsgIn,
                               nLen,
                               MTVBF_MODE_CBC );
        iRet = (MTVBF_OKAY == iRet) ? 0 : -1;
    }

#ifdef  TARGET_MVS
    if ( 0 != pBF_Key )
    {
        MtvBF_Destroy( &pBF_Key );
    }
#endif

    return iRet;
}

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           IsEncryptOff()
 *
 *  DESCRIPTION:        Check if environment variable MTV_ENCRYPTION_ON
 *                      is set to false
 *
 *  INPUT PARAMETERS:   none
 *
 *  RETURN VALUE:       0       encryption is on
 *                      1       encryption is off
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/

extern "C" int IsEncryptOff()
{
    static int encryptOff = -1;
    if( encryptOff < 0 )
    {
        if( const char* env = getenv( "MTV_ENCRYPTION_ON" ) )
            encryptOff = strcmp( env, "false" ) ? 0 : 1;
        else
            encryptOff = 0;
    }
    return encryptOff;
}

/*+
 ***********************!***********************************************
 *
 *  FUNCTION:           GetMTVKey()
 *
 *  DESCRIPTION:        Return encryotion key and its size based on
 *                      MTV_ENCRYPTION_KEY_SIZE
 *
 *  INPUT PARAMETERS:   none
 *
 *  RETURN VALUE:       (aucMtvKey40, 40)
 *                      (aucMtvKey448, 448)
 *                      (aucMtvKey128, 128) default key
 *
 *  SPECIAL LOGIC:      none
 *
 ***********************************************************************
+*/

std::pair<const unsigned char*, int> GetMTVKey()
{
    static auto key = std::pair<const unsigned char*, int>();
    if( !key.first ) // if not initialized yet
    {
        int keySize = 128;
        if( const char* env = getenv( "MTV_ENCRYPTION_KEY_SIZE" ) )
        {
            keySize = std::atoi(env);
        }

        switch(keySize)
        {
        case 40:  key = std::make_pair(aucMtvKey40, 40); break;
        case 448: key = std::make_pair(aucMtvKey448, 448); break;
        default:  key = std::make_pair(aucMtvKey128, 128); break;
        }
    }
    return key;
}

#endif  /* def METAVANCE_HELPERS */

/*
 ***********************************************************************
 * Helpers and stuff                                                   *
 ***********************************************************************
 */

#ifdef  _DEBUG
#ifdef  _WIN32

#include <rpc.h>
#include <stdio.h>
#include <tchar.h>

extern int DumpKey( MTVBF* pBF, FILE* fout )
{
    int i;
    int j;

    fprintf( fout, "const uint32 auiInitP[18] =\n{\n" );
    for ( i = 0; i < _countof(pBF->m_auiP); )
    {
        fprintf( fout, "    0x%08x,", pBF->m_auiP[i++] );
        fprintf( fout, " 0x%08x",    pBF->m_auiP[i++] );
        if ( i < _countof(pBF->m_auiP) - 2 )
        {
            fprintf( fout, ", 0x%08x",    pBF->m_auiP[i++] );
            fprintf( fout, ", 0x%08x,\n",    pBF->m_auiP[i++] );
        }
    }
    fprintf( fout, "\n};\n\n" );

    fprintf( fout, "const uint32 auiInitS[4][256] =\n{\n" );
    for ( i = 0; i < 4; i++ )
    {
        fprintf( fout, "    {\n    /* %d start */\n", i );

        for ( j = 0; j < 256; j += 4 )
        {
            fprintf( fout, 
                     "        0x%08x, 0x%08x, 0x%08x, 0x%08x",
                     pBF->m_auiS[i][j + 0],
                     pBF->m_auiS[i][j + 1],
                     pBF->m_auiS[i][j + 2],
                     pBF->m_auiS[i][j + 3] );
            fprintf( fout,
                     "%s\n",
                     (j < 256) ? "," : "" );
        }

        fprintf( fout,
                 "    /* %d end */\n    }%s\n",
                 i,
                 (3 == i) ? "" : "," );
    }
    fprintf( fout, "};\n\n" );

    return 0;
}

extern void CreateBoxes( PTSTR pszKeyFile,
                         PTSTR pszMtv448File,
                         PTSTR pszMtv40File,
						 PTSTR pszMtv128File)
{
#define UUIDWORDS   (sizeof(uuid)/sizeof(uint32))

    MTVBF*      pBF_Hold = 0;
    MTVBF*      pBF = 0;
    UUID        uuid;
    uint32*     puiUuid = 0;
    RPC_STATUS  rpcStatus = 0;
    FILE*       fout = 0;
    int         i = 0;
    int         j = 0;
    int         k = 0;
    int*        piKeyStats = 0;
    int*        pi448Stats = 0;
    int*        pi40Stats = 0;
    BOOL        bRC = FALSE;

    OSVERSIONINFO   ver;
    memset( &ver, 0, sizeof(ver) );
    ver.dwOSVersionInfoSize = sizeof(ver);

    bRC = GetVersionEx( &ver );
    if ( 5 > ver.dwMajorVersion )
    {
        _tprintf( _T("Windows 2000 or greater has a better random ") \
                  _T("number generator available via UuidCreate().\n") \
                  _T("Data generation aborted.  Try it on a ") \
                  _T("Windows 2000 machine!\n\n") );
        return;
    }

    piKeyStats = (int*) malloc( 256 * sizeof(int) );
    pi448Stats = (int*) malloc( 256 * sizeof(int) );
    pi40Stats  = (int*) malloc( 256 * sizeof(int) );

    pBF = (MTVBF*) malloc( sizeof(MTVBF) );
    if ( 0 == pBF || 0 == piKeyStats || 0 == pi448Stats 
         || 0 == pi40Stats )
    {
        _tprintf( _T("%s(%d): No memory\n"), _T(__FILE__), __LINE__ );
        return;
    }
    memset( piKeyStats, 0, 256 * sizeof(int) );
    memset( pi448Stats, 0, 256 * sizeof(int) );
    memset( pi40Stats,  0, 256 * sizeof(int) );

    memset( pBF, 0, sizeof(MTVBF) );
    puiUuid = (uint32*) &uuid;

    k = UUIDWORDS;
    for ( i = 0; i < _countof(pBF->m_auiP); i++ )
    {
        if ( k >= UUIDWORDS )
        {
            rpcStatus = UuidCreate( &uuid );
            if ( RPC_S_OK != rpcStatus )
            {
                _tprintf( _T("UuidCreate() failed: %d\n"), rpcStatus );
                return;
            }
            k = 0;
        }
        pBF->m_auiP[i] = GET32( &puiUuid[k++] );
    }

    k = UUIDWORDS;
    for ( i = 0; i < 4; i++ )
    {
        for ( j = 0; j < 256; j++ )
        {
            if ( k >= UUIDWORDS )
            {
                rpcStatus = UuidCreate( &uuid );
                if ( RPC_S_OK != rpcStatus )
                {
                    _tprintf( _T("UuidCreate() failed: %d\n"),
                        rpcStatus );
                    return;
                }
                k = 0;
            }

            pBF->m_auiS[i][j] = GET32( &puiUuid[k++] );
        }
    }

    fout = _tfopen( pszKeyFile, _T("w") );
    if ( 0 == fout )
    {
        _tprintf( _T("Cannot open %s: %d\n"), pszKeyFile, errno );
        return;
    }
    DumpKey( pBF, fout );
    fclose( fout );
    fout = 0;

    /* Determine S-box distribution */
    for ( i = 0; i < 4; i++ )
    {
        for ( j = 0; j < 256; j++ )
        {
            uchar*  puc = (uchar*) &pBF->m_auiS[i][j];
            uchar   ch;

            ch = *(puc + 0);
            piKeyStats[ch] += 1;
            ch = *(puc + 1);
            piKeyStats[ch] += 1;
            ch = *(puc + 2);
            piKeyStats[ch] += 1;
            ch = *(puc + 3);
            piKeyStats[ch] += 1;
        }
    }

    pBF_Hold = (MTVBF*) malloc( sizeof(MTVBF) );
    if ( 0 == pBF_Hold )
    {
        _tprintf( _T("%s(%d): No memory\n"), _T(__FILE__), __LINE__ );
    }
    memcpy( pBF_Hold, pBF, sizeof(MTVBF) );

    MakeKey( pBF, aucMtvKey448, sizeof(aucMtvKey448) );
    fout = _tfopen( pszMtv448File, _T("w") );
    if ( 0 == fout )
    {
        _tprintf( _T("Cannot open %s: %d\n"), pszMtv448File, errno );
        return;
    }
    DumpKey( pBF, fout );
    fclose( fout );
    fout = 0;

    memcpy( pBF, pBF_Hold, sizeof(MTVBF) );

    MakeKey( pBF, aucMtvKey40, sizeof(aucMtvKey40) );
    fout = _tfopen( pszMtv40File, _T("w") );
    if ( 0 == fout )
    {
        _tprintf( _T("Cannot open %s: %d\n"), pszMtv40File, errno );
        return;
    }
    DumpKey( pBF, fout );
    fclose( fout );
    fout = 0;

	memcpy( pBF, pBF_Hold, sizeof(MTVBF) );

    MakeKey( pBF, aucMtvKey128, sizeof(aucMtvKey128) );
    fout = _tfopen( pszMtv128File, _T("w") );
    if ( 0 == fout )
    {
        _tprintf( _T("Cannot open %s: %d\n"), pszMtv128File, errno );
        return;
    }
    DumpKey( pBF, fout );
    fclose( fout );
    fout = 0;

    free( pBF );
    free( pBF_Hold );

    /* Dump distributions */
    _tprintf( _T("Raw S-box distribution\nByte\tFrequency\n") );
    for ( i = 0; i < 256; i++ )
    {
        _tprintf( _T("%d\t%d\n"), i, piKeyStats[i] );
    }

    free( piKeyStats );
    free( pi448Stats );
    free( pi40Stats );

#undef  UUIDWORDS
}

#endif  /* def _WIN32 */
#endif  /* def _DEBUG */

