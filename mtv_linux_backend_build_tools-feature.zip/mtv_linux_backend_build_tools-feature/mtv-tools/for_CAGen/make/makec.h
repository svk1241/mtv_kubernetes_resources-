/**********************************************************/
/*   CA Gen                                               */
/*   Copyright (c) 2013 CA. All rights reserved.          */
/**********************************************************/
/* */
/* COMM_VER is set outside of this header */
/*  MML 03/17/05  r7.5 Linux port                         */
/*  MML 08/29/05  14355506 Prevent implicit rules for suffixes*/
/*  RAL 07/31/06  15098020 Remove obsolete env variables  */
/*  RAL 03/14/08  Add back AWK declaratioi                */
/*  RAL 06/01/09  Convert HPia64 to HPIA64                */
/*  RAL 05/20/10  r8.5 Replace RS6000 with IEF_AIX        */
/* */
.SUFFIXES:
TRC    = -DNOTRACE
SNPLOG = -DSNPLOG $(TRC)
MAKE   = make
AWK    = awk
BINDIR = $(IEFH)/bin
OB     = o
/* */
STD_INCL   = -I./ $(COMMON_HEAD_INC) $(SRC_INCL) -I/usr/include -I/usr/include/sys
SRC_INCL   = -I$(IEFH_HEAD) -I$(MTV_TOOLS_DIR)/include -I$(ORA_INCL)
COOP_INCL  = 
C_INCL     = 
VERSION_INCL = -I$(COMMON_VERSION) $(BUILDNO_INC)
/* */
#ifdef IEF_AIX
#include <rs6000.h>
#endif
/* */
#ifdef HPIA64
#include <hpia64.h>
#endif
/* */
#ifdef IEF_SOL
#include <ief_sol.h>
#endif
/* */
#ifdef IEF_LINUX
#include <ief_linux.h>
#endif
/* */
