#!/bin/ksh

AREA=$1

DIRTYPE=`basename ${AREA}`
if [ ${DIRTYPE} = "comp" ]
then
    DIRNAME=`dirname ${AREA}`
    DIRTYPE=`basename ${DIRNAME}`
fi

cat  $BLD_SCRIPT_DIR/mtvinfo.txt | while read line
do
   substring=`echo $line | cut -d,  -f1`
   if [ ${DIRTYPE} = ${substring} ]
   then
       AFG_VERSION=`echo $line | cut -d,  -f10`
   fi
done

export AFG_VERSION_TMP=$AFG_VERSION

