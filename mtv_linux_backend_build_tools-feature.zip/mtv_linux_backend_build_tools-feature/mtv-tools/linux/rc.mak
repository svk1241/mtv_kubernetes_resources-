#############################################################################
#
# rc.mak -- Builds an librc.sl for Composer external action block
#            linkage resolution.
#
#  Requires:	dep		set to Dependency list
#               bld		set to build component list
#               baseDir set to the base of a build area
#
#  Who		When		What    
# -----------------------------------------------------------------------
# Poirier   95????      Initial
# Poirier   980220      Modify for inline build for Composer 4/COOL:Gen 4.a
# Poirier   980316      Documentation
# Poirier   980709      Translate to HPUX
#############################################################################

SHELL  = /bin/ksh

#@echo "This is a test"
#COMPILER_FLAGS= -Aa -c +Z -fast
#LIB_FLAGS= ar -r
#echo $(COMPILER_FLAGS)
#echo $(LOAD_FLAGS)

TMPDIR  = $(BASEDIR)tmp/
#TARGET_LIB = $(BASEDIR)lib/librc.sl
INCDIR  = $(BASEDIR)rc/include
INCDIRC = $(CUSTDIR)rc/include
INCDIR1 = $(IEFH)/src
INCDIR2 = $(IEFH)/include

CC     = gcc
CXX    = $(CC)
CCOPTS = $(COMPILER_FLAGS)
CCMEM  = 
##CCINC = -I$(INCDIR) -I$(INCDIR1)
CCINC  = -I$(INCDIR) -I$(INCDIRC) -I$(INCDIR1) -I$(INCDIR2)

#  CCDEFS    = -DTARGET_HPUX -D_INCLUDE_POSIX_SOURCE
#CCDEFS    = -DTARGET_HPUX -D_INCLUDE_HPUX_SOURCE -D_INCLUDE_XOPEN_SOURCE -D_INCLUDE_POSIX_SOURCE +DAportable
##CCDEFS    = -DTARGET_HPUX  -D_INCLUDE_XOPEN_SOURCE -D_INCLUDE_POSIX_SOURCE +DAportable
CCDEFS    = -DTARGET_LINUX  -D_INCLUDE_XOPEN_SOURCE -D_INCLUDE_POSIX_SOURCE
LD        = $(CC)
LDFLAGS   = 
LIBS      = 
#LIB		  = ar
#LIB_FLAGS = -b -o
LIB_CMD = $(LIB_FLAGS)
OBJEXT    = .o

# ESQL/C support for ORACLE
DB        = ORACLE
SQLPRE    = proc
#  
# THe following line was change because of Oracle cursor with hold.
 # TLB 12/19/2010 SQLOPT    = sqlcheck=syntax mode=oracle oreclen=255 ireclen=255 ltype=none include=$(INCDIR)
 SQLOPT    = sqlcheck=syntax mode=ansi oreclen=255 ireclen=255 ltype=none include=$(INCDIR)

# Inference Rules
.SUFFIXES: $(OBJEXT) .asm .c .C .sqc .lib

.cpp$(OBJEXT):
	$(CC) $(CCOPTS) $(CCDEFS) $(CCMEM) $(CCDEBUG) $(CCINC) -o$*$(OBJEXT) $*.cpp

.c$(OBJEXT):
	$(CC) $(CCOPTS) $(CCDEFS) $(CCMEM) $(CCDEBUG) $(CCINC) -o$*$(OBJEXT) $*.c

.sqc$(OBJEXT):
	$(SQLPRE) $(SQLOPT) iname=$*.sqc oname=$*.c
	$(CC) $(CCOPTS) $(CCDEFS) $(CCDEBUG) $(CCINC) -o$*$(OBJEXT) $*.c
	@rm $*.c > /dev/null

# Targets and dependents
all: $(TARGET_LIB)

include $(DEP)

$(TARGET_LIB):
	$(LIB_CMD) $@ $?


include $(BLD)

# parameters:
#	-@rm $(TARGET_LIB) 2> /dev/null
