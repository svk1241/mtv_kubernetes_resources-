#############################################################################
#
# onlnsl.mak -- Builds a shared library for online super servers
#            linkage resolution.
#
#  Requires:	dep		set to Dependency list
#               bld		set to build component list
#               baseDir set to the base of a build area
#
#  Who		When		What    
# -----------------------------------------------------------------------
#############################################################################

SHELL	  = /bin/ksh
TMPDIR    = $(BASEDIR)tmp/
#TARGET_LIB = $(BASEDIR)lib/libonline.sl
INCDIR    = $(BASEDIR)extrn/include
INCDIR1   = $(IEFH)/src
INCDIR2   = $(IEFH)/include
INCDIR3   = $(ORA_INCL)
#INCDIR4    = /opt/bea/tuxedo8.1/include
#INCDIR5   = $(CC_HOME)/custom/example
#INCDIR6   = $(DRG_HOME)
INCDIR7   = $(MTV_TOOLS_DIR)/include
VPATH     = $(BASEDIR)src

CC        = gcc
ACC       = $(CC)
CXX		  = $(CC)
CCOPTS    = $(CC_OPTS)
ACCOPTS   = ${ACC_OPTS)

CCMEM     = 
#  Following line changed for DRG Grouper
CCINC     = -I$(INCDIR) -I$(INCDIR1) -I$(INCDIR2) -I$(INCDIR3) -I$(INCDIR5) -I$(INCDIR6) -I$(INCDIR7)
#CCINC     = -I$(INCDIR) -I$(INCDIR1) -I$(INCDIR2) -I$(INCDIR3) -I$(INCDIR5)
#  Following line changed for DRG Grouper
#SQLINC     = include=$(INCDIR) include=$(INCDIR1) include=$(INCDIR2) include=$(INCDIR3) include=$(INCDIR5) include=$(INCDIR6) include=$(INCDIR7)
SQLINC     = include=$(INCDIR) include=$(INCDIR1) include=$(INCDIR2) include=$(INCDIR3) include=$(INCDIR7)

#  Following line changed for DRG Grouper
# CCDEFS    = -DUNIX -DTARGET_HPUX -D_INCLUDE_HPUX_SOURCE -D_INCLUDE_XOPEN_SOURCE -D_INCLUDE_POSIX_SOURCE +DAportable
CCDEFS    = $(CC_DEFS)
ACCDEFS   = $(ACC_DEFS)

LD        = $(CC)
LDFLAGS   = 

LIBS      = 
LIB		  = $(CC)
#BB 07/17/08 Removed the following line, because it is now set in MakeEab.mak
#LIB_FLAGS = -b   -L/usr/lib -l mqic -o
#good 01/11/2007 LIB_FLAGS = +s -b -L/opt/sna/lib -l mgr -l csv -l appc -o 
OBJEXT    = .o

# ESQL/C support for ORACLE
DB        = ORACLE
SQLPRE    = proc
#  
# THe following line was change because of Oracle cursor with hold.
#TLB 12/20/2010 SQLOPT    = sqlcheck=syntax mode=oracle oreclen=255 ireclen=255 ltype=none $(SQLINC) define=ORACLE
 SQLOPT    = sqlcheck=syntax mode=ansi oreclen=255 ireclen=255 ltype=none $(SQLINC) define=ORACLE

# Targets and dependents
all: parameters $(TARGET_LIB) 

include $(DEP)

$(TARGET_LIB):
	@echo "Build is $(BLD)"
	$(LIB) $(LIB_FLAGS) $@ $?

include $(BLD)

parameters:
	-@rm $(TARGET_LIB) 2> /dev/null
