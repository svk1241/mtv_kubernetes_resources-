#!/bin/ksh

#JPH INCL

AREA=$1

if [ ! -d ${AREA} ]
then
  echo "$0 -- ${AREA} is not a valid directory"
  exit
fi

   BASE_AREA=$AREA
   CUSTOMER_AREA=$AREA
##   BASE_AREA=`echo $AREA | cut -f1-3 -d"/"`
##   CUSTOMER_AREA=`echo $AREA | cut -f1-3 -d"/"`

   IS_COMP_AREA="0"
   echo $AREA | grep -q comp
   if [ $? = 0 ]
   then
      CONCATFILE=`dirname ${AREA}`
      CONCATFILE=${CONCATFILE}/configs/concat.ini
      IS_COMP_AREA="1"
   else
      CONCATFILE="${AREA}/configs/concat.ini"
   fi

   if [ -f $CONCATFILE ]
   then
      ((line_count=1))
      cat  ${CONCATFILE} | while read line
      do
         if [[ $line_count -eq 1 ]]
         then
	   BASE_AREA=$line
	   if [ "$IS_COMP_AREA" = "1" ]
	   then
	      BASE_AREA=${BASE_AREA}/comp
	   fi
         elif [[ $line_count -eq 2 ]]
         then
	    CUSTOMER_AREA=$line
	    if [ "$IS_COMP_AREA" = "1" ]
	    then
	       CUSTOMER_AREA=${CUSTOMER_AREA}/comp
	    fi
         fi
	 ((line_count += 1))
      done
   fi

export CUSTOMER_AREA_TMP=$CUSTOMER_AREA
export BASE_AREA_TMP=$BASE_AREA

