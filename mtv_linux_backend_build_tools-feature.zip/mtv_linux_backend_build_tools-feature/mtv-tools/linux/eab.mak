#############################################################################
#
# Eab.mak -- Builds an EXTRNC.lib for Composer external action block
#            linkage resolution.
#
#  Requires:	dep		set to Dependency list
#               bld		set to build component list
#               baseDir set to the base of a build area
#
#  Who		When		What    
# -----------------------------------------------------------------------
# Poirier   95????      Initial
# Poirier   980220      Modify for inline build for Composer 4/COOL:Gen 4.a
# Poirier   980316      Documentation
# Poirier   980709      Translate to HPUX
# Barton    061207      Added support for TOPPAPPC.cpp
#############################################################################

SHELL   = /bin/ksh
TMPDIR  = $(BASEDIR)tmp/
#TARGET_LIB = $(BASEDIR)lib/libextrnc.a
INCDIR  = $(BASEDIR)extrn/include
##JPH INCL
INCDIRC = $(CUSTDIR)extrn/include
INCDIR1 = $(IEFH)/src
INCDIR2 = $(IEFH)/include
INCDIR3 = $(MQ_INCL)
#INCDIR4 = /opt/bea/tuxedo11gR1/include
#INCDIR5 = $(CC_HOME)/custom/example
#INCDIR6 = $(DRG_HOME)
INCDIR7 = $(MTV_TOOLS_DIR)/include
INCDIR8 = $(JAVA_INCL)/linux
INCDIR9 = $(JAVA_INCL)
INCDIRS = $(ORA_INCL)

CC        = gcc
ACC       = $(CC)
CXX       = $(CC)
CCOPTS    = $(CC_OPTS)
ACCOPTS   = $(ACC_OPTS)

CCMEM     = 
#  Following line changed for DRG Grouper
CCINC     = -I$(INCDIR) -I$(INCDIRC) -I$(INCDIR1) -I$(INCDIR2) -I$(INCDIR3) -I$(INCDIR7) -I$(INCDIR8) -I$(INCDIR9)
#CCINC     = -I$(INCDIR) -I$(INCDIR1) -I$(INCDIR2) -I$(INCDIR3) -I$(INCDIR5)
#  Following line changed for DRG Grouper
#SQLINC     = include=$(INCDIR) include=$(INCDIR1) include=$(INCDIR2) include=$(INCDIR3) include=$(INCDIR5) include=$(INCDIR6)
SQLINC    = include=$(INCDIR) include=$(INCDIR1) include=$(INCDIR2) include=$(INCDIRS)
#SQLINC     = include=$(INCDIR) include=$(INCDIR1) include=$(INCDIR2) include=$(INCDIR3) include=$(INCDIR5)

#  Following line changed for DRG Grouper
# CCDEFS    = -DUNIX -DTARGET_HPUX -D_INCLUDE_HPUX_SOURCE -D_INCLUDE_XOPEN_SOURCE -D_INCLUDE_POSIX_SOURCE +DAportable
CCDEFS    = $(CC_DEFS)
ACCDEFS   = $(ACC_DEFS)

LD        = $(CC)
LDFLAGS   = 

LIBS      = 
#LIB		  = ld
#BB 07/17/08 Removed the following line, because it is now set in MakeEab.mak
#LIB_FLAGS = -b   -L/usr/lib -l mqic -o
#good 01/11/2007 LIB_FLAGS = +s -b -L/opt/sna/lib -l mgr -l csv -l appc -o 
OBJEXT    = .o

# ESQL/C support for ORACLE
DB        = ORACLE
SQLPRE    = proc
#  
# THe following line was change because of Oracle cursor with hold.
 #TLB 12/19/2010 SQLOPT    = sqlcheck=syntax mode=oracle oreclen=255 ireclen=255 ltype=none $(SQLINC) define=ORACLE
 #TLB 04/03/2104 SQLOPT    = sqlcheck=syntax mode=ansi oreclen=255 ireclen=255 ltype=none $(SQLINC) define=ORACLE
 SQLOPT    = sqlcheck=syntax mode=oracle oreclen=255 ireclen=255 ltype=none $(SQLINC) define=ORACLE

# Inference Rules
.SUFFIXES: $(OBJEXT) .asm .c .C .sqc .lib .cpp

.cpp$(OBJEXT):
	$(ACC) $(ACCOPTS) $(ACCDEFS) $(CCMEM) $(CCDEBUG) $(CCINC) -o$*$(OBJEXT) $*.cpp

.c$(OBJEXT):
	$(CC) $(CCOPTS) $(CCDEFS) $(CCMEM) $(CCDEBUG) $(CCINC) -o$*$(OBJEXT) $*.c

.sqc$(OBJEXT):
	$(SQLPRE) $(SQLOPT) iname=$*.sqc oname=$*.c
	$(CC) $(CCOPTS) $(CCDEFS) $(CCDEBUG) $(CCINC) -o$*$(OBJEXT) $*.c
	@rm $*.c  > /dev/null

# Targets and dependents
all: parameters $(TARGET_LIB)

include $(DEP)

$(TARGET_LIB):
	@echo -e "!!!!! Build is $(BLD) !!!!!"
	$(LIB_FLAGS) $@ $?


include $(BLD)

parameters:
	-@rm $(TARGET_LIB) 2> /dev/null
