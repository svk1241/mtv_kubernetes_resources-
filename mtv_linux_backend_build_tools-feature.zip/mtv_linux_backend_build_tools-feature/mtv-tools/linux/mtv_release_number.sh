#!/bin/ksh

#######################################################################
### This shell will have two options for input parameters
##    1.) Take in an an {$AREAA) using the -a (area) option
##     -a /mtv/m290 and get the number associated with the release,
##    or
##    2.) Take in a user id with the -i option (-i tuxa28a) and
##    get the appropriate $DOM_TOP ($AREAA) to compute the release number.
##
##  The release number will be set in a environment variable - MTV_TMP_RELEASE
##     
##         ${AREA}   - $MTV_TMP_RELEASE 
##     ex  /mtv/m290 - 290
##     ex  /mtv/m28a - 280
##     ex  /mtv/m210 - 291    for the new 2.10 release we will add the last 2 
##                            digit (1+0) to 290, giving us 291
##     ex  /mtv/m21a - 291.5  for the new 2.1a release we will add the second 
##                            digit (1) plus (.5) to 290, giving us 291.5
#############################################################################

#############################################################################
# If no parameters are entered this section will display errors and stop
# processing.
#############################################################################
usage()
{
      echo "\n ... Directory sturcture (ex: /mtv/m290) must be entered using the -a param"
      echo "\n ... User Id must be entered (ex:tuxa28a) using the -i param"
      exit
}

optstr=":A:a:I:i:"
#get the command line options

opt=""
#unset $OPTARG
OPTIND=0

while getopts $optstr opt
do
    case $opt in
    A|a)
       AREAA=$OPTARG
       ;;
    I|i)
       USER=$OPTARG
       ;;

    *) usage;;
    esac
done

if [ "$AREAA" ]
then 
   DIRECTORY_LINE=$AREAA
else
    if [ "$USER" ]
    then
       touch /tmp/mtv_tmp_release.txt
       chmod 777 /tmp/mtv_tmp_release.txt

    ## get $DOM_TOP for the user
        su - $USER -c 'RELEASE_AREA=`echo ${DOM_TOP}` ; \
        (print $RELEASE_AREA > /tmp/mtv_tmp_release.txt) '

        cat  /tmp/mtv_tmp_release.txt | read LINE
        if [ -d $LINE ]
        then
            DIRECTORY_LINE=`echo $LINE`
        else
            echo "The user ID you entered $USER does not have a valid DOM_TOP directory"
        fi
        rm /tmp/mtv_tmp_release.txt
    else
        usage
    fi
fi



VAR290=290
SHRT_RELEASE_AREA=$(basename $DIRECTORY_LINE | cut -c2-4)
if [ ${SHRT_RELEASE_AREA} -eq "omp" ]
then
    SHRT_RELEASE_AREA=$(basename $(dirname $DIRECTORY_LINE) | cut -c2-4)
fi
#echo "SHRT_RELEASE_AREA = ${SHRT_RELEASE_AREA}"
#typeset -R1 RIGHT_DIGIT=$SHRT_RELEASE_AREA
RIGHT_DIGIT=$(echo $SHRT_RELEASE_AREA | cut -c3)
echo $RIGHT_DIGIT | grep -E -q "0|1|2|3|4|5|6|7|8|9"
if [ $? = 0 ]
then
##   this is a 3 digit area  - 290, 210
#    typeset -L2 LEFT_TWO=$SHRT_RELEASE_AREA
    LEFT_TWO=$(echo $SHRT_RELEASE_AREA | cut -c1-2)
    if [ "$LEFT_TWO" -eq "21" ]
    then
        THIRD_DIGIT=$(echo $SHRT_RELEASE_AREA | cut -c3)
        SECOND_DIGIT=$(echo $SHRT_RELEASE_AREA | cut -c2)
        SHRT_RELEASE_NUMBER=$(echo $VAR290 $THIRD_DIGIT $SECOND_DIGIT | awk '{print $1 + $2 + $3}')
    else
        SHRT_RELEASE_NUMBER=$SHRT_RELEASE_AREA
    fi
else
##  this is a 2 digit area followed by a letter - 28a, 21a
    LEFT_TWO=$(echo $SHRT_RELEASE_AREA | cut -f1 -d$RIGHT_DIGIT)
    if [ "${LEFT_TWO}" -eq "21" ]
    then
       SECOND_DIGIT=$(echo $SHRT_RELEASE_AREA | cut -c2)
       THIRD_DIGIT=".5"
       SHRT_RELEASE_NUMBER=$(echo $VAR290 $THIRD_DIGIT $SECOND_DIGIT | awk $(print $1 + $2 + $3))
    else
       SHRT_RELEASE_NUMBER=$(LEFT_TWO)0
    fi
fi

export MTV_TMP_RELEASE=$SHRT_RELEASE_NUMBER


