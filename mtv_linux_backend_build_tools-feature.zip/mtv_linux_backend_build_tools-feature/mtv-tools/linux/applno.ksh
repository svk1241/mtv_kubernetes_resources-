#!/bin/ksh
#set -x
#
# CA Gen
# Copyright (c) 2013 CA. All rights reserved.
#
#   Applno.ksh will increment BUILDVERS which will be compiled into the
#   application via the gversion.c source file for load modules, tversion.c
#   source file for Triggers, or cversion.c source file for Opslibs.
#   The file <execunit.MEMBER>_buildver.h will be created and incremented
#   in this script, and can be modified by the customer in order to manage
#   the build version number.
#
#   Parameter 1 is the fully quailified current working directory.  The
#      directory should contain a trailing delimiter.
#
#   Parameter 2 is the execunit MEMBER name
#   
#   Parameter 3 is the execunit Type:
#      lm - Load Module
#      ri - RI Triggers
#      cbd - Opslib
#   
#   Modifications:
#
#   ral  | 08/03/04 | Initial pass for 7.0 release
#   ral  | 10/01/04 | 13709212  Provide directory for temp files as
#                               parameter 1. The directory needs to
#                               be fully qualified with a trailing delim.
#   ral  | 08/26/10 | 19457763  Rewritten to generate
#                               <execunit.MEMBER>_buildver.h file
#

#
#  Display usage when incorrect parameters are provided
#
applno_usage()
{
   echo " "
   echo "----------------------------------------------------------------"
   echo "applno.ksh parameters required:"
   echo "   <model_dir> - fully qualified path of working model directory"
   echo "   <member_name> - Execunit Member name being built"
   echo "   <member_type> - Execunit Member type.  One of:"
   echo "      lm  - Load Module"
   echo "      ri  - RI Triggers"
   echo "      cbd - Ops Library"
   echo "----------------------------------------------------------------"
   echo " "
}

#
#  Define local variables
#
if [ "$1" = "" ]
then
    echo "\nMissing parameter 1 - model directory"
    applno_usage
    exit 1
fi
if [ "$2" = "" ]
then
    echo "\nMissing parameter 2 - MEMBER name"
    applno_usage
    exit 1
fi
if [ "$3" = "" ]
then
    echo "\nMissing parameter 3 - Execunit Type"
    applno_usage
    exit 1
fi
MODEL_DIR=$1
EXECUNIT=$2
EXECUNIT_TYPE=$3
APPLICATION_FILE=${MODEL_DIR}application.h
BUILD_VER_FILE=${MODEL_DIR}${EXECUNIT}_buildver.h

#
#  Determine version source file name based on EXECUNIT_TYPE
#
if [ "$EXECUNIT_TYPE" = "lm" ]
then
   VER_FILE=gversion.c
fi
if [ "$EXECUNIT_TYPE" = "ri" ]
then
   VER_FILE=tversion.c
fi
if [ "$EXECUNIT_TYPE" = "cbd" ]
then
   VER_FILE=oversion.c
fi
VERSION_FILE=${MODEL_DIR}$VER_FILE

#
#  If building a BM/Server load module or CBD/Cascade Library for
#  the 1st time, no *version.c file exists. Create one which will 
#  include the build version header being created along with application.h
#
if [ ! -a $VERSION_FILE ]
then
   echo "/* Copyright (c) 2013 CA. All rights reserved. */" > $VERSION_FILE
   echo "/*" >> $VERSION_FILE
   echo " * This file creates an object with the current time of" >> $VERSION_FILE
   echo " * the compile and an incremented build version number" >> $VERSION_FILE 
   echo " * that appear in a string made visible by the command" >> $VERSION_FILE
   echo " * \"strings <filename> | grep Gen\". This file should be" >> $VERSION_FILE
   echo " * in the same directory as the included files for the" >> $VERSION_FILE
   echo " * double quoted filenames to be found." >> $VERSION_FILE
   echo " */" >> $VERSION_FILE
   echo "#define iuxdb_$EXECUNIT_TYPE" >> $VERSION_FILE
   echo "#include \"application.h\"" >> $VERSION_FILE
   echo "#include \"${EXECUNIT}_buildver.h\"" >> $VERSION_FILE
   echo "char main_iuxdb${EXECUNIT_TYPE}_version[]=CG_WHAT_STRING;" >> $VERSION_FILE
fi

#
#  Extract existing build version
#  If file does not yet exists, skip the extraction
#
VERSION_NUM=0
if [ -a $BUILD_VER_FILE ]
then
   for extraction in `cat $BUILD_VER_FILE | grep "#define BUILDVERS" | cut -f3`
   do
      VERSION_NUM=$extraction
   done

   #
   #  Remove quotes around version_num extracted from file
   #
   VERSION_NUM=`echo $VERSION_NUM | awk -F\" '{print $2}'`
fi

#
#  Increment build version
#
VERSION_NUM=`expr $VERSION_NUM + 1`

#
#  Pad incremented number with 0's
#
VERSION_NUM=`echo $VERSION_NUM | awk '{printf "%05s\n", $1}'`

#
#  Write build version to execunit's buildver file,
#  creating a new version of the file
#
#  If previous version of application.h exists, BUILDVERS
#  may already be present in the file. Handle backward
#  compatibility by undefining BUILDVERS before defining it.
#
echo "/* Copyright (c) 2013 CA. All rights reserved. */" > $BUILD_VER_FILE
echo "#ifdef BUILDVERS" >> $BUILD_VER_FILE
echo "#undef BUILDVERS" >> $BUILD_VER_FILE
echo "#endif" >> $BUILD_VER_FILE
echo "#define BUILDVERS \"$VERSION_NUM\"" >> $BUILD_VER_FILE

