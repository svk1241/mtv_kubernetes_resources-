#!/bin/ksh

# svcbld.cmd <AREA> <remote file name>  <module name>
#
# svcbld.cmd  <area> <remote file name> <module name>
# svcbld.cmd /t07/cert HQ09S00C.rmt HQ09S00C
#
# Parms
#    area - area to be built
#    remote file name -  any file with name ending in rmt
#    module name -  you figure it out.  I am not suppose to know this information.
#
#
# Environment Variables
#       IEFEXT - External Action Block library 
#       IEFH -- IEFAE runtime directory path
#       IEFPLATFORM -- Type of system (HP9000, RS6000, SUN, ...)
#       AEHOME -- Path to where application is to be installed.
#       HANDSOFF -- if 'y' or 'Y', the rmt scripts files are not removed
#
# Copyright 1997, Sterling Software, Inc.
#

FTYPE=""
NODDL="NODDL"

TARDIR=""
IEFPRODUCT=""

#PRODDIR=""
CUSTOMER_AREA=""
BASE_AREA=""
##JPH
NON_COMP_CUST=""
NON_COMP_BASE=""

HOMEDIR=""
EXTLIB=""
EXTCOBLIB=""
EXTCLIB=""
CASLIB=""

#This function checks to see
#if AREA has a concatenation file and
#then sets variabls appropiately based on the
#content
handle_concatenation()
{
   BASE_AREA=$AREA
   CUSTOMER_AREA=$AREA
   IS_COMP_AREA="0"
   echo $AREA | grep -q comp
   if [ $? = 0 ]
   then
      CONCATFILE=`dirname ${AREA}`
      CONCATFILE=${CONCATFILE}/configs/concat.ini
      IS_COMP_AREA="1"
   else
      CONCATFILE="${AREA}/configs/concat.ini"
   fi

   if [ -f $CONCATFILE ]
   then
      ((line_count=1))
      cat  $CONCATFILE | while read line
      do
        if [[ $line_count -eq 1 ]]
        then
           BASE_AREA=$line
           if [ "$IS_COMP_AREA" = "1" ]
           then
              BASE_AREA=${BASE_AREA}/comp
           fi	

        elif [[ $line_count -eq 2 ]]
        then
           CUSTOMER_AREA=$line
           if [ "$IS_COMP_AREA" = "1" ]
           then
              CUSTOMER_AREA=${CUSTOMER_AREA}/comp
           fi
        fi

        ((line_count += 1))
      done
   fi

}

getliblist()
{

   MTV_CUSTOMER_LIB_LIST=""

   if [ "$BASE_AREA" != "$CUSTOMER_AREA" ]
   then

      #Get lib list from AREA/lib
      #and put it in MTV_LIB_LST
      . ${BLD_SCRIPT_DIR}/get-lib-list ${CUSTOMER_AREA}
      ###JPH
      if [ "${IS_COMP_AREA}" = "1" ]
      then
         NON_COMP_CUST=`dirname ${CUSTOMER_AREA}`
         . ${BLD_SCRIPT_DIR}/get-lib-list ${NON_COMP_CUST}
      fi

      MTV_CUSTOMER_LIB_LIST=$MTV_LIB_LST
      MTV_LIB_LST=""
   fi

   . ${BLD_SCRIPT_DIR}/get-lib-list ${BASE_AREA}
   ###JPH
   if [ "${IS_COMP_AREA}" = "1" ]
   then
       NON_COMP_BASE=`dirname ${BASE_AREA}`
       . ${BLD_SCRIPT_DIR}/get-lib-list ${NON_COMP_BASE}
   fi



   if [ "$MTV_CUSTOMER_LIB_LIST" != "" ]
   then
      MTV_LIB_LST="${MTV_CUSTOMER_LIB_LIST} ${MTV_LIB_LST}"
   fi

   if [ "$MTV_LIB_LST" = "" ]
   then
      echo  "The getliblist() function did not find any libraries"
      exit $ERROR_CODE
   fi 

   MTV_LIB_LST="-Wl,--start-group ${MTV_LIB_LST}"
}

RemoveOPLIBreference() 
{

   TMPFILE=/tmp/TMPFILE.${PID}
   if [ -f ${IEFPRODUCT}.icm ]
   then
      grep -v -E 'oplib=|operation=' ${IEFPRODUCT}.icm > ${TMPFILE}
      mv ${TMPFILE} ${IEFPRODUCT}.icm
   else
      grep -v -E 'oplib=|operation=' ${rmtFile} > ${TMPFILE}
      mv ${TMPFILE} $rmtFile
   fi
}

RemoveOPLIB_OtherOPLIBreference() 
{
   PID=$$
   TMPOPFILE=${AREA}/tmp/TMPOPFILE.${PID}
   if [ -f ${IEFPRODUCT}.icm ]
   then
      INFILE=${IEFPRODUCT}.icm
   else
      INFILE=${rmtFile}
   fi
 
   awk -v a=${IEFPRODUCT} '
   {
      FS="="
      if ( $1 ~ "oplib"  && $2 !~ a )
      {
         skip="true";
      }
      if ( $1 ~ "operation" && skip == "true" )
      {
         skip2="true";
      }
      if ( skip != "true" && skip2 != "true" )
      {
         print $0
      }
      else
      {
         if ( skip == "true" && skip2 == "true"  )
         {
            skip="false";
            skip2="false";
         }
      }
   }
   ' ${INFILE} > ${TMPOPFILE}
   dos2unix -n ${TMPOPFILE} ${INFILE}
   rm ${TMPOPFILE}
}

modify_name()
{

   TARGETSTRING1="static void c0000_ietexit(void)"
   grep -q "${TARGETSTRING1}"  ${rmtFileshrt}
   grepret=$?
   if [ ${grepret} -ne 0 ]
   then
      PID=$$

      TMPFILE=/tmp/TMPFILE.${PID}

      TARGETSTRING3=":pstep"

      line3=$(grep -n "${TARGETSTRING3}" ${rmtFileshrt} | tail -1 | sed 's/:.*$//')
      ((line3+=1))

      PSTEP_NAME=`head -${line3} ${rmtFileshrt} | tail -1 | cut -f2 -d"="`

      sed s/PROC_STEP/${PSTEP_NAME}/ < ${BLD_SCRIPT_DIR}/UnixBatchMain.c > ${TMPFILE}

      mv ${TMPFILE} ${AREA}/src/${rmtName}.c
      return
   fi

   PID=$$

   TMPFILE=/tmp/TMPFILE.${PID}

   TARGETSTRING1=":split member=${rmtName} type"

   TARGETSTRING2=":esplit."

   TARGETSTRING3=":pstep"

   line1=$(grep -n "${TARGETSTRING1}" ${rmtFileshrt} | tail -1 | sed 's/:.*$//')

   line2=$(grep -n "${TARGETSTRING2}" ${rmtFileshrt} | head -2 | tail -1 | sed 's/:.*$//')

   line3=$(grep -n "${TARGETSTRING3}" ${rmtFileshrt} | tail -1 | sed 's/:.*$//')
   ((line3+=1))

   PSTEP_NAME=`head -${line3} ${rmtFileshrt} | tail -1 | cut -f2 -d"="`

   head -${line1} ${rmtFileshrt} > ${TMPFILE}

   cat ${BLD_SCRIPT_DIR}/UnixBatchMain.c >> ${TMPFILE}

   echo "\n" >> ${TMPFILE}
   tail +${line2} ${rmtFileshrt} >> ${TMPFILE}

   mv ${TMPFILE} ${rmtFileshrt}

   sed s/PROC_STEP/${PSTEP_NAME}/ < ${rmtFileshrt} > ${TMPFILE}

   mv ${TMPFILE} ${rmtFileshrt}

}

modify_batch_ret_code()
{
   TARGETSTRING1="static void c0000_ietexit(void)"
   grep -q "${TARGETSTRING1}"  ${rmtFileshrt}
   grepret=$?
   if [ ${grepret} -ne 0 ]
   then
      return
   fi 

   NEWSTRING1="int processReturnCode = 0;"

   TARGETSTRING2="return_values->return_tran_sw = appl_list->cics_conv_sw;"

   NEWSTRING2A="if ('A' == globdata->psmgr_rollback_rqsted) "
   NEWSTRING2B="{"
   NEWSTRING2C="      processReturnCode = 42;"
   NEWSTRING2D=" }"

   TARGETSTRING3="TIREXIT(0);"
   NEWSTRING3="TIREXIT(processReturnCode);"


   PID=$$
   TMPFILE=/tmp/TMPFILE.${PID}

   grep -q "${NEWSTRING1}" $rmtFileshrt
   RETCOD_TOTAL=$?

   grep -q "${NEWSTRING2A}" $rmtFileshrt
   ((RETCOD_TOTAL=$RETCOD_TOTAL+$?))

   grep -q "${NEWSTRING2C}" $rmtFileshrt
   ((RETCOD_TOTAL=$RETCOD_TOTAL+$?))

   grep -q "${NEWSTRING3}" $rmtFileshrt
   ((RETCOD_TOTAL=$RETCOD_TOTAL+$?))


   if [ ${RETCOD_TOTAL} -eq 0 ]
   then
      echo "$0 - ${rmtFileshrt} already has the changes"
      #exit
      return
   fi

   #######FIRST GROUP  ############################################
   line1=$(grep -n "${TARGETSTRING1}" ${rmtFileshrt} | tail -1 | sed 's/:.*$//')

   ((line1+=1))

   line2=$(grep -n "${TARGETSTRING2}" ${rmtFileshrt} | tail -1 | sed 's/:.*$//')


   sed -e "${line1}a\\
   ${NEWSTRING1}"  -e "${line2}a\\
   ${NEWSTRING2A}" -e "${line2}a\\
   ${NEWSTRING2B}" -e "${line2}a\\
   ${NEWSTRING2C}" -e "${line2}a\\
   ${NEWSTRING2D}" -e "s/${TARGETSTRING3}/${NEWSTRING3}/g" ${rmtFileshrt} > ${TMPFILE}

   mv ${TMPFILE} ${rmtFileshrt}
  
   TARGETSTRING4="return_values->return_tran_sw = appl_list->cics_conv_sw;"
   NEWSTRING4A="if ( 'N' != globdata->psmgr_exit_msgtype)"
   NEWSTRING4B="{"
   NEWSTRING4C="    printf(\"Exit state message: $s\\\n\", globdata->psmgr_exit_infomsg);"
   NEWSTRING4D="}"

   PID=$$
   TMPFILE=/tmp/TMPFILE.${PID}

   grep -q "${NEWSTRING4A}" $rmtFileshrt
   RETCOD_TOTAL=$?

   grep -q "${NEWSTRING4C}" $rmtFileshrt
   ((RETCOD_TOTAL=$RETCOD_TOTAL+$?))

   if [ ${RETCOD_TOTAL} -eq 0 ]
   then
      echo "$0 - $rmtFileshrt  already has the changes"
      return
   else
     echo "$rmtFileshrt is being changed"
   fi


   #######FIRST GROUP  ############################################
   line1=$(grep -n "${TARGETSTRING4}" ${rmtFileshrt} | tail -1 | sed 's/:.*$//')


   sed -e "${line1}a\\
   ${NEWSTRING4A}" -e "${line1}a\\
   ${NEWSTRING4B}" -e "${line1}a\\
   ${NEWSTRING4C}" -e "${line1}a\\
   ${NEWSTRING4D}"  ${rmtFileshrt} > ${TMPFILE}

   mv ${TMPFILE} ${rmtFileshrt}

}
mainwork()
{

    rmtFile=$1


   rmtFileshrt=`basename ${rmtFile}`


   rmtName=${rmtFileshrt%.rmt}


   DBPCCFLAGS="ireclen=255 oreclen=255 \
               mode=ansi DBMS=V7 release_cursor=no hold_cursor=yes \
               sqlcheck=syntax ltype=none parse=none \
               include=${ORA_INCL} \
               include=${MTV_TOOLS_DIR}/include"

   echo "#Profile Manager " 								>user.$$.profile
   echo "#Wed Mar 09 16:27:54 EST 2005" 						>>user.$$.profile

   echo $$.C.LOC.EXTERNAL_LIB				$EXTLIB 			>>user.$$.profile
   echo $$.C.LOC.OPLIB					$BASE_AREA/lib/			>>user.$$.profile
   echo $$.C.OPT.IEF_BITMAP    				$IEF_BITMAP			>>user.$$.profile
   echo $$.OPTIONS.OPT.DBPCCFLAGS 			$DBPCCFLAGS 			>>user.$$.profile

   echo $$.OPTIONS.OPT.CMD_FORM				$UNIXCMD  			>>user.$$.profile
   echo $$.OPTIONS.OPT.HAS_SQL				YES 				>>user.$$.profile
   echo $$.OPTIONS.OPT.INSTALL_TRANCODES		$TRANCODES 			>>user.$$.profile
   echo $$.OPTIONS.OPT.TE 				AEFAD 				>>user.$$.profile
   echo $$.OPTIONS.OPT.LIBTYPE 				$LIBTYPE			>>user.$$.profile

   echo $$.TARGET.LOC.CODE_EXE				$HOMEDIR/       		>>user.$$.profile
   echo $$.TARGET.LOC.CODE_LIB 				$CUSTOMER_AREA/lib/		>>user.$$.profile
   echo $$.TARGET.LOC.CODE_OBJ 				$CUSTOMER_AREA/obj/ 		>>user.$$.profile
   echo $$.TARGET.LOC.CODE_SRC 				$CUSTOMER_AREA/src/		>>user.$$.profile
   echo $$.TARGET.LOC.INSTALL 				$HOMEDIR/ 			>>user.$$.profile
   echo $$.TARGET.LOC.PROD_OBJ 				$BASE_AREA/obj/			>>user.$$.profile
   echo $$.TARGET.LOC.PROD_SRC 				$BASE_AREA/src/ 		>>user.$$.profile
   echo $$.TARGET.LOC.RI_TRIG_SRC 			$CUSTOMER_AREA/ri/src/ 		>>user.$$.profile
   echo $$.TARGET.LOC.RI_TRIG_OBJ 			$CUSTOMER_AREA/ri/obj/ 		>>user.$$.profile
   echo $$.TARGET.LOC.DDL				$HOMEDIR/bldcmd 		>>user.$$.profile

   echo $$.SYSTEM.LOC.PLATFORM 				"IEF_$IEFPLATFORM"		>>user.$$.profile
   echo $$.SYSTEM.LOC.SCRIPT 				$IEFH/bt/scripts/		>>user.$$.profile


   # Used by Sybase, and DB2 (?)
   # srvr

      DIRTYPE=`basename ${AREA}`
      if [ ${DIRTYPE} = "comp" ]
      then
        DIRNAME=`dirname ${AREA}`
        DIRTYPE=`basename ${DIRNAME}`
      fi


      cat  $BLD_SCRIPT_DIR/mtvinfo.txt | while read line
      do
        substring=`echo $line | cut -d,  -f1`
        if [ ${DIRTYPE} = ${substring} ]
        then
           VAR2=`echo $line | cut -d,  -f2`
           #coop/batch
           if [ $FILENUM -eq 3 ]
           then
              VAR4=`echo $line | cut -d,  -f3`
           else
              VAR4=`echo $line | cut -d,  -f4`
           fi
           AFG_JAVA_CLASS=`echo $line | cut -d,  -f6`
           BUILD_SCRIPT=`echo $line | cut -d,  -f7`   
           RI_SCRIPT=`echo $line | cut -d,  -f8` 
           DB_SCRIPT=`echo $line | cut -d,  -f9`
           AFG_VERSION=`echo $line | cut -d,  -f10` 
           #Get the first four characters of the release number
           BASE_RELEASE_NUM=`echo $substring | cut -c 1-4`
        fi
      done

      if [ "$AFG_JAVA_CLASS" = "" ]
      then
          echo "The AFG_JAVA_CLASS was not found in mtvinfo.txt"
          exit $ERROR_CODE
      fi

      if [ "$IEFCAS" != "" ]
      then
          CASLIB=$IEFCAS
      else
          if [ "$AFG_VERSION" = "7.0" ]
          then
             CASLIB="${AREA}/lib/libCASCADE.sl"
          else
             CASLIB=""
          fi
      fi

      DBUSER="${VAR4}/${VAR4}@${VAR2}"
      DBPSWD=' ' 

      echo $$.DBMS.ORACLE.OPT.DBUSER			$DBUSER				>>user.$$.profile
      echo $$.DBMS.ORACLE.OPT.DBPSWD			$DBPSWD				>>user.$$.profile

      echo $$.SYSTEM.LOC.SCRIPT_NAME			$BUILD_SCRIPT			>>user.$$.profile
      echo $$.SYSTEM.LOC.RI_SCRIPT			$RI_SCRIPT			>>user.$$.profile
      echo $$.SYSTEM.LOC.DB_SCRIPT			$DB_SCRIPT			>>user.$$.profile
      echo $$.TARGET.LOC.RI_TRIG_LIB			$CASLIB				>>user.$$.profile 

      #For batch jobs modify return code
      #to give more descriptive info 
      if [ $FILENUM -eq 3 ]
      then
        if [[ "${MTV_TMP_RELEASE}" < "280" ]]
        then
            modify_batch_ret_code
        else
            modify_name
        fi
      fi
 
      if [[ "${MTV_TMP_RELEASE}" = "290" || "${MTV_TMP_RELEASE}" > "290" ]]
      then
         case ${FILENUM} in
          1|3) 
             RemoveOPLIBreference 
             ;;
          5)
             RemoveOPLIB_OtherOPLIBreference
             ;;
          *)
             ;;
         esac
#TLB 05-29-15  added the following conditonal stmt to remove WSDL from remote files
         if [ $FILENUM -eq 1 ]
         then
            RemoveWSDL $rmtFile
            retCode=$?
            if [ $retCode != 0 ]
            then
               echo "Error returned from the RemoveWSDL program, remote file name: $rmtFile, return code: $retCode"
               exit $ERROR_CODE
            fi 
         fi

         ForceRounding $rmtFile 
         retCode=$?
         if [ $retCode != 0 ]
         then
            echo "Error returned from the ForceRounding program, remote file name: $rmtFile, return code: $retCode"
            exit $ERROR_CODE
         fi 
         ForceTS $rmtFile
         retCode=$?
         if [ $retCode != 0 ]
         then
            echo "Error returned from the ForceTS program, remote file name: $rmtFile, return code: $retCode"
            exit $ERROR_CODE
         fi

       fi

          #$IEFH/bt/jre/bin/java  \

         if [ -f ${TMPDIR}/java.log ]; then
            rm ${TMPDIR}/java.log
         fi

          java  \
           -Duser.home="${TMPDIR}" \
           -classpath "$IEFH/bt/bt.jar:$IEFH/bt/bt.ui.jar" "com.ca.${AFG_JAVA_CLASS}.bt.Bldtool.Bldtool" \
           -c COMMAND -a $BUILD_TYPE -l ${TMPDIR} -n ${rmtFileshrt}  -f $$ 2>&1 | tee ${TMPDIR}/java.log

         if [ -f ${TMPDIR}/java.log ]; then
            cat ${TMPDIR}/java.log | while read line
            do
            substring=`echo $line | cut -d. -f3`
            error="NullPointerException"
            if [ "$error" = "$substring" ]
            then
               exit 133
            fi
            done
         fi

#TLB - added this conditional statement to control opslibs.

       if [[ "${MTV_TMP_RELEASE}" = "290" || "${MTV_TMP_RELEASE}" > "290" ]]
       then
          if [ $FILENUM -eq 5 ]
          then
              #/mtv-tools/develop/archive-oplib/make-archive-oplib ${AREA} ${rmtName}
#              ${BLD_SCRIPT_DIR}/make-archive-oplib ${AREA} ${rmtName} >>$BATCHBCTS
              ${BLD_SCRIPT_DIR}/make-archive-oplib ${AREA} ${rmtName}
              if [ -f ${AREA}/lib/lib${rmtName}.${LIB_SX} ]
              then
                 rm ${AREA}/lib/lib${rmtName}.${LIB_SX}  
               fi
          fi

          #check to see if this is a CASCADE remote file
          echo ${rmtName} | grep -q CASCADE
          if [ $? = 0 ]
          then
             if [ "${BUILD_TYPE}" != "SPLIT" ]
             then
                #build an archive version of libCASCADE and remove shared lib version
                ${BLD_SCRIPT_DIR}/make-cascade ${AREA}
                rm -f ${AREA}/lib/libCASCADE.s?
             fi
          fi
       fi
}


# clean up
#
cleanup()
{
   #BB 01/15/08 if building base then CUSTOMER_AREA is same
   #as BASE_AREA
   #TLB
   if [ ${CUSTOMER_AREA} != ${HOMEDIR} ]
   then
      if [ -f ${CUSTOMER_AREA}/src/${rmtName}.c ]
      then
         cp  ${CUSTOMER_AREA}/src/${rmtName}.c ${HOMEDIR}/src/${rmtName}.c
         rm  ${CUSTOMER_AREA}/src/${rmtName}.c 
      fi
   fi

   if [ -f ${CUSTOMER_AREA}/src/${rmtName}.dde ]
   then
      cp  $CUSTOMER_AREA/src/${rmtName}.dde $HOMEDIR/src/${rmtName}.dde
      rm  $CUSTOMER_AREA/src/${rmtName}.dde 
   fi

   if [ -f $CUSTOMER_AREA/src/${rmtName}.gml ]
   then
      cp  $CUSTOMER_AREA/src/${rmtName}.gml $HOMEDIR/src/${rmtName}.gml
      rm  $CUSTOMER_AREA/src/${rmtName}.gml 
   fi

   if [ -f $CUSTOMER_AREA/src/${rmtName}.h ]
   then
      cp  $CUSTOMER_AREA/src/${rmtName}.h $HOMEDIR/src/${rmtName}.h
      rm  $CUSTOMER_AREA/src/${rmtName}.h 
   fi

   if [ -f ${CUSTOMER_AREA}/src/${rmtName}.rc ]
   then
      cp  ${CUSTOMER_AREA}/src/${rmtName}.rc ${HOMEDIR}/src/${rmtName}.rc
      rm  ${CUSTOMER_AREA}/src/${rmtName}.rc 
   fi
   
   echo ===============================    >>${OUTFILE}
   echo = Results of build of $IEFPRODUCT  >>${OUTFILE}
   echo ===============================    >>${OUTFILE}
   echo ===============================    >>${OUTFILE}
   echo ${FILENAME%.rmt}.out               >>${OUTFILE}
   echo -------------------------------    >>${OUTFILE}
   if [ -f ${FILENAME%.rmt}.out -o "$BUILD_TYPE" = "SPLIT" ]
   then
     rm ${FILENAME%.rmt}.scrpt > /dev/null 2>&1
     #rm ${FILENAME%.rmt}.icm > /dev/null 2>&1
     mv ${FILENAME%.rmt}.icm ${HOMEDIR}/icm > /dev/null 2>&1
     chmod 644  ${HOMEDIR}/icm/${FILENAME%.rmt}.icm > /dev/null 2>&1
     rm ${FILENAME%.rmt}.tmp > /dev/null 2>&1
     rm ${FILENAME%.rmt}.tgt > /dev/null 2>&1
     rm ${FILENAME%.rmt}.crc > /dev/null 2>&1
     rm ${FILENAME%.rmt}.mak > /dev/null 2>&1
     rm ${FILENAME%.rmt}.map > /dev/null 2>&1
     rm ${FILENAME%.rmt}.maptmp > /dev/null 2>&1
     cat ${FILENAME%.rmt}.out                >>${OUTFILE}
     rm ${FILENAME%.rmt}.out
   fi
   if [ -f ${FILENAME%.icm}.out ]
   then
     rm ${FILENAME%.icm}.scrpt > /dev/null 2>&1
     #rm ${FILENAME%.icm}.icm > /dev/null 2>&1
     rm ${FILENAME%.icm}.tmp > /dev/null 2>&1
     rm ${FILENAME%.icm}.tgt > /dev/null 2>&1
     rm ${FILENAME%.icm}.crc > /dev/null 2>&1
     rm ${FILENAME%.icm}.mak > /dev/null 2>&1
     rm ${FILENAME%.icm}.map > /dev/null 2>&1
     rm ${FILENAME%.icm}.maptmp > /dev/null 2>&1
     cat ${FILENAME%.icm}.out      >>${OUTFILE}
     rm ${FILENAME%.icm}.out
   fi

   cat ${BATCHBCTS}               >> ${OUTFILE}

##JPH
   rm ${AREA}/srvr/[A-Z]* > /dev/null 2>&1
   rm -R ${AREA}/inqload > /dev/null 2>&1
   rm ${AREA}/srvr/inqload/*libtype.txt > /dev/null 2>&1

   rm user.$$.profile > /dev/null 2>&1
   rm ${LOGNAME}*.c > /dev/null 2>&1
   rm ${LOGNAME}*.i > /dev/null 2>&1
   rm ${BATCHBCTS}  > /dev/null 2>&1

}


#################################################################
# "Main" portion of script
#################################################################

ERROR_CODE=2

USAGE="eval echo \"\nusage:  $0 <area> <remote file name> <module name> <build type>\n  example: $0 /t07/cert HQ09S00C.rmt HQ09S00C SPLIT\n\";exit $ERROR_CODE"


#  Get command line parameters
ARG[0]=$0
MAXARGS=0
for ARGS
do
  ((MAXARGS+=1))
  ARG[$MAXARGS]=$ARGS
  #echo $ARGS
done

if [[ $MAXARGS -lt 4 ]]
then
  $USAGE
fi

if [ -d ${ARG[1]} ]
then
   AREA=$1
else
   echo "$0 -- ${ARG[1]} is not a valid area or directory"
   $USAGE
fi

if [ -r ${AREA}/tmp/${ARG[2]} ]
then
    FILENAME=${ARG[2]}
else
    echo "$0 -- ${ARG[2]} is not a valid rmt file within the directory ${AREA}/tmp"
    $USAGE
 fi

if [ ! -s $BLD_SCRIPT_DIR/mtvinfo.txt ]
then
    echo "$0 -- ${BLD_SCRIPT_DIR}/mtvinfo.txt is an important file for this process"
    echo "      Please find or build the file."
    echo "      Example first two lines:"
    echo "      AREA,SID,BATCHID,ONLNID"
    echo "      cert,m240,mcpcbtch,mcpconln"
    $USAGE
 fi


IEFPRODUCT=${ARG[3]}

BUILD_TYPE=$4
case ${BUILD_TYPE} in
BUILD)
  echo "Build type is: BUILD"
;;
SPLIT)
  echo "Build type is: SPLIT"
;;
*)
  echo "Build type must be BUILD or SPLIT"
  exit $ERROR_CODE 
;;
esac

case `uname` in
HP-UX | Linux)
  case `uname -m` in
  ia64 | x86_64)
     export LIB_SX=so
  ;;
  *)
      export LIB_SX=sl
  ;;
  esac
  export GREP_HOME=/usr/bin
  export AWK_HOME=/usr/bin
  export AWK=$AWK_HOME/awk
  umask 000
;;
SunOS)
  export GREP_HOME=/usr/xpg4/bin
  export AWK_HOME=/usr/xpg4/bin
  umask 000

;;
AIX)
   echo "This tool is not setup for AIX yet"
   $USAGE
;;
*)
   echo "This tool is not setup for this system type yet"
   echo "Valid systems are HP-UX and SunOS"
   $USAGE
;;
esac

. ${BLD_SCRIPT_DIR}/mtv_release_number.sh -a ${AREA}

handle_concatenation

#TLB 0928 added following 8 lines

export LIBTYPE=archive_shared
#export LIBTYPE=archive
export TMPDIR=${AREA}/tmp
export AEHOME=${AREA}
export AEPATH="$AEHOME;$IEFH"
export IEFGXTP="$IEFH/translat/"
export ADHOME=${AREA}/srvr
export ADPROD=${AREA}
export UNIXCMD=yes
export TRANCODES=yes
export BATCHBCTS=${AREA}/tmp/batchb.cts.$$
export OUTFILE=${AREA}/tmp/out.${IEFPRODUCT}.$$


#Get lib list from AREA/lib
#and put it in MTV_LIB_LIST
getliblist

. ${BLD_SCRIPT_DIR}/get-afg-version.sh ${AREA}

IEFEXT2=" "

  #SHRT_BASE_RELEASE_NUM=`echo $AREA | ${AWK_HOME}/awk -F/ '{print $3}' | cut -b 2-3`

##  if [[ "${MTV_TMP_RELEASE}" = "280" || "${MTV_TMP_RELEASE}" > "280" ]]
##  then
##     IEFEXT13="${BLD_SCRIPT_DIR}/UnixBatch.a"
##     export IEFEXT13="${IEFEXT13} ${MTV_LIB_LST} -Wl,-a,archive_shared "
##JPH - add rt link option
##     if [[ ${IEFPLATFORM} = "HPia64" &&  "$ORAVER" = "11" ]]
##     then
##          export IEFEXT13="${IEFEXT13} -lrt "
##     fi
##  else
##     export IEFEXT13="${IEFEXT13} ${MTV_LIB_LST} " 
##  fi

  IEFEXT13="${BLD_SCRIPT_DIR}/UnixBatch.a"
  if [[ ${IEFPLATFORM} = "HPia64" || ${IEFPLATFORM} = "HPIA64" ]]
  then
##     if [ ${AFG_VERSION_TMP} -ge 8.0 ]
##     then 
##        IEFEXT13="${BLD_SCRIPT_DIR}/UnixBatch64.a"
##     fi
##JPH - add rt link option
     if [ "$ORAVER" = "11" ]
     then
        IEFEXT13="${IEFEXT13} -lrt"
     fi
  fi
##  export IEFEXT13="${IEFEXT13} ${MTV_LIB_LST} -Wl,-a,archive_shared "
  export IEFEXT13="${IEFEXT13} ${MTV_LIB_LST} "


##JPH
NON_COMP_CUST_LIB=""
NON_COMP_BASE_LIB=""
BASE_AREA_LIB="-L${BASE_AREA}/lib"
#ORA_LIB_DIR=-L/usr/lib/oracle/19.10/client64/lib
if [ "${IS_COMP_AREA}" = "1" ]
then
    NON_COMP_BASE_LIB="-L${NON_COMP_BASE}/lib"
    NON_COMP_CUST_LIB="-L${NON_COMP_CUST}/lib"
fi
if [ "$BASE_AREA" != "$CUSTOMER_AREA" ]
then
   CUSTOMER_AREA_LIB="-L${CUSTOMER_AREA}/lib"
else
   CUSTOMER_AREA_LIB=""
   NON_COMP_CUST_LIB=""
fi
   
##      export EXTLIB="-Wl,+n ${CUSTOMER_AREA_LIB} ${NON_COMP_CUST_LIB} ${BASE_AREA_LIB} ${NON_COMP_BASE_LIB} ${IEFEXT13} " 
export EXTLIB="${CUSTOMER_AREA_LIB} ${NON_COMP_CUST_LIB} ${BASE_AREA_LIB} ${NON_COMP_BASE_LIB} ${ORA_LIB_DIR} ${IEFEXT13} " 

#export EXTLIB="-L${CUSTOMER_AREA}/lib -L${BASE_AREA}/lib ${IEFEXT13} "

export SHLIB_PATH=$SHLIB_PATH:/usr/lib:/opt/aCC/lib:$ORACLE_HOME/lib:$IEFH/ae/cief


#Strip out any ^M at the end of the line
echo "File Name Is: ${AREA}/tmp/${FILENAME}"
mv ${AREA}/tmp/${FILENAME} ${AREA}/tmp/${FILENAME}.work
#cat ${AREA}/tmp/${FILENAME}.work | dos2unix > ${AREA}/tmp/${FILENAME} 2>> ${OUTFILE} 
dos2unix -n ${AREA}/tmp/${FILENAME}.work ${AREA}/tmp/${FILENAME} 2>> ${OUTFILE}
rm ${AREA}/tmp/${FILENAME}.work

FTYPE=rmt

###########################################################################
#  :screen logic
###########################################################################

grep -q -i -E ':screen|:escreen' ${AREA}/tmp/${FILENAME}
if [ $? = 0 ]
then
   echo "found a screen"
   echo "$0 - ${FILENAME} has :screen and/or :escreen, IEFSIGNAL:FAIL" >>$BATCHBCTS
   echo "$0 - ${FILENAME} has :screen and/or :escreen, IEFSIGNAL:FAIL" 
   cleanup
   $USAGE
   
fi

###########################################################################
#  StubTrapper logic
###########################################################################

type ${BLD_SCRIPT_DIR}/StubTrapper > /dev/null 2>&1
retcode=$?
if [ "${retcode}" -eq "0" ]
then
    ${BLD_SCRIPT_DIR}/StubTrapper  ${AREA}/tmp/${FILENAME} ${IEFPRODUCT} 
    retcode=$?
    if [ $retcode != 0 ]
    then
        echo "$0 - ${FILENAME} has Stubbed out code, IEFSIGNAL:FAIL" >>$BATCHBCTS
        echo "$0 - ${FILENAME} has Stubbed out code, IEFSIGNAL:FAIL" 
        cleanup
        $USAGE
    fi
else
    echo "$0 - StubTrapper not found. Continuing with build.IEFSIGNAL:FAIL" >>$BATCHBCTS
    echo "$0 - StubTrapper not found. Continuing with build.IEFSIGNAL:FAIL"
fi
 
FILETYPE=$(icmtype ${AREA}/tmp/${FILENAME})
FILENUM=$?

case $FILENUM in
   0) echo ========================= >>$BATCHBCTS 
      date >>$BATCHBCTS
      echo "$0 icmtype.exec had a general processing error" >>$BATCHBCTS
      echo ========================= >>$BATCHBCTS
      retcode=1
      cleanup
     ;;
   1) echo ========================= >>$BATCHBCTS 
      date >>$BATCHBCTS
      echo "$0 - icmtype.exec found $FILENAME to be coop server - ONLINE" >>$BATCHBCTS
      echo ========================= >>$BATCHBCTS
      HOMEDIR=${AREA}/srvr
     ;;
   2) echo ========================= >>$BATCHBCTS 
      date >>$BATCHBCTS
      echo "$0 - icmtype.exec found $FILENAME to be coop window" >>$BATCHBCTS
      echo "$0 - Can not process rmt of type coop windows" >>$BATCHBCTS
      echo ========================= >>$BATCHBCTS
      cleanup
     ;;
   3) echo ========================= >>$BATCHBCTS 
      date >>$BATCHBCTS
      echo "$0 - icmtype.exec found $FILENAME to be windows packaged no display - BATCH" >>$BATCHBCTS
      echo ========================= >>$BATCHBCTS
      #TLB

      if [[ "${MTV_TMP_RELEASE}" < "280" ]]
      then
         HOMEDIR=${AREA}/coop/batch
      else
         HOMEDIR=${AREA}
      fi
     ;;
   4) echo ========================= >>$BATCHBCTS 
      date >>$BATCHBCTS
      echo "$0 - icmtype.exec found $FILENAME to be a cascade descriptor" >>$BATCHBCTS
      echo ========================= >>$BATCHBCTS
      export IEFCAS=${AREA}/lib/
      HOMEDIR=${AREA}/ri
      ADHOME=${AREA}/ri
     ;;
   5) echo ========================= >>$BATCHBCTS 
      date >>$BATCHBCTS
      echo "$0 - icmtype.exec found $FILENAME to be OPSLIB" >>$BATCHBCTS
      echo ========================= >>$BATCHBCTS
      HOMEDIR=${AREA}/srvr
     ;;
   *) echo ========================= >>$BATCHBCTS 
      date >>$BATCHBCTS
      echo "$0 - Unknown return code from icmtype.exec " >>$BATCHBCTS
      echo ========================= >>$BATCHBCTS
      cleanup
     ;;
esac

TARDIR=$PWD

IEF_BITMAP=$TARDIR/Coop/Bitmap/


#PRODDIR=${AREA}


cd ${AREA}/tmp
#cd ${HOMEDIR}/tmp

# echo "pwd is `pwd`"



cd -

if [ "$IEFCAS" != "" ] 
then
    CASLIB=$IEFCAS
else
    CASLIB="-L$CUSTOMER_AREA/lib -lCASCADE"
fi

mainwork ${CUSTOMER_AREA}/tmp/${FILENAME}

cleanup

${GREP_HOME}/grep 'IEFSIGNAL:FAIL' ${OUTFILE}  >/dev/null
if [ $? = 0 ] 
then
   bldRc=$ERROR_CODE
else
   bldRc=0
fi
exit $bldRc

