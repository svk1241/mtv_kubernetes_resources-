#!/bin/bash

ERROR_CODE=2
USAGE="eval echo -e \"\nusage:  $0 AREA \n\texample: $0 /opt/bknd \n\t\t $0 /opt/m210\n\";exit $ERROR_CODE"

ARG[0]=$0
MAXARGS=0
for ARGS
do
  ((MAXARGS+=1))
  ARG[$MAXARGS]=$ARGS
done

if [ $MAXARGS -lt 1 ]
then
  $USAGE
fi

AREA=${ARG[1]}

AREADIRS="${AREA}/tmp ${AREA}/bin ${AREA}/lib ${AREA}/obj ${AREA}/comp/icm ${AREA}/comp/lib ${AREA}/comp/tmp ${AREA}/comp/obj ${AREA}/ri/obj"

if [ ! -d ${AREA} ]
then
  echo -e "$0 -- ${AREA} is not a valid directory"
  $USAGE
fi

for DIR in ${AREADIRS}; do
   if [ ! -d ${DIR} ]
   then
      echo -e "$0 -- Creating ${DIR}"
      mkdir ${DIR}
      if [ ! -d ${DIR} ]
      then
         echo -e "$0 -- ${DIR} is not a valid directory"
        $USAGE
      fi
   fi
done


