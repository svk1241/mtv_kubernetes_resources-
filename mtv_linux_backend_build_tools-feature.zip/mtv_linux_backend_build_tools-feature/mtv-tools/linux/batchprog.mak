#############################################################################
#
# onlnsl.mak -- Builds a shared library for online super servers
#            linkage resolution.
#
#  Requires:	dep		set to Dependency list
#               bld		set to build component list
#               baseDir set to the base of a build area
#
#  Who		When		What    
# -----------------------------------------------------------------------
#############################################################################

SHELL      = /bin/ksh
TMPDIR     = $(BASEDIR)tmp/
#TARGET_LIB = $(BASEDIR)lib/libonline.sl
INCDIR     = $(BASEDIR)extrn/include
##JPH INCL
INCDIRC    = $(CUSTDIR)extrn/include
INCDIR1    = $(IEFH)/src
INCDIR2    = $(IEFH)/include
INCDIR3    = $(ORA_INCL)
#INCDIR4    = /opt/bea/tuxedo8.1/include
#INCDIR5    = $(CC_HOME)/custom/example
#INCDIR6    = $(DRG_HOME)
INCDIR7    = $(MTV_TOOLS_DIR)/include

LIBDIR1    = $(ORA_LIBS)

CC        = gcc
ACC       = $(CC)
CXX       = $(CC)
CCOPTS    = $(CC_OPTS)
ACCOPTS   = $(ACC_OPTS)

CCMEM     = 
#  Following line changed for DRG Grouper
##JPH INCL
CCINC     = -I$(INCDIR) -I$(INCDIRC) -I$(INCDIR1) -I$(INCDIR2) -I$(INCDIR3) -I$(INCDIR7)
#CCINC     = -I$(INCDIR) -I$(INCDIR1) -I$(INCDIR2) -I$(INCDIR3) -I$(INCDIR5)
#  Following line changed for DRG Grouper
SQLINC    = include=$(INCDIR) include=$(INCDIR1) include=$(INCDIR2) include=$(INCDIR3) include=$(INCDIR7)
#SQLINC    = include=$(INCDIR) include=$(INCDIR1) include=$(INCDIR2) include=$(INCDIR3) include=$(INCDIR5)

#  Following line changed for DRG Grouper
# CCDEFS    = -DUNIX -DTARGET_HPUX -D_INCLUDE_HPUX_SOURCE -D_INCLUDE_XOPEN_SOURCE -D_INCLUDE_POSIX_SOURCE +DAportable
CCDEFS    = $(CC_DEFS)
ACCDEFS   = $(ACC_DEFS)

LD        = $(CC)
LDFLAGS   = 

LIBS      = 
##LIB		  = aCC +DD64 -Wl,-E,+s -ldld  -Wl,-a,default,+n -o 
LIB       = $(LIB_COMPILER)
OBJEXT    = .o

# ESQL/C support for ORACLE
DB        = ORACLE
SQLPRE    = proc
#  
# THe following line was change because of Oracle cursor with hold.
 #TLB 12/19/2010 SQLOPT    = sqlcheck=syntax mode=oracle oreclen=255 ireclen=255 ltype=none $(SQLINC) define=ORACLE
SQLOPT    = sqlcheck=syntax mode=ansi oreclen=255 ireclen=255 ltype=none $(SQLINC) define=ORACLE

# Inference Rules
.SUFFIXES:

.SUFFIXES: $(OBJEXT) .asm .c .C .sqc .lib .cpp

.cpp$(OBJEXT):
	$(ACC) $(ACCOPTS) $(ACCDEFS) $(CCMEM) $(CCDEBUG) $(CCINC) -o$*$(OBJEXT) $*.cpp

.c$(OBJEXT):
	$(CC) $(CCOPTS) $(CCDEFS) $(CCMEM) $(CCDEBUG) $(CCINC) -o$*$(OBJEXT) $*.c

.sqc$(OBJEXT):
	$(SQLPRE) $(SQLOPT) iname=$*.sqc oname=$*.c
	$(CC) $(CCOPTS) $(CCDEFS) $(CCDEBUG) $(CCINC) -o$*$(OBJEXT) $*.c
	@rm $*.c > /dev/null

# Targets and dependents
all: parameters $(TARGET_PROG)

include $(DEP)

$(TARGET_PROG):
	@echo "Build is $(BLD)"
#	$(LIB) $(TARGET_PROG) $(OBJS) $(LIB_FLAGS)
	$(LIB) $@ $? -L$(LIBDIR1) $(LIB_FLAGS)
	

include $(BLD)

parameters:
	-@rm $(TARGET_PROG) 2> /dev/null
