

#export MTV_TOOLS_DIR=/opt/bknd/mtv-tools
export MTV_TOOLS_DIR=`cd .. && pwd && cd linux`
#echo "export MTV_TOOLS_DIR = $MTV_TOOLS_DIR"
export BLD_SCRIPT_DIR=$MTV_TOOLS_DIR/linux
export IEFPLATFORM=LINUX
export IEFH=/opt/CA86/CAGen/runtime
export ORA_INCL=/usr/include/oracle/19.10/client64
export ORA_LIBS=/usr/lib/oracle/19.10/client64/lib
export MQ_INCL=/opt/MQ/inc
export JAVA_INCL=/usr/lib/jvm/java/include
export PATH=$PATH:$BLD_SCRIPT_DIR:$IEFH/bin
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$IEFH/lib
export BLD_THREADS=-j16
