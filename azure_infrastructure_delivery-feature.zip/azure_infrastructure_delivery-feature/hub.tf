# data "azurerm_virtual_network" "peer" {
#   name                = "production"
#   resource_group_name = "networking"
# }

module "poc" {
  source          = "./modules/poc-v1"
  location        = local.location
  visibility      = local.visibility
  vnet_cidr_block = "10.0.0.0/10"
  main_snet_cidr  = "10.1.0.0/24"

  default_pool_node_count = 1
  system_pool_node_count  = 1
  #Optional parameters:
  # windows_vm_count = 1
  # linux_vm_count = 1
  # oracle_vm_count = 1
  # peering_vnet_id = azurerm_virtual_network.peer.id
}
