location             = "eastus"
visibility           = "private"
environment          = "devaz"
windows_gui_image_id = "/subscriptions/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx/resourceGroups/$RG_NAME/providers/Microsoft.Compute/images/WindowsServer2016-with-mtv-v2"
windows_smb_image_id = "/subscriptions/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx/resourceGroups/$RG_NAME/providers/Microsoft.Compute/images/WindowsServer2016-smb"

# This module uses Azure KeyVault to store VM access secret
# Must be in json format with 'user' and 'password' fields.
# Example:
# {"user":"admin",   "password":"secretpassword"}
azure_keyvault_rg   = "rg-service-global"        # Resource group in which Key Vault is deployed
azure_keyvault_name = "kv-secrets-eastus-global" # Key Vault name
azure_key_name      = "default-vm-access"        # Secret name