# This file is maintained automatically by "terraform init".
# Manual edits may be lost in future updates.

provider "registry.terraform.io/hashicorp/azurerm" {
  version     = "2.51.0"
  constraints = "~> 2.51.0"
  hashes = [
    "h1:jWV1mCPvixdCH7nn+FFWj/QFdViMtEihdT2OWxZCmGQ=",
    "zh:096a9de20ba3c65bbc90342d541c28f554fc9cf04ed9b062d3518476d9e062d0",
    "zh:2b818673e200916149dfae83ff0c261060c80201683620e8759f5415216fda81",
    "zh:474cb0ae8ccd90382f208999269c5e26d31df34fed58c170612db72d29014c74",
    "zh:58e535f38e465586696b8128e329fba39f7e03df0379a46ed2c27715901f301d",
    "zh:69faed24648d1fa4b93dd16040a91b93f2153298ccdfee76e118a3621efacba2",
    "zh:86a7a0f05ac5fc8de551e2832553b50c5b3de020efb1029e6c16f24e4d57c503",
    "zh:86cad0bf11a5111d6ddf5d9ed0bfe52975d89c4c3e2a695984fe92278c21087a",
    "zh:a17e98579094db5aff0a4785a7f8969959b8408969dcad52fc24dfe3396bdb8c",
    "zh:aa8fcee289c8a8c46db6c8e1738bca1f5c7e098915bfa4b55065e4713128df18",
    "zh:c63c48aa11ff4c5b9c653d7a8d851c8d7829b172353606714036680e7b1f1d74",
    "zh:e69d627d0fc101fef0aa0362062c9930831a43264b828ab014e9107727ba2e71",
  ]
}

provider "registry.terraform.io/hashicorp/random" {
  version     = "2.3.1"
  constraints = "~> 2.2"
  hashes = [
    "h1:aScA+t1Y6fM1OAFClfuUpP9YCyHlUtWoLo76AxeLJZk=",
    "h1:bPBDLMpQzOjKhDlP9uH2UPIz9tSjcbCtLdiJ5ASmCx4=",
    "zh:322ec2b56765162c193d0ff0f7634351bf4ca09d719558df82b92d31059995a1",
    "zh:34c500857d14148bc6f7f21f9fc0d832ba31d00e1b911b0437d99dda29aeb108",
    "zh:a3372514add474fcb07d2026a49b0c0d8a699e365f540e43e5f590eb924b95f7",
    "zh:a54acd50f13f38a86454acad16b3487701608188fd2cc454fd48beee00127ae5",
    "zh:b1285c47ab01fc11b6086f080da7d17b9155b3fac6a4175948a2abb5d52c60af",
    "zh:c7e7bd46218cf504ca31d8a1e4eab5cad625c9951fb89d4f56861d5bddec9afb",
    "zh:d9f95764480d7b884db7247a5ee9d1c72aaf1c1cde3d7b5e34bc33c4ef5ccf48",
    "zh:ddf11fb807d61ff93c08206733129bf9668fc0c4adedf8a6ac38a7c382a24b35",
    "zh:f631a0c1ffa94991d87cd5fe4e08c0dd6d36c780585f35a582c05ee2affb7e86",
    "zh:fb5f5fb19e8a9ff73dbdee85a97f548099e480497a7a1f4ca4725c83db300b8d",
  ]
}
