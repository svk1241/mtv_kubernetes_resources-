resource "azurerm_resource_group" "this" {
  location = var.location
  name     = "rg-deltadental-eastus-private"
}

# General Networking
resource "azurerm_virtual_network" "this" {
  address_space       = ["10.0.0.0/16"]
  location            = var.location
  name                = module.naming.virtual_network.name
  resource_group_name = azurerm_resource_group.this.name

  tags = {
    environment = var.environment
  }
}

resource "azurerm_subnet" "this" {
  name                                           = module.naming.subnet.name_unique
  resource_group_name                            = azurerm_resource_group.this.name
  virtual_network_name                           = azurerm_virtual_network.this.name
  address_prefixes                               = ["10.0.0.0/20"]
  enforce_private_link_endpoint_network_policies = true
  service_endpoints                              = ["Microsoft.Storage"]

}

resource "azurerm_proximity_placement_group" "ppg-aks-001" {
  name                = "ppg-spoke-aks001-001"
  location            = var.location
  resource_group_name = azurerm_resource_group.this.name

  tags = {
    environment = var.environment
  }
}

#Azure Container Registry
module "dd_acr_public" {
  source              = "./modules/acr-v1"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  visibility          = "public"
  application         = "registry"
  environment         = var.environment
}

#GUI client VM
module "dd_windows_gui" {
  source                     = "./modules/windows-vm-auto-v2"
  resource_group_name        = azurerm_resource_group.this.name
  subnet_id                  = azurerm_subnet.this.id
  vm_size                    = "Standard_D4s_v3"
  vm_image_id                = var.windows_gui_image_id
  secret                     = [var.azure_keyvault_rg, var.azure_keyvault_name, var.azure_key_name]
  name_prefix                = "gui"
  instance_count             = 1
  start_count_number         = 1
  ppg_id                     = azurerm_proximity_placement_group.ppg-aks-001.id
  use_accelerated_networking = true

  application = "gui"
  environment = var.environment
  location    = var.location
  visibility  = var.visibility

}

#Windows SMB server
module "dd_windows_smb_server" {
  source                     = "./modules/windows-vm-auto-v2"
  resource_group_name        = azurerm_resource_group.this.name
  subnet_id                  = azurerm_subnet.this.id
  vm_size                    = "Standard_D4s_v3"
  vm_image_id                = var.windows_smb_image_id
  secret                     = [var.azure_keyvault_rg, var.azure_keyvault_name, var.azure_key_name]
  name_prefix                = "smb"
  instance_count             = 1
  start_count_number         = 1
  ppg_id                     = azurerm_proximity_placement_group.ppg-aks-001.id
  use_accelerated_networking = true

  application = "smb"
  environment = var.environment
  location    = var.location
  visibility  = var.visibility
}

resource "azurerm_managed_disk" "batch_dir" {
  name                 = module.naming.managed_disk.name_unique
  location             = var.location
  resource_group_name  = azurerm_resource_group.this.name
  storage_account_type = "Premium_LRS"
  create_option        = "Empty"
  disk_size_gb         = "256"
}

resource "azurerm_virtual_machine_data_disk_attachment" "batch_dir_attachment" {
  managed_disk_id    = azurerm_managed_disk.batch_dir.id
  virtual_machine_id = module.dd_windows_smb_server.wm_id[0]
  lun                = "10"
  caching            = "ReadWrite"
}

# Kubernetes Cluster
resource "azurerm_private_dns_zone" "dd_kubernetes" {
  name                = "privatelink.eastus.azmk8s.io"
  resource_group_name = azurerm_resource_group.this.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "dd_kubernetes" {
  name                  = azurerm_virtual_network.this.name
  resource_group_name   = azurerm_resource_group.this.name
  private_dns_zone_name = azurerm_private_dns_zone.dd_kubernetes.name
  virtual_network_id    = azurerm_virtual_network.this.id
  registration_enabled  = false
}

module "dd_aks001_cluster" {
  source                 = "./modules/aks-v1"
  resource_group_name    = azurerm_resource_group.this.name
  user_identity          = "aks-identity"
  location               = var.location
  visibility             = "private"
  application            = "k8s_cluster"
  environment            = var.environment
  subnet_id              = azurerm_subnet.this.id
  default_nodes_vm_size  = "Standard_DS2_v2"
  default_node_pool_name = "systempool"
  min_nodes_count        = 3
  max_nodes_count        = 3
  enable_auto_scaling    = true
  acr_id                 = module.dd_acr_public.id
  service_cidr           = "10.0.16.0/24"
  dns_service_ip         = "10.0.16.10"
  docker_bridge_cidr     = "172.17.0.1/16"
  kubernetes_dns_zone_id = azurerm_private_dns_zone.dd_kubernetes.id
  ppg_id                 = azurerm_proximity_placement_group.ppg-aks-001.id
}

module "aks001_application_nodepool" {
  source              = "./modules/node-pool-v1"
  name                = "apppool"
  cluster_id          = replace(module.dd_aks001_cluster.cluster_id, "resourceGroups", "resourcegroups")
  subnet_id           = azurerm_subnet.this.id
  nodepool_vm_size    = "Standard_D4s_v3"
  taints              = []
  labels              = { "purpose" = "application" }
  ppg_id              = azurerm_proximity_placement_group.ppg-aks-001.id
  environment         = var.environment
  enable_auto_scaling = true
  min_nodes_count     = 5
  max_nodes_count     = 16
  node_count          = 5
  mode                = "User"
}

# Database Server
module "oracle-database-001" {
  source                     = "./modules/oracle-db-v2"
  resource_group_name        = azurerm_resource_group.this.name
  hostname                   = "integration-oracle-001"
  subnet_id                  = azurerm_subnet.this.id
  vm_size                    = "Standard_E4s_v3"
  vm_image                   = ["Oracle", "oracle-database-19-3", "oracle-database-19-0904", "latest"]
  volume_size                = ["256"]
  secret                     = [var.azure_keyvault_rg, var.azure_keyvault_name, var.azure_key_name]
  ppg_id                     = azurerm_proximity_placement_group.ppg-aks-001.id
  use_accelerated_networking = true

  application = "oracle-db"
  environment = var.environment
  location    = var.location
  visibility  = var.visibility
}

# Naming convention module
module "naming" {
  source = "./modules/terraform-azurerm-naming"
  suffix = [var.environment, "deltadental", var.location, var.visibility]
}
