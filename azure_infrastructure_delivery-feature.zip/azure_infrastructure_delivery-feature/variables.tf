variable "location" {
  type = string
}
variable "visibility" {
  type = string
}
variable "environment" {
  type = string
}
variable "azure_keyvault_rg" {
  type = string
}
variable "azure_keyvault_name" {
  type = string
}
variable "azure_key_name" {
  type = string
}
variable "windows_gui_image_id" {
  type = string
}
variable "windows_smb_image_id" {
  type = string
}