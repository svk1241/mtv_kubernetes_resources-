resource "random_id" "ipconf-id" {
  byte_length = 4
}

resource "random_id" "hostname-id" {
  byte_length = 2
}

resource "azurerm_network_interface" "interface" {
  name                = "mtv-poc-windows-vm"
  location            = var.location
  resource_group_name = var.resource_group_name

  ip_configuration {
    name                          = "pip-win-vm"
    subnet_id                     = var.subnet_id
    private_ip_address_allocation = "Dynamic"
  }
}

data "azurerm_key_vault" "this" {
  resource_group_name = var.secret[0]
  name                = var.secret[1]
}

data "azurerm_key_vault_secret" "this" {
  name         = var.secret[2]
  key_vault_id = data.azurerm_key_vault.this.id
}

resource "azurerm_windows_virtual_machine" "win-vm" {
  name                = "mtv-poc-win-vm"
  computer_name       = format("%s-%s", "mtv-client", random_id.hostname-id.hex) # Naming convention mismatch due to limits on name length
  resource_group_name = var.resource_group_name
  location            = var.location
  size                = var.vm_size
  admin_username      = "azadmin"
  admin_password      = "1qaz@WSX3edc"
  count               = var.vm_count

  network_interface_ids = [
    azurerm_network_interface.interface.id,
  ]

  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "Standard_LRS"
  }

  source_image_reference {
    publisher = var.vm_image[0]
    offer     = var.vm_image[1]
    sku       = var.vm_image[2]
    version   = var.vm_image[3]
  }
}
