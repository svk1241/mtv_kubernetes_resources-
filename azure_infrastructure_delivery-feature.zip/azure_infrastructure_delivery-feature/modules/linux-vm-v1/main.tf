resource "azurerm_network_interface" "this" {
  name                = "mtv-poc-linux-ws"
  location            = var.location
  resource_group_name = var.resource_group_name

  ip_configuration {
    name                          = "pip-linux-vm"
    subnet_id                     = var.subnet_id
    private_ip_address_allocation = "Dynamic"
  }
}

data "azurerm_key_vault" "this" {
  resource_group_name = var.secret[0]
  name                = var.secret[1]
}

data "azurerm_key_vault_secret" "this" {
  name         = var.secret[2]
  key_vault_id = data.azurerm_key_vault.this.id
}

resource "azurerm_linux_virtual_machine" "main" {
  name                            = "mtv-poc-linux-vm"
  resource_group_name             = var.resource_group_name
  location                        = var.location
  size                            = var.vm_size
  admin_username                  = "azadmin"
  disable_password_authentication = true
  count                           = var.vm_count

  network_interface_ids = [
    azurerm_network_interface.this.id,
  ]

  admin_ssh_key {
    username   = "azadmin"
    public_key = file("./ssh/ssh_key.pub")
  }

  source_image_reference {
    publisher = var.vm_image[0]
    offer     = var.vm_image[1]
    sku       = var.vm_image[2]
    version   = var.vm_image[3]
  }

  os_disk {
    storage_account_type = "Standard_LRS"
    caching              = "ReadWrite"
  }
}

resource "azurerm_managed_disk" "opt" {
  count                = var.vm_count
  name                 = "${azurerm_linux_virtual_machine.main[count.index].name}-disk1"
  location             = var.location
  resource_group_name  = var.resource_group_name
  storage_account_type = "Standard_LRS"
  create_option        = "Empty"
  disk_size_gb         = 32
}

resource "azurerm_virtual_machine_data_disk_attachment" "this" {
  count              = var.vm_count
  managed_disk_id    = azurerm_managed_disk.opt[count.index].id
  virtual_machine_id = azurerm_linux_virtual_machine.main[count.index].id
  lun                = "10"
  caching            = "ReadWrite"
}
