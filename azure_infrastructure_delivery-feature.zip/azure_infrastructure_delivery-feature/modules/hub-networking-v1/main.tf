resource "azurerm_virtual_network" "this" {
  address_space       = [var.vnet_cidr_block]
  location            = var.location
  name                = "mtv-poc-vnet"
  resource_group_name = var.resource_group_name

  tags = {
    team           = "cm"
    realm          = "hub"
    resource_group = var.resource_group_name
    region         = var.location
  }
}


resource "azurerm_subnet" "this" {
  name                                           = "mtv-poc-main_snet"
  resource_group_name                            = var.resource_group_name
  virtual_network_name                           = azurerm_virtual_network.this.name
  address_prefixes                               = [var.main_snet_cidr]
  enforce_private_link_endpoint_network_policies = var.enforce_private_link_endpoint_network_policies
}

resource "azurerm_virtual_network_peering" "peering-backward" {
  count                        = var.peering_vnet_id != "" ? 1 : 0
  name                         = "peering-to-hub-vnet"
  resource_group_name          = var.resource_group_name
  virtual_network_name         = azurerm_virtual_network.this.name
  remote_virtual_network_id    = var.peering_vnet_id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  allow_gateway_transit        = false
}
