variable "resource_group_name" { type = string }
variable "application" { type = string }
variable "environment" { type = string }
variable "location" { type = string }
variable "visibility" { type = string }
variable "vnet_cidr_block" { type = string }
variable "main_snet_cidr" { type = string }
variable "enforce_private_link_endpoint_network_policies" {
    type = bool
    default = false
    }

variable "peering_vnet_id" {
    type = string
    default = ""
    }
