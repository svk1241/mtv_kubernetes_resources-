data "azurerm_subscription" "primary" {
}

resource "azurerm_user_assigned_identity" "this" {
  name                = var.user_identity
  resource_group_name = var.resource_group_name
  location            = var.location
}

resource "azurerm_role_assignment" "this" {
  scope                = data.azurerm_subscription.primary.id
  role_definition_name = "Contributor"
  principal_id         = azurerm_user_assigned_identity.this.principal_id
}

resource "azurerm_kubernetes_cluster" "this" {
  name                    = "cluster-${var.environment}-${var.location}-${var.visibility}"
  location                = var.location
  resource_group_name     = var.resource_group_name
  dns_prefix              = "aks"
  private_cluster_enabled = true
  private_dns_zone_id     = var.kubernetes_dns_zone_id

  depends_on = [
    azurerm_role_assignment.this,
  ]

  default_node_pool {
    name                         = var.default_node_pool_name
    max_count                    = var.max_nodes_count
    min_count                    = var.min_nodes_count
    vm_size                      = var.default_nodes_vm_size
    enable_auto_scaling          = var.enable_auto_scaling
    node_count                   = var.max_nodes_count
    vnet_subnet_id               = var.subnet_id
    proximity_placement_group_id = var.ppg_id != "" ? var.ppg_id : null
    os_sku                       = var.os_sku
  }

  identity {
    type         = "UserAssigned"
    identity_ids = [azurerm_user_assigned_identity.this.id]
  }

  tags = {
    environment = var.environment
  }

  network_profile {
    network_plugin     = "azure"
    service_cidr       = var.service_cidr
    dns_service_ip     = var.dns_service_ip
    docker_bridge_cidr = var.docker_bridge_cidr
  }
}

resource "azurerm_role_assignment" "kubweb_to_acr" {
  scope                = var.acr_id
  role_definition_name = "AcrPull"
  principal_id         = azurerm_user_assigned_identity.this.principal_id
}
