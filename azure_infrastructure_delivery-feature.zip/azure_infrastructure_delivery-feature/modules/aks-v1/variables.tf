variable "resource_group_name" { type = string }
variable "user_identity" { type = string }
variable "default_nodes_vm_size" { type = string }
variable "subnet_id" { type = string }
variable "service_cidr" { type = string }
variable "dns_service_ip" { type = string }
variable "docker_bridge_cidr" { type = string }
variable "default_node_pool_name" { type = string }
variable "ppg_id" { type = string }

variable "application" { type = string }
variable "environment" { type = string }
variable "location" { type = string }
variable "visibility" { type = string }
variable "acr_id" { type = string }

variable "min_nodes_count" {
  type    = string
  default = 3
}
variable "max_nodes_count" { type = string }
variable "enable_auto_scaling" { type = bool }
variable "kubernetes_dns_zone_id" { type = string }
variable "os_sku" {
  type    = string
  default = "CBLMariner"
}
