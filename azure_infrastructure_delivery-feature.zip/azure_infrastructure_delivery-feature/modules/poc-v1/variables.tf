variable "location" { type = string }
variable "visibility" { type = string }
variable "vnet_cidr_block" { type = string }
variable "main_snet_cidr" { type = string }
variable "default_pool_node_count" { type = number }
variable "system_pool_node_count" { type = number }
variable "peering_vnet_id" {
    type = string
    default = ""
    }
variable "windows_vm_count" { 
    type = number
    default = 1 
}
variable "oracle_vm_count" { 
    type = number
    default = 1 
}
variable "linux_vm_count" { 
    type = number
    default = 1 
}