resource "azurerm_resource_group" "hub" {
  location = var.location
  name     = "rg-mtv-poc-eastus-private"
}

resource "azurerm_storage_account" "this" {
  name                     = "mtvpocaksstorage"
  resource_group_name      = azurerm_resource_group.hub.name
  location                 = var.location
  account_tier             = "Standard"
  account_replication_type = "GRS"

  tags = {
    environment = "mtv-poc"
  }
}


module "hub" {
  source              = "../hub-networking-v1"
  resource_group_name = azurerm_resource_group.hub.name
  vnet_cidr_block     = var.vnet_cidr_block
  main_snet_cidr      = var.main_snet_cidr
  peering_vnet_id     = var.peering_vnet_id


  application                                    = "network"
  environment                                    = "hub"
  location                                       = var.location
  visibility                                     = var.visibility
  enforce_private_link_endpoint_network_policies = true
}


module "acr" {
  source              = "../acr-v1"
  resource_group_name = azurerm_resource_group.hub.name

  application = "registry"
  environment = "hub"
  location    = var.location
  visibility  = var.visibility
}

module "kv" {
  source              = "../kv-v1"
  resource_group_name = azurerm_resource_group.hub.name
  location            = var.location
  name                = "mtv-poc-kv"
}

module "aks001_cluster" {
  source                  = "../aks-v1"
  resource_group_name     = azurerm_resource_group.hub.name
  location                = var.location
  visibility              = "private"
  application             = "k8s_cluster"
  environment             = "aks001"
  subnet_id               = module.hub.subnet_id
  vm_size                 = "Standard_B4ms"
  acr_id                  = module.acr.id
  service_cidr            = "10.1.16.0/24"
  dns_service_ip          = "10.1.16.10"
  docker_bridge_cidr      = "172.17.0.1/16"
  default_pool_node_count = 1
  system_pool_node_count  = 1
}

module "linux-backend" {
  source              = "../linux-vm-v1"
  resource_group_name = azurerm_resource_group.hub.name
  subnet_id           = module.hub.subnet_id
  vm_size             = "Standard_B4ms"
  vm_image            = ["RedHat", "RHEL", "8_3", "latest"]
  vm_count            = var.linux_vm_count
  secret              = [azurerm_resource_group.hub.name, module.kv.kv_name, "default-vm-access"]

  application = "backend"
  environment = "poc001"
  location    = var.location
  visibility  = var.visibility
  depends_on  = [module.kv]
}

module "windows-clients" {
  source              = "../windows-vm-v1"
  resource_group_name = azurerm_resource_group.hub.name
  subnet_id           = module.hub.subnet_id
  vm_size             = "Standard_B4ms"
  vm_image            = ["MicrosoftWindowsServer", "WindowsServer", "2019-Datacenter", "latest"]
  vm_count            = var.windows_vm_count
  secret              = [azurerm_resource_group.hub.name, module.kv.kv_name, "default-vm-access"]

  application = "clients"
  environment = "poc001"
  location    = var.location
  visibility  = var.visibility
  depends_on  = [module.kv]
}

module "oracle-database" {
  source              = "../oracle-db-v1"
  resource_group_name = azurerm_resource_group.hub.name
  subnet_id           = module.hub.subnet_id
  vm_size             = "Standard_E2s_v3"
  vm_image            = ["Oracle", "oracle-database-19-3", "oracle-database-19-0904", "latest"]
  vm_count            = var.oracle_vm_count
  volume_size         = ["512", "128"]
  secret              = [azurerm_resource_group.hub.name, module.kv.kv_name, "default-vm-access"]

  application = "oracle"
  environment = "poc001"
  location    = var.location
  visibility  = var.visibility
  depends_on  = [module.kv]
}
