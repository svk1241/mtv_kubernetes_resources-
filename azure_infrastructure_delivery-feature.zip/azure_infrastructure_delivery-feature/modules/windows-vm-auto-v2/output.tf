output "wm_id" {
  value = azurerm_windows_virtual_machine.win-vm.*.id
}