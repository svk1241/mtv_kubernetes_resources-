variable "resource_group_name" { type = string }
variable "vm_size" { type = string }
variable "vm_image_id" { type = string }
variable "subnet_id" { type = string }
variable "secret" { type = list(any) }

variable "application" { type = string }
variable "environment" { type = string }
variable "location" { type = string }
variable "visibility" { type = string }
variable "name_prefix" { type = string }
variable "instance_count" { type = number }
variable "start_count_number" { type = number }

variable "ppg_id" {
  type    = string
  default = ""
}

variable "use_accelerated_networking" {
  type    = bool
  default = false
}