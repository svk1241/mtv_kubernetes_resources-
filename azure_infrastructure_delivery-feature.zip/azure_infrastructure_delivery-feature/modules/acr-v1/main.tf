module "naming" {
  source = "../terraform-azurerm-naming"
  suffix = [var.application, var.environment, var.location, var.visibility]
}

resource "azurerm_container_registry" "this" {
  name                = module.naming.container_registry.name_unique
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "Premium"
  admin_enabled       = true

  network_rule_set {
    default_action = "Allow"
  }
}