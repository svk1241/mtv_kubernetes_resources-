variable "resource_group_name" { type = string }

variable "application" { type = string }
variable "environment" { type = string }
variable "location" { type = string }
variable "visibility" { type = string }

variable "roles_assignment" {
  description = "acr roles assignment"
  type = list(object({
    role      = string # role can be 'AcrPush', 'AcrPull', 'AcrDelete'
    client_id = string
  }))

  default = []
}
