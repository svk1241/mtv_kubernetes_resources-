terraform {
  required_version = "~>0.14.0"
  
  required_providers {
    azurerm = {
      version = "~>2.51.0"
    }
    random = {
      version = "~> 2.2"
    }
  }
}

provider "azurerm" {
  subscription_id = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
  features {}
}
