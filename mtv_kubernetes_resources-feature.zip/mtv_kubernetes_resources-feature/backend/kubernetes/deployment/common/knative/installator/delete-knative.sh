#! /bin/bash

current_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
version=$(kubectl get namespace knative-serving -o 'go-template={{index .metadata.labels "app.kubernetes.io/version"}}')

usage () {
    echo "USAGE: ${BASH_SOURCE[0]} -v <knative-version>"
    echo
    echo "    -v - (optional) specify Knative version. By default script attempt to detect currently installed version from cluster."
    exit 0
}

while getopts ":v:h" opt; do
  case $opt in
    v) version="$OPTARG"
    ;;
    h) usage
    ;;
    *) echo "Invalid option -$OPTARG !"
       echo "Use -h key to get usage information."
       exit 1
    ;;
  esac
done

if [[ ! $version =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]  # Ensure Knative version is in semver format xx.yy.zz
then
  echo "Script was unable to detect Knative version. Use -h option to get list of valid options."
  exit 1
fi

manifests_dir="$current_dir/knative-manifests/$version"

##############################################
echo "[1/6] Backuping existing ConfigMaps . . ."

mkdir -p $manifests_dir/backup/{knative,istio}

for cm in $(kubectl get cm -n knative-serving | grep config | cut -d' ' -f1); do
    echo "Creating backup for $cm"
    config_backup="kubectl get cm $cm -o yaml -n knative-serving > $manifests_dir/backup/knative/$cm.yaml"
    eval $config_backup
done

for cm in $(kubectl get cm -n istio-system | grep istio | cut -d' ' -f1); do
    echo "Creating backup for $cm"
    config_backup="kubectl get cm $cm -o yaml -n istio-system > $manifests_dir/backup/istio/$cm.yaml"
    eval $config_backup
done
##############################################

##############################################
echo "[2/6] Deleting existing Knative services . . ."

kubectl get ksvc --all-namespaces --no-headers | while read -r svc; do
    ns=$(echo $svc | awk '{print $1}')
    svc_name=$(echo $svc | awk '{print $2}')
    delete_svc="kubectl delete ksvc $svc_name -n $ns"
    eval $delete_svc
done

kubectl get vs --all-namespaces --no-headers | while read -r vs; do
    vs_ns=$(echo $vs | awk '{print $1}')
    vs_name=$(echo $vs | awk '{print $2}')
    delete_vs="kubectl delete vs $vs_name -n $vs_ns"
    eval $delete_vs
done

while [ "$(kubectl get ksvc --all-namespaces | wc -l)" != 0 ]; do
    echo "Waiting for ksvc resources removal"
    sleep 5
done

while [ "$(kubectl get vs --all-namespaces | wc -l)" != 0 ]; do
    echo "Waiting for vs resources removal"
    sleep 5
done

while [ "$(kubectl get kingress --all-namespaces | wc -l)" != 0 ]; do
    echo "Waiting for kingress resources removal"
    sleep 5
done

while [ "$(kubectl get rt --all-namespaces | wc -l)" != 0 ]; do
    echo "Waiting for rt resources removal"
    sleep 5
done

echo "Knative services were deleted!"
##############################################

##############################################
echo "[3/6] Uninstalling Knative-serving . . ."
kubectl delete -f $manifests_dir/yamls/serving-core.yaml
if [[ $version != "0.23.0" ]]; then
    kubectl delete -f $manifests_dir/yamls/serving-webhooks.yaml
fi
##############################################

##############################################
echo "[4/6] Deleting Istio . . ."
echo "Uninstalling core Istio"
kubectl delete -f $manifests_dir/yamls/istio.yaml
echo "Uninstalling Knative controller"
kubectl delete -f $manifests_dir/yamls/net-istio.yaml
if [[ $version != "0.23.0" ]]; then
    kubectl delete -f $manifests_dir/yamls/net-istio-webhooks.yaml
fi
##############################################

##############################################
echo "[5/6] Deleting Istio CRDs . . ."
kubectl delete -f $manifests_dir/yamls/istio-crds.yaml
##############################################

##############################################
echo "[6/6] Deleting Knative CRDs . . ."
kubectl delete -f $manifests_dir/yamls/serving-crds.yaml
kubectl delete -f $manifests_dir/yamls/serving-ns.yaml
kubectl delete -f $manifests_dir/yamls/istio-ns.yaml
##############################################
echo "Waiting for Knative to become uninstalled . . ."
sleep 80
echo "[SUCCESS] Uninstallation completed!"
