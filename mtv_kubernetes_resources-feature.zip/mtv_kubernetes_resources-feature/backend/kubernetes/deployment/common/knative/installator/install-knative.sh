#! /bin/bash -e

usage () {
    echo "USAGE: ${BASH_SOURCE[0]} -d <example.url> -v <knative-version> [-n <node-label>:<value>] -i <istio-registry> -k <knative-registry>"
    echo
    echo "    -d - (required) specify DNS suffix for Knative services."
    echo "    -v - (optional) specify Knative version. Default value: latest. Latest means the most recent supported version in knative-manifests folder."
    echo "    -n - (optional) specify label of nodes to deploy Knative on. This parameter will be placed in nodeSelector key in YAML files. Default value: kubernetes.azure.com/mode=system"
    echo "    -i - (optional) specify Registry for Istio images. This parameter will be placed in image URL in istio.yaml file. Default value: docker.io"
    echo "    -k - (optional) specify Registry for Knative images. This parameter will be placed in image URL in net-istio and serving-core YAML files. Default value: gcr.io"
    exit 0
}

current_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
node="kubernetes.azure.com/mode:system"
version="latest"

while getopts ":d:v:n:i:k:h" opt; do
  case $opt in
    d) dns="$OPTARG"
    ;;
    v) version="$OPTARG"
    ;;
    n) node="$OPTARG"
    ;;
    i) istio_registry="$OPTARG"
    ;;
    k) knative_registry="$OPTARG"
    ;;
    h) usage
    ;;    
    *) echo "Invalid option -$OPTARG !"
       echo "Use -h key to get usage information."
       exit 1
    ;;
  esac
done

if [[ $version == "latest" ]]; then
    version=$(ls -v $current_dir/knative-manifests | sort -V | tail -1 )
fi

if [[ $dns == '' ]]; then
    usage
    exit 1
fi

if [[ $knative_registry == '' ]]; then
    knative_registry="gcr.io"
fi

if [[ $istio_registry == '' ]]; then
    istio_registry="docker.io"
fi

echo "DNS suffix for Knative services: $dns"
echo "Knative version to install: $version"
echo "Node pool to deploy Knative: $node"
echo "Registry for Istio images: $istio_registry"
echo "Registry for Knative images: $knative_registry"

manifests_dir="$current_dir/knative-manifests/$version"

IFS=':' read -a nodearg <<< "$node"
node_tag_key="${nodearg[0]}"
node_tag_value="${nodearg[1]}"

key_content=$(cat $current_dir/certificates/key.pem)
cert_content=$(cat $current_dir/certificates/cert.pem)

if [[ $key_content == '' || $cert_content == '' ]]; then
    echo "Error! Certificate or key content is empty under certificates folder. Please, update these files with right values. Exiting . . ."
    exit 1
fi

echo "Preparing deployment yaml files from templates . . ."
rm -rf $manifests_dir/yamls
mkdir -p $manifests_dir/yamls

cp $manifests_dir/files/* $manifests_dir/yamls/
cp $manifests_dir/templates/istio-tmpl.yaml $manifests_dir/yamls/istio.yaml
cp $manifests_dir/templates/net-istio-tmpl.yaml $manifests_dir/yamls/net-istio.yaml
cp $manifests_dir/templates/serving-core-tmpl.yaml $manifests_dir/yamls/serving-core.yaml

sed -i "s|<placeholder>|${node_tag_key}: ${node_tag_value}|g" $manifests_dir/yamls/istio.yaml $manifests_dir/yamls/net-istio.yaml $manifests_dir/yamls/serving-core.yaml
sed -i "s|<knative_registry>|${knative_registry}|g" $manifests_dir/yamls/net-istio.yaml $manifests_dir/yamls/serving-core.yaml
sed -i "s|<istio_registry>|${istio_registry}|g" $manifests_dir/yamls/istio.yaml

echo "Creating namespaces"
kubectl apply -f $manifests_dir/yamls/serving-ns.yaml
kubectl apply -f $manifests_dir/yamls/istio-ns.yaml

##############################################
echo "[1/4] Adding Istio CRDs . . ."
kubectl apply -f $manifests_dir/yamls/istio-crds.yaml
##############################################

##############################################
echo "[2/4] Adding Knative CRDs . . ."
kubectl apply -f $manifests_dir/yamls/serving-crds.yaml
##############################################

echo "Waiting for CRDs to become ready . . ."
sleep 5

##############################################
echo "[3/4] Installing Istio . . ."
echo "Installing core Istio"
kubectl apply -f $manifests_dir/yamls/istio.yaml

##############################################
echo "[4/4] Installing Knative-serving . . ."
kubectl apply -f $manifests_dir/yamls/serving-core.yaml
sleep 5
if [[ $version != "0.23.0" ]]; then
    kubectl apply -f $manifests_dir/yamls/serving-webhooks.yaml
fi
kubectl apply -f $manifests_dir/yamls/net-istio.yaml
sleep 5
if [[ $version != "0.23.0" ]]; then
    kubectl apply -f $manifests_dir/yamls/net-istio-webhooks.yaml
fi
##############################################

echo "Configuring DNS"
json="'{\"data\":{\"${dns}\":\"\"}}'"
patch_cm="kubectl patch configmap/config-domain --namespace knative-serving --type merge --patch $json"
eval $patch_cm
echo "Creating TLS secrets"
kubectl create --namespace istio-system secret tls tls-cert --key $current_dir/certificates/key.pem --cert $current_dir/certificates/cert.pem
##############################################
echo "Waiting for resources to become ready . . ."
sleep 15
echo "[SUCCESS] Installation completed!"
echo

external_ip=$(kubectl --namespace istio-system get service istio-ingressgateway --output jsonpath='{.status.loadBalancer.ingress[0].ip}')

echo "Next Steps:"

echo
echo "1) Update Knative ingress gateway to serve HTTPS"
echo

echo "2) Add corresponding record in your DNS system using IP address below:"
echo "  -------------------------------------------------------------"
echo "  | External IP address for the IngressGateway | $external_ip |"
echo "  -------------------------------------------------------------"
