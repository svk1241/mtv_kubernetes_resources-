#!/bin/bash

#TODO: we need to change yaml generator to get array of ingress hosts and change this variable to array aftewards
export ingress_host=$(cat <<EOF
dev.ddmtv.private
  - dev-aks003.ddmtv.private
EOF
)
export knative_domain=knative.aks003.ddmtv.private
export https_wrapper_image=acrregistryhubeastusprivatew4ft.azurecr.io/https-wrapper-deltadental:v.XX.XX
export transaction_enabler_image=acrregistryhubeastusprivatew4ft.azurecr.io/transaction-enabler-deltadental:v.XX.XX
export batch_image=acrregistryhubeastusprivatew4ft.azurecr.io/mtv-backend-batch:v.XX.XX
export infrastructure_image=acrregistryhubeastusprivatew4ft.azurecr.io/mtv-backend-infrastructure:v.XX.XX
export batch_claim_name=batchpvcdev
export batch_temp_claim_name=batchtemppvcdev
export batch_pv_name=batchpvdev
export batch_temp_pv_name=batchtemppvdev
export batch_pv_source=batchdev
export batch_pv_temp_source=tempdev
export batch_namespace=batch-dev
export batch_ingress_host=batch-dev.ddmtv.private
export batch_node_selector="purpose: dev"
export infrastructure_namespace=batch-dev
export infrastructure_ingress_host=infrastructure-dev.ddmtv.private
export infrastructure_node_selector="purpose: dev"
export online_namespace=online-dev
export online_node_selector="purpose: dev"
export environment_label=dev
export online_toleration="dev"
export batch_toleration="dev"
export tracing_backend="http://monitoring-grafana-tempo-distributor.monitoring.svc.cluster.local:9411/api/v2/spans"
export extensions_wrapper_server_host="extensions-service.extensions-service-dev.svc.cluster.local"

# Request and limits settings

# Online

export https_wrapper_cpu_request="50m"
export https_wrapper_cpu_limit="100m"
export https_wrapper_memory_request="50Mi"
export https_wrapper_memory_limit="100Mi"

export transaction_enabler_cpu_request="100m"
export transaction_enabler_cpu_limit="300m"
export transaction_enabler_memory_request="200Mi"
export transaction_enabler_memory_limit="250Mi"

# Batch

export batch_cpu_request="2"
export batch_cpu_limit="2.5"
export batch_memory_request="2Gi"
export batch_memory_limit="2.5Gi"
