#!/bin/bash

#TODO: we need to change yaml generator to get array of ingress hosts and change this variable to array aftewards
export ingress_host=$(cat <<EOF
extensions.ddmtv.private
  - extensions-aks002.ddmtv.private
EOF
)
export knative_domain=knative.aks002.ddmtv.private
export https_wrapper_image=acrregistryhubeastusprivatew4ft.azurecr.io/https-wrapper-deltadental:v.XX.XX
export transaction_enabler_image=acrregistryhubeastusprivatew4ft.azurecr.io/transaction-enabler-deltadental:v.XX.XX
export batch_image=acrregistryhubeastusprivatew4ft.azurecr.io/mtv-backend-batch:v.XX.XX
export infrastructure_image=acrregistryhubeastusprivatew4ft.azurecr.io/mtv-backend-infrastructure:v.XX.XX
export batch_claim_name=batchpvcextensions
export batch_temp_claim_name=batchtemppvcextensions
export batch_namespace=batch-extensions
export batch_ingress_host=batch-extensions.ddmtv.private
export batch_node_selector="purpose: extensions"
export infrastructure_namespace=batch-extensions
export infrastructure_ingress_host=infrastructure-extensions.ddmtv.private
export infrastructure_node_selector="purpose: extensions"
export online_namespace=online-extensions
export online_node_selector="purpose: extensions"
export environment_label=extensions
export online_toleration="extensions"
export batch_toleration="extensions"
export tracing_backend="http://monitoring-grafana-tempo-distributor.monitoring.svc.cluster.local:9411/api/v2/spans"
export extensions_wrapper_server_host="extensions-service.extensions-service-extensions.svc.cluster.local"

# Request and limits settings

# Online

export https_wrapper_cpu_request="50m"
export https_wrapper_cpu_limit="100m"
export https_wrapper_memory_request="50Mi"
export https_wrapper_memory_limit="100Mi"

export transaction_enabler_cpu_request="100m"
export transaction_enabler_cpu_limit="300m"
export transaction_enabler_memory_request="200Mi"
export transaction_enabler_memory_limit="250Mi"

# Batch

export batch_cpu_request="2"
export batch_cpu_limit="2.5"
export batch_memory_request="2Gi"
export batch_memory_limit="2.5Gi"
