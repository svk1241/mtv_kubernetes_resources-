#!/bin/bash

#TODO: we need to change yaml generator to get array of ingress hosts and change this variable to array aftewards
export ingress_host=$(cat <<EOF
regression.ddmtv.private
  - regression-aks002.ddmtv.private
EOF
)
export knative_domain=knative.aks002.ddmtv.private
export https_wrapper_image=acrregistryhubeastusprivated9f2.azurecr.io/https-wrapper-deltadental:v.XX.XX
export transaction_enabler_image=acrregistryhubeastusprivated9f2.azurecr.io/transaction-enabler-deltadental:v.XX.XX
export batch_image=acrregistryhubeastusprivated9f2.azurecr.io/mtv-backend-batch:v.XX.XX
export infrastructure_image=acrregistryhubeastusprivated9f2.azurecr.io/mtv-backend-infrastructure:v.XX.XX
export batch_claim_name=batchpvcregression
export batch_temp_claim_name=batchtemppvcregression
export batch_namespace=batch-regression
export batch_ingress_host=batch-regression.ddmtv.private
export batch_node_selector="purpose: regression"
export infrastructure_namespace=batch-regression
export infrastructure_ingress_host=infrastructure-regression.ddmtv.private
export infrastructure_node_selector="purpose: regression"
export online_namespace=online-regression
export online_node_selector="purpose: regression"
export environment_label=regression
export online_toleration="regression"
export batch_toleration="regression"
export tracing_backend="http://monitoring-grafana-tempo-distributor.monitoring.svc.cluster.local:9411/api/v2/spans"
export extensions_wrapper_server_host="extensions-service.extensions-service-extensions-regression.svc.cluster.local"

# Request and limits settings

# Online

export https_wrapper_cpu_request="50m"
export https_wrapper_cpu_limit="100m"
export https_wrapper_memory_request="50Mi"
export https_wrapper_memory_limit="100Mi"

export transaction_enabler_cpu_request="100m"
export transaction_enabler_cpu_limit="300m"
export transaction_enabler_memory_request="200Mi"
export transaction_enabler_memory_limit="250Mi"

# Batch

export batch_cpu_request="2"
export batch_cpu_limit="2.5"
export batch_memory_request="2Gi"
export batch_memory_limit="2.5Gi"
