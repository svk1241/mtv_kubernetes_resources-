#!/bin/bash

#TODO: we need to change yaml generator to get array of ingress hosts and change this variable to array aftewards
export ingress_host=$(cat <<EOF
integration.ddmtv.private
  - integration-86-1.ddmtv.private
  - integration-86-1-aks002.ddmtv.private
EOF
)
export knative_domain=knative.aks002.ddmtv.private
export https_wrapper_image=acrregistryhubeastusprivated9f2.azurecr.io/https-wrapper-deltadental:v.XX.XX
export transaction_enabler_image=acrregistryhubeastusprivated9f2.azurecr.io/transaction-enabler-deltadental:v.XX.XX
export batch_image=acrregistryhubeastusprivated9f2.azurecr.io/mtv-backend-batch:v.XX.XX
export infrastructure_image=acrregistryhubeastusprivated9f2.azurecr.io/mtv-backend-infrastructure:v.XX.XX
export batch_claim_name=batchpvc86
export batch_temp_claim_name=batchtemppvc86
export batch_namespace=batch-integration-86-1
export batch_ingress_host=batch-integration-86-1.ddmtv.private
export batch_node_selector="purpose: integration86"
export infrastructure_namespace=batch-integration-86-1
export infrastructure_ingress_host=infrastructure-integration-86-1.ddmtv.private
export infrastructure_node_selector="purpose: integration86"
export online_namespace=online-integration-86-1
export online_node_selector="purpose: integration86"
export environment_label=integration-86-1
export online_toleration="integration86"
export batch_toleration="integration86"
export tracing_backend="http://monitoring-grafana-tempo-distributor.monitoring.svc.cluster.local:9411/api/v2/spans"
export extensions_wrapper_server_host="extensions-service.extensions-service-extensions-integration.svc.cluster.local"

# Request and limits settings

# Online

export https_wrapper_cpu_request="50m"
export https_wrapper_cpu_limit="100m"
export https_wrapper_memory_request="50Mi"
export https_wrapper_memory_limit="100Mi"

export transaction_enabler_cpu_request="100m"
export transaction_enabler_cpu_limit="300m"
export transaction_enabler_memory_request="200Mi"
export transaction_enabler_memory_limit="250Mi"

# Batch

export batch_cpu_request="2"
export batch_cpu_limit="2.5"
export batch_memory_request="2Gi"
export batch_memory_limit="2.5Gi"
