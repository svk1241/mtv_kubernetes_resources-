#!/bin/bash

# Main cluster environmental variables
export ingress_host=ddhcionline-extensions.grnmtvhci.com.ddmtv.private
export knative_domain=knative.grnmtvhci.com
export https_wrapper_image=acreastuspublicdd.azurecr.io/mtv-backend-https-wrapper-deltadental:v.XX.XX
export transaction_enabler_image=acreastuspublicdd.azurecr.io/mtv-transaction-enabler-deltadental-extensions:v.XX.XX
export batch_image=acreastuspublicdd.azurecr.io/mtv-backend-batch-deltadental-extensions:v.XX.XX
export infrastructure_image=acreastuspublicdd.azurecr.io/mtv-backend-infrastructure:v.XX.XX
export batch_claim_name=batch-storage-extensions
export batch_temp_claim_name=batch-tempstorage-extensions
export batch_namespace=ddhcibatch-extensions
export batch_node_selector="purpose: batch"
export batch_toleration="batch"
export infrastructure_namespace=ddhcibatch-extensions
export infrastructure_ingress_host=infrastructure-ddhcionline-extensions.grnmtvhci.com.ddmtv.private
export infrastructure_node_selector="purpose: batch"
export online_namespace=ddhcionline-extensions
export online_node_selector="purpose: online"
export online_toleration="online"
export environment_label=DDHCITestingGRNExtensions
export tracing_backend="http://otel-collector.telemetry.svc.cluster.local:9411/api/v2/spans"
export extensions_wrapper_server_host="extensions-service.ddhciextensions-extensions.svc.cluster.local"

# Request and limits settings

# Online

export https_wrapper_cpu_request="50m"
export https_wrapper_cpu_limit="100m"
export https_wrapper_memory_request="50Mi"
export https_wrapper_memory_limit="100Mi"

export transaction_enabler_cpu_request="100m"
export transaction_enabler_cpu_limit="300m"
export transaction_enabler_memory_request="200Mi"
export transaction_enabler_memory_limit="500Mi"

# Batch

export batch_cpu_request="2"
export batch_cpu_limit="10"
export batch_memory_request="2Gi"
export batch_memory_limit="50Gi"
