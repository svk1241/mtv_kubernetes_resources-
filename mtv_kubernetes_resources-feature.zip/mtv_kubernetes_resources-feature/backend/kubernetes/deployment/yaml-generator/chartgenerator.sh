#!/bin/bash

if [[ $# -lt 1 ]];then
  echo "Invalid number of arguments!"
  echo "Usage: ./chartgenerator.sh [output chart folder path]"
  echo
  exit 1
fi

# Setup
BASE_PATH="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
CHART_PATH=$1
APP_VERSION="20.20"

# Clean-up
rm -r $CHART_PATH > /dev/null 2>&1

# Create folder structure
mkdir -p $CHART_PATH
mkdir -p $CHART_PATH/templates

cp $BASE_PATH/templates/chart-tmpl.yaml $CHART_PATH/Chart.yaml
sed -i "s/<placeholder>/$APP_VERSION/g" $CHART_PATH/Chart.yaml

# Create Kubernetes manifests
$BASE_PATH/autogenerator.sh $CHART_PATH/templates