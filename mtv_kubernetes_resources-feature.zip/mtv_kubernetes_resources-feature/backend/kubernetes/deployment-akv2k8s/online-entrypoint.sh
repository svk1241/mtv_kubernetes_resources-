#!/bin/bash
cp -L /opt/MTV/aeenv-secret/aeenv /opt/MTV/m210/online/aeenv

echo "$TNSNAMES" > /usr/lib/oracle/19.3/client64/lib/network/admin/tnsnames.ora
echo "$MQSECRET" | base64 -d > /var/mqm/AMQCLCHL.TAB
chmod 777 /var/mqm/AMQCLCHL.TAB
chown mqm:mqm /var/mqm/AMQCLCHL.TAB
unset TNSNAMES
unset MQSECRET

env > /app/env

crond

/opt/MTV/m210/online/run_tranEnab.sh

tail -qF ./lg-*