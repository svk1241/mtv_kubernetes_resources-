#!/bin/bash

echo "$MQSECRET" | base64 -d > /var/mqm/AMQCLCHL.TAB
echo "$TNSNAMES" > /usr/lib/oracle/19.3/client64/lib/network/admin/tnsnames.ora
chmod 777 /var/mqm/AMQCLCHL.TAB
chown mqm:mqm /var/mqm/AMQCLCHL.TAB
unset TNSNAMES
unset MQSECRET

/sbin/sshd -D -e -f /etc/ssh/sshd_config