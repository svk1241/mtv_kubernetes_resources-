#!/bin/bash

source ./check_running.sh

is_all_listening() {
  lsof -i -P -n | grep "*:2888 (LISTEN)" >/dev/null  &&  lsof -i -P -n | grep "*:3888 (LISTEN)" >/dev/null
}


send_request_with_restart_script() {
  sleep 0.8
  curl http://$1:$2/restart_te
  return 0
}


restart_if_failed() {
  if is_running
  then
    sleep 0.8
    return 0
  else
    echo "{\"timestamp\":\"$( date )\", \"message\": \"Restarting TE from cron due to process failure\"}"
    send_request_with_restart_script $1 $2
  fi
}


while true
do
 restart_if_failed $1 $2
done
