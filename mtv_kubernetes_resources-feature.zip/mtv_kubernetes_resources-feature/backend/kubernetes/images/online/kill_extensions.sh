#!/bin/bash

kill_extensions() {
    signal=$1

    pkill -$signal fas
    pkill -$signal npf
    pkill -$signal cas
    pkill -$signal ips

    sleep 0.5
}