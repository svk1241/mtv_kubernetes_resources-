#!/bin/bash -e

handle_term() {
	echo "SIGTERM received, exiting . . ."
	kill -TERM $pid 2>/dev/null
}

function process_ddext_logs() {
    while true; do
      tail -qF -n 0 $1 | /app/xml_logs_processor.sh
    done
}

trap handle_term SIGTERM

cp -L /opt/mqsecret/AMQCLCHL.TAB /var/mqm/
chmod 777 /var/mqm/AMQCLCHL.TAB
chown mqm:mqm /var/mqm/AMQCLCHL.TAB


sed -i "s|$| ${aeenv_creds}|g" /app/aeenv.template
mv /app/aeenv.template /opt/MTV/m210/online/aeenv
unset aeenv_creds

env > /app/env

. ./run_tranEnab.sh

ip=127.0.0.1
port=8080

if [ "${RUN_RESTART_WATCHER}" = "true" ]
then
  ./check_tranEnab.sh $ip $port &
fi

/app/te_restarter --script-folder /app --ip $ip --port $port --json > ./lg-te-restarter.log  2>&1 &

sleep 0.5

mkdir -p ${MTV_EXTENSIONS_LOG_FOLDER}

MTV_EXTENSIONS_LOGS=($MTV_EXTENSIONS_LOGS)

for file in "${MTV_EXTENSIONS_LOGS[@]}"; do
    touch "${MTV_EXTENSIONS_LOG_FOLDER}/${file}"

    if [[ $file == "ddext1.log" ]] || [[ $file == "ddext2.log" ]]; then
        process_ddext_logs "${MTV_EXTENSIONS_LOG_FOLDER}/${file}" &
    else
        MTV_OBSERVED_FILES="${MTV_OBSERVED_FILES} ${MTV_EXTENSIONS_LOG_FOLDER}/${file}"
    fi
done

while true; do
  tail -qF -n 0 ./lg-te-restarter.log ${MTV_OBSERVED_FILES} &
  pid=$!

  wait $pid
done
