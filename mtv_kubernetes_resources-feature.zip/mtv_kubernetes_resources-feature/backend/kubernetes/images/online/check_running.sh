#!/bin/bash

is_running() {
  is_running_all
}

is_running_all() {
  pidof aefad  >/dev/null  &&  pidof aefuf  >/dev/null
}

is_running_extensions() {
  pidof fas  >/dev/null  ||  pidof npf  >/dev/null || pidof cas  >/dev/null || pidof ips  >/dev/null
}

is_running_at_least_one() {
  pidof aefad  >/dev/null  ||  pidof aefuf  >/dev/null || is_running_extensions
}