#!/bin/bash
cd /app || exit
while read line; do export "${line?}"; done < /app/env

# path to CA Gen runtime
export IEFH=/opt/CA/CAGen/runtime
export LD_LIBRARY_PATH="/mtv/ddx/lib:${LD_LIBRARY_PATH}:/opt/CA/CAGen/runtime:/opt/CA/CAGen/runtime/lib:/opt/mqm/lib64:/opt/MTV/m210/lib"

# built binaries will be in ${AEPATH}/inqload
export AEPATH=/opt/MTV/m210/online
# path to "codepage translation files"
export IEFGXTP=/opt/CA/CAGen/runtime/translat/
# MQ client variable
export SHLIB_PATH=$SHLIB_PATH:/opt/mqm/lib64
export PATH=$PATH:/opt/mqm/bin

export TNS_ADMIN=/usr/lib/oracle/19.3/client64/lib/network/admin

export DDXDIR=/mtv/ddx


# *_PRELOAD_TCP_NODELAY_ENABLED parameter enables TCP_NODELAY socket option to reduce latency
# listen on 2888
if [[ ${AEFAD_PRELOAD_TCP_NODELAY_ENABLED} == "true" ]]; then
    LD_PRELOAD=./preload_tcp_nodelay.so /opt/CA/CAGen/runtime/bin/aefad -h 0.0.0.0 -i 2888 -t "${TE_LOG_LEVEL}" -a "${TE_CONCURRENT_LOAD_MODULES}" ${TE_AEFAD_PARAMS} >>/proc/1/fd/1 2>>/proc/1/fd/2
else
    /opt/CA/CAGen/runtime/bin/aefad -h 0.0.0.0 -i 2888 -t "${TE_LOG_LEVEL}" -a "${TE_CONCURRENT_LOAD_MODULES}" ${TE_AEFAD_PARAMS} >>/proc/1/fd/1 2>>/proc/1/fd/2
fi

# listen on 3888 and forward to 2888
if [[ ${AEFUF_PRELOAD_TCP_NODELAY_ENABLED} == "true" ]]; then
    LD_PRELOAD=./preload_tcp_nodelay.so /opt/CA/CAGen/runtime/bin/aefuf -i 3888 -c 2888 -t "${TE_LOG_LEVEL}" ${TE_AEFUF_PARAMS} >>/proc/1/fd/1 2>>/proc/1/fd/2
else
    /opt/CA/CAGen/runtime/bin/aefuf -i 3888 -c 2888 -t "${TE_LOG_LEVEL}" ${TE_AEFUF_PARAMS} >>/proc/1/fd/1 2>>/proc/1/fd/2
fi


