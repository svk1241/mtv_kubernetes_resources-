curl -H 'X-JFrog-Art-Api:AKCp8k8Z97sAVZVmcBfA43awtufxqkfbHJow3kQTXRX5PnPEWQbjJhe8d3oV8mQx1iiUe5y47' -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/builds/v.XX.XX/OnlineTransactionsP10.v.XX.XX.tar.gz'
curl -H 'X-JFrog-Art-Api:AKCp8k8Z97sAVZVmcBfA43awtufxqkfbHJow3kQTXRX5PnPEWQbjJhe8d3oV8mQx1iiUe5y47' -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/builds/v.XX.XX/libs.v.XX.XX.tar.gz'
curl -H 'X-JFrog-Art-Api:AKCp8k8Z97sAVZVmcBfA43awtufxqkfbHJow3kQTXRX5PnPEWQbjJhe8d3oV8mQx1iiUe5y47' -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/builds/v.XX.XX/aeenv.v.XX.XX'
curl -H 'X-JFrog-Art-Api:AKCp8k8Z97sAVZVmcBfA43awtufxqkfbHJow3kQTXRX5PnPEWQbjJhe8d3oV8mQx1iiUe5y47' -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/builds/v.XX.XX/te_restarter.v.XX.XX.tar.gz'
curl -H 'X-JFrog-Art-Api:AKCp8k8Z97sAVZVmcBfA43awtufxqkfbHJow3kQTXRX5PnPEWQbjJhe8d3oV8mQx1iiUe5y47' -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/builds/v.XX.XX/preload_tcp_nodelay.v.XX.XX.tar.gz'
curl -H 'X-JFrog-Art-Api:AKCp8k8Z97sAVZVmcBfA43awtufxqkfbHJow3kQTXRX5PnPEWQbjJhe8d3oV8mQx1iiUe5y47' -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/builds/v.XX.XX/libs-extensions.v.XX.XX.tar.gz' && \
    tar -xvzf libs-extensions.v.XX.XX.tar.gz && rm -f libs-extensions.v.XX.XX.tar.gz
curl -H 'X-JFrog-Art-Api:AKCp8k8Z97sAVZVmcBfA43awtufxqkfbHJow3kQTXRX5PnPEWQbjJhe8d3oV8mQx1iiUe5y47' -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/builds/v.XX.XX/appsettings.json'

awk 'NF{NF--};1' aeenv.v.XX.XX > aeenv.template
rm -f aeenv.v.XX.XX
