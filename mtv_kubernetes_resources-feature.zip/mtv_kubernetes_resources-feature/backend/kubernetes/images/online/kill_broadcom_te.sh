#!/bin/bash

kill_broadcom_te() {
    signal=$1

    pkill -$signal aefad
    pkill -$signal aefuf

    sleep 0.5
}