#!/bin/bash -ex
[ -z "$ARTIFACTORY_TOKEN" ] && echo "Variable 'ARTIFACTORY_TOKEN' is empty or absent " && exit 1
curl --fail -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/Oracle/oracle-instantclient19.3-basic-19.3.0.0.0-1.x86_64.rpm'
curl --fail -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/Oracle/oracle-instantclient19.3-sqlplus-19.3.0.0.0-1.x86_64.rpm'
curl --fail -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/Oracle/oracle-instantclient19.3-tools-19.3.0.0.0-1.x86_64.rpm'
curl --fail -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/CAGenRuntime86reduced.tar.gz'
curl --fail -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/backend/MQSeries/MQCLT-v9.3.0-25.tar.gz'
curl --fail -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/builds/v.XX.XX/encryption.v.XX.XX.tar.gz'
curl --fail -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/builds/v.XX.XX/version.txt'
curl --fail -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/builds/v.XX.XX/supported_version.txt'
#curl --fail -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/builds/v.XX.XX/libs-extensions.v.XX.XX.tar.gz' 
