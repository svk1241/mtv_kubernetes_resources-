#!/bin/bash

UNIC=`date +"%Y-%m-%d_%H:%M:%S_%N_%Z"`
R="$RANDOM"
CNT=0

SUB='<?xml version='

while IFS= read -r line; do

    if [[ "$line" == *"$SUB"* ]]; then
        UNIC=`date +"%Y-%m-%d_%H:%M:%S_%N_%Z"`
	    R="$RANDOM"
        CNT=0
    fi

    ((CNT++))
    printf '%05d EXTID-%05d%s\n' "$CNT" "$R" "$UNIC | $line"
done