#!/bin/bash

cp -L /opt/mqsecret/AMQCLCHL.TAB /var/mqm/
chmod 777 /var/mqm/AMQCLCHL.TAB
chown mqm:mqm /var/mqm/AMQCLCHL.TAB

BATCH_DIRS=(backup data datain external otherinput output report restartinput restartoutput userctli temp work)
for i in "${BATCH_DIRS[@]}";
	do mkdir -p "/opt/MTV/m210/batch/${i}";
done 

/usr/bin/ksh export -p |grep -vwE "PATH|HOME" >> /home/batch/.bashrc

chown -R batch:batch /opt/MTV/m210

if [ "${MTV_EXTENSIONS_LOGS_TROUGHPUT_LIMIT}" -gt 0 ]; then
  rm -f "${MTV_EXTENSIONS_MERGED_LOGS_FIFO_DDEXT1}"
  mkfifo "${MTV_EXTENSIONS_MERGED_LOGS_FIFO_DDEXT1}"

  rm -f "${MTV_EXTENSIONS_MERGED_LOGS_FIFO_DDEXT2}"
  mkfifo "${MTV_EXTENSIONS_MERGED_LOGS_FIFO_DDEXT2}"

  rm -f "${MTV_EXTENSIONS_MERGED_LOGS_FIFO_OBSERVED}"
  mkfifo "${MTV_EXTENSIONS_MERGED_LOGS_FIFO_OBSERVED}"
  
  ./log_driver.sh &

  while true; do
    ./logs_limiter.sh < ${MTV_EXTENSIONS_MERGED_LOGS_FIFO_DDEXT1} &
    ./logs_limiter.sh < ${MTV_EXTENSIONS_MERGED_LOGS_FIFO_DDEXT2} &
    ./logs_limiter.sh < ${MTV_EXTENSIONS_MERGED_LOGS_FIFO_OBSERVED}
  done

else
  ./log_driver.sh &
  pid=$!

  wait $pid
fi
