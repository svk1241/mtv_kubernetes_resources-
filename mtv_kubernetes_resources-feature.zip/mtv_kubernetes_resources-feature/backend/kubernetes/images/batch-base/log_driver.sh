#!/bin/bash

function process_ddext1_logs() {
    if [ "${MTV_EXTENSIONS_LOGS_TROUGHPUT_LIMIT}" -gt 0 ]; then
        while true; do
            /app/tools/tail_ddext -qF -n 0 $1 | /app/xml_logs_processor.sh >> "${MTV_EXTENSIONS_MERGED_LOGS_FIFO_DDEXT1}"
        done    
    else
        while true; do
            /app/tools/tail_ddext -qF -n 0 $1 | /app/xml_logs_processor.sh
        done
    fi
}

function process_ddext2_logs() {
    if [ "${MTV_EXTENSIONS_LOGS_TROUGHPUT_LIMIT}" -gt 0 ]; then
        while true; do
            /app/tools/tail_ddext -qF -n 0 $1 | /app/xml_logs_processor.sh >> "${MTV_EXTENSIONS_MERGED_LOGS_FIFO_DDEXT2}"
        done    
    else
        while true; do
            /app/tools/tail_ddext -qF -n 0 $1 | /app/xml_logs_processor.sh
        done
    fi
}

function process_observed_logs() {
    if [ "${MTV_EXTENSIONS_LOGS_TROUGHPUT_LIMIT}" -gt 0 ]; then
        while true; do
            tail -qF -n 0 $1 >> "${MTV_EXTENSIONS_MERGED_LOGS_FIFO_OBSERVED}"
        done
    else
        while true; do
            tail -qF -n 0 $1
        done
    fi
}

mkdir -p ${MTV_EXTENSIONS_LOG_FOLDER}

MTV_EXTENSIONS_LOGS=($MTV_EXTENSIONS_LOGS)

for file in "${MTV_EXTENSIONS_LOGS[@]}"; do
    touch "${MTV_EXTENSIONS_LOG_FOLDER}/${file}"
    if [[ $file == "ddext1.log" ]] || [[ $file == "ddext2.log" ]]; then
        if [[ $file == "ddext1.log" ]]; then
            process_ddext1_logs "${MTV_EXTENSIONS_LOG_FOLDER}/${file}" &
        else
            process_ddext2_logs "${MTV_EXTENSIONS_LOG_FOLDER}/${file}" &
        fi
    else
        MTV_OBSERVED_FILES="${MTV_OBSERVED_FILES} ${MTV_EXTENSIONS_LOG_FOLDER}/${file}"
    fi
done

process_observed_logs "${MTV_OBSERVED_FILES}"
