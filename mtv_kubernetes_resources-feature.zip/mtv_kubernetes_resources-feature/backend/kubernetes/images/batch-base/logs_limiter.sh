#!/bin/bash

if [ "${MTV_EXTENSIONS_LOGS_TROUGHPUT_LIMIT}" -gt 0 ]; then
    pause_s=$(bc <<< "scale=5; 1/${MTV_EXTENSIONS_LOGS_TROUGHPUT_LIMIT}")
else
    pause_s=0
fi

while IFS= read -r line; do
    echo $line
    sleep ${pause_s}
done
