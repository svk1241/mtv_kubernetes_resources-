#!/bin/bash -ex
[ -z "$ARTIFACTORY_TOKEN" ] && echo "Variable 'ARTIFACTORY_TOKEN' is empty or absent " && exit 1
curl --fail -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/backend/tail_ddext/tail_ddext'
curl --fail -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic//builds/v.XX.XX/appsettings.json'
curl --fail -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O  'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/builds/v.XX.XX/libs-extensions.v.XX.XX.tar.gz' 