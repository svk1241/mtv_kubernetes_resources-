#! /bin/bash

/usr/bin/ksh export -p |grep -vwE "PATH|HOME" >> /home/batch/.bashrc

chown -R batch:batch /opt /temp

tail -F /dev/null