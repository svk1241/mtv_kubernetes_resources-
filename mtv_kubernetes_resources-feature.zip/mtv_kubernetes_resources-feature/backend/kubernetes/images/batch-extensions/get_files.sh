#!/bin/bash -ex
[ -z "$ARTIFACTORY_TOKEN" ] && echo "Variable 'ARTIFACTORY_TOKEN' is empty or absent " && exit 1
curl -H "X-JFrog-Art-Api:AKCp8k8Z97sAVZVmcBfA43awtufxqkfbHJow3kQTXRX5PnPEWQbjJhe8d3oV8mQx1iiUe5y47" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/DMExpress/dmexpress-silent-install.sli'
curl -H "X-JFrog-Art-Api:AKCp8k8Z97sAVZVmcBfA43awtufxqkfbHJow3kQTXRX5PnPEWQbjJhe8d3oV8mQx1iiUe5y47" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/DMExpress/dmexpress-silent-uninstall.sli'
curl -H "X-JFrog-Art-Api:AKCp8k8Z97sAVZVmcBfA43awtufxqkfbHJow3kQTXRX5PnPEWQbjJhe8d3oV8mQx1iiUe5y47" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/DMExpress/dmexpress_9-13-11-x64-linux-english.tar'
curl -H "X-JFrog-Art-Api:AKCp8k8Z97sAVZVmcBfA43awtufxqkfbHJow3kQTXRX5PnPEWQbjJhe8d3oV8mQx1iiUe5y47" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/testing/test-scripts.zip' && unzip test-scripts.zip

dos2unix ./*.sli
