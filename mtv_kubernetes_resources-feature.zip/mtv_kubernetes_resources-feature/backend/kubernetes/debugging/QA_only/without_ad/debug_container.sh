#!/bin/bash

usage () {
    echo
    echo "USAGE: ./debug_container.sh -n [NAMESPACE] -p [POD_NAME] -c [TARGET_CONTAINER_NAME]"
    echo
    echo         "-n, --namespace - namespace where pod (POD_NAME) with target container (CONTAINER_NAME) is being deployed."
    echo         "-p, --pod       - Name of Kubernetes pod with target container."
    echo         "-c, --container - Name of target container within the pod."
    echo         "-s, - add SYS_PTRACE privilege"
    echo
}

if [[ $# < 6 ]];then
    echo "Error: Invalid number of arguments!"
    usage
    exit 1
fi

BASE_PATH="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
CONFIG_FILE=${BASE_PATH}/configuration.sh
DEBUG_CONTAINER_NAME="debug-container-$(date +%s)"
STRACE='false'

while [ $# -gt 0 ]; do
  case "$1" in
      -n|--namespace)
        NAMESPACE="$2"
        ;;

      -p|--pod)
        POD="$2"
        ;;

      -c|--container)
        CONTAINER="$2"
        ;;
      -s)
        STRACE="true"
        ;;
      *)
      printf "Error: Unknown argument '$1'. Please refer to the usage instructions."
      usage
      exit 1
  esac
  shift
  shift
done

echo "Namespace provided: $NAMESPACE"
echo "Target pod: $POD"
echo "Target container: $CONTAINER"

source ${CONFIG_FILE}
if [[ $STRACE != 'true' ]];then
    echo "Execute debug w/o SYS_PTRACE"
    kubectl debug -it -n ${NAMESPACE} ${POD} --target ${CONTAINER} --image ${DEBUG_CONTAINER_IMAGE} -- sh
    exit 0
fi

echo "Execute debug with SYS_PTRACE. Event will be audited!"
has_eph_containers=$(kubectl get po -n ${NAMESPACE} ${POD} -o yaml | grep ephemeralContainers)

if [ -z $has_eph_containers ]; then
  read -r -d '' workload << EOM
[{
"op": "add", "path": "/spec",
"value": {
"ephemeralContainers": [{
"command":[ "/bin/sh" ],
"stdin": true, "tty": true,
"image": "${DEBUG_CONTAINER_IMAGE}",
"name": "${DEBUG_CONTAINER_NAME}",
"securityContext": {"capabilities": {"add": ["SYS_PTRACE"]}},
"targetContainerName": "${CONTAINER}" }]}}]
EOM
else
  read -r -d '' workload << EOM
[{
"op": "add", "path": "/spec/ephemeralContainers/-",
"value": {
"command":[ "/bin/sh" ],
"stdin": true, "tty": true,
"image": "${DEBUG_CONTAINER_IMAGE}",
"name": "${DEBUG_CONTAINER_NAME}",
"securityContext": {"capabilities": {"add": ["SYS_PTRACE"]}},
"targetContainerName": "${CONTAINER}" }}]
EOM
fi

curl -k -f -XPATCH -H "Content-Type: application/json-patch+json" \
       --cacert ${CA_CERT} \
       --cert ${USER_CERT} \
       --key ${USER_KEY} \
       "${KUBE_API}/api/v1/namespaces/${NAMESPACE}/pods/${POD}/ephemeralcontainers" \
--data-binary @- << EOF
$workload
EOF

if [[ $? != 0 ]]; then
  echo "Couldn't create debug container, exiting"
  exit 1
fi

state=""
while [ -z $state ]; do
  echo "wait container running"
  sleep 1
  state=$(kubectl get po -n ${NAMESPACE} ${POD} --output  "jsonpath={.status.ephemeralContainerStatuses[?(@.name==\"${DEBUG_CONTAINER_NAME}\")].state.running}")
done
kubectl attach -it -n ${NAMESPACE} ${POD} -c "${DEBUG_CONTAINER_NAME}"
