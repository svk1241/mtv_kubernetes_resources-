#!/bin/bash


KUBE_CONTEXT=$(kubectl config current-context)
KUBE_CLUSTER=$(kubectl config view -o json --output "jsonpath={.contexts[?(@.name==\"${KUBE_CONTEXT}\")].context.cluster}")
KUBE_API=$(kubectl config view -o json --output "jsonpath={.clusters[?(@.name==\"${KUBE_CLUSTER}\")].cluster.server}")
kubectl config view -o json --raw --output "jsonpath={.clusters[?(@.name==\"${KUBE_CLUSTER}\")].cluster.certificate-authority-data}" | base64 -d > ~/.kube/${KUBE_CLUSTER}-cacert.crt
CA_CERT=~/.kube/${KUBE_CLUSTER}-cacert.crt
DEBUG_CONTAINER_IMAGE=..
#Fill for SYS_PTRACE functionality
# Please, refer to kubelogin cashe file and fill the variable with appropriate value
BEARER_TOKEN=..
