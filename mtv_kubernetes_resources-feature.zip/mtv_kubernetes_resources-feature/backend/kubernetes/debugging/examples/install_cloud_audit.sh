#resource group name
RG_NAME=...
# AKS cluster name
AKS_CLUSTER_NAME=...
# Log analytics workspace name
WS_NAME=...
# Diagnosting setting name
DIAG_SETTING_NAME=...
# Creating workspace for logs
az monitor log-analytics workspace create \
    --resource-group $RG_NAME \
    --workspace-name $WS_NAME

# Creating diagnosting setting
az monitor diagnostic-settings create \
    --resource-group $RG_NAME \
    --resource-type "microsoft.containerservice/managedclusters" \
    --resource $AKS_CLUSTER_NAME \
    --name $DIAG_SETTING_NAME \
    --workspace $WS_NAME \
    --logs "[{category:kube-audit-admin,enabled:true,retention-policy:{enabled:false,days:0}}]"
