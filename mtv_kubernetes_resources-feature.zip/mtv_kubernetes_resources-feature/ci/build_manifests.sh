#!/bin/bash -e

BASE_PATH="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
# shellcheck source=/dev/null
source "$BASE_PATH/../build_manifests.sh"

VERSION=$2
HTTPS_WRAPPER_REPO="https-wrapper-deltadental"
HTTPS_WRAPPER_TAG="v.$VERSION"
TRANSACTION_ENABLER_REPO="transaction-enabler-deltadental"
TRANSACTION_ENABLER_TAG="v.$VERSION"
BATCH_REPO="mtv-backend-batch"
BATCH_TAG="v.$VERSION"
INFRASTRUCTURE_TAG="v.$VERSION"

cd $1
cd backend/kubernetes/deployment/yaml-generator && mv -fv ./configs-default/* ./configs/ && cd -
build_manifests aks002 concurrency "$VERSION"
