#! /bin/bash

APP_NAME=$1
REPO=$2
BRANCH=$3
RESOURCES_PATH=$4
DEST=$5

DEST="https://kubernetes.default.svc"

usage () {
        echo " ./create_app.sh [Application] [Repository] [Branch] [Path] [Destination]"
        echo
        echo "   Application - name of ArgoCD application"
        echo "   Repository - URL address of repository which will be tracked by application"
        echo "   Branch - branch name which will be tracked by application"
        echo "   Path - path to directory with Kubernetes manifests inside repository"
        echo "   Destination - target cluster to deploy Kubernetes resources"
        echo
}

if [[ $# < 5 ]]; then
        echo "Invalid number of arguments!"
        usage
        exit 1
fi

echo "Creating application . . ."

argocd app create $APP_NAME --repo $REPO \
                            --path examples \
                            --revision $BRANCH \
                            --dest-server $DEST \
                            --sync-policy automated \
                            --auto-prune \
                            --self-heal
