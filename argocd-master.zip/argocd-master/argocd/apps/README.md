# Creating of ArgoCD applications

There are three general ways to deploy ArgoCD application.

## Creating via UI

Visit page of your ArgoCD and perform corresponding actions as described [here](https://argo-cd.readthedocs.io/en/stable/getting_started/#creating-apps-via-ui).

## Creating via Kubernetes manifest

You can describe an application using Kubernetes manifest:

- Edit corresponding properties in `example-argocd-app.yaml` file
- Execute `kubectl apply -f example-argocd-app.yaml` command

## Creating via CLI

Another option of deploying ArgoCD applications is to use ArgoCD CLI:

- Download ArgoCD CLI as described [here](https://argo-cd.readthedocs.io/en/stable/cli_installation/). 
- Login your CLI with proper credentials by executing command `argocd login <IP address of ArgoCD>`
- Go to path `./argocd/apps`
- Run `create_app.sh` file

*Please note: It is necessary to provide arguments to script `create_app.sh`. Running it without arguments will show usage.*
*Please note [2]: For now destination cluster is hardcoded so the value provided as argument to script will be ignored.*