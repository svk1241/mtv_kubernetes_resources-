[ -z "$ARTIFACTORY_TOKEN" ] && echo "Variable 'ARTIFACTORY_TOKEN' is empty or absent " && exit 1
curl -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/golang/go1.20.10.linux-amd64.tar.gz'
curl -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/CM/rocky8.repo'
cp -r ../../extensions_wrapper_service_src .
