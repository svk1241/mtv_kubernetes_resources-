#!/bin/bash
/app/extserver &
tail -qF /app/appsettings.json
