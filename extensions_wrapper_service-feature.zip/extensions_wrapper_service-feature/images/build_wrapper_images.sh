#!/bin/bash
set -e
VERSION=$1

[ -z "$VERSION" ] && echo "Variable 'VERSION' is empty or absent " && exit 1
[ -z "$ATHENS_USER" ] && echo "Variable 'ATHENS_USER' is empty or absent " && exit 1
[ -z "$ATHENS_PASSWORD" ] && echo "Variable 'ATHENS_PASSWORD' is empty or absent " && exit 1

cd ./base
source ./get_files.sh
az acr build \
    --registry acrregistryhubeastusprivated9f2.azurecr.io \
    --image extensions-wrapper-base:v.${VERSION} \
    .
cd ..
cd ./server
source ./get_files.sh
az acr build \
    --registry acrregistryhubeastusprivated9f2.azurecr.io \
    --image extensions-wrapper-server:v.${VERSION} \
    --build-arg VERSION=$VERSION \
    --build-arg ATHENS_USER=$ATHENS_USER \
    --build-arg ATHENS_PASSWORD=$ATHENS_PASSWORD \
    .
cd ..
