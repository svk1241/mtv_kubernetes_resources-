[ -z "$ARTIFACTORY_TOKEN" ] && echo "Variable 'ARTIFACTORY_TOKEN' is empty or absent " && exit 1
curl -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O "https://artifactory.luxoft.com/ddmtv-generic/builds/v.${EXTENSIONS_VERSION}/ews.tar.gz"
