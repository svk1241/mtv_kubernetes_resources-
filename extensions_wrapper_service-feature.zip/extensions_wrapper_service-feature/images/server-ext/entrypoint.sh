#!/bin/bash

handle_term() {
	echo "SIGTERM received, exiting . . ."
	kill -TERM $pid 2>/dev/null
}

extensions_logs=(${EXTENSIONS_LOG_FILES})

for log in ${extensions_logs[@]}; do
    ln -s ${EXTENSIONS_SHARED_LOG_FOLDER}/${log}_${HOSTNAME} ${EXTENSIONS_LOCAL_LOG_FOLDER}/${log}
done

trap handle_term SIGTERM

/app/extserver &
tail -qF /app/appsettings.json &
pid=$!

wait $pid
