#!/bin/bash
set -e
VERSION=$1
EXTENSIONS_VERSION=$2

[ -z "$VERSION" ] && echo "Variable 'VERSION' is empty or absent " && exit 1
[ -z "$EXTENSIONS_VERSION" ] && echo "Variable 'EXTENSIONS_VERSION' is empty or absent " && exit 1

cd ./server-ext
source ./get_files.sh
az acr build \
    --registry acrregistryhubeastusprivatew4ft.azurecr.io \
    --image extensions-wrapper-server:v.${VERSION}-${EXTENSIONS_VERSION} \
    --build-arg VERSION=$VERSION \
    --build-arg EXTENSIONS_VERSION=$EXTENSIONS_VERSION \
    .
cd ..
