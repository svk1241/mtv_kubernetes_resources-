[ -z "$ARTIFACTORY_TOKEN" ] && echo "Variable 'ARTIFACTORY_TOKEN' is empty or absent " && exit 1
curl -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/CM/rocky8.repo'
curl -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/Oracle/oracle-instantclient19.3-basic-19.3.0.0.0-1.x86_64.rpm'
curl -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/Oracle/oracle-instantclient19.3-sqlplus-19.3.0.0.0-1.x86_64.rpm'
curl -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/Oracle/oracle-instantclient19.3-tools-19.3.0.0.0-1.x86_64.rpm'
curl -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/CAGenRuntime86reduced.tar.gz'
curl -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/backend/MQSeries/MQSeriesClient.tar.gz'
# The only dependency on MTV version, remove or uncomment after testing EAAS-47
# curl -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/builds/v.XX.XX/encryption.v.XX.XX.tar.gz'
