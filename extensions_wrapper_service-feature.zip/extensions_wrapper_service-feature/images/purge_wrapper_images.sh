#!/bin/bash

# List images to be removed
PURGE_CMD="acr purge \
  --filter 'extensions-wrapper-base:v\.[^\.]{11}' \
  --filter 'extensions-wrapper-server:v\.[^\.]{11}' \
  --ago 3d --untagged --dry-run"

# Remove images once
PURGE_CMD="acr purge \
  --filter 'extensions-wrapper-base:v\.[^\.]{11}' \
  --filter 'extensions-wrapper-server:v\.[^\.]{11}' \
  --ago 3d --untagged"

az acr run \
  --cmd "$PURGE_CMD" \
  --registry acrregistryhubeastusprivated9f2 \
  /dev/null

# Schedule image cleanup every week
az acr task create --name weeklyPurgeTask \
  --cmd "$PURGE_CMD" \
  --schedule "0 1 * * Sun" \
  --registry acrregistryhubeastusprivated9f2 \
  --context /dev/null
