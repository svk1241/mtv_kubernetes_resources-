package main

/*
#cgo CFLAGS: -I ./libadapter
#cgo LDFLAGS: -L./bin -ladapter -ldl

#include "allocate_memory.h"
#include "ddext1.h"
#include "ddext2.h"
#include "adapter.h"
*/
import "C"
import (
	"fmt"
	"time"
	"unsafe"

	ci "luxproject.luxoft.com/stash/scm/mpcexp/extensions_control_info.git"
	appconfig "luxproject.luxoft.com/stash/scm/mpcexp/lms_app_config_go.git"
)

func ProduceControlInfo(controlInfo ci.DeltaControlInfoRecord) *C.CONTROL_INFO {
	res := C.allocateItf((C.int)(controlInfo.ServiceLineCount), (C.int)(controlInfo.IgnoredServiceLineCount), (C.int)(controlInfo.ServiceHistoryLineCount))
	return res
}

func DeleteControlInfo(t_ *C.CONTROL_INFO) {
	C.freeItf(t_)
}

func ProduceControlInfoInc(controlInfoInc ci.DeltaControlInfoIncRecord) *C.CONTROL_INFO_INC {
	res := C.allocateItfInc((C.int)(controlInfoInc.ServiceLineCount), (C.int)(controlInfoInc.SubscriberMemberCnt))
	return res
}

func DeleteControlInfoInc(t_ *C.CONTROL_INFO_INC) {
	C.freeItfInc(t_)
}

func NanosecondsToTime(duaration time.Duration) string {
	hours := int(duaration.Hours())
	minutes := int(duaration.Minutes()) % 60
	seconds := int(duaration.Seconds()) % 60
	nanosecondsRemaining := duaration.Nanoseconds() % int64(time.Second)

	return fmt.Sprintf("%02d:%02d:%02d.%09d", hours, minutes, seconds, nanosecondsRemaining)
}

func LoadLibrary(cfg appconfig.AppConfig) {
	libC := cfg.GetValue("PathToExtLibrary", "/opt/CA/CAGen/runtime/lib/libixclusex.so")

	var lib []C.char
	for i := 0; i < len(libC); i++ {
		lib = append(lib, C.char(libC[i]))
	}

	C.load_library(&lib[0])
}

func DeltaExtension1(data *ci.DeltaControlInfoRecord, cfg appconfig.AppConfig, extElapsedMs *string) error {
	tPtr := ProduceControlInfo(*data)
	ci.PointerControlInfo(*data, unsafe.Pointer(tPtr))

	start := time.Now()
	C.use_delta_extension_1(tPtr)
	duration := time.Since(start)
	*extElapsedMs = NanosecondsToTime(duration)

	err := ci.C2GoDeltaControlInfoRecord(unsafe.Pointer(tPtr), data)
	if err != nil {
		return err
	}

	DeleteControlInfo(tPtr)
	return nil
}

func DeltaExtension2(data *ci.DeltaControlInfoIncRecord, cfg appconfig.AppConfig, extElapsedMs *string) error {
	tPtr := ProduceControlInfoInc(*data)
	ci.PointerControlInfoInc(*data, unsafe.Pointer(tPtr))

	start := time.Now()
	C.use_delta_extension_2(tPtr)
	duration := time.Since(start)
	*extElapsedMs = NanosecondsToTime(duration)

	err := ci.C2GoDeltaControlInfoIncRecord(unsafe.Pointer(tPtr), data)
	if err != nil {
		return err
	}

	DeleteControlInfoInc(tPtr)

	return nil
}
