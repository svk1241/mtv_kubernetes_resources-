package main

import (
	"net/http"
)

type HealthHandler struct{}

func (handler *HealthHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	w.WriteHeader(200)
}
