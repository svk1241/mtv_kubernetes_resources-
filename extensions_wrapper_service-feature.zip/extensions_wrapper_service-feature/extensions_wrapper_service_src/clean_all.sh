#!/bin/sh

cd libadapter

make clean

cd ..

make clean
