module extserver
go 1.22

require (
	luxproject.luxoft.com/stash/scm/mpcexp/extensions_control_info.git v1.1.6
	luxproject.luxoft.com/stash/scm/mpcexp/lms_app_config_go.git v1.0.1
	luxproject.luxoft.com/stash/scm/mpcexp/lms_logger_go.git v1.1.1
)

require (
	github.com/MicahParks/jwkset v0.5.19 // indirect
	github.com/MicahParks/keyfunc/v3 v3.3.5
	github.com/golang-jwt/jwt/v5 v5.2.1
	github.com/sirupsen/logrus v1.9.3 // indirect
	golang.org/x/sys v0.13.0 // indirect
	golang.org/x/time v0.5.0 // indirect
)
