package main

import (
	"fmt"
	appconfig "luxproject.luxoft.com/stash/scm/mpcexp/lms_app_config_go.git"
	customlogger "luxproject.luxoft.com/stash/scm/mpcexp/lms_logger_go.git"
	"os"
)

var GlobalLoggingSettings *customlogger.LoggingSettings
var Cfg appconfig.AppConfig

func main() {
	appConfigFile, ok := os.LookupEnv("EXT_APP_CONFIG_PATH")
	if !ok {
		appConfigFile = "/app/appsettings.json"
		fmt.Fprintf(os.Stderr, "Environment variable EXT_APP_CONFIG_PATH not set, reading config from default location %s\n", appConfigFile)
	}
	newJsonConfigSource, _ := appconfig.NewJsonConfigSource(appConfigFile)

	Cfg = appconfig.NewOrderedAppConfig().
		AddSource(appconfig.NewCommandLineConfigSource(os.Args)).
		AddSource(appconfig.NewEnvironmentConfigSource("")).
		AddSource(newJsonConfigSource)

	GlobalLoggingSettings = customlogger.GetLoggingSettings(
		Cfg.GetValue("LogFile", "/tmp/extserver-[TS].log"),
		Cfg.GetValue("LogFormat", ""),
		Cfg.GetValue("Logging.File_LogLevel", "Information"),
		Cfg.GetValue("Logging.Console_LogLevel", "Information"),
		Cfg.GetValue("LogFileTimestampPattern", "[TS]"),
		Cfg.GetValue("LogFileTimestampFormat", "yyyy-MM-dd"),
		Cfg.GetBool("LogFileUseTimestamp", true),
		Cfg.GetBool("LogFileTracing", false),
		Cfg.GetBool("LogUsingConsoleWriteln", true),
		Cfg.GetBool("UseAsyncLog", false),
		int(Cfg.GetInt64("AsyncLogBufferSize", 0)),
	)

	port := Cfg.GetValue("PORT", "8088")

	LoadLibrary(Cfg)

	server := CreateServer(port)
	go server.ListenAndServe()

	select {}

}
