package main

import (
	"fmt"
	"io"
	ci "luxproject.luxoft.com/stash/scm/mpcexp/extensions_control_info.git"
	customlogger "luxproject.luxoft.com/stash/scm/mpcexp/lms_logger_go.git"
	"net/http"
	"os"
	"strings"
	"time"
)

var callUrl string
var date time.Time
var elapsedMs *int
var extElapsedMs string
var hostName string
var httpStatusCodeptr *int
var requestId string
var successfulptr *bool

var logAgs map[string]interface{}

type WrapperHandler struct{}

func InitLogAgs(pLogAgs *map[string]interface{}) {
	*pLogAgs = map[string]interface{}{
		"CallUrl":       &callUrl,
		"ClientId":      nil,
		"Context":       "EWS",
		"Date":          &date,
		"ElapsedMs":     &elapsedMs,
		"Hostname":      &hostName,
		"HttpStatus":    &httpStatusCodeptr,
		"InstanceId":    nil,
		"RequestId":     &requestId,
		"Successful":    &successfulptr,
		"TransactionId": nil,
	}
}

func (handler *WrapperHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	start := time.Now()
	endpoint := GetExtensionEndpoint(r.URL.Path)
	callUrl = r.Header.Get("X-MTV-CallUrl")
	date = time.Now()
	elapsedMs = nil
	var err error
	hostName, err = os.Hostname()
	if err != nil {
		hostName = "env {hostnameEnvVar} is not set"
	}
	httpStatusCodeptr = nil
	requestId = r.Header.Get("X-MTV-RequestId")
	successfulptr = nil

	InitLogAgs(&logAgs)

	log, httpStatusCode, err := CheckContentType(r, logAgs)
	if err != nil {
		log.Error(err)
		http.Error(w, err.Error(), httpStatusCode)
		return
	}

	httpStatusCodeptr = &httpStatusCode
	successful := IsSuccess(httpStatusCode)
	successfulptr = &successful

	body, err := io.ReadAll(r.Body)
	log.Debug(endpoint+" json input: ", (string)(body))
	var data interface{}
	switch {
	case endpoint == "delta_extension_1":
		data, err = ci.ConvertDeltaControlInfoRecordFromJSON(body)
	case endpoint == "delta_extension_2":
		data, err = ci.ConvertDeltaControlInfoIncRecordFromJSON(body)
	default:
		log.Error(err)
		http.Error(w, err.Error(), http.StatusBadRequest)
	}

	if err != nil {
		log.Error(err)
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	errChan := make(chan error)

	go func() {
		switch data_ := data.(type) {
		case ci.DeltaControlInfoRecord:
			errChan <- DeltaExtension1(&data_, Cfg, &extElapsedMs)
			data = data_
		case ci.DeltaControlInfoIncRecord:
			errChan <- DeltaExtension2(&data_, Cfg, &extElapsedMs)
			data = data_
		}
	}()

	err = <-errChan
	if err != nil {
		log.Error(err)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	close(errChan)

	processesReceivedData := Cfg.GetBool("ProcessesReceivedData", false)
	if processesReceivedData {
		switch data_ := data.(type) {
		case ci.DeltaControlInfoRecord:
			err = UpdateDataControlInfo(&data_, log)
			data = data_
		case ci.DeltaControlInfoIncRecord:
			err = UpdateDataControlInfoInc(&data_, log)
			data = data_
		}
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
	}

	body, err = ci.ConvertToJSON(data)
	if err != nil {
		log.Error(err)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	log.Debug(endpoint+" json output: ", (string)(body))
	_, err = w.Write(body)
	if err != nil {
		log.Error(err)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	duration := time.Since(start)
	duration_int := int(duration.Milliseconds())
	elapsedMs = &duration_int

	log.Information("Extension processing elapsed ", extElapsedMs)
}

func GetExtensionEndpoint(Path string) (endpoint string) {
	strs := strings.Split(Path, "/")
	if len(strs) > 0 {
		return strs[len(strs)-1]
	}
	return "null"
}

func CheckContentType(r *http.Request, logAgs map[string]interface{}) (log customlogger.LoggerInterface, httpStatusCode int, err error) {
	log = customlogger.GetLog(&logAgs, GlobalLoggingSettings)

	//check method
	if r.Method != http.MethodPost {
		httpStatusCode = http.StatusMethodNotAllowed
		err = fmt.Errorf("only POST method is allowed")
		return
	}

	//check content type
	contentType := strings.ToLower(r.Header.Get("Content-Type"))
	if !strings.Contains(contentType, "application/json") {
		httpStatusCode = http.StatusUnsupportedMediaType
		err = fmt.Errorf("wrong Content Type. Expected application/json")
		return
	}

	httpStatusCode = http.StatusOK

	return
}
