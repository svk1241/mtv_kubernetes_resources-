#!/bin/sh

cd libadapter

make all

cd ..

make all
