Build:

./build_all.sh

Artifacts:

extserver
libadapter.so

For run need set LD_LIBRARY_PATH for libadapter.so

export LD_LIBRARY_PATH=/home/user/work/extension_adapter_all/extensions_wrapper_service/extensions_wrapper_service_src/bin:$LD_LIBRARY_PATH
export EXT_APP_CONFIG_PATH=/home/user/work/extension_adapter_all/extensions_wrapper_service/extensions_wrapper_service_src/appsettings.json