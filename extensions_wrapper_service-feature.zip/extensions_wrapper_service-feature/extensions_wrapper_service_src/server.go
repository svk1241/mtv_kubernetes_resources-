package main

import (
	"net/http"
	"regexp"
)

type ExtensionsWrapperServiceHandler struct {
	extWrapperHandler *WrapperHandler
	healthHandler     *HealthHandler
	infoHandler       *InfoHandler
	aliveHandler      *HealthHandler
}

func CreateServer(port string) (server *http.Server) {
	var handler http.Handler

	extWrapperHandler := &ExtensionsWrapperServiceHandler{}

	handler = extWrapperHandler

	server = &http.Server{
		Handler: handler,
		Addr:    ":" + port,
	}
	return server
}

func (handler *ExtensionsWrapperServiceHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	deltaExtensionMask := regexp.MustCompile(`/delta_extension_[1-2]{1}`)

	url := r.URL.Path
	switch {
	case deltaExtensionMask.MatchString(url):
		handler.extWrapperHandler.ServeHTTP(w, r)
	case url == "/health":
		handler.healthHandler.ServeHTTP(w, r)
	case url == "/alive":
		handler.aliveHandler.ServeHTTP(w, r)
	case url == "/info":
		handler.infoHandler.ServeHTTP(w, r)
	default:
		switch r.Method {
		case http.MethodGet:
			w.WriteHeader(404)
		case http.MethodPost:
			w.WriteHeader(404)
		case http.MethodPut:
			w.WriteHeader(404)
		case http.MethodDelete:
			w.WriteHeader(404)
		default:
			w.WriteHeader(404)
		}
	}
}

func IsSuccess(httpStatusCode int) (success bool) {
	return (httpStatusCode >= 200) && (httpStatusCode <= 299)
}
