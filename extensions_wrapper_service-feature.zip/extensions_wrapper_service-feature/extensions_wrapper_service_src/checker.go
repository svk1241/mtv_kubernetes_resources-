package main

import (
	"fmt"
	ci "luxproject.luxoft.com/stash/scm/mpcexp/extensions_control_info.git"
	customlogger "luxproject.luxoft.com/stash/scm/mpcexp/lms_logger_go.git"
	"os"
	"path/filepath"
	"strings"
)

func listFiles(root string) ([]string, error) {
	var files []string
	err := filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if !info.IsDir() {
			files = append(files, path)
		}
		return nil
	})
	return files, err
}

// TODO: upgrade and check superservice
func CheckAllTemplateControlInfo(record ci.DeltaControlInfoRecord, rootPath string) string {
	inputPaths, _ := listFiles(rootPath)
	for _, inputPath := range inputPaths {
		if CheckControlInfo(record, inputPath) {
			outputPath := strings.ReplaceAll(inputPath, "input", "output")
			return outputPath
		}
	}
	return ""
}

func CheckControlInfo(record ci.DeltaControlInfoRecord, inputPath string) bool {
	recordFromTemplate, err := ci.GetControlInfoFromFile(inputPath)
	if err != nil {
		fmt.Println("Error read file:", err)
		return false
	}

	return ci.СompareData(recordFromTemplate, record)
}

func UpdateControlInfo(outputPath string, dest *ci.DeltaControlInfoRecord) error {
	source := *dest
	template, err := ci.GetControlInfoFromFile(outputPath)
	if err != nil {
		fmt.Println("Error read file:", err)
		return err
	}
	destination, err := ci.GetControlInfoFromFile(outputPath)
	ci.UpdateData(&destination, template, source)
	*dest = destination
	return nil
}

func UpdateDataControlInfo(data *ci.DeltaControlInfoRecord, log customlogger.LoggerInterface) error {
	pathToTemplate := Cfg.GetValue("PathToReceivedDataTemplate", "/app")
	log.Debug("Templates is used")
	outputPath := CheckAllTemplateControlInfo(*data, pathToTemplate+"/extension_template/ddext1")
	if outputPath != "" {
		log.Debug("Transaction found: ", outputPath)
		err := UpdateControlInfo(outputPath, data)
		if err != nil {
			log.Error(err)
			return err
		}
	} else {
		log.Debug("Transaction template not found")
	}

	return nil
}

func CheckAllTemplateControlInfoInc(record ci.DeltaControlInfoIncRecord, rootPath string) string {
	inputPaths, _ := listFiles(rootPath)
	for _, inputPath := range inputPaths {
		if CheckControlInfoInc(record, inputPath) {
			outputPath := strings.ReplaceAll(inputPath, "input", "output")
			return outputPath
		}
	}
	return ""
}

func CheckControlInfoInc(record ci.DeltaControlInfoIncRecord, inputPath string) bool {
	recordFromTemplate, err := ci.GetControlInfoIncFromFile(inputPath)
	if err != nil {
		fmt.Println("Error read file:", err)
		return false
	}

	return ci.СompareData(recordFromTemplate, record)
}

func UpdateControlInfoInc(outputPath string, dest *ci.DeltaControlInfoIncRecord) error {
	source := *dest
	template, err := ci.GetControlInfoIncFromFile(outputPath)
	if err != nil {
		fmt.Println("Error read file:", err)
		return err
	}
	destination, err := ci.GetControlInfoIncFromFile(outputPath)
	ci.UpdateData(&destination, template, source)
	*dest = destination
	return nil
}

func UpdateDataControlInfoInc(data *ci.DeltaControlInfoIncRecord, log customlogger.LoggerInterface) error {
	pathToTemplate := Cfg.GetValue("PathToReceivedDataTemplate", "/app")
	log.Debug("Templates is used")
	outputPath := CheckAllTemplateControlInfoInc(*data, pathToTemplate+"/extension_template/ddext2")
	if outputPath != "" {
		log.Debug("Transaction found: ", outputPath)
		err := UpdateControlInfoInc(outputPath, data)
		if err != nil {
			log.Error(err)
			return err
		}
	} else {
		log.Debug("Transaction template not found")
	}
	return nil
}
