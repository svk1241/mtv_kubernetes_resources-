#include <stdio.h>
#include <dlfcn.h>
#include "ddext1.h"
#include "ddext2.h"

typedef void (*function_type)();

struct Library {
    function_type delta_extension_1;
    function_type delta_extension_2;
};

struct Library lib;

extern void load_library(const char *library_path);

extern void use_delta_extension_1(CONTROL_INFO *control_info);

extern void use_delta_extension_2(CONTROL_INFO_INC *control_info);
