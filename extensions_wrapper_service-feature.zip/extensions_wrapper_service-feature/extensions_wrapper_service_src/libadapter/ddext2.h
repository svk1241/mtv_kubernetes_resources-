/*
 * ====================================================================
 *
 * MetaVance is a registered mark of HPDC
 *
 * Copyright (c) 2011 Hewlett-Packard Development Company, L.P.                      
 * 
 * All rights reserved.
 *
 * Hewlett-Packard Development Company, LP
 * http://www.hp.com
 *
 * This source code is the confidential property of HP.  All
 * proprietary rights, including but not limited to any trade secret, 
 * copyright, patent or trademark rights in and to this source code are 
 * the property of HP.  This source code is not to be used, disclosed 
 * or reproduced in any form without the express written consent of HP.
 *
 * Export Compliance Warning: The information contained in this document 
 * may be subject to United States Export Administration Regulations and 
 * may not be exported  or re-exported, directly or indirectly, (i) into 
 * (or to a national or resident of) any U.S. embargoed country or  
 * (ii) to anyone on the U.S. Treasury Department�s list of Specially 
 * Designated Nationals or the U.S. Department of Commerce�s Table of   
 * Denial Orders or (iii) for any end-use that is prohibited by United  
 * States law. Please contact your export compliance coordinator for  
 * country specific restrictions.
 * Export Control Classification Number: 5D002
 *    
 *************************************************************
 *
 *	@(#)Interface for Delta Dental Incentives Processing Extension
 *
 *      This module may contain proprietary information of Delta Dental
 *      of California, and should be treated as confidential.
 *
 *      Copyright(c) 2006-2007, Delta Dental of California.  All rights
 *      reserved.
 *
 *
 ***    ddext2.h
 *
 *
 *      MODIFICATION HISTORY
 *      --------------------
 *      M000    pdr     20-Apr-2007
 *      - Created from structure definitions originally found in
 *        EDS MetaVance C-language header file EDCCE02.h
 *
 *      M001    pdr     23-May-2007
 *      - Deleted periodic payment indicator member (periodic_pmt_ind)
 *        from definition of SERVICE_LINE
 *
 *      M002    bjs     13-May-2008
 *      - Per change #14614 added Mbr Incentive Level and restructured
 *        Start Date to apply to all members
 *
 *      M003    JAL     17-Apr-2010
 *      - Changed CONTROL_INFO to CONTROL_INFO_INC, SERVICE_LINE to
 *		  SERVICE_LINE_INC and CLAIM_HEADER to CLAIM_HEADER_INC - 
 *        defect - DELTA00090260
 *
 *      M004    JHL     20-Sep-2011
 *      - Added svc_prov_id, svc_prov_role_code, svc_prov_network_id, 
 *        svc_prov_status_code, npf_prod_code, grp_prov_id to SERVICE_LINE 
 *        record. Added birth_date to claim record.
 *        Project 514 Release 2.10 Patch 4
 */


#ifndef DDEXT2_H_INCLUDED
#define DDEXT2_H_INCLUDED



#define ELIGIBILITY_COVERAGE_MAX 200

#define MEMBER_COVERAGE_MAX 31

#define BENEFIT_COUNTER_MAX 200

#define SERVICE_LINE_MAX 99

#define SUBSCRIBER_MEMBER_MAX 2




typedef struct	 	/* ELIGIBILITY_COVERAGE record definition */
{

    char bus_lev_4_id[12 +1];

    char bus_lev_5_id[12 +1];

    char bus_lev_6_id[12 +1];

    char bus_lev_7_id[12 +1];

    char class_code[4 +1];
    
    char benefit_pkg[8 +1];

    long eff_date;

    long end_date;

    char emp_grp_lev_1_id[12 +1];

    char emp_grp_lev_2_id[12 +1];

    char emp_class_code[4 +1];

} ELIGIBILITY_COVERAGE;





typedef struct 		/* MEMBER_COVERAGE record definition */
{

    char contract_id[25 +1];

    char mbr_id[2 +1];

    long start_date;

    char mbr_incent_level[2 +1];

    /*  The eligibility_coverage[] array has ELIGIBILITY_COVERAGE_MAX
     *  elements reserved for storage of eligibility-coverage records.
     *  The value of eligibility_coverage_cnt is the number of elements
     *  of this array that are actually in use.
     *
     *  Note that "eligibility_coverage_cnt" was previously named
     *  "mbr_cov_cnt".
     */

    short eligibility_coverage_cnt;

    ELIGIBILITY_COVERAGE eligibility_coverage[ELIGIBILITY_COVERAGE_MAX];

} MEMBER_COVERAGE;





typedef struct 		/* BENEFIT_COUNTER record definition */
{

    char id[10 +1];	/* Previously named "benefit_counter_id" */

    long date;		/* Previously named "benefit_counter_date" */

} BENEFIT_COUNTER;





typedef struct 		/* CLAIM_HEADER record definition */
{

    char claim_id[15 +1];

    char mbr_bus_lev_4_id[12 +1];

    char mbr_bus_lev_5_id[12 +1];

    char mbr_bus_lev_6_id[12 +1];

    char mbr_bus_lev_7_id[12 +1];

	long birth_date;

} CLAIM_HEADER_INC;





typedef struct 		/* SERVICE_LINE record definition */
{

    short svc_line_num;

    long from_date;

    long thru_date;

    char proc_code_id[11 +1];

    char treatment_type_code[2 +1];

    char proc_class_code[2 +1];


    /* "emp_grp_level_1_id" changed to "emp_grp_lev_1_id" 18-May-2007 */

    char emp_grp_lev_1_id[12 +1];


    /* "emp_grp_level_2_id" changed to "emp_grp_lev_2_id" 18-May-2007 */

    char emp_grp_lev_2_id[12 +1];

    char svc_prov_id[12 +1];

    char svc_prov_role_code[2 +1];

    char svc_prov_network_id[12 +1];

    char svc_prov_status_code[2 +1];

    char benefit_pkg_id[8 +1];

    /*
     *  Array with space reserved for storing up to 10 EX codes. Use the
     *  "svc_line_expl_code_cnt" member to determine how many slots are
     *  actually in use.
     */

    short svc_line_expl_code_cnt;

    char svc_line_expl_code[10][3 +1];


    long hire_date;


    /* "incentive_rule_id" changed to "incent_rule_id" 18-May-2007 */

    char incent_rule_id[5 +1];


    /* "sub_mbr_ind" changed to "incent_sub_mbr_ind" 18-May-2007 */

    char incent_sub_mbr_ind[1 +1];


    /* "level_cnt" changed to "incent_lev_cnt" 18-May-2007 */

    short incent_lev_cnt;


    /* "util_flag" changed to "incent_util_flag" 18-May-2007 */

    char incent_util_flag[1 +1];

    char npf_prod_code[2 +1];

    char grp_prov_id[12 +1];

	/* return the incentive level in incentive_level 05-Jun-2007 */

	char incentive_level[2 +1];

} SERVICE_LINE_INC;





typedef struct 		/* SUBSCRIBER_MEMBER record definition */
{

    char sub_mbr_ind[1 +1];

    /*  The member_coverage[] array has MEMBER_COVERAGE_MAX elements
     *  reserved for storage of member-coverage records. The value of
     *  member_coverage_cnt is the number of elements of this array
     *  that are actually in use.
     *
     *  Note that the first element of the member_coverage[] array
     *  always contains the primary member-coverage record (for the
     *  claim member).
     */

    short member_coverage_cnt;

    MEMBER_COVERAGE member_coverage[MEMBER_COVERAGE_MAX];


    /*  The benefit_counter[] array has BENEFIT_COUNTER_MAX elements
     *  reserved for storage of benefit-counter records. The value of
     *  benefit-counter_cnt is the number of elements in this array
     *  which are actually in use.
     */

    short benefit_counter_cnt;

    BENEFIT_COUNTER benefit_counter[BENEFIT_COUNTER_MAX];

} SUBSCRIBER_MEMBER;





typedef struct 		/* CONTROL_INFO record definition */
{

    char user_id[8 +1];			/* MetaVance user ID */

    char password[8 +1];		/* MetaVance password */


    CLAIM_HEADER_INC *claim_header;		/* Pointer to claim-header record */


    short service_line_cnt;		/* Count of service-line records */

    SERVICE_LINE_INC *service_line;		/* Array of service-line records */


    /* Count of subscriber-member records, followed by array reference */

    short subscriber_member_cnt;

    SUBSCRIBER_MEMBER *subscriber_member;


    char process_real_time[1 +1];	/* Realtime flag (non-batch mode) */

    char call_was_successful[1 +1];	/* Delta Extension was called */

} CONTROL_INFO_INC;




extern void delta_extension_2(CONTROL_INFO_INC *);	/* MetaVance exit point */




#endif	/* DDEXT2_H_INCLUDED */
