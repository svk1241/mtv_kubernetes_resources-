#include <stdio.h>
#include "adapter.h"


void load_library(const char *library_path) {
    void *handle = dlopen(library_path, RTLD_LAZY);
    if (!handle) {
        fprintf(stderr, "Error while loading %s\n", library_path);
        return;
    }

    lib.delta_extension_1 = (function_type)dlsym(handle, "delta_extension_1");
    if (!lib.delta_extension_1) {
        fprintf(stderr, "Function delta_extension_1 not found\n");
        return;
    }

    lib.delta_extension_2 = (function_type)dlsym(handle, "delta_extension_2");
    if (!lib.delta_extension_2) {
        fprintf(stderr, "Function delta_extension_2 not found\n");
        return;
    }
}

void use_delta_extension_1(CONTROL_INFO *control_info) {
    lib.delta_extension_1(control_info);
}

void use_delta_extension_2(CONTROL_INFO_INC *control_info) {
    lib.delta_extension_2(control_info);
}

