/*
 *	@(#)Interface for Delta ESP Coding Audit & Fee Selection
 *
 *      This software module may contain proprietary information
 *      of Delta Dental, and should be treated as confidential.
 *
 *      Copyright(c) 2006-2007 by Delta Dental of California.
 *      All rights reserved.
 *
 *
 ***    ddext1.h
 *
 *
 *      MODIFICATION HISTORY
 *      --------------------
 *      M000    pdr     28-Feb-2007
 *      Created from structure definitions originally found in EDS MTV
 *      header file EDCCE01.h
 *
 *      M001    pdr	08-Mar-2007
 *      Reworked per technical discussions with EDS reps.
 *
 *      M002    pdr	14-Mar-2007
 *      Moved field active_svc_line_cnt to delta_control_info_record
 *      structure and renamed it as service_line_cnt.  Added two new
 *      fields, ignored_service_line_cnt and service_history_line_cnt,
 *      to the same structure; these fields were accidentally omitted
 *      from the M001 version of this interface.  Changed data type of
 *      svc_line_ovr_expl_code from int to char to account for an error
 *      in data-type specification.
 *
 *      M003   pdr	18-Apr-2007
 *      Added user_id and password fields to delta_control_info_record.
 *      Added 10 new npf_.* fields to service_line record.
 *
 */


#ifndef DDEXT1_H_INCLUDED
#define DDEXT1_H_INCLUDED


#define MAX_SERVICE_LINES 99

#define MAX_IGNORED_SERVICE_LINES 99

#define MAX_SERVICE_HISTORY_LINES 500




/* Define and typedef all interface record layouts */


typedef struct delta_control_info_record \
    CONTROL_INFO;

typedef struct delta_claim_header_record \
    CLAIM_HEADER;

typedef struct delta_service_line_record \
    SERVICE_LINE;

typedef struct delta_service_line_record \
    IGNORED_SERVICE_LINE;	/* Same record layout as SERVICE_LINE */

typedef struct delta_service_history_line_record \
    SERVICE_HISTORY_LINE;


/*
 * Declare function prototype for Delta Dental's "Coding Audit"
 * & "Fee Selection" extension module
 */

extern void delta_extension_1(CONTROL_INFO *);   




struct delta_control_info_record
{

    CLAIM_HEADER *claim_header;


    char user_id[9];	/* User ID and password for MTV claim examiner */
    char password[9];	/* (added 18-Apr-2007) */


    /*
     *  NOTE: The "service_line_cnt" member used to be named (by EDS)
     *  "import_export_curr_grp_s_ma" and was found in a claim-related
     *  data structure.
     */

    SERVICE_LINE *service_line;

    short service_line_cnt;	// 15 ca


    IGNORED_SERVICE_LINE *ignored_service_line;

    short ignored_service_line_cnt;


    SERVICE_HISTORY_LINE *service_history_line;

    short service_history_line_cnt;



#ifdef EDCCE01

    /* Entity View: IMPORT_ADJUDICATION_PASS, Type: CL_CLAIMS */

    char command[9];

#else

    char adjudication_pass[9];  /* Value of "PASS2" on readjudication */

#endif



#ifdef EDCCE01

    /* Entity View: IMPORT_PROCESS_REAL_TIME, Type: IEF_SUPPLIED */

    char flag[2];

#else

    /* The "batch_mode" flag is nonzero when in "batch input" mode */
    /* Real Time Processing Flag - Page 9 FS  */

    char process_real_time[2];	// fs 9

#endif



#ifdef EDCCE01

    /* Entity View: EXPORT_CALL_WAS_SUCCESSFUL, Type: IEF_SUPPLIED */

    char flag[2];

#else

    char call_was_successful[2];

#endif


};




struct delta_claim_header_record
{

    /* Entity View: IMPORT_EXPORT_CURR, Type: CLAIM */


    /* Claim Type pg 6 */

    char type[3];	/* "DE" for Dental, etc. */


#ifdef EDCCE01

    char claim_identifier[16];	/* Claim Number pg 5 */

#else

    char claim_id[16];

#endif


#ifdef EDCCE01

    char business_level_4_id[13];
    char business_level_5_id[13];
    char business_level_6_id[13];
    char business_level_7_id[13];

#else

    /* Page 5-6  &14 Code Audit */

    char mbr_bus_lev_4_id[13];
    char mbr_bus_lev_5_id[13];
    char mbr_bus_lev_6_id[13];
    char mbr_bus_lev_7_id[13];

#endif


#ifdef EDCCE01
    char coverage_contract_identifi[26];
#else
    char coverage_contract_id[26];
/* */
#endif


#ifdef EDCCE01
    char member_identifier[3];
    char person_identifier[17];
    char billing_provider_id[13];
#else
    char mbr_id[3];
    char person_id[17];
    char billing_prov_id[13];
#endif


    char billing_prov_type_code[5];


#ifdef EDCCE01

    char billing_prov_specialty_cod[5];
    char predetermination_claim_fla[2];
    double total_charges_amount_;

#else

    char billing_prov_spec_code[5];

    char predetermination_claim_flag[2];

    double total_charge;

#endif


    char cause_of_illness_code[3];  // 6 fs
    char caused_by_employment_flag[2]; // 15 ca
    char auto_accident_flag[2]; // 14 ca
    char other_accident_flag[2];// 15 ca


#ifdef EDCCE01
    long birth_date_;
#else
    long mbr_birth_date; // 14 ca
#endif


#ifdef EDCCE01

    /* Entity View: IMPORT_MEMBER, Type: METAVANCE_ADDRESS */

    char state_code[3];
    char zip[16];

#else

    char mbr_state_code[3]; // fs 30 - at service level in mapping document
    char mbr_zip[16];	// fs 30 - at service level in mapping document

#endif




#ifdef EDCCE01

    /* Entity View: IMPORT_CURR_LAST_SERVICE_NUMBER, Type: CLAIM */

    short services_number_;

#else

    /*
     *  The "total_claim_svc_cnt" should be incremented when active
     *  service lines are added.  It represents the total of all active,
     *  ignored, and voided service lines.  Note that we do not see any
     *  voided service lines (from MTV) in the ESP Extensions input.
     */

    short total_claim_svc_cnt; // 9 fs

#endif



#ifdef EDCCE01

    /* Repeating GV: IMPORT_CURR_GROUP_CLAIM_HDR, Repeats: 8 times */

    int import_curr_group_claim__ma;
    char import_curr_group_claim__ac[8];

#else

    /*
     *  NOTE: The "import_curr_group_claim__ma" member is used as the
     *  actual count of the number of "diag_code_id[]" elements used
     *  (see below).  This member is being retyped as a "short int" and
     *  renamed "diag_code_id_cnt".
     */

    short diag_code_id_cnt;	// Not in docs

#endif



    /* Entity View: IMPORT_CURR_G_CLAIM_HDR */
    /* Type: CLAIM_DIAGNOSIS_ASSOCIATION */

    char diag_code_id[8][9];// 14 ca



#ifdef EDCCE01

    /* Repeating GV:  IMPORT_EXPORT_CURR_GRP_SVC_LINE */
    /* Repeats: 99 times */

    int import_export_curr_grp_s_ma;// Already covered above
    char import_export_curr_grp_s_ac[99];

#else

    /*
     *  NOTE: The "import_export_curr_grp_s_ma" element is used for
     *  the count of "active" service line structures. This element
     *  is being renamed "service_line_cnt", its data type is being
     *  changed to "short int", and it is being moved to another
     *  data structure.
     */

#endif


};




struct delta_service_line_record
{

    /* Entity View: IO_CURR_G, Type: SERVICE_LINE */

#ifdef EDCCE01
    short service_number;
    short sequence_number;
#else
    short svc_line_num;	// 16 ca 44 fs
    short seq_num;	// 16 ca
#endif



#ifdef EDCCE01

    double charge_amount[99];

#else

    double charge;	// 18 ca 19 fs

#endif



#ifdef EDCCE01

    long from_date[99];
    long thru_date[99];
    char periodic_payment_ind[2];

#else

    long from_date;	//  16 ca  39 fs
    long thru_date;	//  16 ca  46 fs

    char periodic_pmt_ind[2];// 34 fs

#endif




#ifdef EDCCE01

    char procedure_code_identifier[12];
#else

    char proc_code_id[12];	// 36 fs

#endif

    char proc_mod_code_1[3];// ca 21 fs 37
    char proc_mod_code_2[3];//  ca 21 fs 37
    char proc_mod_code_3[3];// ca 21 fs 37
    char proc_mod_code_4[3];// ca 21 fs 37
    char proc_mod_code_5[3];// ca 21 fs 37

    char treatment_type_code[3];// ca 21 fs 52


#ifdef EDCCE01
    char status_indicator[2];
#else
    char status_ind[2]; // fs 45
#endif

    char status_expl[4];  // fs 45 reason code ca 16 status Explanation


#ifdef EDCCE01
    char benefit_package_identifier[9];
#else
    char benefit_pkg_id[9]; // fs 18 -Group with group number- ca 18
#endif

    char proc_class_code[3];	// fs 36 -Group with treatment type-
    char proc_cat_code[3];	// fs 36-Group with treatment type-



#ifdef EDCCE01

    long service_units_count;
    long service_minutes_count;
    double allowed_amount[99];

#else

    long svc_units; // fs 46 ca 18
    long svc_mins; // fs 46 
    double allowed_amt; // fs 11 ca 18-Group with Approved-

#endif



#ifdef EDCCE01

    double oic_paid_amount;
    char man_payment_allowed_entere[2];

#else

    double oic_paid_amt; // fs 34
    char man_pmt_allowed_entered[2];// fs 13

#endif


    /*
     *  NOTE: Structure members "cas_send_group_indicator" and
     *  "cas_replacement_proc_code" were not originally defined
     *  in the "IMPORT_IGNRD_G" entity view (type "SERVICE_LINE").
     *  These members should be set to an empty string when the
     *  service line should be ignored.
     */

#ifdef EDCCE01
    char cas_send_group_indicator[3];
#else
    char cas_send_grp_ind[3]; // not in documents
#endif


    char cas_repl_proc_code[12]; // ca 41 


    char mode_of_pay_code[5]; // fs 31 


    /*
     *  NOTE: Structure members "cas_proc_payment_stat" and
     *  "cas_procedure_code_origin_" were not originally defined
     *  in the "IMPORT_IGNRD_G" entity view (type "SERVICE_LINE").
     *  These members should be set to an empty string when the
     *  service line should be ignored.
     */

#ifdef EDCCE01

    char cas_proc_code_pmt_stat[2];
    char cas_procedure_code_origin_[2];

#else

    char cas_proc_code_pmt_stat[2]; // ca 42 
    char cas_proc_code_origin[2]; // ca 42 

#endif



#ifdef EDCCE01
    double oic_allowed_amount;
    short hipaa_service_line_num;
#else
    double oic_allowed_amt; // fs 33 
    short hipaa_svc_line_num; // ca 22
#endif


#ifdef EDCCE01
    char external_pricing_flag[2];
    char external_pricing_field_1[26];
    char external_pricing_field_2[26];
    char external_pricing_field_3[26];
    char external_pricing_field_4[26];
    char external_pricing_field_5[26];

#else
    char ext_pricing_flag[2]; // fs 22

    char ext_pricing_fld_1[26]; // fs 21 ca 22
    char ext_pricing_fld_2[26]; // fs 21 ca 22
    char ext_pricing_fld_3[26]; // fs 21 ca 22
    char ext_pricing_fld_4[26]; // fs 21 ca 22
    char ext_pricing_fld_5[26]; // fs 21 ca 22
#endif




#ifdef EDCCE01
    char network_indicator[2];
    short cross_ref_service_number;
#else
    char network_ind[2]; // fs 32 
    short cross_ref_svc_num; // ca 43 22 - one is a return value same holder
#endif


#ifdef EDCCE01
    char invalid_data_exists_flag[2];
#else
    char invalid_data[2];	// fs 23
#endif


#ifdef EDCCE01
    char procedure_code_data_invali[2];
    char hcpcs_proc_code_data_inval[2];
    char procedure_modifier_data_in[2];
    char procedure_modifr_2_data_in[2];
    char procedure_modifr_3_data_in[2];
    char procedure_modifr_4_data_in[2];
    char procedure_modifr_5_data_in[2];
    char place_of_service_code_inva[2];
    char svc_facility_loc_data_invl[2];
#else

    char proc_code_data_invalid[2]; // fs 26 Invalid flag for Diagnosis Code

    char hcpcs_proc_code_data_invalid[2];// fs 25

    char proc_mod_1_data_invalid[2]; // fs 27
    char proc_mod_2_data_invalid[2]; // fs 27 
    char proc_mod_3_data_invalid[2]; // fs 27
    char proc_mod_4_data_invalid[2]; // fs 27
    char proc_mod_5_data_invalid[2]; // fs 27

    char place_of_svc_code_invalid[2]; // fs 26

    char svc_facility_loc_data_invalid[2]; // fs 29

#endif



#ifdef EDCCE01
    double approved_amount;
#else
    double approved_amt; // fs 15  ca 27
#endif

    char man_pay_approved_entered_flag[2]; // fs 17 
    char approved_fee_sched_tab[11]; // fs 18 -is it 10 or 4 in size-
    char allowed_fee_sched_tab[11]; // fs 14 -is it 10 or 4 in size-


#ifdef EDCCE01
    char external_pricing_ind_1[2];
    char external_pricing_ind_2[2];
#else
    char npf_priced_flag[2]; // fs 32 NPF Price Flag
    char npf_hit_charge[2]; // fs 33 NPF Hit Charge
#endif


    char npf_bus_id[31];	/* NPF-related fields added 18-Apr-2007 */
    char npf_mult_bus_flag[2];
    char npf_lic_id[31];
    char npf_mult_lic_flag[2];
    char npf_lic_state[3];
    char npf_office_id[4];
    char npf_owning_state[13];
    char npf_prod_code[3];
    char npf_region[3];
    char npf_spec_code[3];


    char grp_prov_id[13];	/* Added 18-Apr-2007 */
    char practice_loc_id[13];	/* Added 18-Apr-2007 */


    char pricing_rule_id[6];	// fs 32 Pricing rule number


#ifdef EDCCE01
    /* Entity View: IMPORT_CURR_PROCESS_CODE_AUDIT */
    /* Type: IEF_SUPPLIED */

    char flag[2];
#else

    char coding_audit_required_flag[2]; // ca 22

#endif



#ifdef EDCCE01

    /* Repeating GV: IMPORT_CURR_NSTD_GRP_OVERRIDE_EX, Repeats: 10 times */

    int import_curr_nstd_grp_ove_ma[99];
    char import_curr_nstd_grp_ove_ac[99][10];

#else

    /* Count of elements in "svc_line_ovr_explanation_code" (see below) */

    short svc_line_ovr_expl_code_cnt; // not in document

#endif



#ifdef EDCCE01

    /* Entity View: IMPORT_CURR_NSTD_G_OVERRIDE_EX */
    /* Type: CLAIM_EXPLANATION_CODE_ASSN */

    char explanation_code[99][10][4];

#else

    char svc_line_ovr_expl_code[10][4]; // ca 16

#endif




#ifdef EDCCE01

    /* Repeating GV: IO_CURR_NSTD_GRP_CLAIM_EX */
    /* Repeats: 10 times */

    int io_curr_nstd_grp_claim_e_ma[99];
    char io_curr_nstd_grp_claim_e_ac[99][10];

#else

    short svc_line_expl_code_cnt;	// Not in Document

#endif



#ifdef EDCCE01

    /* Entity View: IO_CURR_NSTD_G_CLAIM_EX */
    /* Type: CLAIM_EXPLANATION_CODE_ASSN */

    char explanation_code[99][10][4];

#else

    char svc_line_expl_code[10][4];  // ca 16 fs 40
#endif





#ifdef EDCCE01


    /* Repeating GV: IO_CURR_NSTD_GRP_ALLOWED_EX */
    /* Repeats: 5 times */
    int io_curr_nstd_grp_allowed_ma[99];
    char io_curr_nstd_grp_allowed_ac[99][5];

#else

    /* Count of elements used in "allowed_explanation_code[]" */

    short allowed_expl_code_cnt; // Not in Document

#endif




#ifdef EDCCE01
    /* Entity View: IO_CURR_NSTD_G_ALLOWED_EX */
    /* Type: CLAIM_EXPLANATION_CODE_ASSN */

    char explanation_code[99][5][4];

#else

    char allowed_expl_code[5][4]; // fs 11 ca 19

#endif



#ifdef EDCCE01

    /* Repeating GV: IO_CURR_NSTD_GRP_APPROVED_EX */
    /* Repeats: 5 times */

    int io_curr_nstd_grp_approve_ma[99];
    char io_curr_nstd_grp_approve_ac[99][5];

#else

    short approved_expl_code_cnt;// Not in Document

#endif




#ifdef EDCCE01
    /* Entity View: IO_CURR_NSTD_G_APPROVED_EX */
    /* Type: CLAIM_EXPLANATION_CODE_ASSN */

    char explanation_code[99][5][4];

#else

    char approved_expl_code[5][4]; // fs 15 ca 19

#endif



    /* Entity View: IO_CURR_G, Type: MEDICAL_OUTPATIENT_SERVICE_LINE */

#ifdef EDCCE01
    long tax_identifier;
    char svc_provider_id[13];
#else
    long tax_id; // ca 16 fs 54 THIS IS NOT THE NPF BUSINESS ID
    char svc_prov_id[13]; // ca 16 fs 47  
#endif


    char svc_prov_type_code[5]; // fs 51 
    char svc_prov_spec_code[5];	// fs 50 ca 16


#ifdef EDCCE01
    char svc_provider_role_code[3];
#else
    char svc_prov_role_code[3]; // fs 49 
#endif


    double anesthesia_units; // ca 26 fs 14


#ifdef EDCCE01
    char svc_prov_network_identifie[13];
#else
    char svc_prov_network_id[13]; // fs 48
#endif


    char svc_prov_status_code[3]; // ca 18 fs 48 participation status
    char svc_prov_region_code[3]; // ca 20 fs 49
    char svc_prov_class_code[3]; // fs 47 
    char svc_prov_med_svc_area_code[5]; // ca 20 fs 47
    char svc_prov_svc_area_block_code[3]; // fs 50

#ifdef EDCCE01
    char diagnosis_code_identifier[9];
    char diagnosis_code_id_2[9];
    char diagnosis_code_id_3[9];
    char diagnosis_code_id_4[9];
#else
    char diag_code_id_1[9]; // ca 21 
    char diag_code_id_2[9]; // ca 21 
    char diag_code_id_3[9]; // ca 21 
    char diag_code_id_4[9]; // ca 21 
#endif


    char emp_grp_level_1_id[13]; // fs 22 group 
    char emp_grp_level_2_id[13]; // fs 20 division

    char mbr_class_code[5]; // ca 21 fs 30
    char hi_range_tooth_code[3]; // ca 16 


#ifdef EDCCE01
    char occlusal_surface_indicator[2];
    char incisal_surface_indicator[2];
    char facial_surface_indicator[2];
    char buccal_surface_indicator[2];
    char lingual_surface_indicator[2];
    char distal_surface_indicator[2];
    char mesial_surface_indicator[2];
#else
    char occlusal_srf_ind[2]; // ca 25 - 26
    char incisal_srf_ind[2]; // ca 25 - 26
    char facial_srf_ind[2]; // ca 25 - 26
    char buccal_srf_ind[2]; // ca 25 - 26
    char lingual_srf_ind[2]; // ca 25 - 26
    char distal_srf_ind[2]; // ca 25 - 26
    char mesial_srf_ind[2]; // ca 25 - 26
#endif

    char svc_prov_par_status_ind[2]; // fs 48


#ifdef EDCCE01
    char pay_to_provider_data_inval[2];
    char svc_provider_data_invalid_[2];
    char diagnosis_code_data_invali[2];
    char diagnosis_code_data_2_inva[2];
    char diagnosis_code_data_3_inva[2];
    char diagnosis_code_data_4_inva[2];

#else

    char pay_to_prov_data_invalid[2]; // fs 25

    char svc_prov_data_invalid[2]; // fs 28

    char diag_code_data_1_invalid[2]; // fs 23
    char diag_code_data_2_invalid[2]; // fs 23
    char diag_code_data_3_invalid[2]; // fs 23
    char diag_code_data_4_invalid[2]; // fs 23
#endif



#ifdef EDCCE01
    /* Entity View: IMPORT_CURR_G_PROVIDER */
    /* Type: METAVANCE_ADDRESS */
    char state_code[99][3];
    char zip[99][16];
#else
    char prov_state_code[3]; // ca 19 fs 50
    char prov_zip[16]; // ca 20 fs 51
#endif



#ifdef EDCCE01
    /* Entity View: IMPORT_CURR_G_PROVIDER */
    /* Type: EXTERNAL_PRICING_WS */
    char postal_cross_reference[4];
    char postal_region[4];
#else
    char prov_postal_cross_ref[4]; // fs 35
    char prov_postal_region[4]; // fs 35
#endif



#ifdef EDCCE01
    /* Entity View: IMPORT_CURR_G_SVC_PROV */
    /* Type: BUSINESS_LEVEL_CONTRACT_ASSN */

    char business_level_4_id[99][13];
    char business_level_5_id[99][13];
    char business_level_6_id[99][13];
    char business_level_7_id[99][13];

#else
    char prov_bus_lev_4_id[13]; // ca 20 
    char prov_bus_lev_5_id[13]; // ca 20 fs 18
    char prov_bus_lev_6_id[13]; // ca 20 fs 18
    char prov_bus_lev_7_id[13]; // ca 20 fs 18
#endif



    /*
     *  NOTE: Structure members "cas_audit_result" through
     *  "cas_audit_rule_id" were not originally defined
     *  in the "IMPORT_IGNRD_G" entity view (type "SERVICE_LINE").
     *  These members should be set to an empty string when the
     *  service line ought to be ignored.
     */

    /* Entity View: IO_CURR_G */
    /* Type: CAS_RECOMMENDATION_INFORMATION */

    char cas_audit_result[8]; // ca 16

    char cas_audit_tab_id[6]; // ca 21

    char cas_audit_rule_id[6]; // ca 16



#ifdef EDCCE01

    /* Entity View: IO_CURR_G_ALLOW_AMT_CALC_0, Type: IEF_SUPPLIED */

    char flag[99][2];

#else

    /*
     *  The "allowed_amt_is_zero" flag tells MTV that 0.0 is NOT to
     *  be considered an error.
     */

    char allowed_amt_is_zero[2];	// fs 11 

#endif




#ifdef EDCCE01

    /* Entity View: IO_CURR_G_APPROVED_AMT_CALC_0, Type: IEF_SUPPLIED */

    char flag[99][2];

#else

    /*
     *  The "approved_amt_is_zero" flag tells MTV that 0.0 is NOT to
     *  be considered an error.
     */

    char approved_amt_is_zero[2];	// fs 15 

#endif


};	/* End of Service Line Structure */




struct delta_service_history_line_record
{
    /*
     *  NOTE: Structure members "claim_identifier" through
     *  "other_accident_flag" were originally defined in
     *  entity view "IMPORT_HIST_G", type "CLAIM".  Delta
     *  Dental decided to merge that entity view with view
     *  "IMPORT_HIST_G", type "SERVICE_LINE".
     */


    /* Entity View: IMPORT_HIST_G, Type: CLAIM */

#ifdef EDCCE01
    char claim_identifier[16];

#else
    char claim_id[16]; // ca 23
#endif


#ifdef EDCCE01
    char business_level_4_id[500][13];
    char business_level_5_id[500][13];
    char business_level_6_id[500][13];
    char business_level_7_id[500][13];
#else
    char mbr_bus_lev_4_id[13]; // ca 23
    char mbr_bus_lev_5_id[13]; // ca 23
    char mbr_bus_lev_6_id[13]; // ca 23
    char mbr_bus_lev_7_id[13]; // ca 23
#endif



#ifdef EDCCE01
    char coverage_contract_identifi[26];
    char member_identifier[3];

#else

    char coverage_contract_id[26]; // ca 23

    char mbr_id[3]; // ca 23

#endif


    char caused_by_employment_flag[2];  // ca 23
    char auto_accident_flag[2]; // ca 23
    char other_accident_flag[2]; // ca 23


#ifdef EDCCE01

    /* Repeating GV: IMPORT_HIST_NSTD_GRP_CLAIM_HDR, Repeats: 8 times */

    int import_hist_nstd_grp_cla_ma[500];
    char import_hist_nstd_grp_cla_ac[500][8];

#else

    /*
     *  NOTE: The "import_hist_nstd_grp_cla_ma" member is used as the
     *  actual count of the number of "diag_code_id[]" elements used
     *  (see below).  This member is being retyped as a "short int" and
     *  renamed "diag_code_id_cnt".
     */

    short diag_code_id_cnt;      // Not in docs

#endif



#ifdef EDCCE01

    /* Entity View: IMPORT_HIST_G_CLAIM_HDR */
    /* Type: CLAIM_DIAGNOSIS_ASSOCIATION */

    char diagnosis_code_identifier[500][8][9];       

#else

    char diag_code_id[8][9];   // ca 23    

#endif



#ifdef EDCCE01

    /* Entity View: IMPORT_HIST_G, Type: SERVICE_LINE */

    short service_number;
    short sequence_number;
    double charge_amount;
    long from_date;
    long thru_date;
    char procedure_code_identifier[12];
#else
    short svc_line_num;		// ca 25
    short seq_num;		// ca 25
    double charge;		// ca 26
    long from_date;		// ca 25
    long thru_date;		// ca 25
    char proc_code_id[12];	// ca 25
#endif


    char proc_mod_code_1[3]; // ca 28
    char proc_mod_code_2[3]; // ca 28
    char proc_mod_code_3[3]; // ca 28
    char proc_mod_code_4[3]; // ca 28
    char proc_mod_code_5[3]; // ca 28

    char treatment_type_code[3]; // ca 28

    char status_expl[4]; // ca 25



#ifdef EDCCE01

    char benefit_package_identifier[9];
    long service_units_count;

#else

    char benefit_pkg_id[9]; // ca 26

    long svc_units; // ca 26

#endif



#ifdef EDCCE01
    double allowed_amount;
    double approved_amount;
#else
    double allowed_amt; // ca 26
    double approved_amt; // ca 27
#endif


    /* Entity View: IMPORT_HIST_G1 */
    /* Type: MEDICAL_OUTPATIENT_SERVICE_LINE */

#ifdef EDCCE01
    long tax_identifier;
    char svc_provider_id[13];
#else
    long tax_id; // ca 25
    char svc_prov_id[13]; // ca 25
#endif


    char svc_prov_spec_code[5]; // ca 25

    double anesthesia_units; // ca 26

    char svc_prov_status_code[3]; // ca 26
    char svc_prov_region_code[3]; // ca 27
    char svc_prov_med_svc_area_code[5]; // ca 27


#ifdef EDCCE01
    char diagnosis_code_identifier[9];
    char diagnosis_code_id_2[9];
    char diagnosis_code_id_3[9];
    char diagnosis_code_id_4[9];
#else
    char diag_code_id_1[9];  // ca 28
    char diag_code_id_2[9]; // ca 28
    char diag_code_id_3[9]; // ca 28
    char diag_code_id_4[9]; // ca 28
#endif


    char mbr_class_code[5];  // ca 28
    char hi_range_tooth_code[3];  // ca 25

#ifdef EDCCE01
    char occlusal_surface_indicator[2];
    char incisal_surface_indicator[2];
    char facial_surface_indicator[2];
    char buccal_surface_indicator[2];
    char lingual_surface_indicator[2];
    char distal_surface_indicator[2];
    char mesial_surface_indicator[2];

#else

    char occlusal_srf_ind[2]; // ca 25
    char incisal_srf_ind[2]; // ca 26
    char facial_srf_ind[2]; // ca 26
    char buccal_srf_ind[2]; // ca 26
    char lingual_srf_ind[2]; // ca 26
    char distal_srf_ind[2]; // ca 26
    char mesial_srf_ind[2]; // ca 26
#endif



#ifdef EDCCE01
    /* Entity View: IMPORT_HIST_G_SVC_PROV */
    /* Type: BUSINESS_LEVEL_CONTRACT_ASSN */

    char business_level_4_id[500][13];
    char business_level_5_id[500][13];
    char business_level_6_id[500][13];
    char business_level_7_id[500][13];

#else
    char prov_bus_lev_4_id[13]; // ca 27
    char prov_bus_lev_5_id[13];// ca 27
    char prov_bus_lev_6_id[13];// ca 27
    char prov_bus_lev_7_id[13];// ca 27
#endif




#ifdef EDCCE01

    /* Entity View: IO_HIST_G_RELATED_CURRENT_CLAIM */
    /* Type: SERVICE_LINE */

    short service_number[500];

#else

    /*
     *  Current service line where a coding audit recommendation was
     *  made using this history service line.
     */

    short svc_line_ref;     // ca 44

#endif




#ifdef EDCCE01

    /* Repeating GV:  IMPORT_HIST_NSTD_GRP_CLAIM_EX */
    /*     Repeats: 5 times */

    int import_hist_nstd_grp_cla_ma[500];
    char import_hist_nstd_grp_cla_ac[500][5];

#else

    short svc_line_expl_code_cnt;	// Not in Document

#endif



#ifdef EDCCE01

    /* Entity View: IMPORT_HIST_NSTD_G_CLAIM_EX */
    /* Type: CLAIM_EXPLANATION_CODE_ASSN */

    char explanation_code[99][10][4];

#else

    char svc_line_expl_code[10][4];  // ca 16 fs 40
#endif





#ifdef EDCCE01

    /* Repeating GV:  IMPORT_HIST_NSTD_GRP_ALLOWED_EX */
    /*     Repeats: 5 times */

    int import_hist_nstd_grp_all_ma[500];
    char import_hist_nstd_grp_all_ac[500][5];

#else

    /* Count of elements used in "allowed_explanation_code[]" */

    short allowed_expl_code_cnt; // Not in Document

#endif




#ifdef EDCCE01

    /* Entity View: IMPORT_HIST_NSTD_G_ALLOWED_EX */
    /*        Type: CLAIM_EXPLANATION_CODE_ASSN */

    char explanation_code[500][5][4] /* 3 + 1 */;

#else

    char allowed_expl_code[5][4]; // fs 11 ca 19

#endif



#ifdef EDCCE01

    /* Repeating GV:  IMPORT_HIST_NSTD_GRP_APPROVED_EX */
    /*     Repeats: 5 times */

    int import_hist_nstd_grp_app_ma[500];
    char import_hist_nstd_grp_app_ac[500][5];

#else

    short approved_expl_code_cnt;// Not in Document

#endif




#ifdef EDCCE01
    /* Entity View: IMPORT_HIST_NSTD_G_APPROVED_EX */
    /*        Type: CLAIM_EXPLANATION_CODE_ASSN */

    char explanation_code[500][5][4] /* 3 + 1 */;

#else

    char approved_expl_code[5][4]; // fs 15 ca 19

#endif

};



#endif	/* DDEXT1_H_INCLUDED */

