#ifndef DELTA_EXTENSION_INTERFACE_H
#define DELTA_EXTENSION_INTERFACE_H

// This code need only for building extension adapter server

typedef struct
{
} CONTROL_INFO_INC;

typedef struct
{
} CONTROL_INFO;

extern void delta_extension_1(CONTROL_INFO *);
extern void delta_extension_2(CONTROL_INFO_INC *);

#endif	/* DELTA_EXTENSION_INTERFACE_H */