#include "delta_extension_interface.h"

// This code need only for building extension adapter server

extern void delta_extension_1(CONTROL_INFO *pCtl)
{
    return;
}

extern void delta_extension_2(CONTROL_INFO_INC *pCtl)
{
    return;
}