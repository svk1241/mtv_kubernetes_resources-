package main

import (
	"fmt"
	"testing"
)

func TestListFiles(t *testing.T) {

	// Test case 2: When the root directory contains files
	root := "/home/user/work/mtv_extentions_mock/extensions_mock_src/extension_adapter/server/extension_template"

	result, err := listFiles(root)
	if err != nil {
		t.Errorf("Error occurred: %v", err)
	}
	fmt.Println(result)
}

func equal(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	for i, v := range a {
		if v != b[i] {
			return false
		}
	}
	return true
}
