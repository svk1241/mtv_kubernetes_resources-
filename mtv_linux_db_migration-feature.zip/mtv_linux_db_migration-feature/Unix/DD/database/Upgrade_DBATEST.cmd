call set_11g_client_path.bat

SET MASTER_INI_FILE=D:\MV_DB_Releases\Testing.ini

java -jar MtvDbInstall.jar Upgrade.xml %*

@echo.
@echo.
@echo RC after Upgrade=%ERRORLEVEL%
@echo.
@echo.
@pause