UPGRADE README
----------------

This document explains the utilities supplied with the MetaVance Install for database upgrades.  
These utilities are located in the ../SERVER_CD/database/utilities directory on the install disk.


Upgrade utility
----------------------

The MtvDbInstall utilitizes an XML file (Upgrade.xml) to determine what steps to process. The XML file can be
found on the same directory as the MtvDbInstall.jar file.  (This document was found in the same directory.)

Also in the directory is the MtvDbInstall_2_2.xsd. This file is the xml schema definition for the xml file. 
The process uses the xsd file to insure that the xml file is in the proper format.

Included in the XML are the following nodes used by the install process:

	VERSION - This is the version of the .jar file that correspondes with this xml
	RELEASE_INFO
		RELEASE - 210
		PATCH - x
		PROCESS_TYPE - Upgrade
		PROCESS_DIRECTORY - Upgrade - this specifies where the sql can be found for the process
  
        UNIX - Information specific to a UNIX environment
  	WORKDIR - Directory where working files and logs will be placed. WORKDIR will typically be:
  		  /tmp/mtv_ora_install:  		
	  The process will create the following structure beneath WORKDIR:
	       rlsePptch/schemaOwner/SQL
	       rlsePptch/schemaOwner/SQL/DYNAMIC 
	       rlsePptch/schemaOwner/LOGS
	       rlsePptch/schemaOwner/TMP
  
        WINDOWS - Information specific to a windows environment
  	WORKDIR - Directory where working files and logs will be placed. WORKDIR will typically be:
  		  c:\temp\mtv_ora_install:  		
  	  The process will create the following structure beneath WORKDIR:
	       rlsePptch\schemaOwner\SQL
	       rlsePptch\schemaOwner\SQL\DYNAMIC 
	       rlsePptch\schemaOwner\LOGS
	       rlsePptch\schemaOwner\TMP

	TMP_EC_SOURCE_ID - 'Before' Temporary Schema ID 
                    (this is used for the 'current' version of the database to be checked)
	TMP_EC_TARGET_ID - 'After' Temporary Schema ID 
	                  (This ID is used for the database checked after the upgrade.
                           Note: This ID is not used for this release)
       
The process depends on an environment variable to be set before the process is executed.

WINDOWS: MASTER_INI_FILE
UNIX:    TUX_MASTER_INI_FILE

There is an example TUX_MASTER_INI_FILE in the same directory as this readme.txt.
The ini file will define schemas and sids that are to be used during the install process.
The ini file can also specify certain other options; see Installation Guide for details.


If all required parameters are supplied in advance, Upgrade can now be run in Silent mode. 
See Installation guide for details.

Also, the ORACLE_HOME environment variable must be set.

To run the process:

UNIX    - Upgrade.ksh
WINDOWS - Upgrade.cmd

Execution Steps - This script must be run by the DBA using a userid that has execution privileges on the script. 

Script prompts include :

1. DOMAIN. Enter the high level DOMAIN value found in the MASTER_INI_FILE file
2. SYSTEM password. Enter the password for the SYSTEM id.

The script will then perform the following steps:

1.  Apply upgrade DDL - all changes.
2.  Enable Constraints.
3.  Recompile Views if necessary
4.  Recompile Triggers if necessary
5.  Identify Invalid or Unusable Indexes.
6.  Grant Roles.
7.  Create missing synonyms for Online and Batch users.
8.  Drop unused synonyms for Online and Batch users.
9.  Apply SeedValue changes for this release.
10. Run X03 job.
11. Run X05 job.
12. Run script to clear full access string.

Log descriptions :

Master_Log.log - documents all steps that were run and whether or not they were successful.
errors.log     - any errors that occurred during the process will be documented here.

Numerous other logs are created that need to be interrogated when errors are encountered.  

Step 1 	- M210Pxx_DDL.SQL
Step 2 	- DISABLED_CONSTRAINTS.LOG
Step 3  - INVALID_VIEWS.LOG
Step 4  - INVALID_TRIGGERS.LOG
Step 5  - INVALID_UNUSABLE_INDEXES.LOG
Step 6  - VERIFY_UNUSABLE_INDEXES
Step 7  - GRANT_TO_ROLE.LOG
Step 8  - CREATE_SYNONYMS.LOG
Step 9  - DROP_SYNONYMS.LOG
Step 10 - SEEDVAL_210Pxx_UPDATES.LOG
Step 11 - TEST_HX11Z00.OUT
Step 12 - TEST_HX17Z00.out
Step 13 - CLEAR_FULL_ACCESS_STRING.LOG