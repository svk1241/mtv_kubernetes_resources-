EnvChecker_readme
------------------

This document explains the Environment Checker supplied with the MetaVance Install for database upgrades.  

Environment Checker
-------------------

UNIX script    - EnvChecker_BEFORE.ksh (or EnvChecker_AFTER.ksh)
WINDOWS script - EnvChecker_BEFORE.cmd (or EnvChecker_AFTER.cmd)

The environment checker installs a temporary schema owner and structures and compares those structures 
against the customer's schema to determine discrepancies in the database structures based on release and 
patch entered. This script can run numerous times from the top.

The MtvDbInstall utilitizes an XML file (EnvChecker_BEFORE.xml & EnvChecker_AFTER.xml) to determine what 
steps to process. The XML file can be found on the same directory as the MtvDbInstall.jar file. 
(The document you are reading should have been opened from the same directory.)

Also in the directory is the MtvDbInstall_2_2.xsd. This file is the xml schema definition for the xml file. 
The process uses the xsd file to insure that the xml file is in the proper format.

Included in the XML are the following nodes used by the install process:

	VERSION - The version of the .jar file that correspondes with this xml.
	RELEASE_INFO
		RELEASE - 310
		PATCH - x
		PROCESS_TYPE - RELEASE
		PROCESS_DIRECTORY - RELEASE - this specifies where the process sql can be found.
  
        UNIX - Information specific to a UNIX environment
  	WORKDIR - Directory where working files and logs will be placed. WORKDIR will typically be:
  		  /tmp/mtv_ora_install:  		
	  The process will create the following structure beneath WORKDIR:
	       rlsePptch/schemaOwner/SQL
	       rlsePptch/schemaOwner/SQL/DYNAMIC 
	       rlsePptch/schemaOwner/LOGS
	       rlsePptch/schemaOwner/TMP
  
        WINDOWS - Information specific to a windows environment
  	WORKDIR - Directory where working files and logs will be placed. WORKDIR will typically be:
  		  c:\temp\mtv_ora_install:  		
  	  The process will create the following structure beneath WORKDIR:
	       rlsePptch\schemaOwner\SQL
	       rlsePptch\schemaOwner\SQL\DYNAMIC 
	       rlsePptch\schemaOwner\LOGS
	       rlsePptch\schemaOwner\TMP
	
        TMP_EC_SOURCE_ID - 'Before' Temporary Schema ID 
                    (this is used for the 'current' version of the database to be checked)
	TMP_EC_TARGET_ID - 'After' Temporary Schema ID 
	                  (This ID is used for the database checked after the upgrade.
                           Note: This ID is not used for this release)
       
The process depends on an environment variable to be set before the process is executed.

WINDOWS: MASTER_INI_FILE
UNIX:    TUX_MASTER_INI_FILE

There is an example MASTER_INI_FILE in the same directory as this readme.txt.
The ini file will define schemas and sids that are to be used during the install process.The ini file can also
specify certain other options; see Installation Guide for details. 

If all required parameters are supplied in advance, Environment Checker can now be run in Silent mode. See Installation 
guide for details.


Execution Steps - This script must be run by the DBA using a UNIX userid that has execution privileges on the script. 

Script prompts include:

1. DOMAIN. Enter the high level DOMAIN value found in the MASTER_INI_FILE file
2. SYSTEM password. Enter the password for the SYSTEM id.

The script will then perform the following steps:

1. Drop the temporary schema owner (if it exists) (MVENVCHKx - this will be either MVENVCHKS for before or MVENVCHKT for after).
2. Create the temporary schema owner MVENVCHKx in the USERS tablespace.
		NOTE: Please insure that the USERS tablespace and the TEMP tablespace have sufficient freespace for the process.
                      The freespace must be at least 1 Gigabyte on USERS and TEMP.
3. Populate MVENVCHKx with structures.
4. Compare Client and Temp schemas
   Once the compares are all done, if there are errors, a message will be displayed indicating that there were errors.
   The user will be prompted as to whether or not to continue(Y or N).
5.  Delete Temporary User.

Log descriptions:

Master_Log.log - documents all steps that were run and whether or not they were successful.
errors.log     - any errors that occurred during the process will be documented here.

Numerous other logs are created that need to be interrogated when errors are encountered.  

Step 1 	- DELETE_TEMP_USER_BEFORE_MVENVCHKx.LOG
Step 2 	- CREATE_TEMP_USER_MVENVCHKx.LOG
Step 3 	- W2100Pxx_DDL_MVENVCHKx.LOG
Step 4 	- ENVCHECK_MVENVCHKx.LOG
Step 5 	- DELETE_TEMP_USER_AFTER_MVENVCHKx.LOG
