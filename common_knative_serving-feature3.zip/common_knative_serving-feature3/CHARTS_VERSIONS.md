Available tested versions:
* serving 1.14.0, operator 1.15.2, istio 1.21.1, aks 1.30.5
* serving 1.19.7, operator 1.19.5, istio 1.26.2, aks 1.34.0
* serving 1.20.1, operator 1.20.1, istio 1.27.3, aks 1.34.2
* serving 1.21.0, operator 1.21.0, istio 1.28.2, aks 1.34.2
