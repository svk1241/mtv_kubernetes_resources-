#! /bin/bash

cd HttpsWrapperGo
go build HttpsWrapperGo
go test HttpsWrapperGo -v
go test ./custom_logger -v
