module SimpleTeMock

go 1.24
