package main

import (
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"time"
)

func RunAsClient(tcpAddr *net.TCPAddr, transHandler *TransactionHandlerImlp, tranChain []string, config *AppConfig) {

	timeout := config.GetTimeout()

	var tcpConn *net.TCPConn
	var httpClient *http.Client
	var err error

	if config.UseHttp {
		httpClient = http.DefaultClient
		if timeout != 0 {
			httpClient.Timeout = timeout
		}
	} else {
		tcpConn, err = net.DialTCP(NetworkType, nil, tcpAddr)
		if err != nil {
			log.Fatal(err)
		}
	}

	defer func(conn *net.TCPConn) {
		if tcpConn != nil {
			err := conn.Close()
			if err != nil {
				log.Println(err)
			}
		}
	}(tcpConn)

	log.Printf("Connected to %v", tcpAddr)

	measurementBegin := time.Now()

	timingReportFile, closer := createTimingsReport(measurementBegin, config)
	defer closer()

	transChain := newTransactionsChain(tranChain)

	for tranId, ok := transChain.nextTransactionId(); ok; tranId, ok = transChain.nextTransactionId() {
		log.Printf("Invoking transaction %s", tranId)

		if timeout != 0 && !config.UseHttp {
			_ = tcpConn.SetDeadline(time.Now().Add(timeout))
		}
		url := fmt.Sprintf("http://%s/transaction/%s", config.Addr, tranId)
		id := fmt.Sprintf("%020d", time.Now().Unix())

		code := http.StatusOK
		var nread, nwritten int64
		var err error

		beg := time.Now()
		if config.UseHttp {
			code, err = transHandler.InvokeTransactionHttp(url, id, httpClient, tranId)
		} else {
			nread, nwritten, err = transHandler.InvokeTransaction(tcpConn, tcpConn, tranId)
		}
		elapsed := time.Since(beg)

		invocationTime := beg.Sub(measurementBegin)

		status := "SUCCESS"
		if err != nil || code != http.StatusOK {
			status = "FAILURE"
		}
		log.Printf("%s for transaction %s within %v [in: %d; out %d]", status, tranId, elapsed, nread, nwritten)

		if timingReportFile != nil {
			_, errPrint := fmt.Fprintf(timingReportFile, "%s, %d, %d, %s\n", tranId, invocationTime.Microseconds(), elapsed.Microseconds(), status)
			if errPrint != nil {
				log.Fatal(err)
			}
		}

		if err != nil || code != http.StatusOK {
			if config.ExitOnFailure {
				log.Fatal(err)
			}

			if !config.UseHttp {
				log.Printf("Reconnecting...")

				err := tcpConn.Close()
				if err != nil {
					log.Println(err)
				}

				tcpConn, err = net.DialTCP(NetworkType, nil, tcpAddr)

				if err != nil {
					log.Fatal("Failed to reconnect, aborting. Reason: ", err)
				}
			}

		}

	}
}

func createTimingsReport(ts time.Time, config *AppConfig) (file *os.File, closer func()) {
	if config.StatsDir == "" {
		return nil, func() {}
	}
	timingReportFile, err := os.Create(fmt.Sprintf("timings_%d.csv", ts.Unix()))
	if err != nil {
		log.Printf("Timing will not be logged due to error: %v", err)
		return nil, func() {}
	}
	return timingReportFile, func() {
		err := timingReportFile.Close()
		if err != nil {
			log.Print(err)
		}
	}
}

type transactionsChain struct {
	chain []string
	cnt   int
	idx   int
}

func newTransactionsChain(tranIds []string) *transactionsChain {
	return &transactionsChain{
		chain: append([]string{}, tranIds...), // Create a copy
		cnt:   len(tranIds),
		idx:   0,
	}
}

func (tc *transactionsChain) nextTransactionId() (tranId string, ok bool) {
	ok = true // Loop is infinite now
	tranId = tc.chain[tc.idx]
	tc.idx = (tc.idx + 1) % tc.cnt
	return
}
