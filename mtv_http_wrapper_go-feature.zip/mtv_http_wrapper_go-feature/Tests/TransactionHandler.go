package main

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"strings"
	"time"
)

const (
	MessageLengthSize        = 4
	TransactionIdSectionSize = 8
)

type transactionData struct {
	Request  string `json:"request"`
	Response string `json:"response"`
	Delay    string `json:"delay"`
}

type TransactionHandlerImlp struct {
	TransactionsMap        map[string]*transactionData `json:"tranMap"`
	ErrorProcessingRequest bool                        `json:"ErrorProcessingRequest"`
	WrongContentType       bool                        `json:"WrongContentType"`
}

func NewTransactionHandler() *TransactionHandlerImlp {
	jsonTransactionHandler, err := os.ReadFile("transactions.json")
	if err != nil {
		panic(err)
	}

	transactionHandlerImpl := &TransactionHandlerImlp{}

	err = json.Unmarshal(jsonTransactionHandler, &transactionHandlerImpl)
	if err != nil {
		panic(err)
	}

	return transactionHandlerImpl
}

func (handler *TransactionHandlerImlp) HandleTransaction(dst io.Writer, src io.Reader) (tranId string, received int64, sent int64, err error) {
	tranId, received, err = receiveRequest(handler.TransactionsMap, src)
	if err != nil {
		return tranId, received, 0, err
	}

	tranData := handler.TransactionsMap[tranId]

	delay, err := time.ParseDuration(tranData.Delay)
	if err != nil {
		log.Printf("Could not parse delay (set to '%s') for transaction '%s'. Assumed to be 0.",
			tranData.Delay, tranId)
		delay = 0
	}

	time.Sleep(delay)

	sent, err = sendResponse(tranData, tranId, dst)
	return tranId, received, sent, err
}

func (handler *TransactionHandlerImlp) InvokeTransaction(dst io.Writer, src io.Reader, tranId string) (received int64, sent int64, err error) {
	tranData, ok := handler.TransactionsMap[tranId]

	if !ok || len([]byte(tranId)) > TransactionIdSectionSize {
		return 0, 0, errors.New("invalid transaction ID")
	}

	sent, err = sendRequest(tranData, tranId, dst)
	if err != nil {
		return sent, 0, err
	}

	// Do some stuff maybe ...

	received, err = receiveResponse(tranData, tranId, src)
	return sent, received, err
}

func (handler *TransactionHandlerImlp) InvokeTransactionHttp(url string, id string, c *http.Client, tranId string) (code int, err error) {
	tranData, ok := handler.TransactionsMap[tranId]

	if !ok || len([]byte(tranId)) > TransactionIdSectionSize {
		return 0, errors.New("invalid transaction ID")
	}

	reqBuf := &bytes.Buffer{}

	_, err = sendRequest(tranData, tranId, reqBuf)
	if err != nil {
		return 0, err
	}

	r, err := http.NewRequest(http.MethodPost, url, reqBuf)
	if err != nil {
		return 0, err
	}
	r.Header.Add("X-MTV-ClientId", "SimpleTeMock")
	r.Header.Add("X-MTV-RequestId", id)
	r.Header.Add("X-MTV-CallUrl", url)
	if GlobalTransHandler.WrongContentType {
		r.Header.Add("Content-Type", "application/wrong")
	} else {
		r.Header.Add("Content-Type", "application/octet-stream")
	}

	response, err := c.Do(r)
	if err != nil {
		return 0, err
	}

	_, err = receiveResponse(tranData, tranId, response.Body)
	return response.StatusCode, err
}

// Client-side
func sendRequest(tranData *transactionData, tranId string, dst io.Writer) (sent int64, err error) {

	requestLength := int32(MessageLengthSize + TransactionIdSectionSize + len(tranData.Request))

	requestBuffer := &bytes.Buffer{}

	// bytes.Buffer::Write never fails
	_ = binary.Write(requestBuffer, binary.BigEndian, &requestLength)
	_, _ = requestBuffer.Write([]byte(fmt.Sprintf("%-*s", TransactionIdSectionSize, tranId)))
	_, _ = io.Copy(requestBuffer, strings.NewReader(tranData.Request))

	nw, err := io.CopyN(dst, requestBuffer, int64(requestLength))
	if err != nil {
		return nw, err
	}

	return int64(requestLength), nil
}

func receiveResponse(tranData *transactionData, tranId string, src io.Reader) (received int64, err error) {
	responseLength := int32(MessageLengthSize + TransactionIdSectionSize + len(tranData.Response))

	var receivedResponseLength int32

	err = binary.Read(src, binary.BigEndian, &receivedResponseLength)
	if err != nil {
		return 0, err
	}

	if receivedResponseLength != responseLength {
		return MessageLengthSize, errors.New(fmt.Sprintf(
			"Got invalid size in response: %d, expected %d", receivedResponseLength, responseLength))
	}

	receivedTranIdBuffer := &bytes.Buffer{}

	nr, err := io.CopyN(receivedTranIdBuffer, src, TransactionIdSectionSize)
	if err != nil {
		return MessageLengthSize + nr, err
	}

	receivedTranId := strings.TrimSpace(receivedTranIdBuffer.String())

	if receivedTranId != tranId {
		return MessageLengthSize + TransactionIdSectionSize, errors.New(fmt.Sprintf(
			"Got response for transaction %s, but expected for %s", receivedTranId, tranId))
	}

	receivedResponseBuffer := &bytes.Buffer{}

	nr, err = io.CopyN(receivedResponseBuffer, src, int64(responseLength-MessageLengthSize-TransactionIdSectionSize))
	if err != nil {
		return MessageLengthSize + TransactionIdSectionSize + nr, err
	}

	if tranData.Response != receivedResponseBuffer.String() {
		return int64(responseLength), errors.New("response body data mismatch")
	}

	return int64(responseLength), nil
}

// Server-side
func receiveRequest(tranDataMap map[string]*transactionData, src io.Reader) (tranId string, received int64, err error) {
	var receivedRequestLength int32

	err = binary.Read(src, binary.BigEndian, &receivedRequestLength)
	if err != nil {
		return "", 0, err
	}

	if receivedRequestLength < MessageLengthSize+TransactionIdSectionSize {
		return "", MessageLengthSize, errors.New(fmt.Sprintf(
			"Received message length is too small: %d, should be >= %d",
			receivedRequestLength,
			MessageLengthSize+TransactionIdSectionSize))
	}

	receivedTranIdBuffer := &bytes.Buffer{}

	nr, err := io.CopyN(receivedTranIdBuffer, src, TransactionIdSectionSize)
	if err != nil {
		return "", MessageLengthSize + nr, err
	}

	receivedTranId := strings.TrimSpace(receivedTranIdBuffer.String())

	tranData, ok := tranDataMap[receivedTranId]

	if !ok {
		return "", MessageLengthSize + TransactionIdSectionSize, errors.New("invalid transaction ID")
	}

	requestLength := int32(MessageLengthSize + TransactionIdSectionSize + len(tranData.Request))

	if receivedRequestLength != requestLength {
		return receivedTranId, MessageLengthSize, errors.New(fmt.Sprintf(
			"Got invalid size in request: %d, expected %d", receivedRequestLength, requestLength))
	}

	receivedRequestBuffer := &bytes.Buffer{}

	nr, err = io.CopyN(receivedRequestBuffer, src, int64(requestLength-MessageLengthSize-TransactionIdSectionSize))
	if err != nil {
		return receivedTranId, MessageLengthSize + TransactionIdSectionSize + nr, err
	}

	if tranData.Request != receivedRequestBuffer.String() {
		return receivedTranId, int64(requestLength), errors.New("request body data mismatch")
	}

	return receivedTranId, int64(requestLength), nil
}

func sendResponse(tranData *transactionData, tranId string, dst io.Writer) (sent int64, err error) {
	responseLength := int32(MessageLengthSize + TransactionIdSectionSize + len(tranData.Response))

	responseBuffer := &bytes.Buffer{}

	// bytes.Buffer::Write never fails
	_ = binary.Write(responseBuffer, binary.BigEndian, &responseLength)
	_, _ = responseBuffer.Write([]byte(fmt.Sprintf("%-*s", TransactionIdSectionSize, tranId)))
	_, _ = io.Copy(responseBuffer, strings.NewReader(tranData.Response))
	if GlobalTransHandler.ErrorProcessingRequest {
		nw, _ := io.CopyN(dst, responseBuffer, 4)
		err := dst.(io.Closer).Close()
		if err != nil {
			return nw, err
		}
	} else {
		nw, err := io.CopyN(dst, responseBuffer, int64(responseLength))
		if err != nil {
			return nw, err
		}
	}

	return int64(responseLength), nil
}
