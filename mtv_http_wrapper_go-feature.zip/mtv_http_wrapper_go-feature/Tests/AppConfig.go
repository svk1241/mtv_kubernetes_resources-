package main

import (
	"fmt"
	"os"
	"strings"
	"time"
)

func PrintUsageAndExit(reason string) {
	usageLines := []string{
		"Usage: SimpleTeMock [OPTIONS]",
		"-r|--role            : Pass 'SERVER' to run as server (default is 'SERVER').",
		"                       Pass '%TRAN_ID%(:%TRAN_ID%)+' to run as client;",
		"                           transactions will be invoked in given order in loop.",
		"-a|--address         : Listen address for server mode, target address for client mode (default is '127.0.0.1:27028').",
		"-s|--stats-dir       : Location for csv in for of 'tranId, usFromBegin, usElapsed, status'.",
		"-t|--tran-timeout    : If set, transactions will be limit with given duration (to timeout by default)",
		"  |--use-http        : If set, client will send requests as http POST to 'http://%address%/transaction/%tranId%'",
		"-e|--exit-on-failure : If set, no attempts to reconnect will be made in case of transaction failure",
		"-h|--help            : Print this help",
	}

	usageMerged := strings.Join(usageLines, "\n")

	if reason != "" {
		fmt.Println(reason)
	}
	fmt.Println(usageMerged)
	if reason != "" {
		os.Exit(1)
	}
	os.Exit(0)
}

type AppConfig struct {
	Role          string
	Addr          string
	StatsDir      string
	Timeout       string
	UseHttp       bool
	ExitOnFailure bool
}

func ParseArgs(cliArgs []string) (config *AppConfig) {
	config = &AppConfig{
		Role:          "SERVER",
		Addr:          "127.0.0.1:27028",
		StatsDir:      "/tmp",
		ExitOnFailure: false,
		Timeout:       "",
	}

	for len(cliArgs) > 0 {
		switch cliArgs[0] {
		case "-r":
			fallthrough
		case "--role":
			if len(cliArgs) < 2 {
				PrintUsageAndExit("Missing value for role")
			}
			config.Role = cliArgs[1]
			cliArgs = cliArgs[2:]
		case "-a":
			fallthrough
		case "--address":
			if len(cliArgs) < 2 {
				PrintUsageAndExit("Missing value for address")
			}
			config.Addr = cliArgs[1]
			cliArgs = cliArgs[2:]
		case "-s":
			fallthrough
		case "--stats-dir":
			if len(cliArgs) < 2 {
				PrintUsageAndExit("Missing value for stats-dir")
			}
			config.StatsDir = cliArgs[1]
			cliArgs = cliArgs[2:]
		case "-t":
			fallthrough
		case "--tran-timeout":
			if len(cliArgs) < 2 {
				PrintUsageAndExit("Missing value for tran-timeout")
			}
			config.Timeout = cliArgs[1]
			cliArgs = cliArgs[2:]
		case "--use-http":
			config.UseHttp = true
			cliArgs = cliArgs[1:]
		case "-e":
			fallthrough
		case "--exit-on-failure":
			config.ExitOnFailure = true
			cliArgs = cliArgs[1:]
		case "-h":
			fallthrough
		case "--help":
			PrintUsageAndExit("")
		default:
			PrintUsageAndExit(fmt.Sprintf("Unexpected argument: %s", cliArgs[0]))
		}
	}

	return config
}

func (appConfig *AppConfig) GetTimeout() time.Duration {
	timeout := time.Duration(0)
	if appConfig.Timeout != "" {
		parsedTimeout, err := time.ParseDuration(appConfig.Timeout)
		if err == nil {
			timeout = parsedTimeout
		}
	}
	return timeout
}
