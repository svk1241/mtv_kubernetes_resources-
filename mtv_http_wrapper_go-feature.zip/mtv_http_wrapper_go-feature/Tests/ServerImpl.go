package main

import (
	"errors"
	"io"
	"net"
	"os"
	"time"
)
import "log"

func RunAsServer(tcpAddr *net.TCPAddr, transHandler *TransactionHandlerImlp, config *AppConfig) {
	listener, err := net.ListenTCP(NetworkType, tcpAddr)
	if err != nil {
		log.Fatal(err)
	}

	log.Printf("Listening on %v", tcpAddr)

	defer func(listener net.Listener) {
		err := listener.Close()
		if err != nil {
			log.Print(err)
		}
	}(listener)

	for {
		conn, err := listener.Accept()

		if err != nil {
			log.Print(err)
			continue
		}

		go handleConnection(conn, transHandler, config)
	}
}

func handleConnection(conn net.Conn, transHandler *TransactionHandlerImlp, config *AppConfig) {
	defer func(conn net.Conn) {
		err := conn.Close()
		if err != nil {
			log.Print(err)
		}
	}(conn)

	timeout := config.GetTimeout()

	for {
		if timeout != 0 {
			_ = conn.SetDeadline(time.Now().Add(timeout))
		}
		beg := time.Now()
		tranId, nread, nwritten, err := transHandler.HandleTransaction(conn, conn)
		elapsed := time.Since(beg)
		if err != nil {
			if err == io.EOF && nread == 0 {
				log.Printf("[%s] Connection closed by client", tranId)
			} else if errors.Is(err, os.ErrDeadlineExceeded) {
				log.Printf("Timeout exceeded for transaction %s within %v [in: %d; out %d]: %v", tranId, elapsed, nread, nwritten, err)
			} else {
				log.Printf("Failed to handle transaction %s within %v [in: %d; out %d]: %v", tranId, elapsed, nread, nwritten, err)
			}
			break
		}
		log.Printf("Successfully handled transaction %s within %v [in: %d; out %d]", tranId, elapsed, nread, nwritten)
	}
}
