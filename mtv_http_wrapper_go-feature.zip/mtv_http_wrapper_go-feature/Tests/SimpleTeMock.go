package main

import (
	"fmt"
	"log"
	"net"
	"os"
	"regexp"
	"strings"
)

const (
	NetworkType = "tcp"
)

var GlobalTransHandler *TransactionHandlerImlp

func main() {

	config := ParseArgs(os.Args[1:])

	GlobalTransHandler = NewTransactionHandler()

	tcpAddr, err := net.ResolveTCPAddr(NetworkType, config.Addr)
	if err != nil {
		log.Fatal(err)
	}

	tranChainRe := regexp.MustCompile("[A-Z0-9]{4}(:[A-Z0-9]{4})*")

	switch {
	case config.Role == "SERVER":
		RunAsServer(tcpAddr, GlobalTransHandler, config)
	case tranChainRe.MatchString(config.Role):
		tranChain := strings.Split(config.Role, ":")
		RunAsClient(tcpAddr, GlobalTransHandler, tranChain, config)
	default:
		PrintUsageAndExit(fmt.Sprintf("Invalid role: %s", config.Role))
	}

}
