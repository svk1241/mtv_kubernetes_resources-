package main

import (
	"encoding/json"
	"os"
	"strconv"
	"strings"

	custom_logger "luxproject.luxoft.com/stash/scm/mpcexp/lms_logger_go.git"
)

type Logging struct {
	File_LogLevel    string `json:"File_LogLevel"`
	Console_LogLevel string `json:"Console_LogLevel"`
}

type AppSetting struct {
	Logging                                 Logging `json:"Logging"`
	AllowedHosts                            string  `json:"AllowedHosts"`
	MtvTrancsactionEnablerHost              string  `json:"MTV_TE_HOST"`
	MtvTrancsactionEnablerPort              int     `json:"MTV_TE_PORT"`
	TrancsactionEnablerStatusCode           int     `json:"TE_ERROR_STATUS_CODE"`
	TrancsactionEnablerUnavailableCode      int     `json:"TE_UNAVAILABLE_STATUS_CODE"`
	UseSmartHealth                          bool    `json:"UseSmartHealth"`
	UseAuthKey                              bool    `json:"UseAuthKey"`
	AuthHeaderName                          string  `json:"AuthHeaderName"`
	AuthKey                                 string  `json:"AuthKey"`
	InstanceId                              string  `json:"InstanceId"`
	LogUsingConsoleWriteln                  bool    `json:"LogUsingConsoleWriteln"`
	LogFileUseTimestamp                     bool    `json:"LogFileUseTimestamp"`
	LogFileTimestampPattern                 string  `json:"LogFileTimestampPattern"`
	LogFileTimestampFormat                  string  `json:"LogFileTimestampFormat"`
	LogFormat                               string  `json:"LogFormat"`
	LogFile                                 string  `json:"LogFile"`
	LogFileTracing                          bool    `json:"LogFileTracing"`
	LogFileReportFilenameStdOut             bool    `json:"LogFileReportFilenameStdOut"`
	X_B3_Sampled                            bool    `json:"X-B3-Sampled"`
	Zipkin_collector                        string  `json:"Zipkin-collector"`
	DoRestartTE                             bool    `json:"DoRestartTE"`
	RestartTrancsactionEnablerEndpoint      string  `json:"RestartTeEndpoint"`
	RestartTrancsactionEnablerForceEndpoint string  `json:"RestartTeForceEndpoint"`
	MtvTrDefaultTimeoutSeconds              int     `json:"MTV_TR_DEFAULT_TIMEOUT"`
	HttpReadTimeoutSeconds                  int     `json:"HttpReadTimeoutSeconds"`
	HttpWriteTimeoutSeconds                 int     `json:"HttpWriteTimeoutSeconds"`
	FireAndForgetForAsyncTransactions       bool    `json:"FireAndForgetForAsyncTransactions"`
	ListOfAsyncTransactionsCSV              string  `json:"MtvListOfAsyncTransactionsCSV"`
	MtvListOfAsyncTransactionsCSV           map[string]struct{}
}

type HostAndPort struct {
	Host string
	Port string
}

type Port struct {
	Port string
}

func StrToMap(str string) map[string]struct{} {
	var strMap = make(map[string]struct{})
	strSplit := strings.Split(strings.ReplaceAll(str, " ", ""), ",")
	for _, s := range strSplit {
		if s != "" {
			strMap[s] = struct{}{}
		}
	}
	return strMap
}

func (s *AppSetting) SettingArrToMap() {
	s.MtvListOfAsyncTransactionsCSV = StrToMap(s.ListOfAsyncTransactionsCSV)
}

func GetAppSetting(appsettingsFileName string) (appSetting *AppSetting, settings_map *map[string]interface{}, err error) {
	// Fill some default values
	appSetting = &AppSetting{
		MtvTrancsactionEnablerHost:         "localhost",
		MtvTrancsactionEnablerPort:         3888,
		TrancsactionEnablerStatusCode:      550,
		TrancsactionEnablerUnavailableCode: 503,
		LogUsingConsoleWriteln:             true,
		HttpReadTimeoutSeconds:             900,
		HttpWriteTimeoutSeconds:            900,
		MtvTrDefaultTimeoutSeconds:         120,
		FireAndForgetForAsyncTransactions:  true,
		ListOfAsyncTransactionsCSV:         string("PPMK, M742, B312, xI001"),
	}

	jsonAppSettings, err := os.ReadFile(appsettingsFileName)
	if err != nil {
		return
	}
	err = json.Unmarshal(jsonAppSettings, &appSetting)
	if err != nil {
		return
	}
	appSetting.SettingArrToMap()
	var json_map map[string]interface{}
	err = json.Unmarshal(jsonAppSettings, &json_map)
	if err != nil {
		return
	}
	settings_map = &json_map
	return appSetting, settings_map, nil
}

func SetTEHostAndPort(appSetting *AppSetting) (TCPaddr HostAndPort) {
	TCPaddr.Host = appSetting.MtvTrancsactionEnablerHost
	TCPaddr.Port = strconv.Itoa(appSetting.MtvTrancsactionEnablerPort)
	return TCPaddr
}

func (h *HostAndPort) GetAddr(log *custom_logger.CustomLogger) string {
	return h.Host + ":" + h.Port
}

func (p *Port) GetPortString() string {
	return ":" + p.Port
}
