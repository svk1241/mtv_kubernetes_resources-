package main

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/openzipkin/zipkin-go"
	custom_logger "luxproject.luxoft.com/stash/scm/mpcexp/lms_logger_go.git"
)

type WrapperHandler struct {
	ErrorStatusCode                  int
	TeTcpAddr                        HostAndPort
	TeUnavailableHttpStatusCode      int
	RequestProcessingErrorStatusCode int
}

func IsSuccess(httpStatusCode int) (success bool) {
	return (httpStatusCode >= 200) && (httpStatusCode <= 299)
}

func GetTransactionId(Path string) (transactionId string) {
	strs := strings.Split(Path, "/")
	if len(strs) > 0 {
		return strs[len(strs)-1]
	}
	return "null"
}

func SetSpanTags(r *http.Request, httpStatusCode int, log *custom_logger.CustomLogger) {
	if GlobalAppSetting.X_B3_Sampled {
		// retrieve span from context (created by server middleware)
		span := zipkin.SpanFromContext(r.Context())
		span.Tag("http.status_code", fmt.Sprintf("%d", httpStatusCode))
		span.Tag("http.url", "tcp://"+GlobalAppSetting.MtvTrancsactionEnablerHost+":"+PortHTTP.GetPortString())
		span.Tag("clientId", r.Header.Get("X-MTV-ClientId"))
		span.Tag("requestId", r.Header.Get("X-MTV-RequestId"))
		log.Debug("Zipkin TraceID: ", span.Context().TraceID)
	}
}

func (handler *WrapperHandler) ServeHTTP(w http.ResponseWriter, r *http.Request,
	transactionTimeout time.Duration) {

	start := time.Now()

	transactionId := GetTransactionId(r.URL.Path)
	clientId := r.Header.Get("X-MTV-ClientId")
	requestId := r.Header.Get("X-MTV-RequestId")
	callUrl := r.Header.Get("X-MTV-CallUrl")
	globalExtensionAdapterData.RequestId = requestId
	globalExtensionAdapterData.TransactionTimeout = transactionTimeout
	globalExtensionAdapterData.TransactionId = transactionId
	hostName, err := os.Hostname()
	if err != nil {
		hostName = "env {hostnameEnvVar} is not set"
	}
	var elapsedMs *int
	elapsedMs = nil
	var successfulptr *bool
	successfulptr = nil
	var httpStatusCodeptr *int
	httpStatusCodeptr = nil
	httpStatusCode := 0
	var isize int64 = 0
	var osize int64 = 0

	logAgs := map[string]interface{}{
		"Context":       "SRV",
		"InstanceId":    GetInstanceId(),
		"ClientId":      &clientId,
		"RequestId":     &requestId,
		"CallUrl":       &callUrl,
		"Hostname":      &hostName,
		"TransactionId": &transactionId,
		"ElapsedMs":     &elapsedMs,
		"Successful":    &successfulptr,
		"HttpStatus":    &httpStatusCodeptr,
		"isize":         &isize,
		"osize":         &osize,
	}

	log := custom_logger.GetNewLog(&logAgs, GlobalLoggingSettings)
	var duration time.Duration

	defer func() {
		if flusher, ok := w.(http.Flusher); ok {
			flusher.Flush()
		}
		log.Information("Elapsed " + custom_logger.GetElapsedForMessage(duration))
	}()

	log.Debug("Called transaction ", transactionId)
	log.Debug(fmt.Sprintf("Timeout for %s is %.0f seconds", transactionId, transactionTimeout.Seconds()))
	countToTe, countFromTe, httpStatusCode, err := handler.handleTransaction(w, r, start.Add(transactionTimeout), log, &isize, &osize)

	httpStatusCodeptr = &httpStatusCode
	successful := IsSuccess(httpStatusCode)
	successfulptr = &successful
	duration = time.Since(start)
	duration_int := int(duration.Milliseconds())

	elapsedMs = &duration_int

	contentType := strings.ToLower(r.Header.Get("Content-Type"))

	if !strings.Contains(contentType, "application/octet-stream") {
		httpStatusCode := http.StatusUnsupportedMediaType
		w.WriteHeader(httpStatusCode)
		log.Debug("Wrong Content Type. Should be contain json (for b64), text/plan (for b64) or application/octet-stream (for binary)")
		SetSpanTags(r, httpStatusCode, log)
		return
	}

	if err != nil {
		if netErr, ok := err.(*net.OpError); ok {
			if netErr.Timeout() {
				httpStatusCode = 408
				RestarterTE.RequestTeRestart(log, true)

				w.WriteHeader(httpStatusCode)

				log.Error("Timeout Exceeded.", err)
				log.Debug(fmt.Sprintf("Written to MTV: %d b; Received back %d b; success %t in %s",
					countToTe, countFromTe, IsSuccess(httpStatusCode), custom_logger.GetElapsedForMessage(duration)))
				SetSpanTags(r, httpStatusCode, log)
				return
			}
		}
		httpStatusCode = handler.RequestProcessingErrorStatusCode
		w.WriteHeader(httpStatusCode)
		log.Error("Error processing request:", err)
		SetSpanTags(r, httpStatusCode, log)
		return
	} else if !IsSuccess(httpStatusCode) {
		RestarterTE.RequestTeRestart(log, false)
	}

	SetSpanTags(r, httpStatusCode, log)
	log.Debug(fmt.Sprintf("Written to MTV: %d b; Received back %d b; success %t in %s",
		countToTe, countFromTe, IsSuccess(httpStatusCode), custom_logger.GetElapsedForMessage(duration)))
}

func FireAndForget(w http.ResponseWriter, log *custom_logger.CustomLogger, countToTe int64) (_, countFromTe int64, statusCode int, err error) {
	log.Debug("Transaction is of type ASYNC, so just fire and forget. Returning immediately.")
	asyncMessage := "ASYNC"
	asyncMessageSize := int32(len(asyncMessage) + 4)
	asyncBuf := new(bytes.Buffer)
	_ = binary.Write(asyncBuf, binary.BigEndian, asyncMessageSize)
	_, _ = io.WriteString(asyncBuf, asyncMessage)

	statusCode = http.StatusOK
	w.WriteHeader(statusCode)
	countFromTe, err = copyTransactionMessage(w, asyncBuf)
	if err != nil {
		return 0, 0, statusCode, err
	}
	return countToTe, countFromTe, statusCode, nil
}

func (handler *WrapperHandler) handleTransaction(w http.ResponseWriter, r *http.Request,
	transactionDeadline time.Time, log *custom_logger.CustomLogger, isize *int64, osize *int64) (countToTe int64, countFromTe int64, statusCode int, err error) {

	log.Debug("Using Transaction Enabler on ", handler.TeTcpAddr.Host, ":", handler.TeTcpAddr.Port)
	tcpConn, err := TCPConnect(handler.TeTcpAddr, transactionDeadline, log)
	if err != nil {
		log.Error(fmt.Sprintf("Cannot create TCP client: %s", err.Error()))
		w.WriteHeader(handler.TeUnavailableHttpStatusCode)
		return 0, 0, handler.TeUnavailableHttpStatusCode, nil // nil is to preserve original logic
	}

	defer func(tcpConn *net.TCPConn) {
		err := tcpConn.Close()
		if err != nil {
			log.Error(err)
		}
	}(tcpConn)

	countToTe, err = copyTransactionMessage(tcpConn, r.Body)
	*isize = countToTe
	if err != nil {
		return 0, 0, 0 /* To be overridden */, err
	}

	// take Transaction Type into account
	log.Debug(fmt.Sprintf("Transaction type: %s", GetTransactionId(r.URL.Path)))
	_, isAsync := GlobalAppSetting.MtvListOfAsyncTransactionsCSV[GetTransactionId(r.URL.Path)]
	if isAsync {
		log.Debug("Transaction type: ASYNC")
	} else {
		log.Debug("Transaction type: NORMAL")
	}

	if GlobalAppSetting.FireAndForgetForAsyncTransactions {
		log.Debug("Transactions of type ASYNC should return immediately. Checking.")
		if isAsync {
			return FireAndForget(w, log, countToTe)
		} else {
			log.Debug("Transaction is of type NORMAL. Proceed with getting its answer.")
		}
	} else {
		log.Debug("Application is configured to process all transactions as if they are NORMAL. " +
			"Set FireAndForgetForAsyncTransactions app settings to true (default is true) to fire-and-forget for ASYNC transactions")
	}

	log.Debug("Start reading from TE stream")

	responseBuffer := &bytes.Buffer{}

	nread, err := copyTransactionMessage(responseBuffer, tcpConn)
	if err != nil {
		return 0, 0, 0 /* To be overridden */, err
	}

	statusCodeAsText := "OK"
	statusCode = http.StatusOK

	messageLength, err := BufferChecker(responseBuffer.Bytes(), int32(nread), log)
	if err != nil {
		// Hard error, do 500
		if err != CheckBufferError {
			return 0, 0, 0 /* To be overridden */, err
		}
		// Soft error, do ErrorStatusCode
		statusCode = handler.ErrorStatusCode
		statusCodeAsText = "ERROR"
		log.Error(fmt.Sprintf("Response from TE: %s returning status code %d", statusCodeAsText, statusCode))
	}
	log.Debug(fmt.Sprintf("Response from TE: %s returning status code %d", statusCodeAsText, statusCode))
	log.Debug(fmt.Sprintf("Message lenght %d", messageLength))

	w.Header().Add("Content-Length", fmt.Sprintf("%d", messageLength))
	w.WriteHeader(statusCode)
	countFromTe, err = copyTransactionMessage(w, responseBuffer)
	*osize = countFromTe
	if err != nil {
		return 0, 0, statusCode, err
	}
	log.Debug("All reading and writing done.")
	return countToTe, countFromTe, statusCode, nil
}

func TCPConnect(addr HostAndPort, transactionDeadline time.Time, log *custom_logger.CustomLogger) (tcpConn *net.TCPConn, err error) {
	tcpAddr, err := net.ResolveTCPAddr("tcp", addr.GetAddr(log))
	if err != nil {
		log.Error("Error TCP client start:", err)
		return nil, err
	}
	log.Debug("TCP client start")

	tcpConn, err = net.DialTCP("tcp", nil, tcpAddr)
	if err != nil {
		log.Error("Error TCP client Dial:", err)
		return nil, err
	}
	err = tcpConn.SetDeadline(transactionDeadline)
	if err != nil {
		log.Error("Error TCP client set deadline:", err)
		return nil, err
	}

	log.Debug("DialTCP")

	return tcpConn, err
}

func copyTransactionMessage(dst io.Writer, src io.Reader) (bytesCopied int64, err error) {
	var messageSize int32
	err = binary.Read(src, binary.BigEndian, &messageSize)
	if err != nil {
		//return 0, errors.New("Wrong input message: first 4 bytes should reflect message length. Message is less than 4 bytes.")
		return 0, err
	}

	if messageSize > 0 {
		err = binary.Write(dst, binary.BigEndian, &messageSize)
		if err != nil {
			return 0, err
		}

		nb, err := io.CopyN(dst, src, int64(messageSize)-4 /* Exclude length of already sent messageSize's 4 bytes */)
		return nb + 4, err
	}
	return 0, nil
}
