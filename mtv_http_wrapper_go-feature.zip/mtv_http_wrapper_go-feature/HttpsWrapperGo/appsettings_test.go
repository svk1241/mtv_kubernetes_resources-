package main

import (
	"encoding/json"
	"io/ioutil"
	"os"
	"testing"
	"time"

	custom_logger "luxproject.luxoft.com/stash/scm/mpcexp/lms_logger_go.git"
)

func GetTestAppSetting() AppSetting {
	return AppSetting{
		Logging: Logging{
			File_LogLevel:    "debug",
			Console_LogLevel: "debug",
		},
		AllowedHosts:                       "127.0.0.1",
		MtvTrancsactionEnablerHost:         "localhost",
		MtvTrancsactionEnablerPort:         8080,
		TrancsactionEnablerStatusCode:      200,
		UseSmartHealth:                     true,
		UseAuthKey:                         false,
		AuthHeaderName:                     "name",
		AuthKey:                            "key",
		InstanceId:                         "test",
		LogFileUseTimestamp:                false,
		LogFileTimestampPattern:            "[TS]",
		LogFileTimestampFormat:             "2006-01-02",
		LogFormat:                          "json",
		LogFile:                            "/tmp/https-wrapper-log_[TS].log",
		LogFileTracing:                     false,
		LogFileReportFilenameStdOut:        false,
		DoRestartTE:                        false,
		RestartTrancsactionEnablerEndpoint: "127.0.0.1:9999/te_restarter",
	}
}

func TestGetAppSetting(t *testing.T) {
	appSettings := GetTestAppSetting()
	jsonAppSettings, _ := json.Marshal(appSettings)
	tmpfile, err := ioutil.TempFile("", "appsettings.json")
	if err != nil {
		t.Fatal(err)
	}
	defer os.Remove(tmpfile.Name())
	if _, err := tmpfile.Write(jsonAppSettings); err != nil {
		t.Fatal(err)
	}
	if err := tmpfile.Close(); err != nil {
		t.Fatal(err)
	}

	_, _, err = GetAppSetting(tmpfile.Name())
	if err != nil {
		t.Errorf("GetAppSetting returned error: %v", err)
	}
}

func TestSetTEHostAndPort(t *testing.T) {
	appSetting := AppSetting{
		MtvTrancsactionEnablerHost: "example.com",
		MtvTrancsactionEnablerPort: 1234,
		//TODO make more fields
	}

	expectedTCPAddr := HostAndPort{
		Host: "example.com",
		Port: "1234",
		//TODO make more fields
	}

	actualTCPAddr := SetTEHostAndPort(&appSetting)

	if actualTCPAddr != expectedTCPAddr {
		t.Errorf("Expected TCPAddr to be %v, but got %v", expectedTCPAddr, actualTCPAddr)
	}
}

func TestGetAddr(t *testing.T) {
	tcpAddr := HostAndPort{
		Host: "example.com",
		Port: "1234",
	}

	expectedAddr := "example.com:1234"

	actualAddr := tcpAddr.GetAddr(&custom_logger.CustomLogger{})

	if actualAddr != expectedAddr {
		t.Errorf("Expected address to be %s, but got %s", expectedAddr, actualAddr)
	}
}

func TestGetPortString(t *testing.T) {
	port := Port{Port: "8080"}

	got := port.GetPortString()
	expected := ":8080"

	if got != expected {
		t.Errorf("Expected port string to be %s, but got %s", expected, got)
	}
}

func TestGetTimeoutTransaction(t *testing.T) {
	b := []byte(`{"MTV_TR_TIMEOUT_TR1": 100, "MTV_TR_TIMEOUT_TR2": 200}`)
	var json_map map[string]interface{}
	_ = json.Unmarshal(b, &json_map)
	GlobalAppSettingMap = &json_map
	appSetting := GetTestAppSetting()
	GlobalAppSetting = &appSetting
	duration := getTransactionTimeout("TR1")
	duration = duration / time.Second
	if duration.String() != "100ns" {
		t.Errorf("TransactionTimeout for TR1 is not equal 100")
	}
	duration = getTransactionTimeout("TR2")
	duration = duration / time.Second
	if duration.String() != "200ns" {
		t.Errorf("TransactionTimeout for TR2 is not equal 200")
	}
	os.Setenv("MTV_TR_TIMEOUT_TR1", "3")
	duration = getTransactionTimeout("TR1")
	duration = duration / time.Second
	if duration.String() != "3ns" {
		t.Errorf("TransactionTimeout for TR1 is not equal 3")
	}
}
