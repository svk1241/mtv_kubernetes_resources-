package main

import (
	"fmt"
	"os"

	custom_logger "luxproject.luxoft.com/stash/scm/mpcexp/lms_logger_go.git"
)

func GetInstanceId() (instanceId *string) {
	instanceId = &GlobalAppSetting.InstanceId

	if *instanceId == "" {
		instanceId = nil
	}

	return instanceId
}

var TETCPAddr HostAndPort
var PortHTTP Port
var GlobalAppSetting *AppSetting
var GlobalAppSettingMap *map[string]interface{}
var GlobalLoggingSettings *custom_logger.LoggingSettings
var AppsettingsFileName string = "appsettings.json"
var RestarterTE RestartTeService

func main() {
	// set default
	PortHTTP.Port = "8080"
	if len(os.Args) == 2 {
		PortHTTP.Port = os.Args[1]
	}
	if len(os.Args) == 3 {
		PortHTTP.Port = os.Args[1]
		AppsettingsFileName = os.Args[2]
	}

	var err error

	GlobalAppSetting, GlobalAppSettingMap, err = GetAppSetting(AppsettingsFileName)
	if err != nil {
		_, _ = fmt.Fprintln(os.Stderr, err)
	}
	GlobalLoggingSettings = custom_logger.GetLoggingSettings(
		GlobalAppSetting.LogFile,
		GlobalAppSetting.LogFormat,
		GlobalAppSetting.Logging.File_LogLevel,
		GlobalAppSetting.Logging.Console_LogLevel,
		GlobalAppSetting.LogFileTimestampPattern,
		GlobalAppSetting.LogFileTimestampFormat,
		GlobalAppSetting.LogFileUseTimestamp,
		GlobalAppSetting.LogFileTracing,
		GlobalAppSetting.LogUsingConsoleWriteln,
		false,
		0,
	)

	TETCPAddr = SetTEHostAndPort(GlobalAppSetting)
	RestarterTE = SetTERestartService(GlobalAppSetting)

	server := CreateServer()
	go server.ListenAndServe()

	select {}
}
