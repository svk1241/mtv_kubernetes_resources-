#! /bin/bash

BASE_PATH=/opt/MTV/m210
GO_PATH=$(pwd)

mkdir -p $BASE_PATH/logs/{transaction-enabler,https-wrapper,te-restarter}

echo "Starting transaction enabler . . ."
cd $BASE_PATH/logs/transaction-enabler/
$BASE_PATH/online/run_tranEnab.sh

echo "Starting TE Restarter . . ."
cd $BASE_PATH/te_restarter
./run_te_restarter.sh

echo "Build and starting HTTPS Wrapper go. . ."
cd $GO_PATH
go build HttpsWrapperGo
./HttpsWrapperGo
