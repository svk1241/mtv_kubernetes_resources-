package main

import (
	"testing"

	custom_logger "luxproject.luxoft.com/stash/scm/mpcexp/lms_logger_go.git"
)

func TestCheckBufSize(t *testing.T) {
	err := CheckBufSize([]byte{0, 0, 0})
	if err == nil {
		t.Errorf("Expected error, but got nil")
	}

	err = CheckBufSize([]byte{0, 0, 0, 0})
	if err != nil {
		t.Errorf("Expected nil, but got error: %v", err)
	}
}

func TestBufferChecker(t *testing.T) {

	GlobalAppSetting, GlobalAppSettingMap, _ = GetAppSetting(AppsettingsFileName)

	GlobalLoggingSettings = custom_logger.GetLoggingSettings(
		GlobalAppSetting.LogFile,
		GlobalAppSetting.LogFormat,
		GlobalAppSetting.Logging.File_LogLevel,
		GlobalAppSetting.Logging.Console_LogLevel,
		GlobalAppSetting.LogFileTimestampPattern,
		GlobalAppSetting.LogFileTimestampFormat,
		GlobalAppSetting.LogFileUseTimestamp,
		GlobalAppSetting.LogFileTracing,
		GlobalAppSetting.LogUsingConsoleWriteln,
		false,
		0,
	)

	logAgs := map[string]interface{}{
		"Context":       "SRV",
		"InstanceId":    GetInstanceId(),
		"ClientId":      nil,
		"RequestId":     nil,
		"CallUrl":       nil,
		"Hostname":      nil,
		"TransactionId": nil,
		"ElapsedMs":     nil,
		"Successful":    nil,
		"HttpStatus":    nil,
	}

	log := custom_logger.GetNewLog(&logAgs, GlobalLoggingSettings)

	buf := []byte{0, 0, 0, 4}
	expected := int32(4)
	actual, err := BufferChecker(buf, expected, log)
	if actual != expected || err != nil {
		t.Errorf("BufferChecker() = (%v, %v), expected (%v, non-nil)", actual, err, expected)
	}

	buf = []byte{0, 0, 0, 5, 0}
	expected = int32(5)
	actual, err = BufferChecker(buf, expected, log)

	if actual != expected || err != nil {
		t.Errorf("BufferChecker() = (%v, %v), expected (%v, non-nil)", actual, err, expected)
	}

	buf = []byte{0, 0, 0, 99, 0, 0, 0, 0}
	expected = int32(99)
	actual, err = BufferChecker(buf, expected, log)

	if actual != expected || err != nil {
		t.Errorf("BufferChecker() = (%v, %v), expected (%v, non-nil)", actual, err, expected)
	}

	buf = []byte{1, 1, 1, 99, 0, 0, 0, 0}
	expected = int32(16843107)
	actual, err = BufferChecker(buf, expected, log)

	if actual != expected || err != nil {
		t.Errorf("BufferChecker() = (%v, %v), expected (%v, non-nil)", actual, err, expected)
	}

	buf = []byte{0, 0, 1, 99, 0, 0, 0, 0}
	expected = int32(99)
	actual, err = BufferChecker(buf, expected, log)

	if actual == expected || err != nil {
		t.Errorf("BufferChecker() = (%v, %v), expected (%v, non-nil)", actual, err, expected)
	}

	errCode := "$#XERR#$"
	bytes := []byte(errCode)
	buf = []byte{0, 0, 0, 99, 0, 0, 0, 0}
	buf = append(buf, bytes...)
	expected = int32(99)
	actual, err = BufferChecker(buf, expected, log)
	if actual != expected || err == nil {
		t.Errorf("BufferChecker() = (%v, %v), expected (%v, non-nil)", actual, err, expected)
	}

	errCode = "$#XFAL#$"
	bytes = []byte(errCode)
	buf = []byte{0, 0, 0, 99, 0, 0, 0, 0}
	buf = append(buf, bytes...)
	expected = int32(99)
	actual, err = BufferChecker(buf, expected, log)
	if actual != expected || err == nil {
		t.Errorf("BufferChecker() = (%v, %v), expected (%v, non-nil)", actual, err, expected)
	}

}
