#! /bin/bash

echo "Stopping transaction enabler . . ."
pkill aefad
pkill aefuf

echo "Stopping TE Restarter . . ."
pkill te_restarter

echo "Stopping HTTPS Wrapper . . ."
pkill HttpsWrapperGo
