package main

import (
	"net/http"

	custom_logger "luxproject.luxoft.com/stash/scm/mpcexp/lms_logger_go.git"
)

type RestartTeService struct {
	RestartTeEndpoint      string
	RestartTeForceEndpoint string
	DoRestartTe            bool
}

func (r *RestartTeService) RequestTeRestart(log *custom_logger.CustomLogger, force bool) {

	if !r.DoRestartTe {
		return
	}

	endpoint := r.RestartTeEndpoint
	mode := "soft"

	if force {
		endpoint = r.RestartTeForceEndpoint
		mode = "force"
	}

	if endpoint == "" {
		return
	}

	log.Debug("Calling " + endpoint + " to " + mode + " restart TE")
	resp, err := http.Get(endpoint)

	if err != nil {
		log.Error("Can't send http GET request for TE "+mode+" restart.", err)
		return
	}

	defer resp.Body.Close()

	log.Debug("Calling " + endpoint + " successful")
}

func SetTERestartService(appSetting *AppSetting) (RestarterTE RestartTeService) {

	RestarterTE.RestartTeEndpoint = appSetting.RestartTrancsactionEnablerEndpoint
	RestarterTE.RestartTeForceEndpoint = appSetting.RestartTrancsactionEnablerForceEndpoint
	RestarterTE.DoRestartTe = appSetting.DoRestartTE
	return RestarterTE
}
