package main

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"regexp"
	"strings"

	custom_logger "luxproject.luxoft.com/stash/scm/mpcexp/lms_logger_go.git"
)

var CheckBufferError = errors.New("error in buf")

func BufferChecker(buf []byte, expectedLength int32, log *custom_logger.CustomLogger) (messageLength int32, err error) {
	err = CheckBufSize(buf)
	if err != nil {
		log.Error(err)
		return 0, err
	}

	_ = binary.Read(bytes.NewReader(buf), binary.BigEndian, &messageLength)

	if messageLength != expectedLength {
		log.Error(err)
		return messageLength, err
	}

	bufStr := string(buf)
	var re = regexp.MustCompile(`@"\p{C}+"`)
	bufStr = re.ReplaceAllString(bufStr, "<--->")
	xerrList := [2]string{"$#XERR#$", "$#XFAL#$"}
	checkErr := false
	for _, xerr := range xerrList {
		thisBuffError := strings.Contains(bufStr, xerr)
		var statusMsg string
		if !thisBuffError {
			statusMsg = "OK"
			errorMsg := fmt.Sprintf("Checking buffer for error (containing %s): buffer: %s result: %s", xerr, bufStr, statusMsg)
			log.Debug(errorMsg)
			errorMsg = fmt.Sprintf("Checking buffer for error result (at least one): %s", statusMsg)
			log.Debug(errorMsg)
		} else {
			checkErr = true
			statusMsg = "ERROR"
			errorMsg := fmt.Sprintf("Checking buffer for error (containing %s): buffer: %s result: %s", xerr, bufStr, statusMsg)
			log.Error(errorMsg)
			errorMsg = fmt.Sprintf("Checking buffer for error result (at least one): %s", statusMsg)
			log.Error(errorMsg)
		}
		// TODO: print everytime
	}

	if checkErr {
		return messageLength, CheckBufferError
	}

	return messageLength, nil
}
