package main

import (
	"net/http"
	"time"

	custom_logger "luxproject.luxoft.com/stash/scm/mpcexp/lms_logger_go.git"
)

type HealthHandler struct{}

func (handler *HealthHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	logAgs := map[string]interface{}{
		"Context":       "SRV",
		"InstanceId":    GetInstanceId(),
		"ClientId":      nil,
		"RequestId":     nil,
		"CallUrl":       nil,
		"Hostname":      nil,
		"TransactionId": nil,
		"ElapsedMs":     nil,
		"Successful":    nil,
		"HttpStatus":    nil,
	}

	healthLog := custom_logger.GetNewLog(&logAgs, GlobalLoggingSettings)
	healthLog.Debug("Health check called")
	if !GlobalAppSetting.UseSmartHealth {
		healthLog.Debug("NOT checking TE. Just return")
		w.WriteHeader(200)
	} else {
		healthLog.Debug("Checking Transaction Enabler on ", TETCPAddr.Host, ":", TETCPAddr.Port)
		tcpConn, err := TCPConnect(TETCPAddr, time.Now().Add(time.Second), healthLog)
		if err != nil {
			w.WriteHeader(500)
			healthLog.Error("FAIL ", TETCPAddr.Host, ":", TETCPAddr.Port, " - ", err)
		} else {
			err := tcpConn.Close()
			if err != nil {
				healthLog.Error("FAIL ", TETCPAddr.Host, ":", TETCPAddr.Port, " - ", err)
				w.WriteHeader(500)
			} else {
				healthLog.Debug("OK ", TETCPAddr.Host, ":", TETCPAddr.Port)
				w.WriteHeader(200)
			}
		}
	}
}
