package main

type BufSizeError struct{}

func (m *BufSizeError) Error() string {
	return "Wrong message from TE: first 4 bytes should reflect message length. Message is less than 4 bytes."
}

func CheckBufSize(buf []byte) error {
	if len(buf) < 4 {
		return &BufSizeError{}
	}
	return nil
}
