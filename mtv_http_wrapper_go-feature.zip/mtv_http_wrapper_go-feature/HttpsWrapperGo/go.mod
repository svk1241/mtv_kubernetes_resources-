module HttpsWrapperGo

go 1.24

require (
	github.com/openzipkin/zipkin-go v0.4.1
	github.com/sirupsen/logrus v1.9.0
)

require (
	golang.org/x/sys v0.0.0-20220715151400-c0bba94af5f8 // indirect
	luxproject.luxoft.com/stash/scm/mpcexp/lms_logger_go.git v1.1.0 // indirect
	google.golang.org/grpc v1.58.3 // indirect
)
