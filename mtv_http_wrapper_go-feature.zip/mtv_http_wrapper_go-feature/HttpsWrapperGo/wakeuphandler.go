package main

import (
	"net/http"
)

type WakeupHandler struct{}

func (handler *WakeupHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	//w.Write([]byte("I didn't sleep"))
	w.WriteHeader(200)
}
