package main

import (
	"bytes"
	"encoding/binary"
	"io"
	"testing"
)

func TestCopyTransactionMessage(t *testing.T) {
	testMessage := "test message"
	testMessageSize := int32(len(testMessage) + 4)
	testBuffer := new(bytes.Buffer)
	err := binary.Write(testBuffer, binary.BigEndian, testMessageSize)
	if err != nil {
		t.Errorf("fail write")
	}
	_, err = io.WriteString(testBuffer, testMessage)
	if err != nil {
		t.Errorf("fail WriteString")
	}

	dst := new(bytes.Buffer)
	src := bytes.NewReader(testBuffer.Bytes())
	bytesCopied, err := copyTransactionMessage(dst, src)
	if err != nil {
		t.Errorf("err")
	}
	if bytesCopied != int64(testMessageSize) {
		t.Errorf("err bytesCopied")
	}
	if !bytes.Equal(dst.Bytes(), testBuffer.Bytes()) {
		t.Errorf("bytes !Equal")
	}

}
