package main

import (
	"net/http"
	"os"
)

type InfoHandler struct{}

// Tmp all probe 200
func (handler *InfoHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	version, err := os.ReadFile("/app/version.txt")
	if err != nil {
		w.Write([]byte("file /app/version.txt not found"))
	} else {
		w.Write(version)
	}
}
