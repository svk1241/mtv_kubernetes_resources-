package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"time"
)

type ExtensionAdapterDataHandler struct{}

type ExtensionAdapterData struct {
	RequestId          string        `json:"global_request_id"`
	TransactionTimeout time.Duration `json:"transaction_timeout"`
	TransactionId      string        `json:"global_transaction_id"`
}

var globalExtensionAdapterData ExtensionAdapterData

func (handler *ExtensionAdapterDataHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	jsonData, err := json.Marshal(globalExtensionAdapterData)
	if err != nil {
		fmt.Println("Error: can't transform json:", err)
		http.Error(w, "Internal Server Error", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "aplication/json")

	w.WriteHeader(http.StatusOK)

	w.Write(jsonData)
}
