package main

import (
	"errors"
	"fmt"
	"net"
	"net/http"
	"os"
	"regexp"
	"strconv"
	"time"

	"github.com/openzipkin/zipkin-go"
	zipkinhttp "github.com/openzipkin/zipkin-go/middleware/http"
	httpreporter "github.com/openzipkin/zipkin-go/reporter/http"
	custom_logger "luxproject.luxoft.com/stash/scm/mpcexp/lms_logger_go.git"
)

type HttpsWrapperHandler struct {
	wrapperHandler *WrapperHandler
	healthHandler  *HealthHandler
	infoHandler    *InfoHandler
	wakeupHandler  *WakeupHandler
	extAdapterData *ExtensionAdapterDataHandler
}

func GetInterfaceIpv4Addr(interfaceName string) (addr string, err error) {
	var (
		ief      *net.Interface
		addrs    []net.Addr
		ipv4Addr net.IP
	)
	if ief, err = net.InterfaceByName(interfaceName); err != nil { // get interface
		return "", err
	}
	if addrs, err = ief.Addrs(); err != nil { // get addresses
		return "", err
	}
	for _, addr := range addrs { // get ipv4 address
		if ipv4Addr = addr.(*net.IPNet).IP.To4(); ipv4Addr != nil {
			break
		}
	}
	if ipv4Addr == nil {
		return "", errors.New(fmt.Sprintf("interface %s don't have an ipv4 address\n", interfaceName))
	}
	return ipv4Addr.String(), nil
}

func CreateServer() (server *http.Server) {
	var handler http.Handler

	httpsWrapperHandler := &HttpsWrapperHandler{
		wrapperHandler: &WrapperHandler{
			ErrorStatusCode:                  GlobalAppSetting.TrancsactionEnablerStatusCode,
			TeTcpAddr:                        SetTEHostAndPort(GlobalAppSetting),
			TeUnavailableHttpStatusCode:      GlobalAppSetting.TrancsactionEnablerUnavailableCode,
			RequestProcessingErrorStatusCode: http.StatusInternalServerError,
		},
	}

	if GlobalAppSetting.X_B3_Sampled {
		logArgs := map[string]interface{}{
			"Context":       "SRV",
			"InstanceId":    GetInstanceId(),
			"ClientId":      nil,
			"RequestId":     nil,
			"CallUrl":       nil,
			"Hostname":      nil,
			"TransactionId": nil,
			"ElapsedMs":     nil,
			"Successful":    nil,
			"HttpStatus":    nil,
		}

		zipkinLog := custom_logger.GetNewLog(&logArgs, GlobalLoggingSettings)

		// set up a span reporter
		zipkinLog.Debug("Zipkin collector Address: ", GlobalAppSetting.Zipkin_collector)
		reporter := httpreporter.NewReporter(GlobalAppSetting.Zipkin_collector)

		// create our local service endpoint
		service_name, _ := os.Hostname()
		ipv4_addr, err := GetInterfaceIpv4Addr("eth0")
		if err != nil {
			zipkinLog.Error(fmt.Sprintf("Zipkin: unable to get ip address: %+v\n", err))
		}
		endpoint, err := zipkin.NewEndpoint(service_name, ipv4_addr)
		if err != nil {
			zipkinLog.Error(fmt.Sprintf("Zipkin: unable to create local endpoint: %+v\n", err))
		}

		// initialize our tracer
		tracer, err := zipkin.NewTracer(
			reporter,
			zipkin.WithSampler(zipkin.NeverSample),
			zipkin.WithLocalEndpoint(endpoint),
			zipkin.WithSharedSpans(false),
		)
		if err != nil {
			zipkinLog.Error(fmt.Sprintf("Zipkin: unable to create tracer: %+v\n", err))
		}

		serverMiddleware := zipkinhttp.NewServerMiddleware(
			tracer,
			zipkinhttp.SpanName("Https_Wrapper_Go"),
		)

		handler = serverMiddleware(httpsWrapperHandler)
	} else {
		handler = httpsWrapperHandler
	}

	minTimeout := GlobalAppSetting.MtvTrDefaultTimeoutSeconds

	readTimeout := GlobalAppSetting.HttpReadTimeoutSeconds
	if readTimeout < minTimeout {
		readTimeout = minTimeout
	}

	writeTimeout := GlobalAppSetting.HttpWriteTimeoutSeconds
	if writeTimeout < minTimeout {
		writeTimeout = minTimeout
	}

	server = &http.Server{
		Handler:      handler,
		Addr:         PortHTTP.GetPortString(),
		ReadTimeout:  time.Duration(readTimeout) * time.Second,
		WriteTimeout: time.Duration(writeTimeout) * time.Second,
	}
	return server
}

// Function to implement the http Handler interface
func (handler *HttpsWrapperHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	transactionMask := regexp.MustCompile(`/transaction/[A-Z0-9]{4}`)

	if GlobalAppSetting.UseAuthKey {
		authKeyReceived := r.Header.Get(GlobalAppSetting.AuthHeaderName)
		authKey := GlobalAppSetting.AuthKey
		if authKey != authKeyReceived {
			w.WriteHeader(http.StatusUnauthorized)
			return
		}
	}

	url := r.URL.Path
	switch {
	case transactionMask.MatchString(url):
		handler.wrapperHandler.ServeHTTP(w, r, getTransactionTimeout(GetTransactionId(url)))
	case url == "/transaction/__wakeup":
		handler.wakeupHandler.ServeHTTP(w, r)
	case url == "/health":
		handler.healthHandler.ServeHTTP(w, r)
	case url == "/wait-for-drain":
		handler.healthHandler.ServeHTTP(w, r)
	case url == "/info":
		handler.infoHandler.ServeHTTP(w, r)
	case url == "/ext-adapter-request":
		handler.extAdapterData.ServeHTTP(w, r)
	default:
		switch r.Method {
		case http.MethodGet:
			w.WriteHeader(404)
		case http.MethodPost:
			w.WriteHeader(404)
		case http.MethodPut:
			w.WriteHeader(404)
		case http.MethodDelete:
			w.WriteHeader(404)
		default:
			w.WriteHeader(404)
		}
	}
}

func getTransactionTimeout(transactionId string) time.Duration {
	timeout := GlobalAppSetting.MtvTrDefaultTimeoutSeconds
	timeout_trID := "MTV_TR_TIMEOUT_" + transactionId
	individualTimeout := os.Getenv(timeout_trID)
	if individualTimeout == "" {
		entry := (*GlobalAppSettingMap)[timeout_trID]
		if entry != "" {
			switch entryCasted := entry.(type) {
			case string:
				timeout, _ = strconv.Atoi(entryCasted)
			case float64:
				timeout = int(entryCasted)
			default:
			}
		}
	} else {
		timeout, _ = strconv.Atoi(individualTimeout)
	}
	return time.Duration(timeout) * time.Second
}
