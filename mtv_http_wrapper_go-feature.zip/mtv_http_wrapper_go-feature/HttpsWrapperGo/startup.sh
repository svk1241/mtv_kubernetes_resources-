#! /bin/bash
GO_PATH=$(pwd)

cd $GO_PATH
./app_stop.sh
./app_start_go.sh