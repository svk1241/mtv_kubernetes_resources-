#! /bin/bash
#=========================================================NEW
cd HttpsWrapperGo
go build HttpsWrapperGo
./HttpsWrapperGo &
cd ..
cd Tests
CUR=$(pwd)
go build SimpleTeMock
./SimpleTeMock -r SERVER -a 0.0.0.0:3888 &
./SimpleTeMock -r SLOW:LORE -e -a 127.0.0.1:8080 --use-http &

curl http://localhost:8080/health
sleep 15
TE_PID=$(pgrep SimpleTeMock)
echo "TE_PID: $TE_PID"
kill -9 $TE_PID
curl http://localhost:8080/health
sleep 5
HW_GO_PID=$(pgrep HttpsWrapperGo)
echo "HW_GO_PID: $HW_GO_PID"
kill -9 $HW_GO_PID
#===============================================================OLD

cd /opt/MTV/m210/https_wrapper
export ASPNETCORE_URLS='http://0.0.0.0:8080;'
export MTV_TE_HOST='127.0.0.1'
export DoRestartTE=true
export RestartTeEndpoint=http://127.0.0.1:8181/restart_te
dotnet MtvHttpsWrapper.dll &
sleep 2

cd $CUR
echo "Current path: $CUR"
./SimpleTeMock -r SERVER -a 0.0.0.0:3888 &
./SimpleTeMock -r SLOW:LORE -e -a 127.0.0.1:8080 --use-http &
sleep 2

curl http://localhost:8080/health
sleep 15

TE_PID=$(pgrep SimpleTeMock)
echo "TE_PID: $TE_PID"
kill -9 $TE_PID

curl http://localhost:8080/health
sleep 5

HW_PID=$(pgrep dotnet)
echo "HW_PID: $HW_PID"
kill -9 $HW_PID
