## Build
az login  
PATCH=44  
EFIX=10  
VERSION=v.XX.YY-suffix  
echo "cagen_version: 8.6" >> ./version.txt  
echo "mtv_patch_level: Patch $PATCH Efix $EFIX" >> ./version.txt  
echo "mtv_mod_build_version: $VERSION" >> ./version.txt  
az acr build -t https-wrapper-deltadental:${VERSION} -r acrregistryhubeastusprivatew4ft .
