## DB analytics tools

### Database' `V#SQLSTATS` `V#SQLAREA` statistics

#### Contents

* [Description](#a-description)
  * [Interface](#a-interface)
* [Usage steps](#a-usage-steps)
* [Usage limitations](#a-usage-limitations)

#### <a id="a-description" name="a-description"></a> Description

[DB_TRACE_CREATE.sql](DB_TRACE_CREATE.sql) defines simple tool to aggregate
statistics provided by Database.
All procedures and tables for this tool are defined in `MTVUSER` schema.

The tool aggregates data over `V#SQLSTATS` and `V#SQLAREA` slices within a time span determined
by start and stop points.

###### <a id="a-interface" name="a-interface"></a> Interface

* _Control_:
  * _Stored procedures_:
    * `MTVUSER.TRACE_START`
      * _Description_: Starts statistics slicing.
      * _Parameters_:
        * `TEST_NAME`: Name of current test session. _Used only for readability_.
        * `ENVIRONMENT`: _Used only for readability_.
        * `DESCRIPTION`: _Used only for readability_.
        * `TEST_START_TIME`: _Used only for readability_.
      * _Returned data_:
        * `TEST_ID`: Unique test session identifier.
    * `MTVUSER.TRACE_STOP`
      * _Description_: Stops statistics slicing.
      * _Parameters_:
        * `TEST_ID`: Unique test session identifier received from
          `MTVUSER.TRACE_START`.
        * `PTEST_END_TIME`: _Used only for readability_.
* _Data_:
  * _Input_:
    * `V#SQLSTATS`: (**Built-in view**) Statistics from Database.
    * `V#SQLAREA`: (**Built-in view**) Statistics from Database for Shared SQL Areas.
    * `MTVUSER.DBTRACE_CONFIG_SCHEMA`: User-defined table.
      * _Columns_:
        * `SCHEMA_TO_COUNT`: Only schemas listed in this column
          are included in statistics aggregation **for Shared SQL Areas**.
  * _Output_:
    * `MTVUSER.DBTRACE_SNAPSHOT_ARCHIVE`
      * _Description_:
        Accumulates dumps from `V#SQLSTATS` over _start_-_stop_ timespan
        for all sessions. Information is stored per-SQL-statement.
    * `MTVUSER.DBTRACE_AREA_SNAPSHOT_ARCHIVE`
      * _Description_:
        Accumulates dumps from `V#SQLAREA` over _start_-_stop_ timespans
        for all session. Information is stored per-SQL-statement.
    * `MTVUSER.TRACE_DATA`
        * _Description_: Main output table with aggregated statistics.
        * _Parameters_:
          * _General_:
            * `ID`: Unique identifier.
            * `TEST_NAME`: From `MTVUSER.TRACE_START`
            * `DESCRIPTION`: From `MTVUSER.TRACE_START`
            * `ENVIRONMENT`: From `MTVUSER.TRACE_START`
            * `TEST_START_TIME`: From `MTVUSER.TRACE_START`
            * `TEST_END_TIME`: From `MTVUSER.TRACE_STOP`
            * `TEST_ORA_TIME`: Actual `MTVUSER.TRACE_START` start time
          * _`V#SQLSTATS`-based_ (Descriptions are given for `V#SQLSTATS` entries (from docs), following columns are their totals):
            * `QS_ROWS_PROCESSED`: Total number of rows the parsed SQL statement returns
            * `QS_FETCHES`: Number of fetches associated with the SQL statement
            * `QS_EXECUTIONS`: Number of executions that took place on this object since it was brought into the library cache
            * `QS_CPU_TIME`: CPU time (in microseconds) used by this cursor for parsing, executing, and fetching
            * `QS_ELAPSED_TIME`: Elapsed time (in microseconds) used by this cursor for parsing, executing, and fetching
          * _`V#SQLAREA`-based_ (Descriptions are given for `V#SQLAREA` entries (from docs), following columns are their totals):
            * `SQA_ROWS_PROCESSED`: Total number of rows processed on behalf of this SQL statement
            * `SQA_FETCHES`: Number of fetches associated with the SQL statement
            * `SQA_EXECUTIONS`: Total number of executions, totalled over all the child cursors
            * `SQA_CPU_TIME`: CPU time (in microseconds) used by this cursor for parsing, executing, and fetching
            * `SQA_ELAPSED_TIME`: Elapsed time (in microseconds) used by this cursor for parsing, executing, and fetching

##### <a id="a-usage-steps" name="a-usage-steps"></a> Usage steps
  0. Make sure `DB_TRACE_CREATE.sql` is applied to the database (described tables and procedures are present).
     _**Note**: Admin rights are required to apply this script._
  1. Fill `MTVUSER.DBTRACE_CONFIG_SCHEMA` with names of schemas you are going to track,
     remove all unnecessary schema names.
  2. Run `MTVUSER.TRACE_START` stored procedure: use the following script
     ```oraclesqlplus
     DECLARE test_id NUMBER;
     BEGIN  
     MTVUSER.TRACE_START(test_id, %test_name%, %env_name%, %description%, SYSDATE);
     dbms_output.put_line(to_char(test_id));
     END;
     ```
     where _%test_name%_, _%env_name%_, _%description%_ are defined by you.
     As a result, you will get the `test_id`.
  3. Run your workload
  4. Run `MTVUSER.TRACE_STOP` stored procedure
     ```oraclesqlplus
     BEGIN
     MTVUSER.TRACE_STOP(%test_id%, SYSDATE);
     END;
     ```
     where _%test_id%_ is the test_id you received from `MTVUSER.TRACE_START`.

##### <a id="a-usage-limitations" name="a-usage-limitations"></a> Usage limitations
  * Traced workload must be run exclusively on the database instance during the tracing process
    since all SQL activities are caught into `V$*` views.
