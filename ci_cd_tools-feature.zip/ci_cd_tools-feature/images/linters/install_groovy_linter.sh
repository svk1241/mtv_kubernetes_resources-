#!/bin/bash -e
curl --fail -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.3/install.sh | bash && \
  . ~/.bashrc && \
  export NVM_DIR="/root/.nvm" && \
  [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh" && \
  [ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion" && \
  NODE_VERSION=$(nvm ls-remote | grep -oP 'v18.\d{0,}.\d{0,}') && \
  nvm install $NODE_VERSION && nvm use $NODE_VERSION && \
  mkdir -p /usr/app && cd /usr/app
  npm install -g npm-groovy-lint
