## Build
```
image_version=<version>
kubescape_version=<kubescape_varsion>
hadolint_version=<hadolint_version>
helm_version=<helm_version>
./build.sh $image_version $kubescape_version $hadolint_version $helm_version
```
