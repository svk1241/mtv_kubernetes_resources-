#!/bin/bash

VERSION=$1
KUBESCAPE_VERSION=${2:-v2.3.6}
HADOLINT_VERSION=${3:-v2.12.0-debian}
HELM_VERSION=${4:-v3.13.2}
az acr build --build-arg KUBESCAPE_VERSION=${KUBESCAPE_VERSION} \
             --build-arg HADOLINT_VERSION=${HADOLINT_VERSION} \
             --build-arg HELM_VERSION=${HELM_VERSION} \
             --registry acrregistryhubeastusprivated9f2 \
             --image devops/linters:${VERSION} .
