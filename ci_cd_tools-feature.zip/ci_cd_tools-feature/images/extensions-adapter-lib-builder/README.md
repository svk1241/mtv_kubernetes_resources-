---
title: Readme file for building extensions-adapter-lib-builder image
---
## Image for building Adapter library from https://luxproject.luxoft.com/stash/projects/DDMTV/repos/extensions_adapter_lib/browse

```
image_version=<version>
export ARTIFACTORY_TOKEN=<token>
./get_files.sh
./build.sh $image_version
```
