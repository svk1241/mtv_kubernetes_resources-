#!/bin/bash -e

[ -z "$ARTIFACTORY_TOKEN" ] && echo "Variable 'ARTIFACTORY_TOKEN' is empty or absent " && exit 1
curl --fail -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Genericc/golang/go1.22.7.linux-amd64.tar.gz'
curl --fail -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/Oracle/oracle-instantclient19.3-basic-19.3.0.0.0-1.x86_64.rpm'
curl --fail -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/Oracle/oracle-instantclient19.3-sqlplus-19.3.0.0.0-1.x86_64.rpm'
curl --fail -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/Oracle/oracle-instantclient19.3-tools-19.3.0.0.0-1.x86_64.rpm'
curl --fail -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/CAGenRuntime86reduced.tar.gz'
curl --fail -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O 'https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/backend/MQSeries/MQCLT-v9.3.0-25.tar.gz'
