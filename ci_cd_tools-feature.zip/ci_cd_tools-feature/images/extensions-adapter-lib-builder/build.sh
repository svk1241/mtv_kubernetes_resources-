#!/bin/bash -e

VERSION=$1

./get_files.sh
az acr build --registry acrregistryhubeastusprivated9f2 --image extensions-adapter-lib-builder:${VERSION} .
