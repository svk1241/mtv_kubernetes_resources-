#!/bin/bash

terraformVersion="1.8.5"
azureCliVersion="2.61.0"
tfDocsVersion="0.18.0"

az acr build \
    --build-arg terraform_version=${terraformVersion} \
    --build-arg azure_cli_version=${azureCliVersion} \
    --build-arg tf_docs=${tfDocsVersion} \
    --image terraform-azure-cli:${terraformVersion}-${azureCliVersion}-${tfDocsVersion} \
    --registry acrregistryhubeastusprivated9f2 .
    
