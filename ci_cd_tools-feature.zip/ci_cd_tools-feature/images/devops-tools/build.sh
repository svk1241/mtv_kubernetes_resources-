#!/bin/bash

VERSION=$1
AZURE_CLI_VERSION=${2:-2.53.0}
HELM_VERSION=${3:-3.14.0}
ARGOCD_VERSION=${4:-2.6.15}

az acr build \
--registry acrregistryhubeastusprivated9f2 \
--image devops-tools:${VERSION} \
--build-arg AZURE_CLI_VERSION=${AZURE_CLI_VERSION} \
--build-arg HELM_VERSION=${HELM_VERSION} \
--build-arg ARGOCD_VERSION=${ARGOCD_VERSION} \
.
