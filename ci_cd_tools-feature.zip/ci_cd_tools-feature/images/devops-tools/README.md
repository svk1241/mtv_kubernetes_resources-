## Build
```
image_version=1.8 # Increment this version on every change
./build.sh $image_version $[AZURE_CLI_VERSION] $[HELM_VERSION] $[ARGOCD_VERSION]
```
