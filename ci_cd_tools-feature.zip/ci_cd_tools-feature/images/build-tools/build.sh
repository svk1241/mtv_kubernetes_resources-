#!/bin/bash

VERSION=$1

az acr build --registry acrregistryhubeastusprivated9f2 --image build-tools:${VERSION} .

