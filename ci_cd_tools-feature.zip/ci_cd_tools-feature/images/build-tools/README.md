---
title: Readme file for building build-tools image
---
## Build
```
image_version=<version>
./build.sh $image_version
```
