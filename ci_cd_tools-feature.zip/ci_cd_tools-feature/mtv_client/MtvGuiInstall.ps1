param (
    [Parameter (Mandatory=$true, Position=1)]
    [String]$guiArchive
)

$baseName=$guiArchive.Substring(0, $guiArchive.LastIndexOf("."))

Write-Host "Extracting files/Mount ISO"
Expand-Archive -Force -Path "$pwd\${guiArchive}" -DestinationPath $pwd
mountvol "G:" (Mount-DiskImage -ImagePath "$pwd\$baseName.iso" -NoDriveLetter -PassThru | Get-Volume).UniqueId
G:
Write-Host "Installing Clients\Setup.EXE"
Set-Location "G:\Clients"
.\Setup.EXE /S  # TBD
Wait-Process -Name "Setup"
Write-Host "Installing Clients-TestHarnesses\Setup.EXE"
Set-Location "G:\Clients-TestHarnesses"
.\Setup.EXE /S  # TBD
Wait-Process -Name "Setup"
Write-Host "Installing DeltaDental\Clients\Setup.EXE"
Set-Location "G:\DeltaDental\Clients"
.\Setup.EXE /S  # TBD
Wait-Process -Name "Setup"
C:
Write-Host "Cleaning files"
Dismount-DiskImage -ImagePath "$pwd\$baseName.iso"
Remove-Item "$pwd\$baseName.iso"
Remove-Item "$pwd\$baseName.mds"
Remove-Item "$pwd\${guiArchive}"
