param (
    [Parameter (Mandatory=$true, Position=1)]
    [String]$cluster,
    [Parameter (Mandatory=$true, Position=2)]
    [String]$clientEnvs,
    [Parameter (Mandatory=$true, Position=3)]
    [String]$logLevel
)

$scriptPath = Split-Path -parent $MyInvocation.MyCommand.Definition
$configPath = Join-Path $scriptPath "connection-settings.ini"

try {
    Function Parse-IniFile ($file) {
        $ini = @{}
        switch -regex -file $file {
            "^\[(.+)\]$" {
                $section = $matches[1].Trim()
                $ini[$section] = @{}
            }
            "^\s*([^#].+?)\s*=\s*(.*)" {
                $name,$value = $matches[1..2]
                # skip comments that start with semicolon:
                if (!($name.StartsWith(";"))) {
                    $ini[$section][$name] = $value.Trim()
                }
            }
        }
        $ini
    }

    Function Install-ClientProxyService { 
        param(
            [string] $environmentName,
            [string] $LogLevel,
            [string] $AppPath,
            [string] $URL,
            [string] $Port,
            [string] $LogPath
        )
        Write-Host "Inside Install function!"
        # Cleaning old installation
        $serviceName = "HTTPS-Proxy-$environmentName-$Port"
        Stop-Service "$serviceName"
        Write-Host "current version of $serviceName service was stopped"
        sc.exe delete $serviceName
        Write-Output "current version of $serviceName service was deleted"
        Remove-Item -Path $AppPath -recurse
        # Setting up new installation
        New-Item -ItemType Directory -Force -Path $AppPath
        New-Item -ItemType Directory -Force -Path $LogPath
        $lastMtvClient = Get-ChildItem -Path . -Recurse -Filter "MtvClientProxy*.zip"| Sort-Object CreationTime -Descending | Select-Object -First 1 | ForEach-Object { $_.DirectoryName + "\$_" }
        Expand-Archive -Force -Path $lastMtvClient -DestinationPath $AppPath
        New-Service -Name "$serviceName" -BinaryPathName "$AppPath\MtvClientProxyWindowsService.exe ListenIp=0.0.0.0 ListenPort=$Port MtvBackendPrefix=$URL LogFileTimestampPattern=[TS] LogFile=$LogPath\$serviceName-[TS].log InstanceId=$environmentName-$Port Logging:LogLevel:Default=$LogLevel Logging:EventLog:LogLevel:Default=None" -StartupType "Automatic" | Out-Null
        Write-Host "New version of $serviceName service was installed"
        Start-Service "$serviceName"
        Write-Host "$serviceName service was started"
    }
    # Main logic
    Write-Host "Inside Powershell!"
    if($cluster -eq 'auto') {
        ((Get-Content -path $configPath -Raw) -replace '<cluster>', '') | Set-Content -Path $configPath
    } else {
        ((Get-Content -path $configPath -Raw) -replace 'integration<cluster>', "integration-86-1-${cluster}") | Set-Content -Path $configPath
        ((Get-Content -path $configPath -Raw) -replace '<cluster>', "-${cluster}") | Set-Content -Path $configPath
    }
    $configurations = Parse-IniFile $configPath
    $environments = if ($clientEnvs -eq 'all') {$configurations.Keys} Else {$clientEnvs}
    foreach ($envName in $environments) {
        $params = $configurations[$envName]
        Write-Host "Before calling Install function"
        Install-ClientProxyService -environmentName $envName -LogLevel $logLevel @params
    }
}
catch {
    Write-Host "Error occured" -BackgroundColor Darkred
    Write-Host $_.ErrorDetails.Message
    throw $_
}
