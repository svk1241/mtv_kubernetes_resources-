param (
    [Parameter (Mandatory=$true, Position=1)]
    [String]$clientEnvs,
    [Parameter (Mandatory=$true, Position=2)]
    [String]$user
)

$scriptPath = Split-Path -parent $MyInvocation.MyCommand.Definition
$configPath = Join-Path $scriptPath "connection-settings.ini"

Function Parse-IniFile ($file) {
    $ini = @{}
    switch -regex -file $file {
        "^\[(.+)\]$" {
            $section = $matches[1].Trim()
            $ini[$section] = @{}
        }
        "^\s*([^#].+?)\s*=\s*(.*)" {
            $name,$value = $matches[1..2]
            # skip comments that start with semicolon:
            if (!($name.StartsWith(";"))) {
                $ini[$section][$name] = $value.Trim()
            }
        }
    }
    $ini
}

$configuration = Parse-IniFile $configPath

Function create-task ($environment) {
    # Create script file
    $logpath=$configuration[$environment].LogPath
    New-Item -ItemType Directory -Force -Path "$logpath\LogsRotation"
    New-Item -Path "$logpath\LogsRotation" -Force -ItemType File -Name "Logs-Rotate.ps1"
    Set-Content -Path "$logpath\LogsRotation\Logs-Rotate.ps1" -Value '
    param (
 
	    [Parameter (Mandatory=$true, Position=1)]
        [String]$logpath
    )

    $CleanupPathMask="$logpath\*.log"
    $DaysToKeep=7

    Get-ChildItem  $CleanupPathMask |
        Where-Object {$_.LastWriteTime -lt (Get-Date).AddDays(-$DaysToKeep)} |
        Remove-Item'
    # Setup scheduled task
    $action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "$logpath\LogsRotation\Logs-Rotate.ps1 $logpath"
    $trigger = New-ScheduledTaskTrigger -Daily -At '00:00'
    $principal = New-ScheduledTaskPrincipal -UserId $user
    $settings = New-ScheduledTaskSettingsSet
    $task = New-ScheduledTask -Action $action -Principal $principal -Trigger $trigger -Settings $settings
    Unregister-ScheduledTask -TaskName "MTV-Proxy-Logs-Rotate-$environment" -Confirm:$false
    Register-ScheduledTask "MTV-Proxy-Logs-Rotate-$environment" -InputObject $task
}
# Main logic
if ($clientEnvs -eq 'all') {
    foreach ($environment in $configuration.Keys) {
        create-task ($environment)
    }
}
else {
    create-task ($clientEnvs)
}
