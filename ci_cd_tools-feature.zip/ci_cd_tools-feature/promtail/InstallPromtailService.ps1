param (
    [Parameter (Mandatory=$true, Position=1)]
    [String] $cluster
)

Function Parse-IniFile ($file) {
    $ini = @{}
    switch -regex -file $file {
        "^\[(.+)\]$" {
            $section = $matches[1].Trim()
            $ini[$section] = @{}
        }
        "^\s*([^#].+?)\s*=\s*(.*)" {
            $name,$value = $matches[1..2]
            # skip comments that start with semicolon:
            if (!($name.StartsWith(";"))) {
                $ini[$section][$name] = $value.Trim()
            }
        }
    }
    $ini
}

$scriptPath = Split-Path -parent $MyInvocation.MyCommand.Definition
$scriptPath += "/client_configs"
$configPath = Join-Path $scriptPath "connection-settings.ini"
$settings = Parse-IniFile $configPath
$apppath = $settings[$cluster].AppPath
$url = $settings[$cluster].URL
$port = $settings[$cluster].Port
$lastPromtail = Get-ChildItem -Path . -Recurse -Filter "promtail-service-src.zip"| Sort-Object CreationTime -Descending | Select-Object -First 1 | ForEach-Object { $_.DirectoryName + "\$_" }
$serviceName = "Promtail Service"
Stop-Service $serviceName
Write-Host "current version of $serviceName service was stopped"
sc.exe delete $serviceName
Write-Output "current version of $serviceName service was deleted"
Expand-Archive -Force -Path $lastPromtail -DestinationPath $appPath
Copy-Item -Path "$scriptPath\config.yaml" -Destination $apppath
Push-Location $apppath
((Get-Content -path config.yaml -Raw) -replace '<promtail-port>',"$port") | Set-Content -Path config.yaml
((Get-Content -path config.yaml -Raw) -replace 'http://<loki-ip>/loki/api/v1/push',"$url") | Set-Content -Path config.yaml
& ".\promtail-service.exe" install
Pop-Location
Start-Service "$serviceName"
Write-Host "New service $serviceName was started"
