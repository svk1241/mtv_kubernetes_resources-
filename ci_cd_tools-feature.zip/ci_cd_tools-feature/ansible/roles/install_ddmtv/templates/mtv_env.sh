# MTV env vars
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/lib:/lib64:/usr/lib:/usr/lib64:/opt/CA/CAGen/runtime/lib:/opt/MTV/m210/lib:/opt/mqm/lib64:/usr/dmexpress/lib
export SHLIB_PATH=$SHLIB_PATH:/opt/mqm/lib64
export TNS_ADMIN=/usr/lib/oracle/19.3/client64/lib/network/admin
export PATH=$PATH:/opt/mqm/bin:/usr/dmexpress/bin:/usr/lib/oracle/19.3/client64/bin
export MTV_INIT_SCRIPT=mtv-batch-init.sh
export TMPDIR=/tmp
export CAGEN_VERSION=8.6
export MTV_PATCH_LEVEL=Patch.44.Efix.{{ efix_version }}
export MTV_MOD_BUILD_VERSION=v.{{ build_version }}
export DSUSER=R210TSTDDB
export DSPSWD=r210tstddb
export DSSERVER={{ database_instance }}
