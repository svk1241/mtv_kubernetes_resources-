#! /bin/bash

BASE_PATH=/opt/MTV/m210

mkdir -p $BASE_PATH/logs/{transaction-enabler,https-wrapper,te-restarter}

echo "Starting transaction enabler . . ."
cd $BASE_PATH/logs/transaction-enabler/
$BASE_PATH/online/run_tranEnab.sh

echo "Starting TE Restarter . . ."
cd $BASE_PATH/te_restarter
./run_te_restarter.sh

echo "Starting HTTPS Wrapper . . ."
cd $BASE_PATH/https_wrapper
./run_wrapper.sh
