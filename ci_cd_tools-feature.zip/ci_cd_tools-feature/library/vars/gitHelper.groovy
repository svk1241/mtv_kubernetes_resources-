import groovy.transform.Field

@Field
String jenkinsCredentialsName = 'ddmtv_service_account'

/**
 * Performs git checkout with detached HEAD with optional retry mode
 *
 * @param repo String name of the repository from which the checkout will be performed
 * @param branch String name of the branch from which the checkout will be performed
 * @param relativeTargetDir String path of the relative target dir
 * @param retry boolean if true was received, then a checkout will be performed with 3 reconnection, otherwise 1
 */
void checkout(String repo='https://luxproject.luxoft.com/stash/scm/ddmtv/ci_cd_tools.git',
              String branch='development',
              String relativeTargetDir='./',
              boolean retry=false) {
    int retryAttempsCount = retry == true ? 3 : 1
    int attemptsMadeCount = 0
    int timeoutBeforeRetry = 30

    while (attemptsMadeCount < retryAttempsCount) {
        try {
            checkout scm: [$class: 'GitSCM', userRemoteConfigs: [
                    [url: repo, credentialsId:jenkinsCredentialsName]
                ],
                extensions: [
                    [$class: 'CloneOption', depth: 1, shallow: true],
                    [$class: 'RelativeTargetDirectory', relativeTargetDir: relativeTargetDir]
                ],
                branches: [[name: branch]]], poll: false
            break
            }
        /* groovylint-disable-next-line CatchException */
        catch (Exception ex) {
            attemptsMadeCount = attemptsMadeCount + 1
            echo "Operation failed with exception: $ex \nRetrying operation\nAttempts remaining: $attemptsMadeCount"
            if (attemptsMadeCount == retryAttempsCount) {
                error("Unable to perform git clone. Number of attempts made - $attemptsMadeCount. Message - $ex")
            }
            sleep(timeoutBeforeRetry)
        }
    }
}

/**
 * Performs git clone
 *
 * @param repo String name of the repository from which the checkout will be performed
 * @param branch String name of the branch from which the checkout will be performed
 * @param relativeTargetDir String path of the relative target dir
 */
void checkoutWithGit(String repo='luxproject.luxoft.com/stash/scm/ddmtv/ci_cd_tools.git',
    String branch='development',
    String relativeTargetDir='./') {
    withCredentials([usernamePassword(credentialsId: buildConstants.jenkinsCredentialsName,
                                    passwordVariable: 'BB_PASSWORD',
                                    usernameVariable: 'BB_USER')]) {
        sh(label:"Checkout ${repo} into ${relativeTargetDir}",
            script: """
                git config --global user.name "ddmtv_service_account"
                git config --global user.email "ddmtv_service_account@luxoft.com"
                [ -d "${relativeTargetDir}" ] && rm -r "${relativeTargetDir}"
                git clone https://${BB_USER}:${BB_PASSWORD}@${repo} -b ${branch} ${relativeTargetDir}
            """
        )
    }
}

/**
 * Performs commiting changes and sending to remote repo
 *
 * @param repoFolder String path of the relative target dir
 * @param commitMessage String Commit message for changes
 */
void commitToGit(String repoFolder='./',
    String commitMessage='') {
    sh(label:"Commit and push to BB. Source folder: ${repoFolder}",
        script: """
            git config --global user.name "ddmtv_service_account"
            git config --global user.email "ddmtv_service_account@luxoft.com"
            cd ${repoFolder}
            git add .
            git status
            if ! git diff-index --quiet HEAD;
            then
                git commit -m "${commitMessage}"
                git push
            else
                echo "No changes"
            fi
        """
    )
}
