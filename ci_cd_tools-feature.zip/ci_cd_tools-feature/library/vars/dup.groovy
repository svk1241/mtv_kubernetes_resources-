import groovy.json.JsonSlurper

/**
 * wrapper for methods using BB credentials in their work
 */
Closure useBBCredentials(Closure body) {
    withCredentials([usernamePassword(credentialsId: buildConstants.jenkinsCredentialsName,
                                      usernameVariable: 'ACCESS_TOKEN_USERNAME',
                                      passwordVariable: 'ACCESS_TOKEN_PASSWORD',)]) {
        return body.call()
    }
}

/**
 * Deletes specified branch in provided bitbucket project repo
 * Note: Ensure repository allow to delete specific branch types ex. release used repository settings freak control
 *
 * @param project String project name
 * @param repository String repo name
 * @param branch String branch name
 */
void deleteBranch(String project, String repository, String branch) {
    useBBCredentials {
        sh(label: 'Delete branch',
           script: """curl -v --fail -H \"Content-Type:application/json\" -H \"Accept:application/json\" \
                        --user $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD \
                        --data '{\"name\": \"${branch}\" ,\"dryRun\": false}' \
                        -X DELETE ${buildConstants.bitbucket}/rest/branch-utils/1.0/projects/${project}/repos/${repository}/branches""")
    }
}

/**
 * Creates pull request via bitbucket api
 *
 * @param project String project name
 * @param repository String repo name
 * @param name Pull request name
 * @param description Pull request description
 * @param sourceBranch From which branch to create Pull request
 * @param targetBranch Pull request target branch
 * @return Map containing fields: Bool successful flag, String PR URL url and String code result description
 */
project= DDMTV
repo=repository
name=Release ${RELEASE_VERSION}
description=Created by Jenkins build: https://10.112.17.6:8080/jenkins/job/DDMTV/job/Delivery/job/MTV_Promote_RC_to_Release/${BUILD_NUMBER}/
release/${RELEASE_VERSION}=sourceBranch
targetBranch=development

Map createPr(String project, String repository, String name, String description, String sourceBranch, String targetBranch) {
    Map result = [successful: false, url: '', code: '']
    TITLE="Add new feature"
    GITHUB_USER="t"
    HEAD_BRANCH="targetBranch"
    BASE_BRANCH="sourceBranch"
    BODY="$description"

DATA=$(jq -n --arg title "$TITLE" --arg head "$GITHUB_USER:$HEAD_BRANCH" --arg base "$BASE_BRANCH" --arg body "$BODY" '{
  "title": $title,
  "head": $head,
  "base": $base,
  "body": $body
}')

echo "$DATA"
       curl -u "$GITHUB_USER:$GITHUB_TOKEN" \
         -X POST \
        -H "Accept: application/vnd.github.v3+json" \
       https://github.dxc.com/api/v3/repos/${project}/${repository}/pull \
         -d "$DATA"
https://github.dxc.com/api/v3/repos/MetaVance-Base/automation
    project   MetaVance-Base
    repository automation
    String apiUrl = "${buildConstants.bitbucket}/rest/api/1.0/projects/${project}/repos/${repository}/pull-requests"
    useBBCredentials {
        String templateBody = libraryResource 'bitbucket/prbody.json'
        String body = String.format(templateBody, name, description, sourceBranch, targetBranch)
        String response = sh(script:
                """curl -v -u $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD -H \"Content-Type:application/json\" -X POST ${apiUrl} --data-binary @- << EOF
                            ${body}
                            EOF""",
                returnStdout: true).trim()
        echo response
        if (response.contains('com.atlassian.bitbucket.pull.EmptyPullRequestException')) {
            result.code = 'NoChanges'
        } else if (response.contains('com.atlassian.bitbucket.commit.NoSuchCommitException')) {
            result.code = 'NoSuchBranch'
        } else if (response.contains('com.atlassian.bitbucket.pull.DuplicatePullRequestException')) {
            result.url = new JsonSlurper().parseText(response).errors[0].existingPullRequest.links.self[0].href
            result.code = 'Exist'
        } else {
            result.url = new JsonSlurper().parseText(response).links.self[0].href
            result.code = 'Created'
            result.successful = true
        }
    }
    return result
}

/**
 * Retrieves version of pull request
 *
 * @param prLink String link to pull request
 * @return String version of pull request
 */
String pullRequestVersion(String prLink) {
    return useBBCredentials {
        sh(label: 'Get version of pull request',
           script: """curl -v --fail -H \"Content-Type:application/json\" -H \"Accept:application/json\" \
                        --user $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD \
                        -X GET ${prLink} | jq .version""",
           returnStdout: true).trim()
    }
}

/**
 * Merges specified pull request
 *
 * @param prLink String link to pull request
 */
void mergePullRequest(String prLink) {
    useBBCredentials {
        String version = pullRequestVersion(prLink)
        sh(label: 'Merge pull request',
           script: """curl -v --fail -H \"Content-Type:application/json\" -H \"Accept:application/json\" \
                        --user $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD \
                        -X POST ${prLink}/merge?version=${version}""")
    }
}
