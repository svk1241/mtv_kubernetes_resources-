import static org.yaml.snakeyaml.DumperOptions.FlowStyle.BLOCK
import groovy.transform.Field
import groovy.text.StreamingTemplateEngine
import org.yaml.snakeyaml.Yaml
import org.yaml.snakeyaml.DumperOptions
import net.sf.json.JSONObject

/**
 * stucture [['repository': 'transaction-enabler-deltadental', 'tag': '54.10'], ..]
 */
@Field
List images = []

@Field final String JSON_FORMAT_INDENT = 4
@Field final String TRANSACTION_ENABLER_REPO_DD = 'transaction-enabler-deltadental-extensions'
@Field final String TRANSACTION_ENABLER_REPO = 'transaction-enabler-deltadental'
@Field final String BATCH_REPO_DD = 'mtv-backend-batch-deltadental'
@Field final String BATCH_REPO = 'mtv-backend-batch'
@Field final String APP_SETTINGS_FILE_NAME = 'appsettings.json'

Map findFirstAbsentImage(String privateRegistry, String privateRepository,
                        String publicRegistry, String publicRepository,
                        Integer days) {
    List privateManifests = azureApi.getManifests(privateRegistry, privateRepository, 360)
    List publicManifests = azureApi.getManifests(publicRegistry, publicRepository, days)
    List privateDigests = getDigests(privateManifests)
    List publicDigests = getDigests(publicManifests)
    String digest = publicDigests.find { d -> !privateDigests.contains(d) }
    return getManifestByDigest(publicManifests, digest)
}

List getDigests(List manifests) {
    List digests = []
    manifests.each { m -> digests.add(m.digest) }
    return digests
}

Map getManifestByDigest(List manifests, String digest) {
    return manifests.find { m -> m['digest'] == digest }
}

String generateManifests(String srcFolder, String envName, Map tags, String tag) {
    String yamlsFolder = "${pwd()}/yamls"
    String resultsFolder = pwd()
    String transactionEnablerRepo = tags[TRANSACTION_ENABLER_REPO_DD] ?
                                         TRANSACTION_ENABLER_REPO_DD :
                                         TRANSACTION_ENABLER_REPO
    String transactionEnablerTag = tags[TRANSACTION_ENABLER_REPO_DD] ?: tags[TRANSACTION_ENABLER_REPO]
    String batchRepo = tags[BATCH_REPO_DD] ? BATCH_REPO_DD : BATCH_REPO
    String batchTag = tags[BATCH_REPO_DD] ?: tags[BATCH_REPO]

    dir(srcFolder) {
        sh """cp -v ./backend/kubernetes/deployment/yaml-generator/namespaces/${envName}.sh \
                ./backend/kubernetes/deployment/yaml-generator/configs/internal-configuration.sh
              sed -i -e "s=https-wrapper-deltadental:v.XX.XX=https-wrapper-deltadental:${tags['https-wrapper-deltadental']}=g" \
                ./backend/kubernetes/deployment/yaml-generator/configs/internal-configuration.sh
              sed -i -e "s=${transactionEnablerRepo}:v.XX.XX=${transactionEnablerRepo}:${transactionEnablerTag}=g" \
                ./backend/kubernetes/deployment/yaml-generator/configs/internal-configuration.sh
              sed -i -e "s=${batchRepo}:v.XX.XX=${batchRepo}:${batchTag}=g" ./backend/kubernetes/deployment/yaml-generator/configs/internal-configuration.sh
              sed -i -e "s=mtv-backend-infrastructure:v.XX.XX=mtv-backend-infrastructure:${tags['mtv-backend-infrastructure']}=g" \
                ./backend/kubernetes/deployment/yaml-generator/configs/internal-configuration.sh
              ./backend/kubernetes/deployment/yaml-generator/autogenerator.sh ${yamlsFolder}/${envName}/
              cd ${yamlsFolder} && zip -r ${resultsFolder}/build.${tag}.zip .
        """
    }
    return "${resultsFolder}/build.${tag}.zip"
}

/**
 * Deprecation notice! method moved to jfrogApi and will no longer maintained here
 */
Closure useArtifactoryCredentials(Closure body) {
    return {
        withCredentials([string(credentialsId: 'artifactory_api_token', variable: 'API_TOKEN')]) {
            return body.call()
        }
    }
}

/**
 * Deprecation notice! method will be moved to gitHelper and will no longer maintained here
 */
void checkout(String repo='https://github.dxc.com/MetaVance-Base/ci_cd_tools.git',
              String branch='feature',
              String relativeTargetDir='./') {
    checkout scm: [$class: 'GitSCM', userRemoteConfigs: [
            [url: repo, credentialsId: buildConstants.jenkinsCredentialsName ]
        ],
        extensions: [
            [$class: 'CloneOption', depth: 1, shallow: true],
            [$class: 'RelativeTargetDirectory', relativeTargetDir: relativeTargetDir]
        ],
        branches: [[name: branch]]], poll: false
}

/**
 * Performs image container scanning using Aquasec
 *
 * @param buildNumber String Jenkins build number will be used to refer job in aquasec portal
 * @param buildUrl String Url to Jenkins job will be used to refer job in aquasec portal
 * @param registry String registry of image to scan
 * @param image String image name to scan
 * @param tag String image tag to scan
 */
String aquaScanImage(String buildNumber,
                 String buildUrl,
                 String registry,
                 String image,
                 String tag) {
    String aquaSecHost = 'http://48.214.241.106:8080/'
    /* groovylint-disable-next-line NoJavaUtilDate */
    Date now = new Date()
    String timestamp = now.format('yy_MM_dd__HH_mm')
    String reportFile = "report-${image}-${tag}-${timestamp}"
    withCredentials([usernamePassword(credentialsId: 'aqua_sec_token', passwordVariable: 'AQUA_PASSWORD', usernameVariable: 'AQUA_USER')]) {
        String aquaSecCmd = """docker run \
                                -e BUILD_JOB_NAME=${buildUrl} \
                                -e BUILD_NUMBER=${buildNumber} \
                                -e SCALOCK_LOG_LEVEL=DEBUG \
                                -t \
                                --rm \
                                -v \$(pwd):/tmp/ci \
                                -v /var/run/docker.sock:/var/run/docker.sock \
                                 acrregistryhubeastusprivated9f2.azurecr.io/scanner:2022.4.517 scan \
                                --scan-timeout 2400 \
                                --host ${aquaSecHost} \
                                --user $AQUA_USER \
                                --password $AQUA_PASSWORD \
                                --verbose-errors \
                                --no-verify \
                                --collect-sensitive \
                                --scan-malware \
                                --dockerfull \
                                --register \
                                --layer-vulnerabilities \
                                --show-negligible \
                                --show-will-not-fix \
                                --text \
                                --textfile /tmp/ci/${reportFile}.txt \
                                --jsonfile /tmp/ci/${reportFile}.json \
                                --htmlfile /tmp/ci/${reportFile}.html \
                                --registry ${registry} \
                                ${image}:v.${tag}"""
        echo "${aquaSecCmd}"
        sh(label: "Execute Aqua Scan for ${registry}/${image}:v.${tag}",
            script: "${aquaSecCmd}")
    }
    return reportFile
}

/**
 * SemVer v2.0.0 compliance check:
 * https://semver.org/spec/v2.0.0.html#is-there-a-suggested-regular-expression-regex-to-check-a-semver-string
 *
 * @param buildVersion String version to validate
 */
boolean isSemVerCompliant(String buildVersion) {
    /* groovylint-disable-next-line LineLength */
    String pattern = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?(?:\+([0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$/
    return buildVersion ==~ pattern
}

/**
 * Fails if provided version is not SemVer v2.0.0 compliant
 *
 * @param buildVersion String version to validate
 */
void failIfNotSemVerCompliant(String buildVersion) {
    if (!isSemVerCompliant(buildVersion)) {
        error('Build version is not compliant with SemVer.')
    }
}

/**
 * Executes specified command over ssh using username and password from provided Jenkins credential id
 *
 * @param hostName String name of host to execute command
 * @param hostDomain String domain of host to execute command
 * @param fromCredentials String ID of jenkins credentials containing username and password to execute command from
 * @param commands List list of String commands to execute
 */
void execSSHCmdUserPassword(String hostName, String hostDomain,
                            String fromCredentials, List commands) {
    Map remote = [:]
    withCredentials([usernamePassword(credentialsId: fromCredentials,
                    passwordVariable: 'password',
                    usernameVariable: 'userName')]) {
        remote.name = hostName
        remote.host = hostName + '.' + hostDomain
        remote.allowAnyHosts = true
        remote.user = userName
        remote.password = password
        commands.each { command ->
            sshCommand remote: remote, command: command
        }
    }
}

/**
 * Executes specified command over ssh using public key from provided Jenkins credential id
 *
 * @param hostName String name of host to execute command
 * @param hostDomain String domain of host to execute command
 * @param fromCredentials String ID of jenkins credentials containing username and password to execute command from
 * @param commands List list of String commands to execute
 */
void execSSHCmdPublicKey(String hostName, String hostDomain,
                        String fromCredentials, List commands) {
    Map remote = [:]
    withCredentials([
        sshUserPrivateKey(credentialsId: fromCredentials,
                        keyFileVariable: 'identity',
                        passphraseVariable: '',
                        usernameVariable: 'userNameSsh')]) {
        remote.name = hostName
        remote.host = "${hostName}.${hostDomain}"
        remote.allowAnyHosts = true
        remote.user = userNameSsh
        remote.identityFile = identity
        commands.each { command ->
            sshCommand remote: remote, command: "ls -lrt"
          sshCommand remote: remote, command: "pwd"
            sshCommand remote: remote, command: command
            
        }
    }
}

/**
 * Given teams channel webhook url, template and map of variables for substitution generate a post
 * https://learn.microsoft.com/en-us/microsoftteams/platform/webhooks-and-connectors/how-to/connectors-using?tabs=cURL#send-messages-using-curl-and-powershell
 *
 * @param channel String url of teams webhook
 * @param templateName String name of file in library/resources/teamsTemplates folder
 * @param msgParams Map<String, String> map of variable names and values for substitution
 */
void postToTeamsChannel(String channel, String templateName, Map<String, String> msgParams) {
    String templateBody = libraryResource("teamsTemplates/${templateName}")
    String msg = new StreamingTemplateEngine().createTemplate(templateBody).make(msgParams)
    o365Api.postCommentTeamsChannel(msg, channel)
}

/**
 * Wrapper to execute commands in devops-tools image
 *
 * @param nodelabel String node to execute docker at
 * @param body Closure block of Groovy code to execute
 */
Closure withDevOpsToolsImage(String nodelabel, Closure body) {
    return {
        node(nodelabel) {
            withDockerRegistry(credentialsId: azureApi.privateRegistryCredentialsName,
                               url: az.privateRegistry) {
                String args = "--net=host --rm --user=root --entrypoint='' --memory=512m --cpus='0.5'"
                docker.image("${azureApi.privateRegistryName}/devops-tools:1.8").inside(args) {
                    body.call()
                }
            }
        }
    }
}

/**
 * Method for dumping data to jaml for manifests in right format
 *
 * @data object which should be dumped
 * @return String contains jaml file content
 */
@NonCPS
String yamlToString(Object data) {
    DumperOptions opts = new DumperOptions()
    opts.setDefaultFlowStyle(BLOCK)
    return new Yaml(opts).dump(data)
}

/**
 * Method for changing specific values in application.json file for EWS/EAL components
 *
 * @appsettings content of application.json file
 * @changingKeys values for change
 * @return String contains jaml file content
 */
String changeEwsConfigValues(JSONObject appsettings, Map<String,String>changingKeys) {
    if (changingKeys.keySet().contains('https') && appsettings?.Https?.Enable != null ) {
        echo "Setting's Https.Enable old value is '${appsettings?.Https?.Enable}', new value is '${changingKeys.https.toBoolean()}'"
        appsettings?.Https?.Enable = changingKeys.https.toBoolean()
    }
    if (changingKeys.keySet().contains('auth') && appsettings?.Auth?.Enable != null ) {
        echo "Setting's Auth.Enable old value is '${appsettings?.Auth?.Enable}', new value is '${changingKeys.auth.toBoolean()}'"
        appsettings?.Auth?.Enable = changingKeys.auth.toBoolean()
    }
    if (changingKeys.keySet().contains('mock') && appsettings?.MockPostProcessing?.Enable != null ) {
        /* groovylint-disable-next-line LineLength */
        echo "Setting's MockPostProcessing.Enable old value is '${appsettings?.MockPostProcessing?.Enable}', new value is '${changingKeys.mock.toBoolean()}'"
        appsettings?.MockPostProcessing?.Enable = changingKeys.mock.toBoolean()
    }
    return appsettings
}

/**
 * Method for changing content of application.json.conf file
 *
 * @configPath path to file
 * @changingKeys values for change
 */
void changeEWSManifest(String configPath, Map<String,String>changingKeys) {
    JSONObject appsettings = readJSON(file: configPath)
    echo "Set values in file ${configPath}"
    appsettings = changeEwsConfigValues(appsettings, changingKeys)
    writeJSON file: configPath, json: appsettings, pretty: JSON_FORMAT_INDENT
}

/**
 * Method for changing content of online.conf and batch.conf files
 *
 * @configPath path to file
 * @changingKeys values for change
 */
void changeEALManifest(String configPath, Map<String,String>changingKeys) {
    String configmapName = 'extensions-adapter-config'
    List configResource = readYaml(file: configPath)
    Map adapterConf = configResource.find { conf -> conf.metadata.name == configmapName }
    JSONObject appsettings = readJSON text: adapterConf['data'][APP_SETTINGS_FILE_NAME]
    appsettings = changeEwsConfigValues(appsettings, changingKeys)
    String newAppsettings = writeJSON returnText: true, json: appsettings, pretty: JSON_FORMAT_INDENT
    /* groovylint-disable-next-line DuplicateStringLiteral */
    adapterConf['data'][APP_SETTINGS_FILE_NAME] = newAppsettings
    String fullManifest = ''
    configResource.each { conf ->
        Map tConf = conf
        if (conf.metadata.name == configmapName ) {
            tConf = adapterConf
        }
        if (fullManifest != '') { fullManifest = "${fullManifest}---\n" }
        String manifest = yamlToString(tConf)
        fullManifest = "${fullManifest}${manifest}"
    }
    writeFile(text: fullManifest, file: configPath)
}
