/* groovylint-disable CompileStatic */
import net.sf.json.JSONArray

@groovy.transform.Field
String confluence = 'https://confluence.dxc.com'

/**
 * wrapper fo methods using Confluence credentials in their work
 */
Closure useConfluenceCredentials(Closure body) {
    return withCredentials([string(credentialsId: 'confluence_api_token', variable: 'TOKEN')]) {
        return body.call()
    }
}

JSONArray getChildPages(String parentPage) {
    String result = useConfluenceCredentials {
        sh(script: """curl --fail -X GET \
                           -H "Authorization: Bearer ${TOKEN}" \
                           -H "Content-Type: application/json" \
                           "${confluence}/rest/api/content/${parentPage}/child/page"
                   """, returnStdout: true)
    }
    return readJSON(text: result).results
}

/**
 * Creates page at confluence with specified parent, title and content
 *
 * @param project String Name of project
 * @param title String Page title
 * @param content String Content of the page
 * @param parentPage String parent page for created one
 */
void createPage(String project, String title, String content, String parentPage) {
    String request = libraryResource('confluence/request.json')
    withEnv(["PARENT_PAGE=${parentPage}",
             "TITLE=${title}",
             "PAGE_CONTENT=${content}",
             "PROJECT=${project}"]) {
        request = envSubst(request).replaceAll(/\s+/, ' ')
    }
    echo "Publishing request:\n${request}"
    useConfluenceCredentials {
        sh(script: """curl --fail -X POST \
                           -H "Authorization:Bearer ${TOKEN}" \
                           -H "Content-Type:application/json" \
                           -d '${request}' \
                           "${confluence}/rest/api/content/"
                   """)
    }
}
