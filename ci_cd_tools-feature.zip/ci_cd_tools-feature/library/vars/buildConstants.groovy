/* groovylint-disable DuplicateStringLiteral */
import groovy.transform.Field


@Field
String devopsImageVer = '1.13'


@groovy.transform.Field
String jenkinsCredentialsName = 'dxc_service_account'


@Field
String artifactoryCredentialsName = 'artifactory_api_token'

@groovy.transform.Field
String nodelabel = 'mtvbuild'

@Field
String nodelabel2 = 'mtvbuild'

@groovy.transform.Field
String artifactory = 'https://artifactory.dxc.com:443/artifactory'

@groovy.transform.Field
String artifactoryBuildPath = "${artifactory}/MetaVance-Base-Generic/builds"

@groovy.transform.Field
String artifactoryHashPath = "${artifactory}/MetaVance-Base-Generic/hashbuilds"

@groovy.transform.Field
String jenkins = 'http://10.112.17.6:8080/jenkins/'

@groovy.transform.Field
String bitbucket = 'https://github.dxc.com'

@Field
String infracost = 'http://infracost.ddmtv.private'

@Field
Map dbInfo = [
  'ANCONC': 'concurrency-oracle-001',
  'ANINT': 'integration-oracle-001',
  'ANREGR': 'regression-oracle-001',
  'ANDEV': 'dev-oracle-001',
  '[MOCK]ANEXT': 'extensions-oracle-mock',
  '[MOCK]ANNPF': 'extensions-oracle-mock',
  '[MOCK]ANMTVEXT': 'extensions-oracle-mock',
  '[EAAS]ANEXT': 'extensions-oracle-eaas',
  '[EAAS]ANNPF': 'extensions-oracle-eaas',
  '[EAAS]ANMTVEXT': 'extensions-oracle-eaas',
  '[DEV]ANEXT': 'extensions-oracle-dev',
  '[DEV]ANNPF': 'extensions-oracle-dev',
  '[DEV]ANMTVEXT': 'extensions-oracle-dev'
]
