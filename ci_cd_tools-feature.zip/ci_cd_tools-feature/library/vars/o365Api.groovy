/**
 * Post comment to teams channel using webhook URL
 * https://learn.microsoft.com/en-us/microsoftteams/platform/webhooks-and-connectors/how-to/connectors-using?tabs=cURL#send-messages-using-curl-and-powershell
 *
 * @param message String message text
 * @param webhookURLCreds String Jenkins credential ID holding webhook URL
 */
void postCommentTeamsChannel(String message, String webhookURLCreds) {
    withCredentials([string(credentialsId: webhookURLCreds, variable: 'WEBHOOK_URL')]) {
        sh "curl -H 'Content-Type: application/json' \
                -d '{\"text\": \"${message}\"}' ${WEBHOOK_URL}"
    }
}
