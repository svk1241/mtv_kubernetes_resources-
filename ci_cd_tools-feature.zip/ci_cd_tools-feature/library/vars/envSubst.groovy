String call(String text) {
    String result = text
    if (result) {
        //Collect all variables's names from text looks like ${VARIABLE_NAME}
        List tmpVariables = result.findAll(/(\$\{[A-z\-\_\.]*\})/).unique()
        tmpVariables.each { tmpVariable ->
            String fmtVariable = tmpVariable.substring(2, tmpVariable.size() - 1)
            if (env."${fmtVariable}") {
                result = result.replace(tmpVariable, env."${fmtVariable}")
            }
            else {
                echo "WARNING! Variable ${tmpVariable} isn't declared"
            }
        }
    }
    return result
}
