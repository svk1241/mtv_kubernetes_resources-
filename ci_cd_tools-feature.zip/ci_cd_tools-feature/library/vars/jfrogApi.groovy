/* groovylint-disable ImplicitReturnStatement */
/**
 * wrapper for methods using Artifactory credentials in their work
 */
Closure useArtifactoryCredentials(Closure body) {
    withCredentials([string(credentialsId: buildConstants.artifactoryCredentialsName, variable: 'API_TOKEN')]) {
        return body.call()
    }
}

/**
 * Uploads provided file to specified artifactory path
 *
 * @param folder String URL path to folder in Jfrog artifactory to upload file
 * @param file String full or relative path to file on local machine
 */
void uploadToArtifactory(String folder, String file) {
    useArtifactoryCredentials {
        sh "curl -H 'X-JFrog-Art-Api:${API_TOKEN}' -X PUT \"$folder\" -T ${file}"
    }
}

/**
 * Download specified file from provided artifactory path to current workdir
 *
 * @param folder String URL path to folder in Jfrog artifactory to upload file
 * @param file String full or relative path to file on local machine
 * @param windows Boolean specify to run on Windows agent or not
 */
void downloadFromArtifactory(String folder, String file) {
    useArtifactoryCredentials {
        if (isUnix()) {
            sh "curl --fail -H 'X-JFrog-Art-Api:${API_TOKEN}' -O \"${folder}/${file}\""
        } else {
            bat "curl --fail -H X-JFrog-Art-Api:${API_TOKEN} -O ${folder}/${file} -x http://proxy-nasa.svcs.entsvcs.com:8088"
        }
    }
}

/**
 * Moves provided artifactory file to speciied artifactory path
 *
 * @param artifactory String Jfrog artifactory URL
 * @param oldFolderName String old folder
 * @param oldFileName String old filename
 * @param newFolderName String new folder
 * @param newFileName String new filename
 */
void moveArtifactoryFile(String artifactory, String oldFolderName, String oldFileName, String newFolderName, String newFileName) {
    String ofn = oldFolderName.replace(artifactory, '')
    String nfn = newFolderName.replace(artifactory, '')
    useArtifactoryCredentials {
        sh "curl -H 'X-JFrog-Art-Api:${API_TOKEN}' --fail -X POST \"${artifactory}/api/move${ofn}/${oldFileName}?to=${nfn}/${newFileName}\""
    }
}

/**
 * Copies provided artifactory file to speciied artifactory path
 *
 * @param artifactory String Jfrog artifactory URL
 * @param oldFolderName String old folder
 * @param oldFileName String old filename
 * @param newFolderName String new folder
 * @param newFileName String new filename
 */
void copyArtifactoryFile(String artifactory, String oldFolderName, String oldFileName, String newFolderName, String newFileName) {
    String ofn = oldFolderName.replace(artifactory, '')
    String nfn = newFolderName.replace(artifactory, '')
    useArtifactoryCredentials {
        sh "curl -H 'X-JFrog-Art-Api:${API_TOKEN}' --fail -X POST \"${artifactory}/api/copy${ofn}/${oldFileName}?to=${nfn}/${newFileName}\""
    }
}

/**
 * Checks if specified file exists in Jfrog artifactory
 *
 * @param artifact String URL of file to verify
 */
boolean existsInArtifactory(String artifact) {
    return useArtifactoryCredentials {
        return !sh(script:"curl -H 'X-JFrog-Art-Api:${API_TOKEN}' --fail --head -X GET \"${artifact}\"", returnStatus: true)
    }
}

/**
 * Returns list of all artifacts for specified path
 *
 * @param artifactory String Jfrog artifactory URL
 * @param folder String path to folder
 */
List getArtifactsList(String artifactory, String folder) {
    List result = []
    useArtifactoryCredentials {
        String responce = sh(
            script:"curl -H 'X-JFrog-Art-Api:${API_TOKEN}' --fail -X GET \"${artifactory}/api/storage/${folder}\"",
            returnStdout: true)
        //We don't know type here, it can be JSONArray or JSONObject
        /* groovylint-disable-next-line NoDef, VariableTypeRequired */
        def jsonObj = readJSON text: responce.trim()
        if (!jsonObj.children) {
            if (jsonObj.errors) {
                echo "${jsonObj.errors.status}:${jsonObj.errors.message}"
            }
            error("Unable to find any artifact at path: ${folder}")
        }
        jsonObj.children.each { artifact ->
            result.add(artifact.uri)
        }
    }
    return result
}

/**
 * Take backup of specified file in artifactory, move it in the same folder with optional suffix and timestamp
 *
 * @param String artifactory artifactory url
 * @param folderName String folder name
 * @param fileName String filename of artifact to backup
 * @param suffix String optional suffix to add before timestamp
 */
void backupArtifactoryFile(String artifactory, String folderName, String fileName, String suffix = '') {
    /* groovylint-disable-next-line NoJavaUtilDate */
    Date now = new Date()
    String timestamp = now.format('yy_MM_dd__HH_mm')
    String folderNameTrim = folderName.replace(artifactory, '')
    if (existsInArtifactory("${artifactory}/${folderNameTrim}/${fileName}")) {
        moveArtifactoryFile(artifactory, folderNameTrim, fileName, folderNameTrim, "${fileName}-${suffix}-${timestamp}")
    }
}
