/**
 * Returns command to perform restore of specified database to provided restore point
 *
 * @param oracleSid String Database SID
 * @param restorePointName String name of restore point
 */
String restoreCommand(String oracleSid, String restorePointName) {
    return """\
        . oraenv <<< ${oracleSid} && \
        echo 'shutdown immediate;' | sqlplus / as sysdba && \
        echo 'startup mount;' | sqlplus / as sysdba && \
        echo 'FLASHBACK DATABASE TO RESTORE POINT ${restorePointName};' | rman target / && \
        echo 'alter database open resetlogs;' | sqlplus / as sysdba && \
        echo 'Finished!'""".stripIndent()
}

/**
 * Returns command to perform restore of specified RAC database to provided restore point
 *
 * @param oracleSid String Database SID
 * @param restorePointName String name of restore point
 */
String restoreRACCommand(String oracleSid, String restorePointName) {
    return """\
        . oraenv <<< ${oracleSid}1 && \
        srvctl stop database -d ${oracleSid} && \
        echo 'startup mount;' | sqlplus / as sysdba && \
        echo 'FLASHBACK DATABASE TO RESTORE POINT ${restorePointName};' | rman target / && \
        echo 'alter database open resetlogs;' | sqlplus / as sysdba && \
        srvctl stop database -d ${oracleSid} && \
        srvctl start database -d ${oracleSid} && \
        echo 'Finished!'""".stripIndent()
}

/**
 * Returns command to create provided restore point at specified database
 *
 * @param oracleSid String Database SID
 * @param restorePointName String name of restore point
 */
String createRestorePointCommand(String oracleSid, String restorePointName) {
    return """\
        . oraenv <<< ${oracleSid} && \
        echo 'CREATE RESTORE POINT ${restorePointName} GUARANTEE FLASHBACK DATABASE;' | sqlplus / as sysdba && \
        echo 'Finished!'""".stripIndent()
}

/**
 * Returns command to drop provided restore point ar specified database
 *
 * @param oracleSid String Database SID
 * @param restorePointName String name of restore point
 */
String dropRestorePointCommand(String oracleSid, String restorePointName) {
    return """\
        . oraenv <<< ${oracleSid} && \
        echo 'DROP RESTORE POINT ${restorePointName};' | sqlplus / as sysdba && \
        echo 'Finished!'""".stripIndent()
}

/**
 * Returns command to perform delete of all archive logs at specified database
 *
 * @param oracleSid String Database SID
 */
String deleteArchiveLogCommand(String oracleSid) {
    return """\
        . oraenv <<< ${oracleSid} && \
        echo 'delete noprompt archivelog all;' | rman target / && \
        echo 'Finished!'""".stripIndent()
}

/**
 * Returns command to shutdown specified database
 *
 * @param oracleSid String Database SID
 */
String shutdownImmediateDb(String oracleSid) {
    return """\
    . oraenv <<< ${oracleSid} && \
    echo 'shutdown immediate' | sqlplus / as sysdba && \
    echo 'Finished!'""".stripIndent()
}

/**
 * Returns command to startup specified database
 *
 * @param oracleSid String Database SID
 */
String startupDb(String oracleSid) {
    return """\
    . oraenv <<< ${oracleSid} && \
    echo 'startup' | sqlplus / as sysdba && \
    echo 'Finished!'""".stripIndent()
}
