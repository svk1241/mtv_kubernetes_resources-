/* groovylint-disable CompileStatic, DuplicateStringLiteral, ImplicitReturnStatement */

import java.text.SimpleDateFormat

@groovy.transform.Field
String publicRegistry = 'https://acreastuspublicdd.azurecr.io'

@groovy.transform.Field
String publicRegistryName = 'acreastuspublicdd.azurecr.io'

@groovy.transform.Field
String privateRegistry = 'https://acrregistryhubeastusprivated9f2.azurecr.io'

@groovy.transform.Field
String privateRegistryName = 'acrregistryhubeastusprivated9f2.azurecr.io'

@groovy.transform.Field
String privateRegistryCredentialsName = 'acrregistryhubeastusprivated9f2_credentials'

@groovy.transform.Field
String azurePrincipal = 'azure_service_principal'

List getManifests(String registry, String repo, Integer days=1) {
    withAzureCli {
        String result = sh label: "Get manigests from ${registry} for ${repo}",
                        returnStdout: true,
                        script: """az acr repository show-manifests \
                                    --name ${registry} \
                                    --repository ${repo} \
                                    --orderby time_desc \
                                    --top 100 \
                                    --output yaml"""
        List manifests = readYaml(text: result)
        Date maxDate = new Date() - days
        String pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS"
        manifests.each { m -> m['timestamp'] = m['timestamp'].drop(-5) }
        manifests = manifests.findAll { m ->
            new SimpleDateFormat(pattern, Locale.ENGLISH).parse(m['timestamp']) > maxDate
        }
        return manifests
    }
}

void importImage(String sourceRegistry, String sourceImage, String targetRegistry, String targetImage, Boolean force = false) {
    importImage("${sourceRegistry}/${sourceImage}", targetRegistry, targetImage, force)
}

void importImage(String sourceImage, String targetRegistry, String targetImage, Boolean force = false) {
    withAzureCli {
        String forceFlag = force ? '--force ' : '--force'
        String sImage = sourceImage.replaceAll('https://', '')
        sh "az acr import ${forceFlag} --name ${targetRegistry} --source ${sImage} --image ${targetImage}"
    }
}

List<String> getListVm(String resourceGroup) {
    withAzureCli {
        String vmList = sh(script: "az vm list --query \"[].name\" -o tsv -g ${resourceGroup}", returnStdout: true).trim()
        return vmList.split('\n')
    }
}

void operateVm(List vmNameList, String resourceGroup, String action) {
    withAzureCli {
        String vmIds = vmNameList.collect { name ->
            sh(script: "az vm show --name ${name} --resource-group ${resourceGroup} --query id -o tsv", returnStdout: true).trim()
        }.join(' ')
        Map<String,String> actionMapping = ['start': 'start', 'stop': 'deallocate']
        if (actionMapping.keySet().contains(action)) {
            sh "az vm ${actionMapping[action]} --ids ${vmIds}"
        } else {
            error("Invalid action specified. Please use 'start' or 'stop'.")
        }
        String finalStates = sh(
                                /* groovylint-disable-next-line LineLength */
                                script: "az vm list --resource-group ${resourceGroup} --show-details --query \"[?contains(['${vmNameList.join('\',\'')}'], name)].{Name:name, PowerState:powerState}\" -o table",
                                returnStdout: true).trim()
        echo "VM States:\n${finalStates}"
    }
}

void nodeScaling(String clusterName, String nodepoolName, String minCount, String maxCount, String resourceGroup) {
    withAzureCli {
        /* groovylint-disable-next-line LineLength */
        sh(script: "az aks nodepool update --update-cluster-autoscaler --min-count ${minCount} --max-count ${maxCount} -g ${resourceGroup} -n ${nodepoolName} --cluster-name ${clusterName}", returnStdout: true).trim()
    }
}

void buildImage(String folder, String registry, String image, String baseImage='') {
    withAzureCli {
        dir(folder) {
            String version = image.substring(image.lastIndexOf(':') + 1)
            if (fileExists('get_files.sh')) {
                withCredentials([string(credentialsId: 'artifactory_api_token', variable: 'ARTIFACTORY_TOKEN')]) {
                    sh './get_files.sh'
                }
            }
            if (baseImage) {
                sh "az acr build --registry ${registry} --image ${image} --build-arg 'IMAGE=${baseImage}' --build-arg VERSION=${version} ."
            } else {
                sh "az acr build --registry ${registry} --image ${image} --build-arg VERSION=${version} ."
            }
        }
    }
}

void printImageInfo(String registry, String image) {
    withAzureCli {
        sh label: "Get image info ${image} from registry ${registry}",
            returnStdout: true,
            script: "az acr repository show -n ${registry} --image ${image}"
    }
}
ARM_CLIENT_ID = '316e2fdb-0da7-4bb8-bb3c-db4588e3081a'
ARM_CLIENT_SECRET = 'ejZ8Q~AgTOV1dd.ki25KKKVoNN6~qdl~oelB0cBf'
ARM_TENANT_ID = '93f33571-550f-43cf-b09f-cd331338d086'
Closure withAzureCli(Closure body) {
    withCredentials([azureServicePrincipal('azurePrincipal')]) {
    sh """set +x ; az login --service-principal -u 316e2fdb-0da7-4bb8-bb3c-db4588e3081a -p 'ejZ8Q~AgTOV1dd.ki25KKKVoNN6~qdl~oelB0cBf' --tenant 93f33571-550f-43cf-b09f-cd331338d086 > /dev/null; set -x;
                  echo 'az login successful'"""
            body.call()
        }
}

void buildHelmPackage(String folder, String registry, String packageName) {
    withAzureCli {
        sh """
            cd ${folder}
            helm package .
            helm push ${packageName} oci://${registry}/helm
        """
    }
}

void importHelmPackage(String sourceRegistry, String sourceImage, String targetRegistry, String targetImage, Boolean force = false) {
    importImage(sourceRegistry, sourceImage, targetRegistry, targetImage, force)
}

return this
