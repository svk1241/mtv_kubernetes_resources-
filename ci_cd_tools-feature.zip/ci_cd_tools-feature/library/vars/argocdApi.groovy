import net.sf.json.JSONObject
import groovy.transform.Field

@Field final String ARGO_OP_STATUS_RUNNING = 'Running'
@Field final String ARGO_OP_STATUS_SUCCEEDED = 'Succeeded'
@Field final String ARGO_OP_STATUS_FAILED = 'Failed'
@Field final String ARGO_OP_STATUS_ERROR = 'Error'
@Field final String ARGO_OP_STATUS_TERMINATING = 'Terminating'
@Field final String ARGO_OP_STATUS_UNKNOWN = 'Unknown'

/* groovylint-disable-next-line DuplicateStringLiteral */
@Field final String ARGO_SYNC_STATUS_UNKNOWN = 'Unknown'
@Field final String ARGO_SYNC_STATUS_OUT_OF_SYNC = 'OutOfSync'
@Field final String ARGO_SYNC_STATUS_SYNCED = 'Synced'

@Field final String ARGO_HEALTH_STATUS_HEALTHY = 'Healthy'
@Field final String ARGO_HEALTH_STATUS_PROGRESSING = 'Progressing'
@Field final String ARGO_HEALTH_STATUS_DEGRADED = 'Degraded'
@Field final String ARGO_HEALTH_STATUS_SUSPENDED = 'Suspended'
@Field final String ARGO_HEALTH_STATUS_MISSING = 'Missing'
/* groovylint-disable-next-line DuplicateStringLiteral */
@Field final String ARGO_HEALTH_STATUS_UNKNOWN = 'Unknown'

/* groovylint-disable ImplicitReturnStatement */
/**
 * wrapper for methods using argocd
 *
 * @param argocdUrl String URL argocd hostname
 * @param body Closure script block to execute
 */
Closure useArgocd(String argocdUrl, Closure body) {
    withCredentials([usernamePassword(credentialsId: 'ddmtv_service_account',
                                      usernameVariable: 'ARGO_USER',
                                      passwordVariable: 'ARGO_PSWD',)]) {
        sh """argocd login  --grpc-web --insecure --username ${ARGO_USER} --password ${ARGO_PSWD} ${argocdUrl} && \
            echo 'argocd login successful'"""
        return body.call()
    }
}

String getArgocdAppStatus(String appName) {
    String output = sh(label: 'Get status', script: "argocd app get ${appName} --output json", returnStdout: true).trim()
    JSONObject jsonOutput = readJSON text: output
    String syncStatus = jsonOutput.status.sync.status
    String healthStatus = jsonOutput.status.health.status
    String operationPhase = jsonOutput.operationState?.phase ?: ARGO_OP_STATUS_UNKNOWN

    return ['syncStatus': syncStatus, 'healthStatus': healthStatus, 'operationPhase': operationPhase]
}

/**
 * Synchronizes argocd app, blocking further execution until either timeout reached or app synchronized
 *
 * @param argocdUrl String URL argocd hostname
 * @param appName Closure name of application to sync
 * @param timeoutSec Integer optional timeout to wait applicaton sync, default 10 minutes
 */
void syncArgocdApp(String argocdUrl, String appName, Integer timeoutSec = 900) {
    useArgocd(argocdUrl) {
        //refresh will trigger sync if auto-sync is enabled
        echo "status: ${getArgocdAppStatus(appName)}"
        String status = getArgocdAppStatus(appName).operationPhase
        echo "Application current operation: ${status}"
        if ([ARGO_OP_STATUS_RUNNING, ARGO_OP_STATUS_UNKNOWN].contains(status)) {
            sh "argocd app terminate-op ${appName} --grpc-web || true"
        }
        // Auto-sync is enabled for managed apps. So, sync will be triggered automatically immediately after refresh
        sh "argocd app get ${appName} --grpc-web --refresh && sleep 5"
        List progressingResources = [['status': ['resources': ['name': 'stub', 'health': ['status': ARGO_HEALTH_STATUS_DEGRADED]]]]]
        timeout(time: timeoutSec, unit: 'SECONDS') {
            while (status != ARGO_HEALTH_STATUS_HEALTHY || !progressingResources.isEmpty()) {
                String output = sh(script: "argocd app get ${appName} --output json", returnStdout: true)
                echo output
                /* groovylint-disable-next-line VariableTypeRequired */
                JSONObject jsonOutput = readJSON text: output
                status = jsonOutput.status.health.status
                progressingResources = jsonOutput.status.resources.findAll { res ->
                    String st = res?.health?.status ?: res?.status
                    return ![ARGO_SYNC_STATUS_SYNCED, ARGO_HEALTH_STATUS_HEALTHY, ''].contains(st)
                }

                if (status == ARGO_HEALTH_STATUS_HEALTHY && progressingResources.isEmpty()) {
                    echo 'Application status is Healthy and all resources are ready.'
                } else {
                    echo "Current application status: ${status}. Progressing resources: ${progressingResources*.name}."
                    sleep(30)
                }
            }
        }
        status = getArgocdAppStatus(appName).healthStatus
        echo "Application status: ${status}"
        sh "argocd app get ${appName}"
    }
}
