import groovy.json.JsonSlurper

/**
 * wrapper for methods using BB credentials in their work
 */
Closure useBBCredentials(Closure body) {
    return withCredentials([usernamePassword(credentialsId: buildConstants.jenkinsCredentialsName,
                                      usernameVariable: 'ACCESS_TOKEN_USERNAME',
                                      passwordVariable: 'ACCESS_TOKEN_PASSWORD',)]) {
        return body.call()
    }
}

/**
 * Deletes specified branch in provided bitbucket project repo
 * Note: Ensure repository allow to delete specific branch types ex. release used repository settings freak control
 *
 * @param project String project name
 * @param repository String repo name
 * @param branch String branch name
 */
void deleteBranch(String project, String repository, String branch) {
    useBBCredentials {
        sh(label: 'Delete branch',
           script: """curl -v --fail -H \"Content-Type:application/json\" -H \"Accept:application/json\" \
                        --user $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD \
                        --data '{\"name\": \"${branch}\" ,\"dryRun\": false}' \
                        -X DELETE ${buildConstants.bitbucket}/api/v3/repos/${project}/${repository}/git/refs/heads/${branch}""")
    }
}

/**
 * Creates pull request via bitbucket api
 *
 * @param project String project name
 * @param repository String repo name
 * @param name Pull request name
 * @param description Pull request description
 * @param sourceBranch From which branch to create Pull request
 * @param targetBranch Pull request target branch
 * @return Map containing fields: Bool successful flag, String PR URL url and String code result description
 */
 //TODO: refactor to use fields from library like repo/project
/* groovylint-disable-next-line ParameterCount */
Map createPr(String project, String repository, String name, String description, String sourceBranch, String targetBranch) {
    Map result = [successful: false, url: '', code: '']
                                                                                                                                                                                                                                                           
    String apiUrl = "${buildConstants.bitbucket}/api/v3/repos/${project}/${repository}/pulls"
    
    useBBCredentials {
        String templateBody = libraryResource 'bitbucket/prbody.json'
         def parsedResponse
         
        String body = String.format(templateBody, name, description, sourceBranch, targetBranch)
        // Check if the branch exists
                    echo "Checking if branch '${sourceBranch}' exists in the repository..."
                    def branchCheckResponse = sh(
                        script: """curl -s -H "Accept: application/vnd.github.v3+json" \
                        --user $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD \
                        -X GET https://github.dxc.com/api/v3/repos/${project}/${repository}/branches/${sourceBranch}""",
                        returnStdout: true).trim()
                 
                   def jsonResponsebranch = readJSON text: branchCheckResponse
                   def branchErrorMessage = jsonResponsebranch.message
                   
        
                   if (branchErrorMessage && branchErrorMessage == "Branch not found") {
                        echo "Branch '${sourceBranch}' does not exist."
                        result.code = 'BranchNotExist'
                    } else  {
                        echo "Branch '${sourceBranch}' exists. Proceeding to create a pull request..."
        
                      echo "Branch '${sourceBranch}' exists. Proceeding to create a pull request..."
        String response = sh(script:
                """curl -v -u $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD -H "Content-Type: application/json" -H \"Accept:application/json\" -X POST ${apiUrl} \
                  --data '{\"title\": \"${name}\" ,\"head\": \"${sourceBranch}\" ,\"base\": \"${targetBranch}\" ,\"body\": \"${description}\"}' 
                  """,
                returnStdout: true).trim()
                 echo "Response: ${response}"
                    def jsonResponse = readJSON text: response
                    if (jsonResponse.errors) {
                       echo "Failed to create pull request: ${jsonResponse.errors[0].message}"
                        if (jsonResponse.errors[0].message.contains('already exists') || jsonResponse.errors[0].message.contains('No commits')) {
                               echo " No Code Change"
                                result.code = 'NoChanges'
                            } else {
                                 echo "Branch Exist"
                                result.code = 'Exist'
                            }
                    } else {
                        def pullRequestUrl = jsonResponse.url
                        def pullRequestUrl1 = jsonResponse.url
                        echo "Pull Request URL: ${pullRequestUrl}"
                        result.code = 'Created'
                        result.successful = true
                        pullRequestUrl1 = jsonResponse.url.replaceAll("/(repos|api|v3)", "")
                        echo "Pull Request HELLLLLLLLLLLLLLLLLLLLLLLL URL: ${pullRequestUrl1}"
                     
                     
                        echo "Pull Request WATCHHHHHHHHHHHHHHHHHHHHURL: ${pullRequestUrl}"
                       result.url = "${pullRequestUrl}"

                    
                    }
                   }
    }
    return result
}

/**
 * Retrieves version of pull request
 *
 * @param prLink String link to pull request
 * @return String version of pull request
 */
String pullRequestVersion(String prLink) {
    return useBBCredentials {
        sh(label: 'Get version of jq',
           script: """apt-get install -y jq""")
        def version1 =  sh(label: 'Get version of pull request',
           script: """curl -v --fail -H \"Content-Type:application/json\" -H \"Accept:application/json\" \
                        --user $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD \
                        -X GET ${prLink} | jq -r .number """,
           returnStdout: true).trim()
        echo "pullRequestVersion PR Version: ${version1}"
    }
}

/**
 * Merges specified pull request
 *
 * @param prLink String link to pull request
 */
void mergePullRequest(String prLink) {
    echo "Line no 98 mergePullRequest============================================================="
    useBBCredentials {
        echo "PRfsgd Vesrion==============================================================}"
          echo "PR LINNNNNNNNNNNNNNNn==============================================================${prLink}"  
       String version1 = pullRequestVersion(prLink)
        sh(label: 'Get version of jq',
           script: """apt-get install -y jq""")
        def version =  sh(label: 'Get version of pull request',
           script: """curl -v --fail -H \"Content-Type:application/json\" -H \"Accept:application/json\" \
                        --user $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD \
                        -X GET ${prLink} | jq -r .head.sha """,
           returnStdout: true).trim()
        
        try{
      def response =  sh(label: 'Merge pull request',
               script: """curl -v --fail -H "Content-Type:application/json" -H "Accept:application/json" \
                          --user $ACCESS_TOKEN_USERNAME:$ACCESS_TOKEN_PASSWORD \
                          -X PUT ${prLink}/merge \
                          -d '{ "sha": "${version}", "commit_title": "Merging PR", "commit_message": "Merged via Jenkins" }'"""
                         )
           } catch (Exception e) {
                        echo "Failed to merge PR: ${e.message}"
                        currentBuild.result = 'FAILURE'
                        throw e
                    }
    }
}


/**
 * Downloads specified file from specified repo in BitBucket
 *
 * @param project String BitBucket project
 * @param repo String BitBucket repo
 * @param path String path to file relative to repo root
 * @param revision String revision (e.g. branch, tag, commit) from which to get file
 * @param outputFileName String file to store downloaded file locally
 */
void downloadFileFromBB(String project, String repo, String path, String revision, String outputFileName) {
    useBBCredentials {
        sh """
             curl -H "Authorization: token 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" -L \
            --output ${outputFileName} \
            'https://github.dxc.com/${project}/${repo}/${revision}/${path}'
            
        """ //'https://raw.githubusercontent.com/${project}/${repo}/${revision}/${path}'
    }
}

