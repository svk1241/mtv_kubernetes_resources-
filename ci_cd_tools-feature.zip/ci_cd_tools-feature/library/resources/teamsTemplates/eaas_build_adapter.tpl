[<b>${status}</b>]: Build DDMTV/Build/Extensions_as_a_Service/job/Extensions_Adapter_Build<br>
Adapter version: ${adapterVersion}<br>
MTV Base Version: ${mtvVersion}<br>
Version: ${mtvVersion}-${adapterVersion}<br>
Jenkins job:<br>
https://luxproject.luxoft.com/jenkins/job/DDMTV/job/Build/job/Extensions_as_a_Service/job/Extensions_Adapter_Build/${buildNumber}/<br>
Build content:<br>
https://luxproject.luxoft.com/confluence/display/DDMTV/Build%3A%3A${mtvVersion}-${adapterVersion}
