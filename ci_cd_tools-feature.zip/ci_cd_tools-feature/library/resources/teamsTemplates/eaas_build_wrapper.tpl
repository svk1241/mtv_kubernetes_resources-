[<b>${status}</b>]: Build DDMTV/Build/Extensions_as_a_Service/Extensions_Wrapper_Build<br>
Version: ${wrapperVersion}<br>
Jenkins job:<br>
https://luxproject.luxoft.com/jenkins/job/DDMTV/job/Build/job/Extensions_as_a_Service/job/Extensions_Wrapper_Build/${buildNumber}/<br>
Build content:<br>
https://luxproject.luxoft.com/confluence/display/DDMTV/Build%3A%3A${wrapperVersion}
