[<b>${status}</b>]: Build DDMTV/Deploy/Extensions_as_a_Service/EAAS_Deploy_All<br>
Extensions Wrapper Version: ${wrapperVer}<br>
Extensions Version: ${extVer}<br>
MTV Version: ${mtvVer}<br>
Environents: ${environments}<br>
Cluster: ${cluster}<br>
Jenkins job:<br>
https://luxproject.luxoft.com/jenkins/job/DDMTV/job/Deploy/job/Extensions_as_a_Service/job/EAAS_Deploy_All/${buildNumber}/
