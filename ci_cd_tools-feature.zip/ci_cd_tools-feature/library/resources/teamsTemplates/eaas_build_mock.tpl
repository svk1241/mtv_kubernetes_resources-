[<b>${status}</b>]: Build DDMTV/Build/Extensions_as_a_Service/job/Extensions_Mock_Build<br>
Mock version: ${mockVersion}<br>
MTV Base Version: ${mtvBaseVersion}<br>
Version: ${mtvBaseVersion}-${mockVersion}<br>
Jenkins job:<br>
https://luxproject.luxoft.com/jenkins/job/DDMTV/job/Build/job/Extensions_as_a_Service/job/Extensions_Mock_Build/${buildNumber}/<br>
Build content:<br>
https://luxproject.luxoft.com/confluence/display/DDMTV/Build%3A%3A${mtvBaseVersion}-${mockVersion}
