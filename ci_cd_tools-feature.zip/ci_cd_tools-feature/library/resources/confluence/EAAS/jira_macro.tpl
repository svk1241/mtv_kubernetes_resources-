<p>Project EAAS</p>
<p>
<ac:structured-macro ac:name=\"jira\" ac:schema-version=\"1\">
<ac:parameter ac:name=\"columns\">key,summary,type,created,updated,due,assignee,reporter,priority,status,resolution</ac:parameter>
<ac:parameter ac:name=\"maximumIssues\">20</ac:parameter>
<ac:parameter ac:name=\"jqlQuery\">project=EAAS and fixVersion=EWS:${VERSION}</ac:parameter>
</ac:structured-macro>
</p>
