#!/bin/bash -e
LOCAL_FOLDER=$1
REMOTE_FOLDER=$2
PASS=$3

function is_mounted() {
    mount | awk -v var=$1 '{if ($3==var) {print 0; exit}} ENDFILE {print 1}'
}

echo "environment=${LOCAL_FOLDER}"

if [[ $(is_mounted "/smb/$LOCAL_FOLDER") == "1" ]]; then
   mkdir -p /smb/${LOCAL_FOLDER}
   mount -t cifs -o "username=smbuser,password=${PASS},iocharset=utf8,vers=2.1" //smb-server/${REMOTE_FOLDER} /smb/${LOCAL_FOLDER}
fi

BATCH_FILES_DIR=/smb/${LOCAL_FOLDER}

if [[ -d ${BATCH_FILES_DIR} ]]
then
    rm -rf ${BATCH_FILES_DIR}/batch/{userctli,datain}
    rm -rf ${BATCH_FILES_DIR}/{bin,common,lib,sysin,userctli}
fi
