#!/bin/bash -e
LOCAL_FOLDER=$1
REMOTE_FOLDER=$2
ARCH_FOLDER=$3
TEST_ARTIFACTS_FOLDER=$4
PASS=$5

function is_mounted() {
    mount | awk -v var=$1 '{if ($3==var) {print 0; exit}} ENDFILE {print 1}'
}

echo "environment=${LOCAL_FOLDER}"
echo "environment=${REMOTE_FOLDER}"
echo "The server name is: $(hostname)"

if [[ $(is_mounted "/mtv/smb/$LOCAL_FOLDER") == "1" ]]; then
   mkdir -p /mtv/smb/${LOCAL_FOLDER}
   sudo mount -t cifs -o "username=smbuser,password=${PASS},iocharset=utf8,vers=2.1" //10.112.17.6/${REMOTE_FOLDER} /mtv/smb/${LOCAL_FOLDER}
fi

BATCH_FILES_DIR=/smb/${LOCAL_FOLDER}

cp -rfvp ${ARCH_FOLDER}/m210/* ${BATCH_FILES_DIR}
cp -rfvp ${ARCH_FOLDER}/m210/userctli/* ${BATCH_FILES_DIR}/batch/userctli/
cp -rfvp ${TEST_ARTIFACTS_FOLDER}/application/batch/datain/* ${BATCH_FILES_DIR}/batch/datain/
