#!/bin/bash -ex

version=${1:-"3.4.0-rc.2-1.0.93325-feature-mtv340rc2"}
folder=${2:-build}

[ -z "$ARTIFACTORY_TOKEN" ] && echo "Variable 'ARTIFACTORY_TOKEN' is empty or absent " && exit 1


mkdir -p ${folder} && rm -rf ${folder}/*
cd ${folder}

BASE_PATH=$(pwd)

mkdir -p ${BASE_PATH}/{dd-extensions,ews,ews_share,batch,online}

echo "Download original archive"
curl --fail -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" -O "https://artifactory.luxoft.com/ddmtv-generic/builds/v.${version}/ddx.tar.gz"
tar -xzf ddx.tar.gz -C ${BASE_PATH}/dd-extensions

#ews
echo "Create archive for EWS image"
mkdir -p ${BASE_PATH}/ews/ddx ${BASE_PATH}/ews/ddx/{scripts,etc/conf}
cp -r ${BASE_PATH}/dd-extensions/ddx/{bin,lib} ${BASE_PATH}/ews/ddx/
cp -r ${BASE_PATH}/dd-extensions/ddx/docs/* ${BASE_PATH}/ews/ddx/scripts/
cd ${BASE_PATH}/ews/
tar -czf ../ews.tar.gz ddx

#ews_share
echo "Create archive for EWS share"
mkdir -p ${BASE_PATH}/ews_share/ddx/flat_files
cp -r ${BASE_PATH}/dd-extensions/ddx/flat_files/prerestore ${BASE_PATH}/ews_share/ddx/flat_files/
cp -r ${BASE_PATH}/dd-extensions/ddx/flat_files/{cas,fss,ips} ${BASE_PATH}/ews_share/ddx/flat_files/
cd ${BASE_PATH}/ews_share/
tar -czf ../ews-share.tar.gz ddx

#mtv online
echo "Create archive for MTV Online"
mkdir -p ${BASE_PATH}/online/ddx/
cp -r ${BASE_PATH}/dd-extensions/ddx/lib ${BASE_PATH}/online/ddx/
cd ${BASE_PATH}/online/
tar -czf ../extensions-online.tar.gz ddx

#mtv batch
echo "Create archive for MTV Batch"
mkdir -p ${BASE_PATH}/batch/ddx/etc/conf
mkdir -p ${BASE_PATH}/batch/ddx/businessload/archive
cp -r ${BASE_PATH}/dd-extensions/ddx/lib ${BASE_PATH}/batch/ddx/
cp -r ${BASE_PATH}/dd-extensions/ddx/etc/dbd ${BASE_PATH}/batch/ddx/etc
cd ${BASE_PATH}/batch/
tar -czf ../extensions-batch.tar.gz ddx
