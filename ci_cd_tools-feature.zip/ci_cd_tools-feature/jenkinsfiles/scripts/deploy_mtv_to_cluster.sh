#!/bin/bash -ex

version="v.$1"
echo "Version: $version"
environments=$2
echo "Environments: $environments"
branch=$3
echo "Branch: $branch"
cluster=$4
echo "Cluster: $cluster"
project_url="https://${BB_USER}:${BB_PASSWORD}@luxproject.luxoft.com/stash/scm/ddmtv/kubernetes_mtv_environments.git"
project_folder="kubernetes_service_environments"
chart_folder='mtv-3.0'
helm_project_url="https://${BB_USER}:${BB_PASSWORD}@luxproject.luxoft.com/stash/scm/ddmtv/mtv_helm_chart.git"
helm_project_folder="mtv_helm_chart"
helm_project_branch="development"
git config --global user.name "ddmtv_service_account"
git config --global user.email "ddmtv_service_account@luxoft.com"
git clone ${project_url} -b ${branch} ${project_folder}
git clone ${helm_project_url} -b ${helm_project_branch} ${helm_project_folder}
cd ${project_folder}

for env in ${environments//,/ }
do
    echo "Updating: $env"
    mkdir -p ./$cluster/$env/charts && cp -rf ../${helm_project_folder}/${chart_folder} ./$cluster/$env/charts/
    rm -rf ./$cluster/$env/charts/${chart_folder}/conf/$env/*
    cp -rf ./$cluster/$env/conf ./$cluster/$env/charts/${chart_folder}/
    sed -i "s/deployApplication: false/deployApplication: true/" ./$cluster/$env/values.yaml
    sed -i "s/tag: \"v\..*\"/tag: \"$version\"/" ./$cluster/$env/values.yaml
done

git add .
git status
if ! git diff-index --quiet HEAD;
then
    git commit -m "[Jenkins]::[CI/CD]: Install MTV ${version}, cluster: ${cluster}, envs: ${environments}"
    git push
else
    echo "No changes"
fi
