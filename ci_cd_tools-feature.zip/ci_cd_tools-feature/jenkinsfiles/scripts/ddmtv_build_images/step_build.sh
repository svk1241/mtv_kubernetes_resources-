#!/bin/bash -e

declare -A image
default_image_name='default_image'
source ./jenkinsfiles/scripts/ddmtv_build_images/build_image_function.sh

# add key/value string
image['base']='step_default_image'
image['backend-batch']='step_default_image'
image['batch']='step_default_image'
image['backend-batch-dev']='step_default_image'
image['transaction-enabler']='step_default_image'
image['backend-infrastructure']='step_default_image'
image['backend-https-wrapper']='step_http_wrapper'
image['debug-image']='step_default_image'
image['batch-extensions']='step_default_image'
image['online-extensions']='step_default_image'

function step_http_wrapper() {
  echo "Build folder: $1"
  cd ./https-wrapper
  curl -H "X-JFrog-Art-Api:AKCp8k8Z97sAVZVmcBfA43awtufxqkfbHJow3kQTXRX5PnPEWQbjJhe8d3oV8mQx1iiUe5y47" -O "https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/builds/v.${VERSION}/version.txt"
 
  az acr build --registry acrregistryhubeastusprivated9f2 \
  --image $2 \
  --build-arg ATHENS_USER=${ATHENS_USERNAME} \
  --build-arg ATHENS_PASSWORD=${ATHENS_PASSWORD} \
  .
  cd -
}

function step_default_image() {
  echo "The $2 image will be built"
  build_image $1 $2 $3
}
