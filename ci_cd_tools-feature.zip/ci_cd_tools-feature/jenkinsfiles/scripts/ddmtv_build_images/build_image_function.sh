#!/bin/bash -e

REGISTRY="acrregistryhubeastusprivated9f2.azurecr.io"
REPOSITORY="mtv-base-gen86"
DIR_BUILD="base"

function build_image () {
  DIR_BUILD=$1
  REPOSITORY=$2
  echo $2 $REGISTRY $VERSION $3
  cd ./$1
  echo "Build folder: $1"
  if [  -f ./get_files.sh  ]
  then
    chmod +x *.sh
    echo "Executing script 'get_files.sh'"
    ./get_files.sh
  fi
  az acr build --registry $REGISTRY --image $2 --build-arg VERSION=$VERSION --build-arg IMAGE=$3 .
  cd -
}
