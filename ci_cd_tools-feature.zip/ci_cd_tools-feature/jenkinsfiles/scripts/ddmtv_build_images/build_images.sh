#!/bin/bash -e

[ -z "$VERSION" ] && echo "Variable 'VERSION' is empty or absent " && exit 1
[ -z "$IMAGE" ] && echo "Variable 'IMAGE' is empty or absent "
[ -z "$FOLDER" ] && echo "Variable 'FOLDER' is empty or absent " && exit 1
[ -z "$IMAGE_NAME" ] && echo "Variable 'IMAGE_NAME' is empty or absent " && exit 1
[ -z "$BASE_IMAGE" ] && echo "Variable 'BASE_IMAGE' is empty or absent "
[ -z "$ARTIFACTORY_TOKEN" ] && echo "Variable 'ARTIFACTORY_TOKEN' is empty or absent "

echo "buildVersion=${VERSION}"
echo "image=${IMAGE}"
echo "folder=${FOLDER}"
echo "IMAGE_NAME=${IMAGE_NAME}"
echo "BASE_IMAGE=${BASE_IMAGE}"
##### added image for getting the var inisde script

if [[ -f dockerfiles.v.${VERSION}.zip \
  || $IMAGE == 'backend-https-wrapper' \
  || $IMAGE == 'debug-image' ]]
then
  echo "zip file exists or not required."
else
  echo "downloading the zip and unzipping it."
  curl -H "X-JFrog-Art-Api:${ARTIFACTORY_TOKEN}" \
       -O https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic/builds/v.$VERSION/dockerfiles.v.$VERSION.zip
  unzip dockerfiles.v.$VERSION.zip
    find . -type f -exec sed -i -e "s/<ADAPTER-LIB-VERSION>/${VERSION}/g" {} ';'
fi
echo "Executing 'step_build.sh'"
source ./jenkinsfiles/scripts/ddmtv_build_images/step_build.sh
echo "trying to get the image associative array in the current file"

for key in "${!image[@]}"
do
  if [ $key == $IMAGE ]
  then
    echo "The '$key' image will be built"
    echo "Function '${image[$key]}' will be used for build."
    ${image[$key]} $FOLDER $IMAGE_NAME $BASE_IMAGE
  fi
done
