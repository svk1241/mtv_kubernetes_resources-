#!/bin/bash -e

project_url="https://${BB_USER}:${BB_PASSWORD}@luxproject.luxoft.com/stash/scm/ddmtv/kubernetes_extensions_service_environments.git"

git clone ${project_url} -b master ${ENV_REPO_FOLDER}


filename="${ENV_REPO_FOLDER}/$1/$2/values.yaml"

echo "yq -i '.secret.files.ddx-conf-secret.secretName = ${SECRET_NAME}' ${filename}"
yq -i '.secret.files.ddx-conf-secret.secretName = strenv(SECRET_NAME)' ${filename}

cd ${ENV_REPO_FOLDER}

git config --global user.name "ddmtv_service_account"
git config --global user.email "ddmtv_service_account@luxoft.com"
git config --global push.autoSetupRemote true

git add .
git status
if ! git diff-index --quiet HEAD;
then
    git commit -m "[Jenkins]::[CI/CD]: set ${SECRET_NAME} ews secret"
    git push
else
    echo "No changes"
fi
