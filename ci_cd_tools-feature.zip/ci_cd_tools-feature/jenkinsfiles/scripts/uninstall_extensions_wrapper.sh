#!/bin/bash -ex

environments=$1
echo "Environments: $environments"
branch=$2
echo "Branch: $branch"
cluster=$3
echo "Cluster: $cluster"
project_url="https://${BB_USER}:${BB_PASSWORD}@luxproject.luxoft.com/stash/scm/ddmtv/kubernetes_extensions_service_environments.git"
project_folder="kubernetes_extensions_service_environments"

git config --global user.name "ddmtv_service_account"
git config --global user.email "ddmtv_service_account@luxoft.com"
git clone ${project_url} -b ${branch} ${project_folder}
cd ${project_folder}

for env in ${environments//,/ }
do
    echo "Updating: $env"
    sed -i "s/deployApplication: true/deployApplication: false/" ./$cluster/$env/values.yaml
done

git add .
git status
if ! git diff-index --quiet HEAD;
then
    git commit -m "[Jenkins]::[CI/CD]: Uninstall extensions service cluster: ${cluster}, envs: ${environments}"
    git push
else
    echo "No changes"
fi
