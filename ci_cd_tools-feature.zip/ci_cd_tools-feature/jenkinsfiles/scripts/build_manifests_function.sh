function check() {
    var_names=("$@")
    for var_name in "${var_names[@]}"; do
        [ -z ${!var_name} ] && echo "$var_name is unset or
        empty." && result=true
    done
    [ -n "$result" ] && exit 1
    return 0
}

function backup () {
    echo "Backup yaml-generator"
    cd backend/kubernetes/deployment/
    mkdir -p yaml-generator-backup && rm -rf yaml-generator-backup/*
    cp -rfv ./yaml-generator/* ./yaml-generator-backup/
    cd -
}

function restore () {
    echo "Restore yaml-generator"
    cd backend/kubernetes/deployment/
    rm -rf yaml-generator/*
    cp -rfv ./yaml-generator-backup/* ./yaml-generator/
    cd -
}

function build_manifests() {
    echo "Build manifests for $1/$2, version $3"
    check HTTPS_WRAPPER_REPO \
          HTTPS_WRAPPER_TAG \
          TRANSACTION_ENABLER_REPO \
          TRANSACTION_ENABLER_TAG \
          BATCH_REPO \
          BATCH_TAG \
          INFRASTRUCTURE_TAG
    # By default we expect image tag which delimited <image>:<tag>
    # @ can be passed as delimeter to support digest <image>@<digest>
    delimiter=${4:-':'}
    cp -v backend/kubernetes/deployment/yaml-generator/namespaces/$1/$2.sh backend/kubernetes/deployment/yaml-generator/configs/internal-configuration.sh
    sed -i -e "s=${HTTPS_WRAPPER_REPO}:v.XX.XX=${HTTPS_WRAPPER_REPO}${delimiter}${HTTPS_WRAPPER_TAG}=g" ./backend/kubernetes/deployment/yaml-generator/configs/internal-configuration.sh
    sed -i -e "s=${TRANSACTION_ENABLER_REPO}:v.XX.XX=${TRANSACTION_ENABLER_REPO}${delimiter}${TRANSACTION_ENABLER_TAG}=g" ./backend/kubernetes/deployment/yaml-generator/configs/internal-configuration.sh
    sed -i -e "s=${BATCH_REPO}:v.XX.XX=${BATCH_REPO}:${BATCH_TAG}=g" ./backend/kubernetes/deployment/yaml-generator/configs/internal-configuration.sh
    sed -i -e "s=mtv-backend-infrastructure:v.XX.XX=mtv-backend-infrastructure:${INFRASTRUCTURE_TAG}=g" ./backend/kubernetes/deployment/yaml-generator/configs/internal-configuration.sh
    ./backend/kubernetes/deployment/yaml-generator/autogenerator.sh ./yamls/$1/$2/
}

function archive_manifests() {
    cd ./yamls && zip -r ../build.$1.zip .
    echo build.$1.zip
}

function get_digest() {
    local digest=$(az acr manifest show-metadata --name $2:$3 --registry $1 --query "digest")
    echo "$digest"
}
