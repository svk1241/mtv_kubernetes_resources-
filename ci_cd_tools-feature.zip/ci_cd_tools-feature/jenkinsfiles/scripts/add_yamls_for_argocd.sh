#!/bin/bash -ex
VERSION=$1
CLUSTER=$2 
ENVIRONMENTS=$3
project_url="https://gkumar22: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@github.dxc.com/MetaVance-Base/deployment_singleservice.git"
environment=deployment_singleservice
yamls_repository_folder=/opt/yamls
yml_generate_folder='/opt/yamls/deployment_singleservice'

git config --global user.name "gkumar22"
git config --global user.email "gkumar22@dxc.com"

rm -rf ${yamls_repository_folder}
mkdir -p ${yamls_repository_folder} && cd ${yamls_repository_folder}
git clone ${project_url} -b development
cd ${yml_generate_folder}

if [ "$CLUSTER" = "dev2" ] && [ "$ENVIRONMENTS" = "dev" ]
then
    cp -v /opt/yamls/deployment_singleservice/Yaml-Generator/namespace/dev.sh /opt/yamls/deployment_singleservice/Yaml-Generator/configs/internal-configuration.sh
    cp -v /opt/yamls/deployment_singleservice/Yaml-Generator/configs/aeenv_dev.tux /opt/yamls/deployment_singleservice/Yaml-Generator/configs/aeenv.tux
    sed -i -e "s=v.XX.XX=v.${VERSION}=g" /opt/yamls/deployment_singleservice/Yaml-Generator/configs/internal-configuration.sh
    chmod +x /opt/yamls/deployment_singleservice/Yaml-Generator/autogenerator.sh
    /opt/yamls/deployment_singleservice/Yaml-Generator/autogenerator.sh /opt/yamls/deployment_singleservice/MTV_Backend_Generated/dev2/dev 
fi
if [ "$CLUSTER" = "dev" ] && [ "$ENVIRONMENTS" = "ba" ]
then
    cp -v /opt/yamls/deployment_singleservice/Yaml-Generator/namespace/ba.sh /opt/yamls/deployment_singleservice/Yaml-Generator/configs/internal-configuration.sh
    cp -v /opt/yamls/deployment_singleservice/Yaml-Generator/configs/aeenv_ba.tux /opt/yamls/deployment_singleservice/Yaml-Generator/configs/aeenv.tux
    sed -i -e "s=v.XX.XX=v.${VERSION}=g" /opt/yamls/deployment_singleservice/Yaml-Generator/configs/internal-configuration.sh
    chmod +x /opt/yamls/deployment_singleservice/Yaml-Generator/autogenerator.sh
    /opt/yamls/deployment_singleservice/Yaml-Generator/autogenerator.sh /opt/yamls/deployment_singleservice/MTV_Backend_Generated/dev/ba
fi
if [ "$CLUSTER" = "dev" ] && [ "$ENVIRONMENTS" = "regression" ]
then
    cp -v /opt/yamls/deployment_singleservice/Yaml-Generator/namespace/regression.sh /opt/yamls/deployment_singleservice/Yaml-Generator/configs/internal-configuration.sh
    cp -v /opt/yamls/deployment_singleservice/Yaml-Generator/configs/aeenv_ba.tux /opt/yamls/deployment_singleservice/Yaml-Generator/configs/aeenv.tux
    sed -i -e "s=v.XX.XX=v.${VERSION}=g" /opt/yamls/deployment_singleservice/Yaml-Generator/configs/internal-configuration.sh
    chmod +x /opt/yamls/deployment_singleservice/Yaml-Generator/autogenerator.sh
    /opt/yamls/deployment_singleservice/Yaml-Generator/autogenerator.sh /opt/yamls/deployment_singleservice/MTV_Backend_Generated/dev/regression
fi
      
git add .
if ! git diff-index --quiet HEAD;
then
git commit -m "[Jenkins]::[CI/CD]: Add yamls for application version ${VERSION}"
git push
else
    echo "No changes"
fi
