#!/bin/bash -ex

project_url="https://${BB_USER}:${BB_PASSWORD}@luxproject.luxoft.com/stash/scm/ddmtv/kubernetes_mtv_environments.git"
yamls_repository_folder=yamls

git config --global user.name "ddmtv_service_account"
git config --global user.email "ddmtv_service_account@luxoft.com"

rm -rf ${yamls_repository_folder}
git clone ${project_url} -b master ${yamls_repository_folder}
cd ${yamls_repository_folder}

for FOLDER in ${YAML_FILES};
do
   rm -rf ${FOLDER}/{online,batch,infrastructure}
done
echo "[Jenkins]::[CI/CD]: Remove MTV application for envs: ${YAML_FILES//\/\*/}"
git add -u .
git status
if ! git diff-index --quiet HEAD;
then
    git commit -m "[Jenkins]::[CI/CD]: Remove MTV application for envs: ${YAML_FILES//\/\*/}"
    git push
else
    echo "No changes"
fi
