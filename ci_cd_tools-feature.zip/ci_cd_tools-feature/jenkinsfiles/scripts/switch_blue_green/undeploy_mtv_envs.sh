#!/bin/bash -ex

project_url="https://${BB_USER}:${BB_PASSWORD}@luxproject.luxoft.com/stash/scm/ddmtv/kubernetes_mtv_environments.git"
yamls_repository_folder=yamls

git config --global user.name "ddmtv_service_account"
git config --global user.email "ddmtv_service_account@luxoft.com"
rm -rf ${yamls_repository_folder}
git clone ${project_url} -b master ${yamls_repository_folder}
cd ${yamls_repository_folder}
for folder in ${ENVIRONMENTS}; do
    rm -rf ${AKS_CLUSTER}/${folder}/{online,batch,infrastructure,namespaces}
done
git add .
if ! git diff-index --quiet HEAD;
then
    git status
    git commit -m "[Jenkins]::[CI/CD]: remove envs: ${ENVIRONMENTS} from cluster ${AKS_CLUSTER}"
    git push
else
    echo "No changes"
fi
