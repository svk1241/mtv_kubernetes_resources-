#!/bin/bash -ex

SERVICE=$1
OLD_CLUSTER=$2
NEW_CLUSTER=$3

project_url="https://${BB_USER}:${BB_PASSWORD}@luxproject.luxoft.com/stash/scm/modpresale/argocd.git"
repository_folder=argocd

git config --global user.name "ddmtv_service_account"
git config --global user.email "ddmtv_service_account@luxoft.com"
rm -rf ${repository_folder}
git clone ${project_url} -b master ${repository_folder}
cd ${repository_folder}

test -e environments/mtv/${OLD_CLUSTER}/support-services/${SERVICE}.yaml || (echo "Service '${SERVICE}' doesn't exist or was already moved"; exit 1)

yq -i "(.. | select(has(\"valueFiles\")).valueFiles[]) |= sub(\"${OLD_CLUSTER}\", \"${NEW_CLUSTER}\") |
       (.. | select(has(\"directory\")).directory | select(has(\"include\")).include) |= sub(\"${OLD_CLUSTER}\", \"${NEW_CLUSTER}\") |
       (.. | select(has(\"directory\")).directory | select(has(\"exclude\")).exclude) |= sub(\"${NEW_CLUSTER}\", \"${OLD_CLUSTER}\")" \
            environments/mtv/${OLD_CLUSTER}/support-services/${SERVICE}.yaml
#Output changed yaml
cat environments/mtv/${OLD_CLUSTER}/support-services/${SERVICE}.yaml

mv environments/mtv/${OLD_CLUSTER}/support-services/${SERVICE}.yaml environments/mtv/${NEW_CLUSTER}/support-services/${SERVICE}.yaml

git add .
if ! git diff-index --quiet HEAD;
then
    git status
    git commit -m "[Jenkins]::[CI/CD]: move service: ${SERVICE} to cluster ${NEW_CLUSTER}"
    git push
else
    echo "No changes"
fi
