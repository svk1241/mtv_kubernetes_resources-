#!/bin/bash
set -e

echo "Repository: $1"
repo=$1
echo "Merging branch: $2"
source_branch=$2
echo "Merging to: $3"
destination_branch=$3
git_creds=$4
echo "Commit message: $5"
commit_message=$5

echo "Cleaning up repository directory . . ."
rm -rf ./current_repo
echo "Clean up completed!"

git clone "https://${git_creds}@${repo}" current_repo
cd ./current_repo
git config user.email "jenkins@ddmtv-cd-ci.com"
git config user.name "Jenkins [Luxoft]"
if [[ -z $(git ls-remote --heads origin $source_branch) ]]; then
    echo "Unable to merge since $source_branch does not exist"
    exit 0
fi
if [[ -z $(git ls-remote --heads origin $destination_branch) ]]; then
    echo "Unable to merge since $destination_branch does not exist"
    exit 0
fi
git checkout $source_branch
git checkout $destination_branch
git merge $source_branch --commit --no-ff -m "$commit_message"
git push origin $destination_branch
cd -

