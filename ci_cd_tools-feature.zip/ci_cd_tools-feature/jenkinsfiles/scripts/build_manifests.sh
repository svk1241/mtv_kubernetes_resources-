#!/bin/bash -e

BASE_PATH="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
source $BASE_PATH/build_manifests_function.sh

VERSION=$2
HTTPS_WRAPPER_REPO="https-wrapper-deltadental"
HTTPS_WRAPPER_TAG="v.$VERSION"
TRANSACTION_ENABLER_REPO="transaction-enabler-deltadental"
TRANSACTION_ENABLER_TAG="v.$VERSION"
BATCH_REPO="mtv-backend-batch"
BATCH_TAG="v.$VERSION"
INFRASTRUCTURE_TAG="v.$VERSION"

cd $1
backup
# Create clear MTV manifests
cd backend/kubernetes/deployment/yaml-generator && mv -fv ./configs-default/* ./configs/ && cd -
build_manifests aks002 regression $VERSION
build_manifests aks003 regression $VERSION
build_manifests aks002 concurrency $VERSION
build_manifests aks003 concurrency $VERSION
build_manifests aks002 extensions $VERSION
build_manifests aks003 extensions $VERSION
# Create MTV manifests with EaaS adapter
build_manifests aks002 extensions_eaas $VERSION
build_manifests aks003 extensions_eaas $VERSION
# Create MTV manifests with mocks
build_manifests aks002 extensions_mock $VERSION
build_manifests aks003 extensions_mock $VERSION
cd backend/kubernetes/deployment/yaml-generator && mv -fv ./configs-dev/* ./configs/ && cd -
build_manifests aks002 dev $VERSION
build_manifests aks003 dev $VERSION
restore
cd backend/kubernetes/deployment/yaml-generator && mv -fv ./configs-integration/* ./configs/ && cd -
build_manifests aks002 integration $VERSION
build_manifests aks003 integration $VERSION
restore
# Getting digests using tags
HTTPS_WRAPPER_REPO="mtv-backend-https-wrapper-deltadental"
HTTPS_WRAPPER_TAG=$(get_digest 'acrregistryhubeastusprivatew4ft' 'https-wrapper-deltadental' "v.${VERSION}")
TRANSACTION_ENABLER_REPO="mtv-transaction-enabler-deltadental"
TRANSACTION_ENABLER_TAG=$(get_digest 'acrregistryhubeastusprivatew4ft' 'transaction-enabler-deltadental' "v.${VERSION}")
BATCH_REPO="mtv-backend-batch-deltadental"
cd backend/kubernetes/deployment/yaml-generator && mv -fv ./configs-mtvbluhci/* ./configs/ && cd -
build_manifests hci mtvbluhci $VERSION '@'
restore
build_manifests hci mtvgrnhci $VERSION '@'
cd backend/kubernetes/deployment/yaml-generator && mv -fv ./configs-mtvbluhci-extensions/* ./configs/ && cd -
build_manifests hci mtvbluhci-extensions $VERSION '@'
restore
build_manifests hci mtvgrnhci-extensions $VERSION '@'
restore
archive_manifests "v.$VERSION"
cd -
