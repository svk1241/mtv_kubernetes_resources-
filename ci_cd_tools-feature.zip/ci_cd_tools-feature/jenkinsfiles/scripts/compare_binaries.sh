#!/bin/bash

dir1=$1
dir2=$2
output_file=$3

compare_dirs() {
  for file in "$1"/*; do
    relative_path="${file#$1/}"
    if [ -d "${file}" ]; then
      if [ -d "$2/${relative_path}" ]; then
        compare_dirs "$file" "$2/${relative_path}"
      else
        echo "Directory ${relative_path} exists in $1 but not in $2" >> "${output_file}"
      fi
    elif [ -f "${file}" ]; then
      if [ -f "$2/${relative_path}" ]; then
        cmp "${file}" "$2/${relative_path}" > /dev/null
        if [ $? -ne 0 ]; then
          echo "File ${relative_path} is different" >> "${output_file}"
        fi
      else
        echo "File ${relative_path} exists in $1 but not in $2" >> "${output_file}"
      fi
    fi
  done
}

compare_dirs "${dir1}" "${dir2}" "${output_file}"
