#!/bin/bash
set -ex

echo "Repository: $1"
repo=$1
echo "Checking out to: $2"
git_branch=$2
echo "Version/tag: $3"
version=$3
git_creds=$4
force=""
rm -rf ./current_repo1
git clone "https://${git_creds}@${repo}" current_repo1

 cd ./current_repo1
 git config user.email "gkumar22@dxc.com"
git config user.name "gkumar22 [DXC]"

if [ $(git tag -l "Build/$version") ]; then
    echo "Provided tag Build/$version already exist"
    if [ -z "$5" ]
    then
        echo "No override flag was provided, exit"
        exit 1
    else
        echo "Override flag was provided, processing"
        force="--force"
    fi
fi
git checkout $git_branch
git tag -a $force "Build/$version" -m "tag added by Jenkins"
git push origin --tags $force
git log -2
pwd
cd -
pwd
rm -rf ./current_repo1
