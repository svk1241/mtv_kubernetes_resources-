#!/bin/bash -ex

version="v.$1"
echo "Version: $version"
environments=$2
echo "Environments: $environments"
branch=$3
echo "Branch: $branch"
cluster=$4
echo "Cluster: $cluster"
project_url="https://gkumar22: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@github.dxc.com/MetaVance-Base/kubernetes_extensions_service_environments.git"
project_folder="kubernetes_extensions_service_environments"

helm_project_url="https://gkumar22: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@github.dxc.com/MetaVance-Base/extensions_service_helm_chart.git"
helm_project_folder="extensions_service_helm_chart"
helm_project_branch="feature"
git config --global user.name "gkumar22"
git config --global user.email "gkumar22@dxc.com"
git clone ${project_url} -b ${branch} ${project_folder}
git clone ${helm_project_url} -b ${helm_project_branch} ${helm_project_folder}
cd ${project_folder}

for env in ${environments//,/ }
do
    echo "Updating: $env"
    mkdir -p ./$cluster/$env/charts && cp -rf ../${helm_project_folder}/extensions-service ./$cluster/$env/charts/
    rm -rf ./$cluster/$env/charts/extensions-service/conf/$env/*
    cp -rf ./$cluster/$env/conf ./$cluster/$env/charts/extensions-service/
    sed -i "s/deployApplication: false/deployApplication: true/" ./$cluster/$env/values.yaml
    sed -i "s/tag: \"v\..*\"/tag: \"$version\"/" ./$cluster/$env/values.yaml
done

git add .
git status
if ! git diff-index --quiet HEAD;
then
    git commit -m "[Jenkins]::[CI/CD]: Install extensions service ${version}, cluster: ${cluster}, envs: ${environments}"
    git push
else
    echo "No changes"
fi
