function gitClone {
  param (
    [Parameter (Mandatory=$true, Position=1)]
    [String]$url,
    [Parameter (Mandatory=$true, Position=2)]
    [String]$branch
  )

  git clone $url --branch $branch --single-branch
  if ($LASTEXITCODE) { Throw "git clone failed" }

}

$ErrorActionPreference = "Stop"

Connect-PnPOnline -Url https://dxcportal.sharepoint.com/sites/DeltaDentalMTV_1 -DeviceLogin ;

[string]$GIT_USER = $env:GIT_USER
[string]$GIT_PASSWORD = $env:GIT_PASSWORD
[string]$VERSION = $env:VERSION
Write-Output "Processing release/${VERSION}"
[string]$ReleaseNotes = "MTV EaaS - Build v.${VERSION} Release Notes.docx"
$FoldersList = "${VERSION}", "automation", "automation_concurrency", "ci_cd_tools", "testing_artifacts"
foreach ($Folder in $FoldersList) {
  if (Test-Path $Folder) {
    Remove-Item $Folder -Recurse -Force
  }
}

New-Item "./${VERSION}/Documentation" -itemType Directory -Force
New-Item "./${VERSION}/Testing/Automated Concurrency Tests" -itemType Directory -Force
New-Item "./${VERSION}/Testing/Automated Tests" -itemType Directory -Force
New-Item "./${VERSION}/Testing/Test Cases" -itemType Directory -Force
New-Item "./${VERSION}/Testing/Testing Artifacts" -itemType Directory -Force
####################################################################################

gitClone -url "https://${GIT_USER}:${GIT_PASSWORD}@luxproject.luxoft.com/stash/scm/ddmtv/automation.git" -branch "EAAS/${VERSION}"
#Copy automated tests
Copy-Item -Path "./automation/*" `
          -Destination "./${VERSION}/Testing/Automated Tests/" -Recurse
Remove-Item "./${VERSION}/Testing/Automated Tests/internal" -Recurse -Force
####################################################################################

gitClone -url "https://${GIT_USER}:${GIT_PASSWORD}@luxproject.luxoft.com/stash/scm/ddmtv/automation_concurrency.git" -branch "EAAS/${VERSION}"
#Copy automated concurency tests
Copy-Item -Path "./automation_concurrency/*" `
          -Destination "./${VERSION}/Testing/Automated Concurrency Tests/" -Recurse
Remove-Item "./${VERSION}/Testing/Automated Concurrency Tests/internal" -Recurse -Force
###################################################################################

gitClone -url "https://${GIT_USER}:${GIT_PASSWORD}@luxproject.luxoft.com/stash/scm/ddmtv/testing_artifacts.git" -branch "EAAS/${VERSION}"
# Copy testing artifacts
Copy-Item -Path "./testing_artifacts/*" `
          -Destination "./${VERSION}/Testing/Testing Artifacts/" -Recurse
###################################################################################

#Collect Documentation
Get-PnPFile -Url "/sites/DeltaDentalMTV_1/Shared Documents/General/DevOps/Release Notes/EaaS/${ReleaseNotes}" `
            -Path "./${VERSION}/" -FileName "${ReleaseNotes}" -AsFile -Force
$files =
@(
  @("/sites/DeltaDentalMTV_1/Shared Documents/General/DevOps/Documents/Deliverables", "MTV EaaS - Deployment Instruction.docx"),
  @("/sites/DeltaDentalMTV_1/Shared Documents/General/Requirements/EaaS/Deliverables", "MTV EaaS - EWS Requirements.docx"),
  @("/sites/DeltaDentalMTV_1/Shared Documents/General/Requirements/EaaS/Deliverables", "MTV EaaS - EAL Requirements.docx"),
  @("/sites/DeltaDentalMTV_1/Shared Documents/General/Requirements/EaaS/Deliverables", "MTV EaaS - EWS HTTP Interface.docx"),
  @("/sites/DeltaDentalMTV_1/Shared Documents/General/Requirements/EaaS/Deliverables", "MTV EaaS - Recomendations for DDC.docx"),
  @("/sites/DeltaDentalMTV_1/Shared Documents/General/Architecture/Documentation/Deliverables", "MTV EaaS - Architecture Definition Document.docx"),
  @("/sites/DeltaDentalMTV_1/Shared Documents/General/Testing/EaaS/Documents/Deliverables/Test Report/Overall Report", "MTV EaaS - Test Report ${VERSION}.xlsx"),
  @("/sites/DeltaDentalMTV_1/Shared Documents/General/Testing/EaaS/Documents/Deliverables/Test Report/Non-Functional", "MTV EaaS - Non-Functional Test Report ${VERSION}.docx"),
  @("/sites/DeltaDentalMTV_1/Shared Documents/General/Testing/EaaS/Documents/Deliverables", "MTV EaaS - Testing Artifacts Guide.pdf"),
  @("/sites/DeltaDentalMTV_1/Shared Documents/General/Testing/EaaS/Documents/Deliverables/Test Strategy", "MTV EaaS - Test Strategy.docx")
)
Foreach ($file in $files) {
  Get-PnPFile -Url "$($file[0])/$($file[1])" `
              -Path "./${VERSION}/Documentation" -FileName $file[1] -AsFile -Force
}
#Collect Testing\Test Cases
$files = @("MTV Extensions - Test cases.xlsx",
           "Test Cases - Functional.docx",
           "Test Cases - Performance.docx",
           "Test Cases - Resilience.docx",
           "Test Cases - Scalability.docx",
           "Test Cases - Security.docx")
$filePath = "/sites/DeltaDentalMTV_1/Shared Documents/General/Testing/EaaS/Documents/Deliverables/Test Cases"
Foreach ($file IN $files) {
  Get-PnPFile -Url "${filePath}/${file}" `
              -Path "./${VERSION}/Testing/Test Cases" -FileName $file -AsFile -Force
}
# #Make zip
Write-Output "Creating zip file EaaS_${VERSION}.zip"
cd ${VERSION} && zip -r ../EaaS_${VERSION}.zip * && cd -
Add-PnPFile -Path "./EaaS_${VERSION}.zip" -Folder "Shared Documents/General/Delivery/Work Package/"
