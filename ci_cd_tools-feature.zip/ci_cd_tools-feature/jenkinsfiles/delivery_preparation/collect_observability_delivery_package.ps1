function gitClone {
  param (
    [Parameter (Mandatory=$true, Position=1)]
    [String]$url,
    [Parameter (Mandatory=$true, Position=2)]
    [String]$branch
  )

  git clone $url --branch $branch --single-branch
  if ($LASTEXITCODE) { Throw "git clone failed" }

}

$ErrorActionPreference = "Stop"

[string]${site} = '/sites/MTV-DXCLuxoftcollaboration'
Connect-PnPOnline -Url "https://dxcportal.sharepoint.com/${site}" -DeviceLogin ;

[string]$GIT_USER = $env:GIT_USER
[string]$GIT_PASSWORD = $env:GIT_PASSWORD
[string]$VERSION = $env:VERSION
[string]$deliveryFolder = "MTV_Observability_Platform_${VERSION}"
[string]$deliveryArtifact = "${deliveryFolder}_auto.zip"
[string]$releaseNotesUrl = "${site}/Shared Documents/General/DevOps/Release Notes/Observability Platform/MetaVance Modernization - Observability Platform ${VERSION} Release Notes.docx"
[string[]] $files =
@(
  "${site}/Shared Documents/General/DevOps/Instructions/MetaVance Modernization - Observability Platform Installation.docx",
  "${site}/Shared Documents/General/Testing/Test Documents/Test Reports/Observability Platform/MetaVance Modernization - Observability Platform Test Report ${VERSION}.pdf",
  "${site}/Shared Documents/General/Requirements/NFR/Deliverables/MetaVance Modernization - Maintenance Scenarios.docx",
  "${site}/Shared Documents/General/DevOps/Runbooks/MetaVance Modernization - Observability Runbook.docx",
  "${site}/Shared Documents/General/Requirements/NFR/Deliverables/MetaVance - Client Proxy Monitoring Requirements.docx",
  "${site}/Shared Documents/General/Testing/Test Documents/Test Cases/Observability/MetaVance - Client Proxy Monitoring - Test Cases.pdf",
  "${site}/Shared Documents/General/Testing/Test Documents/Test Cases/Observability/MetaVance - Scheduled query alerts - Test Cases.pdf"
)

# Initial cleanup
$FoldersList = "./${deliveryFolder}", "./observability_platform_delivery"
foreach ($Folder in $FoldersList) {
  if (Test-Path $Folder) {
    Remove-Item $Folder -Recurse -Force
  }
}
New-Item $deliveryFolder -itemType Directory

gitClone -url "https://${GIT_USER}:${GIT_PASSWORD}@luxproject.luxoft.com/stash/scm/ddmtv/observability_platform_delivery.git" -branch "${VERSION}"

# Copy terraform files and stamp them with current version
Copy-Item -Path "./observability_platform_delivery/Terraform" -Destination "./${deliveryFolder}" -Recurse
Get-ChildItem "./${deliveryFolder}/Terraform/data" -Recurse -Filter *.workbook |
Foreach-Object {
  ((Get-Content -path $_.FullName -Raw) -replace '{{ development }}', "${VERSION}") | Set-Content -NoNewline -Path $_.FullName
}
Get-ChildItem "./${deliveryFolder}/Terraform/modules" -Recurse -Filter *.tf |
Foreach-Object {
  ((Get-Content -path $_.FullName -Raw) -replace '{{ development }}', "${VERSION}") | Set-Content -NoNewline -Path $_.FullName
}
Write-Host "Terraform files fetched and stamped with ${VERSION}"

# Copy requirements.txt
Copy-Item -Path "./observability_platform_delivery/requirements.txt" -Destination "./${deliveryFolder}"
Write-Host "requirements.txt fetched"

# Generate otel-collector
New-Item "./${deliveryFolder}/Manifests" -itemType Directory
helm template "./observability_platform_delivery/Manifests/otel-collector" > "./observability_platform_delivery/Manifests/otel-collector-deployment.yaml"
Get-Content "./observability_platform_delivery/Manifests/otel-collector-deployment.yaml" | Where { $_ -notmatch "^#." } | Set-Content "./${deliveryFolder}/Manifests/otel-collector-deployment.yaml"
Write-Host "Otel collector generated"

# Copy container-azm-ms-agentconfig.yaml
Copy-Item -Path "./observability_platform_delivery/Manifests/container-azm-ms-agentconfig.yaml" -Destination "./${deliveryFolder}/Manifests"
Write-Host "container-azm-ms-agentconfig.yaml fetched"

# Generate version.txt
if (Test-Path "./${deliveryFolder}/version.txt") {
  Remove-Item "./${deliveryFolder}/version.txt"
}
$VERSION | Out-File "./${deliveryFolder}/version.txt"
Write-Host "Generated version.txt"

# Get Release notes
Get-PnPFile -Url ${releaseNotesUrl} -Path "./${deliveryFolder}" -FileName $($releaseNotesUrl -split "/")[-1] -AsFile -Force
Write-Host "Release notes fetched"

# Platform documentation folder
[string]$docsFolder = "./${deliveryFolder}/Platform Documentation"
New-Item $docsFolder -itemType Directory

Foreach ($file in $files) {
  $fileName = $($file -split "/")[-1]
  Get-PnPFile -Url ${file} `
              -Path $docsFolder -FileName ${fileName} -AsFile -Force
  Write-Host "'${fileName}' fetched into '${docsFolder}'"
}

# Make zip
cd ${deliveryFolder} && zip -r "../${deliveryArtifact}" * && cd -
Write-Host "Archive '${deliveryArtifact}' prepared"

# Upload archive
Add-PnPFile -Path "./${deliveryArtifact}" -Folder "Shared Documents/General/Delivery/Observability Platform/"
Write-Host "Archive uploaded"
