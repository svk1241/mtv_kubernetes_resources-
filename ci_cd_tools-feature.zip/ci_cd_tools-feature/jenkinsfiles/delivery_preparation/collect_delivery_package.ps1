function gitClone {
  param (
    [Parameter (Mandatory=$true, Position=1)]
    [String]$url,
    [Parameter (Mandatory=$true, Position=2)]
    [String]$branch
  )

  git clone $url --branch $branch --single-branch
  if ($LASTEXITCODE) { Throw "git clone failed" }

}

$ErrorActionPreference = "Stop"
$ARTIFACTORY_TOKEN = "AKCp8k8Z97sAVZVmcBfA43awtufxqkfbHJow3kQTXRX5PnPEWQbjJhe8d3oV8mQx1iiUe5y47"


Connect-PnPOnline -Url "https://dxcportal.sharepoint.com/sites/MTV-DXCLuxoftcollaboration" -ClientId "63ca2cdc-5a9c-4885-b560-b97bedea2fc7" -Tenant "CSCPortal.onmicrosoft.com" -CertificatePath "/app/MTV_Delivery_Package2.pfx"

[string]$GIT_USER = $env:GIT_USER
[string]$GIT_PASSWORD = $env:GIT_PASSWORD
[string]$VERSION = $env:VERSION
write-host "Processing release/${VERSION}"
[string]$ReleaseNotes = "MetaVance Modernization - Build v.${VERSION} Release Notes.docx"
[string]$ARTIFACTORY_FOLDER = "https://artifactory.dxc.com:443/artifactory/MetaVance-Base-Generic"
[string]$ARTIFACTORY_BUILD_FOLDER = "$ARTIFACTORY_FOLDER/builds/v.${VERSION}"
[string]$ARTIFACTORY_TOKEN = $env:ARTIFACTORY_TOKEN
[string]$GUI_CLIENT = $env:GUI_CLIENT
[string]$KNATIVE_ARTIFACT_VERSION = $env:KNATIVE_ARTIFACT_VERSION
$FoldersList = "${VERSION}", "automation" , "mtv_kubernetes_resources", "azure_infrastructure_delivery", "automation_concurrency", "ci_cd_tools"
foreach ($Folder in $FoldersList) {
  if (Test-Path $Folder) {
    Remove-Item $Folder -Recurse -Force
  }
}
New-Item ".\${VERSION}\Linux Backend\Batch" -itemType Directory -Force
New-Item ".\${VERSION}\Linux Backend\Extensions" -itemType Directory -Force
New-Item ".\${VERSION}\Linux Backend\Kubernetes\Deployment\Common" -itemType Directory -Force
New-Item "./${VERSION}/Linux Backend/Kubernetes/Deployment/Common/knative" -itemType Directory -Force
New-Item ".\${VERSION}\Linux Backend\Kubernetes\Deployment\Common\secrets" -itemType Directory -Force
New-Item ".\${VERSION}\Linux Backend\Kubernetes\Deployment\Yaml-Generator" -itemType Directory -Force
New-Item "./${VERSION}/Modernization Documentation" -itemType Directory -Force
New-Item ".\${VERSION}\Optional Tools\Azure Infrastructure Example (DEV env)" -itemType Directory -Force
New-Item "./${VERSION}/Testing/Automated Concurrency Tests" -itemType Directory -Force
New-Item "./${VERSION}/Testing/Automated Tests" -itemType Directory -Force
New-Item "./${VERSION}/Testing/Test Cases" -itemType Directory -Force
New-Item "./${VERSION}/Testing/Testing Artifacts" -itemType Directory -Force
New-Item "./${VERSION}/Testing/Automated Infrastructure Tests" -itemType Directory -Force
New-Item ".\${VERSION}\Windows\MtvClientProxy" -itemType Directory -Force
####################################################################################

gitClone -url "https://${GIT_USER}:${GIT_PASSWORD}@github.dxc.com/MetaVance-Base/automation.git" -branch "delivery"
#Copy automated tests
Copy-Item -Path "./automation/*" `
          -Destination "./${VERSION}/Testing/Automated Tests/" -Recurse
Remove-Item "./${VERSION}/Testing/Automated Tests/internal" -Recurse -Force
####################################################################################

gitClone -url "https://${GIT_USER}:${GIT_PASSWORD}@github.dxc.com/MetaVance-Base/automation_concurrency.git" -branch "delivery"
#Copy automated concurency tests
Copy-Item -Path "./automation_concurrency/*" `
          -Destination "./${VERSION}/Testing/Automated Concurrency Tests/" -Recurse
Remove-Item "./${VERSION}/Testing/Automated Concurrency Tests/internal" -Recurse -Force
###################################################################################
gitClone -url "https://${GIT_USER}:${GIT_PASSWORD}@github.dxc.com/MetaVance-Base/testing_artifacts.git" -branch "feature"
# Copy testing artifacts
Copy-Item -Path "./testing_artifacts/*" `
          -Destination "./${VERSION}/Testing/Testing Artifacts/" -Recurse
###################################################################################

gitClone -url "https://${GIT_USER}:${GIT_PASSWORD}@github.dxc.com/MetaVance-Base/automation_test_infrastructure.git" -branch "delivery"
# Copy testing artifacts
Copy-Item -Path "./automation_test_infrastructure/*" `
          -Destination "./${VERSION}/Testing/Automated Infrastructure Tests/" -Recurse
###################################################################################

gitClone -url "https://${GIT_USER}:${GIT_PASSWORD}@github.dxc.com/MetaVance-Base/mtv_kubernetes_resources.git" -branch "feature"
#Copy Yaml Generator
Copy-Item -Path "./mtv_kubernetes_resources/backend/kubernetes/deployment/yaml-generator/autogenerator.sh", `
                "./mtv_kubernetes_resources/backend/kubernetes/deployment/yaml-generator/chartgenerator.sh" `
          -Destination "./${VERSION}/Linux Backend/Kubernetes/Deployment/Yaml-Generator/"
Copy-Item -Path "./mtv_kubernetes_resources/backend/kubernetes/deployment/yaml-generator/configs" `
          -Destination "./${VERSION}/Linux Backend/Kubernetes/Deployment/Yaml-Generator/" -Recurse
Copy-Item -Path "./mtv_kubernetes_resources/backend/kubernetes/deployment/yaml-generator/templates" `
          -Destination "./${VERSION}/Linux Backend/Kubernetes/Deployment/Yaml-Generator/" -Recurse
#Copy common deployments
Copy-Item -Path "./mtv_kubernetes_resources/backend/kubernetes/deployment/common/smb-share-pv-claim.yaml" `
          -Destination ".\${VERSION}\Linux Backend\Kubernetes\Deployment\Common\"
Copy-Item -Path "./mtv_kubernetes_resources/backend/kubernetes/deployment/common/secrets\batch-db.yaml" `
          -Destination "./${VERSION}/Linux Backend/Kubernetes/Deployment/Common/secrets"
# Copy knative helm deliverable
Invoke-WebRequest -Headers @{'X-JFrog-Art-Api'=$ARTIFACTORY_TOKEN} `
                  -Uri "https://artifactory.platformdxc-mg.com/artifactory/MetaVance-Base-Generic/knative/serving/helmfile-deliverables/knative-serving-1.21.0-operator-1.21.0.zip" `
                  -outfile "./${VERSION}/Linux Backend/Kubernetes/Deployment/Common/knative/knative.zip"
cd "./${VERSION}/Linux Backend/Kubernetes/Deployment/Common/knative/" && unzip knative.zip && rm -rf knative.zip && cd -
####################################################################################

gitClone -url "https://${GIT_USER}:${GIT_PASSWORD}@github.dxc.com/MetaVance-Base/azure_infrastructure_delivery.git" -branch "feature"
#Copy Infrastructure Example
Copy-Item -Path "./azure_infrastructure_delivery/configuration.tf", `
                "./azure_infrastructure_delivery/terraform.tfvars", `
                "./azure_infrastructure_delivery/main.tf", `
                "./azure_infrastructure_delivery/variables.tf" `
          -Destination "./${VERSION}/Optional Tools/Azure Infrastructure Example (DEV env)/"
Copy-Item -Path "./azure_infrastructure_delivery/modules" `
          -Destination "./${VERSION}/Optional Tools/Azure Infrastructure Example (DEV env)/" -Recurse
####################################################################################
#Copy Windows artifacts
gitClone -url "https://${GIT_USER}:${GIT_PASSWORD}@github.dxc.com/MetaVance-Base/ci_cd_tools.git" -branch "feature"
Copy-Item -Path "./ci_cd_tools/proxy_client/config for delta/connection-settings.ini" `
          -Destination "./${VERSION}/Windows/MtvClientProxy/connection-settings.ini"
Copy-Item -Path "./ci_cd_tools/proxy_client/MtvClientProxyInstall.ps1", `
                "./ci_cd_tools/proxy_client/MtvLogsRotate.ps1" `
          -Destination "./${VERSION}\Windows/MtvClientProxy/"
Invoke-WebRequest -Headers @{'X-JFrog-Art-Api' =$ARTIFACTORY_TOKEN} `
                  -Uri "${ARTIFACTORY_FOLDER}/MTV_Client/MTV_GUI_v.${VERSION}.zip" `
                  -outfile "./${VERSION}/Windows/MTV_GUI_v.${VERSION}.zip"
Invoke-WebRequest -Headers @{'X-JFrog-Art-Api'=$ARTIFACTORY_TOKEN} `
                  -Uri "${ARTIFACTORY_FOLDER}/backend/MtvClientProxy/MtvClientProxy-v.${VERSION}.zip" `
                  -outfile "./${VERSION}/Windows/MtvClientProxy/MtvClientProxy-v.${VERSION}.zip"
####################################################################################

#Copy Backend artifacts
Invoke-WebRequest -Headers @{'X-JFrog-Art-Api'=$ARTIFACTORY_TOKEN} `
                  -Uri "${ARTIFACTORY_BUILD_FOLDER}/libs-extensions.v.${VERSION}.tar.gz" `
                  -outfile "./${VERSION}/Linux Backend/Extensions/libs-extensions.v.${VERSION}.tar.gz"

Invoke-WebRequest -Headers @{'X-JFrog-Art-Api'=$ARTIFACTORY_TOKEN} `
                  -Uri "${ARTIFACTORY_BUILD_FOLDER}/BatchFileSystemP10.v.${VERSION}.zip" `
                  -outfile "./${VERSION}/Linux Backend/Batch/BatchFileSystemP10.v.${VERSION}.zip"

Get-PnPFile -Url "/sites/MTV-DXCLuxoftcollaboration/Shared Documents/General/DevOps/Release Notes/${ReleaseNotes}" `
            -Path "./${VERSION}/" -FileName "${ReleaseNotes}" -AsFile -Force
#Collect Modernization Documentation
$files =
@(
  @("/sites/MTV-DXCLuxoftcollaboration/Shared Documents/General/Architecture/Documentation/Deliverables", "MetaVance Modernization - Architecture.docx"),
  @("/sites/MTV-DXCLuxoftcollaboration/Shared Documents/General/Architecture/Documentation/Deliverables", "MetaVance Modernization - Detailed Solution Scope.docx"),
  @("/sites/MTV-DXCLuxoftcollaboration/Shared Documents/General/Architecture/Documentation/Deliverables", "MetaVance Modernization - Technology Infrastructure.docx"),
  @("/sites/MTV-DXCLuxoftcollaboration/Shared Documents/General/Architecture/Documentation/Deliverables", "MetaVance Modernization - Pre-Production and Production Support Instrumentation.docx"),
  @("/sites/MTV-DXCLuxoftcollaboration/Shared Documents/General/DevOps/Instructions", "MetaVance Modernization - Build Installation.docx"),
  @("/sites/MTV-DXCLuxoftcollaboration/Shared Documents/General/DevOps/Instructions", "MetaVance Modernization - Platform Installation.docx"),
  @("/sites/MTV-DXCLuxoftcollaboration/Shared Documents/General/Requirements/NFR/Deliverables", "MetaVance Modernization - Log Requirements.docx"),
  @("/sites/MTV-DXCLuxoftcollaboration/Shared Documents/General/Requirements/NFR/Deliverables", "MetaVance Modernization - Non-Functional Requirements.docx"),
  @("/sites/MTV-DXCLuxoftcollaboration/Shared Documents/General/Requirements/Batch/Description", "MetaVance - Batch Cycle Manual.pdf"),
  @("/sites/MTV-DXCLuxoftcollaboration/Shared Documents/General/Testing/Test Documents/Test Strategy", "MetaVance Modernization - Construction and Test Strategy.docx"),
  @("/sites/MTV-DXCLuxoftcollaboration/Shared Documents/General/Testing/Test Documents/Test Strategy", "MTV Helm and Knative Operator - Test Strategy.docx"),
  @("/sites/MTV-DXCLuxoftcollaboration/Shared Documents/General/Testing/Test Documents/Automation", "MetaVance Modernization - Deployment instructions for test automation framework.docx"),
  @("/sites/MTV-DXCLuxoftcollaboration/Shared Documents/General/Testing/Test Documents/Test Reports/Functional Test Reports", "MetaVance Modernization - Functional Test Report v.${VERSION}.xlsx"),
  @("/sites/MTV-DXCLuxoftcollaboration/Shared Documents/General/Testing/Test Documents/Test Reports/Non-Functional Test Reports", "MetaVance Modernization - Non-Functional Test Report v.${VERSION}.docx"),
  @("/sites/MTV-DXCLuxoftcollaboration/Shared Documents/General/Testing/Test Documents/Test Plan", "MetaVance Modernization - Test plan Sprint 25.xlsx")
)
Foreach ($file in $files) {
  Get-PnPFile -Url "$($file[0])/$($file[1])" `
              -Path "./${VERSION}/Modernization Documentation" -FileName $file[1] -AsFile -Force
}
#Collect Testing\Test Cases
$files = @("MTV API - Test cases.xlsx",
           "MTV GUI - Test cases.xlsx",
           "MTV Batch - Test cases.xlsx",
           "MTV Extensions - Test cases.xlsx",
           "MTV GUI API - Test cases.xlsx",
           "MTV MQ Test cases.xlsx")
$filePath = "/sites/MTV-DXCLuxoftcollaboration/Shared Documents/General/Testing/Test Documents/Test Cases"
Foreach ($file IN $files) {
  Get-PnPFile -Url "$filePath/${file}" `
              -Path "./${VERSION}/Testing/Test Cases" -FileName $file -AsFile -Force
}
# #Make zip
Write-Output "Creating zip file MTV_v.${VERSION}.zip"
cd ${VERSION} && zip -r ../MTV_v.${VERSION}.zip * && cd -
Add-PnPFile -Path "./MTV_v.${VERSION}.zip" -Folder "Shared Documents/General/Delivery/release_${VERSION}/"
