#!/bin/bash -ex
if [ "$#" -lt 4 ]; then
    echo >&2 'Please specify 4 parameters: "build number", "environment", artifactory_username, artifactory_password'
    echo >&2 'deploy_extensions_files.sh 3.4.0-rc.2-1.0.9-feature-luxoft mtvbluhci X-JFrog-Art-Api P@$$w0rd!'
    exit
fi
echo "Build number: $1"
echo "Environment: $2"
echo "Artifactory_user: $3"
echo "Downloading artifacts"
export HTTPS_PROXY="http://proxy-2-emea.svcs.entsvcs.com:8088"
if [[ -f "extensions/$1/ews-share.tar.gz" ]];
then
    echo "Deploy ews-share from existing file extensions/$1/ews-share.tar.gz"
else
    echo "File extensions/$1/ews-share.tar.gz does not exist, pulling it from artifactory"
	mkdir -p extensions/$1 && cd extensions/$1
    curl --fail -H "${3}:${4}" -O "https://artifactory.luxoft.com/ddmtv-generic/builds/v.$1/ews-share.tar.gz"
	cd -
fi

unset HTTPS_PROXY
if [[ -f "extensions/$1/ews-share.tar.gz" ]];
then
    echo "Artifacts downloaded, successful"
else
    echo "Problems downloading artifacts, try again later"
    exit
fi

EWS_FILES_DIR=/f/$2

if [[ -d ${EWS_FILES_DIR} ]]
then
    rm -rf ${EWS_FILES_DIR}/*
fi
echo "Cleanup complete"
echo "Starting deploy"
cd extensions/$1
tar --strip-components=2 -zxvf ews-share.tar.gz --directory ${EWS_FILES_DIR}/
echo "Deploy complete"
