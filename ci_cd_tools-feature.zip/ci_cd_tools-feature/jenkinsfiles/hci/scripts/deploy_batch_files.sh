#!/bin/bash
if [ "$#" -lt 6 ]; then
    echo >&2 'Please specify 6 parameters: build number, environment, git_username, git_password, artifactory_username, artifactory_password'
    echo >&2 'deploy_batch_files.sh 61.10 mtvbluhci svc_ddmtv_cicd P@$$w0rd! X-JFrog-Art-Api P@$$w0rd!'
    exit
fi
build_number=$1
echo "Build number: $build_number"
environment=$2
echo "Environment: $environment"
git_user=$3
echo "GIT_user: $git_user"
git_password=$4
artifactory_user=$5
echo "Artifactory_user: $artifactory_user"
artifactory_password=$6
echo "Downloading artifacts"
export HTTPS_PROXY="http://proxy-2-emea.svcs.entsvcs.com:8088"
if [[ -f BatchFileSystemP10.v.$build_number.zip ]];
then
    echo "Deploy batch fs from existing file BatchFileSystemP10.v.$build_number.zip"
else
    echo "File BatchFileSystemP10.v.$build_number.zip does not exist, pulling it from artifactory"
    curl -H "${artifactory_user}:${artifactory_password}" -O "https://artifactory.luxoft.com/ddmtv-generic/builds/v.$build_number/BatchFileSystemP10.v.$build_number.zip"
fi
if [[ -d testing_artifacts ]];
then
    cd testing_artifacts
    git checkout development
    git pull
    cd ..
else
    git clone https://$git_user:$git_password@luxproject.luxoft.com/stash/scm/ddmtv/testing_artifacts.git
fi
unset HTTPS_PROXY
if [[ -d testing_artifacts ]] && [[ -f BatchFileSystemP10.v.$build_number.zip ]];
then
    echo "Artifacts downloaded, successful"
else
    echo "Problems downloading artifacts, try again later"
    exit
fi

BATCH_FILES_DIR=/f/$environment

if [[ -d ${BATCH_FILES_DIR} ]]
then
    rm -rf ${BATCH_FILES_DIR}/batch/{userctli,datain}
    rm -rf ${BATCH_FILES_DIR}/{bin,common,lib,sysin,userctli}
fi
echo "Cleanup complete"
echo "Starting deploy"
rm -rf m210 && unzip -o BatchFileSystemP10.v.$build_number.zip && cp -rfvp m210/* ${BATCH_FILES_DIR}/ && rm -rf m210
cp -rv ./testing_artifacts/application/batch/datain ${BATCH_FILES_DIR}/batch
cp -rv ${BATCH_FILES_DIR}/userctli/* ${BATCH_FILES_DIR}/batch/userctli/
echo "Deploy complete"
