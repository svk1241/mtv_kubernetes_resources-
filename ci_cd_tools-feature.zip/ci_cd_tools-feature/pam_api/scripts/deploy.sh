#!/bin/bash -ex

version="$1"
environments=$2
branch=$3
cluster=$4
service_name=$5
echo "Version: $version"
echo "Environments: $environments"
echo "Branch: $branch"
echo "Cluster: $cluster"
#DST repo
project_url="https://${BB_USER}:${BB_PASSWORD}@luxproject.luxoft.com/stash/scm/ddmtv/mtv_pam_business_service_environments.git"
project_folder="${service_name}_environments"
#SRC repo
helm_project_url="https://${BB_USER}:${BB_PASSWORD}@luxproject.luxoft.com/stash/scm/ddmtv/mtv_pam_business_service_helm_chart.git"
helm_project_folder="${service_name}_helm_chart"
helm_project_branch="master"
git config --global user.name "ddmtv_service_account"
git config --global user.email "ddmtv_service_account@luxoft.com"

git clone ${project_url} -b ${branch} ${project_folder}
git clone ${helm_project_url} -b ${helm_project_branch} ${helm_project_folder}
cd ${project_folder}

for env in ${environments//,/ }
do
    echo "Updating: $env"
    mkdir -p ./$cluster/$env/charts && cp -rf ../${helm_project_folder}/${service_name} ./$cluster/$env/charts/
    rm -rf ./$cluster/$env/charts/${service_name}/conf/$env/*
    # cp -rf ./$cluster/$env/conf ./$cluster/$env/charts/${service_name}/
    sed -i "s/deployApplication: false/deployApplication: true/" ./$cluster/$env/values.yaml
    sed -i "s/tag: \".*\"/tag: \"$version\"/" ./$cluster/$env/values.yaml
done

git add .
git status
if ! git diff-index --quiet HEAD;
then
    git commit -m "[Jenkins]::[CI/CD]: Install ${service_name} service ${version}, cluster: ${cluster}, envs: ${environments}"
    git push
else
    echo "No changes"
fi
