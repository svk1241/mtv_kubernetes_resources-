resource_location   = "Central US"
resource_group_name = "rg-observability-ddmtv-2254"
workspace = {
  name              = "ws-log-analytics-observability-ddmtv-2254",
  sku               = "PerGB2018",
  retention_in_days = 30,
  daily_cap         = 250
}
aks_clusters = {
  mtvbluonlhcicluster = "/subscriptions/e09a8dd5-6f50-4718-a54a-cc31913b6d2b/resourceGroups/Metavance_3.0_HCI/providers/Microsoft.Kubernetes/connectedClusters/mtvbluonlhcicluster"
  mtvgrnonlhcicluster = "/subscriptions/e09a8dd5-6f50-4718-a54a-cc31913b6d2b/resourceGroups/Metavance_3.0_HCI/providers/Microsoft.Kubernetes/connectedClusters/mtvgrnonlhcicluster"
}
app_insights = {
  name              = "app-insights-observability-ddmtv-2254",
  retention_in_days = 30,
}
aks_cluster_action_group = {
  name       = "mtv-aks-cluster-notification"
  short_name = "mtv-aks-alrt"
  email_receivers = {
    Sergey_Kiyan = "sergey.s.kiyan@dxc.com"
    Testing_Team = "Lux-prj-MTV_Test@dxc.com"
  }
}
mtv_backend_action_group = {
  name       = "mtv-backend-notification"
  short_name = "mtv-bke-alrt"
  email_receivers = {
    Sergey_Kiyan = "sergey.s.kiyan@dxc.com"
    Testing_Team = "Lux-prj-MTV_Test@dxc.com"
  }
}
online_namespace = "ddhcionline"
batch_namespace  = "ddhcibatch"

collect_client_proxy_logs = false

client_proxy_machines = {
  usplsvulm1058 = "Metavance_3.0_HCI"
}

client_proxy_agent_settings = "{\"proxy\" : {\"mode\" : \"application\", \"address\" : \"http://proxy-nasa.svcs.entsvcs.com:8088\", \"auth\" : false}}"

client_proxy_logs_workspace = {
  name                = "ws-client-proxy-mtvacc-756"
  resource_group_name = "rg-client-proxy-mtvacc-756"
  id                  = "/subscriptions/e09a8dd5-6f50-4718-a54a-cc31913b6d2b/resourceGroups/rg-client-proxy-mtvacc-756/providers/Microsoft.OperationalInsights/workspaces/ws-client-proxy-mtvacc-756"
}

client_proxy_log_table_name = "CLIENT_PROXY_CL"

client_proxy_file_patterns = [
  "C:\\tmp\\HTTPS-Proxy-MTV-7001\\*.log"
]
