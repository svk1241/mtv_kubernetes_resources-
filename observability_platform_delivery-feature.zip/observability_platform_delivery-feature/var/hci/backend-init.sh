terraform init -reconfigure \
               -backend-config="resource_group_name=DefaultResourceGroup-CUS" \
               -backend-config="storage_account_name=mtvhciinfrastructure" \
               -backend-config="container_name=tfstate" \
               -backend-config="key=observability.terraform.tfstate"
