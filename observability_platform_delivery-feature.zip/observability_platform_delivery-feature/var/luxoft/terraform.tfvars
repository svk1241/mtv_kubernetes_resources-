resource_location   = "East US"
resource_group_name = "rg-observability-ddmtv-2254"

workspace = {
  name              = "ws-log-analytics-observability-ddmtv-2254",
  sku               = "PerGB2018",
  retention_in_days = 30,
  daily_cap         = 150
}

aks_clusters = {
  cluster-aks002-eastus-private = "/subscriptions/d705f4d8-7a99-4443-b7df-67187358521f/resourceGroups/rg-spoke-aks001-eastus-private/providers/Microsoft.ContainerService/managedClusters/cluster-aks002-eastus-private"
  cluster-aks003-eastus-private = "/subscriptions/d705f4d8-7a99-4443-b7df-67187358521f/resourceGroups/rg-spoke-aks001-eastus-private/providers/Microsoft.ContainerService/managedClusters/cluster-aks003-eastus-private"
}

app_insights = {
  name              = "app-insights-observability-ddmtv-2254",
  retention_in_days = 30,
}

aks_cluster_action_group = {
  name       = "mtv-aks-cluster-notification"
  short_name = "mtv-aks-alrt"
  email_receivers = {
    Danil_Dyagilets = "danil.dyagilets2@dxc.com"
    Sergey_Kiyan    = "sergey.s.kiyan@dxc.com"
    Testing_Team    = "Lux-prj-MTV_Test@dxc.com"
  }
}

mtv_backend_action_group = {
  name       = "mtv-backend-cluster-notification"
  short_name = "mtv-bke-alrt"
  email_receivers = {
    Danil_Dyagilets = "danil.dyagilets2@dxc.com"
    Sergey_Kiyan    = "sergey.s.kiyan@dxc.com"
    Testing_Team    = "Lux-prj-MTV_Test@dxc.com"
  }
}
online_namespace = "online-concurrency"
batch_namespace  = "batch-concurrency"
cluster_type     = "microsoft.containerservice/managedclusters"
create_alerts    = false
