terraform init -reconfigure \
               -backend-config="resource_group_name=rg-service-global" \
               -backend-config="storage_account_name=deltadentalmtv" \
               -backend-config="container_name=tfstate" \
               -backend-config="key=observability.terraform.tfstate"
