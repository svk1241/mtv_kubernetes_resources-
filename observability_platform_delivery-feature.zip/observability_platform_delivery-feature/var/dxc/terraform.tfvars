resource_location   = "Central US"
resource_group_name = "rg-observability-dxccloud"

workspace = {
  name              = "ws-log-analytics-observability-dxccloud",
  sku               = "PerGB2018",
  retention_in_days = 30,
  daily_cap         = 150
}

aks_clusters = {
  mtv-aks-dev-cluster  = "/subscriptions/e09a8dd5-6f50-4718-a54a-cc31913b6d2b/resourceGroups/metavance3.0-resources/providers/Microsoft.ContainerService/managedClusters/mtv-aks-dev-cluster"
  mtv-aks-dev2-cluster = "/subscriptions/e09a8dd5-6f50-4718-a54a-cc31913b6d2b/resourceGroups/metavance3.0-resources/providers/Microsoft.ContainerService/managedClusters/mtv-aks-dev2-cluster"
}

app_insights = {
  name              = "app-insights-observability-dxccloud",
  retention_in_days = 30,
}

aks_cluster_action_group = {
  name       = "mtv-dxc-cluster-notification"
  short_name = "mtv-dxc-alrt"
  email_receivers = {
    Gyan_Kumar = "gkumar22@dxc.com"
    Gayathri = "gayathri.d2@dxc.com"
    Chourasia_Gourav = "gourav.chourasia@dxc.com"
    Sirangu_Sivaramakrishna = "s.sirangu@dxc.com"
    Sridharan_Rangarajan = "Rangarajan.Sridharan@dxc.com"
    Aulakh_Ramandeep_Singh = "ramandeep.aulakh@dxc.com"
  }
}

mtv_backend_action_group = {
  name       = "mtv-dxc-backend-cluster-notification"
  short_name = "mtv-dxc-balt"
  email_receivers = {
    Gyan_Kumar = "gkumar22@dxc.com"
    Gayathri   = "gayathri.d2@dxc.com"
    Chourasia_Gourav = "gourav.chourasia@dxc.com"
    Sirangu_Sivaramakrishna = "s.sirangu@dxc.com"
    Sridharan_Rangarajan = "Rangarajan.Sridharan@dxc.com"
    Aulakh_Ramandeep_Singh = "ramandeep.aulakh@dxc.com"
  }
}

online_namespace = "online"
batch_namespace  = "batch"
cluster_type     = "microsoft.containerservice/managedclusters"
