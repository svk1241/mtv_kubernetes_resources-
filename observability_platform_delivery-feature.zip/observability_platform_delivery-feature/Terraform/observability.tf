resource "azurerm_resource_group" "main_rg" {
  name     = var.resource_group_name
  location = var.resource_location
}

resource "azurerm_log_analytics_workspace" "workspace" {
  count               = var.existing_workspace_id == "" ? 1 : 0
  name                = var.workspace.name
  location            = var.resource_location
  resource_group_name = azurerm_resource_group.main_rg.name
  sku                 = var.workspace.sku
  retention_in_days   = var.workspace.retention_in_days
  daily_quota_gb      = var.workspace.daily_cap
}

resource "azurerm_application_insights" "app_insights" {
  name                = var.app_insights.name
  location            = var.resource_location
  resource_group_name = azurerm_resource_group.main_rg.name
  workspace_id        = var.existing_workspace_id == "" ? azurerm_log_analytics_workspace.workspace[0].id : var.existing_workspace_id
  application_type    = "other"
  retention_in_days   = var.app_insights.retention_in_days
}

module "aks_cluster_action_group" {
  count                   = var.create_alerts && var.existing_aks_cluster_action_group_id == "" ? 1 : 0
  source                  = "./modules/azure_monitor_action_groups"
  resource_group_name     = azurerm_resource_group.main_rg.name
  action_group_name       = var.aks_cluster_action_group.name
  action_group_short_name = var.aks_cluster_action_group.short_name
  email_receivers         = var.aks_cluster_action_group.email_receivers
}

module "mtv_backend_action_group" {
  count                   = var.create_alerts && var.existing_mtv_backend_action_group_id == "" ? 1 : 0
  source                  = "./modules/azure_monitor_action_groups"
  resource_group_name     = azurerm_resource_group.main_rg.name
  action_group_name       = var.mtv_backend_action_group.name
  action_group_short_name = var.mtv_backend_action_group.short_name
  email_receivers         = var.mtv_backend_action_group.email_receivers
}

module "azure_monitor_alert_rules" {
  count                       = var.create_alerts ? 1 : 0
  source                      = "./modules/azure_monitor_alert_rules"
  resource_group_name         = azurerm_resource_group.main_rg.name
  location                    = var.resource_location
  aks_clusters                = var.aks_clusters
  aks_cluster_action_group_id = var.existing_aks_cluster_action_group_id == "" ? module.aks_cluster_action_group[0].azure_monitor_action_group_id : var.existing_aks_cluster_action_group_id
  log_analytics_workspace_id  = var.existing_workspace_id == "" ? azurerm_log_analytics_workspace.workspace[0].id : var.existing_workspace_id
  app_insights_id             = azurerm_application_insights.app_insights.id
  mtv_backend_action_group_id = var.existing_mtv_backend_action_group_id == "" ? module.mtv_backend_action_group[0].azure_monitor_action_group_id : var.existing_mtv_backend_action_group_id
  cluster_type                = var.cluster_type
  online_namespace            = var.online_namespace
  batch_namespace             = var.batch_namespace
}

module "azure_monitor_workbooks" {
  source              = "./modules/azure_monitor_workbooks"
  resource_group_name = azurerm_resource_group.main_rg.name
  location            = azurerm_resource_group.main_rg.location
  workspace_id        = var.existing_workspace_id == "" ? azurerm_log_analytics_workspace.workspace[0].id : var.existing_workspace_id
  aks_clusters        = var.aks_clusters
  online_namespace    = var.online_namespace
  cluster_type        = var.cluster_type
}

module "azure_monitor_query_packs" {
  count               = var.create_query_packs ? 1 : 0
  source              = "./modules/azure_monitor_query_packs"
  resource_group_name = azurerm_resource_group.main_rg.name
  location            = azurerm_resource_group.main_rg.location
  aks_clusters        = var.aks_clusters
  online_namespace    = var.online_namespace
  cluster_type        = var.cluster_type
}

module "azure_monitor_client_data_collection" {
  count                 = var.collect_client_proxy_logs ? 1 : 0
  source                = "./modules/azure_monitor_client_data_collection"
  location              = var.resource_location
  client_proxy_machines = var.client_proxy_machines
  workspace             = var.client_proxy_logs_workspace
  table_name            = var.client_proxy_log_table_name
  file_patterns         = var.client_proxy_file_patterns
  agent_settings        = var.client_proxy_agent_settings
}
