variable "client_proxy_machines" {
  type        = map(string)
  description = "Azure Arc connected machines to deploy Azure Monitor Agent(AMA) map name to resource group"
}

variable "agent_settings" {
  type        = string
  default     = null
  description = "Optional settings to configure Azure Monitor Agents, ex. Proxy settimgs"
}

variable "location" {
  description = "Location of Client Proxy machines and data collection resources"
  type        = string
}

variable "workspace" {
  description = "Log Analytics Workspace for Client Proxy details"
  type = object({
    name                = string
    resource_group_name = string
    id                  = string
  })
}

variable "table_name" {
  description = "Name of table to upload ClientProxy logs"
  type        = string
}

variable "file_patterns" {
  description = "List of file patterns which will be used to collect logs from machines"
  type        = list(string)
}
