resource "azurerm_monitor_data_collection_endpoint" "client_proxy_endpoint" {
  resource_group_name           = var.workspace.resource_group_name
  location                      = var.location
  name                          = "${var.workspace.name}-dce"
  public_network_access_enabled = true
  description                   = "Endpoint to collect logs from Client Proxy machines in ${var.location} region to ${var.workspace.name} log analytics workspace"
}

resource "azurerm_monitor_data_collection_rule_association" "client_proxy_machine_endpoint_association" {
  for_each                    = data.azurerm_arc_machine.client_proxy_machine
  target_resource_id          = data.azurerm_arc_machine.client_proxy_machine[each.key].id
  data_collection_endpoint_id = azurerm_monitor_data_collection_endpoint.client_proxy_endpoint.id
  description                 = "Associates ${data.azurerm_arc_machine.client_proxy_machine[each.key].name} machine with ${azurerm_monitor_data_collection_endpoint.client_proxy_endpoint.name} endpoint"
}

resource "azurerm_monitor_data_collection_rule" "client_proxy_rule" {
  resource_group_name         = var.workspace.resource_group_name
  location                    = var.location
  name                        = "${var.workspace.name}-dcr"
  data_collection_endpoint_id = azurerm_monitor_data_collection_endpoint.client_proxy_endpoint.id
  description                 = "Rule to collect logs from Client Proxy machines in ${var.location} region to ${var.table_name} table of ${var.workspace.name} log analytics workspace"

  stream_declaration {
    stream_name = "Custom-Text-${var.table_name}"
    column {
      name = "TimeGenerated"
      type = "datetime"
    }
    column {
      name = "RawData"
      type = "string"
    }
  }

  data_sources {
    log_file {
      streams       = ["Custom-Text-${var.table_name}"]
      file_patterns = var.file_patterns
      format        = "text"
      settings {
        text {
          record_start_timestamp_format = "ISO 8601"
        }
      }
      name = "Custom-Text-${var.table_name}"
    }
  }

  destinations {
    log_analytics {
      workspace_resource_id = var.workspace.id
      name                  = "la-${var.workspace.name}"
    }
  }

  data_flow {
    streams       = ["Custom-Text-${var.table_name}"]
    destinations  = ["la-${var.workspace.name}"]
    transform_kql = "source"
    output_stream = "Custom-${var.table_name}"
  }

  depends_on = [
    azapi_resource.client_proxy_log_table
  ]
}

resource "azurerm_monitor_data_collection_rule_association" "client_proxy_machine_rule_association" {
  for_each                = data.azurerm_arc_machine.client_proxy_machine
  name                    = "${data.azurerm_arc_machine.client_proxy_machine[each.key].name}-${azurerm_monitor_data_collection_rule.client_proxy_rule.name}-association"
  target_resource_id      = data.azurerm_arc_machine.client_proxy_machine[each.key].id
  data_collection_rule_id = azurerm_monitor_data_collection_rule.client_proxy_rule.id
  description             = "Associates ${data.azurerm_arc_machine.client_proxy_machine[each.key].name} machine with ${azurerm_monitor_data_collection_rule.client_proxy_rule.name} rule"
}
