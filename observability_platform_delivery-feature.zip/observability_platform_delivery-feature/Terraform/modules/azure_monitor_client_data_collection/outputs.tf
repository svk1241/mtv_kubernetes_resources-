output "client_proxy_machine_ama_agent_ids" {
  value = [for agent in azurerm_arc_machine_extension.client_proxy_machine_ama_agent : agent.id]
}

output "data_collection_endpoint_id" {
  value = azurerm_monitor_data_collection_endpoint.client_proxy_endpoint.id
}

output "data_collection_endpoint_association_ids" {
  value = [for association in azurerm_monitor_data_collection_rule_association.client_proxy_machine_endpoint_association : association.id]
}

output "data_collection_rule_id" {
  value = azurerm_monitor_data_collection_rule.client_proxy_rule.id
}

output "data_collection_rule_association_ids" {
  value = [for association in azurerm_monitor_data_collection_rule_association.client_proxy_machine_rule_association : association.id]
}
