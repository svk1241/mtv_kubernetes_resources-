resource "azapi_resource" "client_proxy_log_table" {
  type      = "microsoft.operationalinsights/workspaces/tables@2022-10-01"
  name      = var.table_name
  parent_id = var.workspace.id

  body = jsonencode(
    {
      "properties" : {
        "schema" : {
          "name" : var.table_name,
          "columns" : [
            {
              "name" : "TimeGenerated",
              "type" : "DateTime"
            },
            {
              "name" : "RawData",
              "type" : "String"
            }
          ]
        },
        "retentionInDays" : 30,
        "totalRetentionInDays" : 30,
        "plan" : "Analytics"
      }
    }
  )
}
