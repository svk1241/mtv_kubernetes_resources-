data "azurerm_arc_machine" "client_proxy_machine" {
  for_each            = var.client_proxy_machines
  name                = each.key
  resource_group_name = each.value
}

resource "azurerm_arc_machine_extension" "client_proxy_machine_ama_agent" {
  for_each                  = data.azurerm_arc_machine.client_proxy_machine
  name                      = "AzureMonitorWindowsAgent"
  publisher                 = "Microsoft.Azure.Monitor"
  type                      = "AzureMonitorWindowsAgent"
  arc_machine_id            = data.azurerm_arc_machine.client_proxy_machine[each.key].id
  location                  = var.location
  automatic_upgrade_enabled = true
  settings                  = var.agent_settings
}
