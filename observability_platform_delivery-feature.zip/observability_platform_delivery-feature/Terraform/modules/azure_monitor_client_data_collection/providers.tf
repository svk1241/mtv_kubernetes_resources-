terraform {
  required_version = ">= 1.2.0, < 2.0.0"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 3.15.0, < 4.0.0"
    }
    azapi = {
      source  = "azure/azapi"
      version = ">= 1.10.0, < 2.0.0"
    }
  }
}
