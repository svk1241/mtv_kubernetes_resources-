output "mtv_transactions_workbook_id" {
  value = azurerm_application_insights_workbook.mtv_transactions.id
}

output "mtv_transaction_trends_workbook_id" {
  value = azurerm_application_insights_workbook.mtv_transaction_trends.id
}

output "aks_cluster_metrics_workbook_ids" {
  value = [for workbook in azurerm_application_insights_workbook.aks_cluster : workbook.id]
}
