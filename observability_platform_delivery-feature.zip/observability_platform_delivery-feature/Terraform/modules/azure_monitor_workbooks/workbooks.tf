resource "random_uuid" "mtv_transactions" {
}

resource "azurerm_application_insights_workbook" "mtv_transactions" {
  resource_group_name = var.resource_group_name
  location            = var.location
  name                = random_uuid.mtv_transactions.result

  tags = {
    "Observability platform" = "{{ development }}"
  }

  display_name = "MTV_transactions"
  data_json = replace(
    replace(
      replace(
        file(
          "${var.workbook_templates_path}mtv_transactions_template.workbook"
        ), "{{ log_analytics_workspace_id }}", "${var.workspace_id}"
      ), "{{ online_namespace }}", "${var.online_namespace}"
    ), "{{ aks_cluster_name }}", keys(var.aks_clusters)[0]
  )
  source_id = lower(var.workspace_id)
}

resource "random_uuid" "mtv_transaction_trends" {
}

resource "azurerm_application_insights_workbook" "mtv_transaction_trends" {
  resource_group_name = var.resource_group_name
  location            = var.location
  name                = random_uuid.mtv_transaction_trends.result

  tags = {
    "Observability platform" = "{{ development }}"
  }

  display_name = "MTV_transaction_trends"
  data_json = replace(
    replace(
      replace(
        file(
          "${var.workbook_templates_path}mtv_transaction_trends_template.workbook"
        ), "{{ log_analytics_workspace_id }}", "${var.workspace_id}"
      ), "{{ online_namespace }}", "${var.online_namespace}"
    ), "{{ aks_cluster_name }}", keys(var.aks_clusters)[0]
  )
  source_id = lower(var.workspace_id)
}

resource "random_uuid" "aks_cluster" {
  for_each = var.aks_clusters
}

resource "azurerm_application_insights_workbook" "aks_cluster" {
  for_each            = var.aks_clusters
  resource_group_name = var.resource_group_name
  location            = var.location
  name                = random_uuid.aks_cluster[each.key].result

  tags = {
    "Observability platform" = "{{ development }}"
  }

  display_name = "${each.key}-metrics"
  data_json = replace(
    replace(
      file("${var.workbook_templates_path}aks_cluster_template.workbook"), "{{ aks_cluster_id }}", each.value
    ), "{{ cluster_type }}", "${var.cluster_type}"
  )
}
