variable "resource_group_name" {
  description = "Name of resource group to create workbooks"
  type        = string
}

variable "location" {
  description = "Location in which to create workbooks"
  type        = string
}

variable "workbook_templates_path" {
  description = "Path to a folder with workbook templates source code in JSON format"
  type        = string
  default     = "./data/azure_monitor_workbook_templates/"
}

variable "workspace_id" {
  description = "ID of log analytics workspace"
  type        = string
}

variable "aks_clusters" {
  description = "AKS clusters to generate dashboard mappig cluster name to cluster ID"
  type        = map(string)
}

variable "online_namespace" {
  description = "Name of namespace where online pods are running"
  type        = string
}

variable "cluster_type" {
  description = "Type of Kubernetes cluster Connected for HCI and Managed for AKS"
  type        = string
  default     = "microsoft.kubernetes/connectedclusters"
}
