terraform {
  required_version = ">= 1.2.0, < 2.0.0"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 3.15.0, < 4.0.0"
    }
    random = {
      source  = "hashicorp/random"
      version = ">= 3.4.0, < 4.0.0"
    }
  }
}
