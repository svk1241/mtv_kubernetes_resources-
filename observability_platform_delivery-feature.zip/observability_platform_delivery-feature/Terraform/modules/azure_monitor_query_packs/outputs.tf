output "query_pack_ids" {
  value = [for query_pack in azurerm_log_analytics_query_pack.mtv_useful_queries : query_pack.id]
}

output "online_transactions_distribution_with_average_query_pack_query_ids" {
  value = [for query_pack_query in azurerm_log_analytics_query_pack_query.online_transactions_distribution_with_average : query_pack_query.id]
}

output "online_transaction_min_max_average_query_pack_query_ids" {
  value = [for query_pack_query in azurerm_log_analytics_query_pack_query.online_transaction_min_max_average : query_pack_query.id]
}

output "extensions_ddext1_and_ddext2_correct_parsing_query_pack_query_ids" {
  value = [for query_pack_query in azurerm_log_analytics_query_pack_query.extensions_ddext1_and_ddext2_correct_parsing : query_pack_query.id]
}

output "count_pod_in_each_status_for_super_service_query_pack_query_ids" {
  value = [for query_pack_query in azurerm_log_analytics_query_pack_query.count_pod_in_each_status_for_super_service : query_pack_query.id]
}

output "get_only_really_failed_transactions_query_pack_query_ids" {
  value = [for query_pack_query in azurerm_log_analytics_query_pack_query.get_only_really_failed_transactions : query_pack_query.id]
}

output "all_transactions_with_failed_percent_query_pack_query_ids" {
  value = [for query_pack_query in azurerm_log_analytics_query_pack_query.all_transactions_with_failed_percent : query_pack_query.id]
}

output "difference_for_transactions_elapsed_time_query_pack_query_ids" {
  value = [for query_pack_query in azurerm_log_analytics_query_pack_query.difference_for_transactions_elapsed_time : query_pack_query.id]
}
