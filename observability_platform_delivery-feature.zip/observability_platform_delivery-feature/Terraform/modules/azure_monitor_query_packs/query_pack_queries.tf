resource "azurerm_log_analytics_query_pack" "mtv_useful_queries" {
  for_each            = var.aks_clusters
  resource_group_name = var.resource_group_name
  location            = var.location
  name                = "${each.key}-mtv-useful-queries"

  tags = {
    "Observability platform" = "{{ development }}"
  }
}

resource "random_uuid" "online_transactions_distribution_with_average" {
  for_each = var.aks_clusters
}

resource "azurerm_log_analytics_query_pack_query" "online_transactions_distribution_with_average" {
  for_each       = var.aks_clusters
  name           = random_uuid.online_transactions_distribution_with_average[each.key].result
  query_pack_id  = azurerm_log_analytics_query_pack.mtv_useful_queries[each.key].id
  display_name   = "${each.key} - Online Transactions elapsed time distribution with average"
  description    = "Query display average transaction elapsed time distribution split by buckets and highlighted average value on the same graph."
  categories     = ["applications"]
  resource_types = [var.cluster_type]

  tags = {
    "Observability platform" = "{{ development }}"
    "Topic"                  = "MTV Useful Queries"
  }

  body = <<-QUERY
  let cluster = "${each.key}";  // cluster name
  let namespace = "${var.online_namespace}";
  let threshold = 121000;
  let binSize=10;
  KubePodInventory
  | where ClusterName == cluster
  | where Namespace == namespace
  | where ContainerName endswith "https-wrapper"
  | distinct Computer, ContainerID, Namespace, ServiceName
  | join (
    ContainerLog
      | extend log = parse_json(LogEntry)
      | where log["ElapsedMs"] >= 0
      | where log["Successful"] in (dynamic(["true", "false"]))
      ) on Computer, ContainerID
  | project DurationMs = iff(toint(log["ElapsedMs"]/binSize)*binSize < threshold, tostring(toint(log["ElapsedMs"]/binSize)*binSize) , "Higher"), LocalDateTime = datetime_utc_to_local(todatetime(log["Date"]), 'US/Pacific'), toint(log["ElapsedMs"]), tostring(log["RequestId"]), tostring(log["TransactionId"]), LogEntry, tobool(log["Successful"])
  | as hint.materialized=true T
  | summarize cnt = count(DurationMs) by DurationMs
  | as hint.materialized=true S
  | union( T | summarize AvgMs = tostring(toint(avg(log_ElapsedMs))))
  | union( S | summarize maxCnt = toint(max(cnt)))
  | as hint.materialized=true U
  | union( U | summarize DurationMs = max(AvgMs), avg = max(maxCnt))
  | where not (isempty(DurationMs))
  | project DurationMs, cnt, avg
  | order by (100000000000 - toint(iff(DurationMs == "Higher", tolong(1000000000), tolong(DurationMs))))
  QUERY
}

resource "random_uuid" "online_transaction_min_max_average" {
  for_each = var.aks_clusters
}

resource "azurerm_log_analytics_query_pack_query" "online_transaction_min_max_average" {
  for_each       = var.aks_clusters
  name           = random_uuid.online_transaction_min_max_average[each.key].result
  query_pack_id  = azurerm_log_analytics_query_pack.mtv_useful_queries[each.key].id
  display_name   = "${each.key} - Online transaction Min/Max/Average on a single graph"
  description    = "Plots a graph of Minimum, Maximum and Average elapsed times of specified transaction."
  categories     = ["applications"]
  resource_types = [var.cluster_type]

  tags = {
    "Observability platform" = "{{ development }}"
    "Topic"                  = "MTV Useful Queries"
  }

  body = <<-QUERY
  let cluster = "${each.key}";  // cluster name
  let namespace = "${var.online_namespace}";
  let threshold = 121000;
  let binSize=100;
  let higher = "Higher";
  let startDate = todatetime('2023-07-15T14:45:00.0000000-07:00');
  let endDate = todatetime('2023-07-16T16:20:00.0000000-07:00');
  let timeInterval = 3m;
  let Title = strcat("[", cluster, "] ", format_datetime((datetime_utc_to_local(startDate, "US/Pacific")), "yyyy-MM-dd HH:mm"), " to ", format_datetime((datetime_utc_to_local(endDate, "US/Pacific")), "yyyy-MM-dd HH:mm"), " PT (over ", timeInterval, ")");
  KubePodInventory
  | where ClusterName == cluster
  | where Namespace == namespace | where ContainerName endswith "https-wrapper" | distinct Computer, ContainerID, Namespace, ServiceName
  | join ( ContainerLog | extend log = parse_json(LogEntry)
      | where log["ElapsedMs"] > 0 //19999 
      //| where log["ElapsedMs"] <= 50000 // filter by elapsed
      | where log["LogLevel"] == "Information"
      //| where log["Successful"] == true // get only successful
      | where log["TransactionId"]  in ("MQA8") // certain transaction
      | where todatetime(log["Date"]) between (startDate .. endDate) // time in logs
      ) on Computer, ContainerID
  | project DurationMs = iff(toint(log["ElapsedMs"]/binSize)*binSize < threshold, tostring(toint(log["ElapsedMs"]/binSize)*binSize) , higher), LocalDateTime = datetime_utc_to_local(todatetime(log["Date"]), 'US/Pacific'), toint(log["ElapsedMs"]), tostring(log["RequestId"]), tostring(log["TransactionId"]), LogEntry, tobool(log["Successful"])
  | summarize
      avg = avg(log_ElapsedMs)*1.0/1000
    , max = max(log_ElapsedMs)*1.0/1000
    , min = min(log_ElapsedMs)*1.0/1000
  by bin(todatetime(LocalDateTime), timeInterval)
  | render timechart with (xtitle="Time PT", ytitle="Duration, sec", title=Title)
  QUERY
}

resource "random_uuid" "extensions_ddext1_and_ddext2_correct_parsing" {
  for_each = var.aks_clusters
}

resource "azurerm_log_analytics_query_pack_query" "extensions_ddext1_and_ddext2_correct_parsing" {
  for_each       = var.aks_clusters
  name           = random_uuid.extensions_ddext1_and_ddext2_correct_parsing[each.key].result
  query_pack_id  = azurerm_log_analytics_query_pack.mtv_useful_queries[each.key].id
  display_name   = "${each.key} - Extensions ddext1 and ddext2 correct parsing"
  description    = "Extracts lines from ddext1/ddext2 logs for certain Claim ID removing blank lines and follow log order."
  categories     = ["applications"]
  resource_types = [var.cluster_type]

  tags = {
    "Observability platform" = "{{ development }}"
    "Topic"                  = "MTV Useful Queries"
  }

  body = <<-QUERY
  let delim1 = " ";
  let delim2 = "|";
  let results =
  ContainerLog
  | where LogEntry contains("<claim_id>2023053123SM01</claim_id>")
  | project split(LogEntry, " ")[1];
  ContainerLog
  | where LogEntry has_any(results)
  // Extract nessesary data as fields
  | extend ExtLogTimeStamp = substring(split(LogEntry, delim1)[1], 11, 26)
  | extend LogLineSeqNumber = toint(split(LogEntry, delim1)[0])
  | extend ExtLogId = split(LogEntry, delim1)[1]
  | extend LogText = split(LogEntry, delim2)[1]
  // Filter, Sort, Display
  | where LogText != " " // Optional, removing empty lines
  | order by ExtLogTimeStamp asc, LogLineSeqNumber asc
  | project ExtLogId, ExtLogTimeStamp, LogLineSeqNumber, LogText // Extended view
  //| project LogText // Just log text view
  QUERY
}

resource "random_uuid" "count_pod_in_each_status_for_super_service" {
  for_each = var.aks_clusters
}

resource "azurerm_log_analytics_query_pack_query" "count_pod_in_each_status_for_super_service" {
  for_each       = var.aks_clusters
  name           = random_uuid.count_pod_in_each_status_for_super_service[each.key].result
  query_pack_id  = azurerm_log_analytics_query_pack.mtv_useful_queries[each.key].id
  display_name   = "${each.key} - Pod count per status for each super-service"
  description    = "Returns list of super-services and number of pods in each state: running, pending, failed."
  categories     = ["applications"]
  resource_types = [var.cluster_type]

  tags = {
    "Observability platform" = "{{ development }}"
    "Topic"                  = "MTV Useful Queries"
  }

  body = <<-QUERY
  let cluster = "${each.key}";  // cluster name
  let namespace = "${var.online_namespace}";
  KubePodInventory
  | where ClusterName == cluster
  | where Namespace == namespace
  | where PodStatus in (dynamic(["Running", "Pending", "Failed"]))
  | distinct PodUid, ControllerName, PodStatus
  | summarize Running = countif(PodStatus == "Running"), Pending = countif(PodStatus == "Pending"), Failed = countif(PodStatus == "Failed") by controller = strcat_array(array_slice(split(ControllerName, "-"), 0, -4), "-")
  | sort by controller asc
  QUERY
}

resource "random_uuid" "get_only_really_failed_transactions" {
  for_each = var.aks_clusters
}

resource "azurerm_log_analytics_query_pack_query" "get_only_really_failed_transactions" {
  for_each       = var.aks_clusters
  name           = random_uuid.get_only_really_failed_transactions[each.key].result
  query_pack_id  = azurerm_log_analytics_query_pack.mtv_useful_queries[each.key].id
  display_name   = "${each.key} - Failed transactions returned to client"
  description    = "Query to get only failed transactions which never been successfully retried."
  categories     = ["applications"]
  resource_types = [var.cluster_type]

  tags = {
    "Observability platform" = "{{ development }}"
    "Topic"                  = "MTV Useful Queries"
  }

  body = <<-QUERY
  let cluster = "${each.key}";  // cluster name
  let namespace = "${var.online_namespace}";
  let ALL =
  KubePodInventory
  | where ClusterName == cluster
  | where Namespace == namespace
  | where ContainerName endswith "https-wrapper"
  | distinct Computer, ContainerID, Namespace, ServiceName
  | join ( ContainerLog | extend log = parse_json(LogEntry)
      | where log["LogLevel"] == "Information" // to keep only elapsed times, not errors (when error there are two records)
      ) on Computer, ContainerID
      | project req = log["RequestId"]
          , success = tostring(log["Successful"])
          , trid = tostring(log["TransactionId"])
          , gen = datetime_utc_to_local(todatetime(log["Date"]), "US/Pacific")
          , elapsed = toint(log["ElapsedMs"])
      ;
  ALL
  | summarize resSuccess = toboolean(max(success)), lastExecuted = max(gen), totalElapsed = sum(elapsed), cnt = count() by tostring(req), trid | where resSuccess == false
  | where totalElapsed > 100
  | project
      reqId = req, cnt
          , lastExecuted
          , trid
          , resSuccess
          , totalElapsed
  QUERY
}

resource "random_uuid" "all_transactions_with_failed_percent" {
  for_each = var.aks_clusters
}

resource "azurerm_log_analytics_query_pack_query" "all_transactions_with_failed_percent" {
  for_each       = var.aks_clusters
  name           = random_uuid.all_transactions_with_failed_percent[each.key].result
  query_pack_id  = azurerm_log_analytics_query_pack.mtv_useful_queries[each.key].id
  display_name   = "${each.key} - All transactions (with failed percent)"
  description    = "All transactions (with failed percent)"
  categories     = ["applications"]
  resource_types = [var.cluster_type]

  tags = {
    "Observability platform" = "{{ development }}"
    "Topic"                  = "MTV Useful Queries"
  }

  body = <<-QUERY
  let cluster = "${each.key}";  // cluster name
  let namespace = "${var.online_namespace}";
  let interval = 30m;
  let ALL =
  KubePodInventory
  | where ClusterName == cluster
  | where Namespace == namespace
  | where ContainerName endswith "https-wrapper"
  | distinct Computer, ContainerID, Namespace, ServiceName
  | join ( ContainerLog | extend log = parse_json(LogEntry)
    | where log["LogLevel"] == "Information" // to keep only elapsed times, not errors (when error there are two records)
    ) on Computer, ContainerID
    | project req = log["RequestId"]
        , success = toboolean(log["Successful"])
        , trid = tostring(log["TransactionId"])
        , gen = datetime_utc_to_local(todatetime(log["Date"]), "US/Pacific")
        , elapsed = toint(log["ElapsedMs"])
    ;
  let MAT = materialize(ALL);
  let failed = toscalar(MAT | where success == false | summarize count());
  let total = toscalar(MAT | summarize count());
  let minDt = toscalar(MAT | summarize min(gen));
  let maxDt = toscalar(MAT | summarize max(gen));
  MAT
  | summarize count() by bin(gen, interval) | render timechart with (title =
  strcat( " Total ", total, " failed ", failed, " (",round(failed * 100.0 / total, 2),"%)"
  ," from ", format_datetime(minDt, "yyyy-MM-dd HH:mm:ss")
  ," to ", format_datetime(maxDt, "yyyy-MM-dd HH:mm:ss")
  ," generated at ", format_datetime(datetime_utc_to_local(now(), "US/Pacific"), "yyyy-MM-dd HH:mm:ss")
  )
  )
  QUERY
}

resource "random_uuid" "difference_for_transactions_elapsed_time" {
  for_each = var.aks_clusters
}

resource "azurerm_log_analytics_query_pack_query" "difference_for_transactions_elapsed_time" {
  for_each       = var.aks_clusters
  name           = random_uuid.difference_for_transactions_elapsed_time[each.key].result
  query_pack_id  = azurerm_log_analytics_query_pack.mtv_useful_queries[each.key].id
  display_name   = "${each.key} - Difference for transactions elapsed time"
  description    = "Difference for transactions elapsed time (in %) from day to day (or interval average vs interval average)"
  categories     = ["applications"]
  resource_types = [var.cluster_type]

  tags = {
    "Observability platform" = "{{ development }}"
    "Topic"                  = "MTV Useful Queries"
  }

  body = <<-QUERY
  let cluster = "${each.key}";  // cluster name
  let namespace = "${var.online_namespace}";
  let observedTransactions = dynamic(["AQLP", "C201", "D252", "D401", "D402", "D871", "DAA1", "DSM3", "DWD7", "M241", "M7PM",
    "MBP4", "MCM2", "MCT2", "MGM3", "MGR2", "MMMF", "MNU3", "MPY1", "MQA8", "MQM3", "MRM8", "MVY2",
    "PCLQ", "PM61", "PPLQ", "RBS2", "RIM2", "RUM2", "U18P", "VCM4", "X10P", "XUM3", "Y061"]);
  let firstRangeFrom = ago(1d);
  let firstRangeTo = ago(0d);
  let secondRangeFrom = ago(2d);
  let secondRangeTo = ago(1d);
  let firstRange = KubePodInventory
  | where TimeGenerated between (firstRangeFrom .. firstRangeTo)
  | where ClusterName == cluster
  | where Namespace == namespace
  | where ContainerName endswith "https-wrapper"
  | distinct Computer, ContainerID, Namespace, ServiceName
  | join (
      ContainerLog
      | where TimeGenerated between (firstRangeFrom .. firstRangeTo)
      | extend log = parse_json(LogEntry)
      | extend elapsed = toint(log["ElapsedMs"])
      | extend TransactionId = tostring(log["TransactionId"])
      | where log["Successful"] == "true"
      | where TransactionId in (observedTransactions)
      )
      on Computer, ContainerID
  | summarize firstRangeAvg = avg(elapsed) by TransactionId;
  let secondRange = KubePodInventory
  | where TimeGenerated between (secondRangeFrom .. secondRangeTo)
  | where ClusterName == cluster
  | where Namespace == namespace
  | where ContainerName endswith "https-wrapper"
  | distinct Computer, ContainerID, Namespace, ServiceName
  | join (
      ContainerLog
      | where TimeGenerated between (secondRangeFrom .. secondRangeTo)
      | extend log = parse_json(LogEntry)
      | extend elapsed = toint(log["ElapsedMs"])
      | extend TransactionId = tostring(log["TransactionId"])
      | where log["Successful"] == "true"
      | where TransactionId in (observedTransactions)
      )
      on Computer, ContainerID
  | summarize secondRangeAvg = avg(elapsed) by TransactionId;
  firstRange
  | join secondRange on TransactionId
  | extend avgPrcChange = round(((firstRangeAvg / secondRangeAvg)), 2) * 100 - 100
  | project TransactionId, firstRangeAvg, secondRangeAvg, avgPrcChange
  QUERY
}
