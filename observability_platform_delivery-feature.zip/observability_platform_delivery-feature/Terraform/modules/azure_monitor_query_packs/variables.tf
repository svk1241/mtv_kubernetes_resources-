variable "resource_group_name" {
  description = "Name of resource group to create workbooks"
  type        = string
}

variable "location" {
  description = "Location in which to create workbooks"
  type        = string
}

variable "aks_clusters" {
  description = "AKS clusters to generate dashboard mappig cluster name to cluster ID"
  type        = map(string)
}

variable "online_namespace" {
  description = "Name of namespace where online pods are running"
  type        = string
}

variable "cluster_type" {
  description = "Type of Kubernetes cluster Connected for HCI and Managed for AKS"
  type        = string
  default     = "microsoft.kubernetes/connectedclusters"
}
