output "container_cpu_threshold_violated_alert_rule_ids" {
  value = [for alert_rule in azurerm_monitor_metric_alert.container_cpu_threshold_violated : alert_rule.id]
}

output "container_memory_working_set_threshold_violated_alert_rule_ids" {
  value = [for alert_rule in azurerm_monitor_metric_alert.container_memory_working_set_threshold_violated : alert_rule.id]
}

output "node_cpu_usage_percentage_alert_rule_ids" {
  value = [for alert_rule in azurerm_monitor_metric_alert.node_cpu_usage_percentage : alert_rule.id]
}

output "node_memory_usage_percentage_rule_alert_ids" {
  value = [for alert_rule in azurerm_monitor_metric_alert.node_memory_usage_percentage : alert_rule.id]
}

output "oom_killed_pods_alert_rule_ids" {
  value = [for alert_rule in azurerm_monitor_metric_alert.oom_killed_pods : alert_rule.id]
}

output "te_restarts_alert_rule_ids" {
  value = [for alert_rule in azurerm_monitor_scheduled_query_rules_alert_v2.te_restarts : alert_rule.id]
}

output "failure_anomalies_smart_detector_alert_rule_id" {
  value = azurerm_monitor_smart_detector_alert_rule.mtv-failure-anomalies.id
}

output "request_performance_smart_detector_alert_rule_id" {
  value = azurerm_monitor_smart_detector_alert_rule.mtv-performance-degradation.id
}

output "la_ws_daily_cap_alert_rule_id" {
  value = azurerm_monitor_scheduled_query_rules_alert_v2.la_ws_daily_cap.id
}

output "failed_transactions_alert_rule_ids" {
  value = [for alert_rule in azurerm_monitor_scheduled_query_rules_alert_v2.failed_transactions : alert_rule.id]
}

output "knative_pod_count_warning_alert_rule_ids" {
  value = [for alert_rule in azurerm_monitor_scheduled_query_rules_alert_v2.knative_pod_count_warning : alert_rule.id]
}

output "knative_pod_count_critical_alert_rule_ids" {
  value = [for alert_rule in azurerm_monitor_scheduled_query_rules_alert_v2.knative_pod_count_critical : alert_rule.id]
}

output "istio_pod_count_warning_alert_rule_ids" {
  value = [for alert_rule in azurerm_monitor_scheduled_query_rules_alert_v2.istio_pod_count_warning : alert_rule.id]
}

output "istio_pod_count_critical_alert_rule_ids" {
  value = [for alert_rule in azurerm_monitor_scheduled_query_rules_alert_v2.istio_pod_count_critical : alert_rule.id]
}

output "long_550_errors_alert_rule_ids" {
  value = [for alert_rule in azurerm_monitor_scheduled_query_rules_alert_v2.long_550_errors : alert_rule.id]
}

output "subsequent_408_retries_alert_rule_ids" {
  value = [for alert_rule in azurerm_monitor_scheduled_query_rules_alert_v2.subsequent_408_retries : alert_rule.id]
}

output "online_pod_pending_alert_rule_ids" {
  value = [for alert_rule in azurerm_monitor_scheduled_query_rules_alert_v2.online_pod_pending : alert_rule.id]
}

output "batch_pod_pending_alert_rule_ids" {
  value = [for alert_rule in azurerm_monitor_scheduled_query_rules_alert_v2.batch_pod_pending : alert_rule.id]
}

output "knative_pod_pending_alert_rule_ids" {
  value = [for alert_rule in azurerm_monitor_scheduled_query_rules_alert_v2.knative_pod_pending : alert_rule.id]
}

output "istio_pod_pending_alert_rule_ids" {
  value = [for alert_rule in azurerm_monitor_scheduled_query_rules_alert_v2.istio_pod_pending : alert_rule.id]
}
