resource "azurerm_monitor_scheduled_query_rules_alert_v2" "te_restarts" {
  for_each             = var.aks_clusters
  name                 = "${each.key}-transaction-enabler-restarts-${var.online_namespace}"
  resource_group_name  = var.resource_group_name
  location             = var.location
  scopes               = [var.log_analytics_workspace_id]
  description          = "Alert indicates high volume of Transaction Enabler restarts. Refer to MetaVance Modernization - Application Runbook paragraph 2.6, MetaVance Modernization - Troubleshooting Runbook paragraph 3.1, 4.2"
  evaluation_frequency = "PT5M"

  tags = {
    "Observability platform" = "{{ development }}"
  }

  criteria {
    # Count all TE restarts in last 5 minutes
    query                   = <<-QUERY
      KubePodInventory
      | where TimeGenerated > ago(5m)
      | where ClusterName == "${each.key}"
      | where ServiceName != ""
      | where Namespace == "${var.online_namespace}"
      | where ContainerName has "transaction-enabler"
      | distinct Computer, ContainerID, ServiceName
      | join (
          ContainerLog
          | where TimeGenerated > ago(5m)
          | where LogEntry has "Restart TE was successful" or LogEntry has "Failure of restart"
          )
          on Computer, ContainerID
      QUERY
    time_aggregation_method = "Count"
    threshold               = 9
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }
  window_duration         = "PT5M"
  severity                = 2
  auto_mitigation_enabled = var.enable_auto_mitigation
  action {
    action_groups = [var.mtv_backend_action_group_id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "la_ws_daily_cap" {
  name                 = join("", [element(split("/", var.log_analytics_workspace_id), length(split("/", var.log_analytics_workspace_id)) - 1), "-daily-cap-reached"])
  resource_group_name  = var.resource_group_name
  location             = var.location
  scopes               = [var.log_analytics_workspace_id]
  description          = "Alert indicates no more data can be uploaded to log analytics workspace today due to maximum daily limit reached. Increase daily cap value."
  evaluation_frequency = "PT30M"

  tags = {
    "Observability platform" = "{{ development }}"
  }

  criteria {
    # Counts log entries which indicate daily limit reached in last 30 minutes
    query                   = <<-QUERY
      _LogOperation
      | where TimeGenerated > ago(30m)
      | where Category =~ "Ingestion"
      | where Detail contains "OverQuota"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  window_duration         = "PT30M"
  severity                = 2
  auto_mitigation_enabled = var.enable_auto_mitigation
  action {
    action_groups = var.mtv_backend_action_group_id == var.aks_cluster_action_group_id ? [var.mtv_backend_action_group_id] : [var.mtv_backend_action_group_id, var.aks_cluster_action_group_id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "failed_transactions" {
  for_each             = var.aks_clusters
  name                 = "${each.key}-failed-transactions-in-${var.online_namespace}-namespace"
  resource_group_name  = var.resource_group_name
  location             = var.location
  scopes               = [var.log_analytics_workspace_id]
  description          = "Alert indicates some Online transactions failed. Refer to MetaVance Modernization - Troubleshooting Runbook paragraph 3.1"
  evaluation_frequency = "PT10M"

  tags = {
    "Observability platform" = "{{ development }}"
  }

  criteria {
    # Count real failed transactions in last 10 minutes (Ones which were not retried)
    query                   = <<-QUERY
    KubePodInventory
    | where TimeGenerated > ago(10m)
    | where ClusterName == "${each.key}"
    | where ServiceName != ""
    | where Namespace == "${var.online_namespace}"
    | where ContainerName has "https-wrapper"
    | distinct Computer, ContainerID, ServiceName
    | join (
        ContainerLog
        | where TimeGenerated > ago(10m)
        | extend log = parse_json(LogEntry)
        | extend Successful = (log["Successful"] == "true")
        | where log["LogLevel"] == "Information"
        | where Successful or (not(Successful) and TimeGenerated < ago(2m))
        )
        on Computer, ContainerID
    | summarize Successes = countif(Successful), Failures = countif(not(Successful)) by RequestId = tostring(log["RequestId"])
    | where Successes == 0 and Failures > 0
    QUERY
    time_aggregation_method = "Count"
    threshold               = 2
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  window_duration         = "PT10M"
  severity                = 2
  auto_mitigation_enabled = var.enable_auto_mitigation
  action {
    action_groups = [var.mtv_backend_action_group_id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "knative_pod_count_warning" {
  for_each             = var.aks_clusters
  name                 = "${each.key}-knative-pod-count-below-threshold-warning"
  resource_group_name  = var.resource_group_name
  location             = var.location
  scopes               = [var.log_analytics_workspace_id]
  description          = "Alert indicates some Knative pods experience failures. Check pods status, events and logs in knative-serving namespace. Refer to MetaVance Modernization - Platform Runbook paragraph 2.4, MetaVance Modernization - Troubleshooting Runbook paragraph 4.1"
  evaluation_frequency = "PT5M"

  tags = {
    "Observability platform" = "{{ development }}"
  }

  criteria {
    # Counts number of pods in knative-serving namespace per controller and return ones which not meet expectations
    query                   = <<-QUERY
    KubePodInventory
    | where TimeGenerated > ago(3m)
    | where ClusterName == "${each.key}"
    | where Namespace == "knative-serving"
    | where PodStatus == "Running"
    | distinct PodUid, ControllerName
    | summarize count() by controller = strcat_array(array_slice(split(ControllerName, "-"), 0, -2), "-")
    | extend Ok = case(controller == "activator" and count_ < 2, false,
                       controller == "webhook" and count_ < 2, false,
                       true)
    | where not(Ok)
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }
  window_duration         = "PT5M"
  severity                = 2
  auto_mitigation_enabled = var.enable_auto_mitigation
  action {
    action_groups = var.mtv_backend_action_group_id == var.aks_cluster_action_group_id ? [var.mtv_backend_action_group_id] : [var.mtv_backend_action_group_id, var.aks_cluster_action_group_id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "knative_pod_count_critical" {
  for_each             = var.aks_clusters
  name                 = "${each.key}-knative-pod-count-below-threshold-critical"
  resource_group_name  = var.resource_group_name
  location             = var.location
  scopes               = [var.log_analytics_workspace_id]
  description          = "Alert indicates some Knative pods experience critical failures. Check pods status, events and logs in knative-serving namespace. Refer to MetaVance Modernization - Platform Runbook paragraph 2.4, MetaVance Modernization - Troubleshooting Runbook paragraph 4.1"
  evaluation_frequency = "PT5M"

  tags = {
    "Observability platform" = "{{ development }}"
  }

  criteria {
    # Counts number of pods in knative-serving namespace per controller and return ones which not meet expectations
    query                   = <<-QUERY
    KubePodInventory
    | where TimeGenerated > ago(3m)
    | where ClusterName == "${each.key}"
    | where Namespace == "knative-serving"
    | where PodStatus == "Running"
    | distinct PodUid, ControllerName
    | summarize count() by controller = strcat_array(array_slice(split(ControllerName, "-"), 0, -2), "-")
    | join kind=rightouter (
      datatable (controller: string) ["activator", "autoscaler", "controller", "net-istio-controller", "net-istio-webhook", "webhook"]
    ) on controller
    | extend Ok = case(controller == "activator" and count_ >= 1, true,
                       controller == "autoscaler" and count_ >= 1, true,
                       controller == "controller" and count_ >= 1, true,
                       controller == "net-istio-controller" and count_ >= 1, true,
                       controller == "net-istio-webhook" and count_ >= 1, true,
                       controller == "webhook" and count_ >= 1, true,
                       false)
    | where not(Ok)
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }
  window_duration         = "PT5M"
  severity                = 1
  auto_mitigation_enabled = var.enable_auto_mitigation
  action {
    action_groups = var.mtv_backend_action_group_id == var.aks_cluster_action_group_id ? [var.mtv_backend_action_group_id] : [var.mtv_backend_action_group_id, var.aks_cluster_action_group_id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "istio_pod_count_warning" {
  for_each             = var.aks_clusters
  name                 = "${each.key}-istio-pod-count-below-threshold-warning"
  resource_group_name  = var.resource_group_name
  location             = var.location
  scopes               = [var.log_analytics_workspace_id]
  description          = "Alert indicates some Istio pods experience failures. Check pods status, events and logs in istio-system namespace. Refer to MetaVance Modernization - Platform Runbook paragraph 2.4, MetaVance Modernization - Troubleshooting Runbook paragraph 4.1"
  evaluation_frequency = "PT5M"

  tags = {
    "Observability platform" = "{{ development }}"
  }

  criteria {
    # Counts number of pods in istio-system namespace per controller and return ones which not meet expectations
    query                   = <<-QUERY
    KubePodInventory
    | where TimeGenerated > ago(3m)
    | where ClusterName == "${each.key}"
    | where Namespace == "istio-system"
    | where PodStatus == "Running"
    | distinct PodUid, ControllerName
    | summarize count() by controller = strcat_array(array_slice(split(ControllerName, "-"), 0, -2), "-")
    | extend Ok = case(controller == "istio-ingressgateway" and count_ < 3, false,
                       controller == "istiod" and count_ < 3, false,
                       true)
    | where not(Ok)
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }
  window_duration         = "PT5M"
  severity                = 2
  auto_mitigation_enabled = var.enable_auto_mitigation
  action {
    action_groups = var.mtv_backend_action_group_id == var.aks_cluster_action_group_id ? [var.mtv_backend_action_group_id] : [var.mtv_backend_action_group_id, var.aks_cluster_action_group_id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "istio_pod_count_critical" {
  for_each             = var.aks_clusters
  name                 = "${each.key}-istio-pod-count-below-threshold-critical"
  resource_group_name  = var.resource_group_name
  location             = var.location
  scopes               = [var.log_analytics_workspace_id]
  description          = "Alert indicates some Istio pods experience cretical failures. Check pods status, events and logs in istio-system namespace. Refer to MetaVance Modernization - Platform Runbook paragraph 2.4, MetaVance Modernization - Troubleshooting Runbook paragraph 4.1"
  evaluation_frequency = "PT5M"

  tags = {
    "Observability platform" = "{{ development }}"
  }

  criteria {
    # Counts number of pods in knative-serving namespace per controller and return ones which not meet expectations
    query                   = <<-QUERY
    KubePodInventory
    | where TimeGenerated > ago(3m)
    | where ClusterName == "${each.key}"
    | where Namespace == "istio-system"
    | where PodStatus == "Running"
    | distinct PodUid, ControllerName
    | summarize count() by controller = strcat_array(array_slice(split(ControllerName, "-"), 0, -2), "-")
    | join kind=rightouter (
      datatable (controller: string) ["istio-ingressgateway", "istiod"]
    ) on controller
    | extend Ok = case(controller == "istio-ingressgateway" and count_ >= 1, true,
                       controller == "istiod" and count_ >= 1, true,
                       false)
    | where not(Ok)
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }
  window_duration         = "PT5M"
  severity                = 1
  auto_mitigation_enabled = var.enable_auto_mitigation
  action {
    action_groups = var.mtv_backend_action_group_id == var.aks_cluster_action_group_id ? [var.mtv_backend_action_group_id] : [var.mtv_backend_action_group_id, var.aks_cluster_action_group_id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "long_550_errors" {
  for_each             = var.aks_clusters
  name                 = "${each.key}-long-550-error-detected"
  resource_group_name  = var.resource_group_name
  location             = var.location
  scopes               = [var.log_analytics_workspace_id]
  description          = "Some pods in Online namespace experience long errors, click <View query results> to identify pod names then delete such pods using kubectl delete pod command."
  evaluation_frequency = "PT5M"

  tags = {
    "Observability platform" = "{{ development }}"
  }

  criteria {
    # Count number of 550 errors in specified namespace with ElapsedTime > 0.5 sec
    query                   = <<-QUERY
    KubePodInventory
    | where TimeGenerated > ago(10m)
    | where ClusterName == "${each.key}"
    | where ServiceName != ""
    | where Namespace == "${var.online_namespace}"
    | where ContainerName endswith "https-wrapper"
    | distinct Computer, ContainerID, Namespace, ServiceName
    | join (
        ContainerLog
        | where TimeGenerated > ago(10m)
        | extend log = parse_json(LogEntry)
        | extend HttpStatus = toint(log["HttpStatus"])
        | extend ElapsedMs = toint(log["ElapsedMs"])
        | extend Hostname = tostring(log["Hostname"])
        | where log["LogLevel"] == "Information"
        | where HttpStatus == 550
        | where ElapsedMs > 500
        )
        on Computer, ContainerID
    | summarize count() by Hostname
    | where count_ > 2
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }
  window_duration         = "PT10M"
  severity                = 1
  auto_mitigation_enabled = var.enable_auto_mitigation
  action {
    action_groups = var.mtv_backend_action_group_id == var.aks_cluster_action_group_id ? [var.mtv_backend_action_group_id] : [var.mtv_backend_action_group_id, var.aks_cluster_action_group_id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "subsequent_408_retries" {
  for_each             = var.aks_clusters
  name                 = "${each.key}-subsequent-408-retries-detected"
  resource_group_name  = var.resource_group_name
  location             = var.location
  scopes               = [var.log_analytics_workspace_id]
  description          = "Some Online transactions experience subsequent retries with 408 error status code. Escalate to MTV support team for deep analisys."
  evaluation_frequency = "PT5M"

  tags = {
    "Observability platform" = "{{ development }}"
  }

  criteria {
    # Count number of clients experience subsequent 408 errors for the same transaction more than 3 times
    query                   = <<-QUERY
    KubePodInventory
    | where TimeGenerated > ago(5m)
    | where ClusterName == "${each.key}"
    | where ServiceName != ""
    | where Namespace == "${var.online_namespace}"
    | where ContainerName endswith "https-wrapper"
    | distinct Computer, ContainerID, Namespace, ServiceName
    | join (
        ContainerLog
        | where TimeGenerated > ago(5m)
        | extend log = parse_json(LogEntry)
        | extend HttpStatus = toint(log["HttpStatus"])
        | extend TransactionId = tostring(log["TransactionId"])
        | where log["LogLevel"] == "Information"
        | where HttpStatus == 408
        )
        on Computer, ContainerID
    | summarize count() by TransactionId
    | where count_ > 2
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }
  window_duration         = "PT5M"
  severity                = 1
  auto_mitigation_enabled = var.enable_auto_mitigation
  action {
    action_groups = var.mtv_backend_action_group_id == var.aks_cluster_action_group_id ? [var.mtv_backend_action_group_id] : [var.mtv_backend_action_group_id, var.aks_cluster_action_group_id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "online_pod_pending" {
  for_each             = var.aks_clusters
  name                 = "${each.key}-online-pod-pending-5-minutes"
  resource_group_name  = var.resource_group_name
  location             = var.location
  scopes               = [var.log_analytics_workspace_id]
  description          = "Some pods in ${var.online_namespace} namespace pending more than 5 minutes. Check pod events using kubectl describe pod command to find reason."
  evaluation_frequency = "PT10M"

  tags = {
    "Observability platform" = "{{ development }}"
  }

  criteria {
    # Identify pods which report Pending state more than 5 times within last 10 minutes
    query                   = <<-QUERY
    KubePodInventory
    | where TimeGenerated > ago(10m)
    | where ClusterName == "${each.key}"
    | where Namespace == "${var.online_namespace}"
    | where PodStatus == "Pending"
    | distinct PodUid, ControllerName, TimeGenerated
    | summarize count(TimeGenerated) by PodUid, ControllerName
    | where count_TimeGenerated >= 5
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  window_duration         = "PT10M"
  severity                = 2
  auto_mitigation_enabled = var.enable_auto_mitigation
  action {
    action_groups = var.mtv_backend_action_group_id == var.aks_cluster_action_group_id ? [var.mtv_backend_action_group_id] : [var.mtv_backend_action_group_id, var.aks_cluster_action_group_id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "batch_pod_pending" {
  for_each             = var.aks_clusters
  name                 = "${each.key}-batch-pod-pending-5-minutes"
  resource_group_name  = var.resource_group_name
  location             = var.location
  scopes               = [var.log_analytics_workspace_id]
  description          = "Some pods in ${var.batch_namespace} namespace pending more than 5 minutes. Check pod events using kubectl describe pod command to find reason."
  evaluation_frequency = "PT10M"

  tags = {
    "Observability platform" = "{{ development }}"
  }

  criteria {
    # Identify pods which report Pending state more than 5 times within last 10 minutes
    query                   = <<-QUERY
    KubePodInventory
    | where TimeGenerated > ago(10m)
    | where ClusterName == "${each.key}"
    | where Namespace == "${var.batch_namespace}"
    | where PodStatus == "Pending"
    | distinct PodUid, ControllerName, TimeGenerated
    | summarize count(TimeGenerated) by PodUid, ControllerName
    | where count_TimeGenerated >= 5
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }
  window_duration         = "PT10M"
  severity                = 2
  auto_mitigation_enabled = var.enable_auto_mitigation
  action {
    action_groups = var.mtv_backend_action_group_id == var.aks_cluster_action_group_id ? [var.mtv_backend_action_group_id] : [var.mtv_backend_action_group_id, var.aks_cluster_action_group_id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "knative_pod_pending" {
  for_each             = var.aks_clusters
  name                 = "${each.key}-knative-pod-pending-5-minutes"
  resource_group_name  = var.resource_group_name
  location             = var.location
  scopes               = [var.log_analytics_workspace_id]
  description          = "Some pods in knative-serving namespace pending more than 5 minutes. Check pod events using kubectl describe pod command to find reason."
  evaluation_frequency = "PT10M"

  tags = {
    "Observability platform" = "{{ development }}"
  }

  criteria {
    # Identify pods which report Pending state more than 5 times within last 10 minutes
    query                   = <<-QUERY
    KubePodInventory
    | where TimeGenerated > ago(10m)
    | where ClusterName == "${each.key}"
    | where Namespace == "knative-serving"
    | where PodStatus == "Pending"
    | distinct PodUid, ControllerName, TimeGenerated
    | summarize count(TimeGenerated) by PodUid, ControllerName
    | where count_TimeGenerated >= 5
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }
  window_duration         = "PT10M"
  severity                = 2
  auto_mitigation_enabled = var.enable_auto_mitigation
  action {
    action_groups = var.mtv_backend_action_group_id == var.aks_cluster_action_group_id ? [var.mtv_backend_action_group_id] : [var.mtv_backend_action_group_id, var.aks_cluster_action_group_id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "istio_pod_pending" {
  for_each             = var.aks_clusters
  name                 = "${each.key}-istio-pod-pending-5-minutes"
  resource_group_name  = var.resource_group_name
  location             = var.location
  scopes               = [var.log_analytics_workspace_id]
  description          = "Some pods in istio-system namespace pending more than 5 minutes. Check pod events using kubectl describe pod command to find reason."
  evaluation_frequency = "PT10M"

  tags = {
    "Observability platform" = "{{ development }}"
  }

  criteria {
    # Identify pods which report Pending state more than 5 times within last 10 minutes
    query                   = <<-QUERY
    KubePodInventory
    | where TimeGenerated > ago(10m)
    | where ClusterName == "${each.key}"
    | where Namespace == "istio-system"
    | where PodStatus == "Pending"
    | distinct PodUid, ControllerName, TimeGenerated
    | summarize count(TimeGenerated) by PodUid, ControllerName
    | where count_TimeGenerated >= 5
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }
  window_duration         = "PT10M"
  severity                = 2
  auto_mitigation_enabled = var.enable_auto_mitigation
  action {
    action_groups = var.mtv_backend_action_group_id == var.aks_cluster_action_group_id ? [var.mtv_backend_action_group_id] : [var.mtv_backend_action_group_id, var.aks_cluster_action_group_id]
  }
}
