resource "azurerm_monitor_metric_alert" "container_cpu_threshold_violated" {
  for_each             = var.aks_clusters
  name                 = "${each.key}-container-cpu-threshold-violated"
  resource_group_name  = var.resource_group_name
  scopes               = [each.value]
  description          = "Alert indicates some container violate CPU threshold, this may indicate CPU limit is too low. To adjust limits Refer to MetaVance Modernization - Application Runbook paragraph 2.5"
  target_resource_type = var.cluster_type
  severity             = 2
  frequency            = "PT5M"
  window_size          = "PT15M"
  auto_mitigate        = var.enable_auto_mitigation

  tags = {
    "Observability platform" = "{{ development }}"
  }

  dynamic_criteria {
    metric_namespace         = "insights.container/containers"
    metric_name              = "cpuThresholdViolated"
    aggregation              = "Count"
    operator                 = "GreaterThan"
    alert_sensitivity        = "Low"
    evaluation_failure_count = 1
    evaluation_total_count   = 1
    dimension {
      name     = "containerName"
      operator = "Include"
      values   = ["https-wrapper", "transaction-enabler", "backend-batch"]
    }
  }

  action {
    action_group_id = var.aks_cluster_action_group_id
  }
}

resource "azurerm_monitor_metric_alert" "container_memory_working_set_threshold_violated" {
  for_each             = var.aks_clusters
  name                 = "${each.key}-container-memory-working-set-threshold-violated"
  resource_group_name  = var.resource_group_name
  scopes               = [each.value]
  description          = "Alert indicates some container violate Memory threshold, this may indicate Memory limit is too low. To adjust limits Refer to MetaVance Modernization - Application Runbook paragraph 2.5"
  target_resource_type = var.cluster_type
  severity             = 2
  frequency            = "PT5M"
  window_size          = "PT15M"
  auto_mitigate        = var.enable_auto_mitigation

  tags = {
    "Observability platform" = "{{ development }}"
  }

  dynamic_criteria {
    metric_namespace         = "insights.container/containers"
    metric_name              = "memoryWorkingSetThresholdViolated"
    aggregation              = "Count"
    operator                 = "GreaterThan"
    alert_sensitivity        = "Low"
    evaluation_failure_count = 1
    evaluation_total_count   = 1
    dimension {
      name     = "containerName"
      operator = "Include"
      values   = ["https-wrapper", "transaction-enabler", "backend-batch"]
    }
  }

  action {
    action_group_id = var.aks_cluster_action_group_id
  }
}

resource "azurerm_monitor_metric_alert" "node_cpu_usage_percentage" {
  for_each             = var.aks_clusters
  name                 = "${each.key}-node-cpu-usage-percentage"
  resource_group_name  = var.resource_group_name
  scopes               = [each.value]
  description          = "Alert indicates some node in ${each.key} cluster experience high CPU usage. Check Insights/Nodes section of ${each.key} cluster in Azure Portal, refer to MetaVance Modernization - Observability Runbook paragraph 4.1. In case of uneven workload distribution adjust container CPU requests, refer to MetaVance Modernization - Application Runbook paragraph 2.5. In case all nodes experience high CPU utilisation consider adding more nodes to cluster or resize nodes."
  target_resource_type = var.cluster_type
  severity             = 2
  frequency            = "PT5M"
  window_size          = "PT15M"
  auto_mitigate        = var.enable_auto_mitigation

  tags = {
    "Observability platform" = "{{ development }}"
  }

  criteria {
    metric_namespace = "insights.container/nodes"
    metric_name      = "cpuUsagePercentage"
    aggregation      = "Average"
    operator         = "GreaterThan"
    threshold        = 80
    dimension {
      name     = "host"
      operator = "Include"
      values   = ["*"]
    }
  }
  action {
    action_group_id = var.aks_cluster_action_group_id
  }
}

resource "azurerm_monitor_metric_alert" "node_memory_usage_percentage" {
  for_each             = var.aks_clusters
  name                 = "${each.key}-node-memory-usage-percentage"
  resource_group_name  = var.resource_group_name
  scopes               = [each.value]
  description          = "Alert indicates some node in ${each.key} cluster experience high Memory usage. Check Insights/Nodes section of ${each.key} cluster in Azure Portal, refer to MetaVance Modernization - Observability Runbook paragraph 4.2. In case of uneven workload distribution adjust container Memory requests, refer to MetaVance Modernization - Application Runbook paragraph 2.5. In case all nodes experience high Memory utilisation consider adding more nodes to cluster or resize nodes."
  target_resource_type = var.cluster_type
  severity             = 2
  frequency            = "PT5M"
  window_size          = "PT15M"
  auto_mitigate        = var.enable_auto_mitigation

  tags = {
    "Observability platform" = "{{ development }}"
  }

  criteria {
    metric_namespace = "insights.container/nodes"
    metric_name      = "memoryWorkingSetPercentage"
    aggregation      = "Average"
    operator         = "GreaterThan"
    threshold        = 80
    dimension {
      name     = "host"
      operator = "Include"
      values   = ["*"]
    }
  }
  action {
    action_group_id = var.aks_cluster_action_group_id
  }
}

resource "azurerm_monitor_metric_alert" "oom_killed_pods" {
  for_each             = var.aks_clusters
  name                 = "${each.key}-oom-killed-pods"
  resource_group_name  = var.resource_group_name
  scopes               = [each.value]
  description          = "Alert indicates some container been OOM killed by Kubernetes, this may indicate Memory limit is too low or application specific issue. To adjust limits refer to MetaVance Modernization - Application Runbook paragraph 2.5"
  target_resource_type = var.cluster_type
  severity             = 2
  frequency            = "PT5M"
  window_size          = "PT15M"
  auto_mitigate        = var.enable_auto_mitigation

  tags = {
    "Observability platform" = "{{ development }}"
  }

  criteria {
    metric_namespace = "insights.container/pods"
    metric_name      = "oomKilledContainerCount"
    aggregation      = "Minimum"
    operator         = "GreaterThanOrEqual"
    threshold        = 1
    dimension {
      name     = "Kubernetes namespace"
      operator = "Include"
      values   = [var.online_namespace, var.batch_namespace, "kube-system", "knative-serving", "istio-system"]
    }
  }
  action {
    action_group_id    = var.aks_cluster_action_group_id
    webhook_properties = null
  }
}
