variable "resource_group_name" {
  description = "Name of resource group to create workbooks"
  type        = string
}

variable "location" {
  description = "Location in which to create alerting rules"
  type        = string
}

variable "aks_clusters" {
  description = "AKS Clusters to setup monitoring map name to id"
  type        = map(string)
}

variable "aks_cluster_action_group_id" {
  description = "ID of action group to notify of cluster alerts"
  type        = string
}

variable "log_analytics_workspace_id" {
  description = "ID of log analytics workspace to use for scheduled query alerts"
  type        = string
}

variable "mtv_backend_action_group_id" {
  description = "ID of action group to notify of backend alerts"
  type        = string
}

variable "app_insights_id" {
  description = "Id of application insights"
  type        = string
}

variable "cluster_type" {
  description = "Type of Kubernetes cluster Connected for HCI and Managed for AKS"
  type        = string
  default     = "microsoft.kubernetes/connectedclusters"
}

variable "online_namespace" {
  description = "Name of namespace where online pods are running"
  type        = string
}

variable "batch_namespace" {
  description = "Name of namespace where batch pods are running"
  type        = string
}

variable "enable_auto_mitigation" {
  description = "Specify to enable auto mitigation for all alert rules or not"
  type        = bool
  default     = true
}
