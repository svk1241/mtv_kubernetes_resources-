resource "azurerm_monitor_smart_detector_alert_rule" "mtv-failure-anomalies" {
  name                = "mtv-failure-anomalies-smart-detector-alert-rule"
  resource_group_name = var.resource_group_name
  severity            = "Sev2"
  scope_resource_ids  = [var.app_insights_id]
  frequency           = "PT1M"
  detector_type       = "FailureAnomaliesDetector"
  description         = "Detects if application experiences an abnormal rise in the rate of HTTP requests or dependency calls that are reported as failed using machine learning algorithm. Refer to MetaVance Modernization - Troubleshooting Runbook paragraph 3.1"

  tags = {
    "Observability platform" = "{{ development }}"
  }

  action_group {
    ids = [var.mtv_backend_action_group_id]
  }
}

resource "azurerm_monitor_smart_detector_alert_rule" "mtv-performance-degradation" {
  name                = "mtv-performance-degradation-smart-detector-alert-rule"
  resource_group_name = var.resource_group_name
  severity            = "Sev2"
  scope_resource_ids  = [var.app_insights_id]
  frequency           = "P1D"
  detector_type       = "RequestPerformanceDegradationDetector"
  description         = "Detects if application experiences an abnormal rise in the latency of HTTP requests using machine learning algorithm. Refer to MetaVance Modernization - Troubleshooting Runbook paragraph 3.1"

  tags = {
    "Observability platform" = "{{ development }}"
  }

  action_group {
    ids = [var.mtv_backend_action_group_id]
  }
}
