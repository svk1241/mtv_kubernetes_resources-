variable "resource_group_name" {
  description = "Name of resource group to create workbooks"
  type        = string
}

variable "action_group_name" {
  description = "The name of the Action Group"
  type        = string
}

variable "action_group_short_name" {
  description = "The short name of the action group. This will be used in SMS messages."
  type        = string
}

variable "email_receivers" {
  description = "Map of email recievers to send notifications name: email"
  type        = map(string)
}
