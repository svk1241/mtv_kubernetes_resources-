resource "azurerm_monitor_action_group" "this" {
  name                = var.action_group_name
  short_name          = var.action_group_short_name
  resource_group_name = var.resource_group_name

  dynamic "email_receiver" {
    for_each = var.email_receivers
    content {
      name                    = email_receiver.key
      email_address           = email_receiver.value
      use_common_alert_schema = true
    }
  }
}
