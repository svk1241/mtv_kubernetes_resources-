resource_location   = "Central US"
resource_group_name = "rg-observability-dxccloud"

workspace = {
  name              = "ws-log-analytics-observability-dxccloud",
  sku               = "PerGB2018",
  retention_in_days = 30,
  daily_cap         = 150
}

aks_clusters = {
  mtv-aks-dev-cluster  = "/subscriptions/e09a8dd5-6f50-4718-a54a-cc31913b6d2b/resourceGroups/metavance3.0-resources/providers/Microsoft.ContainerService/managedClusters/mtv-aks-dev-cluster"
  mtv-aks-dev2-cluster = "/subscriptions/e09a8dd5-6f50-4718-a54a-cc31913b6d2b/resourceGroups/metavance3.0-resources/providers/Microsoft.ContainerService/managedClusters/mtv-aks-dev2-cluster"
aks_clusters = {           # Existing AKS clusters details
  online_cluster_name = "" # for example: mtvonlinehcicluster = "/subscriptions/aaaaaaaa-bbbb-1111-cccc-222222222222/resourceGroups/Metavance_RG/providers/Microsoft.Kubernetes/connectedClusters/mtvonlinehcicluster"
  batch_cluster_name  = ""
}

app_insights = {
  name              = "app-insights-observability-dxccloud",
  retention_in_days = 30,
}

aks_cluster_action_group = {
  name       = "mtv-dxc-cluster-notification"
  short_name = "mtv-dxc-alrt"
  email_receivers = {
    Gyan_Kumar = "gkumar22@dxc.com"
    Gayathri = "gayathri.d2@dxc.com"
    Chourasia_Gourav = "gourav.chourasia@dxc.com"
    Sirangu_Sivaramakrishna = "s.sirangu@dxc.com"
    Sridharan_Rangarajan = "Rangarajan.Sridharan@dxc.com"
    Aulakh_Ramandeep_Singh = "ramandeep.aulakh@dxc.com"
  }
}

mtv_backend_action_group = {
  name       = "mtv-dxc-backend-cluster-notification"
  short_name = "mtv-dxc-balt"
  email_receivers = {
    Gyan_Kumar = "gkumar22@dxc.com"
    Gayathri   = "gayathri.d2@dxc.com"
    Chourasia_Gourav = "gourav.chourasia@dxc.com"
    Sirangu_Sivaramakrishna = "s.sirangu@dxc.com"
    Sridharan_Rangarajan = "Rangarajan.Sridharan@dxc.com"
    Aulakh_Ramandeep_Singh = "ramandeep.aulakh@dxc.com"
  }
}

online_namespace = ""
batch_namespace  = ""

# Default is false, if false all variables below are ignored
collect_client_proxy_logs = true

# Azure Arc connected Windows machines running ClientProxy
client_proxy_machines = {
  arc_machine_name = "" # for example: EBZPRD001 = "rg-prd-ebz-servers"
}

# Optional settings as JSON string
client_proxy_agent_settings = "" # for example: {\"proxy\" : {\"mode\" : \"application\", \"address\" : \"https://my.proxy.com:8443\", \"auth\" : false}}"

# Log Analytics workspace detail
client_proxy_logs_workspace = {
  name                = ""
  resource_group_name = ""
  id                  = "" # for example: "/subscriptions/aaaaaaaa-bbbb-1111-cccc-222222222222/resourceGroups/Metavance_RG/providers/Microsoft.OperationalInsights/workspaces/nprod-eus-log-ws"
}

# Name of table to create within specified workspace
client_proxy_log_table_name = "" # for example: "CLIENT_PROXY_CL"

# File patterns to capture logs
client_proxy_file_patterns = [
  "" # for example "C:\\tmp\\HTTPS-Proxy-MTV-7001\\*.log"
]
