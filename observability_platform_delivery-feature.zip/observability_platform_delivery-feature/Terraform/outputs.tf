output "resource_group_id" {
  value = azurerm_resource_group.main_rg.id
}

output "log_analytics_workspace_id" {
  value = var.existing_workspace_id == "" ? azurerm_log_analytics_workspace.workspace[0].id : null
}

output "app_insights_connection_string" {
  value     = azurerm_application_insights.app_insights.connection_string
  sensitive = true
}

output "aks_cluster_action_group_id" {
  value = var.create_alerts && var.existing_aks_cluster_action_group_id == "" ? module.aks_cluster_action_group[0].azure_monitor_action_group_id : null
}

output "mtv_backend_action_group_id" {
  value = var.create_alerts && var.existing_mtv_backend_action_group_id == "" ? module.mtv_backend_action_group[0].azure_monitor_action_group_id : null
}

output "alert_rule_ids" {
  value = var.create_alerts ? module.azure_monitor_alert_rules[0].* : null
}

output "azure_monitor_workbook_mtv_transactions_id" {
  value = module.azure_monitor_workbooks.mtv_transactions_workbook_id
}

output "azure_monitor_workbook_aks_cluster_metrics_ids" {
  value = module.azure_monitor_workbooks.aks_cluster_metrics_workbook_ids.*
}

output "azure_monitor_query_pack_query_ids" {
  value = var.create_query_packs ? module.azure_monitor_query_packs[0].* : null
}

output "azure_monitor_client_data_collection_ids" {
  value = var.collect_client_proxy_logs ? module.azure_monitor_client_data_collection[0].* : null
}
