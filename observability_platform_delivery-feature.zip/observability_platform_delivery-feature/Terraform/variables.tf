variable "resource_location" {
  description = "Location of resources to be provisioned"
  type        = string
}

variable "resource_group_name" {
  description = "Name of resource group withing which to provision resources"
  type        = string
}

variable "existing_workspace_id" {
  description = "ID of existing log analytics workspace, if blank new one will be created"
  type        = string
  default     = ""
}

variable "workspace" {
  description = "Log analytics workspace resource to be created"
  type = object({
    name              = string
    sku               = string
    retention_in_days = number
    daily_cap         = number
  })
  default = null
}

variable "aks_clusters" {
  description = "AKSHCI clusters to apply settings map name to id"
  type        = map(string)
}

variable "app_insights" {
  description = "Application insights object to be created"
  type = object({
    name              = string
    retention_in_days = number
  })
}

variable "existing_aks_cluster_action_group_id" {
  description = "ID of existing aks custer action group"
  type        = string
  default     = ""
}

variable "aks_cluster_action_group" {
  description = "Action group for AKSHCI cluster notifications"
  type = object({
    name            = string
    short_name      = string
    email_receivers = map(string)
  })
  default = null
}

variable "existing_mtv_backend_action_group_id" {
  description = "ID of existing MTV backend action group"
  type        = string
  default     = ""
}

variable "mtv_backend_action_group" {
  description = "Action group for MTV backend notifications"
  type = object({
    name            = string
    short_name      = string
    email_receivers = map(string)
  })
  default = null
}

variable "online_namespace" {
  description = "Name of namespace where online pods are running"
  type        = string
}

variable "batch_namespace" {
  description = "Name of namespace where batch pods are running"
  type        = string
}

variable "cluster_type" {
  description = "Type of Kubernetes cluster Connected for HCI and Managed for AKS"
  type        = string
  default     = "microsoft.kubernetes/connectedclusters"
}

variable "create_alerts" {
  description = "Specify to create alerts or not"
  type        = bool
  default     = true
}

variable "create_query_packs" {
  description = "Specify to create query packs or not"
  type        = bool
  default     = true
}

variable "collect_client_proxy_logs" {
  description = "Specify to collect logs from client proxy or not"
  type        = bool
  default     = false
}

variable "client_proxy_machines" {
  type        = map(string)
  description = "Azure Arc connected machines to deploy Azure Monitor Agent(AMA) map name to resource group"
}

variable "client_proxy_agent_settings" {
  type        = string
  default     = null
  description = "Optional settings to configure Azure Monitor Agents, ex. Proxy settimgs"
}

variable "client_proxy_logs_workspace" {
  description = "Log Analytics Workspace for Client Proxy details"
  type = object({
    name                = string
    resource_group_name = string
    id                  = string
  })
}

variable "client_proxy_log_table_name" {
  description = "Name of table to upload ClientProxy logs"
  type        = string
}

variable "client_proxy_file_patterns" {
  description = "List of file patterns which will be used to collect logs from machines"
  type        = list(string)
}
