
Find installation guide using following [link](https://dxcportal.sharepoint.com/:w:/r/sites/DeltaDentalMTV_1/Shared%20Documents/General/DevOps/Instructions/MetaVance%20Modernization%20-%20Observability%20Platform%20Installation.docx?d=w8df90e7aa59c4df5931658d636826ad0&csf=1&web=1&e=4orMm6)

Optional: Modify version tags  
``` PowerShell
$VERSION = "v.X.Y"
Get-ChildItem ".\Terraform\data" -Recurse -Filter *.workbook |
Foreach-Object {
  ((Get-Content -path $_.FullName -Raw) -replace '{{ development }}', "${VERSION}") | Set-Content -NoNewline -Path $_.FullName
}
Get-ChildItem ".\Terraform\modules" -Recurse -Filter *.tf |
Foreach-Object {
  ((Get-Content -path $_.FullName -Raw) -replace '{{ development }}', "${VERSION}") | Set-Content -NoNewline -Path $_.FullName
}
```

Luxoft:  
``` bash
az login # Select Luxoft ID
cd Terraform
../var/luxoft/backend-init.sh
cp ../var/luxoft/terraform.tfvars .
# Disable or enable container insights per cluster
az aks disable-addons -a monitoring \
                      -n cluster-aks002-eastus-private \
                      -g rg-spoke-aks001-eastus-private
az aks enable-addons -a monitoring \
                     -n cluster-aks002-eastus-private \
                     -g rg-spoke-aks001-eastus-private \
                     --enable-msi-auth-for-monitoring \
                     --workspace-resource-id /subscriptions/d705f4d8-7a99-4443-b7df-67187358521f/resourcegroups/rg-observability-ddmtv-2254/providers/microsoft.operationalinsights/workspaces/ws-log-analytics-observability-ddmtv-2254
# Get manifests to deploy Open telemetry agent
cd ../Manifests
helm install --create-namespace -n telemetry otel-collector ./otel-collector -f ../var/luxoft/values.yaml
# Deprecated way
helm template otel-collector ./otel-collector -f ..var/luxoft/values.yaml > otel-collector-deployment.yaml
```
DXC Cloud:  
``` bash
az login # Select DXC ID
cd Terraform
../var/dxc/backend-init.sh
cp ../var/dxc/terraform.tfvars .
# Disable or enable container insights per cluster
az aks disable-addons -a monitoring \
                      -n mtv-aks-dev-cluster \
                      -g metavance3.0-resources
az aks disable-addons -a monitoring \
                      -n mtv-aks-dev2-cluster \
                      -g metavance3.0-resources
az aks enable-addons -a monitoring \
                     -n mtv-aks-dev-cluster \
                     -g metavance3.0-resources \
                     --enable-msi-auth-for-monitoring \
                     --workspace-resource-id /subscriptions/e09a8dd5-6f50-4718-a54a-cc31913b6d2b/resourcegroups/rg-observability-dxccloud/providers/microsoft.operationalinsights/workspaces/ws-log-analytics-observability-dxccloud
az aks enable-addons -a monitoring \
                     -n mtv-aks-dev2-cluster \
                     -g metavance3.0-resources \
                     --enable-msi-auth-for-monitoring \
                     --workspace-resource-id /subscriptions/e09a8dd5-6f50-4718-a54a-cc31913b6d2b/resourcegroups/rg-observability-dxccloud/providers/microsoft.operationalinsights/workspaces/ws-log-analytics-observability-dxccloud
# Get manifests to deploy Open telemetry agent
cd ../Manifests
helm install --create-namespace -n telemetry otel-collector ./otel-collector -f ../var/dxc/values.yaml
# Deprecated way
helm template otel-collector ./otel-collector -f ..var/dxc/values.yaml > otel-collector-deployment.yaml
```
HCI:  
```bash
az login # Select DXC ID
cd Terraform
../var/hci/backend-init.sh
cp ../var/hci/terraform.tfvars .
# Disable or enable container insights per cluster
az k8s-extension delete --name azuremonitor-containers \
                        --cluster-type connectedClusters \
                        --cluster-name mtvbluonlhcicluster \
                        --resource-group Metavance_3.0_HCI

az k8s-extension delete --name azuremonitor-containers \
                        --cluster-type connectedClusters \
                        --cluster-name mtvgrnonlhcicluster \
                        --resource-group Metavance_3.0_HCI

kubectl apply -f container-azm-ms-agentconfig.yaml

az k8s-extension create --name azuremonitor-containers \
                        --cluster-name mtvbluonlhcicluster \
                        --resource-group Metavance_3.0_HCI \
                        --cluster-type connectedClusters \
                        --extension-type Microsoft.AzureMonitor.Containers \
                        --configuration-settings amalogs.useAADAuth=true \
                        --configuration-settings logAnalyticsWorkspaceResourceID=/subscriptions/e09a8dd5-6f50-4718-a54a-cc31913b6d2b/resourcegroups/rg-observability-ddmtv-2254/providers/microsoft.operationalinsights/workspaces/ws-log-analytics-observability-ddmtv-2254 \
                        --configuration-settings amalogs.resources.daemonsetlinux.limits.cpu=1000m

az k8s-extension create --name azuremonitor-containers \
                        --cluster-name mtvgrnonlhcicluster \
                        --resource-group Metavance_3.0_HCI \
                        --cluster-type connectedClusters \
                        --extension-type Microsoft.AzureMonitor.Containers \
                        --configuration-settings amalogs.useAADAuth=true \
                        --configuration-settings logAnalyticsWorkspaceResourceID=/subscriptions/e09a8dd5-6f50-4718-a54a-cc31913b6d2b/resourcegroups/rg-observability-ddmtv-2254/providers/microsoft.operationalinsights/workspaces/ws-log-analytics-observability-ddmtv-2254 \
                        --configuration-settings amalogs.resources.daemonsetlinux.limits.cpu=1000m

# Get manifests to deploy Open telemetry agent
cd ../Manifests
helm install --create-namespace -n telemetry otel-collector ./otel-collector -f ../var/hci/values.yaml
# Deprecated way
helm template otel-collector ./otel-collector -f ../var/hci/values.yaml > otel-collector-deployment.yaml
```
