#!/bin/bash

# List images to be removed
PURGE_CMD="acr purge \
  --filter 'extensions-adapter-lib-checker:v\.[^\.]{11}' \
  --ago 3d --untagged"

# Schedule image cleanup every week
az acr task create --name weeklyPurgeTask \
  --cmd "$PURGE_CMD" \
  --schedule "0 1 * * Sun" \
  --registry acrregistryhubeastusprivated9f2 \
  --context /dev/null
