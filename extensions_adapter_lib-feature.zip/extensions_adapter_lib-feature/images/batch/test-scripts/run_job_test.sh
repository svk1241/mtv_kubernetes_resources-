# created by atikhonov
# Auto tests use full path to batch job

export MTV_INIT_SCRIPT=mtv-batch-init.sh

for job in "$@"
do
    time /mtv/ddx/common/$job.cmd DEFAULT /mtv/ddx/batch/
done
