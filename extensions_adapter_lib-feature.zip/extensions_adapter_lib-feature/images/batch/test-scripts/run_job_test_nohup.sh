# created by atikhonov
# Auto tests use full path to batch job

export MTV_INIT_SCRIPT=mtv-batch-init.sh
app_root="/mtv/ddx"

for job in "$@"
do
    nohup bash -c "time $app_root/common/$job.cmd DEFAULT $app_root/batch/" >$app_root/batch/output/$job.out 2>$app_root/batch/output/$job.err &
done
