#!/bin/bash
set -e
ADAPTER_VERSION=$1
MTV_VERSION=$2

[ -z "ADAPTER_VERSION" ] && echo "Variable 'ADAPTER_VERSION' is empty or absent " && exit 1
[ -z "$MTV_VERSION" ] && echo "Variable 'MTV_VERSION' is empty or absent " && exit 1

cd ./online
az acr build \
    --registry acrregistryhubeastusprivated9f2.azurecr.io \
    --image transaction-enabler-deltadental-extensions-adapter:v.${MTV_VERSION}-${ADAPTER_VERSION} \
    --build-arg ADAPTER_VERSION=$ADAPTER_VERSION \
    --build-arg MTV_VERSION=$MTV_VERSION \
    .
cd ..
cd ./batch
az acr build \
    --registry acrregistryhubeastusprivated9f2.azurecr.io \
    --image mtv-backend-batch-extensions-adapter:v.${MTV_VERSION}-${ADAPTER_VERSION} \
    --build-arg ADAPTER_VERSION=$ADAPTER_VERSION \
    --build-arg MTV_VERSION=$MTV_VERSION \
    .
cd ..
