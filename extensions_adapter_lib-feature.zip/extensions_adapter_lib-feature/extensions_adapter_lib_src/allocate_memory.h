#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "ddext1.h"
#include "ddext2.h"

#ifndef max
#define max(a,b)    (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a,b)    (((a) < (b)) ? (a) : (b))
#endif

static void freeItf(CONTROL_INFO* pControlInfo)
{
	if (NULL != pControlInfo)
	{
		free(pControlInfo->claim_header);
    	free(pControlInfo->service_line);
    	free(pControlInfo->ignored_service_line);
    	free(pControlInfo->service_history_line);
		free(pControlInfo);
	}
}

static void allocateItf(CONTROL_INFO* pControlInfo, int nServices, int nIgnored, int nHistory)
{
	size_t alloc;

	if (NULL != pControlInfo)
	{
		nServices = max(nServices, MAX_SERVICE_LINES);
		nIgnored = min(nIgnored, MAX_IGNORED_SERVICE_LINES);
		nHistory = min(nHistory, MAX_SERVICE_HISTORY_LINES);

		alloc = nServices * sizeof(SERVICE_LINE);
    	pControlInfo->service_line = (SERVICE_LINE*)malloc(alloc);
		if (NULL == pControlInfo->service_line) goto ERROR_EXIT;
		memset(pControlInfo->service_line, 0, alloc);

		alloc = nIgnored * sizeof(IGNORED_SERVICE_LINE);
    	pControlInfo->ignored_service_line = (IGNORED_SERVICE_LINE*)malloc(alloc);
		if (NULL == pControlInfo->ignored_service_line) goto ERROR_EXIT;
		memset(pControlInfo->ignored_service_line, 0, alloc);

		alloc = nHistory * sizeof(SERVICE_HISTORY_LINE);
    	pControlInfo->service_history_line = (SERVICE_HISTORY_LINE*)malloc(alloc);
		if (NULL == pControlInfo->service_history_line) goto ERROR_EXIT;
		memset(pControlInfo->service_history_line, 0, alloc);

		goto NOT_ERROR_EXIT;
ERROR_EXIT:;
		freeItf(pControlInfo);
		pControlInfo = NULL;
NOT_ERROR_EXIT:;
	}
	return;
}

static void freeItfInc(CONTROL_INFO_INC* pControlInfo)
{
	if (NULL != pControlInfo)
	{
		free(pControlInfo->claim_header);
		free(pControlInfo->service_line);
		free(pControlInfo->subscriber_member);
		free(pControlInfo);
	}
}

static void allocateItfInc(CONTROL_INFO_INC* pControlInfo, int nServices, int nSubMemberRecords)
{
	size_t alloc;

	if (NULL != pControlInfo)
	{
		nServices = max(nServices, SERVICE_LINE_MAX);
		nSubMemberRecords = max(nSubMemberRecords, SUBSCRIBER_MEMBER_MAX);

		alloc = nServices * sizeof(SERVICE_LINE_INC);
		pControlInfo->service_line = (SERVICE_LINE_INC*)malloc(alloc);
		if (NULL == pControlInfo->service_line) goto ERROR_EXIT;
		memset(pControlInfo->service_line, 0, alloc);

		alloc = nSubMemberRecords * sizeof(SUBSCRIBER_MEMBER);
		pControlInfo->subscriber_member = (SUBSCRIBER_MEMBER*)malloc(alloc);
		if (NULL == pControlInfo->subscriber_member) goto ERROR_EXIT;
		memset(pControlInfo->subscriber_member, 0, alloc);

		goto NOT_ERROR_EXIT;
ERROR_EXIT:;
		freeItfInc(pControlInfo);
		pControlInfo = NULL;
NOT_ERROR_EXIT:;
	}
	return;
}
