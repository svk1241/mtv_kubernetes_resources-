#!/bin/sh

make all

cd ddext

make all
