#!/bin/sh

make clean

cd ddext

make clean
