package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

type ExtAdapterMetaData struct {
	EWSVersion string
}

func getValueStringFromVersionFile(file *os.File, searchString string) (string, error) {
	_, err := file.Seek(0, 0)
	if err != nil {
		err = fmt.Errorf("moving file pointer to beginning: %v ", err)
	}
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		currentLine := scanner.Text()
		index := strings.Index(currentLine, ":")
		if index != -1 {
			subStr := currentLine[:index]
			if subStr == searchString {
				return strings.TrimSpace(currentLine[index+1:]), nil
			}
		} else {
			err = fmt.Errorf("there is not simbol ':' in the supported_version.txt file string ")
		}
	}

	if err := scanner.Err(); err != nil {
		return "", err
	}

	return "", err
}

func initMetaData() (ExtAdapterMetaData, error) {
	filePath := GlobalAppConfig.GetValue("Server.SupportedVersionPath", "/app/supported_version.txt")
	file, err := os.Open(filePath)
	if err != nil {
		return ExtAdapterMetaData{}, err
	}
	defer file.Close()

	extensionWrapperServiceVersion := "extensions_wrapper_version"

	wrapperServiceVersion, err := getValueStringFromVersionFile(file, extensionWrapperServiceVersion)
	if err != nil || wrapperServiceVersion == "" {
		return ExtAdapterMetaData{}, fmt.Errorf("can't get value %s from supported_version.txt: %v ", extensionWrapperServiceVersion, err)
	}

	return ExtAdapterMetaData{wrapperServiceVersion}, nil
}

func GetExtAdapterMetaDataString() (string, error) {
	metaData, err := initMetaData()
	if err != nil {
		return "", fmt.Errorf("can't init metadata: %v ", err)
	}

	return metaData.EWSVersion, nil
}
