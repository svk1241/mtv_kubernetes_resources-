#include <stdlib.h>
#include <libextclient.h>

#include "ddext1.h"



void delta_extension_1(CONTROL_INFO* control_info)
{
	int rc = CallExtension1(control_info); 
    if (rc != 0) {
    	exit(2);
    }
}
