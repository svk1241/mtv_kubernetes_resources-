#include <stdlib.h>
#include <libextclient.h>

#include "ddext2.h"

void delta_extension_2(CONTROL_INFO_INC* control_info)
{
    int rc = CallExtension2(control_info); 
    if (rc != 0) {
    	exit(2);
    }
}
