package main

/*
#cgo CFLAGS: -I ddext
#include "allocate_memory.h"
#include "ddext1.h"
#include "ddext2.h"
*/
import "C"
import (
	"bytes"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math/rand"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
	"unicode"
	"unsafe"

	ci "luxproject.luxoft.com/stash/scm/mpcexp/extensions_control_info.git"
	appconfig "luxproject.luxoft.com/stash/scm/mpcexp/lms_app_config_go.git"
	customlogger "luxproject.luxoft.com/stash/scm/mpcexp/lms_logger_go.git"
)

const ReturnCodeOK int = 0
const ReturnCodeEwsError int = 1
const ReturnCodeEalError int = 2

var GlobalLoggingSettings *customlogger.LoggingSettings
var GlobalAppConfig appconfig.AppConfig
var contentType = "application/json"
var callUrl string
var claimID string
var date time.Time
var elapsedMs int
var elapsedMsEWS int
var hostName string
var httpStatusCode int
var requestID string
var successful bool
var transactionID string
var transactionTimeout time.Duration

var logAgs map[string]interface{}

var responseEOF = errors.New("failed to read response, status code: EOF")
var responseUnexpectedEOF = errors.New("failed to read response, status code: unexpected EOF")

type HTTPSWraperData struct {
	RequestID          string        `json:"global_request_id"`
	TransactionTimeout time.Duration `json:"transaction_timeout"`
	TransactionId      string        `json:"global_transaction_id"`
}

func IsSuccess(httpStatusCode int) (success bool) {
	return (httpStatusCode >= 200) && (httpStatusCode <= 299)
}

func InitLogAgs(pLogAgs *map[string]interface{}) {
	date = time.Now()
	callUrl = ""
	elapsedMs = 0
	elapsedMsEWS = 0
	hostName = ""
	httpStatusCode = 0
	requestID = ""
	successful = false
	transactionID = ""
	transactionTimeout = 0
	*pLogAgs = map[string]interface{}{
		"CallUrl":       &callUrl,
		"ClaimId":       &claimID,
		"Context":       "EAL",
		"Date":          &date,
		"ElapsedMs":     &elapsedMs,
		"EWSElapsedMs":  &elapsedMsEWS,
		"Hostname":      &hostName,
		"HttpStatus":    &httpStatusCode,
		"RequestId":     &requestID,
		"Successful":    &successful,
		"TransactionId": &transactionID,
	}
}

func generateRandomString(length int) string {
	source := rand.NewSource(time.Now().UnixNano())
	random := rand.New(source)
	const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

	result := make([]byte, length)
	for i := range result {
		result[i] = charset[random.Intn(len(charset))]
	}

	return string(result)
}

func getHTTPSWraperData() (HTTPSWraperData, error) {
	timeout := (time.Duration(GlobalAppConfig.GetInt64("Timeouts.TransactionTimeout", 120)) * time.Second)
	port := GlobalAppConfig.GetValue("HttpsWrapper.Port", "6000")
	url := ("http://localhost:" + port + "/ext-adapter-request")
	response, err := http.Get(url)
	if err != nil {
		return HTTPSWraperData{generateRandomString(23), timeout, getProcessName()}, nil
	}
	defer response.Body.Close()

	if response.StatusCode != http.StatusOK {
		return HTTPSWraperData{generateRandomString(23), timeout, getProcessName()}, nil
	}

	var httpsWrapperData HTTPSWraperData
	err = json.NewDecoder(response.Body).Decode(&httpsWrapperData)
	if err != nil {
		return HTTPSWraperData{generateRandomString(23), timeout, getProcessName()}, fmt.Errorf("can't decode data from https wrapper: %v ", err)
	}

	return httpsWrapperData, nil
}

func getProcessName() string {
	exePath, err := os.Executable()
	if err != nil {
		return ""
	}

	return filepath.Base(exePath)
}

func calculateDurationTime(start time.Time, pElapsedMs *int) {
	duration := time.Since(start)
	*pElapsedMs = int(duration.Milliseconds())
}

func ExtensionProcessing(endpoint string, t unsafe.Pointer, start time.Time, log customlogger.LoggerInterface) int {
	var err error

	var data interface{}
	switch {
	case endpoint == "delta_extension_1":
		controlInfo := ci.DeltaControlInfoRecord{}
		err = ci.C2GoDeltaControlInfoRecord(t, &controlInfo)
		claimID = trimClaimID(controlInfo.ClaimHeader.ClaimID)
		data = controlInfo
	case endpoint == "delta_extension_2":
		controlInfoInc := ci.DeltaControlInfoIncRecord{}
		err = ci.C2GoDeltaControlInfoIncRecord(t, &controlInfoInc)
		claimID = trimClaimID(controlInfoInc.ClaimHeaderInc.ClaimID)
		data = controlInfoInc
	default:
		calculateDurationTime(start, &elapsedMs)
		log.Error("Bad structure:", err)
		return ReturnCodeEalError
	}

	buffer, err := ci.ConvertToJSON(data)
	if err != nil {
		calculateDurationTime(start, &elapsedMs)
		log.Error("Error converting struct to binary:", err)
		return ReturnCodeEalError
	}

	response, err := sendJSON(buffer)
	if err != nil {
		calculateDurationTime(start, &elapsedMs)
		switch err {
		case responseEOF:
			log.Debug("Extensions Wrapper Service failed with error: ", err)
			log.Error("Extensions Wrapper Service failed.")
			return ReturnCodeEwsError
		case responseUnexpectedEOF:
			log.Debug("Extensions Wrapper Service failed with error: ", err)
			log.Error("Extensions Wrapper Service failed.")
			return ReturnCodeEwsError
		default:
			log.Error("Error sending JSON to Extensions Wrapper Service: ", err)
			return ReturnCodeEwsError
		}
	}
	successful = IsSuccess(httpStatusCode)

	switch {
	case endpoint == "delta_extension_1":
		var controlInfo_ ci.DeltaControlInfoRecord
		err = json.Unmarshal(response, &controlInfo_)
		if err != nil {
			calculateDurationTime(start, &elapsedMs)
			log.Error("Wrong data")
			return ReturnCodeEalError
		}
		C.allocateItf((*C.CONTROL_INFO)(t), (C.int)(controlInfo_.ServiceLineCount), (C.int)(controlInfo_.IgnoredServiceLineCount), (C.int)(controlInfo_.ServiceHistoryLineCount))
		err = ci.PointerControlInfo(controlInfo_, t)
		if err != nil {
			//TODO: added error
			return ReturnCodeEalError
		}
	case endpoint == "delta_extension_2":
		var controlInfoInc_ ci.DeltaControlInfoIncRecord
		err = json.Unmarshal(response, &controlInfoInc_)
		if err != nil {
			calculateDurationTime(start, &elapsedMs)
			log.Error("Bad structure:", err)
			return ReturnCodeEalError
		}

		C.allocateItfInc((*C.CONTROL_INFO_INC)(t), (C.int)(controlInfoInc_.ServiceLineCount), (C.int)(controlInfoInc_.SubscriberMemberCnt))
		err = ci.PointerControlInfoInc(controlInfoInc_, t)
		if err != nil {
			//TODO: added error
			return ReturnCodeEalError
		}
	default:
		calculateDurationTime(start, &elapsedMs)
		log.Error("Bad structure:", err)
		return ReturnCodeEalError
	}

	calculateDurationTime(start, &elapsedMs)
	log.Information("Request is successfully processed")
	return ReturnCodeOK
}

// TODO: move to ControlInfo
func trimClaimID(str string) string {
	isTrimmedRune := func(r rune) bool {
		return unicode.IsSpace(r) || r == '\u0000'
	}
	return strings.TrimRightFunc(str, isTrimmedRune)
}

func ExtensionWrapperRunner(endpoint string, t unsafe.Pointer) int {
	start := time.Now()

	appConfigFile, ok := os.LookupEnv("EXT_APP_CONFIG_PATH")
	if !ok {
		appConfigFile = "/app/appsettings.json"
		fmt.Fprintf(os.Stderr, "environment variable EXT_APP_CONFIG_PATH not set, reading config from default location: %s\n", appConfigFile)
	}
	err := getConfig(appConfigFile)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error then config read: %v\n", err)
	}

	loggingInitialize(GlobalAppConfig)
	InitLogAgs(&logAgs)
	callUrl = GetURL(endpoint)
	log := customlogger.GetLog(&logAgs, GlobalLoggingSettings)

	hostName, err = os.Hostname()
	if err != nil {
		hostName = "env {hostnameEnvVar} is not set"
	}

	httpsWraperData, err := getHTTPSWraperData()
	requestID = httpsWraperData.RequestID
	transactionTimeout = httpsWraperData.TransactionTimeout
	transactionID = httpsWraperData.TransactionId
	if err != nil {
		log.Debug("Warning: ", err)
	}

	count := int(GlobalAppConfig.GetInt64("Server.RetryCount", 10))
	timeout := time.Duration(int(GlobalAppConfig.GetInt64("Server.RetryTimeoutMillisecs", 500))) * time.Millisecond
	status := ReturnCodeEwsError
	for count >= 0 {
		status = ExtensionProcessing(endpoint, t, start, log)
		if status == ReturnCodeOK {
			return status
		}

		if count >= 0 {
			log.Debug("Warning: sleep 500 ms before request will be restarted. Try: ", count)
			count--
			time.Sleep(timeout)
		}
	}
	return status
}

//export CallExtension1
func CallExtension1(t *C.CONTROL_INFO) int {
	return ExtensionWrapperRunner("delta_extension_1", unsafe.Pointer(t))
}

//export CallExtension2
func CallExtension2(t *C.CONTROL_INFO_INC) int {
	return ExtensionWrapperRunner("delta_extension_2", unsafe.Pointer(t))
}

func GetURL(path string) string {
	host := GlobalAppConfig.GetValue("Server.Host", "localhost")
	port := GlobalAppConfig.GetValue("Server.Port", "8088")
	httpPrefix := "http"
	if GlobalAppConfig.GetBool("Https.Enable", false) {
		httpPrefix = "https"
	}
	url := httpPrefix + "://" + host + ":" + port + "/" + path
	return url
}

func getAuthCredentials() (user string, password string, err error) {
	storagePath := GlobalAppConfig.GetValue("Auth.StoragePath", "/app/authstorage.json")
	newJSONConfigSource, err := appconfig.NewJsonConfigSource(storagePath)
	if err != nil {
		return user, password, err
	}

	authStorage := appconfig.NewOrderedAppConfig().
		AddSource(appconfig.NewCommandLineConfigSource(os.Args)).
		AddSource(appconfig.NewEnvironmentConfigSource("")).
		AddSource(newJSONConfigSource)

	user = authStorage.GetValue("User", "")
	password = authStorage.GetValue("Password", "")

	return user, password, nil
}

func sendJSON(buf []byte) ([]byte, error) {

	metaData, err := GetExtAdapterMetaDataString()
	if err != nil {
		return []byte{}, fmt.Errorf("can't get extension adapter metadata: %v ", err)
	}

	request, err := http.NewRequest(http.MethodPost, callUrl, bytes.NewBuffer(buf))
	if err != nil {
		return []byte{}, err
	}
	request.Header.Add("X-MTV-CallUrl", callUrl)
	request.Header.Add("X-MTV-RequestId", requestID)
	request.Header.Add("Content-Type", contentType)
	request.Header.Add("ExtAdapter-MetaData", metaData)
	request.Header.Add("X-MTV-TransactionId", transactionID)
	request.Header.Add("X-MTV-TransactionTimeout", strconv.Itoa(int(transactionTimeout/time.Second)))

	var tr *http.Transport
	if GlobalAppConfig.GetBool("Https.Enable", false) {
		fmt.Fprintf(os.Stderr, "Using https\n")
		certPool := x509.NewCertPool()
		certPath := GlobalAppConfig.GetValue("Https.CertPath", "")
		if certPath != "" {
			cert, err := os.ReadFile(certPath)
			if err != nil {
				return []byte{}, err
			}
			if ok := certPool.AppendCertsFromPEM(cert); !ok {
				return []byte{}, errors.New("failed to add custom certificate")
			}
		}
		tr = &http.Transport{
			TLSClientConfig: &tls.Config{
				RootCAs:            certPool,
				InsecureSkipVerify: true,
			},
		}
	} else {
		tr = http.DefaultTransport.(*http.Transport).Clone()
	}

	if GlobalAppConfig.GetBool("Auth.Enable", false) {
		user, pass, err := getAuthCredentials()
		if err != nil {
			return []byte{}, fmt.Errorf("error then config read: %v", err)
		}

		if user == "" || pass == "" {
			return []byte{}, errors.New("user or password is not setted")
		}
		request.SetBasicAuth(user, pass)
	}

	tr.DisableKeepAlives = true
	//tr.IdleConnTimeout = time.Millisecond * 100
	c := &http.Client{
		Transport: tr,
	}
	start := time.Now()
	resp, err := c.Do(request)
	duration := time.Since(start)
	elapsedMsEWS = int(duration.Milliseconds())

	if err != nil {
		return []byte{}, err
	}
	defer func(Body io.ReadCloser) {
		Body.Close()
	}(resp.Body)

	response, err := io.ReadAll(resp.Body)
	if err != nil {
		switch err {
		case io.EOF:
			return []byte{}, responseEOF
		case io.ErrUnexpectedEOF:
			return []byte{}, responseUnexpectedEOF
		default:
			return []byte{}, fmt.Errorf("failed to read response, status code: %v", err)
		}
	}

	httpStatusCode = resp.StatusCode
	if resp.StatusCode == http.StatusNotImplemented {
		bodyString := strings.TrimRight(string(response), "\n")
		return []byte{}, fmt.Errorf("%s, status code: %v", bodyString, resp.StatusCode)
	} else if resp.StatusCode == http.StatusBadGateway {
		errorString := strings.TrimRight(string(response), "\n")
		if errorString == "EOF" {
			return []byte{}, responseEOF
		} else {
			return []byte{}, fmt.Errorf(" %s, status code: %v", errorString, resp.StatusCode)
		}
	} else if resp.StatusCode != http.StatusOK {
		errorString := strings.TrimRight(string(response), "\n")
		return []byte{}, fmt.Errorf(" %s, status code: %v", errorString, resp.StatusCode)
	}

	return response, err
}

func getConfig(path string) error {
	var err error
	err = nil
	newJSONConfigSource, err := appconfig.NewJsonConfigSource(path)

	GlobalAppConfig = appconfig.NewOrderedAppConfig().
		AddSource(appconfig.NewCommandLineConfigSource(os.Args)).
		AddSource(appconfig.NewEnvironmentConfigSource("")).
		AddSource(newJSONConfigSource)

	return err
}

func loggingInitialize(appConfig appconfig.AppConfig) {
	GlobalLoggingSettings = customlogger.GetLoggingSettings(
		appConfig.GetValue("Logging.File.File", "/tmp/extserver-[TS].log"),
		"", //appConfig.GetValue("LogFormat", ""),
		appConfig.GetValue("Logging.File.LogLevel", "Information"),
		appConfig.GetValue("Logging.Console.LogLevel", "Information"),
		appConfig.GetValue("Logging.File.TimestampPattern", "[TS]"),
		appConfig.GetValue("Logging.File.TimestampFormat", "yyyy-MM-dd"),
		appConfig.GetBool("Logging.File.UseTimestamp", true),
		false, //appConfig.GetBool("Logging.File.Tracing", false),
		true,  //appConfig.GetBool("LogUsingConsoleWriteln", true),
		false, //appConfig.GetBool("UseAsyncLog", false),
		0,     //int(appConfig.GetInt64("AsyncLogBufferSize", 0)),
	)
}

func main() {}
