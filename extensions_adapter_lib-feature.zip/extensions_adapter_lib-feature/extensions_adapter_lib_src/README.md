Build:

make all

Artifacts:

libextclient.so

For run tests set LD_LIBRARY_PATH for libextclient.so

export LD_LIBRARY_PATH=/home/user/work/extension_adapter_all/extensions_adapter_lib/extensions_adapter_lib_src/bin:$LD_LIBRARY_PATH

Configuration files:

Config file example:
```
{
    "Server": {
        "Host": "<server_host>",
        "Port": "<server_port>"
    },
    "Logging": {
        "Console": {
            "LogLevel": "<log_level>"
        },
        "File": {
            "LogLevel": "<log_level>,
            "UseTimestamp": <use_ts_flag>,
            "TimestampPattern": "[<ts_pattern>]",
            "TimestampFormat": "<format>",
            "File": "<path_to_log_file>"
        }
    },
    "Https": {
        "Enable": <is_enable_flag>,
        "CertPath": "<path_to_cert>"
    },
    "Auth": {
        "Enable": <is_enable_flag>,
        "User": "<user>",
        "Password": "<password>"
    }
}
```

Parameters description:
1. Server - server parameters section;
    1.1 Host - server address;
    1.2 Port - port that the server listens to;
2. Logging - logging parameters section;
    2.1 Console - console logging parameters section;
        2.1.1 LogLevel - console logging level;
    2.2 File - file logging parameters section;
        2.2.1 LogLevel - file logging level;
        2.2.2 UseTimestamp - using timestamp in logging file name;
        2.2.3 TimestampPattern - timestamp pattern in logging file name;
        2.2.4 TimestampFormat - timestamp format in logging file name;
        2.2.5 File - log file path;
3. Https - https parameters section;
    3.1 Enable - enable/disable using https;
    3.2 CertPath - path to certificate. If no path is specified, system
        certificates will be used;
4. Auth - authentication parameters section;
    4.1 Enable - enable/disable using authentication;
    4.2 User - user name;
    4.3 Password - user password.

