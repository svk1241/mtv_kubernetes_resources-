#include "generator.h"
#include "../ddext/ddext1.h"
#include "../ddext/ddext2.h"
#include <string.h>
#include <stdio.h>


static void CreateControlIncInformation(CONTROL_INFO_INC* pCtl, int nServices, int nSubMemberRecords)
{
    COPY(           pCtl->user_id, generator(sizeof(pCtl->user_id)));// pLoginInfo->l000l01.user_id_001);
    COPY(           pCtl->password, generator(sizeof(pCtl->password)));// pLoginInfo->l000l01.password_001);
    pCtl->service_line_cnt = nServices;
    pCtl->subscriber_member_cnt = nSubMemberRecords;
    COPY(           pCtl->process_real_time, generator(sizeof(pCtl->process_real_time)));// pRealTime->l001l01.flag_002);
    pCtl->call_was_successful[0] = 'N';
}

static void CreateClaimHeaderInc(CLAIM_HEADER_INC* pHeader)
{
	COPY(pHeader->claim_id, generator(sizeof(pHeader->claim_id)));//					pClaim->l002l01.claim_identifier_003);
	COPY(pHeader->mbr_bus_lev_4_id, generator(sizeof(pHeader->mbr_bus_lev_4_id)));//			pClaim->l002l01.business_level_4_id_003);
	COPY(pHeader->mbr_bus_lev_5_id, generator(sizeof(pHeader->mbr_bus_lev_5_id)));//			pClaim->l002l01.business_level_5_id_003);
	COPY(pHeader->mbr_bus_lev_6_id, generator(sizeof(pHeader->mbr_bus_lev_6_id)));//			pClaim->l002l01.business_level_6_id_003);
	COPY(pHeader->mbr_bus_lev_7_id, generator(sizeof(pHeader->mbr_bus_lev_7_id)));//			pClaim->l002l01.business_level_7_id_003);
	ASSIGN(pHeader->birth_date, generator(sizeof(pHeader->birth_date)));//				pClaim->l002l01.birth_date_003);
}

static void CreateDeltaServiceLinesInc(int nServices, SERVICE_LINE_INC* pLine)
{
	int d =	0;
	int i;

	for (i = 0; i < nServices; ++i) {
		COPYID(d, i,                pLine->benefit_pkg_id, generator(sizeof(pLine->benefit_pkg_id)));//					pServiceLine->l003l01.l005l02.benefit_package_identifier_006);
		COPYID(d, i,                pLine->emp_grp_lev_1_id, generator(sizeof(pLine->emp_grp_lev_1_id)));//				pServiceLine->l003l01.l006l02.employer_group_level_1_id_008);
		COPYID(d, i,                pLine->emp_grp_lev_2_id, generator(sizeof(pLine->emp_grp_lev_2_id)));//				pServiceLine->l003l01.l006l02.employer_group_level_2_id_009);
		ASSIGNID(d, i,            pLine->from_date, generator(sizeof(pLine->from_date)));//						pServiceLine->l003l01.l005l02.from_date_004);
		ASSIGNID(d, i,            pLine->hire_date, generator(sizeof(pLine->hire_date)));//						pServiceLine->l003l01.l010l02.hire_date_011);
		COPYID(d, i,                pLine->incent_rule_id, generator(sizeof(pLine->incent_rule_id)));//				    pServiceLine->l003l01.l011l02.incentive_rule_identifier_013);
		ASSIGNID(d, i,            pLine->incent_lev_cnt, generator(sizeof(pLine->incent_lev_cnt)));//                 pServiceLine->l003l01.l011l02.incentive_level_count_014);
		COPYID(d, i,                pLine->proc_class_code, generator(sizeof(pLine->proc_class_code)));//				pServiceLine->l003l01.l005l02.procedure_class_code_006);
		COPYID(d, i,                pLine->proc_code_id, generator(sizeof(pLine->proc_code_id)));//					pServiceLine->l003l01.l005l02.procedure_code_identifier_005);
		COPYID(d, i,                pLine->incent_sub_mbr_ind, generator(sizeof(pLine->incent_sub_mbr_ind)));// 			pServiceLine->l003l01.l011l02.subscriber_member_indicato_014);
		COPYID(d, i,                pLine->svc_line_expl_code, generator(sizeof(pLine->svc_line_expl_code)));//				pServiceLine->l003l01.l007l02.l009l03.explanation_code_010);
		ASSIGNID_itos(d, i,          pLine->svc_line_expl_code_cnt, generator(sizeof(pLine->svc_line_expl_code_cnt)));//		pServiceLine->l003l01.l007l02.l008l02.import_nested_grp_claim__002ma);
		ASSIGNID(d, i,            pLine->svc_line_num, generator(sizeof(pLine->svc_line_num)));//					pServiceLine->l003l01.l005l02.service_number_004);
		ASSIGNID(d, i,            pLine->thru_date, generator(sizeof(pLine->thru_date)));//						pServiceLine->l003l01.l005l02.thru_date_004);
		COPYID(d, i,                pLine->treatment_type_code, generator(sizeof(pLine->treatment_type_code)));//			pServiceLine->l003l01.l005l02.treatment_type_code_005);
		COPYID(d, i,                pLine->incent_util_flag, generator(sizeof(pLine->incent_util_flag)));//   			pServiceLine->l003l01.l011l02.utilization_based_flag_014);
		COPYID(d, i,                pLine->svc_prov_id, generator(sizeof(pLine->svc_prov_id)));//   					pServiceLine->l003l01.l006l02.svc_provider_id_009);
		COPYID(d, i,                pLine->svc_prov_role_code, generator(sizeof(pLine->svc_prov_role_code)));//   			pServiceLine->l003l01.l006l02.svc_provider_role_code_009);
		COPYID(d, i,                pLine->svc_prov_network_id, generator(sizeof(pLine->svc_prov_network_id)));//   			pServiceLine->l003l01.l006l02.svc_prov_network_identifie_010);
		COPYID(d, i,                pLine->svc_prov_status_code, generator(sizeof(pLine->svc_prov_status_code)));//   			pServiceLine->l003l01.l006l02.svc_prov_status_code_010);
		COPYID(d, i,                pLine->npf_prod_code, generator(sizeof(pLine->npf_prod_code)));//   				pServiceLine->l003l01.l012l02.product_code_016);
		COPYID(d, i,                pLine->grp_prov_id, generator(sizeof(pLine->grp_prov_id)));//   					pServiceLine->l003l01.l013l02.group_provider_id_017);
		++pLine;
	}
}


static void CreateSubMemberRecordInc(int nSubMemberRecords, SUBSCRIBER_MEMBER* pRecord)
{
	int i;
	int j;
	int k;

	for (i = 0; i < nSubMemberRecords; ++i) {
		ASSIGNI_itos(i, pRecord->benefit_counter_cnt,	 generator(sizeof(pRecord->benefit_counter_cnt)));//                                         pSubscriberMember->l012l01.l027l02.l028l02.import_g_benefit_counter_007ma);
		for (j = 0; j < 2; ++j) {
		    ASSIGNI(j,           pRecord->benefit_counter[j].date, generator(sizeof(pRecord->benefit_counter[j].date)));//		                          pSubscriberMember->l012l01.l027l02.l029l03.counter_date_028[i]);
		    COPYI(j,             pRecord->benefit_counter[j].id, generator(sizeof(pRecord->benefit_counter[j].id)));//                                  pSubscriberMember->l012l01.l027l02.l029l03.identifier_028[i]);
		}
		COPYI(i,		 pRecord->sub_mbr_ind, generator(sizeof(pRecord->sub_mbr_ind)));//                                                    pSubscriberMember->l012l01.l014l02.select_char_015);
		ASSIGNI_itos(i, pRecord->member_coverage_cnt, generator(sizeof(pRecord->member_coverage_cnt)));//                                             pSubscriberMember->l012l01.l020l02.l021l02.import_g_othr_mem_cov_hi_005ma);

		COPYI(i,        pRecord->member_coverage[0].contract_id, generator(sizeof(pRecord->member_coverage[0].contract_id)));//                                        pSubscriberMember->l012l01.l015l02.contract_id_3_016);
		COPYI(i,		 pRecord->member_coverage[0].mbr_id, generator(sizeof(pRecord->member_coverage[0].mbr_id)));//                                            pSubscriberMember->l012l01.l015l02.member_id_016);
		ASSIGNI(i, 		 pRecord->member_coverage[0].start_date, generator(sizeof(pRecord->member_coverage[0].start_date)));//                                        pSubscriberMember->l012l01.l015l02.user_defined_date_1_016);
		COPYI(i,		 pRecord->member_coverage[0].mbr_incent_level, generator(sizeof(pRecord->member_coverage[0].mbr_incent_level)));//                                  pSubscriberMember->l012l01.l015l02.incentive_level_016);
		ASSIGNI_itos(i, pRecord->member_coverage[0].eligibility_coverage_cnt, generator(sizeof(pRecord->member_coverage[0].eligibility_coverage_cnt)));//                           pSubscriberMember->l012l01.l016l02.l017l02.import_nested_g_prim_mem_004ma);
		for (j = 0; j < 2; ++j) {
			COPYI(j,        pRecord->member_coverage[0].eligibility_coverage[j].bus_lev_4_id, generator(sizeof(pRecord->member_coverage[0].eligibility_coverage[j].bus_lev_4_id)));//          pSubscriberMember->l012l01.l016l02.l018l03.business_level_4_id_017[i]);
			COPYI(j,        pRecord->member_coverage[0].eligibility_coverage[j].bus_lev_5_id, generator(sizeof(pRecord->member_coverage[0].eligibility_coverage[j].bus_lev_5_id)));//          pSubscriberMember->l012l01.l016l02.l018l03.business_level_5_id_017[i]);
			COPYI(j,        pRecord->member_coverage[0].eligibility_coverage[j].bus_lev_6_id, generator(sizeof(pRecord->member_coverage[0].eligibility_coverage[j].bus_lev_6_id)));//          pSubscriberMember->l012l01.l016l02.l018l03.business_level_6_id_017[i]);
			COPYI(j,        pRecord->member_coverage[0].eligibility_coverage[j].bus_lev_7_id, generator(sizeof(pRecord->member_coverage[0].eligibility_coverage[j].bus_lev_7_id)));//          pSubscriberMember->l012l01.l016l02.l018l03.business_level_7_id_017[i]);
			COPYI(j,        pRecord->member_coverage[0].eligibility_coverage[j].class_code, generator(sizeof(pRecord->member_coverage[0].eligibility_coverage[j].class_code)));//            pSubscriberMember->l012l01.l016l02.l018l03.class_code_017[i]);
			COPYI(j,        pRecord->member_coverage[0].eligibility_coverage[j].benefit_pkg, generator(sizeof(pRecord->member_coverage[0].eligibility_coverage[j].benefit_pkg)));//           pSubscriberMember->l012l01.l016l02.l018l03.benefit_package_identifier_018[i]);
			ASSIGNI(j,      pRecord->member_coverage[0].eligibility_coverage[j].eff_date, generator(sizeof(pRecord->member_coverage[0].eligibility_coverage[j].eff_date)));//              pSubscriberMember->l012l01.l016l02.l019l03.effective_date_019[i]);
			ASSIGNI(j,      pRecord->member_coverage[0].eligibility_coverage[j].end_date, generator(sizeof(pRecord->member_coverage[0].eligibility_coverage[j].end_date)));//              pSubscriberMember->l012l01.l016l02.l019l03.end_date_019[i]);
			COPYI(j,		  pRecord->member_coverage[0].eligibility_coverage[j].emp_grp_lev_1_id, generator(sizeof(pRecord->member_coverage[0].eligibility_coverage[j].emp_grp_lev_1_id)));//      pSubscriberMember->l012l01.l016l02.l019l03.employer_group_level_1_id_020[i]);
			COPYI(j,		  pRecord->member_coverage[0].eligibility_coverage[j].emp_grp_lev_2_id, generator(sizeof(pRecord->member_coverage[0].eligibility_coverage[j].emp_grp_lev_2_id)));//      pSubscriberMember->l012l01.l016l02.l019l03.employer_group_level_2_id_021[i]);
			COPYI(j,	 	  pRecord->member_coverage[0].eligibility_coverage[j].emp_class_code, generator(sizeof(pRecord->member_coverage[0].eligibility_coverage[j].emp_class_code)));//        pSubscriberMember->l012l01.l016l02.l019l03.employment_class_code_021[i]);
		}
		for (j = 1; j < 2; ++j) {
			COPYI(j - 1,        pRecord->member_coverage[j].contract_id, generator(sizeof(pRecord->member_coverage[j].contract_id)));//                               pSubscriberMember->l012l01.l020l02.l022l03.contract_id_3_022[i]);
			COPYI(j - 1,        pRecord->member_coverage[j].mbr_id, generator(sizeof(pRecord->member_coverage[j].mbr_id)));//                                    pSubscriberMember->l012l01.l020l02.l022l03.member_id_022[i]);
			COPYI(j - 1,        pRecord->member_coverage[j].mbr_incent_level, generator(sizeof(pRecord->member_coverage[j].mbr_incent_level)));//                          pSubscriberMember->l012l01.l020l02.l022l03.incentive_level_022[i]);
			ASSIGNI(j - 1,      pRecord->member_coverage[j].start_date, generator(sizeof(pRecord->member_coverage[j].start_date)));//                                pSubscriberMember->l012l01.l020l02.l022l03.user_defined_date_1_022[i]);
			ASSIGNI_itos(j - 1, pRecord->member_coverage[j].eligibility_coverage_cnt, generator(sizeof(pRecord->member_coverage[j].eligibility_coverage_cnt)));//                  pSubscriberMember->l012l01.l020l02.l023l03.l024l03.import_nested_g_othr_mem_006ma[i]);
			for (k = 0; k < 2; ++k) {
				COPYI(k,        pRecord->member_coverage[j].eligibility_coverage[k].bus_lev_4_id, generator(sizeof(pRecord->member_coverage[j].eligibility_coverage[k].bus_lev_4_id)));//     pSubscriberMember->l012l01.l020l02.l023l03.l025l04.business_level_4_id_023[i][j - 1]);
				COPYI(k,        pRecord->member_coverage[j].eligibility_coverage[k].bus_lev_5_id, generator(sizeof(pRecord->member_coverage[j].eligibility_coverage[k].bus_lev_5_id)));//     pSubscriberMember->l012l01.l020l02.l023l03.l025l04.business_level_5_id_023[i][j - 1]);
				COPYI(k,        pRecord->member_coverage[j].eligibility_coverage[k].bus_lev_6_id, generator(sizeof(pRecord->member_coverage[j].eligibility_coverage[k].bus_lev_6_id)));//     pSubscriberMember->l012l01.l020l02.l023l03.l025l04.business_level_6_id_023[i][j - 1]);
				COPYI(k,        pRecord->member_coverage[j].eligibility_coverage[k].bus_lev_7_id, generator(sizeof(pRecord->member_coverage[j].eligibility_coverage[k].bus_lev_7_id)));//     pSubscriberMember->l012l01.l020l02.l023l03.l025l04.business_level_7_id_023[i][j - 1]);
				COPYI(k,        pRecord->member_coverage[j].eligibility_coverage[k].class_code, generator(sizeof(pRecord->member_coverage[j].eligibility_coverage[k].class_code)));//       pSubscriberMember->l012l01.l020l02.l023l03.l025l04.class_code_023[i][j - 1]);
				COPYI(k,        pRecord->member_coverage[j].eligibility_coverage[k].benefit_pkg, generator(sizeof(pRecord->member_coverage[j].eligibility_coverage[k].benefit_pkg)));//      pSubscriberMember->l012l01.l020l02.l023l03.l025l04.benefit_package_identifier_024[i][j - 1]);
				ASSIGNI(k,      pRecord->member_coverage[j].eligibility_coverage[k].eff_date, generator(sizeof(pRecord->member_coverage[j].eligibility_coverage[k].eff_date)));//         pSubscriberMember->l012l01.l020l02.l023l03.l026l04.effective_date_025[i][j - 1]);
				ASSIGNI(k,      pRecord->member_coverage[j].eligibility_coverage[k].end_date, generator(sizeof(pRecord->member_coverage[j].eligibility_coverage[k].end_date)));//         pSubscriberMember->l012l01.l020l02.l023l03.l026l04.end_date_025[i][j - 1]);
				COPYI(k,        pRecord->member_coverage[j].eligibility_coverage[k].emp_class_code, generator(sizeof(pRecord->member_coverage[j].eligibility_coverage[k].emp_class_code)));//   pSubscriberMember->l012l01.l020l02.l023l03.l026l04.employment_class_code_027[i][j - 1]);
				COPYI(k,        pRecord->member_coverage[j].eligibility_coverage[k].emp_grp_lev_1_id, generator(sizeof(pRecord->member_coverage[j].eligibility_coverage[k].emp_grp_lev_1_id)));// pSubscriberMember->l012l01.l020l02.l023l03.l026l04.employer_group_level_1_id_026[i][j - 1]);
				COPYI(k,        pRecord->member_coverage[j].eligibility_coverage[k].emp_grp_lev_2_id, generator(sizeof(pRecord->member_coverage[j].eligibility_coverage[k].emp_grp_lev_2_id)));// pSubscriberMember->l012l01.l020l02.l023l03.l026l04.employer_group_level_2_id_027[i][j - 1]);
			}
		}
		++pRecord;
	}
}
