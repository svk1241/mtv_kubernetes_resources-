#include "generator.h"
#include "../ddext/ddext1.h"
#include "../ddext/ddext2.h"
#include <string.h>
#include <stdio.h>

static void CreateControlInformation(CONTROL_INFO* pCtl, int nServices, int nIgnored, int nHistory)
{
	COPY(           pCtl->adjudication_pass, generator(sizeof(pCtl->adjudication_pass)));
	COPY(           pCtl->process_real_time, generator(sizeof(pCtl->process_real_time)));
	COPY(           pCtl->user_id, generator(sizeof(pCtl->user_id)));
	COPY(           pCtl->password, generator(sizeof(pCtl->password)));
	pCtl->service_line_cnt = nServices;
	pCtl->ignored_service_line_cnt = nIgnored;
	pCtl->service_history_line_cnt = nHistory;
	pCtl->call_was_successful[0] = 'N';
}


static void CreateClaimHeader(CLAIM_HEADER* pHeader)
{
    COPY(		pHeader->auto_accident_flag,		   generator(sizeof(pHeader->auto_accident_flag)));
    COPY(		pHeader->billing_prov_id,			   generator(sizeof(pHeader->billing_prov_id)));
    COPY(		pHeader->billing_prov_spec_code,	   generator(sizeof(pHeader->billing_prov_spec_code)));
    COPY(		pHeader->billing_prov_type_code,	   generator(sizeof(pHeader->billing_prov_type_code)));
    COPY(		pHeader->cause_of_illness_code,		   generator(sizeof(pHeader->cause_of_illness_code)));
    COPY(		pHeader->caused_by_employment_flag,	   generator(sizeof(pHeader->caused_by_employment_flag)));
    COPY(		pHeader->claim_id,					   generator(sizeof(pHeader->claim_id)));
    COPY(		pHeader->coverage_contract_id,		   generator(sizeof(pHeader->coverage_contract_id)));
    COPY(		pHeader->diag_code_id,				   generator(sizeof(pHeader->diag_code_id)));
    ASSIGN_itos(pHeader->diag_code_id_cnt,			   generator(sizeof(pHeader->diag_code_id_cnt)));
    ASSIGN(		pHeader->mbr_birth_date,			   generator(sizeof(pHeader->mbr_birth_date)));
    COPY(		pHeader->mbr_bus_lev_4_id,			   generator(sizeof(pHeader->mbr_bus_lev_4_id)));
    COPY(		pHeader->mbr_bus_lev_5_id,			   generator(sizeof(pHeader->mbr_bus_lev_5_id)));
    COPY(		pHeader->mbr_bus_lev_6_id,			   generator(sizeof(pHeader->mbr_bus_lev_6_id)));
    COPY(		pHeader->mbr_bus_lev_7_id,			   generator(sizeof(pHeader->mbr_bus_lev_7_id)));
    COPY(		pHeader->mbr_id,					   generator(sizeof(pHeader->mbr_id)));
    COPY(		pHeader->mbr_state_code,			   generator(sizeof(pHeader->mbr_state_code)));
    COPY(		pHeader->mbr_zip,					   generator(sizeof(pHeader->mbr_zip)));
    COPY(		pHeader->other_accident_flag,		   generator(sizeof(pHeader->other_accident_flag)));
    COPY(		pHeader->person_id,					   generator(sizeof(pHeader->person_id)));
    COPY(		pHeader->predetermination_claim_flag,  generator(sizeof(pHeader->predetermination_claim_flag)));
    ASSIGN(		pHeader->total_charge,				   generator(sizeof(pHeader->total_charge)));
    ASSIGN(		pHeader->total_claim_svc_cnt,		   generator(sizeof(pHeader->total_claim_svc_cnt)));
    COPY(		pHeader->type,						   generator(sizeof(pHeader->type)));
}


static void CreateServiceLines(int nDirection, SERVICE_LINE* pLine)
{
	int i;
	int d = 0;

	for (i = 0; i < nDirection; ++i)
	{
        ASSIGNID(d, i,  pLine->allowed_amt, generator(sizeof(pLine->allowed_amt)));//						pServiceLine->l008l01.l010l02.allowed_amount_020);
        COPYID(d, i,    pLine->allowed_amt_is_zero, generator(sizeof(pLine->allowed_amt_is_zero)));//				pServiceLine->l008l01.l029l02.flag_076);
        COPYID(d, i,    pLine->allowed_expl_code,   generator(sizeof(pLine->allowed_expl_code)));//				pServiceLine->l008l01.l018l02.l020l03.explanation_code_048);
        ASSIGNID_itos(d, i, pLine->allowed_expl_code_cnt,   generator(sizeof(pLine->allowed_expl_code_cnt)));//		pServiceLine->l008l01.l018l02.l019l02.io_curr_nstd_grp_allowed_005ma);
        COPYID(d, i,    pLine->allowed_fee_sched_tab,   generator(sizeof(pLine->allowed_fee_sched_tab)));//			pServiceLine->l008l01.l010l02.allowed_fee_schedule_table_044);
        ASSIGNID(d, i,  pLine->anesthesia_units,    generator(sizeof(pLine->anesthesia_units)));//				pServiceLine->l008l01.l024l02.anesthesia_units_051);
        ASSIGNID(d, i,  pLine->approved_amt,    generator(sizeof(pLine->approved_amt)));//					pServiceLine->l008l01.l010l02.approved_amount_041);
        COPYID(d, i,    pLine->approved_amt_is_zero,    generator(sizeof(pLine->approved_amt_is_zero)));//			pServiceLine->l008l01.l030l02.flag_077);
        COPYID(d, i,    pLine->approved_expl_code,  generator(sizeof(pLine->approved_expl_code)));//				pServiceLine->l008l01.l021l02.l023l03.explanation_code_049);
        ASSIGNID_itos(d, i, pLine->approved_expl_code_cnt,  generator(sizeof(pLine->approved_expl_code_cnt)));//		pServiceLine->l008l01.l021l02.l022l02.io_curr_nstd_grp_approve_006ma);
        COPYID(d, i,    pLine->approved_fee_sched_tab,  generator(sizeof(pLine->approved_fee_sched_tab)));//			pServiceLine->l008l01.l010l02.approved_fee_schedule_tabl_043);
        COPYID(d, i,    pLine->benefit_pkg_id,  generator(sizeof(pLine->benefit_pkg_id)));//					pServiceLine->l008l01.l010l02.benefit_package_identifier_019);
        COPYID(d, i,    pLine->buccal_srf_ind,  generator(sizeof(pLine->buccal_srf_ind)));//					pServiceLine->l008l01.l024l02.buccal_surface_indicator_061);
        COPYID(d, i,    pLine->cas_audit_result,    generator(sizeof(pLine->cas_audit_result)));//				pServiceLine->l008l01.l028l02.cas_audit_result_075);
        COPYID(d, i,    pLine->cas_audit_rule_id,   generator(sizeof(pLine->cas_audit_rule_id)));//				pServiceLine->l008l01.l028l02.cas_audit_rule_id_075);
        COPYID(d, i,    pLine->cas_audit_tab_id,    generator(sizeof(pLine->cas_audit_tab_id)));//				pServiceLine->l008l01.l028l02.cas_audit_table_id_075);
        COPYID(d, i,    pLine->cas_proc_code_origin,    generator(sizeof(pLine->cas_proc_code_origin)));//			pServiceLine->l008l01.l010l02.cas_procedure_code_origin__025);
        COPYID(d, i,    pLine->cas_proc_code_pmt_stat,  generator(sizeof(pLine->cas_proc_code_pmt_stat)));//			pServiceLine->l008l01.l010l02.cas_proc_code_payment_stat_024);
        COPYID(d, i,    pLine->cas_repl_proc_code,  generator(sizeof(pLine->cas_repl_proc_code)));//				pServiceLine->l008l01.l010l02.cas_replacement_proc_code_023);
        COPYID(d, i,    pLine->cas_send_grp_ind,    generator(sizeof(pLine->cas_send_grp_ind)));//				pServiceLine->l008l01.l010l02.cas_send_group_indicator_022);
        ASSIGNID(d, i,  pLine->charge,  generator(sizeof(pLine->charge)));//							pServiceLine->l008l01.l010l02.charge_amount_012);
        COPYID(d, i,    pLine->coding_audit_required_flag,  generator(sizeof(pLine->coding_audit_required_flag)));//		pServiceLine->l008l01.l011l02.flag_045);
        ASSIGNID(d, i,  pLine->cross_ref_svc_num,   generator(sizeof(pLine->cross_ref_svc_num)));//				pServiceLine->l008l01.l010l02.cross_ref_service_number_031);
        COPYID(d, i,    pLine->diag_code_data_1_invalid,    generator(sizeof(pLine->diag_code_data_1_invalid)));//		pServiceLine->l008l01.l024l02.diagnosis_code_data_invali_068);
        COPYID(d, i,    pLine->diag_code_data_2_invalid,    generator(sizeof(pLine->diag_code_data_2_invalid)));//		pServiceLine->l008l01.l024l02.diagnosis_code_data_2_inva_069);
        COPYID(d, i,    pLine->diag_code_data_3_invalid,    generator(sizeof(pLine->diag_code_data_3_invalid)));//		pServiceLine->l008l01.l024l02.diagnosis_code_data_3_inva_070);
        COPYID(d, i,    pLine->diag_code_data_4_invalid,    generator(sizeof(pLine->diag_code_data_4_invalid)));//		pServiceLine->l008l01.l024l02.diagnosis_code_data_4_inva_071);
        COPYID(d, i,    pLine->diag_code_id_1,  generator(sizeof(pLine->diag_code_id_1)));//					pServiceLine->l008l01.l024l02.diagnosis_code_identifier_055);
        COPYID(d, i,    pLine->diag_code_id_2,  generator(sizeof(pLine->diag_code_id_2)));//					pServiceLine->l008l01.l024l02.diagnosis_code_id_2_055);
        COPYID(d, i,    pLine->diag_code_id_3,  generator(sizeof(pLine->diag_code_id_3)));//					pServiceLine->l008l01.l024l02.diagnosis_code_id_3_055);
        COPYID(d, i,    pLine->diag_code_id_4,  generator(sizeof(pLine->diag_code_id_4)));//					pServiceLine->l008l01.l024l02.diagnosis_code_id_4_055);
        COPYID(d, i,    pLine->distal_srf_ind,  generator(sizeof(pLine->distal_srf_ind)));//					pServiceLine->l008l01.l024l02.distal_surface_indicator_063);
        COPYID(d, i,    pLine->emp_grp_level_1_id,  generator(sizeof(pLine->emp_grp_level_1_id)));//				pServiceLine->l008l01.l024l02.employer_group_level_1_id_056);
        COPYID(d, i,    pLine->emp_grp_level_2_id,  generator(sizeof(pLine->emp_grp_level_2_id)));//				pServiceLine->l008l01.l024l02.employer_group_level_2_id_057);
        COPYID(d, i,    pLine->ext_pricing_flag,    generator(sizeof(pLine->ext_pricing_flag)));//				pServiceLine->l008l01.l010l02.external_pricing_flag_025);
        COPYID(d, i,    pLine->ext_pricing_fld_1,   generator(sizeof(pLine->ext_pricing_fld_1)));//				pServiceLine->l008l01.l010l02.external_pricing_field_1_026);
        COPYID(d, i,    pLine->ext_pricing_fld_2,   generator(sizeof(pLine->ext_pricing_fld_2)));//				pServiceLine->l008l01.l010l02.external_pricing_field_2_027);
        COPYID(d, i,    pLine->ext_pricing_fld_3,   generator(sizeof(pLine->ext_pricing_fld_3)));//				pServiceLine->l008l01.l010l02.external_pricing_field_3_028);
        COPYID(d, i,    pLine->ext_pricing_fld_4,   generator(sizeof(pLine->ext_pricing_fld_4)));//				pServiceLine->l008l01.l010l02.external_pricing_field_4_029);
        COPYID(d, i,    pLine->ext_pricing_fld_5,   generator(sizeof(pLine->ext_pricing_fld_5)));//				pServiceLine->l008l01.l010l02.external_pricing_field_5_030);
        COPYID(d, i,    pLine->facial_srf_ind,  generator(sizeof(pLine->facial_srf_ind)));//					pServiceLine->l008l01.l024l02.facial_surface_indicator_060);
        ASSIGNID(d, i,  pLine->from_date,   generator(sizeof(pLine->from_date)));//						pServiceLine->l008l01.l010l02.from_date_012);
        COPYID(d, i,    pLine->grp_prov_id, generator(sizeof(pLine->grp_prov_id)));//                     pServiceLine->l008l01.l031l02.group_provider_id_078);
        COPYID(d, i,    pLine->hcpcs_proc_code_data_invalid,    generator(sizeof(pLine->hcpcs_proc_code_data_invalid)));//	pServiceLine->l008l01.l010l02.hcpcs_proc_code_data_inval_034);
        COPYID(d, i,    pLine->hi_range_tooth_code, generator(sizeof(pLine->hi_range_tooth_code)));//				pServiceLine->l008l01.l024l02.hi_range_tooth_code_057);
        ASSIGNID(d, i,  pLine->hipaa_svc_line_num,  generator(sizeof(pLine->hipaa_svc_line_num)));//				pServiceLine->l008l01.l010l02.hipaa_service_line_num_025);
        COPYID(d, i,    pLine->incisal_srf_ind, generator(sizeof(pLine->incisal_srf_ind)));//					pServiceLine->l008l01.l024l02.incisal_surface_indicator_059);
        COPYID(d, i,    pLine->invalid_data,    generator(sizeof(pLine->invalid_data)));//					pServiceLine->l008l01.l010l02.invalid_data_exists_flag_032);
        COPYID(d, i,    pLine->lingual_srf_ind, generator(sizeof(pLine->lingual_srf_ind)));//					pServiceLine->l008l01.l024l02.lingual_surface_indicator_062);
        COPYID(d, i,    pLine->man_pay_approved_entered_flag,   generator(sizeof(pLine->man_pay_approved_entered_flag)));//	pServiceLine->l008l01.l010l02.man_pay_approved_entered_f_042);
        COPYID(d, i,    pLine->man_pmt_allowed_entered, generator(sizeof(pLine->man_pmt_allowed_entered)));//			pServiceLine->l008l01.l010l02.man_payment_allowed_entere_021);
        COPYID(d, i,    pLine->mbr_class_code,  generator(sizeof(pLine->mbr_class_code)));//					pServiceLine->l008l01.l024l02.member_class_code_057);
        COPYID(d, i,    pLine->mesial_srf_ind,  generator(sizeof(pLine->mesial_srf_ind)));//					pServiceLine->l008l01.l024l02.mesial_surface_indicator_064);
        COPYID(d, i,    pLine->mode_of_pay_code,    generator(sizeof(pLine->mode_of_pay_code)));//				pServiceLine->l008l01.l010l02.mode_of_pay_code_023);
        COPYID(d, i,    pLine->network_ind, generator(sizeof(pLine->network_ind)));//						pServiceLine->l008l01.l010l02.network_indicator_030);
        COPYID(d, i,    pLine->npf_bus_id,  generator(sizeof(pLine->npf_bus_id)));//                      pServiceLine->l008l01.l032l02.business_id_079);
        COPYID(d, i,    pLine->npf_hit_charge,  generator(sizeof(pLine->npf_hit_charge)));//					pServiceLine->l008l01.l010l02.external_pricing_ind_2_044);
        COPYID(d, i,    pLine->npf_lic_id,  generator(sizeof(pLine->npf_lic_id)));//                      pServiceLine->l008l01.l032l02.license_id_079);
        COPYID(d, i,    pLine->npf_lic_state,   generator(sizeof(pLine->npf_lic_state)));//                   pServiceLine->l008l01.l032l02.license_state_079);
        COPYID(d, i,    pLine->npf_mult_bus_flag,   generator(sizeof(pLine->npf_mult_bus_flag)));//               pServiceLine->l008l01.l032l02.multiple_business_flag_079);
        COPYID(d, i,    pLine->npf_mult_lic_flag,   generator(sizeof(pLine->npf_mult_lic_flag)));//               pServiceLine->l008l01.l032l02.multiple_license_flag_079);
        COPYID(d, i,    pLine->npf_office_id,   generator(sizeof(pLine->npf_office_id)));//                   pServiceLine->l008l01.l032l02.office_id_079);
        COPYID(d, i,    pLine->npf_owning_state,    generator(sizeof(pLine->npf_owning_state)));//                pServiceLine->l008l01.l032l02.owning_state_079);
        COPYID(d, i,    pLine->npf_priced_flag, generator(sizeof(pLine->npf_priced_flag)));//					pServiceLine->l008l01.l010l02.external_pricing_ind_1_044);
        COPYID(d, i,    pLine->npf_prod_code,   generator(sizeof(pLine->npf_prod_code)));//                   pServiceLine->l008l01.l032l02.product_code_079);
        COPYID(d, i,    pLine->npf_region,  generator(sizeof(pLine->npf_region)));//                      pServiceLine->l008l01.l032l02.region_079);
        COPYID(d, i,    pLine->npf_spec_code,   generator(sizeof(pLine->npf_spec_code)));//                   pServiceLine->l008l01.l032l02.specialty_079);
        COPYID(d, i,    pLine->occlusal_srf_ind,    generator(sizeof(pLine->occlusal_srf_ind)));//				pServiceLine->l008l01.l024l02.occlusal_surface_indicator_058);
        ASSIGNID(d, i,  pLine->oic_allowed_amt, generator(sizeof(pLine->oic_allowed_amt)));//					pServiceLine->l008l01.l010l02.oic_allowed_amount_025);
        ASSIGNID(d, i,  pLine->oic_paid_amt,    generator(sizeof(pLine->oic_paid_amt)));//					pServiceLine->l008l01.l010l02.oic_paid_amount_020);
        COPYID(d, i,    pLine->pay_to_prov_data_invalid,    generator(sizeof(pLine->pay_to_prov_data_invalid)));//		pServiceLine->l008l01.l024l02.pay_to_provider_data_inval_066);
        COPYID(d, i,    pLine->periodic_pmt_ind,    generator(sizeof(pLine->periodic_pmt_ind)));//				pServiceLine->l008l01.l010l02.periodic_payment_ind_012);
        COPYID(d, i,    pLine->place_of_svc_code_invalid,   generator(sizeof(pLine->place_of_svc_code_invalid)));//		pServiceLine->l008l01.l010l02.place_of_service_code_inva_040);
        COPYID(d, i,    pLine->practice_loc_id, generator(sizeof(pLine->practice_loc_id)));//                 pServiceLine->l008l01.l031l02.practice_location_id_078);
        COPYID(d, i,    pLine->pricing_rule_id, generator(sizeof(pLine->pricing_rule_id)));//					pServiceLine->l008l01.l010l02.pricing_rule_id_044);
        COPYID(d, i,    pLine->proc_cat_code,   generator(sizeof(pLine->proc_cat_code)));//					pServiceLine->l008l01.l010l02.procedure_category_code_020);
        COPYID(d, i,    pLine->proc_class_code, generator(sizeof(pLine->proc_class_code)));//					pServiceLine->l008l01.l010l02.procedure_class_code_019);
        COPYID(d, i,    pLine->proc_code_data_invalid,  generator(sizeof(pLine->proc_code_data_invalid)));//			pServiceLine->l008l01.l010l02.procedure_code_data_invali_033);
        COPYID(d, i,    pLine->proc_code_id,    generator(sizeof(pLine->proc_code_id)));//					pServiceLine->l008l01.l010l02.procedure_code_identifier_013);
        COPYID(d, i,    pLine->proc_mod_1_data_invalid, generator(sizeof(pLine->proc_mod_1_data_invalid)));//			pServiceLine->l008l01.l010l02.procedure_modifier_data_in_035);
        COPYID(d, i,    pLine->proc_mod_2_data_invalid, generator(sizeof(pLine->proc_mod_2_data_invalid)));//			pServiceLine->l008l01.l010l02.procedure_modifr_2_data_in_036);
        COPYID(d, i,    pLine->proc_mod_3_data_invalid, generator(sizeof(pLine->proc_mod_3_data_invalid)));//			pServiceLine->l008l01.l010l02.procedure_modifr_3_data_in_037);
        COPYID(d, i,    pLine->proc_mod_4_data_invalid, generator(sizeof(pLine->proc_mod_4_data_invalid)));//			pServiceLine->l008l01.l010l02.procedure_modifr_4_data_in_038);
        COPYID(d, i,    pLine->proc_mod_5_data_invalid, generator(sizeof(pLine->proc_mod_5_data_invalid)));//			pServiceLine->l008l01.l010l02.procedure_modifr_5_data_in_039);
        COPYID(d, i,    pLine->proc_mod_code_1, generator(sizeof(pLine->proc_mod_code_1)));//					pServiceLine->l008l01.l010l02.procedure_modifier_code_014);
        COPYID(d, i,    pLine->proc_mod_code_2, generator(sizeof(pLine->proc_mod_code_2)));//					pServiceLine->l008l01.l010l02.procedure_modifier_code_2_015);
        COPYID(d, i,    pLine->proc_mod_code_3, generator(sizeof(pLine->proc_mod_code_3)));//					pServiceLine->l008l01.l010l02.procedure_modifier_code_3_016);
        COPYID(d, i,    pLine->proc_mod_code_4, generator(sizeof(pLine->proc_mod_code_4)));//					pServiceLine->l008l01.l010l02.procedure_modifier_code_4_017);
        COPYID(d, i,    pLine->proc_mod_code_5, generator(sizeof(pLine->proc_mod_code_5)));//					pServiceLine->l008l01.l010l02.procedure_modifier_code_5_018);
        COPYID(d, i,    pLine->prov_bus_lev_4_id,   generator(sizeof(pLine->prov_bus_lev_4_id)));//				pServiceLine->l008l01.l027l02.business_level_4_id_074);
        COPYID(d, i,    pLine->prov_bus_lev_5_id,   generator(sizeof(pLine->prov_bus_lev_5_id)));//				pServiceLine->l008l01.l027l02.business_level_5_id_074);
        COPYID(d, i,    pLine->prov_bus_lev_6_id,   generator(sizeof(pLine->prov_bus_lev_6_id)));//				pServiceLine->l008l01.l027l02.business_level_6_id_074);
        COPYID(d, i,    pLine->prov_bus_lev_7_id,   generator(sizeof(pLine->prov_bus_lev_7_id)));//				pServiceLine->l008l01.l027l02.business_level_7_id_074);
        COPYID(d, i,    pLine->prov_postal_cross_ref,   generator(sizeof(pLine->prov_postal_cross_ref)));//			pServiceLine->l008l01.l026l02.postal_cross_reference_073);
        COPYID(d, i,    pLine->prov_postal_region,  generator(sizeof(pLine->prov_postal_region)));//				pServiceLine->l008l01.l026l02.postal_region_073);
        COPYID(d, i,    pLine->prov_state_code, generator(sizeof(pLine->prov_state_code)));//					pServiceLine->l008l01.l025l02.state_code_072);
        COPYID(d, i,    pLine->prov_zip,    generator(sizeof(pLine->prov_zip)));//						pServiceLine->l008l01.l025l02.zip_072);
        ASSIGNID(d, i,  pLine->seq_num, generator(sizeof(pLine->seq_num)));//							pServiceLine->l008l01.l010l02.sequence_number_012);
        COPYID(d, i,    pLine->status_expl, generator(sizeof(pLine->status_expl)));//						pServiceLine->l008l01.l010l02.status_explanation_018);
        COPYID(d, i,    pLine->status_ind,  generator(sizeof(pLine->status_ind)));//						pServiceLine->l008l01.l010l02.status_indicator_018);
        COPYID(d, i,    pLine->svc_facility_loc_data_invalid,   generator(sizeof(pLine->svc_facility_loc_data_invalid)));//	pServiceLine->l008l01.l010l02.svc_facility_loc_data_invl_041);
        COPYID(d, i,    pLine->svc_line_expl_code,  generator(sizeof(pLine->svc_line_expl_code)));//				pServiceLine->l008l01.l015l02.l017l03.explanation_code_047);
        ASSIGNID_itos(d, i, pLine->svc_line_expl_code_cnt,  generator(sizeof(pLine->svc_line_expl_code_cnt)));//		pServiceLine->l008l01.l015l02.l016l02.io_curr_nstd_grp_claim_e_004ma);
        ASSIGNID(d, i,  pLine->svc_line_num,    generator(sizeof(pLine->svc_line_num)));//					pServiceLine->l008l01.l010l02.service_number_012);
        COPYID(d, i,    pLine->svc_line_ovr_expl_code,  generator(sizeof(pLine->svc_line_ovr_expl_code)));//			pServiceLine->l008l01.l012l02.l014l03.explanation_code_046);
        ASSIGNID_itos(d, i,  pLine->svc_line_ovr_expl_code_cnt, generator(sizeof(pLine->svc_line_ovr_expl_code_cnt)));//	pServiceLine->l008l01.l012l02.l013l02.import_curr_nstd_grp_ove_003ma);
        ASSIGNID(d, i,  pLine->svc_mins,    generator(sizeof(pLine->svc_mins)));//						pServiceLine->l008l01.l010l02.service_minutes_count_020);
        COPYID(d, i,    pLine->svc_prov_class_code, generator(sizeof(pLine->svc_prov_class_code)));//				pServiceLine->l008l01.l024l02.svc_prov_class_code_052);
        COPYID(d, i,    pLine->svc_prov_data_invalid,   generator(sizeof(pLine->svc_prov_data_invalid)));//			pServiceLine->l008l01.l024l02.svc_provider_data_invalid__067);
        COPYID(d, i,    pLine->svc_prov_id, generator(sizeof(pLine->svc_prov_id)));//						pServiceLine->l008l01.l024l02.svc_provider_id_050);
        COPYID(d, i,    pLine->svc_prov_med_svc_area_code,  generator(sizeof(pLine->svc_prov_med_svc_area_code)));//		pServiceLine->l008l01.l024l02.svc_prov_med_svc_area_code_053);
        COPYID(d, i,    pLine->svc_prov_network_id, generator(sizeof(pLine->svc_prov_network_id)));//				pServiceLine->l008l01.l024l02.svc_prov_network_identifie_052);
        COPYID(d, i,    pLine->svc_prov_par_status_ind, generator(sizeof(pLine->svc_prov_par_status_ind)));//			pServiceLine->l008l01.l024l02.svc_prov_par_status_ind_065);
        COPYID(d, i,    pLine->svc_prov_region_code,    generator(sizeof(pLine->svc_prov_region_code)));//			pServiceLine->l008l01.l024l02.svc_prov_region_code_052);
        COPYID(d, i,    pLine->svc_prov_role_code,  generator(sizeof(pLine->svc_prov_role_code)));//				pServiceLine->l008l01.l024l02.svc_provider_role_code_051);
        COPYID(d, i,    pLine->svc_prov_spec_code,  generator(sizeof(pLine->svc_prov_spec_code)));//				pServiceLine->l008l01.l024l02.svc_prov_specialty_code_051);
        COPYID(d, i,    pLine->svc_prov_status_code,    generator(sizeof(pLine->svc_prov_status_code)));//			pServiceLine->l008l01.l024l02.svc_prov_status_code_052);
        COPYID(d, i,    pLine->svc_prov_svc_area_block_code,    generator(sizeof(pLine->svc_prov_svc_area_block_code)));//	pServiceLine->l008l01.l024l02.svc_prov_svc_area_block_co_054);
        COPYID(d, i,    pLine->svc_prov_type_code,  generator(sizeof(pLine->svc_prov_type_code)));//				pServiceLine->l008l01.l024l02.svc_prov_type_code_050);
        ASSIGNID(d, i,  pLine->svc_units,   generator(sizeof(pLine->svc_units)));//						pServiceLine->l008l01.l010l02.service_units_count_020);
        ASSIGNID(d, i,  pLine->tax_id,  generator(sizeof(pLine->tax_id)));//							pServiceLine->l008l01.l024l02.tax_identifier_050);
        ASSIGNID(d, i,  pLine->thru_date,   generator(sizeof(pLine->thru_date)));//						pServiceLine->l008l01.l010l02.thru_date_012);
        COPYID(d, i,    pLine->treatment_type_code, generator(sizeof(pLine->treatment_type_code)));//				pServiceLine->l008l01.l010l02.treatment_type_code_018);

		++pLine;
	}
}

static void CreateIgnoredServiceLine(int nIgnored, IGNORED_SERVICE_LINE* pLine)
{
	int i;

	for (i = 0; i < nIgnored; ++i)
	{
        ASSIGNI(i,  pLine->allowed_amt, generator(sizeof(pLine->allowed_amt)));//						pIgnoredLine->l033l01.l035l02.allowed_amount_088);
        COPYI(i,    pLine->allowed_expl_code, generator(sizeof(pLine->allowed_expl_code)));//				pIgnoredLine->l033l01.l039l02.l041l03.explanation_code_110);
        ASSIGNI_itos(i, pLine->allowed_expl_code_cnt, generator(sizeof(pLine->allowed_expl_code_cnt)));//		pIgnoredLine->l033l01.l039l02.l040l02.import_ignrd_nstd_grp_al_009ma);
        COPYI(i,    pLine->allowed_fee_sched_tab, generator(sizeof(pLine->allowed_fee_sched_tab)));//			pIgnoredLine->l033l01.l035l02.allowed_fee_schedule_table_108);
        ASSIGNI(i,  pLine->anesthesia_units, generator(sizeof(pLine->anesthesia_units)));//				pIgnoredLine->l033l01.l045l02.anesthesia_units_113);
        ASSIGNI(i,  pLine->approved_amt, generator(sizeof(pLine->approved_amt)));//					pIgnoredLine->l033l01.l035l02.approved_amount_105);
        COPYI(i,    pLine->approved_expl_code, generator(sizeof(pLine->approved_expl_code)));//				pIgnoredLine->l033l01.l042l02.l044l03.explanation_code_111);
        ASSIGNI_itos(i, pLine->approved_expl_code_cnt, generator(sizeof(pLine->approved_expl_code_cnt)));//		pIgnoredLine->l033l01.l042l02.l043l02.import_ignrd_nstd_grp_ap_010ma);
        COPYI(i,    pLine->approved_fee_sched_tab, generator(sizeof(pLine->approved_fee_sched_tab)));//			pIgnoredLine->l033l01.l035l02.approved_fee_schedule_tabl_107);
        COPYI(i,    pLine->benefit_pkg_id, generator(sizeof(pLine->benefit_pkg_id)));//					pIgnoredLine->l033l01.l035l02.benefit_package_identifier_087);
        COPYI(i,    pLine->buccal_srf_ind, generator(sizeof(pLine->buccal_srf_ind)));//					pIgnoredLine->l033l01.l045l02.buccal_surface_indicator_123);
        ASSIGNI(i,  pLine->charge, generator(sizeof(pLine->charge)));//							pIgnoredLine->l033l01.l035l02.charge_amount_080);
        ASSIGNI(i,  pLine->cross_ref_svc_num, generator(sizeof(pLine->cross_ref_svc_num)));//				pIgnoredLine->l033l01.l035l02.cross_ref_service_number_095);
        COPYI(i,    pLine->diag_code_data_1_invalid, generator(sizeof(pLine->diag_code_data_1_invalid)));//		pIgnoredLine->l033l01.l045l02.diagnosis_code_data_invali_130);
        COPYI(i,    pLine->diag_code_data_2_invalid, generator(sizeof(pLine->diag_code_data_2_invalid)));//		pIgnoredLine->l033l01.l045l02.diagnosis_code_data_2_inva_131);
        COPYI(i,    pLine->diag_code_data_3_invalid, generator(sizeof(pLine->diag_code_data_3_invalid)));//		pIgnoredLine->l033l01.l045l02.diagnosis_code_data_3_inva_132);
        COPYI(i,    pLine->diag_code_data_4_invalid, generator(sizeof(pLine->diag_code_data_4_invalid)));//		pIgnoredLine->l033l01.l045l02.diagnosis_code_data_4_inva_133);
        COPYI(i,    pLine->diag_code_id_1, generator(sizeof(pLine->diag_code_id_1)));//					pIgnoredLine->l033l01.l045l02.diagnosis_code_identifier_117);
        COPYI(i,    pLine->diag_code_id_2, generator(sizeof(pLine->diag_code_id_2)));//					pIgnoredLine->l033l01.l045l02.diagnosis_code_id_2_117);
        COPYI(i,    pLine->diag_code_id_3, generator(sizeof(pLine->diag_code_id_3)));//					pIgnoredLine->l033l01.l045l02.diagnosis_code_id_3_117);
        COPYI(i,    pLine->diag_code_id_4, generator(sizeof(pLine->diag_code_id_4)));//					pIgnoredLine->l033l01.l045l02.diagnosis_code_id_4_117);
        COPYI(i,    pLine->distal_srf_ind, generator(sizeof(pLine->distal_srf_ind)));//					pIgnoredLine->l033l01.l045l02.distal_surface_indicator_125);
        COPYI(i,    pLine->emp_grp_level_1_id, generator(sizeof(pLine->emp_grp_level_1_id)));//				pIgnoredLine->l033l01.l045l02.employer_group_level_1_id_118);
        COPYI(i,    pLine->emp_grp_level_2_id, generator(sizeof(pLine->emp_grp_level_2_id)));//				pIgnoredLine->l033l01.l045l02.employer_group_level_2_id_119);
        COPYI(i,    pLine->ext_pricing_flag, generator(sizeof(pLine->ext_pricing_flag)));//				pIgnoredLine->l033l01.l035l02.external_pricing_flag_089);
        COPYI(i,    pLine->ext_pricing_fld_1, generator(sizeof(pLine->ext_pricing_fld_1)));//				pIgnoredLine->l033l01.l035l02.external_pricing_field_1_090);
        COPYI(i,    pLine->ext_pricing_fld_2, generator(sizeof(pLine->ext_pricing_fld_2)));//				pIgnoredLine->l033l01.l035l02.external_pricing_field_2_091);
        COPYI(i,    pLine->ext_pricing_fld_3, generator(sizeof(pLine->ext_pricing_fld_3)));//				pIgnoredLine->l033l01.l035l02.external_pricing_field_3_092);
        COPYI(i,    pLine->ext_pricing_fld_4, generator(sizeof(pLine->ext_pricing_fld_4)));//				pIgnoredLine->l033l01.l035l02.external_pricing_field_4_093);
        COPYI(i,    pLine->ext_pricing_fld_5, generator(sizeof(pLine->ext_pricing_fld_5)));//				pIgnoredLine->l033l01.l035l02.external_pricing_field_5_094);
        COPYI(i,    pLine->facial_srf_ind, generator(sizeof(pLine->facial_srf_ind)));//					pIgnoredLine->l033l01.l045l02.facial_surface_indicator_122);
        ASSIGNI(i,  pLine->from_date, generator(sizeof(pLine->from_date)));//						pIgnoredLine->l033l01.l035l02.from_date_080);
        COPYI(i,    pLine->hcpcs_proc_code_data_invalid, generator(sizeof(pLine->hcpcs_proc_code_data_invalid)));//	pIgnoredLine->l033l01.l035l02.hcpcs_proc_code_data_inval_098);
        COPYI(i,    pLine->hi_range_tooth_code, generator(sizeof(pLine->hi_range_tooth_code)));//				pIgnoredLine->l033l01.l045l02.hi_range_tooth_code_119);
        ASSIGNI(i,  pLine->hipaa_svc_line_num, generator(sizeof(pLine->hipaa_svc_line_num)));//				pIgnoredLine->l033l01.l035l02.hipaa_service_line_num_089);
        COPYI(i,    pLine->incisal_srf_ind, generator(sizeof(pLine->incisal_srf_ind)));//					pIgnoredLine->l033l01.l045l02.incisal_surface_indicator_121);
        COPYI(i,    pLine->invalid_data, generator(sizeof(pLine->invalid_data)));//					pIgnoredLine->l033l01.l035l02.invalid_data_exists_flag_096);
        COPYI(i,    pLine->lingual_srf_ind, generator(sizeof(pLine->lingual_srf_ind)));//					pIgnoredLine->l033l01.l045l02.lingual_surface_indicator_124);
        COPYI(i,    pLine->man_pay_approved_entered_flag, generator(sizeof(pLine->man_pay_approved_entered_flag)));//	pIgnoredLine->l033l01.l035l02.man_pay_approved_entered_f_106);
        COPYI(i,    pLine->man_pmt_allowed_entered, generator(sizeof(pLine->man_pmt_allowed_entered)));//			pIgnoredLine->l033l01.l035l02.man_payment_allowed_entere_089);
        COPYI(i,    pLine->mbr_class_code, generator(sizeof(pLine->mbr_class_code)));//					pIgnoredLine->l033l01.l045l02.member_class_code_119);
        COPYI(i,    pLine->mesial_srf_ind, generator(sizeof(pLine->mesial_srf_ind)));//					pIgnoredLine->l033l01.l045l02.mesial_surface_indicator_126);
        COPYI(i,    pLine->mode_of_pay_code, generator(sizeof(pLine->mode_of_pay_code)));//				pIgnoredLine->l033l01.l035l02.mode_of_pay_code_089);
        COPYI(i,    pLine->network_ind, generator(sizeof(pLine->network_ind)));//						pIgnoredLine->l033l01.l035l02.network_indicator_094);
        COPYI(i,    pLine->npf_hit_charge, generator(sizeof(pLine->npf_hit_charge)));//					pIgnoredLine->l033l01.l035l02.external_pricing_ind_2_108);
        COPYI(i,    pLine->npf_priced_flag, generator(sizeof(pLine->npf_priced_flag)));//					pIgnoredLine->l033l01.l035l02.external_pricing_ind_1_108);
        COPYI(i,    pLine->occlusal_srf_ind, generator(sizeof(pLine->occlusal_srf_ind)));//				pIgnoredLine->l033l01.l045l02.occlusal_surface_indicator_120);
        ASSIGNI(i,  pLine->oic_allowed_amt, generator(sizeof(pLine->oic_allowed_amt)));//					pIgnoredLine->l033l01.l035l02.oic_allowed_amount_089);
        ASSIGNI(i,  pLine->oic_paid_amt, generator(sizeof(pLine->oic_paid_amt)));//					pIgnoredLine->l033l01.l035l02.oic_paid_amount_088);
        COPYI(i,    pLine->pay_to_prov_data_invalid, generator(sizeof(pLine->pay_to_prov_data_invalid)));//		pIgnoredLine->l033l01.l045l02.pay_to_provider_data_inval_128);
        COPYI(i,    pLine->periodic_pmt_ind, generator(sizeof(pLine->periodic_pmt_ind)));//				pIgnoredLine->l033l01.l035l02.periodic_payment_ind_080);
        COPYI(i,    pLine->place_of_svc_code_invalid, generator(sizeof(pLine->place_of_svc_code_invalid)));//		pIgnoredLine->l033l01.l035l02.place_of_service_code_inva_104);
        COPYI(i,    pLine->pricing_rule_id, generator(sizeof(pLine->pricing_rule_id)));//					pIgnoredLine->l033l01.l035l02.pricing_rule_id_108);
        COPYI(i,    pLine->proc_cat_code, generator(sizeof(pLine->proc_cat_code)));//					pIgnoredLine->l033l01.l035l02.procedure_category_code_088);
        COPYI(i,    pLine->proc_class_code, generator(sizeof(pLine->proc_class_code)));//					pIgnoredLine->l033l01.l035l02.procedure_class_code_087);
        COPYI(i,    pLine->proc_code_data_invalid, generator(sizeof(pLine->proc_code_data_invalid)));//			pIgnoredLine->l033l01.l035l02.procedure_code_data_invali_097);
        COPYI(i,    pLine->proc_code_id, generator(sizeof(pLine->proc_code_id)));//					pIgnoredLine->l033l01.l035l02.procedure_code_identifier_081);
        COPYI(i,    pLine->proc_mod_1_data_invalid, generator(sizeof(pLine->proc_mod_1_data_invalid)));//			pIgnoredLine->l033l01.l035l02.procedure_modifier_data_in_099);
        COPYI(i,    pLine->proc_mod_2_data_invalid, generator(sizeof(pLine->proc_mod_2_data_invalid)));//			pIgnoredLine->l033l01.l035l02.procedure_modifr_2_data_in_100);
        COPYI(i,    pLine->proc_mod_3_data_invalid, generator(sizeof(pLine->proc_mod_3_data_invalid)));//			pIgnoredLine->l033l01.l035l02.procedure_modifr_3_data_in_101);
        COPYI(i,    pLine->proc_mod_4_data_invalid, generator(sizeof(pLine->proc_mod_4_data_invalid)));//			pIgnoredLine->l033l01.l035l02.procedure_modifr_4_data_in_102);
        COPYI(i,    pLine->proc_mod_5_data_invalid, generator(sizeof(pLine->proc_mod_5_data_invalid)));//			pIgnoredLine->l033l01.l035l02.procedure_modifr_5_data_in_103);
        COPYI(i,    pLine->proc_mod_code_1, generator(sizeof(pLine->proc_mod_code_1)));//					pIgnoredLine->l033l01.l035l02.procedure_modifier_code_082);
        COPYI(i,    pLine->proc_mod_code_2, generator(sizeof(pLine->proc_mod_code_2)));//					pIgnoredLine->l033l01.l035l02.procedure_modifier_code_2_083);
        COPYI(i,    pLine->proc_mod_code_3, generator(sizeof(pLine->proc_mod_code_3)));//					pIgnoredLine->l033l01.l035l02.procedure_modifier_code_3_084);
        COPYI(i,    pLine->proc_mod_code_4, generator(sizeof(pLine->proc_mod_code_4)));//					pIgnoredLine->l033l01.l035l02.procedure_modifier_code_4_085);
        COPYI(i,    pLine->proc_mod_code_5, generator(sizeof(pLine->proc_mod_code_5)));//					pIgnoredLine->l033l01.l035l02.procedure_modifier_code_5_086);
        COPYI(i,    pLine->prov_bus_lev_4_id, generator(sizeof(pLine->prov_bus_lev_4_id)));//				pIgnoredLine->l033l01.l048l02.business_level_4_id_136);
        COPYI(i,    pLine->prov_bus_lev_5_id, generator(sizeof(pLine->prov_bus_lev_5_id)));//				pIgnoredLine->l033l01.l048l02.business_level_5_id_136);
        COPYI(i,    pLine->prov_bus_lev_6_id, generator(sizeof(pLine->prov_bus_lev_6_id)));//				pIgnoredLine->l033l01.l048l02.business_level_6_id_136);
        COPYI(i,    pLine->prov_bus_lev_7_id, generator(sizeof(pLine->prov_bus_lev_7_id)));//				pIgnoredLine->l033l01.l048l02.business_level_7_id_136);
        COPYI(i,    pLine->prov_postal_cross_ref, generator(sizeof(pLine->prov_postal_cross_ref)));//			pIgnoredLine->l033l01.l047l02.postal_cross_reference_135);
        COPYI(i,    pLine->prov_postal_region, generator(sizeof(pLine->prov_postal_region)));//				pIgnoredLine->l033l01.l047l02.postal_region_135);
        COPYI(i,    pLine->prov_state_code, generator(sizeof(pLine->prov_state_code)));//					pIgnoredLine->l033l01.l046l02.state_code_134);
        COPYI(i,    pLine->prov_zip, generator(sizeof(pLine->prov_zip)));//						pIgnoredLine->l033l01.l046l02.zip_134);
        ASSIGNI(i,  pLine->seq_num, generator(sizeof(pLine->seq_num)));//							pIgnoredLine->l033l01.l035l02.sequence_number_080);
        COPYI(i,    pLine->status_expl, generator(sizeof(pLine->status_expl)));//						pIgnoredLine->l033l01.l035l02.status_explanation_086);
        COPYI(i,    pLine->status_ind, generator(sizeof(pLine->status_ind)));//						pIgnoredLine->l033l01.l035l02.status_indicator_086);
        COPYI(i,    pLine->svc_facility_loc_data_invalid, generator(sizeof(pLine->svc_facility_loc_data_invalid)));//	pIgnoredLine->l033l01.l035l02.svc_facility_loc_data_invl_105);
        COPYI(i,    pLine->svc_line_expl_code, generator(sizeof(pLine->svc_line_expl_code)));//				pIgnoredLine->l033l01.l036l02.l038l03.explanation_code_109);
        ASSIGNI_itos(i, pLine->svc_line_expl_code_cnt, generator(sizeof(pLine->svc_line_expl_code_cnt)));//		pIgnoredLine->l033l01.l036l02.l037l02.import_ignrd_nstd_grp_cl_008ma);
        ASSIGNI(i,  pLine->svc_line_num, generator(sizeof(pLine->svc_line_num)));//	 				pIgnoredLine->l033l01.l035l02.service_number_080);
        ASSIGNI(i,  pLine->svc_mins, generator(sizeof(pLine->svc_mins)));//						pIgnoredLine->l033l01.l035l02.service_minutes_count_088);
        COPYI(i,    pLine->svc_prov_class_code, generator(sizeof(pLine->svc_prov_class_code)));//				pIgnoredLine->l033l01.l045l02.svc_prov_class_code_114);
        COPYI(i,    pLine->svc_prov_data_invalid, generator(sizeof(pLine->svc_prov_data_invalid)));//			pIgnoredLine->l033l01.l045l02.svc_provider_data_invalid__129);
        COPYI(i,    pLine->svc_prov_id, generator(sizeof(pLine->svc_prov_id)));//						pIgnoredLine->l033l01.l045l02.svc_provider_id_112);
        COPYI(i,    pLine->svc_prov_med_svc_area_code, generator(sizeof(pLine->svc_prov_med_svc_area_code)));//		pIgnoredLine->l033l01.l045l02.svc_prov_med_svc_area_code_115);
        COPYI(i,    pLine->svc_prov_network_id, generator(sizeof(pLine->svc_prov_network_id)));//				pIgnoredLine->l033l01.l045l02.svc_prov_network_identifie_114);
        COPYI(i,    pLine->svc_prov_par_status_ind, generator(sizeof(pLine->svc_prov_par_status_ind)));//			pIgnoredLine->l033l01.l045l02.svc_prov_par_status_ind_127);
        COPYI(i,    pLine->svc_prov_region_code, generator(sizeof(pLine->svc_prov_region_code)));//			pIgnoredLine->l033l01.l045l02.svc_prov_region_code_114);
        COPYI(i,    pLine->svc_prov_role_code, generator(sizeof(pLine->svc_prov_role_code)));//				pIgnoredLine->l033l01.l045l02.svc_provider_role_code_113);
        COPYI(i,    pLine->svc_prov_spec_code, generator(sizeof(pLine->svc_prov_spec_code)));//				pIgnoredLine->l033l01.l045l02.svc_prov_specialty_code_113);
        COPYI(i,    pLine->svc_prov_status_code, generator(sizeof(pLine->svc_prov_status_code)));//			pIgnoredLine->l033l01.l045l02.svc_prov_status_code_114);
        COPYI(i,    pLine->svc_prov_svc_area_block_code, generator(sizeof(pLine->svc_prov_svc_area_block_code)));//	pIgnoredLine->l033l01.l045l02.svc_prov_svc_area_block_co_116);
        COPYI(i,    pLine->svc_prov_type_code, generator(sizeof(pLine->svc_prov_type_code)));//				pIgnoredLine->l033l01.l045l02.svc_prov_type_code_112);
        ASSIGNI(i,  pLine->svc_units, generator(sizeof(pLine->svc_units)));//						pIgnoredLine->l033l01.l035l02.service_units_count_088);
        ASSIGNI(i,  pLine->tax_id, generator(sizeof(pLine->tax_id)));//							pIgnoredLine->l033l01.l045l02.tax_identifier_112);
        ASSIGNI(i,  pLine->thru_date, generator(sizeof(pLine->thru_date)));//						pIgnoredLine->l033l01.l035l02.thru_date_080);
        COPYI(i,    pLine->treatment_type_code, generator(sizeof(pLine->treatment_type_code)));//				pIgnoredLine->l033l01.l035l02.treatment_type_code_086);

		++pLine;
	}
}

static void CreateHistoryServiceLine(int nHistory, SERVICE_HISTORY_LINE* pLine)
{
	int i;

	for (i = 0; i < nHistory; ++i)
	{
		ASSIGNI(i,		pLine->allowed_amt, generator(sizeof(pLine->allowed_amt)));//					pHistoryLine->l049l01.l055l02.allowed_amount_149);
		COPYI(i,		pLine->allowed_expl_code, generator(sizeof(pLine->allowed_expl_code)));//			pHistoryLine->l049l01.l059l02.l061l03.explanation_code_151);
		ASSIGNI_itos(i,	pLine->allowed_expl_code_cnt, generator(sizeof(pLine->allowed_expl_code_cnt)));//		pHistoryLine->l049l01.l059l02.l060l02.import_hist_nstd_grp_all_014ma);
		ASSIGNI(i,		pLine->anesthesia_units, generator(sizeof(pLine->anesthesia_units)));//			pHistoryLine->l049l01.l065l02.anesthesia_units_154);
		ASSIGNI(i,		pLine->approved_amt, generator(sizeof(pLine->approved_amt)));//				pHistoryLine->l049l01.l055l02.approved_amount_149);
		COPYI(i,		pLine->approved_expl_code, generator(sizeof(pLine->approved_expl_code)));//			pHistoryLine->l049l01.l062l02.l064l03.explanation_code_152);
		ASSIGNI_itos(i,	pLine->approved_expl_code_cnt, generator(sizeof(pLine->approved_expl_code_cnt)));//		pHistoryLine->l049l01.l062l02.l063l02.import_hist_nstd_grp_app_015ma);
		COPYI(i,		pLine->auto_accident_flag, generator(sizeof(pLine->auto_accident_flag)));//			pHistoryLine->l049l01.l051l02.auto_accident_flag_139);
		COPYI(i,		pLine->benefit_pkg_id, generator(sizeof(pLine->benefit_pkg_id)));//				pHistoryLine->l049l01.l055l02.benefit_package_identifier_149);
		COPYI(i,		pLine->buccal_srf_ind, generator(sizeof(pLine->buccal_srf_ind)));//				pHistoryLine->l049l01.l065l02.buccal_surface_indicator_160);
		COPYI(i,		pLine->caused_by_employment_flag, generator(sizeof(pLine->caused_by_employment_flag)));//	pHistoryLine->l049l01.l051l02.caused_by_employment_flag_139);
		ASSIGNI(i,		pLine->charge, generator(sizeof(pLine->charge)));//						pHistoryLine->l049l01.l055l02.charge_amount_142);
		COPYI(i,		pLine->claim_id, generator(sizeof(pLine->claim_id)));//					pHistoryLine->l049l01.l051l02.claim_identifier_137);
		COPYI(i,		pLine->coverage_contract_id, generator(sizeof(pLine->coverage_contract_id)));//		pHistoryLine->l049l01.l051l02.coverage_contract_identifi_138);
		COPYI(i,		pLine->diag_code_id, generator(sizeof(pLine->diag_code_id)));//				pHistoryLine->l049l01.l052l02.l054l03.diagnosis_code_identifier_141);
		COPYI(i,		pLine->diag_code_id_1, generator(sizeof(pLine->diag_code_id_1)));//				pHistoryLine->l049l01.l065l02.diagnosis_code_identifier_156);
		COPYI(i,		pLine->diag_code_id_2, generator(sizeof(pLine->diag_code_id_2)));//				pHistoryLine->l049l01.l065l02.diagnosis_code_id_2_156);
		COPYI(i,		pLine->diag_code_id_3, generator(sizeof(pLine->diag_code_id_3)));//				pHistoryLine->l049l01.l065l02.diagnosis_code_id_3_156);
		COPYI(i,		pLine->diag_code_id_4, generator(sizeof(pLine->diag_code_id_4)));//				pHistoryLine->l049l01.l065l02.diagnosis_code_id_4_156);
		ASSIGNI_itos(i,	pLine->diag_code_id_cnt, generator(sizeof(pLine->diag_code_id_cnt)));//			pHistoryLine->l049l01.l052l02.l053l02.import_hist_nstd_grp_cla_012ma);
		COPYI(i,		pLine->distal_srf_ind, generator(sizeof(pLine->distal_srf_ind)));//				pHistoryLine->l049l01.l065l02.distal_surface_indicator_162);
		COPYI(i,		pLine->facial_srf_ind, generator(sizeof(pLine->facial_srf_ind)));//				pHistoryLine->l049l01.l065l02.facial_surface_indicator_159);
		ASSIGNI(i,		pLine->from_date, generator(sizeof(pLine->from_date)));//					pHistoryLine->l049l01.l055l02.from_date_142);
		COPYI(i,		pLine->hi_range_tooth_code, generator(sizeof(pLine->hi_range_tooth_code)));//			pHistoryLine->l049l01.l065l02.hi_range_tooth_code_156);
		COPYI(i,		pLine->incisal_srf_ind, generator(sizeof(pLine->incisal_srf_ind)));//				pHistoryLine->l049l01.l065l02.incisal_surface_indicator_158);
		COPYI(i,		pLine->lingual_srf_ind, generator(sizeof(pLine->lingual_srf_ind)));//				pHistoryLine->l049l01.l065l02.lingual_surface_indicator_161);
		COPYI(i,		pLine->mbr_bus_lev_4_id, generator(sizeof(pLine->mbr_bus_lev_4_id)));//			pHistoryLine->l049l01.l051l02.business_level_4_id_137);
		COPYI(i,		pLine->mbr_bus_lev_5_id, generator(sizeof(pLine->mbr_bus_lev_5_id)));//			pHistoryLine->l049l01.l051l02.business_level_5_id_137);
		COPYI(i,		pLine->mbr_bus_lev_6_id, generator(sizeof(pLine->mbr_bus_lev_6_id)));//			pHistoryLine->l049l01.l051l02.business_level_6_id_137);
		COPYI(i,		pLine->mbr_bus_lev_7_id, generator(sizeof(pLine->mbr_bus_lev_7_id)));//			pHistoryLine->l049l01.l051l02.business_level_7_id_137);
		COPYI(i,		pLine->mbr_class_code, generator(sizeof(pLine->mbr_class_code)));//				pHistoryLine->l049l01.l065l02.member_class_code_156);
		COPYI(i,		pLine->mbr_id, generator(sizeof(pLine->mbr_id)));//						pHistoryLine->l049l01.l051l02.member_identifier_138);
		COPYI(i,		pLine->mesial_srf_ind, generator(sizeof(pLine->mesial_srf_ind)));//				pHistoryLine->l049l01.l065l02.mesial_surface_indicator_163);
		COPYI(i,		pLine->occlusal_srf_ind, generator(sizeof(pLine->occlusal_srf_ind)));//			pHistoryLine->l049l01.l065l02.occlusal_surface_indicator_157);
		COPYI(i,		pLine->other_accident_flag, generator(sizeof(pLine->other_accident_flag)));//			pHistoryLine->l049l01.l051l02.other_accident_flag_139);
		COPYI(i,		pLine->proc_code_id, generator(sizeof(pLine->proc_code_id)));//				pHistoryLine->l049l01.l055l02.procedure_code_identifier_143);
		COPYI(i,		pLine->proc_mod_code_1, generator(sizeof(pLine->proc_mod_code_1)));//				pHistoryLine->l049l01.l055l02.procedure_modifier_code_144);
		COPYI(i,		pLine->proc_mod_code_2, generator(sizeof(pLine->proc_mod_code_2)));//				pHistoryLine->l049l01.l055l02.procedure_modifier_code_2_145);
		COPYI(i,		pLine->proc_mod_code_3, generator(sizeof(pLine->proc_mod_code_3)));//				pHistoryLine->l049l01.l055l02.procedure_modifier_code_3_146);
		COPYI(i,		pLine->proc_mod_code_4, generator(sizeof(pLine->proc_mod_code_4)));//				pHistoryLine->l049l01.l055l02.procedure_modifier_code_4_147);
		COPYI(i,		pLine->proc_mod_code_5, generator(sizeof(pLine->proc_mod_code_5)));//				pHistoryLine->l049l01.l055l02.procedure_modifier_code_5_148);
		COPYI(i,		pLine->prov_bus_lev_4_id, generator(sizeof(pLine->prov_bus_lev_4_id)));//			pHistoryLine->l049l01.l066l02.business_level_4_id_164);
		COPYI(i,		pLine->prov_bus_lev_5_id, generator(sizeof(pLine->prov_bus_lev_5_id)));//			pHistoryLine->l049l01.l066l02.business_level_5_id_164);
		COPYI(i,		pLine->prov_bus_lev_6_id, generator(sizeof(pLine->prov_bus_lev_6_id)));//			pHistoryLine->l049l01.l066l02.business_level_6_id_164);
		COPYI(i,		pLine->prov_bus_lev_7_id, generator(sizeof(pLine->prov_bus_lev_7_id)));//			pHistoryLine->l049l01.l066l02.business_level_7_id_164);
		ASSIGNI(i,		pLine->seq_num, generator(sizeof(pLine->seq_num)));//						pHistoryLine->l049l01.l055l02.sequence_number_142);
		COPYI(i,		pLine->status_expl, generator(sizeof(pLine->status_expl)));//					pHistoryLine->l049l01.l055l02.status_explanation_148);
		COPYI(i,		pLine->svc_line_expl_code, generator(sizeof(pLine->svc_line_expl_code)));//			pHistoryLine->l049l01.l056l02.l058l03.explanation_code_150);
		ASSIGNI_itos(i,	pLine->svc_line_expl_code_cnt, generator(sizeof(pLine->svc_line_expl_code_cnt)));//		pHistoryLine->l049l01.l056l02.l057l02.import_hist_nstd_grp_cla_013ma);
		ASSIGNI(i,		pLine->svc_line_num, generator(sizeof(pLine->svc_line_num)));//				pHistoryLine->l049l01.l055l02.service_number_142);
		ASSIGNI(i,		pLine->svc_line_ref, generator(sizeof(pLine->svc_line_ref)));//				pHistoryLine->l049l01.l067l02.service_number_165);
		COPYI(i,		pLine->svc_prov_id, generator(sizeof(pLine->svc_prov_id)));//					pHistoryLine->l049l01.l065l02.svc_provider_id_153);
		COPYI(i,		pLine->svc_prov_med_svc_area_code, generator(sizeof(pLine->svc_prov_med_svc_area_code)));//	pHistoryLine->l049l01.l065l02.svc_prov_med_svc_area_code_155);
		COPYI(i,		pLine->svc_prov_region_code, generator(sizeof(pLine->svc_prov_region_code)));//		pHistoryLine->l049l01.l065l02.svc_prov_region_code_154);
		COPYI(i,		pLine->svc_prov_spec_code, generator(sizeof(pLine->svc_prov_spec_code)));//			pHistoryLine->l049l01.l065l02.svc_prov_specialty_code_154);
		COPYI(i,		pLine->svc_prov_status_code, generator(sizeof(pLine->svc_prov_status_code)));//		pHistoryLine->l049l01.l065l02.svc_prov_status_code_154);
		ASSIGNI(i,		pLine->svc_units, generator(sizeof(pLine->svc_units)));//					pHistoryLine->l049l01.l055l02.service_units_count_149);
		ASSIGNI(i,		pLine->tax_id, generator(sizeof(pLine->tax_id)));//						pHistoryLine->l049l01.l065l02.tax_identifier_153);
		ASSIGNI(i,		pLine->thru_date, generator(sizeof(pLine->thru_date)));//					pHistoryLine->l049l01.l055l02.thru_date_142);
		COPYI(i,		pLine->treatment_type_code, generator(sizeof(pLine->treatment_type_code)));//			pHistoryLine->l049l01.l055l02.treatment_type_code_148);

		++pLine;
	}
}
