#include <string.h>
#include <stdio.h>

#ifndef GENERATOR_H_INCLUDED
#define GENERATOR_H_INCLUDED


#define COPY(dest, src) \
	memcpy( (dest), (src), sizeof(dest) );


#define COPYID(direction, index, delta, src) \
	COPY(delta, src);

#define ASSIGN(dest, src) \
	dest = 9;

#define ASSIGNID(direction, index, delta, src) \
    delta = 9;


#define ASSIGN_itos(dest, src) \
	dest = 9;

#define ASSIGNID_itos(direction, index, delta, src) \
	delta = 9;


#define COPYI(index, dest, src) \
	COPY(dest, src);

#define ASSIGNI(index, dest, src) \
	dest = 9;

#define ASSIGNI_itos(index, dest, src) \
	dest = 9;


char* generator(size_t size){
    char *out = (char*)malloc(size);
    for (int i = 0; i < size; i++){
        out[i] = i%10 + '0';
    }
    return out;
}

#endif