#include "../libextclient.h"
#include "../ddext/ddext1.h"
#include "../ddext/ddext2.h"
#include "allocate.h"
#include "ddext1_generator.h"
#include "ddext2_generator.h"
#include <string.h>
#include <stdio.h>

void print_ddext1(CONTROL_INFO *pCtl) {
    printf("call_was_successful: %s\n", pCtl->call_was_successful);
}

int ddext1(int nServices, int nIgnored, int nHistory) {

    CONTROL_INFO *pCtl = allocateItf1(nServices, nIgnored, nHistory);

    CreateControlInformation(pCtl, nServices, nIgnored, nHistory);
    CreateClaimHeader(pCtl->claim_header);
    CreateServiceLines(nServices, pCtl->service_line);
    CreateIgnoredServiceLine(nIgnored,  pCtl->ignored_service_line);
    CreateHistoryServiceLine(nHistory, pCtl->service_history_line);

    print_ddext1(pCtl);
    CallExtension1(pCtl);
    print_ddext1(pCtl);

    freeItf1(pCtl);

    return 0;
}

void print_ddext2(CONTROL_INFO_INC *pCtl) {
    printf("call_was_successful: %s\n", pCtl->call_was_successful);
}

int ddext2(int nServices, int nSubMemberRecords) {

    CONTROL_INFO_INC *pCtl = allocateItfInc1(nServices, nSubMemberRecords);

    CreateControlIncInformation(pCtl, nServices, nSubMemberRecords);
	CreateClaimHeaderInc(pCtl->claim_header);
	CreateDeltaServiceLinesInc(nServices, pCtl->service_line);
	CreateSubMemberRecordInc(nSubMemberRecords, pCtl->subscriber_member);

    print_ddext2(pCtl);
    CallExtension2(pCtl);
    print_ddext2(pCtl);

    freeItfInc1(pCtl);
    return 0;
}

int main() {

    ddext1(1,1,1);
    ddext2(1,1);
    ddext1(1,1,1);
    ddext2(1,1);

    return 0;
}
